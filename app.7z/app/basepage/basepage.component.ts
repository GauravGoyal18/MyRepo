import { Component, OnInit } from '@angular/core';
declare var $;

@Component({
  selector: 'app-basepage',
  templateUrl: './basepage.component.html',
  styleUrls: ['./basepage.component.scss']
})
export class BasepageComponent implements OnInit {
  screenTab = '1023px';
  //---------------------------------------------------------
  //---------------------------------------------------------
  //---- JSON URLs ------------------------------------------
  url_latest_nav = "https://10.54.16.24:9443/pensionFunds/iprupnsnfunds/navdetails.rest";
  url_latest_nav_sheet = "https://10.54.16.24:9443/pensionFunds/iprupnsnfunds/navExcel.rest"

  url_portfolio_details = "https://10.54.16.24:9443/pensionFunds/iprupnsnfunds/jsonReaders/portfolio-details.json";
  url_financial_reports = "https://10.54.16.24:9443/pensionFunds/iprupnsnfunds/jsonReaders/financial-reports.json";

  url_proxy_voting_detail = "https://10.54.16.24:9443/pensionFunds/iprupnsnfunds/jsonReaders/proxy-voting-details.json";
  url_policy = "https://10.54.16.24:9443/pensionFunds/iprupnsnfunds/jsonReaders/policy.json";
  url_nav_history = "https://10.54.16.24:9443/pensionFunds/iprupnsnfunds/navhistory.rest";
  url_regulatory_circulars = "https://10.54.16.24:9443/pensionFunds/iprupnsnfunds/jsonReaders/regulatory-circulars.json";

  url_form_submit = "https://localhost:8080/IPruPensionWEB/iprupnsnfunds/contactUsCustServiceFormSubmit.rest";

  //url_form_submit = "https://10.54.16.24:9443/pensionFunds/iprupnsnfunds/formSubmit.rest";
  url_buy_now = "https://10.54.16.24:9443/pensionFunds/iprupnsnfunds/buyNowRedirect.rest";

  url_fetch_user = "http://localhost:8080/IPruPensionWEB/iprupnsnfunds/getCorpAppForm/";

  url_personal_details = "http://localhost:8080/IPruPensionWEB/iprupnsnfunds/corpAppForm/";

  url_access_matrix = "http://localhost:8080/IPruPensionWEB/iprupnsnfunds/npsFetchUser/"  ;

  url_download_Corp_Nps_PDF = "http://localhost:8080/IPruPensionWEB/iprupnsnfunds/downloadPdf/";

/*   url_contact_us = "./assets/json/contact-us.php";
  url_customer_query = "./assets/json/customer-query.php"; */

  url_search_json = "./assets/json/search.json";

  //---------------------------------------------------------
  //---------------------------------------------------------
  //---------------------------------------------------------

  constructor() { 
  }

  ngOnInit() {
  }

  setupTable(jsonObj){
    var accordian = $("#refAccordian");
    var accordionTab = $(".accordion-tab");
    function updateTable(refDataTable, tableData, refAccordian){
      refDataTable.empty();      
      refDataTable.css({display:"inline-table"});
      if(tableData){ }else{ return; }
      var th = tableData.th;
      var tr = $('<tr>');
      refDataTable.append(tr);
      for (let j = 0; j < th.length; j++) {
        const thData = th[j];
        tr.append("<th align='center'>"+thData+"</th>");     
      }
      for (let j = 0; j < tableData.td.length; j++) {
        const tdData = tableData.td[j];
        var tr = $('<tr>')
        refDataTable.append(tr);
        for (let k = 0; k < tdData.length; k++) {
          const colData = tdData[k];
          if(k==0){
            tr.append("<td align='center'>"+colData+"</td>");
          }else{          
            if(colData==""){
              tr.append('<td align="center"></td>');
            } else{
              tr.append('<td align="center"><a href="'+colData+'" target="_blank"><img src="assets/images/download-icon.png" /></a></td>');
            }     
          }
        }         
      }
    }
    function setUpDropDown(dropDownUl, dropdown, refDataTable, refAccordian){      
      var select = dropDownUl.find("select");
      var optionArray = [];
      var dropdownList = dropdown.dropdownList;
      dropDownUl.css({display:"block"});
      dropDownUl.find(".dropdownInd").html(dropdown.dropdownInd);
      select.empty();
      for (let i = 0;  i< dropdownList.length; i++) {
        let info = dropdownList[i];
        var option = $("<option value=''>"+info.title+"</option>");
        option.data(info);
        optionArray.push(option);
        select.append(option);  
      }
      function showtable(index){
        var option = optionArray[index];
        var tableData = option.data().table;
        var downloadLineData = option.data().downloadLine;
        updateTable(refDataTable, tableData, refAccordian);
        showDownloadLine(downloadLineData, refAccordian);
        //console.log(option.data());
      }
      select.bind("change", function(){
        var option = $(this);
        showtable(this.selectedIndex);
      })
    }
    function showDownloadLine(downloadLineData, refAccordian){      
      var downloadLine = refAccordian.find(".download-line");
      downloadLine.css({display:"none"});
      //console.log(downloadLineData);
      if(downloadLineData && downloadLineData.text && downloadLineData.url){
        downloadLine.css({display:"block"});
        downloadLine.html(downloadLineData.text);
        var link = $('<a href="'+downloadLineData.url+'" target="_blank">Download Now</a>');
        downloadLine.append(link);
      }
    }
   


    var dataArr = jsonObj.data;
    for (let i = 0; i < dataArr.length; i++) {
      const data = dataArr[i]; 
      var refAccordian = accordian.clone();
      var refDataTable = refAccordian.find(".dataTable");
      var dropDownUl = refAccordian.find(".dropDownUl");
      var downloadLine = refAccordian.find(".download-line");
      
      refAccordian.css({display:"block"});
      accordionTab.append(refAccordian);
      refAccordian.find(".accordion_head").html(data.accTitle);        
      refDataTable.empty();
      refDataTable.css({display:"none"});
      dropDownUl.css({display:"none"}); 
      downloadLine.css({display:"none"});
      if(data.table){         
        updateTable(refDataTable, data.table, refAccordian);
      }else if(data.dropdown){          
        setUpDropDown(dropDownUl, data.dropdown, refDataTable, refAccordian);
      }             
    }
    $('.accordion-row').beefup({
      openSingle: true,
      scroll: true,
      scrollOffset:-95,
    });


    
  }



  setupListing(jsonObj){
    var navUL = $(".nav-data ul");
    function addLiToUl(infoData, parentEle){
      //console.log(infoData);
      if(infoData && infoData.url){
        var li = $('<li><a href="'+infoData.url+'" target="_blank">'+infoData.title+' <img src="assets/images/download-icon.png" /></a></li>');
        parentEle.append(li);
      }else if(infoData && infoData.data){
        var li = $(`<li class="year-end">
                      <a href="javascript:;">`+infoData.title+`</a>
                      <ul></ul>
                    </li>`);
        parentEle.append(li);
        for (let i = 0; i < infoData.data.length; i++) {
          const newInfoData = infoData.data[i];  
          addLiToUl(newInfoData, li.find("ul"));    
        }
      }
    }
    for (let i = 0; i < jsonObj.data.length; i++) {
      const infoData = jsonObj.data[i];  
      addLiToUl(infoData, navUL);    
    }
    //console.log(jsonObj);
    $(".year-end > a").on('click', function () {
      $(this).parent().find("ul").toggle(100);
    });
  }



  errorDialog(jsonObj,titleName){

    $("#error-dialog").html('<div>'+jsonObj.errorMessage+'</div>');
  
    $('#error-dialog').dialog({
  
      title: titleName,
      resizable: false,
  
      closeOnEscape: false,
  
      modal: true,
  
      width: 500,
  
      height: 200,
  
      buttons: [
  
        {
  
          text: "Ok",
  
          icon: "ui-icon-heart",
  
          click: function() {
  
           location.href="/home";
  
          }
  
        }],
  
        create: function (event, ui) {
  
   
  
          $(".ui-dialog").css('border-radius','0px');
  
          $(".ui-dialog").css('font-size','20px');
  
          $(".ui-dialog-title").css('color','#FFF');
  
          $(".ui-dialog-buttonset").css('color','#FFF');
  
          $(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
  
        
  
      },
  
   
  
    });

  }

  onSubmit(e){
    $.ajax({
      url: this.url_buy_now,
      dataType: "json",
      type: "GET",
      crossDomain: true,
      xhrFields: {
        withCredentials: true
      },
      success: function (data) {

        $("#karvy-dialog").html("<p class='dialogPara'>You will now be redirected to the website of Karvy Fintech Private Limited (Karvy Fintech), the Central Recordkeeping Agency (CRA), which has extended the facility for onboarding of the subscribers pursuant to the PFRDA circular number PFRDA/2018/49/CRA/2 dated June 12, 2018.</p>");
        $('#karvy-dialog').dialog({

          
          title:'Information',
          
          resizable: false,
      
          closeOnEscape: false,
      
          modal: true,
      
          width: 700,
      
          height: 310,
      
          buttons: [
      
            {
      
              text: "OK",
      
              icon: "ui-icon-heart",
      
              click: function() {
      
                (<HTMLInputElement>document.getElementById('CRACODE')).value=data[0]; 
                (<HTMLInputElement>document.getElementById('UniqueTranCode')).value = data[1];
                (<HTMLInputElement>document.getElementById('EncUniqueKey')).value = data[2];
                (<HTMLInputElement>document.getElementById('RandomNo')).value  = data[3];
  
                var f = (<HTMLFormElement>document.getElementById('redirectForm'));
                f.submit();
                $('#karvy-dialog').dialog("close" );
              }
      
            },
          {
            text:"Close",
            click: function() {
              $('#karvy-dialog').dialog("close" );
            }
          }],
      
            create: function (event, ui) {
      
       
      
              $(".ui-dialog").css('border-radius','0px');
      
              $(".ui-dialog").css('font-size','20px');
      
              $(".ui-dialog-title").css('color','#FFF');
      
              $(".ui-dialog-buttonset").css('color','#FFF');
      
              $(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
      
            
      
          },
      
       
      
        });
  
      
       
      },
      error: function () {
        alert('Something went wrong. Please try after sometime');
      },
      
    
   
  })
  }



}
