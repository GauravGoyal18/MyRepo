import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $;

@Component({
  selector: 'app-about-nps-investment-options',
  templateUrl: './about-nps-investment-options.component.html',
  styleUrls: ['./about-nps-investment-options.component.scss']
})
export class AboutNpsInvestmentOptionsComponent extends BasepageComponent implements OnInit {

  constructor() {
    super();
  }

  ngOnInit() {
    //document.getElementById("defaultOpen").click();
    $("#tab1").click(function () {
      $("#tabCont1").fadeIn();
      $("#tabCont2").hide();
      $("#tab1").addClass("active");
      $(".tab2").removeClass("active")
    });
   
    $(".tab2").click(function () {
      $("#tabCont2").fadeIn();
      $("#tabCont1").hide();
      $(".tab2").addClass("active");
      $("#tab1").removeClass("active")
   
    });






    $('.accordion-row').beefup({
      openSingle: true,
      scroll: true,
      scrollOffset:-95,
    });


    $(".tab a").click(function (evt) {
      var cityName = $(this).data("value")
      var i, tabcontent, tablinks;

      // Get all elements with class="tabcontent" and hide them
      tabcontent = document.getElementsByClassName("tabText");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }

      // Get all elements with class="tablinks" and remove the class "active"
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }

      // Show the current tab, and add an "active" class to the button that opened the tab
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    })

    /* function openCity(evt, cityName) {
      // Declare all variables
      var i, tabcontent, tablinks;
    
      // Get all elements with class="tabcontent" and hide them
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
    
      // Get all elements with class="tablinks" and remove the class "active"
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
    
      // Show the current tab, and add an "active" class to the button that opened the tab
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    }*/

  }

}
