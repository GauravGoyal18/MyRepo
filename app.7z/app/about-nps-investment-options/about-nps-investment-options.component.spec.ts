import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AboutNpsInvestmentOptionsComponent } from './about-nps-investment-options.component';



describe('AboutNpsInvestmentOptionsComponent', () => {
  let component: AboutNpsInvestmentOptionsComponent;
  let fixture: ComponentFixture<AboutNpsInvestmentOptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AboutNpsInvestmentOptionsComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsInvestmentOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});


