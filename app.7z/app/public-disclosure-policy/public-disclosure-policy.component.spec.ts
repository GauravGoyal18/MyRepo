import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicDisclosurePolicyComponent } from './public-disclosure-policy.component';

describe('PublicDisclosurePolicyComponent', () => {
  let component: PublicDisclosurePolicyComponent;
  let fixture: ComponentFixture<PublicDisclosurePolicyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicDisclosurePolicyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicDisclosurePolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
