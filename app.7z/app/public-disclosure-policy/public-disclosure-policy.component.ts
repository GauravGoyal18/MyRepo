import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $;

@Component({
  selector: 'app-public-disclosure-policy',
  templateUrl: './public-disclosure-policy.component.html',
  styleUrls: ['./public-disclosure-policy.component.scss']
})
export class PublicDisclosurePolicyComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    $.getJSON(this.url_policy,  ( jsonObj ) =>{
     
      if(!jsonObj.hasOwnProperty( 'errorMessage')){
        this.setupListing(jsonObj);
      }else{
        this.errorDialog(jsonObj,"Policy");
      }
    });  

  }
}
