import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutNpsOverviewComponent } from './about-nps-overview.component';

describe('AboutNpsOverviewComponent', () => {
  let component: AboutNpsOverviewComponent;
  let fixture: ComponentFixture<AboutNpsOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutNpsOverviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
