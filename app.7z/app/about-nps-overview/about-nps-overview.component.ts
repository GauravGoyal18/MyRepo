import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-about-nps-overview',
  templateUrl: './about-nps-overview.component.html',
  styleUrls: ['./about-nps-overview.component.scss']
})
export class AboutNpsOverviewComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
