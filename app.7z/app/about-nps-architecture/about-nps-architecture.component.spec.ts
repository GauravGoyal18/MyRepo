import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutNpsArchitectureComponent } from './about-nps-architecture.component';

describe('AboutNpsArchitectureComponent', () => {
  let component: AboutNpsArchitectureComponent;
  let fixture: ComponentFixture<AboutNpsArchitectureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutNpsArchitectureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsArchitectureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
