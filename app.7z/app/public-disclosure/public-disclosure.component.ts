import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-public-disclosure',
  templateUrl: './public-disclosure.component.html',
  styleUrls: ['./public-disclosure.component.scss']
})
export class PublicDisclosureComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
