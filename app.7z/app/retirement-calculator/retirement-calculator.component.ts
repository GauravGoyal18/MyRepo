import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $: Function;
@Component({
  selector: 'app-retirement-calculator',
  templateUrl: './retirement-calculator.component.html',
  styleUrls: ['./retirement-calculator.component.scss']
})
export class RetirementCalculatorComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    var slideSmoothVal = 10;
    function setUpSlider(props){
      var sliderRef = $(props.id);
      sliderRef.slider({
        range: "min",
        value: props.inValue*slideSmoothVal,
        min: props.min*slideSmoothVal,
        max: props.max*slideSmoothVal,
        slide: function( event, ui ) {
          sliderRef.find(".ui-slider-handle").html( Math.round(ui.value/slideSmoothVal)+props.postFix );
          setTimeout(function(){
            calculate();
          }, 40);          
        }
      });
      sliderRef.find(".ui-slider-handle").html(props.inValue+props.postFix);
    }
    function setOnChange(props){
      $(props.id).change(function(){
        //console.log("change")
        calculate();
      })
      $(props.id).keyup(function(){
        //console.log("change")
        calculate();
      })
    }
    setUpSlider({id:"#retAnnuityRateThen", inValue:8, min:2, max:20, postFix:"%"});
	  setUpSlider({id:"#retGrowthRate", inValue:8, min:5, max:20, postFix:"%"});
	  setUpSlider({id:"#retCurrentage", inValue:22, min:18, max:60, postFix:""});
    setUpSlider({id:"#retRetirementage", inValue:57, min:41, max:60, postFix:""});
    setOnChange({id:"#annualPensionAmountInLac"})
  
    function calculate(){ 
      //console.log("D")
      /* var currentAge = Number($("#currentage").slider( "value" ));
      var retirementAge = Number($("#retirementage").slider( "value" ));
      var growthRate = Number($("#growthRate").slider( "value" ));
      var corpusreinvested = Number($("#corpusreinvested").slider( "value" ));
      var expectedROI = Number($("#expectedROI").slider( "value" ));
      var monthlyContribution = Number($("#monthlyContribution").val());
      var totalInvetPeriod = retirementAge - currentAge;
      var totalNumOfMonths = totalInvetPeriod*12; */
      var annualPensionAmountInLac = Math.round(Number($("#annualPensionAmountInLac").val()));

      var retAnnuityRateThen = Math.round(Number($("#retAnnuityRateThen").slider( "value" ))/slideSmoothVal);
      var retGrowthRate = Math.round(Number($("#retGrowthRate").slider( "value" ))/slideSmoothVal);
      var retCurrentage = Math.round(Number($("#retCurrentage").slider( "value" ))/slideSmoothVal);
      var retRetirementage = Math.round(Number($("#retRetirementage").slider( "value" ))/slideSmoothVal);
      
      var annualPensionAmount = annualPensionAmountInLac*100000;
      var int = retAnnuityRateThen;
      
     
      //
      var corpusRequired = Math.round((annualPensionAmount * 100) / retAnnuityRateThen);
      var totalYear = retRetirementage - retCurrentage;
      if(totalYear<0){
        totalYear = 0;
      }
      var totalMonth = totalYear*12;
      var pensionPerMonth = Math.abs(Math.round(PMT((retGrowthRate / 1200), totalMonth, 0, corpusRequired, 1)));
      if(totalMonth<=0){
        pensionPerMonth = 0;
      }

      $("#corpusRequired").val(corpusRequired);
      $("#totalYear").val(totalYear);
      $("#totalMonth").val(totalMonth);
      $("#pensionPerMonth").val(pensionPerMonth);
      
      
    } 
    calculate();
    function PMT(rate, nperiod, pv, fv, type) {
      if (!fv) fv = 0;
      if (!type) type = 0;
      if (rate == 0) return -(pv + fv) / nperiod;
      var pvif = Math.pow(1 + rate, nperiod);
      var pmt = rate / (pvif - 1) * -(pv * pvif + fv);
      if (type == 1) {
         pmt /= (1 + rate);
      };
      return pmt;
   }
  }

}
