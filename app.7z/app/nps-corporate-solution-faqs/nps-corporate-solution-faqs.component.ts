import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $: Function;

@Component({
  selector: 'app-nps-corporate-solution-faqs',
  templateUrl: './nps-corporate-solution-faqs.component.html',
  styleUrls: ['./nps-corporate-solution-faqs.component.scss']
})
export class NpsCorporateSolutionFaqsComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    $('.accordion-row').beefup({
      openSingle: true,
      scroll: true,
      scrollOffset:-95,
    });
  }

}
