import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NpsCorporateSolutionFaqsComponent } from './nps-corporate-solution-faqs.component';

describe('NpsCorporateSolutionFaqsComponent', () => {
  let component: NpsCorporateSolutionFaqsComponent;
  let fixture: ComponentFixture<NpsCorporateSolutionFaqsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NpsCorporateSolutionFaqsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NpsCorporateSolutionFaqsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
