import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $: Function;
@Component({
  selector: 'app-about-us-why-choose-icici',
  templateUrl: './about-us-why-choose-icici.component.html',
  styleUrls: ['./about-us-why-choose-icici.component.scss']
})
export class AboutUsWhyChooseIciciComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {

    var ww = $(window).width();

    if (ww <= 1023) {
      $('#slidercirclelist').slick({
        autoplay: false,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll:1,
        dots: true,
        arrows: true,
      });
    }
    else{

    }

    
  }
}
