import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutUsWhyChooseIciciComponent } from './about-us-why-choose-icici.component';

describe('AboutUsWhyChooseIciciComponent', () => {
  let component: AboutUsWhyChooseIciciComponent;
  let fixture: ComponentFixture<AboutUsWhyChooseIciciComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutUsWhyChooseIciciComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutUsWhyChooseIciciComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
