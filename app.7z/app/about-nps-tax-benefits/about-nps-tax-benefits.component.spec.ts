import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutNpsTaxBenefitsComponent } from './about-nps-tax-benefits.component';

describe('AboutNpsTaxBenefitsComponent', () => {
  let component: AboutNpsTaxBenefitsComponent;
  let fixture: ComponentFixture<AboutNpsTaxBenefitsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutNpsTaxBenefitsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsTaxBenefitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
