import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-about-nps-tax-benefits',
  templateUrl: './about-nps-tax-benefits.component.html',
  styleUrls: ['./about-nps-tax-benefits.component.scss']
})
export class AboutNpsTaxBenefitsComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
