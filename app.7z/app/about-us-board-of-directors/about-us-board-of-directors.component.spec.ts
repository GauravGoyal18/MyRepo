import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutUsBoardOfDirectorsComponent } from './about-us-board-of-directors.component';

describe('AboutUsBoardOfDirectorsComponent', () => {
  let component: AboutUsBoardOfDirectorsComponent;
  let fixture: ComponentFixture<AboutUsBoardOfDirectorsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutUsBoardOfDirectorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutUsBoardOfDirectorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
