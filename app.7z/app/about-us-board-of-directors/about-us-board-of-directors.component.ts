import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-about-us-board-of-directors',
  templateUrl: './about-us-board-of-directors.component.html',
  styleUrls: ['./about-us-board-of-directors.component.scss']
})

export class AboutUsBoardOfDirectorsComponent extends BasepageComponent implements OnInit {
  closeResult: string;

  constructor(private modalService: NgbModal){ 
    super();
  }

  ngOnInit() {
  }
  
   open(content) {
    this.modalService.open(content).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  } 

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  } 

  

}
