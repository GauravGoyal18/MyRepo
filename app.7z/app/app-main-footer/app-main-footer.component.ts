import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-footer',
  templateUrl: './app-main-footer.component.html',
  styleUrls: ['./app-main-footer.component.scss']
})
export class AppMainFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}