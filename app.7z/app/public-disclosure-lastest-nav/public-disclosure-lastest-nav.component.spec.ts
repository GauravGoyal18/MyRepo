import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicDisclosureLastestNavComponent } from './public-disclosure-lastest-nav.component';

describe('PublicDisclosureLastestNavComponent', () => {
  let component: PublicDisclosureLastestNavComponent;
  let fixture: ComponentFixture<PublicDisclosureLastestNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicDisclosureLastestNavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicDisclosureLastestNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
