import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $;
@Component({
  selector: 'app-public-disclosure-lastest-nav',
  templateUrl: './public-disclosure-lastest-nav.component.html',
  styleUrls: ['./public-disclosure-lastest-nav.component.scss']
})
export class PublicDisclosureLastestNavComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {    
    //console.log(this.url_latest_nav);
    var navTable = $(".latestNavTable");
    $.getJSON(this.url_latest_nav, function( jsonObj ) {
      var dataArr = jsonObj.data;
      for (let i = 0; i < dataArr.length; i++) {
        const data = dataArr[i]; 
        const headerData = data.th; 
        var tr = $('<tr>');``
        navTable.append(tr);
        for (let j = 0; j < headerData.length; j++) {
          const innerHeaderData = headerData[j];
          tr.append("<th>"+innerHeaderData+"</th>");     
        }


        for (let j = 0; j < data.td.length; j++) {
          const innerData = data.td[j];
          var tr = $('<tr>')
          navTable.append(tr);
          for (let k = 0; k < innerData.length; k++) {
            const colData = innerData[k];
            tr.append("<td>"+colData+"</td>");
          }
          //console.log(innerData);          
        }
        
      }
    });
  }

}
