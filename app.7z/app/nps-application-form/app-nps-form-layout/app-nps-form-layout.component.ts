import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nps-form-layout',
  templateUrl: './app-nps-form-layout.component.html',
  styleUrls: ['./app-nps-form-layout.component.scss']
})
export class AppNpsFormLayoutComponent implements OnInit {
  

  constructor() { }

  ngOnInit() {
    
  }

}