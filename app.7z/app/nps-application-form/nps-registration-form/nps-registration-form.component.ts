import { Component, OnInit, Input, ViewChild } from '@angular/core';
import {FormBuilder, FormGroup, Validators,FormControl} from '@angular/forms';
import {MatIconRegistry, MatStepper} from '@angular/material';
declare var $;

import { PersonAddContactDetailsPO } from '../child-nps-classes/AddressDetailsPo';
import { NpsPersonalDetails } from '../child-nps-classes/RegistrationForm';
import { forbiddenNameValidator } from '../ui-validation/ui-validation.directive';
import { BasepageComponent } from '../../basepage/basepage.component';
import { GoogleAnalyticsEventsService } from '../../google-analytics-events.service';
import { NpsPersonalShareDataService } from '../../nps-personal-shareddata.service';

@Component({
  selector: 'app-nps-registration-form',
  templateUrl: './nps-registration-form.component.html',
  styleUrls: ['./nps-registration-form.component.scss']
})
export class NpsRegistrationFormComponent extends BasepageComponent {
  isLinear = true;
  globalApplicationNumber: any;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  fourthFormGroup: FormGroup;
  fifthFormGroup: FormGroup;
  sixthFormGroup: FormGroup;
  seventhFormGroup: FormGroup;
  eighthFormGroup: FormGroup;
  ninthFormGroup: FormGroup;
  tenthFormGroup: FormGroup;
  
  public NpsPersonal : NpsPersonalDetails;
  public NpsProofOfAddress =new PersonAddContactDetailsPO();
  //public NpsProofOfAddress:personAddContactDetailsPO;
  dynamic: number;
  jsonMap : any;
  accessMatrixRef:any;
  dropDownMap : any;
  pageNamesMap = new Map();
  fieldNamesMap = new Map();
  sectionMap = new Map();
  editFieldMap = new Map();
  mandatoryfieldsMap = new Map();
  url: string;
  tabFilled : string;
  //personIdEncrypted : string;
  corpUid : string;
  user: any;
  @ViewChild('stepper') stepper: MatStepper;
  @ViewChild('testId') testId: any;
  constructor(private _formBuilder: FormBuilder,private googleAnalyticsEventsService : GoogleAnalyticsEventsService,public npsPrsnlShrDtSrvc : NpsPersonalShareDataService){ 
    super();
    this.url = this.googleAnalyticsEventsService.getUrl();
  }




  ngOnInit() {
  //Added to fetch UID
  var urlArray = this.url.split('/');
  this.corpUid = urlArray.pop();
  //Added to fetch UID

  this.NpsPersonal = this.npsPrsnlShrDtSrvc.getOption();

if(this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo!=null && this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo!= "" && this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo!= undefined){
  
  var tabFilled = this.NpsPersonal.personApplicationFormDetailsPO.tabFilled;
  var tabfilledArray =tabFilled.split(''); 
  var tabFilledVal = tabfilledArray.pop();
  if(tabFilledVal=='P')
  {
    this.stepper.selectedIndex = 0;
  }
  else if (tabFilledVal=='A')
  {
    this.stepper.selectedIndex = 1;
  }
  else if(tabFilledVal=='B')
  {
    this.stepper.selectedIndex = 2;
  }
  else if(tabFilledVal=='O')
  {
    this.stepper.selectedIndex = 3;
  }
  else if(tabFilledVal=='S')
  {
    this.stepper.selectedIndex = 4;
  }
 /*  else
  {
    this.stepper.selectedIndex = 5;
  } */
}  
  

  this.jsonMap = this.getAccessMatrix1();

  this.accessMatrixRef = this.jsonMap.accessMatrix;
  this.dropDownMap = this.jsonMap.dropDownMap;
  this.user = this.jsonMap.user


  this.accessMatrixRef.forEach(element => {
    this.pageNamesMap.set(element.section.page.p_pageName,element.section.page.roleAccessMatix.amHasRead); //Map created to Show-Hide Pages
    this.fieldNamesMap.set(element.sfmFieldName,element.sfmShow); //Map created to Show-Hide Fields
    this.sectionMap.set(element.section.sectionName,element.section.sectionShow); //Map created to Show-Hide Sections
    this.editFieldMap.set(element.sfmFieldName,element.sfmEdit); //Map created to make fields editable or non-editable
    this.mandatoryfieldsMap.set(element.sfmFieldName,element.sfmMandatory); // Map created for Mandatory Fields
  });

    let value = Math.floor(Math.random() * 100 + 1);
    this.dynamic = value;

    this.firstFormGroup = this._formBuilder.group({
      'salutation': new FormControl(this.NpsPersonal.salutation),
      'fName': new FormControl(this.NpsPersonal.fName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'maidenName': new FormControl(this.NpsPersonal.maidenName,[Validators.minLength(0),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'fatherName': new FormControl(this.NpsPersonal.fatherName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'motherName': new FormControl(this.NpsPersonal.motherName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'dob': new FormControl(this.NpsPersonal.dob,[Validators.required]),
      'birthCity': new FormControl(this.NpsPersonal.birthCity,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("CITY_VALIDATION")]),
      'birthCountry': new FormControl(this.NpsPersonal.birthCountry,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'gender': new FormControl(this.NpsPersonal.gender,[Validators.required]),
      'nationality': new FormControl(this.NpsPersonal.nationality),
      'maritalStatus': new FormControl(this.NpsPersonal.maritalStatus,[Validators.required]),
      'spouseName': new FormControl(this.NpsPersonal.spouseName,[Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'resStatus': new FormControl(this.NpsPersonal.resStatus),
      'document': new FormControl(this.NpsPersonal.personDocDetailsPO.poiDropDown_poiNumber,[Validators.required]),
      'documentNumber': new FormControl(this.NpsPersonal.personDocDetailsPO.poiNumber,[Validators.required]),
      'documentName': new FormControl(this.NpsPersonal.personDocDetailsPO.documentName),
      'docExpiryDate': new FormControl(this.NpsPersonal.personDocDetailsPO.docExpiryDate,[Validators.required]),
       
    },{ updateOn: 'blur' });
  
    this.secondFormGroup = this._formBuilder.group({
      'proofOfAddress': new FormControl(this.NpsPersonal.personAddContactDetailsPO[0].proofOfAddress,[Validators.required]),
      'corresAddType' : new FormControl(this.NpsPersonal.personAddContactDetailsPO[0].corresAddType,[Validators.required]),
      'corresFlat': new FormControl(this.NpsPersonal.personAddContactDetailsPO[0]. corresFlat,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("ALPHANUMARIC_VALIDATION")]),
      'corresLandMark':new FormControl(this.NpsPersonal.personAddContactDetailsPO[0].corresLandMark,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("LANDMARK_VALIDATION")]),
      'corresPremises' : new FormControl(this.NpsPersonal.personAddContactDetailsPO[0].corresPremises,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'corresRoad' : new FormControl(this.NpsPersonal.personAddContactDetailsPO[0].corresRoad,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("ADDRESS_VALIDATION")]),
      'corresArea' : new FormControl(this.NpsPersonal.personAddContactDetailsPO[0].corresArea,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'corresCity' : new FormControl(this.NpsPersonal.personAddContactDetailsPO[0].corresCity,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("CITY_VALIDATION")]),
      'corresPincode' : new FormControl(this.NpsPersonal.personAddContactDetailsPO[0].corresPincode,[Validators.required,Validators.minLength(3),Validators.maxLength(6),forbiddenNameValidator("INDIAN_PINCODE_VALIDATION")]),
      'corresState' : new FormControl(this.NpsPersonal.personAddContactDetailsPO[0].corresState,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'corresCountry' : new FormControl(this.NpsPersonal.personAddContactDetailsPO[0].corresCountry,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'proofOfAddressPerm': new FormControl(this.NpsPersonal.personAddContactDetailsPO[1].proofOfAddress,[Validators.required]),
      'permAddType' : new FormControl(this.NpsPersonal.personAddContactDetailsPO[1].corresAddType,[Validators.required]),
      'permFlat': new FormControl(this.NpsPersonal.personAddContactDetailsPO[1]. corresFlat,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("ALPHANUMARIC_VALIDATION")]),
      'permLandMark':new FormControl(this.NpsPersonal.personAddContactDetailsPO[1].corresLandMark,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("LANDMARK_VALIDATION")]),
      'permPermises':new FormControl(this.NpsPersonal.personAddContactDetailsPO[1].corresPremises,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'permRoad': new FormControl(this.NpsPersonal.personAddContactDetailsPO[1].corresRoad,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("ADDRESS_VALIDATION")]),
      'permArea': new FormControl(this.NpsPersonal.personAddContactDetailsPO[1].corresArea,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'permCity': new FormControl(this.NpsPersonal.personAddContactDetailsPO[1].corresCity,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("CITY_VALIDATION")]),
      'permPincode': new FormControl(this.NpsPersonal.personAddContactDetailsPO[1].corresPincode,[Validators.required,Validators.minLength(3),Validators.maxLength(6),forbiddenNameValidator("INDIAN_PINCODE_VALIDATION")]),
      'permState': new FormControl(this.NpsPersonal.personAddContactDetailsPO[1].corresState,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'permCountry': new FormControl(this.NpsPersonal.personAddContactDetailsPO[1].corresCountry,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'officeTel':new FormControl(this.NpsPersonal.officeTel,[forbiddenNameValidator("LANDLINE_VALIDATION")]),
      'resTel':new FormControl(this.NpsPersonal.resTel,[forbiddenNameValidator("LANDLINE_VALIDATION")]),
      'mobile':new FormControl(this.NpsPersonal.mobile,[Validators.required,Validators.maxLength(10),forbiddenNameValidator("MOBILE_VALIDATION")]),
      'emailId':new FormControl(this.NpsPersonal.emailId,[forbiddenNameValidator("EMAIL_VALIDATION")]), 
      
    },{ updateOn: 'blur' });
    
    this.thirdFormGroup = this._formBuilder.group({
      'occupationDetails':new FormControl(this.NpsPersonal.occupationDetails,[Validators.required]),
      'otheroccupation':new FormControl(this.NpsPersonal.otheroccupation,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'incomeRange':new FormControl(this.NpsPersonal.incomeRange),
      'eduQualifictn':new FormControl(this.NpsPersonal.eduQualifictn),
      'politicalRelantinshp':new FormControl(this.NpsPersonal.politicalRelantinshp),
      'accType':new FormControl('',[Validators.required]),
      'accNo':new FormControl(this.NpsPersonal.personBankDetailsPO.accNo,[Validators.required,Validators.minLength(9),Validators.maxLength(18),forbiddenNameValidator("BANKACCOUNTNUMBER_VALIDATION")]),
      'bankName': new FormControl(this.NpsPersonal.personBankDetailsPO.bankName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("BANKNAME_VALIDATION")]),
      'branchName': new FormControl(this.NpsPersonal.personBankDetailsPO.branchName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'bankAddress':new FormControl(this.NpsPersonal.personBankDetailsPO.bankAddress,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("ADDRESS_VALIDATION")]),
      'bankPincode':new FormControl(this.NpsPersonal.personBankDetailsPO.bankPincode,[Validators.required,Validators.minLength(3),Validators.maxLength(6),forbiddenNameValidator("INDIAN_PINCODE_VALIDATION")]),
      'bankState':new FormControl(this.NpsPersonal.personBankDetailsPO.bankState,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'bankCountry':new FormControl(this.NpsPersonal.personBankDetailsPO.bankCountry,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'micr':new FormControl(this.NpsPersonal.personBankDetailsPO.micr,[Validators.required,forbiddenNameValidator("MICR_CODE_VALIDATION")]),
      'ifsc':new FormControl(this.NpsPersonal.personBankDetailsPO.ifsc,[Validators.required,Validators.minLength(11),Validators.maxLength(11),forbiddenNameValidator("IFSC_CODE_VALIDATION")]),
      'nomFName':new FormControl(this.NpsPersonal.nomineeDetailsPO.nomFName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'nomMName':new FormControl(this.NpsPersonal.nomineeDetailsPO.nomMName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'nomLName':new FormControl(this.NpsPersonal.nomineeDetailsPO.nomLName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'relationWNom':new FormControl(this.NpsPersonal.nomineeDetailsPO.relationWNom,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'nomDob':new FormControl(this.NpsPersonal.nomineeDetailsPO.nomDob,[Validators.required]),
      'guardFName':new FormControl(this.NpsPersonal.nomineeDetailsPO.guardFName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'guardMName':new FormControl(this.NpsPersonal.nomineeDetailsPO.guardMName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),
      'guardLName':new FormControl(this.NpsPersonal.nomineeDetailsPO.guardLName,[Validators.required,Validators.minLength(3),Validators.maxLength(30),forbiddenNameValidator("NAME_VALIDATION")]),

},{ updateOn: 'blur' });


    this.fourthFormGroup = this._formBuilder.group({
      'pensionFundName': new FormControl(this.NpsPersonal.personApplicationFormDetailsPO.pensionFundName),
      'investmentOption': new FormControl(this.NpsPersonal.personApplicationFormDetailsPO.investmentOption),
      'autoChoiceLC': new FormControl(this.NpsPersonal.personApplicationFormDetailsPO.autoChoiceLC,[Validators.required]),
    },{ updateOn: 'blur'});


   
    this.fifthFormGroup = this._formBuilder.group({
     
         'c1TaxResidence':new FormControl(this.NpsPersonal.personFATCADetailsPO[0].c1TaxResidence,[Validators.required,forbiddenNameValidator("ADDRESS_VALIDATION")]),
         'c1AddressLine1':new FormControl(this.NpsPersonal.personFATCADetailsPO[0].c1AddressLine1,[Validators.required,forbiddenNameValidator("ADDRESS_VALIDATION")]),
         'c1City':new FormControl(this.NpsPersonal.personFATCADetailsPO[0].c1City,[Validators.required,forbiddenNameValidator("CITY_VALIDATION")]),
           'c1State':new FormControl(this.NpsPersonal.personFATCADetailsPO[0].c1State,[Validators.required,forbiddenNameValidator("NAME_VALIDATION")]),
          'c1Zip':new FormControl(this.NpsPersonal.personFATCADetailsPO[0].c1Zip,[Validators.required,forbiddenNameValidator("INDIAN_PINCODE_VALIDATION")]),
           'c1Validity':new FormControl(this.NpsPersonal.personFATCADetailsPO[0].c1Validity,[Validators.required]),
           'c1TIN':new FormControl(this.NpsPersonal.personFATCADetailsPO[0].c1TIN,[Validators.required,,forbiddenNameValidator("TIN_VALIDATION")]),
           'c1TinCountry':new FormControl(this.NpsPersonal.personFATCADetailsPO[0].c1TinCountry,[Validators.required,forbiddenNameValidator("NAME_VALIDATION")]),
           'c1TaxResidence_1':new FormControl(this.NpsPersonal.personFATCADetailsPO[1].c1TaxResidence,[Validators.required,forbiddenNameValidator("ADDRESS_VALIDATION")]),
           'c1AddressLine1_1':new FormControl(this.NpsPersonal.personFATCADetailsPO[1].c1AddressLine1,[Validators.required,forbiddenNameValidator("ADDRESS_VALIDATION")]),
           'c1City_1':new FormControl(this.NpsPersonal.personFATCADetailsPO[1].c1City,[Validators.required,forbiddenNameValidator("CITY_VALIDATION")]),
             'c1State_1':new FormControl(this.NpsPersonal.personFATCADetailsPO[1].c1State,[Validators.required,forbiddenNameValidator("NAME_VALIDATION")]),
            'c1Zip_1':new FormControl(this.NpsPersonal.personFATCADetailsPO[1].c1Zip,[Validators.required,forbiddenNameValidator("INDIAN_PINCODE_VALIDATION")]),
             'c1Validity_1':new FormControl(this.NpsPersonal.personFATCADetailsPO[1].c1Validity,[Validators.required]),
             'c1TIN_1':new FormControl(this.NpsPersonal.personFATCADetailsPO[1].c1TIN,[Validators.required,,forbiddenNameValidator("TIN_VALIDATION")]),
             'c1TinCountry_1':new FormControl(this.NpsPersonal.personFATCADetailsPO[1].c1TinCountry,[Validators.required,forbiddenNameValidator("NAME_VALIDATION")]),
           'c1TaxResidence_2':new FormControl(this.NpsPersonal.personFATCADetailsPO[2].c1TaxResidence,[Validators.required,forbiddenNameValidator("ADDRESS_VALIDATION")]),
           'c1AddressLine1_2':new FormControl(this.NpsPersonal.personFATCADetailsPO[2].c1AddressLine1,[Validators.required,forbiddenNameValidator("ADDRESS_VALIDATION")]),
           'c1City_2':new FormControl(this.NpsPersonal.personFATCADetailsPO[2].c1City,[Validators.required,forbiddenNameValidator("CITY_VALIDATION")]),
             'c1State_2':new FormControl(this.NpsPersonal.personFATCADetailsPO[2].c1State,[Validators.required,forbiddenNameValidator("NAME_VALIDATION")]),
            'c1Zip_2':new FormControl(this.NpsPersonal.personFATCADetailsPO[2].c1Zip,[Validators.required,forbiddenNameValidator("INDIAN_PINCODE_VALIDATION")]),
             'c1Validity_2':new FormControl(this.NpsPersonal.personFATCADetailsPO[2].c1Validity,[Validators.required]),
             'c1TIN_2':new FormControl(this.NpsPersonal.personFATCADetailsPO[2].c1TIN,[Validators.required,,forbiddenNameValidator("TIN_VALIDATION")]),
             'c1TinCountry_2':new FormControl(this.NpsPersonal.personFATCADetailsPO[2].c1TinCountry,[Validators.required,forbiddenNameValidator("NAME_VALIDATION")]),
        },{ updateOn: 'blur' });
       

    this.sixthFormGroup = this._formBuilder.group({
      
    });
    this.seventhFormGroup = this._formBuilder.group({
      
    });
    this.eighthFormGroup = this._formBuilder.group({
      
    });
    this.ninthFormGroup = this._formBuilder.group({
      
    });
    this.tenthFormGroup = this._formBuilder.group({
      
    });
    
  }

  onStepChange(event){
    if(event.selectedIndex == 5){
      this.submitSubscriberDetails();
    }
  
  }
  submitNPSApplicationForm(){
    var This = this;
    var PersonPoJson : NpsPersonalDetails;
    $.ajax({
      url: this.url_personal_details,
      dataType: "json",
      contentType: "application/json",
      type: "POST",
      async: false,
      data : JSON.stringify(this.NpsPersonal),
      success: function (NpsPersonalPOJson) {

        if(NpsPersonalPOJson.hasOwnProperty('errorMessage')){
          This.errorDialog(NpsPersonalPOJson,"NPS Application");
         }

      },
      error: function (e) {
         alert('Something went wrong. Please try after sometime');
      },
    })
   // this.globalApplicationNumber = PersonPoJson.personApplicationFormDetailsPO.npsAppNo;
    this.npsPrsnlShrDtSrvc.setOption(PersonPoJson);
  }
  
  submitPersonalDetails(){
    if(this.firstFormGroup.status == 'VALID'){
      this.NpsPersonal.personApplicationFormDetailsPO.tabFilled = "P";
      //this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo = this.globalApplicationNumber;
      this.submitNPSApplicationForm();
    }
  } 

  submitAddressDetails(){
    if(this.secondFormGroup.status == 'VALID'){
      //this.NpsPersonal.personId = this.personIdEncrypted;
      this.NpsPersonal.personApplicationFormDetailsPO.tabFilled = "A";
      //this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo = this.globalApplicationNumber;
      this.submitNPSApplicationForm();
    }
  } 

  submitBankDetails(){
    if(this.thirdFormGroup.status == 'VALID'){
      //this.NpsPersonal.personId = this.personIdEncrypted;
      this.NpsPersonal.personApplicationFormDetailsPO.tabFilled = "B";
      //this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo = this.globalApplicationNumber;
      this.submitNPSApplicationForm();
    }
  } 

  submitOptionDetails(){
    if(this.fourthFormGroup.status == 'VALID'){
      //this.NpsPersonal.personId = this.personIdEncrypted;
      this.NpsPersonal.personApplicationFormDetailsPO.tabFilled = "O";
     // this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo = this.globalApplicationNumber;
       this.submitNPSApplicationForm();
    }
  }

  submitSubscriberDetails(){
    if(this.thirdFormGroup.status == 'VALID'){
     // this.NpsPersonal.personId = this.personIdEncrypted;
      this.NpsPersonal.personApplicationFormDetailsPO.tabFilled = "S";
     // this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo = this.globalApplicationNumber;
      this.submitNPSApplicationForm();
    }
  } 

    //Gets the access matrix from backend
    getAccessMatrix1(){
      var This = this;
      var accessMatrixRef = [];
        $.ajax({
          url: this.url_access_matrix.concat(this.corpUid),
          dataType: "json",
          type: "GET",
          async: false,
          success: function (jsonObj) {
          if(jsonObj.hasOwnProperty('errorMessage')){
              This.errorDialog(jsonObj,"NPS Application");
            }
            else{
              accessMatrixRef = jsonObj;
            }
          },
          error: function () {
            alert('Something went wrong. Please try after sometime');
          },    
      })
      return accessMatrixRef;
    }

    

    runCommand(){
      alert("test");
      
    }
}
