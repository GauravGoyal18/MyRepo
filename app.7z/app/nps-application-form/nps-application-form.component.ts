import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker/ngx-bootstrap-datepicker';
import { Router } from '../../../node_modules/@angular/router';
//import { NpsPersonalDetails } from './child-nps-classes/RegistrationForm';

import { NpsPersonalDetails } from '../nps-application-form/child-nps-classes/RegistrationForm';
import { NpsPersonalShareDataService } from '../nps-personal-shareddata.service';
import { BasepageComponent } from '../basepage/basepage.component';
import { FormBuilder,FormControl, FormGroup, Validators } from '../../../node_modules/@angular/forms';
import { forbiddenNameValidator } from './ui-validation/ui-validation.directive';
import { MatStepper } from '../../../node_modules/@angular/material';
/* import{NpsEntry} from './child-nps-classes/RegistrationForm'; */
declare var $; 
@Component({
  selector: 'app-nps-application-form',
  templateUrl: './nps-application-form.component.html',
  styleUrls: ['./nps-application-form.component.scss']
})
export class NpsApplicationFormComponent extends BasepageComponent{

  bsValue = new Date();
  public NpsPersonal = new  NpsPersonalDetails();
  maxDate: any;
  minDate: any;
  //maxDateDob=new Date().getFullYear()-18;
  //minDateDob=new Date().getFullYear()-61;

  

  entry: FormGroup;
  //myForm: any;
 
  constructor(private _formBuilder: FormBuilder,private router: Router,public  npsPrsnlShrDtSrvc : NpsPersonalShareDataService){
    super();
    this.minDate=new Date(new Date().getTime() - 65*365.25*24*60*60*1000);
    this.maxDate=new Date(new Date().getTime() - 18*365.25*24*60*60*1000); 
  }

  ngOnInit() {  
    
   
     this.entry = this._formBuilder.group({
      'mobile': new FormControl(this.NpsPersonal.mobile,[Validators.required,Validators.maxLength(10),forbiddenNameValidator("MOBILE_VALIDATION")]),
      'dob': new FormControl(this.NpsPersonal.dob,[Validators.required]), 


    },{ updateOn: 'blur' }); 
  }


  

  resetvalues(){
  this.NpsPersonal.mobile = '';
  this.NpsPersonal.dob=null;
  }




   basicPageSubmit(){
    {

      if(this.entry.status == 'VALID'){ 
        
        this.NpsPersonal.personApplicationFormDetailsPO.tabFilled = 'I';
        var PersonPoJson : NpsPersonalDetails;

        PersonPoJson= new NpsPersonalDetails();
            $.ajax({
              url: this.url_fetch_user,
              dataType: "json",
              contentType: "application/json",
              type: "POST",
              async: false,
              data : JSON.stringify(this.NpsPersonal),
              success: function (jsonObj) {
                $.extend(PersonPoJson,jsonObj);
              },
              error: function () {
                alert('Something went wrong. Please try after sometime');
              },    
          })
        
          this.npsPrsnlShrDtSrvc.setOption(PersonPoJson);
          
        this.router.navigate(['/nps-application-form/registration-form/'])}
     ;
     }
    
    
  
  } 
  
}

