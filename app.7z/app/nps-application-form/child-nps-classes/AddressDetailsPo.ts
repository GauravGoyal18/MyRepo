

export class PersonAddContactDetailsPO
{

constructor(){};
public addContId=null;
public proofOfAddress: string = '';
public  corresAddType:string='';
public  corresLandMark:string='';
public  corresRoad:string='';
public  corresFlat:string='';
public  corresArea:string='';
public  corresPremises:string='';
public corresState:string='';
public corresCity:string='';
public corresCountry:string='';
public corresPincode:Number;
public isPermSameAsCorress:string='No';
public proofOfCorresAddress:string='';
public permAddFlatName:string='';
public lastUpdatedDt:string='';
public  flagAddressDetails:string='';


}