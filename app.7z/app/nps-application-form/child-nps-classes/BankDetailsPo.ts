export class PersonBankDetailsPO 
{
constructor(){};
accType: string = '';
accNo: Number;
bankName: string = '';
firstName: string = '';
middleName: string = '';
lastName: string = '';
branchName: string = '';
bankAddress: string = '';
bankPincode: Number;
bankState: string = '';
bankCountry: string = '';
micr: Number;
ifsc: string = '';
lastUpdatedDate:Date;
//Relationship: string = '';
Date: string = '';
//nomineeFName: string = '';
//nomineeMName: string = '';
//nomineeLName: string = '';
flagBankDetails:string='';


}