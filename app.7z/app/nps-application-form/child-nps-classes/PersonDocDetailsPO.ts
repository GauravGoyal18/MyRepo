export class PersonDocDetailsPO
{
    constructor(){};
    public docId:string=null;
    public poiDropDown_poiNumber:String='';
    public poiNumber:String='';          
    public poiExpDate:String='';
    public lastUpdateDt:String='';
    public flagPersonDocDetails:string='';
    public documentName:String='';
    public docExpiryDate:Date;
} 