export class PersonDeclarationEmployeePO
{
    constructor(){};
    public declr_dob:Date;
    public declr_retirement:Date;
    public employeeCode:String='';
    public ChoNo:String='';
    public CboNo:String='';
    public Name:String='';
    public accountOffice:String='';
    public collectionCentre:String='';
    public membershipNumber:String='';

}