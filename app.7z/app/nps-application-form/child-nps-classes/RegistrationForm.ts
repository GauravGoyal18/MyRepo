
import { NomineeDetailsPO } from "./NomineeDetailsPO";
import { PersonAddContactDetailsPO } from "./AddressDetailsPo";
import { PersonBankDetailsPO } from "./BankDetailsPo";
import { PersonApplicationFormDetailsPO } from "./PersonApplicationFormDetailsPO";
import { PersonDocDetailsPO } from "./PersonDocDetailsPO";
import { PersonFATCADetailsPO } from "./PersonFATCADetailsPO";



export class NpsPersonalDetails
{

constructor(){};
public personId=null;
public salutation: string = '';
public fName: string = '';
public maidenName: string = '';
public fatherName:string = '';
public motherName:string = '';
public dob:Date;
public birthCity:string = '';
public birthCountry:string = '';
public gender:string = '';
public nationality:string = '';
public maritalStatus:string = '';
public spouseName:string = '';
public resStatus:string = '';
private _errorArray = new Set();
//public document:string='';
//public documentNumber:string='';
public officeTel:string = null;
public resTel:string = null;
public mobile:string='';
public emailId:string = null;
public uidAadhaar:string='';
public occupationDetails:string='';
public otheroccupation:string='';
public incomeRange:string='';
public eduQualifictn:string='';
public politicalRelantinshp:string='';
public flagPersonalDetails:string='';
public doj:Date;
public dor:Date;
public personAddContactDetailsPO  = [new PersonAddContactDetailsPO(), new PersonAddContactDetailsPO()];
public personBankDetailsPO=new PersonBankDetailsPO ();
public personApplicationFormDetailsPO=new PersonApplicationFormDetailsPO();
public personDocDetailsPO=new PersonDocDetailsPO();
//public personFATCADetailsPO = new PersonFATCADetailsPO();
public personFATCADetailsPO=[new PersonFATCADetailsPO(),new PersonFATCADetailsPO(),new PersonFATCADetailsPO()];
public nomineeDetailsPO=new NomineeDetailsPO();
public get errorArray() {
  return this._errorArray;
}
public set errorArray(value) {
  this._errorArray = value;
}


}