export class PersonApplicationFormDetailsPO 
{
    constructor(){};

    public npsAppNo=null;
    public  nafCorpUid:string=''; 
    public  pensionFundName:string=''; 
    public  investmentOption:string='';  
    public  autoChoiceLC:string='';
    public  flag1:string='';
    public  flag2:string='';
    public  flag3:string='';
    public  flag4:string='';
    public  status:string=''; 
    public tabFilled:string='';
    public flagPersonApplicationFormDetails:string='';
    
}