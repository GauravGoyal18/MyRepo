export class PersonFATCADetailsPO
{
    constructor(){};
    
    public fatcaDeclId=null;
    public sec1UsPerson:String='';            
    public c1TaxResidence:String='';
    public c1AddressLine1:String='';  
    public c1City:String='';
    public c1State:String='';
    public c1Zip:Number; 
    public c1TIN:Number;  
    public c1TinCountry:String='';  
    public c1Validity:String='';
    public flagFatcaDetails:string='';

}