

export class NomineeDetailsPO
{

constructor(){};

public nomineeId=null;
public nomFName : string = '';
public nomMName : string = '';
public nomLName : string ='';
public nomDob : Date;
public relationWNom:string='';
public guardFName : string = '';
public guardMName : string = '';
public guardLName : string ='';

}