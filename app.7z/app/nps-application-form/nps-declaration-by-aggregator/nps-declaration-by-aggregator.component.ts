import { Component, OnInit, Input } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatIconRegistry} from '@angular/material';
import { NpsRegistrationFormComponent } from '../nps-registration-form/nps-registration-form.component';
import { NpsPersonalDetails } from '../child-nps-classes/RegistrationForm';
import { NpsPersonalShareDataService } from '../../nps-personal-shareddata.service';

@Component({
  selector: 'app-nps-declaration-by-aggregator',
  templateUrl: './nps-declaration-by-aggregator.component.html',
  styleUrls: ['./nps-declaration-by-aggregator.component.scss']
})
export class NpsDeclarationByAggregatorComponent {
  
  fieldNamesMap = new Map();
  editFieldMap = new Map();
  sectionMap = new Map();
  dropDownMap : any;
  user: any;
  age:any;
  globalApplicationNumber: any;
  personAge:Date;
  today1=new Date();
  today2=new Date();
  maxRetireAge=new Date();
  diff:Number=18;

  @Input('NpsPersonal') NpsPersonal:NpsPersonalDetails;
  constructor(private _formBuilder: FormBuilder,private npsAppForm : NpsRegistrationFormComponent,public npsSharedDataSrvc : NpsPersonalShareDataService){ 

   
  }
  ageCal()
  {

    var timeDiff = Math.abs(Date.now() - this.NpsPersonal.dob.getTime());
    this.age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
    if(this.age>=18)
    {
     
      this.today2.setUTCFullYear(this.NpsPersonal.dob.getFullYear()+18,this.NpsPersonal.dob.getUTCMonth(),this.NpsPersonal.dob.getUTCDate()+1);
    
    }
    else{
      
    }
  }

  retirementCal()
  {

    var timeDiff = Math.abs(Date.now() - this.NpsPersonal.dob.getTime());
    this.age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
    if(this.age>=18)
    {
     
      this.maxRetireAge.setUTCFullYear(this.NpsPersonal.dob.getFullYear()+65,this.NpsPersonal.dob.getUTCMonth(),this.NpsPersonal.dob.getUTCDate()+1);
    
    }
    else{
      
    }
  }
  
  
 
  
  ngOnInit() {
    
    this.fieldNamesMap = this.npsAppForm.fieldNamesMap;
    this.sectionMap = this.npsAppForm.sectionMap;
    this.editFieldMap = this.npsAppForm.editFieldMap;
    this.dropDownMap = this.npsAppForm.dropDownMap;
    this.user = this.npsAppForm.user;
  
    
    this.NpsPersonal = this.npsSharedDataSrvc.getOption();
    this.globalApplicationNumber = this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo;
    
  }

}
