import { Component, OnInit, Input } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatIconRegistry} from '@angular/material';
import { NpsRegistrationFormComponent } from '../nps-registration-form/nps-registration-form.component';
import { NpsPersonalDetails } from '../child-nps-classes/RegistrationForm';
import { PersonApplicationFormDetailsPO } from '../child-nps-classes/PersonApplicationFormDetailsPO';
import { NpsPersonalShareDataService } from '../../nps-personal-shareddata.service';

@Component({
  selector: 'app-nps-option-details',
  templateUrl: './nps-option-details.component.html',
  styleUrls: ['./nps-option-details.component.scss']
})
export class NpsOptionDetailsComponent {
  fieldNamesMap = new Map();
  editFieldMap = new Map();
  sectionMap = new Map();
  dropDownMap : any;
  globalApplicationNumber: any;

  @Input() option: FormGroup;
  @Input('NpsPersonal') NpsPersonal:NpsPersonalDetails;
  
  constructor(private _formBuilder: FormBuilder,private npsAppForm : NpsRegistrationFormComponent,public npsSharedDataSrvc : NpsPersonalShareDataService){ 
    //super();
    
  }

  ngOnInit() {
    
    this.fieldNamesMap = this.npsAppForm.fieldNamesMap;
    this.sectionMap = this.npsAppForm.sectionMap;
    this.editFieldMap = this.npsAppForm.editFieldMap;
    this.dropDownMap = this.npsAppForm.dropDownMap;
    
    this.NpsPersonal = this.npsSharedDataSrvc.getOption();
    this.globalApplicationNumber = this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo;
    this.NpsPersonal.personApplicationFormDetailsPO.autoChoiceLC='LC 50';
    //this.option=this._formBuilder.group({autoChoiceLC:['LC50']
/*     this.NpsPersonal.personApplicationFormDetailsPO.autoChoiceLC='LC50' */
  /* }); */
  }

}
