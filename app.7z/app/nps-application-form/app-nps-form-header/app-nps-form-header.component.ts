import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nps-form-header',
  templateUrl: './app-nps-form-header.component.html',
  styleUrls: ['./app-nps-form-header.component.scss']
})
export class AppNpsFormHeaderComponent implements OnInit {

  constructor() { }
  title = 'icicipru';
  ngOnInit() {
  }

}