import { Component, OnInit, Input } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import {MatIconRegistry} from '@angular/material';
import { NpsRegistrationFormComponent } from '../nps-registration-form/nps-registration-form.component';
import { NpsPersonalDetails } from '../child-nps-classes/RegistrationForm';
import { PersonFATCADetailsPO } from '../child-nps-classes/PersonFATCADetailsPO';
import { NpsPersonalShareDataService } from '../../nps-personal-shareddata.service';
import { NULL_EXPR } from '../../../../node_modules/@angular/compiler/src/output/output_ast';
import { forbiddenNameValidator } from '../ui-validation/ui-validation.directive';

@Component({
  selector: 'app-nps-declaration-by-subscriber',
  templateUrl: './nps-declaration-by-subscriber.component.html',
  styleUrls: ['./nps-declaration-by-subscriber.component.scss']
})
export class NpsDeclarationBySubscriberComponent {
  //countries = [{key:"key1",value: this.NpsPersonal.personFATCADetailsPO}];

  counter = 0;
  temp=0;
  formArray = [];
  fieldNamesMap = new Map();
  editFieldMap = new Map();
  sectionMap = new Map();
  dropDownMap : any;
  firstform = true;
  secondForm = false;
  thirdForm = false;
  globalApplicationNumber: any;
  @Input() fatca: FormGroup;
  @Input('NpsPersonal') NpsPersonal:NpsPersonalDetails;

  constructor(private _formBuilder: FormBuilder,private npsAppForm : NpsRegistrationFormComponent,public npsSharedDataSrvc : NpsPersonalShareDataService){ 
    //super();
 
  }
  

  ngOnInit() {
        this.formArray.push(new PersonFATCADetailsPO());
    this.fieldNamesMap = this.npsAppForm.fieldNamesMap;
    this.sectionMap = this.npsAppForm.sectionMap;
    this.editFieldMap = this.npsAppForm.editFieldMap;
    this.dropDownMap = this.npsAppForm.dropDownMap;
    this.globalApplicationNumber = this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo;
    this.NpsPersonal = this.npsSharedDataSrvc.getOption();


    this.npsAppForm.fifthFormGroup.controls['c1TaxResidence_1'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1AddressLine1_1'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1City_1'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1State_1'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1Zip_1'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1Validity_1'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1TIN_1'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1TinCountry_1'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1TaxResidence_2'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1AddressLine1_2'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1City_2'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1State_2'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1Zip_2'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1Validity_2'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1TIN_2'].disable();
    this.npsAppForm.fifthFormGroup.controls['c1TinCountry_2'].disable();
   





  }

   isUSPerson(flag){
    this.NpsPersonal.personFATCADetailsPO[0].sec1UsPerson= flag;
  } 
   deleteCountry()
  {
    while(true)
    {
    if(this.counter>2)
    {
      while(this.counter!=this.temp)
      {
      this.counter=this.counter-1;
      }
    }
    else
    {
     if(this.counter<=2 && this.counter>0)
    {
      if(this.counter == 1){
        this.secondForm = false;
       this.NpsPersonal.personFATCADetailsPO[1]=new PersonFATCADetailsPO();
        this.npsAppForm.fifthFormGroup.controls['c1TaxResidence_1'].disable();
        this.npsAppForm.fifthFormGroup.controls['c1AddressLine1_1'].disable();
        this.npsAppForm.fifthFormGroup.controls['c1City_1'].disable();
        this.npsAppForm.fifthFormGroup.controls['c1State_1'].disable();
        this.npsAppForm.fifthFormGroup.controls['c1Zip_1'].disable();
        this.npsAppForm.fifthFormGroup.controls['c1Validity_1'].disable();
        this.npsAppForm.fifthFormGroup.controls['c1TIN_1'].disable();
        this.npsAppForm.fifthFormGroup.controls['c1TinCountry_1'].disable();
       /*  this.npsAppForm.fifthFormGroup.controls['c1TaxResidence_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1AddressLine1_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1City_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1State_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1Zip_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1Validity_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1TIN_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1TinCountry_1'].setErrors(null);
 */
 
        this.counter = this.counter -1;
        break;
        
      }
      if(this.counter == 2){
        this.thirdForm = false;
       this.NpsPersonal.personFATCADetailsPO[2]=new PersonFATCADetailsPO();
       this.npsAppForm.fifthFormGroup.controls['c1TaxResidence_2'].disable();
       this.npsAppForm.fifthFormGroup.controls['c1AddressLine1_2'].disable();
       this.npsAppForm.fifthFormGroup.controls['c1City_2'].disable();
       this.npsAppForm.fifthFormGroup.controls['c1State_2'].disable();
       this.npsAppForm.fifthFormGroup.controls['c1Zip_2'].disable();
       this.npsAppForm.fifthFormGroup.controls['c1Validity_2'].disable();
       this.npsAppForm.fifthFormGroup.controls['c1TIN_2'].disable();
       this.npsAppForm.fifthFormGroup.controls['c1TinCountry_2'].disable();
     /*   this.npsAppForm.fifthFormGroup.controls['c1TaxResidence_2'].setErrors(null);
       this.npsAppForm.fifthFormGroup.controls['c1AddressLine1_2'].setErrors(null);
       this.npsAppForm.fifthFormGroup.controls['c1City_2'].setErrors(null);
       this.npsAppForm.fifthFormGroup.controls['c1State_2'].setErrors(null);
       this.npsAppForm.fifthFormGroup.controls['c1Zip_2'].setErrors(null);
       this.npsAppForm.fifthFormGroup.controls['c1Validity_2'].setErrors(null);
       this.npsAppForm.fifthFormGroup.controls['c1TIN_2'].setErrors(null);
       this.npsAppForm.fifthFormGroup.controls['c1TinCountry_2'].setErrors(null); */

        this.counter = this.counter -1;
        break;
       
      }
     }
     else{
      alert("Cannot delete more countries");
      break;
     }
    }
     
  }
} 
 
  addInputCountry() {
    
 
    this.counter = this.counter +1;
    if(this.counter<=2){
    
      if(this.counter == 1){
        this.secondForm = true;
        this.npsAppForm.fifthFormGroup.controls['c1TaxResidence_1'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1AddressLine1_1'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1City_1'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1State_1'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1Zip_1'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1Validity_1'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1TIN_1'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1TinCountry_1'].enable();
/*         this.npsAppForm.fifthFormGroup.controls['c1TaxResidence_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1AddressLine1_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1City_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1State_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1Zip_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1Validity_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1TIN_1'].setErrors(null);
        this.npsAppForm.fifthFormGroup.controls['c1TinCountry_1'].setErrors(null);
 */
        this.temp=this.counter;
       
      }
      if(this.counter == 2){
        this.thirdForm = true;
        this.npsAppForm.fifthFormGroup.controls['c1TaxResidence_2'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1AddressLine1_2'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1City_2'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1State_2'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1Zip_2'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1Validity_2'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1TIN_2'].enable();
        this.npsAppForm.fifthFormGroup.controls['c1TinCountry_2'].enable();
       

        this.temp=this.counter;

      }

   }
   else{
    alert("can not add more countries");
   
   }

  }
}
