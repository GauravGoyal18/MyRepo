import { Component, OnInit, Input } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatIconRegistry} from '@angular/material';

import { NpsPersonalDetails } from '../child-nps-classes/RegistrationForm';

import { NpsRegistrationFormComponent } from '../nps-registration-form/nps-registration-form.component';
import { PersonBankDetailsPO } from '../child-nps-classes/BankDetailsPo';
import { NomineeDetailsPO } from '../child-nps-classes/NomineeDetailsPO';
import { NpsPersonalShareDataService } from '../../nps-personal-shareddata.service';
import { forbiddenNameValidator } from '../ui-validation/ui-validation.directive';

@Component({
  selector: 'app-nps-other-and-bank-details',
  templateUrl: './nps-other-and-bank-details.component.html',
  styleUrls: ['./nps-other-and-bank-details.component.scss']
})
export class NpsOtherAndBankDetailsComponent {
  age:Number;
  fieldNamesMap = new Map();
  editFieldMap = new Map();
  sectionMap = new Map();
  dropDownMap : any;
  first = true;
  showotheroccupation: boolean = false;
  globalApplicationNumber: any;
  @Input() bank: FormGroup;
  @Input('NpsPersonal') NpsPersonal:NpsPersonalDetails;
  public NpsBankDetails=new PersonBankDetailsPO ();
  public NpsNomineeDetails=new NomineeDetailsPO();
  constructor(private _formBuilder: FormBuilder,private npsAppForm : NpsRegistrationFormComponent,public npsSharedDataSrvc : NpsPersonalShareDataService){ 
    //this.NpsBankDetails=new BankDetailsVo();
    
  }
  today1=new Date();
  ngOnInit() {
    this.fieldNamesMap = this.npsAppForm.fieldNamesMap;
    this.sectionMap = this.npsAppForm.sectionMap;
    this.editFieldMap = this.npsAppForm.editFieldMap;
    this.dropDownMap = this.npsAppForm.dropDownMap;

    this.NpsPersonal = this.npsSharedDataSrvc.getOption();

    this.NpsPersonal.nomineeDetailsPO.nomDob = new Date(this.NpsPersonal.nomineeDetailsPO.nomDob); // date conversion for date picker
    this.globalApplicationNumber = this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo;
  }
  calAge(){
    var timeDiff = Math.abs(Date.now() -  this.NpsPersonal.nomineeDetailsPO.nomDob.getTime());
    this.age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
    //console.log(this.age);
    if(this.age>18)
    {
      this.first=false;
      this.npsAppForm.thirdFormGroup.controls['guardFName'].disable();
      this.npsAppForm.thirdFormGroup.controls['guardMName'].disable();
      this.npsAppForm.thirdFormGroup.controls['guardLName'].disable();

    }
    else{
      this.first=true; 
      this.npsAppForm.thirdFormGroup.controls['guardFName'].enable();
      this.npsAppForm.thirdFormGroup.controls['guardMName'].enable();
      this.npsAppForm.thirdFormGroup.controls['guardLName'].enable();
    }

      }
     

OtherDocumentShowHide(){
  if(this.npsAppForm.thirdFormGroup.controls.occupationDetails.value == 'Private Sector'){
    this.npsAppForm.thirdFormGroup.controls['otheroccupation'].setErrors(null);
    this.showotheroccupation=false;
    
  }
  if(this.npsAppForm.thirdFormGroup.controls.occupationDetails.value == 'Public Sector'){
    this.npsAppForm.thirdFormGroup.controls['otheroccupation'].setErrors(null);
    this.showotheroccupation=false;
  }
  if(this.npsAppForm.thirdFormGroup.controls.occupationDetails.value == 'Government Sector'){
    this.npsAppForm.thirdFormGroup.controls['otheroccupation'].setErrors(null);
    this.showotheroccupation=false;
  }

  if(this.npsAppForm.thirdFormGroup.controls.occupationDetails.value == 'Professional'){
    this.npsAppForm.thirdFormGroup.controls['otheroccupation'].setErrors(null);
    this.showotheroccupation=false;
    
  }
  if(this.npsAppForm.thirdFormGroup.controls.occupationDetails.value == 'Self Employed'){
    this.npsAppForm.thirdFormGroup.controls['otheroccupation'].setErrors(null);
    this.showotheroccupation=false;
  }
  if(this.npsAppForm.thirdFormGroup.controls.occupationDetails.value == 'Homemaker'){
    this.npsAppForm.thirdFormGroup.controls['otheroccupation'].setErrors(null);
    this.showotheroccupation=false;
  }

  if(this.npsAppForm.thirdFormGroup.controls.occupationDetails.value == 'Student'){
    this.npsAppForm.thirdFormGroup.controls['otheroccupation'].setErrors(null);
    this.showotheroccupation=false;
    
  }
  if(this.npsAppForm.thirdFormGroup.controls.occupationDetails.value == 'Others(Please Specify)'){
    this.npsAppForm.thirdFormGroup.controls['otheroccupation'].setValidators([Validators.required,forbiddenNameValidator("NAME_VALIDATION")]);
    this.showotheroccupation=true;
  }
  


}


}
