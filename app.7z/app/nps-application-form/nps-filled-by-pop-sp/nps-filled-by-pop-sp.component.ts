import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatIconRegistry} from '@angular/material';
import { NpsRegistrationFormComponent } from '../nps-registration-form/nps-registration-form.component';

@Component({
  selector: 'app-nps-filled-by-pop-sp',
  templateUrl: './nps-filled-by-pop-sp.component.html',
  styleUrls: ['./nps-filled-by-pop-sp.component.scss']
})
export class NpsFilledByPopSPComponent {
  
  fieldNamesMap = new Map();
  editFieldMap = new Map();
  sectionMap = new Map();
  dropDownMap : any;

  constructor(private _formBuilder: FormBuilder,private npsAppForm : NpsRegistrationFormComponent){ 
    //super();
  }

  ngOnInit() {
    
    this.fieldNamesMap = this.npsAppForm.fieldNamesMap;
    this.sectionMap = this.npsAppForm.sectionMap;
    this.editFieldMap = this.npsAppForm.editFieldMap;
    this.dropDownMap = this.npsAppForm.dropDownMap;
    
  }

}
