import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatIconRegistry} from '@angular/material';

@Component({
  selector: 'app-nps-save-and-review',
  templateUrl: './nps-save-and-review.component.html',
  styleUrls: ['./nps-save-and-review.component.scss']
})
export class NpsSaveAndReviewComponent {
  
  constructor(private _formBuilder: FormBuilder){ 
    //super();
  }

  ngOnInit() {
    
  }

}
