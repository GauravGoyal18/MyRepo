import { Component, OnInit, Input } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatIconRegistry} from '@angular/material';
import { NpsRegistrationFormComponent } from '../nps-registration-form/nps-registration-form.component';

import { PersonAddContactDetailsPO } from '../child-nps-classes/AddressDetailsPo';
import { NpsPersonalDetails } from '../child-nps-classes/RegistrationForm';
import { NpsPersonalShareDataService } from '../../nps-personal-shareddata.service';

@Component({
  selector: 'app-nps-proof-of-address',
  templateUrl: './nps-proof-of-address.component.html',
  styleUrls: ['./nps-proof-of-address.component.scss']
})
export class NpsProofOfAddressComponent {
  
  fieldNamesMap = new Map();
  editFieldMap = new Map();
  sectionMap = new Map();
  dropDownMap : any;
  globalApplicationNumber: any;
  @Input() address: FormGroup;

  @Input('NpsPersonal') NpsPersonal:NpsPersonalDetails;
  public NpsProofOfAddress =new PersonAddContactDetailsPO();


  constructor(private _formBuilder: FormBuilder,private npsAppForm : NpsRegistrationFormComponent,public npsSharedDataSrvc : NpsPersonalShareDataService){
    
   // this.NpsProofOfAddress=new PersonAddContactDetailsVO();
    //this.NpsPersonal.prefix="";
  }
 
  ngOnInit() {
    this.fieldNamesMap = this.npsAppForm.fieldNamesMap;
    this.sectionMap = this.npsAppForm.sectionMap;
    this.editFieldMap = this.npsAppForm.editFieldMap;
    this.dropDownMap = this.npsAppForm.dropDownMap;

    this.NpsPersonal = this.npsSharedDataSrvc.getOption();
    this.globalApplicationNumber = this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo;
  }
  hh1(){
   console.log(this.NpsPersonal);
      }

   copyOnChange()
   {
    if((<HTMLInputElement>document.getElementById("sameAddress")).checked)
    {
    this.NpsPersonal.personAddContactDetailsPO[1].proofOfAddress=this.NpsPersonal.personAddContactDetailsPO[0].proofOfAddress;
    this.NpsPersonal.personAddContactDetailsPO[1].corresAddType=this.NpsPersonal.personAddContactDetailsPO[0].corresAddType;
    this.NpsPersonal.personAddContactDetailsPO[1].corresFlat=this.NpsPersonal.personAddContactDetailsPO[0].corresFlat;
    this.NpsPersonal.personAddContactDetailsPO[1].corresLandMark=this.NpsPersonal.personAddContactDetailsPO[0].corresLandMark;
    this.NpsPersonal.personAddContactDetailsPO[1].corresPremises=this.NpsPersonal.personAddContactDetailsPO[0].corresPremises;
    this.NpsPersonal.personAddContactDetailsPO[1].corresRoad=this.NpsPersonal.personAddContactDetailsPO[0].corresRoad;
    this.NpsPersonal.personAddContactDetailsPO[1].corresArea=this.NpsPersonal.personAddContactDetailsPO[0].corresArea;
    this.NpsPersonal.personAddContactDetailsPO[1].corresCity=this.NpsPersonal.personAddContactDetailsPO[0].corresCity;
    this.NpsPersonal.personAddContactDetailsPO[1].corresPincode=this.NpsPersonal.personAddContactDetailsPO[0].corresPincode;
    this.NpsPersonal.personAddContactDetailsPO[1].corresState=this.NpsPersonal.personAddContactDetailsPO[0].corresState;
    this.NpsPersonal.personAddContactDetailsPO[1].corresCountry=this.NpsPersonal.personAddContactDetailsPO[0].corresCountry;
 

   }    
  }
      
  copyAddress(){
    if((<HTMLInputElement>document.getElementById("sameAddress")).checked){
      this.NpsPersonal.personAddContactDetailsPO[0].isPermSameAsCorress = 'Yes';
      this.NpsPersonal.personAddContactDetailsPO[1].isPermSameAsCorress = 'Yes';
      this.NpsPersonal.personAddContactDetailsPO[1].proofOfAddress=this.NpsPersonal.personAddContactDetailsPO[0].proofOfAddress;
      this.NpsPersonal.personAddContactDetailsPO[1].corresAddType=this.NpsPersonal.personAddContactDetailsPO[0].corresAddType;
      this.NpsPersonal.personAddContactDetailsPO[1].corresFlat=this.NpsPersonal.personAddContactDetailsPO[0].corresFlat;
      this.NpsPersonal.personAddContactDetailsPO[1].corresLandMark=this.NpsPersonal.personAddContactDetailsPO[0].corresLandMark;
      this.NpsPersonal.personAddContactDetailsPO[1].corresPremises=this.NpsPersonal.personAddContactDetailsPO[0].corresPremises;
      this.NpsPersonal.personAddContactDetailsPO[1].corresRoad=this.NpsPersonal.personAddContactDetailsPO[0].corresRoad;
      this.NpsPersonal.personAddContactDetailsPO[1].corresArea=this.NpsPersonal.personAddContactDetailsPO[0].corresArea;
      this.NpsPersonal.personAddContactDetailsPO[1].corresCity=this.NpsPersonal.personAddContactDetailsPO[0].corresCity;
      this.NpsPersonal.personAddContactDetailsPO[1].corresPincode=this.NpsPersonal.personAddContactDetailsPO[0].corresPincode;
      this.NpsPersonal.personAddContactDetailsPO[1].corresState=this.NpsPersonal.personAddContactDetailsPO[0].corresState;
      this.NpsPersonal.personAddContactDetailsPO[1].corresCountry=this.NpsPersonal.personAddContactDetailsPO[0].corresCountry;
      //this.npsAppForm.secondFormGroup.disable();
      this.npsAppForm.secondFormGroup.controls['proofOfAddressPerm'].disable();
      this.npsAppForm.secondFormGroup.controls['permAddType'].disable();
      this.npsAppForm.secondFormGroup.controls['permFlat'].disable();
      this.npsAppForm.secondFormGroup.controls['permLandMark'].disable();
      this.npsAppForm.secondFormGroup.controls['permPermises'].disable();
      this.npsAppForm.secondFormGroup.controls['permRoad'].disable();
      this.npsAppForm.secondFormGroup.controls['permArea'].disable();
      this.npsAppForm.secondFormGroup.controls['permCity'].disable();
      this.npsAppForm.secondFormGroup.controls['permPincode'].disable();
      this.npsAppForm.secondFormGroup.controls['permState'].disable();
      this.npsAppForm.secondFormGroup.controls['permCountry'].disable();
     
    }
     
    else{
      this.NpsPersonal.personAddContactDetailsPO[0].isPermSameAsCorress = 'No';
      this.NpsPersonal.personAddContactDetailsPO[1].isPermSameAsCorress = 'No';
      this.NpsPersonal.personAddContactDetailsPO[1].proofOfAddress=null;
      this.NpsPersonal.personAddContactDetailsPO[1].corresAddType=null;
      this.NpsPersonal.personAddContactDetailsPO[1].corresFlat=null;
      this.NpsPersonal.personAddContactDetailsPO[1].corresLandMark=null;
      this.NpsPersonal.personAddContactDetailsPO[1].corresPremises=null;
      this.NpsPersonal.personAddContactDetailsPO[1].corresRoad=null;
      this.NpsPersonal.personAddContactDetailsPO[1].corresArea=null;
      this.NpsPersonal.personAddContactDetailsPO[1].corresCity=null;
      this.NpsPersonal.personAddContactDetailsPO[1].corresPincode=null;
      this.NpsPersonal.personAddContactDetailsPO[1].corresState=null;
      this.NpsPersonal.personAddContactDetailsPO[1].corresCountry=null;

      this.npsAppForm.secondFormGroup.controls['proofOfAddressPerm'].enable();
      this.npsAppForm.secondFormGroup.controls['permAddType'].enable();
      this.npsAppForm.secondFormGroup.controls['permFlat'].enable();
      this.npsAppForm.secondFormGroup.controls['permLandMark'].enable();
      this.npsAppForm.secondFormGroup.controls['permPermises'].enable();
      this.npsAppForm.secondFormGroup.controls['permRoad'].enable();
      this.npsAppForm.secondFormGroup.controls['permArea'].enable();
      this.npsAppForm.secondFormGroup.controls['permCity'].enable();
      this.npsAppForm.secondFormGroup.controls['permPincode'].enable();
      this.npsAppForm.secondFormGroup.controls['permState'].enable();
      this.npsAppForm.secondFormGroup.controls['permCountry'].enable();
     
    }
 
   

    
  }
    

}
