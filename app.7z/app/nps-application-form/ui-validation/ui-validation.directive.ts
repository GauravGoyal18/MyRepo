import { Directive,Input, ElementRef } from '@angular/core';
import { Validator, AbstractControl, NG_VALIDATORS,ValidatorFn } from '@angular/forms';
import {regexConstant} from '../regex-constants/regex-constants'
import { NpsPersonalDetails } from '../child-nps-classes/RegistrationForm';



/* @Directive({
    selector: '[appForbiddenText]',
  providers: [{provide: NG_VALIDATORS, useExisting: UiValidationDirective, multi: true}],
})



export class UiValidationDirective implements Validator {
  public NpsPersonal=new NpsPersonalDetails();
  constructor(private elementRef: ElementRef){ 
    this.NpsPersonal;
   // this.NpsPersonal.prefix="";
  }

  @Input('appForbiddenText') forbiddenText: string;
  

validate(control: AbstractControl): {[key: string]: any} | null {
 // console.log(this.forbiddenText + this.elementRef.nativeElement.name + " " + );

    if(control.value!=""){
    var isValid=forbiddenNameValidator(regexConstant[this.forbiddenText])(control);

    if(isValid){
      this.NpsPersonal.errorArray.delete(this.elementRef.nativeElement.name);
      return control;
    }else{
      if(this.elementRef.nativeElement.required){
        
        this.NpsPersonal.errorArray.add(this.elementRef.nativeElement.name);
      }
      return {'forbiddenText': {value: control.value}};

    }
  
    }else{
      if(this.elementRef.nativeElement.required){
        
        this.NpsPersonal.errorArray.add(this.elementRef.nativeElement.name);
      }
    return control;
    }
}


} */

export function forbiddenNameValidator(nameRe: string): ValidatorFn {
  
  return (control: AbstractControl): {[key: string]: any} | any => {
    if(control.value != null){
      if(control.value!="" || control.value === undefined ){
        const forbidden = regexConstant[nameRe].test(control.value);
        return forbidden ? "" :{'forbiddenName': {value: control.value}} ;
        }
    }
    
  };
  
}