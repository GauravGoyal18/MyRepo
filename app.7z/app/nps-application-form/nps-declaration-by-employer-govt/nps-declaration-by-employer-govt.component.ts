import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatIconRegistry} from '@angular/material';
import { NpsRegistrationFormComponent } from '../nps-registration-form/nps-registration-form.component';
import { NpsPersonalShareDataService } from '../../nps-personal-shareddata.service';

@Component({
  selector: 'app-nps-declaration-by-employer-govt',
  templateUrl: './nps-declaration-by-employer-govt.component.html',
  styleUrls: ['./nps-declaration-by-employer-govt.component.scss']
})
export class NpsDeclarationByEmployerGovtComponent {
  
  fieldNamesMap = new Map();
  editFieldMap = new Map();
  sectionMap = new Map();
  dropDownMap : any;

  constructor(private _formBuilder: FormBuilder,private npsAppForm : NpsRegistrationFormComponent ,public npsSharedDataSrvc : NpsPersonalShareDataService){ 
    //super();
  }

  ngOnInit() {
            
    this.fieldNamesMap = this.npsAppForm.fieldNamesMap;
    this.sectionMap = this.npsAppForm.sectionMap;
    this.editFieldMap = this.npsAppForm.editFieldMap;
    this.dropDownMap = this.npsAppForm.dropDownMap;

    //this.NpsPersonal = this.npsSharedDataSrvc.getOption();
  }

}
