import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nps-form-footer',
  templateUrl: './app-nps-form-footer.component.html',
  styleUrls: ['./app-nps-form-footer.component.scss']
})
export class AppNpsFormFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}