import { Component, OnInit, Input } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatIconRegistry} from '@angular/material';
import { NpsPersonalDetails } from '../child-nps-classes/RegistrationForm';



import { NpsRegistrationFormComponent } from '../nps-registration-form/nps-registration-form.component';
import { forbiddenNameValidator } from '../ui-validation/ui-validation.directive';
import { NpsPersonalShareDataService } from '../../nps-personal-shareddata.service';

@Component({
  selector: 'app-nps-personal-details',
  templateUrl: './nps-personal-details.component.html',
  styleUrls: ['./nps-personal-details.component.scss']
})
export class NpsPersonalDetailsComponent {
  fieldNamesMap = new Map();
  editFieldMap = new Map();
  sectionMap = new Map();
  dropDownMap : any;
  @Input() personal: FormGroup;
  @Input('NpsPersonal') public NpsPersonal:NpsPersonalDetails;
  maxDate: any;
  minDate: any;
  minDatePOIdoc : Date;
  startDate: any;
  mandatoryfieldsMap: Map<any, any>;
  today: Date;
  min : Date;
  
  //public NpsProofOfAddress =new  PersonAddContactDetailsVO();
  //public NpsBankDetails =new BankDetailsVo(); 
  
  maxDateDob=new Date().getFullYear()-18;
  minDateDob=new Date().getFullYear()-61;
  
  showspousefield:boolean=false;
  showExpiryDate: boolean = false;
  showDocName: boolean = false;
  docMaxLength: Number;
  globalApplicationNumber: any;
  constructor(private _formBuilder: FormBuilder,private npsAppForm : NpsRegistrationFormComponent,public npsSharedDataSrvc : NpsPersonalShareDataService){ 
    this.minDatePOIdoc = new Date();
    this.minDatePOIdoc.setDate(this.minDatePOIdoc.getDate());
    this.minDate = new Date(this.minDateDob, 0, 1);
   
   this.maxDate = new Date(this.maxDateDob, 11, 31);
    
  }
  //today=new Date();

  ngOnInit() {
  
    this.fieldNamesMap = this.npsAppForm.fieldNamesMap;
    this.sectionMap = this.npsAppForm.sectionMap;
    this.editFieldMap = this.npsAppForm.editFieldMap;
    this.dropDownMap = this.npsAppForm.dropDownMap;
    this.mandatoryfieldsMap = this.npsAppForm.mandatoryfieldsMap;
    
    this.NpsPersonal = this.npsSharedDataSrvc.getOption();

    this.NpsPersonal.dob = new Date(this.NpsPersonal.dob); // date conversion for date picker
    this.globalApplicationNumber = this.NpsPersonal.personApplicationFormDetailsPO.npsAppNo;
    this.npsAppForm.firstFormGroup.controls['dob'].disable();

  }


SpouseNameShowHide(){
  if(this.npsAppForm.firstFormGroup.controls.maritalStatus.value == 'Married'){
    this.npsAppForm.firstFormGroup.controls['spouseName'].setValidators([Validators.required,forbiddenNameValidator("NAME_VALIDATION")]);
    this.showspousefield=true;
    
  }
  if(this.npsAppForm.firstFormGroup.controls.maritalStatus.value == 'Unmarried'){
    this.npsAppForm.firstFormGroup.controls['spouseName'].setErrors(null);
    this.showspousefield=false;
  }
  if(this.npsAppForm.firstFormGroup.controls.maritalStatus.value == 'Others'){
    this.npsAppForm.firstFormGroup.controls['spouseName'].setErrors(null);
    this.showspousefield=false;
  }


}



  DocumentVerification(){

    if(this.npsAppForm.firstFormGroup.controls.document.value == 'Passport'){
      this.npsAppForm.firstFormGroup.controls['documentNumber'].setValidators([Validators.required,forbiddenNameValidator("PASSPORT_VALIDATION")]);
      this.npsAppForm.firstFormGroup.controls['documentName'].setErrors(null);
      this.showExpiryDate = true;
      this.showDocName = false;
      this.NpsPersonal.personDocDetailsPO.poiNumber = "";
      this.docMaxLength = 8;
      
    }
    if(this.npsAppForm.firstFormGroup.controls.document.value == 'Vote ID Card'){
      this.npsAppForm.firstFormGroup.controls['documentNumber'].setValidators([Validators.required,forbiddenNameValidator("VOTERID_VALIDATION")]);
      this.npsAppForm.firstFormGroup.controls['documentName'].setErrors(null);
      this.npsAppForm.firstFormGroup.controls['docExpiryDate'].setErrors(null);
      this.showExpiryDate = false;
      this.showDocName = false;
      this.NpsPersonal.personDocDetailsPO.poiNumber = "";
      this.docMaxLength = 10;
    }
    if(this.npsAppForm.firstFormGroup.controls.document.value == 'PAN Card'){
      this.npsAppForm.firstFormGroup.controls['documentNumber'].setValidators([Validators.required,forbiddenNameValidator("PANDISC_VALIDATION")]);
      this.npsAppForm.firstFormGroup.controls['documentName'].setErrors(null);
      this.npsAppForm.firstFormGroup.controls['docExpiryDate'].setErrors(null);
      this.showExpiryDate = false;
      this.showDocName = false;
      this.NpsPersonal.personDocDetailsPO.poiNumber = "";
      this.docMaxLength = 10;
    }
    if(this.npsAppForm.firstFormGroup.controls.document.value == 'Driving License'){
      this.npsAppForm.firstFormGroup.controls['documentNumber'].setValidators([Validators.required,forbiddenNameValidator("DL_VALIDATION")]);
      this.npsAppForm.firstFormGroup.controls['documentName'].setErrors(null);
      this.showExpiryDate = true;
      this.showDocName = false;
      this.NpsPersonal.personDocDetailsPO.poiNumber = "";
      this.docMaxLength = 15;
    }
    if(this.npsAppForm.firstFormGroup.controls.document.value == 'NREGA Job Card'){
      this.npsAppForm.firstFormGroup.controls['documentNumber'].setValidators([Validators.required,forbiddenNameValidator("NREGACARD_VALIDATION")]);
      this.npsAppForm.firstFormGroup.controls['documentName'].setErrors(null);
      this.npsAppForm.firstFormGroup.controls['docExpiryDate'].setErrors(null);
      this.showExpiryDate = false;
      this.showDocName = false;
      this.NpsPersonal.personDocDetailsPO.poiNumber = "";
      this.docMaxLength = 17;
      
    }

    if(this.npsAppForm.firstFormGroup.controls.document.value == 'Others'){
      this.npsAppForm.firstFormGroup.controls['documentNumber'].setValidators([Validators.required,forbiddenNameValidator("ALPHANUMARIC_VALIDATION")]);
      this.npsAppForm.firstFormGroup.controls['documentName'].setValidators([Validators.required,forbiddenNameValidator("NAME_VALIDATION")]);
      this.npsAppForm.firstFormGroup.controls['docExpiryDate'].setErrors(null);
      this.showDocName = true;
      this.showExpiryDate = false;
      this.NpsPersonal.personDocDetailsPO.poiNumber = "";
      this.docMaxLength = 15;
    }
    if(this.npsAppForm.firstFormGroup.controls.document.value == 'UID (Aadhar)'){
      this.npsAppForm.firstFormGroup.controls['documentNumber'].setValidators([Validators.required,forbiddenNameValidator("AADHAR_VALIDATION")]);
      this.npsAppForm.firstFormGroup.controls['documentName'].setErrors(null);
      this.npsAppForm.firstFormGroup.controls['docExpiryDate'].setErrors(null);
      this.showExpiryDate = false;
      this.showDocName = false;
      this.NpsPersonal.personDocDetailsPO.poiNumber = "";
      this.docMaxLength = 12;
    }
    { updateOn: 'blur' }
  }

  

}

