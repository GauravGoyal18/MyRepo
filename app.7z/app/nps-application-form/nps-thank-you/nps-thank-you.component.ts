import { Component, OnInit, Input } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { faCheck, faDownload } from '@fortawesome/free-solid-svg-icons';
import { BasepageComponent } from '../../basepage/basepage.component';
import { NpsPersonalShareDataService } from '../../nps-personal-shareddata.service';
import { NpsPersonalDetails } from '../child-nps-classes/RegistrationForm';
//import { NpsApplicationFormComponent } from '../nps-application-form.component';


declare var $; 
@Component({
  selector: 'app-nps-thank-you',
  templateUrl: './nps-thank-you.component.html',
  styleUrls: ['./nps-thank-you.component.scss']
})
export class NpsThankYouComponent extends BasepageComponent /* extends NpsApplicationFormComponent implements OnInit */{
  
  checkCircle = faCheck; 
  download = faDownload;
  
  
  @Input('NpsPersonal') NpsPersonal:NpsPersonalDetails;

  constructor(private _formBuilder: FormBuilder,public npsPrsnlShrDtSrvc : NpsPersonalShareDataService){ 
    super();
  }

  ngOnInit() {
    this.NpsPersonal = this.npsPrsnlShrDtSrvc.getOption();
 
  }

  downloadUrl()
  {
    //var npsappNo =this.NpsPersonal.personId;
    var url = 'http://localhost:8080/IPruPensionWEB/iprupnsnfunds/corpNpdPdf/'+1104;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.responseType = 'arraybuffer';
    xhr.onload = function(e) {
       if (this.status == 200) {
          var blob=new Blob([this.response], {type:"application/pdf"});
          var link=document.createElement('a');
          link.href=window.URL.createObjectURL(blob);
          link.download="Report.pdf";
          link.click();
       }
       else
       {
        alert('Something went wrong. Please try after sometime');
       }
    };
    xhr.send();
  }
}
