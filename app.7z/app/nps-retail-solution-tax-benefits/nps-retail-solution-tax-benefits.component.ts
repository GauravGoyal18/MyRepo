import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $: Function;

@Component({
  selector: 'app-nps-retail-solution-tax-benefits',
  templateUrl: './nps-retail-solution-tax-benefits.component.html',
  styleUrls: ['./nps-retail-solution-tax-benefits.component.scss']
})
export class NpsRetailSolutionTaxBenefitsComponent extends BasepageComponent implements OnInit {

  constructor() {
    super();
  }

  ngOnInit() {
    $('#taxBenefits').slick({
      autoplay: false,
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: true,
      arrows: true,
    });
  }

}
