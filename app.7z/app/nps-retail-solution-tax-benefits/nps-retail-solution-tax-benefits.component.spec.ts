import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NpsRetailSolutionTaxBenefitsComponent } from './nps-retail-solution-tax-benefits.component';

describe('NpsRetailSolutionTaxBenefitsComponent', () => {
  let component: NpsRetailSolutionTaxBenefitsComponent;
  let fixture: ComponentFixture<NpsRetailSolutionTaxBenefitsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NpsRetailSolutionTaxBenefitsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NpsRetailSolutionTaxBenefitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
