import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutNpsBenefitsComponent } from './about-nps-benefits.component';

describe('AboutNpsBenefitsComponent', () => {
  let component: AboutNpsBenefitsComponent;
  let fixture: ComponentFixture<AboutNpsBenefitsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutNpsBenefitsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsBenefitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
