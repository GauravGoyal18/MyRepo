import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-about-nps-benefits',
  templateUrl: './about-nps-benefits.component.html',
  styleUrls: ['./about-nps-benefits.component.scss']
})
export class AboutNpsBenefitsComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
