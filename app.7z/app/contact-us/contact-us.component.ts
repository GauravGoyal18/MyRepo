import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $;

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss']
})
export class ContactUsComponent extends BasepageComponent implements OnInit {

  constructor() {
    super();
  }

  ngOnInit() {
    var NameArr;
    var This = this;

    function specificsonly(ob) {
      var invalidChars = /([^a-z 0-9,!.])/gi
      if (invalidChars.test(ob.value)) {
        ob.value = ob.value.replace(invalidChars, "");
      }
    }
  
      $('#firstname').keydown(function(e) {
        if ( e.ctrlKey || e.altKey) {
          e.preventDefault();
        } else {
          var key = e.keyCode;
          if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
            e.preventDefault();
          }
          else
          {
            $(".error-msg").css('display','none');
          }
        }
      });
      

      $('#lastname').keydown(function(e) {
        if ( e.ctrlKey || e.altKey) {
          e.preventDefault();
        } else {
          var key = e.keyCode;
          if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
            e.preventDefault();
          }
          else
          {
            $(".error-msg").css('display','none');
          }
        }
      });

      $('#mobile').keypress(function(e) {
        var unicode = e.charCode ? e.charCode : e.keyCode; 
        if ((unicode == 8) || (unicode == 9) || (unicode > 47 && unicode < 58)){
          return true;
        }else{
          return false;
        }
      });

      $('#message').keypress(function(e) {
        var unicode = e.charCode ? e.charCode : e.keyCode; 
        if((unicode>32 && unicode<38) || (unicode>57 && unicode<65) || (unicode>90 && unicode<97) ||  (unicode>39 && unicode<44)  || (unicode == 94)){
          return false;
        }else{
          return true;
        }
      });
      
    //var isSubmiting = false;
    $("#contactNow").on('click',  function(){
      var firstname = $("#firstname").val();
      var lastname 		= $("#lastname").val();
      var mobile		= $("#mobile").val();
      var message		= $("#message").val();
      var email		= $("#email").val();

      var fieldsArray:String[] = [firstname,lastname,mobile,message,email];
      
      for(var i = 0; i<fieldsArray.length ;i++) { 
       if(fieldsArray[i]==""){
       var jsonObj =  {"errorMessage" : "Please enter valid details."};
       errorDialog(jsonObj);
       return false;
      }
    }
      
      

      $("#contactNow").val("SUBMITING...");
      var data ={
        firstName:firstname,
        lastName:lastname,
        mobile:mobile,
        email:email,
        message:message,
        identifier: 'Contact Us'

      }
      $.ajax({
        type: "POST",
        url: This.url_form_submit,
        data: data,
        success: (response)=>{ 
          if(response.hasOwnProperty('Invalid'))
          {
            var reponseObj = JSON.parse(response);
            errorDialog(reponseObj);
          }else if(response.hasOwnProperty( 'errorMessage')){
            
            This.errorDialog(response,"Contact Us");
          }
          else{
            $("#contactNow").val("SUBMIT");
            $('#formContact').css('display','none');
            $('#thank-you').css('display','block');
          }      
         
        },
        error: function () {
          $("#contactNow").val("SUBMIT");
          alert('Unable to save details at this moment. Please try again later.');
        }

      });   
    });   
    
    function errorDialog(jsonObj){

      $("#contact-error-dialog").html('<div>'+jsonObj.errorMessage+'</div>');
    
      $('#contact-error-dialog').dialog({
    
        resizable: false,
    
        closeOnEscape: false,
    
        modal: true,
    
        width: 500,
    
        height: 200,
    
        buttons: [
    
          {
    
            text: "Ok",
    
            icon: "ui-icon-heart",
    
            click: function() {
    
             location.href="/icicinps/contact-us";
    
            }
    
          }],
    
          create: function (event, ui) {
    
     
    
            $(".ui-dialog").css('border-radius','0px');
    
            $(".ui-dialog").css('font-size','20px');
    
            $(".ui-dialog-title").css('color','#FFF');
    
            $(".ui-dialog-buttonset").css('color','#FFF');
    
            $(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
    
        },
    
      });
  
    }

  }


  validate(fieldName){

    switch (fieldName) {
    
      case 'firstname':
      var firstname = $("#firstname").val();
      if(firstname=="" || firstname=="First Name*"){
        $(".error-msg span").text("Please enter first name.");
        $(".error-msg#firstname-error").css('display','block');
        $("#firstname").addClass('errorRed');
        $("#firstname").focus();
        return false;
      }else if(!validateFirstnameLastname(document.getElementById('firstname'),"Please enter valid first name.")) {
        $("#firstname").addClass('errorRed')
        $(".error-msg#firstname-error").css('display','block');
        return false;
      }else{
        $("#firstname").removeClass('errorRed');
        $(".error-msg#firstname-error").css('display','none');
      }
    
      break;
    
        
      case 'lastname':
      var lastname = $("#lastname").val();
      if(lastname=="" || lastname=="First Name*"){
        $(".error-msg span").text("Please enter last name.");
        $(".error-msg#lastname-error").css('display','block');
        $("#lastname").addClass('errorRed');
        $("#lastname").focus();
        return false;
      }else if(!validateFirstnameLastname(document.getElementById('lastname'),"Please enter valid last name.")) {
        $("#lastname").addClass('errorRed')
        $(".error-msg#lastname-error").css('display','block');
        return false;
      }else{
        $("#lastname").removeClass('errorRed');
        $(".error-msg#lastname-error").css('display','none');
      }
    
      break;
    
      case 'mobile':
      var mobile = $("#mobile").val();
      var checkmobile  = validateMobile(mobile);
      if(mobile=="" || mobile=="Mobile Number*"){
        $(".error-msg span").text("Please enter your mobile.");
        $(".error-msg#mobile-error").css('display','block');
        $("#mobile").addClass('errorRed');
        $("#mobile").focus();
        return false;
      }else if (!checkmobile) {
        $(".error-msg#mobile-error span").text("Please enter valid mobile no.");
        $(".error-msg#mobile-error").css('display','block');
        $("#mobile").addClass('errorRed');
        $("#mobile").focus();
        return false;
      }else {
        $("#mobile").removeClass('errorRed');
        $(".error-msg#mobile-error").css('display','none');
      }
      
      break; 
    
    
      case 'email':
      var email = $("#email").val();
      var checkemail  = validateEmailAddress(email);
      if(email=='' || email=='Email Id*'){
        $(".error-msg#email-error span").text('Please enter email address.');
        $(".error-msg#email-error").css('display','block');
        $("#email").addClass('errorRed')
        $("#email").focus();
        return  false;
        
      }else if(!checkemail && email!=''){
        $(".error-msg#email-error span").text('Please enter valid email address.');
        $(".error-msg#email-error").css('display','block');
        $("#email").addClass('errorRed')
        $("#email").focus();
        return false;
      }else{
        $("#email").removeClass('errorRed');
        $(".error-msg").css('display','none');
      }

      break;


      case 'message':
      var message = $("#message").val();
      if (message.length > 500) {
        $(".error-msg#message-error span").text("Please enter less than or equal to 500 characters.");
        $(".error-msg#message-error").css('display','block');
        $("#message").addClass('errorRed');
        $("#message").focus();
        return false;
      }else {
        $("#message").removeClass('errorRed');
        $(".error-msg").css('display','none');
      }

      break;
    
      
      default:
        break;
    }
    
    
    //FirstNameLastName
    function validateFirstnameLastname(obj, msg) {
      //var validStr = /^[a-zA-Z ]{1,}$/;
      var validStr =  /(\b(?:([A-Za-z])(?!\2{2}))+\b)/
     // var NameArr = obj.value.split("");
     var value = obj.value;
     // for (var i = 0; i < NameArr.length + 5; i++) {
        if (validStr.test(value) == false) {
          $(".error-msg span").text(msg);
          obj.focus();
          obj.select();
          return false;
        }
     // } 
      return true;
    }
    
    //email
    function validateEmailAddress(elementValue) {
      var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
      var op = emailPattern.test(elementValue);
      if (op == false) {
        return false;
      } else {
        return true;
      }
    }

    //mobile validation
    function validateMobile(elementValue) {
      var mobilePattern = /(^[6-9]{1}[\d]{9}$)|(^([0]{2})[\d]{11,14}$)/;
      var op = mobilePattern.test(elementValue);
      if (op == false) {
        return false;
      } else {
        return true;
      }
    }
     
      }


}
