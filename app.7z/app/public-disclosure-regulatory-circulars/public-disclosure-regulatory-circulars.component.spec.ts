import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicDisclosureRegulatoryCircularsComponent } from './public-disclosure-regulatory-circulars.component';

describe('PublicDisclosurePolicyComponent', () => {
  let component: PublicDisclosureRegulatoryCircularsComponent;
  let fixture: ComponentFixture<PublicDisclosureRegulatoryCircularsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicDisclosureRegulatoryCircularsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicDisclosureRegulatoryCircularsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
