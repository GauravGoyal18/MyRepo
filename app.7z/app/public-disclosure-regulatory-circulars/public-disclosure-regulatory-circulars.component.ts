import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $;

@Component({
  selector: 'app-public-disclosure-regulatory-circulars',
  templateUrl: './public-disclosure-regulatory-circulars.component.html',
  styleUrls: ['./public-disclosure-regulatory-circulars.component.scss']
})
export class PublicDisclosureRegulatoryCircularsComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    $.getJSON(this.url_regulatory_circulars,  ( jsonObj ) =>{
     
      if(!jsonObj.hasOwnProperty( 'errorMessage')){
        this.setupListing(jsonObj);
      }else{
        this.errorDialog(jsonObj,"RegulatoryCirculars");
      }
    });  

  }
}
