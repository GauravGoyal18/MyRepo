import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-public-disclosure-company-disclosure',
  templateUrl: './public-disclosure-company-disclosure.component.html',
  styleUrls: ['./public-disclosure-company-disclosure.component.scss']
})
export class PublicDisclosureCompanyDisclosureComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
