import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicDisclosureCompanyDisclosureComponent } from './public-disclosure-company-disclosure.component';

describe('PublicDisclosureCompanyDisclosureComponent', () => {
  let component: PublicDisclosureCompanyDisclosureComponent;
  let fixture: ComponentFixture<PublicDisclosureCompanyDisclosureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicDisclosureCompanyDisclosureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicDisclosureCompanyDisclosureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
