import { Component } from '@angular/core';
import {Router, NavigationEnd} from "@angular/router";
import {GoogleAnalyticsEventsService} from "./google-analytics-events.service";
import { DataService } from './data/data.service';

//import { FormBuilder, FormGroup, Validators } from '@angular/forms';
declare var ga: Function;
declare var $, window;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'icicipru';
   
  
    constructor(public router: Router, public googleAnalyticsEventsService: GoogleAnalyticsEventsService, public dataService:DataService){
    this.router.events.subscribe(event => {
       if (event instanceof NavigationEnd) {
         ga('set', 'page', event.urlAfterRedirects);
         ga('send', 'pageview');
         // console.log("test");         
        // this.submitEvent(); 
       }
      });
  }
  ngOnInit() {
    this.googleAnalyticsEventsService.setUrl();
    var headerSearchBtn = $("#headerSearchBtn");
    var headerSearchText = $("#headerSearchText");
    
    headerSearchBtn.unbind("click");
    headerSearchBtn.bind("click", ()=>{
      var searchVal = headerSearchText.val();
      if(searchVal!=""){
        this.dataService.searchInputText = searchVal;

        if(this.dataService.searchBtn){
          this.dataService.searchBtn.trigger("click");
        }else{
          headerSearchText.val("");
          this.router.navigate(["/search"]);
        }
      }
    })
    headerSearchText.unbind("keydown");
    headerSearchText.bind("keydown",  (e)=>{
      //console.log(e.keyCode);
      if (e.keyCode == 13) {
        headerSearchBtn.trigger("click");
        if(window.closeNativation){
          window.closeNativation();
        }        
      }
    });
  
  }
  submitEvent(){

    
    this.googleAnalyticsEventsService.emitEvent("testCategory", "testAction", "testLabel", 10);
  }

  onActivate(event) {
      window.scroll(0,0);
  }
  
}
