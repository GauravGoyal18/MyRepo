import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicDisclosureProxyVotingDetailsComponent } from './public-disclosure-proxy-voting-details.component';

describe('PublicDisclosureProxyVotingDetailsComponent', () => {
  let component: PublicDisclosureProxyVotingDetailsComponent;
  let fixture: ComponentFixture<PublicDisclosureProxyVotingDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicDisclosureProxyVotingDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicDisclosureProxyVotingDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
