import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $;

@Component({
  selector: 'app-public-disclosure-proxy-voting-details',
  templateUrl: './public-disclosure-proxy-voting-details.component.html',
  styleUrls: ['./public-disclosure-proxy-voting-details.component.scss']
})
export class PublicDisclosureProxyVotingDetailsComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    $.getJSON(this.url_proxy_voting_detail,  ( jsonObj ) =>{
    
      if(!jsonObj.hasOwnProperty( 'errorMessage')){

        this.setupListing(jsonObj);
  
      }else{
  
        this.errorDialog(jsonObj,"Proxy Voting Details");
  
      }
    });  

  }
}
