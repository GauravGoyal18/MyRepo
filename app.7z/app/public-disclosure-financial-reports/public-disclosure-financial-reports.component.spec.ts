import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicDisclosureFinancialReportsComponent } from './public-disclosure-financial-reports.component';

describe('PublicDisclosureFinancialReportsComponent', () => {
  let component: PublicDisclosureFinancialReportsComponent;
  let fixture: ComponentFixture<PublicDisclosureFinancialReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicDisclosureFinancialReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicDisclosureFinancialReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
