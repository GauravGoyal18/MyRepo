import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $;

@Component({
  selector: 'app-public-disclosure-financial-reports',
  templateUrl: './public-disclosure-financial-reports.component.html',
  styleUrls: ['./public-disclosure-financial-reports.component.scss']
})
export class PublicDisclosureFinancialReportsComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    $.getJSON(this.url_financial_reports,  ( jsonObj ) =>{
      if(!jsonObj.hasOwnProperty( 'errorMessage')){

        this.setupTable(jsonObj);
  
      }else{
  
        this.errorDialog(jsonObj,"Financial Reports");
  
      }
    });
  }

}
