import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutNpsExitProcessComponent } from './about-nps-exit-process.component';

describe('AboutNpsExitProcessComponent', () => {
  let component: AboutNpsExitProcessComponent;
  let fixture: ComponentFixture<AboutNpsExitProcessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutNpsExitProcessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsExitProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
