import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $;
@Component({
  selector: 'app-about-nps-exit-process',
  templateUrl: './about-nps-exit-process.component.html',
  styleUrls: ['./about-nps-exit-process.component.scss']
})
export class AboutNpsExitProcessComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    $('#navTab').children('li').first().children('a').addClass('active')
      .next().addClass('is-open').show();
  $('#navTab').on('click', 'li > a', function() {
    if (!$(this).hasClass('active')) {
      $('#navTab .is-open').removeClass('is-open').hide();
      $(this).next().toggleClass('is-open').toggle();
      $('#navTab').find('.active').removeClass('active');
      $(this).addClass('active');
      } else {
      $('#navTab .is-open').removeClass('is-open').hide();
      $(this).removeClass('active');
    }
 });
  }

}

