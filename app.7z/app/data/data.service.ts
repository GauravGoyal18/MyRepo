import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  public searchInputText;
  public searchJSON;
  public searchFilterJSON;
  public searchBtn;
  constructor() { 
    this.searchInputText = "";
    this.searchJSON = [];
    this.searchFilterJSON = [];
    this.searchBtn = null;
  }

}
