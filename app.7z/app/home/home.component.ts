import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
import { Meta, Title } from '@angular/platform-browser';
import { ReadFromInjectorFn } from '../../../node_modules/@angular/core/src/render3/di';
import { httpFactory } from '../../../node_modules/@angular/platform-server/src/http';

declare var $;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent extends BasepageComponent implements OnInit {

  bannerslides = [
    { img: "./assets/images/home/home-banner-10.jpg", mobimg: "./assets/images/mobile/home/home-banner-10.jpg" },
    //{ img: "./assets/images/home/home-banner-1.jpg", mobimg: "./assets/images/mobile/home/home-banner-1.jpg" },
    //{ img: "./assets/images/home/home-banner-1.jpg", mobimg: "./assets/images/mobile/home/home-banner-1.jpg" },
    //{ img: "./assets/images/home/home-banner-1.jpg", mobimg: "./assets/images/mobile/home/home-banner-1.jpg" }
  ];
  bannerConfig = { "slidesToShow": 1, "slidesToScroll": 1, "infinite": true, "dots": false, "arrows": false, "autoplay": false, responsive: [{ breakpoint: 640, settings: { arrows: false } }] };

  slides = [
    //{ img: "./assets/images/home/ico-voluntary.png", label: 'Voluntary', desc: 'NPS is voluntary and open to every Indian citizen' },
    { img: "./assets/images/home/ico-simple.png", label: 'Simple', desc: 'Open your NPS account in few easy steps' },
    { img: "./assets/images/home/ico-safe-and-secure.png", label: 'Safe and secure', desc: 'Your money is safe as NPS is regulated by a government  authority PFRDA' },
    { img: "./assets/images/home/ico-low-cost.png", label: 'Low Cost', desc: 'NPS has one of the lowest administrative and fund management charges' }, 
    { img: "./assets/images/home/flexibole-home.png", label: 'Flexible', desc: 'Choose your investment options as per your requirements' },
    // {img: "./assets/images/home/ico-simple.png", label: 'Simple', desc:'Open an account online in 5 easy steps. NPS is a standard product designed by PFRDA.'},
    { img: "./assets/images/home/icon-portable.png", label: 'Portable', desc: 'Operate your account from anywhere in the country' }
    
    
  ];
  slideConfig = {
    "slidesToShow": 3, "slidesToScroll": 1, "infinite": true, "dots": true, "centerMode": true, "centerPadding": "0px", responsive: [{
      breakpoint: 767, settings: {
        "slidesToShow": 1, "slidesToScroll": 1, "centerMode": false, "centerPadding": "0px"
      }
    }]
  };

  nextArrow() {

  }

  addSlide(e) {
    //this.slides.push({img: "http://placehold.it/350x150/777777", label: 'label 7'})
  }

  removeSlide(e) {
    //this.slides.length = this.slides.length - 1;
  }

  slickInit(e) {
    //console.log('slick initialized');
  }

  breakpoint(e) {
    //console.log('breakpoint');
  }

  afterChange(e) {
    //console.log('afterChange');
  }

  beforeChange(e) {
    //console.log('beforeChange');
  }

  constructor(public title: Title, public meta: Meta) {
    super();
    //
    this.title.setTitle("ICICI Prudential Pension Funds");
    this.meta.addTag({ name: 'description', content: '' });
    this.meta.addTag({ name: 'keywords', content: '' });
    this.meta.addTag({ name: 'author', content: 'bcwebwise' });

  }

  ngOnInit() {

    
}


};

