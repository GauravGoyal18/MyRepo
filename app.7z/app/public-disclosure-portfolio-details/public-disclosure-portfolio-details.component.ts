import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $;

@Component({
  selector: 'app-public-disclosure-portfolio-details',
  templateUrl: './public-disclosure-portfolio-details.component.html',
  styleUrls: ['./public-disclosure-portfolio-details.component.scss']
})
export class PublicDisclosurePortfolioDetailsComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() { 

    $.getJSON(this.url_portfolio_details,  ( jsonObj ) =>{
    
      if(!jsonObj.hasOwnProperty( 'errorMessage')){

        this.setupTable(jsonObj);
  
      }else{
  
        this.errorDialog(jsonObj,"Portfolio Details");
  
      }
    });
  }

}
