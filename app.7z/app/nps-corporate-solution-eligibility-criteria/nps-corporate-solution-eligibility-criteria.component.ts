import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-nps-corporate-solution-eligibility-criteria',
  templateUrl: './nps-corporate-solution-eligibility-criteria.component.html',
  styleUrls: ['./nps-corporate-solution-eligibility-criteria.component.scss']
})
export class NpsCorporateSolutionEligibilityCriteriaComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
