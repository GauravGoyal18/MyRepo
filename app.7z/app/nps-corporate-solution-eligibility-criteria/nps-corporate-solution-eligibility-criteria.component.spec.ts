import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NpsCorporateSolutionEligibilityCriteriaComponent } from './nps-corporate-solution-eligibility-criteria.component';

describe('NpsCorporateSolutionEligibilityCriteriaComponent', () => {
  let component: NpsCorporateSolutionEligibilityCriteriaComponent;
  let fixture: ComponentFixture<NpsCorporateSolutionEligibilityCriteriaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NpsCorporateSolutionEligibilityCriteriaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NpsCorporateSolutionEligibilityCriteriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
