import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $: Function;

@Component({
  selector: 'app-corporate-calculator',
  templateUrl: './corporate-calculator.component.html',
  styleUrls: ['./corporate-calculator.component.scss']
})
export class CorporateCalculatorComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    var slideSmoothVal = 50;
    function setUpSlider(props){
      var sliderRef = $(props.id);
      sliderRef.slider({
        range: "min",
        value: props.inValue*slideSmoothVal,
        min: props.min*slideSmoothVal,
        max: props.max*slideSmoothVal,
        slide: function( event, ui ) {
          sliderRef.find(".ui-slider-handle").html(Math.round(ui.value/slideSmoothVal)+props.postFix );
          setTimeout(function(){
            calculate();
          }, 40);          
        }
      });
      sliderRef.find(".ui-slider-handle").html(props.inValue+props.postFix);
    }
    function setOnChange(props){
      $(props.id).change(function(){
        //console.log("change")
        calculate();
      })
      $(props.id).keyup(function(){
        //console.log("change")
        calculate();
      })
    }
    setUpSlider({id:"#currentage", inValue:22, min:18, max:60, postFix:""});
    setUpSlider({id:"#retirementage", inValue:57, min:41, max:60, postFix:""});
    setUpSlider({id:"#yearlySalaryIncreament", inValue:8, min:0, max:100, postFix:"%"});
    setUpSlider({id:"#growthRate", inValue:8, min:5, max:20, postFix:"%"});
    setUpSlider({id:"#corpusreinvested", inValue:80, min:40, max:100, postFix:"%"});
    setUpSlider({id:"#expectedROI", inValue:8, min:6, max:10, postFix:"%"});
    setOnChange({id:"#monthlyBasicSalary"});
  
    function calculate(){
      var currentAge = Math.round(Number($("#currentage").slider( "value" ))/slideSmoothVal);
      var retirementAge = Math.round(Number($("#retirementage").slider( "value" ))/slideSmoothVal);     
      var yearlySalaryIncreament = Math.round(Number($("#yearlySalaryIncreament").slider("value"))/slideSmoothVal);
      var growthRate = Math.round(Number($("#growthRate").slider( "value" ))/slideSmoothVal);
      var corpusreinvested = Math.round(Number($("#corpusreinvested").slider( "value" ))/slideSmoothVal);
      var expectedROI = Math.round(Number($("#expectedROI").slider( "value" ))/slideSmoothVal);

      var monthlyBasicSalary = Math.round(Number($("#monthlyBasicSalary").val()));
      var totalInvetPeriod = retirementAge - currentAge;
      var totalNumOfMonths = totalInvetPeriod*12;

      var principalAmount = 0;
      var pensionWealth = 0;
      var monthlySalaryYearWise = monthlyBasicSalary;
      if (totalInvetPeriod > 0) {
        for (var i = 0; i < totalInvetPeriod; i++) {
          var monthlyConYearWise = (monthlySalaryYearWise * 10) / 100;

          principalAmount += (monthlyConYearWise*12);   
          
          monthlySalaryYearWise = monthlySalaryYearWise+(monthlySalaryYearWise * yearlySalaryIncreament) / 100;     

          pensionWealth += Number(fv(growthRate, 12, 12, monthlyConYearWise, 0))
        }
      }
      principalAmount = Math.round(principalAmount);
      pensionWealth = Math.round(pensionWealth);

            
      var interestEarned = pensionWealth-principalAmount;
      var totalTax = Math.round(principalAmount*0.309);

      var pensionAmountReinvested = Math.round((pensionWealth*corpusreinvested)/100);

      var pensionPerMonth = Math.round(((pensionAmountReinvested*expectedROI)/100)/12)
  
      $("#totalInvestingPeriod").val(totalInvetPeriod);
      $("#principalAmount").val(principalAmount);
      $("#pensionWealth").val(pensionWealth);
      $("#interestEarned").val(interestEarned);
      $("#totalTax").val(totalTax);
      $("#pensionAmountReinvested").val(pensionAmountReinvested);
      $("#pensionPerMonth").val(pensionPerMonth);
    }
    
    function fv(rate, per, nper, pmt, pv){
      per = Number(per)
      var x, fv_value;
      nper = parseFloat(nper);
      pmt = parseFloat(pmt);
      pv = parseFloat(pv);
      rate = (rate)/(per * 100);

      if (( pmt == 0 ) || ( nper == 0 )) {
        //alert("Why do you want to test me with zeros?");
        return(0);
      }
      if ( rate == 0 ){
          fv_value = -(pv + (pmt * nper)); 
      }   else    {
          x = Math.pow(1 + rate, nper);
          fv_value = ( -pmt  +  x * pmt  + rate * x * pv ) /rate;
      }
      fv_value = conv_number(fv_value,2);		
      return (fv_value);
    }
    function conv_number(expr, decplaces) { 	
        var str = "" + Math.round(eval(expr) * Math.pow(10,decplaces));
        while (str.length <= decplaces) {
              str = "0" + str;
        }
        var decpoint = str.length - decplaces;
        return (str.substring(0,decpoint) + "." + str.substring(decpoint,str.length));
    }
    calculate();
  }

}
