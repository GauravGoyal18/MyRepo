import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateCalculatorComponent } from './corporate-calculator.component';

describe('CorporateCalculatorComponent', () => {
  let component: CorporateCalculatorComponent;
  let fixture: ComponentFixture<CorporateCalculatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporateCalculatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporateCalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
