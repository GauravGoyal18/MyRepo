import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutNpsNpsChargesComponent } from './about-nps-nps-charges.component';

describe('AboutNpsNpsChargesComponent', () => {
  let component: AboutNpsNpsChargesComponent;
  let fixture: ComponentFixture<AboutNpsNpsChargesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutNpsNpsChargesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsNpsChargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
