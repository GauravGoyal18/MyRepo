import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-about-nps-nps-charges',
  templateUrl: './about-nps-nps-charges.component.html',
  styleUrls: ['./about-nps-nps-charges.component.scss']
})
export class AboutNpsNpsChargesComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
