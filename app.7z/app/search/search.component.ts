import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
import { DataService } from '../data/data.service';
declare var $: any;

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent extends BasepageComponent implements OnInit {
  public searchInput:any;
  public searchBtn:any;
  public searchSelected:any;
  constructor(public dataService:DataService){ 
    super();

  }
  ngOnInit() {
    if(this.dataService.searchJSON.length<=0){
      $.getJSON(this.url_search_json,  ( jsonObj ) =>{
        this.dataService.searchJSON = jsonObj.data;
        for (let i = 0; i < this.dataService.searchJSON.length; i++) {
          const element = this.dataService.searchJSON[i];
          element.id = i;
          
        }
        this.searchBtn.trigger("click");
      });
    }
    this.searchSelected = "";
    this.searchBtn = this.dataService.searchBtn =  $(".submit_btn");
    this.searchBtn.unbind("click");
    this.searchBtn.bind("click", ()=>{
      this.searchInDB({searchVal:this.dataService.searchInputText});
    });
    this.searchBtn.trigger("click");

    this.searchInput = $("#searchInput");
    this.searchInput.unbind("keydown");
    this.searchInput.bind("keydown",  (e)=>{
      //console.log(e.keyCode);
      if (e.keyCode == 13) {
        this.searchBtn.trigger("click");
      }
    });

  }
  public searchInDB(prop){    
    if(prop.searchVal==undefined || prop.searchVal==""){
      return;
    }
    this.searchSelected = prop.searchVal;
    function filterByID(item) {
      var searchArr = prop.searchVal.toLowerCase().split(" ");
      var keywordStr = item.keyword.toLowerCase();
      var isFound = true;
      for (let i = 0; i < searchArr.length; i++) {
        if(keywordStr.indexOf(searchArr[i])<0){
          isFound = false;
        }       
      }
      if (isFound) {
        return true;
      } 
      return false; 
    }    
    var arr_1 = this.dataService.searchJSON.filter(filterByID);
    //
    function filterByID_d(item) {
      var searchArr = prop.searchVal.toLowerCase().split(" ");
      var keywordStr = item.keyword.toLowerCase();
      var isFound = false;
      for (let i = 0; i < searchArr.length; i++) {
        if(keywordStr.indexOf(searchArr[i])>=0){
          isFound = true;
        }       
      }
      if (isFound) {
        return true;
      } 
      return false; 
    }    
    var arr_2 = this.dataService.searchJSON.filter(filterByID_d);
    for (let i = 0; i < arr_2.length; i++) {
      const ele_2 = arr_2[i];
      let isFound = false;
      for (let k = 0; k < arr_1.length; k++) {
        const ele_1 = arr_1[k];   
        if(ele_2.id==ele_1.id){
          isFound = true;
        } 
      }
      if(isFound==false){
        arr_1.push(ele_2);
      }
      
    }
    this.dataService.searchFilterJSON = arr_1;
    //console.log(this.dataService.searchFilterJSON);
  }
  ngOnDestroy(){
    this.dataService.searchBtn = null;
    $("#headerSearchText").val("");
  }

}
