import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicDisclosureFundPerformanceComponent } from './public-disclosure-fund-performance.component';

describe('PublicDisclosureFundPerformanceComponent', () => {
  let component: PublicDisclosureFundPerformanceComponent;
  let fixture: ComponentFixture<PublicDisclosureFundPerformanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicDisclosureFundPerformanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicDisclosureFundPerformanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
