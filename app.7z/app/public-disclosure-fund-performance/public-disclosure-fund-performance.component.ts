import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-public-disclosure-fund-performance',
  templateUrl: './public-disclosure-fund-performance.component.html',
  styleUrls: ['./public-disclosure-fund-performance.component.scss']
})
export class PublicDisclosureFundPerformanceComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
