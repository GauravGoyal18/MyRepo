import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutUsSponsorsComponent } from './about-us-sponsors.component';

describe('AboutUsSponsorsComponent', () => {
  let component: AboutUsSponsorsComponent;
  let fixture: ComponentFixture<AboutUsSponsorsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutUsSponsorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutUsSponsorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
