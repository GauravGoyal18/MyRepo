import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-about-us-sponsors',
  templateUrl: './about-us-sponsors.component.html',
  styleUrls: ['./about-us-sponsors.component.scss']
})
export class AboutUsSponsorsComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
