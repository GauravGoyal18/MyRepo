import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-layout',
  templateUrl: './app-main-layout.component.html',
  styleUrls: ['./app-main-layout.component.scss']
})
export class AppMainLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}