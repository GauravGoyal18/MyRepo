import { NgtUniversalModule } from '@ng-toolkit/universal';
import { CommonModule } from '@angular/common';
//import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule } from '@angular/forms';

import {RouterModule, Routes} from '@angular/router';
import {GoogleAnalyticsEventsService} from "./google-analytics-events.service";

// Import your library
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { ReactiveFormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { MatIconModule, MatInputModule, MatStepperModule, MatSelectModule, MatCardModule } from '@angular/material';

import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { AccordionModule } from 'ngx-bootstrap/accordion';

import { AppComponent } from './app.component';
import { BasepageComponent } from './basepage/basepage.component';

import { HomeComponent } from './home/home.component';
import { CustomerSpeakComponent } from './customer-speak/customer-speak.component';
import { PublicDisclosureComponent } from './public-disclosure/public-disclosure.component';
import { AgewiseCalculatorComponent } from './agewise-calculator/agewise-calculator.component';
import { RetirementCalculatorComponent } from './retirement-calculator/retirement-calculator.component';
import { CorporateCalculatorComponent } from './corporate-calculator/corporate-calculator.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AboutNpsFaqsComponent } from './about-nps-faqs/about-nps-faqs.component';
import { AboutNpsArchitectureComponent } from './about-nps-architecture/about-nps-architecture.component';
import { AboutNpsOverviewComponent } from './about-nps-overview/about-nps-overview.component';
import { AboutNpsBenefitsComponent } from './about-nps-benefits/about-nps-benefits.component';
import { AboutNpsNeedComponent } from './about-nps-need/about-nps-need.component';
import { AboutNpsTaxBenefitsComponent } from './about-nps-tax-benefits/about-nps-tax-benefits.component';
import { AboutNpsNpsChargesComponent } from './about-nps-nps-charges/about-nps-nps-charges.component';
import { AboutNpsInvestmentOptionsComponent } from './about-nps-investment-options/about-nps-investment-options.component';
import { AboutNpsExitProcessComponent } from './about-nps-exit-process/about-nps-exit-process.component';
import { AboutNpsAnnuityPurchaseComponent } from './about-nps-annuity-purchase/about-nps-annuity-purchase.component';
import { AboutUsCompanyInfoComponent } from './about-us-company-info/about-us-company-info.component';
import { AboutUsSponsorsComponent } from './about-us-sponsors/about-us-sponsors.component';
import { AboutUsBoardOfDirectorsComponent } from './about-us-board-of-directors/about-us-board-of-directors.component';
import { AboutUsWhyChooseIciciComponent } from './about-us-why-choose-icici/about-us-why-choose-icici.component';
import { NpsRetailSolutionEligibilityCriteriaComponent } from './nps-retail-solution-eligibility-criteria/nps-retail-solution-eligibility-criteria.component';
import { NpsRetailSolutionTaxBenefitsComponent } from './nps-retail-solution-tax-benefits/nps-retail-solution-tax-benefits.component';
import { NpsRetailSolutionTaxFaqsComponent } from './nps-retail-solution-tax-faqs/nps-retail-solution-tax-faqs.component';
import { NpsCorporateSolutionEligibilityCriteriaComponent } from './nps-corporate-solution-eligibility-criteria/nps-corporate-solution-eligibility-criteria.component';
import { NpsCorporateSolutionFaqsComponent } from './nps-corporate-solution-faqs/nps-corporate-solution-faqs.component';
import { NpsCorporateSolutionTaxBenefitEmployeeComponent } from './nps-corporate-solution-tax-benefit-employee/nps-corporate-solution-tax-benefit-employee.component';
import { NpsCorporateSolutionTaxBenefitEmployerComponent } from './nps-corporate-solution-tax-benefit-employer/nps-corporate-solution-tax-benefit-employer.component';
import { PublicDisclosureLastestNavComponent } from './public-disclosure-lastest-nav/public-disclosure-lastest-nav.component';
import { PublicDisclosureNavHistoryComponent } from './public-disclosure-nav-history/public-disclosure-nav-history.component';
import { PublicDisclosurePortfolioDetailsComponent } from './public-disclosure-portfolio-details/public-disclosure-portfolio-details.component';
import { PublicDisclosureFundPerformanceComponent } from './public-disclosure-fund-performance/public-disclosure-fund-performance.component';
import { PublicDisclosureFinancialReportsComponent } from './public-disclosure-financial-reports/public-disclosure-financial-reports.component';
import { PublicDisclosurePolicyComponent } from './public-disclosure-policy/public-disclosure-policy.component';
import { PublicDisclosureInvestmentManagementFeeComponent } from './public-disclosure-investment-management-fee/public-disclosure-investment-management-fee.component';
import { PublicDisclosureProxyVotingDetailsComponent } from './public-disclosure-proxy-voting-details/public-disclosure-proxy-voting-details.component';
import { PublicDisclosureRegulatoryCircularsComponent } from './public-disclosure-regulatory-circulars/public-disclosure-regulatory-circulars.component';
import { PublicDisclosureCompanyDisclosureComponent } from './public-disclosure-company-disclosure/public-disclosure-company-disclosure.component';
import { AboutNpsPartialWithdrawalsComponent } from './about-nps-partial-withdrawals/about-nps-partial-withdrawals.component';
import { NpsCorporateSolutionHowToRegisterComponent } from './nps-corporate-solution-how-to-register/nps-corporate-solution-how-to-register.component';
import { SearchComponent } from './search/search.component';

import { AppMainLayoutComponent } from './app-main-layout/app-main-layout.component';
import { AppMainHeaderComponent } from './app-main-header/app-main-header.component';
import { AppMainFooterComponent } from './app-main-footer/app-main-footer.component';
import { NpsApplicationFormComponent } from './nps-application-form/nps-application-form.component';
import { AppNpsFormLayoutComponent } from './nps-application-form/app-nps-form-layout/app-nps-form-layout.component';
import { AppNpsFormHeaderComponent } from './nps-application-form/app-nps-form-header/app-nps-form-header.component';
import { AppNpsFormFooterComponent } from './nps-application-form/app-nps-form-footer/app-nps-form-footer.component';
import { NpsRegistrationFormComponent } from './nps-application-form/nps-registration-form/nps-registration-form.component';
import { NpsPersonalDetailsComponent } from './nps-application-form/nps-personal-details/nps-personal-details.component';
import { NpsDeclarationByAggregatorComponent } from './nps-application-form/nps-declaration-by-aggregator/nps-declaration-by-aggregator.component';
import { NpsDeclarationByEmployerGovtComponent } from './nps-application-form/nps-declaration-by-employer-govt/nps-declaration-by-employer-govt.component';
import { NpsDeclarationBySubscriberComponent } from './nps-application-form/nps-declaration-by-subscriber/nps-declaration-by-subscriber.component';
import { NpsFilledByPopSPComponent } from './nps-application-form/nps-filled-by-pop-sp/nps-filled-by-pop-sp.component';
import { NpsOptionDetailsComponent } from './nps-application-form/nps-option-details/nps-option-details.component';
import { NpsOtherAndBankDetailsComponent } from './nps-application-form/nps-other-and-bank-details/nps-other-and-bank-details.component';
import { NpsProofOfAddressComponent } from './nps-application-form/nps-proof-of-address/nps-proof-of-address.component';
import { NpsSaveAndReviewComponent } from './nps-application-form/nps-save-and-review/nps-save-and-review.component';
import { NpsThankYouComponent } from './nps-application-form/nps-thank-you/nps-thank-you.component';
import { NpsPersonalShareDataService } from './nps-personal-shareddata.service';
import { HttpModule } from '../../node_modules/@angular/http';
import { BrowserModule } from '../../node_modules/@angular/platform-browser';
/* import { UiValidationDirective } from './nps-application-form/ui-validation/ui-validation.directive'; */







const appRoutes:Routes = [
  
  //Main Website Components
  { path:'',
    component: AppMainLayoutComponent,
    children: [
      { path :'', component: HomeComponent},
      { path :'home', component: HomeComponent, pathMatch: 'full'},
      { path :'about-us/company-overview', component: AboutUsCompanyInfoComponent},
      { path :'about-us/board-of-directors', component: AboutUsBoardOfDirectorsComponent},
      { path :'about-us/sponsors', component: AboutUsSponsorsComponent},
      { path :'about-us/why-choose-icici-pension-funds', component: AboutUsWhyChooseIciciComponent},
      { path :'about-nps/overview', component: AboutNpsOverviewComponent},
      { path :'about-nps/nps-ecosystem', component: AboutNpsArchitectureComponent},
      { path :'about-nps/benefits', component: AboutNpsBenefitsComponent},
      { path :'about-nps/need', component: AboutNpsNeedComponent},
      { path :'about-nps/tax-benefits', component: AboutNpsTaxBenefitsComponent},
      { path :'about-nps/charges-under-nps', component: AboutNpsNpsChargesComponent},
      { path :'about-nps/investment-choices', component: AboutNpsInvestmentOptionsComponent},
      { path :'about-nps/partially-withdrawals-from-nps', component: AboutNpsPartialWithdrawalsComponent},
      { path :'about-nps/faqs', component: AboutNpsFaqsComponent},   
      { path :'about-nps/exit-from-nps', component: AboutNpsExitProcessComponent},
      { path :'about-nps/income-post-retirment', component: AboutNpsAnnuityPurchaseComponent},
      { path :'nps-retail-solution/eligibility-criteria', component: NpsRetailSolutionEligibilityCriteriaComponent},
      { path :'nps-retail-solution/benefits', component: NpsRetailSolutionTaxBenefitsComponent},
      { path :'nps-retail-solution/faqs', component: NpsRetailSolutionTaxFaqsComponent},
      { path :'nps-corporate-solution/eligibility-criteria', component: NpsCorporateSolutionEligibilityCriteriaComponent},
      { path :'nps-corporate-solution/how-to-register', component: NpsCorporateSolutionHowToRegisterComponent},
      { path :'nps-corporate-solution/benefits', component: NpsCorporateSolutionTaxBenefitEmployeeComponent},
      { path :'nps-corporate-solution/tax-benefits-to-employer', component: NpsCorporateSolutionTaxBenefitEmployerComponent},
      { path :'nps-corporate-solution/faqs', component: NpsCorporateSolutionFaqsComponent},
      { path :'customer-service', component: CustomerSpeakComponent},
      { path :'calculators/nps-calculator', component: AgewiseCalculatorComponent},
      { path :'calculators/retirement-calculator', component: RetirementCalculatorComponent},
      { path :'nps-corporate-solution/corporate-calculator', component: CorporateCalculatorComponent},
      { path :'public-disclosure/latest-nav', component: PublicDisclosureLastestNavComponent},
      { path :'public-disclosure/nav-history', component: PublicDisclosureNavHistoryComponent},
      { path :'public-disclosure/portfolio-details', component: PublicDisclosurePortfolioDetailsComponent},
      { path :'public-disclosure/fund-performance', component: PublicDisclosureFundPerformanceComponent},
      { path :'public-disclosure/financial-reports', component: PublicDisclosureFinancialReportsComponent},
      { path :'public-disclosure/policy', component: PublicDisclosurePolicyComponent},
      { path :'public-disclosure/investment-management-fee', component: PublicDisclosureInvestmentManagementFeeComponent},
      { path :'public-disclosure/proxy-voting-details', component: PublicDisclosureProxyVotingDetailsComponent},
      { path :'public-disclosure/company-disclosure', component: PublicDisclosureCompanyDisclosureComponent},
      { path :'public-disclosure/regulatory-circulars', component: PublicDisclosureRegulatoryCircularsComponent},
      { path :'contact-us', component: ContactUsComponent},
      { path :'search', component: SearchComponent}
    ]
  },
  //NPS Form Application Components
  { path: 'nps-application-form',
    component: AppNpsFormLayoutComponent,
    children:[ 
      {path :'UID/:restOfPath', component:NpsApplicationFormComponent},
      {path :'registration-form', component:NpsRegistrationFormComponent},
      {path :'thank-you', component:NpsThankYouComponent}   
    ]
  },
  { path :'', redirectTo:'/home', pathMatch:'full'},
  { path :'**', redirectTo:'/home', pathMatch:'full'}
]

@NgModule({
  declarations: [
    AppComponent,
    BasepageComponent,
    HomeComponent,
    CustomerSpeakComponent,
    PublicDisclosureComponent,
    AgewiseCalculatorComponent,
    RetirementCalculatorComponent,
    CorporateCalculatorComponent,
    ContactUsComponent,
    AboutNpsFaqsComponent,
    AboutNpsArchitectureComponent,
    AboutNpsOverviewComponent,
    AboutNpsBenefitsComponent,
    AboutNpsNeedComponent,
    AboutNpsTaxBenefitsComponent,
    AboutNpsNpsChargesComponent,
    AboutNpsInvestmentOptionsComponent,
    AboutNpsExitProcessComponent,
    AboutNpsAnnuityPurchaseComponent,
    AboutNpsPartialWithdrawalsComponent,
    AboutUsCompanyInfoComponent,
    AboutUsSponsorsComponent,
    AboutUsBoardOfDirectorsComponent,
    AboutUsWhyChooseIciciComponent,
    NpsRetailSolutionEligibilityCriteriaComponent,
    NpsRetailSolutionTaxBenefitsComponent,
    NpsRetailSolutionTaxFaqsComponent,
    NpsCorporateSolutionEligibilityCriteriaComponent,
    NpsCorporateSolutionFaqsComponent,
    NpsCorporateSolutionTaxBenefitEmployeeComponent,
    NpsCorporateSolutionTaxBenefitEmployerComponent,
    
    PublicDisclosureLastestNavComponent,
    PublicDisclosureNavHistoryComponent,
    PublicDisclosurePortfolioDetailsComponent,
    PublicDisclosureFundPerformanceComponent,
    PublicDisclosureFinancialReportsComponent,
    PublicDisclosurePolicyComponent,
    PublicDisclosureInvestmentManagementFeeComponent,
    PublicDisclosureProxyVotingDetailsComponent,
    PublicDisclosureCompanyDisclosureComponent,
    PublicDisclosureRegulatoryCircularsComponent,
    NpsCorporateSolutionHowToRegisterComponent,
    
    SearchComponent,

    AppMainLayoutComponent,
    AppMainHeaderComponent,
    AppMainFooterComponent,
    NpsApplicationFormComponent,
    AppNpsFormLayoutComponent,
    AppNpsFormHeaderComponent,
    AppNpsFormFooterComponent,
    NpsRegistrationFormComponent,
    NpsPersonalDetailsComponent,
    NpsDeclarationByAggregatorComponent,
    NpsDeclarationByEmployerGovtComponent,
    NpsDeclarationBySubscriberComponent,
    NpsFilledByPopSPComponent,
    NpsOptionDetailsComponent,
    NpsOtherAndBankDetailsComponent,
    NpsProofOfAddressComponent,
    NpsSaveAndReviewComponent,
    NpsThankYouComponent,
    /* UiValidationDirective */
 
    
    
  ],
  imports:[
    CommonModule,
    HttpModule,
    NgtUniversalModule,
    BrowserAnimationsModule,
    SlickCarouselModule, 
    FormsModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    ReactiveFormsModule,
    ProgressbarModule.forRoot(),
    MatInputModule,
    MatStepperModule,
    MatIconModule,
    MatSelectModule,
    MatCardModule,
    FontAwesomeModule,
    AccordionModule.forRoot(),
    BrowserModule,
    RouterModule.forRoot(appRoutes, {anchorScrolling: 'enabled'})
  ],
  providers: [GoogleAnalyticsEventsService,NpsPersonalShareDataService],
  
})
export class AppModule { }
