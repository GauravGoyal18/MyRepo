import { Injectable } from '@angular/core';
import { NpsPersonalDetails } from './nps-application-form/child-nps-classes/RegistrationForm';


@Injectable()  
export class NpsPersonalShareDataService {  
  
 public value : NpsPersonalDetails;

 setOption(value:NpsPersonalDetails) {      
    this.value= value;  
  }  
  
  getOption() {  
    return this.value;  
  }  


 
   
} 
