import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $: Function;

@Component({
  selector: 'app-about-nps-partial-withdrawals',
  templateUrl: './about-nps-partial-withdrawals.component.html',
  styleUrls: ['./about-nps-partial-withdrawals.component.scss']
})
export class AboutNpsPartialWithdrawalsComponent extends BasepageComponent implements OnInit {

  constructor() { super();}

  ngOnInit() {
  }

}
