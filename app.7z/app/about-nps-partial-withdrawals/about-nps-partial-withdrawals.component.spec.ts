import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutNpsPartialWithdrawalsComponent } from './about-nps-partial-withdrawals.component';

describe('AboutNpsPartialWithdrawalsComponent', () => {
  let component: AboutNpsPartialWithdrawalsComponent;
  let fixture: ComponentFixture<AboutNpsPartialWithdrawalsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutNpsPartialWithdrawalsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsPartialWithdrawalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
