import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-about-nps-need',
  templateUrl: './about-nps-need.component.html',
  styleUrls: ['./about-nps-need.component.scss']
})
export class AboutNpsNeedComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
