import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutNpsNeedComponent } from './about-nps-need.component';

describe('AboutNpsNeedComponent', () => {
  let component: AboutNpsNeedComponent;
  let fixture: ComponentFixture<AboutNpsNeedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutNpsNeedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsNeedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
