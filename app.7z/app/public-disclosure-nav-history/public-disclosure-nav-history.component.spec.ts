import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicDisclosureNavHistoryComponent } from './public-disclosure-nav-history.component';

describe('PublicDisclosureNavHistoryComponent', () => {
  let component: PublicDisclosureNavHistoryComponent;
  let fixture: ComponentFixture<PublicDisclosureNavHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicDisclosureNavHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicDisclosureNavHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
