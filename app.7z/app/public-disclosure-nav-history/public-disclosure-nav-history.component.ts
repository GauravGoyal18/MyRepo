import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
declare var $;

@Component({
	selector: 'app-public-disclosure-nav-history',
	templateUrl: './public-disclosure-nav-history.component.html',
	styleUrls: ['./public-disclosure-nav-history.component.scss']
})
export class PublicDisclosureNavHistoryComponent extends BasepageComponent implements OnInit {
	bsValue = new Date();
	constructor() {
		super();
		
	}

	ngOnInit() {
		var This = this;
		
		//console.log("ss - ", $.ajax);
		var format_inception_date;
		var inception_date;
		var no_past_days;
		var initial_date;
		var url;
		var productCode;
		var mindate, maxdate, sdate, edate;

		var Months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
		var Months_cap = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
		var fullMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		var funds;
		$(document).ready(function () {
			$(".period-selection").hide();
			$(".date-selection").hide();
			$("#fundPerform").hide();
			$(".fund-charts").hide();
			$("select").change(function () {
				$(".period-selection").show();
				
				if ($("#timedropdown option:selected").val() == 'custom') {
					$(".date-selection").show();
					$("#period_dropdown").hide();
				} else{
					$(".date-selection").hide();
					$("#period_dropdown").show();
					
				}

				productCode = $('#products').val();
				if (productCode == "A1") {
					$("#fundPerform").hide();
					$(".fund-charts").hide();
					inception_date = "11/21/2016";
				}
				else if (productCode == "C1") {
					$("#fundPerform").hide();
					$(".fund-charts").hide();
					inception_date = "05/18/2009";
				}
				else if (productCode == "C2") {
					$("#fundPerform").hide();
					$(".fund-charts").hide();
					inception_date = "01/12/2010";
				}
				else if (productCode == "E1") {
					$("#fundPerform").hide();
					$(".fund-charts").hide();
					inception_date = "05/18/2009";
				}
				else if (productCode == "E2") {
					$("#fundPerform").hide();
					$(".fund-charts").hide();
					inception_date = "01/11/2010";
				}
				else if (productCode == "G1") {
					$("#fundPerform").hide();
					$(".fund-charts").hide();
					inception_date = "05/18/2009";
				}
				else if (productCode == "G2") {
					$("#fundPerform").hide();
					$(".fund-charts").hide();
					inception_date = "02/08/2010";
				}
			})
			$("#show-data").click(function () {
				$("#fundPerform").show();
				$(".fund-charts").show();
			})


			//console.log(productCode);
			//var url = '${properties.url @ context='scriptString'}?fundCode='+productCode+'&startDate='+findDate(180)+'&endDate='+findDate(0);
			var url = This.url_nav_history+'?fundCode=' + productCode + '&startDate=' + findDate(181) + '&endDate=' + findDate(1);
		});

		$("#show-data").click(function () {
			if ($("#timedropdown option:selected").val() == 'fixed') {
				switch ($('#timeframe option:selected').val()) {
					case '30':
						no_past_days = 30;
						initial_date = findDate(30);
						url = This.url_nav_history+'?fundCode=' + productCode + '&startDate=' + initial_date + '&endDate=' + findDate(1);
						break;
					case '90':
						no_past_days = 90;
						initial_date = findDate(90);
						url = This.url_nav_history+'?fundCode=' + productCode + '&startDate=' + initial_date + '&endDate=' + findDate(1);
						break;
					case '180':
						no_past_days = 180;
						initial_date = findDate(180);
						url = This.url_nav_history+'?fundCode=' + productCode + '&startDate=' + initial_date + '&endDate=' + findDate(1);
						break;
					case '365':
						no_past_days = 365;
						initial_date = findDate(365);
						url = This.url_nav_history+'?fundCode=' + productCode + '&startDate=' + initial_date + '&endDate=' + findDate(1);
						break;
					case '0':
						format_inception_date = new Date(inception_date);
						initial_date = dateFormat(format_inception_date);
						var oneDay = 24 * 60 * 60 * 1000;
						var current_date = new Date();
						var inc_date = new Date(inception_date);
						no_past_days = Math.round(Math.abs((inc_date.getTime() - current_date.getTime()) / (oneDay)));
						url = This.url_nav_history+'?fundCode=' + productCode + '&startDate=' + initial_date + '&endDate=' + findDate(1);
						break;
					default:
				}
			}

			if ($("#timedropdown option:selected").val() == 'custom') {
				$(".date-selection").show();
				mindate = $("#customdatefrom").val();
				maxdate = $("#customdateto").val();
				sdate = $("#customdatefrom").val();
				edate = $("#customdateto").val();
				url = This.url_nav_history+'?fundCode=' + productCode + '&startDate=' + sdate + '&endDate=' + edate;
				mindate = new Date(mindate.split('-')[2], Months.indexOf(mindate.split('-')[1]), mindate.split('-')[0]).getTime();
				maxdate = new Date(maxdate.split('-')[2], Months.indexOf(maxdate.split('-')[1]), maxdate.split('-')[0]).getTime();
			}


			$.ajax({
				url: url,
				dataType: "json",
				type: "GET",
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				success: function (data) {

				},
				error: function (error) {
					alert('Fund performance details are currently unavailable. Please try after some time. We regret the inconvenience.');
				},
				complete: function (data) {
					$("#loading").html("");
					funds = JSON.parse(data.responseText);
					//console.log(funds);
					//funds = funds.reverse();
					$(function () {

						var fund1 = $.map($.makeArray(funds), function (v, i) {

							//v.x = new Date(v.x).getTime(); 
							//var yyyy = "20"+v.x.split('-')[2];
							//var month_index = Months_cap.indexOf(v.x.split('-')[1]);//returns 0-11
							//var dd = v.x.split('-')[0];
							v.x = Date.UTC(v.x.split('-')[2], Months.indexOf(v.x.split('-')[1]), v.x.split('-')[0]);
							//v.x = Date.UTC(yyyy, month_index, dd);							 
							v.y = parseFloat(v.y);
							return v;

						});

						var plotoption_line = {
							marker: {
								enabled: false,
								radius: 0
							},
							states: {
								hover: {
									halo: {
										size: 7
									}
								}
							},
							events: {
								legendItemClick: function () {
									return false;
								}
							}
						};


						$('#container_fund').highcharts({
							chart: {

							},
							legend: {
								enabled: false
							},
							title: {
								text: null
							},
							xAxis: [{
								title: {
									text: 'Period',
									style: {
										color: 'black',
										fontFamily: 'ZurichBT-Roman',
										fontSize: 14,
										fontWeight: 'bold'
									}

								},
								tickPosition: 'inside',
								type: 'datetime',
								minRange: 3600000 * 24,
								labels: {
									formatter: function () {
										return new Date(this.value).getDate() + ' ' + Months[new Date(this.value).getMonth()] + ' ' + new Date(this.value).getFullYear().toString().substring(2);
									},
									style: {
										color: 'black',
										fontFamily: 'ZurichBT-Roman',
										fontSize: 14
									}
								}
							}],
							yAxis: [{

								title: {
									text: 'Unit Values (in â‚¹)',
									style: {
										color: 'black',
										fontFamily: 'ZurichBT-Roman',
										fontSize: 14,
										fontWeight: 'bold'
									}

								},
								startOnTick: false,
								endOnTick: true,
								labels: {
									useHTML: true,
									formatter: function () {
										return parseFloat(this.value).toFixed(4);
									},
									style: {
										color: 'black',
										fontFamily: 'ZurichBT-Roman',
										fontSize: 14,
										fontWeight: 'bold'
									}
								}
							}],
							plotOptions: {
								line: plotoption_line

							},
							tooltip: {
								valueDecimals: 4,
								shared: true
							},
							series: [{
								//type: 'line',
								name: 'NAV',
								data: fund1,
								turboThreshold: 0,
								color: '#004a80'
								//pointInterval: 24 * 3600 * 1000,
								//animation: {
								//    duration: 2000,
								//    easing: 'easing'
								//}
							}]
						});
						if ($("#timedropdown option:selected").val() == 'fixed') {
							var mindate = funds[funds.length - 1].x;
							mindate -= (24 * 60 * 60 * 1000) * no_past_days;
							var maxdate = funds[funds.length - 1].x;
						}
						dateRangeControl(mindate, maxdate);

						function dateRangeControl(mindate, maxdate) {

							var fundchart = $('#container_fund').highcharts();
							fundchart.xAxis[0].setExtremes(mindate, maxdate);
							//var template = $.templates("#fundsTemplate");
							var template = $.templates('<tr> <td><span class="font-s">{{:~formatDate(x)}}</span></td> <td><span class="font-s">{{:~format2(y)}}</span></td> </tr>');
							var htmlOutput = template.render(funds.reverse().slice(fundchart.series[0].points[0].index, fundchart.series[0].points[fundchart.series[0].points.length - 1].index + 1), myHelper);
							//console.log("log "+fundchart.series[0].points[0].index+" "+fundchart.series[0].points[fundchart.series[0].points.length - 1].index);
							//console.log(htmlOutput)
							$("#fund-perform-table tbody").html(htmlOutput);
						}

						var enddate = new Date(funds[0].x);
						var startdate = new Date(funds[funds.length - 1].x);

						//$("#customdatefrom").val(dateFormatter(startdate));
						//$("#customdateto").val(dateFormatter(enddate));


						/* if ($(window).width() > 1025) {
							$("#customdatefrom").dateEntry({
								dateFormat: 'dny-',
								minDate: new Date(funds[0].x),
								maxDate: new Date(funds[funds.length - 1].x),
								beforeShow: customRange
							});
							$("#customdateto").dateEntry({
								dateFormat: 'dny-',
								minDate: new Date(funds[0].x),
								maxDate: new Date(funds[funds.length - 1].x),
								beforeShow: customRange
							});
						}; */
					/*	if ($(window).width() < 1025) {

							$("#customdatefrom").datepick({
								dateFormat: 'dd-M-yyyy',
								showOnFocus: true,
								showTrigger: '#calfromImg'
							});
							$("#customdateto").datepick({
								dateFormat: 'dd-M-yyyy',
								showOnFocus: true,
								showTrigger: '#calfromImg'
							});
						///	//$('#customdatefrom').datepick({showOnFocus: false, showTrigger: '#calfromImg'});

						///	//$('#imagePicker').datepick({showOnFocus: false, showTrigger: '#calImg'});
						}; */

					});

				}
			})
		});


		//pass date object as parameter -> returns date in MMMM dd, yyyy format
		function dateFormat1(format_date) {
			var dd = format_date.getDate();
			var mm = format_date.getMonth();
			var mmm = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
			var yyyy = format_date.getFullYear();

			if (dd < 10) {
				dd = '0' + dd
			}
			var str = mmm[mm] + ' ' + dd + ', ' + yyyy;
			//console.log(str);
			return str;
		}

		var myHelpers = { format: dateFormat2 };
		$.views.helpers(myHelpers);
		//pass date yyyy-mm-dd as parameter -> returns date in MMMM dd, yyyy format
		function dateFormat2(data) {
			var format_date = new Date(data);
			var dd = format_date.getDate();
			var mm = format_date.getMonth();
			var mmm = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
			var yyyy = format_date.getFullYear();
			var ddStr = String(dd)
			if (dd < 10) {
				ddStr = ('0' + dd);
			}
			var str = mmm[mm] + ' ' + ddStr + ', ' + yyyy;
			//console.log(str);
			return str;
		}
		var myHelpers1 = { format1: toMillion };
		$.views.helpers(myHelpers1);
		function toMillion(data) {
			data = data / 1000000;
			data = data.toFixed(1);
			data = commaSeparateNumber(data);
			return data;
		}
		function commaSeparateNumber(val) {
			while (/(\d+)(\d{3})/.test(val.toString())) {
				val = val.toString().replace(/(\d+)(\d{3})/, '$1' + ',' + '$2');
			}
			return val;
		}
		//pass date object as parameter -> returns date in dd-MMM-yy format
		function dateFormat(format_date) {
			var dd = format_date.getDate();
			var mm = format_date.getMonth();
			var mmm = new Array("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC");
			var yy = format_date.getFullYear();
			yy = yy.toString().substr(2, 2);
			if (dd < 10) {
				dd = '0' + dd
			}
			var str = dd + '-' + mmm[mm] + '-' + yy;
			return str;
		}
		//pass no of past days for which date is required -> returns date in dd-MM-format
		function findDate(noOfDays) {
			var date = new Date();
			var last = new Date(date.getTime() - (noOfDays * 24 * 60 * 60 * 1000));
			return dateFormat(last);
		}

		var myHelper = {
			formatDate: function (utcdate) {

				var date = new Date(utcdate);

				var day;
				if (date.getDate() < 10) {
					day = "0" + String(date.getDate());

				} else {
					day = String(date.getDate());
				};
				//alert("month ="+date.getMonth());
				var str = fullMonths[date.getMonth()] + " " + day + ", " + date.getFullYear();
				//console.log(str);
				return str;
			}
		};

		function dateFormatter(utcdate) {

			var date = new Date(utcdate);

			var day;
			if (date.getDay() < 10) {
				day = "0" + date.getDay();

			} else {
				day = date.getDay();
			};
			//alert("month ="+date.getMonth());
			return day + "-" + Months[date.getMonth()] + "-" + date.getFullYear();
		}

		function customRange(input) {
			return {
				minDate: (input.id === 'customdateto' ?
					$('#customdatefrom').dateEntry('getDate') : null),
				maxDate: (input.id === 'customdatefrom' ?
					$('#customdateto').dateEntry('getDate') : null)
			};
		}
		var myHelpers2 = { format2: toFix };
		$.views.helpers(myHelpers2);
		function toFix(data) {
			return data.toFixed(4);
		}
	}

	
}

