import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NpsCorporateSolutionTaxBenefitEmployerComponent } from './nps-corporate-solution-tax-benefit-employer.component';

describe('NpsCorporateSolutionTaxBenefitEmployerComponent', () => {
  let component: NpsCorporateSolutionTaxBenefitEmployerComponent;
  let fixture: ComponentFixture<NpsCorporateSolutionTaxBenefitEmployerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NpsCorporateSolutionTaxBenefitEmployerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NpsCorporateSolutionTaxBenefitEmployerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
