import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-nps-corporate-solution-tax-benefit-employer',
  templateUrl: './nps-corporate-solution-tax-benefit-employer.component.html',
  styleUrls: ['./nps-corporate-solution-tax-benefit-employer.component.scss']
})
export class NpsCorporateSolutionTaxBenefitEmployerComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
