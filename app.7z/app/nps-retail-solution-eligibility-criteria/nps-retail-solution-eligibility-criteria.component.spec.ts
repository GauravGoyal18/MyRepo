import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NpsRetailSolutionEligibilityCriteriaComponent } from './nps-retail-solution-eligibility-criteria.component';

describe('NpsRetailSolutionEligibilityCriteriaComponent', () => {
  let component: NpsRetailSolutionEligibilityCriteriaComponent;
  let fixture: ComponentFixture<NpsRetailSolutionEligibilityCriteriaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NpsRetailSolutionEligibilityCriteriaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NpsRetailSolutionEligibilityCriteriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
