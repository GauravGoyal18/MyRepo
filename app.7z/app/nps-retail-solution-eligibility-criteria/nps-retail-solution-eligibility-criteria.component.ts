import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-nps-retail-solution-eligibility-criteria',
  templateUrl: './nps-retail-solution-eligibility-criteria.component.html',
  styleUrls: ['./nps-retail-solution-eligibility-criteria.component.scss']
})
export class NpsRetailSolutionEligibilityCriteriaComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
