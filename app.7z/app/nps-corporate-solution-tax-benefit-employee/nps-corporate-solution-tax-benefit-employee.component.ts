import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $: Function;

@Component({
  selector: 'app-nps-corporate-solution-tax-benefit-employee',
  templateUrl: './nps-corporate-solution-tax-benefit-employee.component.html',
  styleUrls: ['./nps-corporate-solution-tax-benefit-employee.component.scss']
})
export class NpsCorporateSolutionTaxBenefitEmployeeComponent extends BasepageComponent implements OnInit {

  constructor() {
    super();
  }

  ngOnInit() {
    $("#tab1").click(function () {
      $("#tabCont1").fadeIn();
      $("#tabCont2").hide();
      $("#tab1").addClass("active");
      $(".tab2").removeClass("active")
    });
    $(".tab2").click(function () {
      $("#tabCont2").fadeIn();
      $("#tabCont1").hide();
      $(".tab2").addClass("active");
      $("#tab1").removeClass("active")
    });
    $('#taxBenefits').slick({
      autoplay: false,
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: true,
      arrows: true,
    });
  }

}
