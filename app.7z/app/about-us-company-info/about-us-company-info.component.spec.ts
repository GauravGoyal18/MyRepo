import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutUsCompanyInfoComponent } from './about-us-company-info.component';

describe('AboutUsCompanyInfoComponent', () => {
  let component: AboutUsCompanyInfoComponent;
  let fixture: ComponentFixture<AboutUsCompanyInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutUsCompanyInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutUsCompanyInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
