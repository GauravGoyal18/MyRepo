import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-about-us-company-info',
  templateUrl: './about-us-company-info.component.html',
  styleUrls: ['./about-us-company-info.component.scss']
})
export class AboutUsCompanyInfoComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
