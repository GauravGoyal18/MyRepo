import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $: Function;

@Component({
  selector: 'app-nps-retail-solution-tax-faqs',
  templateUrl: './nps-retail-solution-tax-faqs.component.html',
  styleUrls: ['./nps-retail-solution-tax-faqs.component.scss']
})
export class NpsRetailSolutionTaxFaqsComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    $('.accordion-row').beefup({
      openSingle: true,
      scroll: true,
      scrollOffset:-95,
    });
  }

}
