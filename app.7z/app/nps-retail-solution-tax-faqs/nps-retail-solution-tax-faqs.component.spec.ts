import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NpsRetailSolutionTaxFaqsComponent } from './nps-retail-solution-tax-faqs.component';

describe('NpsRetailSolutionTaxFaqsComponent', () => {
  let component: NpsRetailSolutionTaxFaqsComponent;
  let fixture: ComponentFixture<NpsRetailSolutionTaxFaqsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NpsRetailSolutionTaxFaqsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NpsRetailSolutionTaxFaqsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
