import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $;

@Component({
  selector: 'app-customer-speak',
  templateUrl: './customer-speak.component.html',
  styleUrls: ['./customer-speak.component.scss']
})
export class CustomerSpeakComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    var This = this;

    function validateEmailAddress(elementValue) {
      var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
      var op = emailPattern.test(elementValue);
      if (op == false) {
        return false;
      } else {
        return true;
      }
    }

    $('#pran-customer').keypress(function(e) {
      var unicode = e.charCode ? e.charCode : e.keyCode; 
      if ((unicode == 8) || (unicode == 9) || (unicode > 47 && unicode < 58)){
        return true;
      }else{
        return false;
      }
    });

    $('#mobile-customer').keypress(function(e) {
      var unicode = e.charCode ? e.charCode : e.keyCode; 
      if ((unicode == 8) || (unicode == 9) || (unicode > 47 && unicode < 58)){
        return true;
      }else{
        return false;
      }
    });

    $('#commments').keypress(function(e) {
      var unicode = e.charCode ? e.charCode : e.keyCode; 
      if((unicode>32 && unicode<38) || (unicode>57 && unicode<65) || (unicode>90 && unicode<97) ||  (unicode>39 && unicode<44)  || (unicode == 94)){
        return false;
      }else{
        return true;
      }
    });
     var scheme ='';

    $("#schemeDropdown").bind('change select', function(e) {
      scheme = $(e.target).val();
      $("#scheme").removeClass('errorRed');
      $(".error-msg#scheme-error").css('display','none');
    }); 

    //var isSubmiting = false;
    $("#customerQuery").on('click',  function(){
     // var formCustomer = document.getElementById('formCustomer');
      var pran		= $("#pran-customer").val();
      var mobile		= $("#mobile-customer").val();
      var commments		= $("#commments").val();
      var email		= $("#email").val();

      var fieldsArray:String[] = [pran,mobile,commments,email];
      
      for(var i = 0; i<fieldsArray.length ;i++) { 
       if(fieldsArray[i]==""){
       var jsonObj =  {"errorMessage" : "Please enter valid details."};
       errorDialog(jsonObj);
       return false;
      }
    }

      $("#customerQuery").val("SUBMITING...");
      var data ={
        //firstname:firstname,
        //lastname:lastname,
        pran:pran,
        mobile:mobile,
        email:email,
        message:commments,
        scheme:scheme,
        identifier: 'Customer Service'
      }
      $.ajax({
        type: "POST",
        url: This.url_form_submit,
        data: data,
        success: (response)=>{ 
          
          if(response.hasOwnProperty('Invalid'))
          {
            var reponseObj = JSON.parse(response);
            errorDialog(reponseObj);
          }else if(response.hasOwnProperty( 'errorMessage')){
            
            This.errorDialog(response,"Customer Service");
          }else{
            $("#customerQuery").val("SUBMIT");
            $('#formCustomer').css('display','none');
            $('#thank-you').css('display','block');
          }
         
        },
        error: function () {
          $("#contactNow").val("SUBMIT");
        alert('Something went wrong. Please try after sometime');
        }
        //dataType: "text"
      });   



      function errorDialog(jsonObj){

        $("#cust-error-dialog").html('<div>'+jsonObj.errorMessage+'</div>');
      
        $('#cust-error-dialog').dialog({
      
          resizable: false,
      
          closeOnEscape: false,
      
          modal: true,
      
          width: 500,
      
          height: 200,
      
          buttons: [
      
            {
      
              text: "Ok",
      
              icon: "ui-icon-heart",
      
              click: function() {
      
               location.href="/icicinps/customer-service";
      
              }
      
            }],
      
            create: function (event, ui) {
      
       
      
              $(".ui-dialog").css('border-radius','0px');
      
              $(".ui-dialog").css('font-size','20px');
      
              $(".ui-dialog-title").css('color','#FFF');
      
              $(".ui-dialog-buttonset").css('color','#FFF');
      
              $(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
      
            
      
          },
      
       
      
        });
    
      }
    });    
  }


  validate(fieldName){

    switch (fieldName) {
    
      case 'pran':
      var pran		= $("#pran-customer").val();
      if(pran=="" || pran=="PRAN*"){
        $(".error-msg#pran-error span").text("Please enter your PRAN number.");
        $(".error-msg#pran-error").css('display','block');
        $("#pran-customer").addClass('errorRed');
       // $("#pran-customer").focus();
        return false;
      }else if (pran.length!= 12) {
        $(".error-msg#pran-error span").text("Please enter valid PRAN number.");
        $(".error-msg#pran-error").css('display','block');
        $("#pran-customer").addClass('errorRed');
        $("#pran-customer").focus();
        return false;
      }else {
        $("#pran-customer").removeClass('errorRed');
        $(".error-msg#pran-error").css('display','none');
      }

      break;
    
      case 'mobile':
      var mobile		= $("#mobile-customer").val();
      var checkmobile  = validateMobile(mobile);
      if(mobile=="" || mobile=="Mobile Number*"){
        $(".error-msg#mobile-error span").text("Please enter your mobile.");
        $(".error-msg#mobile-error").css('display','block');
        $("#mobile-customer").addClass('errorRed');
       // $("#mobile-customer").focus();
        return false;
      }else if (!checkmobile) {
        $(".error-msg#mobile-error span").text("Please enter valid mobile no.");
        $(".error-msg#mobile-error").css('display','block');
        $("#mobile-customer").addClass('errorRed');
        $("#mobile-customer").focus();
        return false;
      }else {
        $("#mobile-customer").removeClass('errorRed');
        $(".error-msg#mobile-error").css('display','none');
      }

      break;
    
    
      case 'email':
      var email = $("#email").val();
      var checkemail  = validateEmailAddress(email);
      if(email=='' || email=='Email Id*'){
        $(".error-msg#email-error span").text('Please enter email address.');
        $(".error-msg#email-error").css('display','block');
        $("#email").addClass('errorRed')
       // $("#email").focus();
        return  false;
        
      }else if(!checkemail && email!=''){
        $(".error-msg#email-error span").text('Please enter valid email address.');
        $(".error-msg#email-error").css('display','block');
        $("#email").addClass('errorRed')
        $("#email").focus();
        return false;
      }else{
        $("#email").removeClass('errorRed');
        $(".error-msg#email-error").css('display','none');
      }

      break;


      case 'scheme':
      var scheme = $("#schemeDropdown").val();
      if(scheme==''){
        $(".error-msg#scheme-error span").text('Please select scheme.');
        $(".error-msg#scheme-error").css('display','block');
        $("#scheme").addClass('errorRed')
        $("#scheme").focus();
        return  false;
      }else{
        $("#scheme").removeClass('errorRed');
        $(".error-msg#scheme-error").css('display','none');
      } 

      break;


      case 'commments':
      var commments		= $("#commments").val();
      if (commments.length > 500) {
        $(".error-msg#commments-error span").text("Please enter less than or equal to 500 characters.");
        $(".error-msg#commments-error").css('display','block');
        $("#commments").addClass('errorRed');
        $("#commments").focus();
        return false;
      }else {
        $("#commments").removeClass('errorRed');
        $(".error-msg#commments-error").css('display','none');
      } 

      break;
     
      default:
        break;
    }
    
    
    //email validation
    function validateEmailAddress(elementValue) {
      var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
      var op = emailPattern.test(elementValue);
      if (op == false) {
        return false;
      } else {
        return true;
      }
    }

    //mobile validation
    function validateMobile(elementValue) {
      var mobilePattern = /(^[6-9]{1}[\d]{9}$)|(^([0]{2})[\d]{11,14}$)/;
      var op = mobilePattern.test(elementValue);
      if (op == false) {
        return false;
      } else {
        return true;
      }
    }
     
      }
}
