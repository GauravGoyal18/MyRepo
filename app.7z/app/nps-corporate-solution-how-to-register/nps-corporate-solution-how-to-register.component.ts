import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $: Function;

@Component({
  selector: 'app-nps-corporate-solution-how-to-register',
  templateUrl: './nps-corporate-solution-how-to-register.component.html',
  styleUrls: ['./nps-corporate-solution-how-to-register.component.scss']
})
export class NpsCorporateSolutionHowToRegisterComponent extends BasepageComponent implements OnInit {

  constructor() { super();}

  ngOnInit() {
  }

}
