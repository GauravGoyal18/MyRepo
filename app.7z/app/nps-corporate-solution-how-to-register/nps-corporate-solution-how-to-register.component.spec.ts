import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NpsCorporateSolutionHowToRegisterComponent } from './nps-corporate-solution-how-to-register.component';

describe('NpsCorporateSolutionHowToRegisterComponent', () => {
  let component: NpsCorporateSolutionHowToRegisterComponent;
  let fixture: ComponentFixture<NpsCorporateSolutionHowToRegisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NpsCorporateSolutionHowToRegisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NpsCorporateSolutionHowToRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
