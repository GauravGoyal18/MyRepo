import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
declare var $: Function;

@Component({
  selector: 'app-about-nps-faqs',
  templateUrl: './about-nps-faqs.component.html',
  styleUrls: ['./about-nps-faqs.component.scss']
})
export class AboutNpsFaqsComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
    $('.accordion-row').beefup({
      openSingle: true,
      scroll: true,
      scrollOffset:-95,
    });
  }

}
