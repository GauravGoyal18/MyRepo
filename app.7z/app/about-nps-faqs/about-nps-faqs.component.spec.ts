import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutNpsFaqsComponent } from './about-nps-faqs.component';

describe('AboutNpsFaqsComponent', () => {
  let component: AboutNpsFaqsComponent;
  let fixture: ComponentFixture<AboutNpsFaqsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutNpsFaqsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsFaqsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
