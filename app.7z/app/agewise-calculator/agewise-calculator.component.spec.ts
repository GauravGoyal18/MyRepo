import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgewiseCalculatorComponent } from './agewise-calculator.component';

describe('AgewiseCalculatorComponent', () => {
  let component: AgewiseCalculatorComponent;
  let fixture: ComponentFixture<AgewiseCalculatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgewiseCalculatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgewiseCalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
