import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';
import { Meta, Title } from '@angular/platform-browser';

@Component({
  selector: 'app-about-nps-annuity-purchase',
  templateUrl: './about-nps-annuity-purchase.component.html',
  styleUrls: ['./about-nps-annuity-purchase.component.scss']
})
export class AboutNpsAnnuityPurchaseComponent extends BasepageComponent implements OnInit {

  constructor(public title:Title, public meta:Meta){ 
    super();
    
    this.title.setTitle("ICICI NPS Microsite");
    this.meta.addTag({ name: 'description', content: 'The National Pension Scheme (NPS) offers a solution to help you start saving for retirement.' });
    this.meta.addTag({ name: 'author', content: 'bcwebwise' });
    this.meta.addTag({ name: 'keywords', content: 'ICICI NPS, National Pension Scheme' });
  }

  ngOnInit() {
  }

}
