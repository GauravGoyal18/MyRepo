import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutNpsAnnuityPurchaseComponent } from './about-nps-annuity-purchase.component';

describe('AboutNpsAnnuityPurchaseComponent', () => {
  let component: AboutNpsAnnuityPurchaseComponent;
  let fixture: ComponentFixture<AboutNpsAnnuityPurchaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutNpsAnnuityPurchaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutNpsAnnuityPurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
