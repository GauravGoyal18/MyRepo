import { Component, OnInit } from '@angular/core';
import { BasepageComponent } from '../basepage/basepage.component';

@Component({
  selector: 'app-public-disclosure-investment-management-fee',
  templateUrl: './public-disclosure-investment-management-fee.component.html',
  styleUrls: ['./public-disclosure-investment-management-fee.component.scss']
})
export class PublicDisclosureInvestmentManagementFeeComponent extends BasepageComponent implements OnInit {

  constructor(){ 
    super();
  }

  ngOnInit() {
  }

}
