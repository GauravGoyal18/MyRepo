import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicDisclosureInvestmentManagementFeeComponent } from './public-disclosure-investment-management-fee.component';

describe('PublicDisclosureInvestmentManagementFeeComponent', () => {
  let component: PublicDisclosureInvestmentManagementFeeComponent;
  let fixture: ComponentFixture<PublicDisclosureInvestmentManagementFeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicDisclosureInvestmentManagementFeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicDisclosureInvestmentManagementFeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
