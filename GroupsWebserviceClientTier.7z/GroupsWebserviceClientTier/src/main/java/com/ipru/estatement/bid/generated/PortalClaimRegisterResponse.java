
package com.ipru.estatement.bid.generated;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PortalClaimRegisterResult" type="{}ClaimRegister" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "portalClaimRegisterResult"
})
@XmlRootElement(name = "PortalClaimRegisterResponse")
public class PortalClaimRegisterResponse {

    @XmlElementRef(name = "PortalClaimRegisterResult", type = JAXBElement.class)
    protected JAXBElement<ClaimRegister> portalClaimRegisterResult;

    /**
     * Gets the value of the portalClaimRegisterResult property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ClaimRegister }{@code >}
     *     
     */
    public JAXBElement<ClaimRegister> getPortalClaimRegisterResult() {
        return portalClaimRegisterResult;
    }

    /**
     * Sets the value of the portalClaimRegisterResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ClaimRegister }{@code >}
     *     
     */
    public void setPortalClaimRegisterResult(JAXBElement<ClaimRegister> value) {
        this.portalClaimRegisterResult = ((JAXBElement<ClaimRegister> ) value);
    }

}
