
package com.ipru.estatement.bid.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOfAuthorisedSignatory complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfAuthorisedSignatory">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AuthorisedSignatory" type="{}AuthorisedSignatory" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfAuthorisedSignatory", propOrder = {
    "authorisedSignatory"
})
public class ArrayOfAuthorisedSignatory {

    @XmlElement(name = "AuthorisedSignatory", nillable = true)
    protected List<AuthorisedSignatory> authorisedSignatory;

    /**
     * Gets the value of the authorisedSignatory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the authorisedSignatory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthorisedSignatory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AuthorisedSignatory }
     * 
     * 
     */
    public List<AuthorisedSignatory> getAuthorisedSignatory() {
        if (authorisedSignatory == null) {
            authorisedSignatory = new ArrayList<AuthorisedSignatory>();
        }
        return this.authorisedSignatory;
    }

}
