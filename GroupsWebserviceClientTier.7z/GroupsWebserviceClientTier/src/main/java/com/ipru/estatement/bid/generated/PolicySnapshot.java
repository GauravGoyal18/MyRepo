
package com.ipru.estatement.bid.generated;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PolicySnapshot complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PolicySnapshot">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AuthorisedSignatory" type="{}ArrayOfAuthorisedSignatory" minOccurs="0"/>
 *         &lt;element name="BidAsOnDate" type="{}ArrayOfBID" minOccurs="0"/>
 *         &lt;element name="BilledToDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CompanyAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CompanyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InforceMemberUnderPolicy" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="MstPolicyNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PaidToDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PolicyCommencementDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PolicyInceptionDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PolicyRenewalDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PolicyType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PremiumMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicySnapshot", propOrder = {
    "authorisedSignatory",
    "bidAsOnDate",
    "billedToDt",
    "companyAddress",
    "companyName",
    "inforceMemberUnderPolicy",
    "mstPolicyNo",
    "paidToDt",
    "policyCommencementDt",
    "policyInceptionDt",
    "policyRenewalDt",
    "policyType",
    "premiumMode"
})
public class PolicySnapshot {

    @XmlElementRef(name = "AuthorisedSignatory", type = JAXBElement.class)
    protected JAXBElement<ArrayOfAuthorisedSignatory> authorisedSignatory;
    @XmlElementRef(name = "BidAsOnDate", type = JAXBElement.class)
    protected JAXBElement<ArrayOfBID> bidAsOnDate;
    @XmlElementRef(name = "BilledToDt", type = JAXBElement.class)
    protected JAXBElement<String> billedToDt;
    @XmlElementRef(name = "CompanyAddress", type = JAXBElement.class)
    protected JAXBElement<String> companyAddress;
    @XmlElementRef(name = "CompanyName", type = JAXBElement.class)
    protected JAXBElement<String> companyName;
    @XmlElementRef(name = "InforceMemberUnderPolicy", type = JAXBElement.class)
    protected JAXBElement<Integer> inforceMemberUnderPolicy;
    @XmlElementRef(name = "MstPolicyNo", type = JAXBElement.class)
    protected JAXBElement<String> mstPolicyNo;
    @XmlElementRef(name = "PaidToDt", type = JAXBElement.class)
    protected JAXBElement<String> paidToDt;
    @XmlElementRef(name = "PolicyCommencementDt", type = JAXBElement.class)
    protected JAXBElement<String> policyCommencementDt;
    @XmlElementRef(name = "PolicyInceptionDt", type = JAXBElement.class)
    protected JAXBElement<String> policyInceptionDt;
    @XmlElementRef(name = "PolicyRenewalDt", type = JAXBElement.class)
    protected JAXBElement<String> policyRenewalDt;
    @XmlElementRef(name = "PolicyType", type = JAXBElement.class)
    protected JAXBElement<String> policyType;
    @XmlElementRef(name = "PremiumMode", type = JAXBElement.class)
    protected JAXBElement<String> premiumMode;

    /**
     * Gets the value of the authorisedSignatory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfAuthorisedSignatory }{@code >}
     *     
     */
    public JAXBElement<ArrayOfAuthorisedSignatory> getAuthorisedSignatory() {
        return authorisedSignatory;
    }

    /**
     * Sets the value of the authorisedSignatory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfAuthorisedSignatory }{@code >}
     *     
     */
    public void setAuthorisedSignatory(JAXBElement<ArrayOfAuthorisedSignatory> value) {
        this.authorisedSignatory = ((JAXBElement<ArrayOfAuthorisedSignatory> ) value);
    }

    /**
     * Gets the value of the bidAsOnDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBID }{@code >}
     *     
     */
    public JAXBElement<ArrayOfBID> getBidAsOnDate() {
        return bidAsOnDate;
    }

    /**
     * Sets the value of the bidAsOnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBID }{@code >}
     *     
     */
    public void setBidAsOnDate(JAXBElement<ArrayOfBID> value) {
        this.bidAsOnDate = ((JAXBElement<ArrayOfBID> ) value);
    }

    /**
     * Gets the value of the billedToDt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBilledToDt() {
        return billedToDt;
    }

    /**
     * Sets the value of the billedToDt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBilledToDt(JAXBElement<String> value) {
        this.billedToDt = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the companyAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCompanyAddress() {
        return companyAddress;
    }

    /**
     * Sets the value of the companyAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCompanyAddress(JAXBElement<String> value) {
        this.companyAddress = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the companyName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCompanyName() {
        return companyName;
    }

    /**
     * Sets the value of the companyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCompanyName(JAXBElement<String> value) {
        this.companyName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the inforceMemberUnderPolicy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getInforceMemberUnderPolicy() {
        return inforceMemberUnderPolicy;
    }

    /**
     * Sets the value of the inforceMemberUnderPolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setInforceMemberUnderPolicy(JAXBElement<Integer> value) {
        this.inforceMemberUnderPolicy = ((JAXBElement<Integer> ) value);
    }

    /**
     * Gets the value of the mstPolicyNo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMstPolicyNo() {
        return mstPolicyNo;
    }

    /**
     * Sets the value of the mstPolicyNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMstPolicyNo(JAXBElement<String> value) {
        this.mstPolicyNo = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the paidToDt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaidToDt() {
        return paidToDt;
    }

    /**
     * Sets the value of the paidToDt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaidToDt(JAXBElement<String> value) {
        this.paidToDt = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the policyCommencementDt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPolicyCommencementDt() {
        return policyCommencementDt;
    }

    /**
     * Sets the value of the policyCommencementDt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPolicyCommencementDt(JAXBElement<String> value) {
        this.policyCommencementDt = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the policyInceptionDt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPolicyInceptionDt() {
        return policyInceptionDt;
    }

    /**
     * Sets the value of the policyInceptionDt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPolicyInceptionDt(JAXBElement<String> value) {
        this.policyInceptionDt = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the policyRenewalDt property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPolicyRenewalDt() {
        return policyRenewalDt;
    }

    /**
     * Sets the value of the policyRenewalDt property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPolicyRenewalDt(JAXBElement<String> value) {
        this.policyRenewalDt = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the policyType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPolicyType() {
        return policyType;
    }

    /**
     * Sets the value of the policyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPolicyType(JAXBElement<String> value) {
        this.policyType = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the premiumMode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPremiumMode() {
        return premiumMode;
    }

    /**
     * Sets the value of the premiumMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPremiumMode(JAXBElement<String> value) {
        this.premiumMode = ((JAXBElement<String> ) value);
    }

}
