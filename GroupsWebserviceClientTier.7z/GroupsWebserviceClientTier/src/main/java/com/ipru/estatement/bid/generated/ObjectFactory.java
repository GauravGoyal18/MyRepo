
package com.ipru.estatement.bid.generated;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import com.ipru.estatement.bid.generated.ArrayOfAuthorisedSignatory;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ipru.estatement.bid.generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _BID_QNAME = new QName("", "BID");
    private final static QName _AnyURI_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "anyURI");
    private final static QName _Char_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "char");
    private final static QName _DateTime_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "dateTime");
    private final static QName _PolicySnapshot_QNAME = new QName("", "PolicySnapshot");
    private final static QName _QName_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "QName");
    private final static QName _CompanyAddress_QNAME = new QName("", "CompanyAddress");
    private final static QName _UnsignedShort_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedShort");
    private final static QName _Float_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "float");
    private final static QName _ArrayOfBIDLine_QNAME = new QName("", "ArrayOfBIDLine");
    private final static QName _Long_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "long");
    private final static QName _Short_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "short");
    private final static QName _BIDLine_QNAME = new QName("", "BIDLine");
    private final static QName _AuthorizedSignatory_QNAME = new QName("", "AuthorizedSignatory");
    private final static QName _Base64Binary_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "base64Binary");
    private final static QName _Byte_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "byte");
    private final static QName _AuthorisedSignatory_QNAME = new QName("", "AuthorisedSignatory");
    private final static QName _Boolean_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "boolean");
    private final static QName _ArrayOfAuthorisedSignatory_QNAME = new QName("", "ArrayOfAuthorisedSignatory");
    private final static QName _ContactPerson_QNAME = new QName("", "ContactPerson");
    private final static QName _UnsignedByte_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedByte");
    private final static QName _AnyType_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "anyType");
    private final static QName _UnsignedInt_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedInt");
    private final static QName _Int_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "int");
    private final static QName _ClaimRegister_QNAME = new QName("", "ClaimRegister");
    private final static QName _Decimal_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "decimal");
    private final static QName _Double_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "double");
    private final static QName _Guid_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "guid");
    private final static QName _Duration_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "duration");
    private final static QName _String_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "string");
    private final static QName _UnsignedLong_QNAME = new QName("http://schemas.microsoft.com/2003/10/Serialization/", "unsignedLong");
    private final static QName _ArrayOfBID_QNAME = new QName("", "ArrayOfBID");
    private final static QName _BankAccountDetails_QNAME = new QName("", "BankAccountDetails");
    private final static QName _Addbeneficiary_QNAME = new QName("", "Addbeneficiary");
    private final static QName _PortalPolicySnapshotResponsePortalPolicySnapshotResult_QNAME = new QName("", "PortalPolicySnapshotResult");
    private final static QName _ContactPersonSQLERRMSG_QNAME = new QName("", "SQLERRMSG");
    private final static QName _ContactPersonResponse_QNAME = new QName("", "Response");
    private final static QName _PortalClaimRegisterResponsePortalClaimRegisterResult_QNAME = new QName("", "PortalClaimRegisterResult");
    private final static QName _PortalAddAuthorizedSignatoryResponsePortalAddAuthorizedSignatoryResult_QNAME = new QName("", "PortalAddAuthorizedSignatoryResult");
    private final static QName _PortalBankAccountDetailsResponsePortalBankAccountDetailsResult_QNAME = new QName("", "PortalBankAccountDetailsResult");
    private final static QName _PortalContactPersonNumber_QNAME = new QName("", "Number");
    private final static QName _PortalContactPersonOtherDesignation_QNAME = new QName("", "OtherDesignation");
    private final static QName _PortalContactPersonLocation_QNAME = new QName("", "Location");
    private final static QName _PortalContactPersonUserId_QNAME = new QName("", "UserId");
    private final static QName _PortalContactPersonLastName_QNAME = new QName("", "LastName");
    private final static QName _PortalContactPersonPhoneType_QNAME = new QName("", "PhoneType");
    private final static QName _PortalContactPersonTitle_QNAME = new QName("", "Title");
    private final static QName _PortalContactPersonExtension_QNAME = new QName("", "Extension");
    private final static QName _PortalContactPersonAreaCode_QNAME = new QName("", "AreaCode");
    private final static QName _PortalContactPersonMiddleName_QNAME = new QName("", "MiddleName");
    private final static QName _PortalContactPersonUnitCode_QNAME = new QName("", "UnitCode");
    private final static QName _PortalContactPersonFirstName_QNAME = new QName("", "FirstName");
    private final static QName _PortalContactPersonCountryCode_QNAME = new QName("", "CountryCode");
    private final static QName _PortalContactPersonEmailId_QNAME = new QName("", "EmailId");
    private final static QName _PortalContactPersonDesignation_QNAME = new QName("", "Designation");
    private final static QName _PortalAddAuthorizedSignatoryType_QNAME = new QName("", "Type");
    private final static QName _PortalPolicySnapshotRequestId_QNAME = new QName("", "RequestId");
    private final static QName _PortalPolicySnapshotPolicyKey_QNAME = new QName("", "PolicyKey");
    private final static QName _PortalCompanyAddressResponsePortalCompanyAddressResult_QNAME = new QName("", "PortalCompanyAddressResult");
    private final static QName _PortalAddBeneficiaryResponsePortalAddBeneficiaryResult_QNAME = new QName("", "PortalAddBeneficiaryResult");
    private final static QName _BIDUnitName_QNAME = new QName("", "UnitName");
    private final static QName _BIDBalance_QNAME = new QName("", "Balance");
    private final static QName _PortalCompanyAddressPin_QNAME = new QName("", "Pin");
    private final static QName _PortalCompanyAddressSameAs_QNAME = new QName("", "SameAs");
    private final static QName _PortalCompanyAddressState_QNAME = new QName("", "State");
    private final static QName _PortalCompanyAddressAddressType_QNAME = new QName("", "AddressType");
    private final static QName _PortalCompanyAddressCountry_QNAME = new QName("", "Country");
    private final static QName _PortalCompanyAddressAddressLine1_QNAME = new QName("", "AddressLine1");
    private final static QName _PortalCompanyAddressCity_QNAME = new QName("", "City");
    private final static QName _PortalCompanyAddressAddressLine2_QNAME = new QName("", "AddressLine2");
    private final static QName _PortalCompanyAddressAddressLine3_QNAME = new QName("", "AddressLine3");
    private final static QName _PortalContactPersonResponsePortalContactPersonResult_QNAME = new QName("", "PortalContactPersonResult");
    private final static QName _PortalBankAccountDetailsMICRCode_QNAME = new QName("", "MICRCode");
    private final static QName _PortalBankAccountDetailsAccountNo_QNAME = new QName("", "AccountNo");
    private final static QName _PortalBankAccountDetailsIFSCCode_QNAME = new QName("", "IFSCCode");
    private final static QName _PortalBankAccountDetailsBankName_QNAME = new QName("", "BankName");
    private final static QName _PortalBankAccountDetailsBankAddress1_QNAME = new QName("", "BankAddress1");
    private final static QName _PortalBankAccountDetailsBankAddress2_QNAME = new QName("", "BankAddress2");
    private final static QName _PortalBankAccountDetailsBankAddress3_QNAME = new QName("", "BankAddress3");
    private final static QName _PortalBankAccountDetailsPayableTo_QNAME = new QName("", "PayableTo");
    private final static QName _PortalBIDUnitwiseResponsePortalBIDUnitwiseResult_QNAME = new QName("", "PortalBIDUnitwiseResult");
    private final static QName _AuthorisedSignatoryAuthorisedSignatoryname_QNAME = new QName("", "AuthorisedSignatoryname");
    private final static QName _AuthorisedSignatoryMobileNo_QNAME = new QName("", "MobileNo");
    private final static QName _PortalAddBeneficiaryTypeOfPayment_QNAME = new QName("", "TypeOfPayment");
    private final static QName _PortalAddBeneficiaryBankAddress_QNAME = new QName("", "BankAddress");
    private final static QName _PortalAddBeneficiaryBeneficiarySharePCT_QNAME = new QName("", "BeneficiarySharePCT");
    private final static QName _PortalAddBeneficiaryRemarks_QNAME = new QName("", "Remarks");
    private final static QName _PortalAddBeneficiaryBeneficiaryRelation_QNAME = new QName("", "BeneficiaryRelation");
    private final static QName _PortalAddBeneficiaryEmployeeID_QNAME = new QName("", "EmployeeID");
    private final static QName _PortalAddBeneficiaryBankAccountNumber_QNAME = new QName("", "BankAccountNumber");
    private final static QName _PortalAddBeneficiaryClaimReferenceNo_QNAME = new QName("", "ClaimReferenceNo");
    private final static QName _PortalAddBeneficiaryBeneficiaryName_QNAME = new QName("", "BeneficiaryName");
    private final static QName _PortalAddBeneficiaryBeneficiaryAddress_QNAME = new QName("", "BeneficiaryAddress");
    private final static QName _PolicySnapshotPolicyInceptionDt_QNAME = new QName("", "PolicyInceptionDt");
    private final static QName _PolicySnapshotInforceMemberUnderPolicy_QNAME = new QName("", "InforceMemberUnderPolicy");
    private final static QName _PolicySnapshotCompanyName_QNAME = new QName("", "CompanyName");
    private final static QName _PolicySnapshotPolicyRenewalDt_QNAME = new QName("", "PolicyRenewalDt");
    private final static QName _PolicySnapshotPremiumMode_QNAME = new QName("", "PremiumMode");
    private final static QName _PolicySnapshotPolicyCommencementDt_QNAME = new QName("", "PolicyCommencementDt");
    private final static QName _PolicySnapshotBilledToDt_QNAME = new QName("", "BilledToDt");
    private final static QName _PolicySnapshotPaidToDt_QNAME = new QName("", "PaidToDt");
    private final static QName _PolicySnapshotBidAsOnDate_QNAME = new QName("", "BidAsOnDate");
    private final static QName _PolicySnapshotMstPolicyNo_QNAME = new QName("", "MstPolicyNo");
    private final static QName _PolicySnapshotPolicyType_QNAME = new QName("", "PolicyType");
    private final static QName _PortalClaimRegisterClaimCauseCode_QNAME = new QName("", "ClaimCauseCode");
    private final static QName _PortalClaimRegisterClaimTypeCode_QNAME = new QName("", "ClaimTypeCode");
    private final static QName _PortalClaimRegisterRiderCode_QNAME = new QName("", "RiderCode");
    private final static QName _PortalClaimRegisterEmployeeName_QNAME = new QName("", "EmployeeName");
    private final static QName _PortalBIDUnitwiseUserID_QNAME = new QName("", "UserID");
    private final static QName _BIDLineAmountDr_QNAME = new QName("", "Amount_Dr");
    private final static QName _BIDLineModeOfPayment_QNAME = new QName("", "ModeOfPayment");
    private final static QName _BIDLineAmountCr_QNAME = new QName("", "Amount_Cr");
    private final static QName _BIDLineDate_QNAME = new QName("", "Date");
    private final static QName _BIDLineParticulars_QNAME = new QName("", "Particulars");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ipru.estatement.bid.generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PortalPolicySnapshotResponse }
     * 
     */
    public PortalPolicySnapshotResponse createPortalPolicySnapshotResponse() {
        return new PortalPolicySnapshotResponse();
    }

    /**
     * Create an instance of {@link ContactPerson }
     * 
     */
    public ContactPerson createContactPerson() {
        return new ContactPerson();
    }

    /**
     * Create an instance of {@link PortalClaimRegisterResponse }
     * 
     */
    public PortalClaimRegisterResponse createPortalClaimRegisterResponse() {
        return new PortalClaimRegisterResponse();
    }

    /**
     * Create an instance of {@link ArrayOfBID }
     * 
     */
    public ArrayOfBID createArrayOfBID() {
        return new ArrayOfBID();
    }

    /**
     * Create an instance of {@link AuthorizedSignatory }
     * 
     */
    public AuthorizedSignatory createAuthorizedSignatory() {
        return new AuthorizedSignatory();
    }

    /**
     * Create an instance of {@link PortalAddAuthorizedSignatoryResponse }
     * 
     */
    public PortalAddAuthorizedSignatoryResponse createPortalAddAuthorizedSignatoryResponse() {
        return new PortalAddAuthorizedSignatoryResponse();
    }

    /**
     * Create an instance of {@link PortalBankAccountDetailsResponse }
     * 
     */
    public PortalBankAccountDetailsResponse createPortalBankAccountDetailsResponse() {
        return new PortalBankAccountDetailsResponse();
    }

    /**
     * Create an instance of {@link ArrayOfBIDLine }
     * 
     */
    public ArrayOfBIDLine createArrayOfBIDLine() {
        return new ArrayOfBIDLine();
    }

    /**
     * Create an instance of {@link BankAccountDetails }
     * 
     */
    public BankAccountDetails createBankAccountDetails() {
        return new BankAccountDetails();
    }

    /**
     * Create an instance of {@link PortalAddAuthorizedSignatory }
     * 
     */
    public PortalAddAuthorizedSignatory createPortalAddAuthorizedSignatory() {
        return new PortalAddAuthorizedSignatory();
    }

    /**
     * Create an instance of {@link PortalContactPerson }
     * 
     */
    public PortalContactPerson createPortalContactPerson() {
        return new PortalContactPerson();
    }

    /**
     * Create an instance of {@link ClaimRegister }
     * 
     */
    public ClaimRegister createClaimRegister() {
        return new ClaimRegister();
    }

    /**
     * Create an instance of {@link PortalPolicySnapshot }
     * 
     */
    public PortalPolicySnapshot createPortalPolicySnapshot() {
        return new PortalPolicySnapshot();
    }

    /**
     * Create an instance of {@link PortalAddBeneficiaryResponse }
     * 
     */
    public PortalAddBeneficiaryResponse createPortalAddBeneficiaryResponse() {
        return new PortalAddBeneficiaryResponse();
    }

    /**
     * Create an instance of {@link PortalCompanyAddressResponse }
     * 
     */
    public PortalCompanyAddressResponse createPortalCompanyAddressResponse() {
        return new PortalCompanyAddressResponse();
    }

    /**
     * Create an instance of {@link BID }
     * 
     */
    public BID createBID() {
        return new BID();
    }

    /**
     * Create an instance of {@link PortalCompanyAddress }
     * 
     */
    public PortalCompanyAddress createPortalCompanyAddress() {
        return new PortalCompanyAddress();
    }

    /**
     * Create an instance of {@link PortalContactPersonResponse }
     * 
     */
    public PortalContactPersonResponse createPortalContactPersonResponse() {
        return new PortalContactPersonResponse();
    }

    /**
     * Create an instance of {@link PortalBIDUnitwiseResponse }
     * 
     */
    public PortalBIDUnitwiseResponse createPortalBIDUnitwiseResponse() {
        return new PortalBIDUnitwiseResponse();
    }

    /**
     * Create an instance of {@link AuthorisedSignatory }
     * 
     */
    public AuthorisedSignatory createAuthorisedSignatory() {
        return new AuthorisedSignatory();
    }

    /**
     * Create an instance of {@link PortalBankAccountDetails }
     * 
     */
    public PortalBankAccountDetails createPortalBankAccountDetails() {
        return new PortalBankAccountDetails();
    }

    /**
     * Create an instance of {@link CompanyAddress }
     * 
     */
    public CompanyAddress createCompanyAddress() {
        return new CompanyAddress();
    }

    /**
     * Create an instance of {@link PortalAddBeneficiary }
     * 
     */
    public PortalAddBeneficiary createPortalAddBeneficiary() {
        return new PortalAddBeneficiary();
    }

    /**
     * Create an instance of {@link PolicySnapshot }
     * 
     */
    public PolicySnapshot createPolicySnapshot() {
        return new PolicySnapshot();
    }

    /**
     * Create an instance of {@link Addbeneficiary }
     * 
     */
    public Addbeneficiary createAddbeneficiary() {
        return new Addbeneficiary();
    }

    /**
     * Create an instance of {@link PortalClaimRegister }
     * 
     */
    public PortalClaimRegister createPortalClaimRegister() {
        return new PortalClaimRegister();
    }

    /**
     * Create an instance of {@link ArrayOfAuthorisedSignatory }
     * 
     */
    public ArrayOfAuthorisedSignatory createArrayOfAuthorisedSignatory() {
        return new ArrayOfAuthorisedSignatory();
    }

    /**
     * Create an instance of {@link PortalBIDUnitwise }
     * 
     */
    public PortalBIDUnitwise createPortalBIDUnitwise() {
        return new PortalBIDUnitwise();
    }

    /**
     * Create an instance of {@link BIDLine }
     * 
     */
    public BIDLine createBIDLine() {
        return new BIDLine();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BID")
    public JAXBElement<BID> createBID(BID value) {
        return new JAXBElement<BID>(_BID_QNAME, BID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "anyURI")
    public JAXBElement<String> createAnyURI(String value) {
        return new JAXBElement<String>(_AnyURI_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "char")
    public JAXBElement<Integer> createChar(Integer value) {
        return new JAXBElement<Integer>(_Char_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "dateTime")
    public JAXBElement<XMLGregorianCalendar> createDateTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_DateTime_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PolicySnapshot }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PolicySnapshot")
    public JAXBElement<PolicySnapshot> createPolicySnapshot(PolicySnapshot value) {
        return new JAXBElement<PolicySnapshot>(_PolicySnapshot_QNAME, PolicySnapshot.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "QName")
    public JAXBElement<QName> createQName(QName value) {
        return new JAXBElement<QName>(_QName_QNAME, QName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CompanyAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "CompanyAddress")
    public JAXBElement<CompanyAddress> createCompanyAddress(CompanyAddress value) {
        return new JAXBElement<CompanyAddress>(_CompanyAddress_QNAME, CompanyAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedShort")
    public JAXBElement<Integer> createUnsignedShort(Integer value) {
        return new JAXBElement<Integer>(_UnsignedShort_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Float }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "float")
    public JAXBElement<Float> createFloat(Float value) {
        return new JAXBElement<Float>(_Float_QNAME, Float.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBIDLine }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ArrayOfBIDLine")
    public JAXBElement<ArrayOfBIDLine> createArrayOfBIDLine(ArrayOfBIDLine value) {
        return new JAXBElement<ArrayOfBIDLine>(_ArrayOfBIDLine_QNAME, ArrayOfBIDLine.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "long")
    public JAXBElement<Long> createLong(Long value) {
        return new JAXBElement<Long>(_Long_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Short }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "short")
    public JAXBElement<Short> createShort(Short value) {
        return new JAXBElement<Short>(_Short_QNAME, Short.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BIDLine }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BIDLine")
    public JAXBElement<BIDLine> createBIDLine(BIDLine value) {
        return new JAXBElement<BIDLine>(_BIDLine_QNAME, BIDLine.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthorizedSignatory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AuthorizedSignatory")
    public JAXBElement<AuthorizedSignatory> createAuthorizedSignatory(AuthorizedSignatory value) {
        return new JAXBElement<AuthorizedSignatory>(_AuthorizedSignatory_QNAME, AuthorizedSignatory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link byte[]}{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "base64Binary")
    public JAXBElement<byte[]> createBase64Binary(byte[] value) {
        return new JAXBElement<byte[]>(_Base64Binary_QNAME, byte[].class, null, ((byte[]) value));
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Byte }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "byte")
    public JAXBElement<Byte> createByte(Byte value) {
        return new JAXBElement<Byte>(_Byte_QNAME, Byte.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthorisedSignatory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AuthorisedSignatory")
    public JAXBElement<AuthorisedSignatory> createAuthorisedSignatory(AuthorisedSignatory value) {
        return new JAXBElement<AuthorisedSignatory>(_AuthorisedSignatory_QNAME, AuthorisedSignatory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "boolean")
    public JAXBElement<Boolean> createBoolean(Boolean value) {
        return new JAXBElement<Boolean>(_Boolean_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAuthorisedSignatory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ArrayOfAuthorisedSignatory")
    public JAXBElement<ArrayOfAuthorisedSignatory> createArrayOfAuthorisedSignatory(ArrayOfAuthorisedSignatory value) {
        return new JAXBElement<ArrayOfAuthorisedSignatory>(_ArrayOfAuthorisedSignatory_QNAME, ArrayOfAuthorisedSignatory.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContactPerson }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ContactPerson")
    public JAXBElement<ContactPerson> createContactPerson(ContactPerson value) {
        return new JAXBElement<ContactPerson>(_ContactPerson_QNAME, ContactPerson.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Short }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedByte")
    public JAXBElement<Short> createUnsignedByte(Short value) {
        return new JAXBElement<Short>(_UnsignedByte_QNAME, Short.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "anyType")
    public JAXBElement<Object> createAnyType(Object value) {
        return new JAXBElement<Object>(_AnyType_QNAME, Object.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedInt")
    public JAXBElement<Long> createUnsignedInt(Long value) {
        return new JAXBElement<Long>(_UnsignedInt_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "int")
    public JAXBElement<Integer> createInt(Integer value) {
        return new JAXBElement<Integer>(_Int_QNAME, Integer.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimRegister }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ClaimRegister")
    public JAXBElement<ClaimRegister> createClaimRegister(ClaimRegister value) {
        return new JAXBElement<ClaimRegister>(_ClaimRegister_QNAME, ClaimRegister.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "decimal")
    public JAXBElement<BigDecimal> createDecimal(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_Decimal_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Double }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "double")
    public JAXBElement<Double> createDouble(Double value) {
        return new JAXBElement<Double>(_Double_QNAME, Double.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "guid")
    public JAXBElement<String> createGuid(String value) {
        return new JAXBElement<String>(_Guid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Duration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "duration")
    public JAXBElement<Duration> createDuration(Duration value) {
        return new JAXBElement<Duration>(_Duration_QNAME, Duration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "string")
    public JAXBElement<String> createString(String value) {
        return new JAXBElement<String>(_String_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://schemas.microsoft.com/2003/10/Serialization/", name = "unsignedLong")
    public JAXBElement<BigInteger> createUnsignedLong(BigInteger value) {
        return new JAXBElement<BigInteger>(_UnsignedLong_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ArrayOfBID")
    public JAXBElement<ArrayOfBID> createArrayOfBID(ArrayOfBID value) {
        return new JAXBElement<ArrayOfBID>(_ArrayOfBID_QNAME, ArrayOfBID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankAccountDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BankAccountDetails")
    public JAXBElement<BankAccountDetails> createBankAccountDetails(BankAccountDetails value) {
        return new JAXBElement<BankAccountDetails>(_BankAccountDetails_QNAME, BankAccountDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Addbeneficiary }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Addbeneficiary")
    public JAXBElement<Addbeneficiary> createAddbeneficiary(Addbeneficiary value) {
        return new JAXBElement<Addbeneficiary>(_Addbeneficiary_QNAME, Addbeneficiary.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PolicySnapshot }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PortalPolicySnapshotResult", scope = PortalPolicySnapshotResponse.class)
    public JAXBElement<PolicySnapshot> createPortalPolicySnapshotResponsePortalPolicySnapshotResult(PolicySnapshot value) {
        return new JAXBElement<PolicySnapshot>(_PortalPolicySnapshotResponsePortalPolicySnapshotResult_QNAME, PolicySnapshot.class, PortalPolicySnapshotResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "SQLERRMSG", scope = ContactPerson.class)
    public JAXBElement<String> createContactPersonSQLERRMSG(String value) {
        return new JAXBElement<String>(_ContactPersonSQLERRMSG_QNAME, String.class, ContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Response", scope = ContactPerson.class)
    public JAXBElement<String> createContactPersonResponse(String value) {
        return new JAXBElement<String>(_ContactPersonResponse_QNAME, String.class, ContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimRegister }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PortalClaimRegisterResult", scope = PortalClaimRegisterResponse.class)
    public JAXBElement<ClaimRegister> createPortalClaimRegisterResponsePortalClaimRegisterResult(ClaimRegister value) {
        return new JAXBElement<ClaimRegister>(_PortalClaimRegisterResponsePortalClaimRegisterResult_QNAME, ClaimRegister.class, PortalClaimRegisterResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "SQLERRMSG", scope = AuthorizedSignatory.class)
    public JAXBElement<String> createAuthorizedSignatorySQLERRMSG(String value) {
        return new JAXBElement<String>(_ContactPersonSQLERRMSG_QNAME, String.class, AuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Response", scope = AuthorizedSignatory.class)
    public JAXBElement<String> createAuthorizedSignatoryResponse(String value) {
        return new JAXBElement<String>(_ContactPersonResponse_QNAME, String.class, AuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthorizedSignatory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PortalAddAuthorizedSignatoryResult", scope = PortalAddAuthorizedSignatoryResponse.class)
    public JAXBElement<AuthorizedSignatory> createPortalAddAuthorizedSignatoryResponsePortalAddAuthorizedSignatoryResult(AuthorizedSignatory value) {
        return new JAXBElement<AuthorizedSignatory>(_PortalAddAuthorizedSignatoryResponsePortalAddAuthorizedSignatoryResult_QNAME, AuthorizedSignatory.class, PortalAddAuthorizedSignatoryResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BankAccountDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PortalBankAccountDetailsResult", scope = PortalBankAccountDetailsResponse.class)
    public JAXBElement<BankAccountDetails> createPortalBankAccountDetailsResponsePortalBankAccountDetailsResult(BankAccountDetails value) {
        return new JAXBElement<BankAccountDetails>(_PortalBankAccountDetailsResponsePortalBankAccountDetailsResult_QNAME, BankAccountDetails.class, PortalBankAccountDetailsResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "SQLERRMSG", scope = BankAccountDetails.class)
    public JAXBElement<String> createBankAccountDetailsSQLERRMSG(String value) {
        return new JAXBElement<String>(_ContactPersonSQLERRMSG_QNAME, String.class, BankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Response", scope = BankAccountDetails.class)
    public JAXBElement<String> createBankAccountDetailsResponse(String value) {
        return new JAXBElement<String>(_ContactPersonResponse_QNAME, String.class, BankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Number", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonNumber(String value) {
        return new JAXBElement<String>(_PortalContactPersonNumber_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "OtherDesignation", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonOtherDesignation(String value) {
        return new JAXBElement<String>(_PortalContactPersonOtherDesignation_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Location", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonLocation(String value) {
        return new JAXBElement<String>(_PortalContactPersonLocation_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UserId", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonUserId(String value) {
        return new JAXBElement<String>(_PortalContactPersonUserId_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "LastName", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonLastName(String value) {
        return new JAXBElement<String>(_PortalContactPersonLastName_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PhoneType", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonPhoneType(String value) {
        return new JAXBElement<String>(_PortalContactPersonPhoneType_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Title", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonTitle(String value) {
        return new JAXBElement<String>(_PortalContactPersonTitle_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Extension", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonExtension(String value) {
        return new JAXBElement<String>(_PortalContactPersonExtension_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AreaCode", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonAreaCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonAreaCode_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "MiddleName", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonMiddleName(String value) {
        return new JAXBElement<String>(_PortalContactPersonMiddleName_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UnitCode", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonUnitCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonUnitCode_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "FirstName", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonFirstName(String value) {
        return new JAXBElement<String>(_PortalContactPersonFirstName_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "CountryCode", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonCountryCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonCountryCode_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "EmailId", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonEmailId(String value) {
        return new JAXBElement<String>(_PortalContactPersonEmailId_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Designation", scope = PortalContactPerson.class)
    public JAXBElement<String> createPortalContactPersonDesignation(String value) {
        return new JAXBElement<String>(_PortalContactPersonDesignation_QNAME, String.class, PortalContactPerson.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Type", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryType(String value) {
        return new JAXBElement<String>(_PortalAddAuthorizedSignatoryType_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Number", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryNumber(String value) {
        return new JAXBElement<String>(_PortalContactPersonNumber_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UserId", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryUserId(String value) {
        return new JAXBElement<String>(_PortalContactPersonUserId_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "LastName", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryLastName(String value) {
        return new JAXBElement<String>(_PortalContactPersonLastName_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PhoneType", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryPhoneType(String value) {
        return new JAXBElement<String>(_PortalContactPersonPhoneType_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Title", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryTitle(String value) {
        return new JAXBElement<String>(_PortalContactPersonTitle_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Extension", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryExtension(String value) {
        return new JAXBElement<String>(_PortalContactPersonExtension_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AreaCode", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryAreaCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonAreaCode_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "MiddleName", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryMiddleName(String value) {
        return new JAXBElement<String>(_PortalContactPersonMiddleName_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UnitCode", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryUnitCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonUnitCode_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "FirstName", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryFirstName(String value) {
        return new JAXBElement<String>(_PortalContactPersonFirstName_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "CountryCode", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryCountryCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonCountryCode_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "EmailId", scope = PortalAddAuthorizedSignatory.class)
    public JAXBElement<String> createPortalAddAuthorizedSignatoryEmailId(String value) {
        return new JAXBElement<String>(_PortalContactPersonEmailId_QNAME, String.class, PortalAddAuthorizedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "SQLERRMSG", scope = ClaimRegister.class)
    public JAXBElement<String> createClaimRegisterSQLERRMSG(String value) {
        return new JAXBElement<String>(_ContactPersonSQLERRMSG_QNAME, String.class, ClaimRegister.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Response", scope = ClaimRegister.class)
    public JAXBElement<String> createClaimRegisterResponse(String value) {
        return new JAXBElement<String>(_ContactPersonResponse_QNAME, String.class, ClaimRegister.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "RequestId", scope = PortalPolicySnapshot.class)
    public JAXBElement<String> createPortalPolicySnapshotRequestId(String value) {
        return new JAXBElement<String>(_PortalPolicySnapshotRequestId_QNAME, String.class, PortalPolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UnitCode", scope = PortalPolicySnapshot.class)
    public JAXBElement<String> createPortalPolicySnapshotUnitCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonUnitCode_QNAME, String.class, PortalPolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PolicyKey", scope = PortalPolicySnapshot.class)
    public JAXBElement<BigDecimal> createPortalPolicySnapshotPolicyKey(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_PortalPolicySnapshotPolicyKey_QNAME, BigDecimal.class, PortalPolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UserId", scope = PortalPolicySnapshot.class)
    public JAXBElement<String> createPortalPolicySnapshotUserId(String value) {
        return new JAXBElement<String>(_PortalContactPersonUserId_QNAME, String.class, PortalPolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CompanyAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PortalCompanyAddressResult", scope = PortalCompanyAddressResponse.class)
    public JAXBElement<CompanyAddress> createPortalCompanyAddressResponsePortalCompanyAddressResult(CompanyAddress value) {
        return new JAXBElement<CompanyAddress>(_PortalCompanyAddressResponsePortalCompanyAddressResult_QNAME, CompanyAddress.class, PortalCompanyAddressResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Addbeneficiary }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PortalAddBeneficiaryResult", scope = PortalAddBeneficiaryResponse.class)
    public JAXBElement<Addbeneficiary> createPortalAddBeneficiaryResponsePortalAddBeneficiaryResult(Addbeneficiary value) {
        return new JAXBElement<Addbeneficiary>(_PortalAddBeneficiaryResponsePortalAddBeneficiaryResult_QNAME, Addbeneficiary.class, PortalAddBeneficiaryResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UnitName", scope = BID.class)
    public JAXBElement<String> createBIDUnitName(String value) {
        return new JAXBElement<String>(_BIDUnitName_QNAME, String.class, BID.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Balance", scope = BID.class)
    public JAXBElement<BigDecimal> createBIDBalance(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_BIDBalance_QNAME, BigDecimal.class, BID.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Pin", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressPin(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressPin_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "SameAs", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressSameAs(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressSameAs_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "State", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressState(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressState_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UnitCode", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressUnitCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonUnitCode_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AddressType", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressAddressType(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressAddressType_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UserId", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressUserId(String value) {
        return new JAXBElement<String>(_PortalContactPersonUserId_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Country", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressCountry(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressCountry_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AddressLine1", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressAddressLine1(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressAddressLine1_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "City", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressCity(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressCity_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AddressLine2", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressAddressLine2(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressAddressLine2_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AddressLine3", scope = PortalCompanyAddress.class)
    public JAXBElement<String> createPortalCompanyAddressAddressLine3(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressAddressLine3_QNAME, String.class, PortalCompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContactPerson }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PortalContactPersonResult", scope = PortalContactPersonResponse.class)
    public JAXBElement<ContactPerson> createPortalContactPersonResponsePortalContactPersonResult(ContactPerson value) {
        return new JAXBElement<ContactPerson>(_PortalContactPersonResponsePortalContactPersonResult_QNAME, ContactPerson.class, PortalContactPersonResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "MICRCode", scope = PortalBankAccountDetails.class)
    public JAXBElement<String> createPortalBankAccountDetailsMICRCode(String value) {
        return new JAXBElement<String>(_PortalBankAccountDetailsMICRCode_QNAME, String.class, PortalBankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UnitCode", scope = PortalBankAccountDetails.class)
    public JAXBElement<String> createPortalBankAccountDetailsUnitCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonUnitCode_QNAME, String.class, PortalBankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AccountNo", scope = PortalBankAccountDetails.class)
    public JAXBElement<String> createPortalBankAccountDetailsAccountNo(String value) {
        return new JAXBElement<String>(_PortalBankAccountDetailsAccountNo_QNAME, String.class, PortalBankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UserId", scope = PortalBankAccountDetails.class)
    public JAXBElement<String> createPortalBankAccountDetailsUserId(String value) {
        return new JAXBElement<String>(_PortalContactPersonUserId_QNAME, String.class, PortalBankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "IFSCCode", scope = PortalBankAccountDetails.class)
    public JAXBElement<String> createPortalBankAccountDetailsIFSCCode(String value) {
        return new JAXBElement<String>(_PortalBankAccountDetailsIFSCCode_QNAME, String.class, PortalBankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BankName", scope = PortalBankAccountDetails.class)
    public JAXBElement<String> createPortalBankAccountDetailsBankName(String value) {
        return new JAXBElement<String>(_PortalBankAccountDetailsBankName_QNAME, String.class, PortalBankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BankAddress1", scope = PortalBankAccountDetails.class)
    public JAXBElement<String> createPortalBankAccountDetailsBankAddress1(String value) {
        return new JAXBElement<String>(_PortalBankAccountDetailsBankAddress1_QNAME, String.class, PortalBankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BankAddress2", scope = PortalBankAccountDetails.class)
    public JAXBElement<String> createPortalBankAccountDetailsBankAddress2(String value) {
        return new JAXBElement<String>(_PortalBankAccountDetailsBankAddress2_QNAME, String.class, PortalBankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BankAddress3", scope = PortalBankAccountDetails.class)
    public JAXBElement<String> createPortalBankAccountDetailsBankAddress3(String value) {
        return new JAXBElement<String>(_PortalBankAccountDetailsBankAddress3_QNAME, String.class, PortalBankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PayableTo", scope = PortalBankAccountDetails.class)
    public JAXBElement<String> createPortalBankAccountDetailsPayableTo(String value) {
        return new JAXBElement<String>(_PortalBankAccountDetailsPayableTo_QNAME, String.class, PortalBankAccountDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBIDLine }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PortalBIDUnitwiseResult", scope = PortalBIDUnitwiseResponse.class)
    public JAXBElement<ArrayOfBIDLine> createPortalBIDUnitwiseResponsePortalBIDUnitwiseResult(ArrayOfBIDLine value) {
        return new JAXBElement<ArrayOfBIDLine>(_PortalBIDUnitwiseResponsePortalBIDUnitwiseResult_QNAME, ArrayOfBIDLine.class, PortalBIDUnitwiseResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AuthorisedSignatoryname", scope = AuthorisedSignatory.class)
    public JAXBElement<String> createAuthorisedSignatoryAuthorisedSignatoryname(String value) {
        return new JAXBElement<String>(_AuthorisedSignatoryAuthorisedSignatoryname_QNAME, String.class, AuthorisedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "MobileNo", scope = AuthorisedSignatory.class)
    public JAXBElement<BigDecimal> createAuthorisedSignatoryMobileNo(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_AuthorisedSignatoryMobileNo_QNAME, BigDecimal.class, AuthorisedSignatory.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "SQLERRMSG", scope = CompanyAddress.class)
    public JAXBElement<String> createCompanyAddressSQLERRMSG(String value) {
        return new JAXBElement<String>(_ContactPersonSQLERRMSG_QNAME, String.class, CompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Response", scope = CompanyAddress.class)
    public JAXBElement<String> createCompanyAddressResponse(String value) {
        return new JAXBElement<String>(_ContactPersonResponse_QNAME, String.class, CompanyAddress.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Pin", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryPin(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressPin_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "TypeOfPayment", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryTypeOfPayment(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryTypeOfPayment_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BankAddress", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryBankAddress(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryBankAddress_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BeneficiarySharePCT", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryBeneficiarySharePCT(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryBeneficiarySharePCT_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Remarks", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryRemarks(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryRemarks_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UserId", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryUserId(String value) {
        return new JAXBElement<String>(_PortalContactPersonUserId_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BeneficiaryRelation", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryBeneficiaryRelation(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryBeneficiaryRelation_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "IFSCCode", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryIFSCCode(String value) {
        return new JAXBElement<String>(_PortalBankAccountDetailsIFSCCode_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BankName", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryBankName(String value) {
        return new JAXBElement<String>(_PortalBankAccountDetailsBankName_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "City", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryCity(String value) {
        return new JAXBElement<String>(_PortalCompanyAddressCity_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "EmployeeID", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryEmployeeID(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryEmployeeID_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BankAccountNumber", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryBankAccountNumber(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryBankAccountNumber_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ClaimReferenceNo", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryClaimReferenceNo(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryClaimReferenceNo_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BeneficiaryName", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryBeneficiaryName(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryBeneficiaryName_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "RequestId", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryRequestId(String value) {
        return new JAXBElement<String>(_PortalPolicySnapshotRequestId_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UnitCode", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryUnitCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonUnitCode_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BeneficiaryAddress", scope = PortalAddBeneficiary.class)
    public JAXBElement<String> createPortalAddBeneficiaryBeneficiaryAddress(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryBeneficiaryAddress_QNAME, String.class, PortalAddBeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PolicyInceptionDt", scope = PolicySnapshot.class)
    public JAXBElement<String> createPolicySnapshotPolicyInceptionDt(String value) {
        return new JAXBElement<String>(_PolicySnapshotPolicyInceptionDt_QNAME, String.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "InforceMemberUnderPolicy", scope = PolicySnapshot.class)
    public JAXBElement<Integer> createPolicySnapshotInforceMemberUnderPolicy(Integer value) {
        return new JAXBElement<Integer>(_PolicySnapshotInforceMemberUnderPolicy_QNAME, Integer.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "CompanyAddress", scope = PolicySnapshot.class)
    public JAXBElement<String> createPolicySnapshotCompanyAddress(String value) {
        return new JAXBElement<String>(_CompanyAddress_QNAME, String.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "CompanyName", scope = PolicySnapshot.class)
    public JAXBElement<String> createPolicySnapshotCompanyName(String value) {
        return new JAXBElement<String>(_PolicySnapshotCompanyName_QNAME, String.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PolicyRenewalDt", scope = PolicySnapshot.class)
    public JAXBElement<String> createPolicySnapshotPolicyRenewalDt(String value) {
        return new JAXBElement<String>(_PolicySnapshotPolicyRenewalDt_QNAME, String.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PremiumMode", scope = PolicySnapshot.class)
    public JAXBElement<String> createPolicySnapshotPremiumMode(String value) {
        return new JAXBElement<String>(_PolicySnapshotPremiumMode_QNAME, String.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PolicyCommencementDt", scope = PolicySnapshot.class)
    public JAXBElement<String> createPolicySnapshotPolicyCommencementDt(String value) {
        return new JAXBElement<String>(_PolicySnapshotPolicyCommencementDt_QNAME, String.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BilledToDt", scope = PolicySnapshot.class)
    public JAXBElement<String> createPolicySnapshotBilledToDt(String value) {
        return new JAXBElement<String>(_PolicySnapshotBilledToDt_QNAME, String.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PaidToDt", scope = PolicySnapshot.class)
    public JAXBElement<String> createPolicySnapshotPaidToDt(String value) {
        return new JAXBElement<String>(_PolicySnapshotPaidToDt_QNAME, String.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAuthorisedSignatory }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "AuthorisedSignatory", scope = PolicySnapshot.class)
    public JAXBElement<ArrayOfAuthorisedSignatory> createPolicySnapshotAuthorisedSignatory(ArrayOfAuthorisedSignatory value) {
        return new JAXBElement<ArrayOfAuthorisedSignatory>(_AuthorisedSignatory_QNAME, ArrayOfAuthorisedSignatory.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "BidAsOnDate", scope = PolicySnapshot.class)
    public JAXBElement<ArrayOfBID> createPolicySnapshotBidAsOnDate(ArrayOfBID value) {
        return new JAXBElement<ArrayOfBID>(_PolicySnapshotBidAsOnDate_QNAME, ArrayOfBID.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "MstPolicyNo", scope = PolicySnapshot.class)
    public JAXBElement<String> createPolicySnapshotMstPolicyNo(String value) {
        return new JAXBElement<String>(_PolicySnapshotMstPolicyNo_QNAME, String.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "PolicyType", scope = PolicySnapshot.class)
    public JAXBElement<String> createPolicySnapshotPolicyType(String value) {
        return new JAXBElement<String>(_PolicySnapshotPolicyType_QNAME, String.class, PolicySnapshot.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "SQLERRMSG", scope = Addbeneficiary.class)
    public JAXBElement<String> createAddbeneficiarySQLERRMSG(String value) {
        return new JAXBElement<String>(_ContactPersonSQLERRMSG_QNAME, String.class, Addbeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Response", scope = Addbeneficiary.class)
    public JAXBElement<String> createAddbeneficiaryResponse(String value) {
        return new JAXBElement<String>(_ContactPersonResponse_QNAME, String.class, Addbeneficiary.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "EmployeeID", scope = PortalClaimRegister.class)
    public JAXBElement<String> createPortalClaimRegisterEmployeeID(String value) {
        return new JAXBElement<String>(_PortalAddBeneficiaryEmployeeID_QNAME, String.class, PortalClaimRegister.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ClaimCauseCode", scope = PortalClaimRegister.class)
    public JAXBElement<String> createPortalClaimRegisterClaimCauseCode(String value) {
        return new JAXBElement<String>(_PortalClaimRegisterClaimCauseCode_QNAME, String.class, PortalClaimRegister.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ClaimTypeCode", scope = PortalClaimRegister.class)
    public JAXBElement<String> createPortalClaimRegisterClaimTypeCode(String value) {
        return new JAXBElement<String>(_PortalClaimRegisterClaimTypeCode_QNAME, String.class, PortalClaimRegister.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "RequestId", scope = PortalClaimRegister.class)
    public JAXBElement<String> createPortalClaimRegisterRequestId(String value) {
        return new JAXBElement<String>(_PortalPolicySnapshotRequestId_QNAME, String.class, PortalClaimRegister.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UnitCode", scope = PortalClaimRegister.class)
    public JAXBElement<String> createPortalClaimRegisterUnitCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonUnitCode_QNAME, String.class, PortalClaimRegister.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "RiderCode", scope = PortalClaimRegister.class)
    public JAXBElement<String> createPortalClaimRegisterRiderCode(String value) {
        return new JAXBElement<String>(_PortalClaimRegisterRiderCode_QNAME, String.class, PortalClaimRegister.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UserId", scope = PortalClaimRegister.class)
    public JAXBElement<String> createPortalClaimRegisterUserId(String value) {
        return new JAXBElement<String>(_PortalContactPersonUserId_QNAME, String.class, PortalClaimRegister.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "EmployeeName", scope = PortalClaimRegister.class)
    public JAXBElement<String> createPortalClaimRegisterEmployeeName(String value) {
        return new JAXBElement<String>(_PortalClaimRegisterEmployeeName_QNAME, String.class, PortalClaimRegister.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "RequestId", scope = PortalBIDUnitwise.class)
    public JAXBElement<String> createPortalBIDUnitwiseRequestId(String value) {
        return new JAXBElement<String>(_PortalPolicySnapshotRequestId_QNAME, String.class, PortalBIDUnitwise.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UnitCode", scope = PortalBIDUnitwise.class)
    public JAXBElement<String> createPortalBIDUnitwiseUnitCode(String value) {
        return new JAXBElement<String>(_PortalContactPersonUnitCode_QNAME, String.class, PortalBIDUnitwise.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "UserID", scope = PortalBIDUnitwise.class)
    public JAXBElement<String> createPortalBIDUnitwiseUserID(String value) {
        return new JAXBElement<String>(_PortalBIDUnitwiseUserID_QNAME, String.class, PortalBIDUnitwise.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Amount_Dr", scope = BIDLine.class)
    public JAXBElement<BigDecimal> createBIDLineAmountDr(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_BIDLineAmountDr_QNAME, BigDecimal.class, BIDLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "ModeOfPayment", scope = BIDLine.class)
    public JAXBElement<String> createBIDLineModeOfPayment(String value) {
        return new JAXBElement<String>(_BIDLineModeOfPayment_QNAME, String.class, BIDLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Amount_Cr", scope = BIDLine.class)
    public JAXBElement<BigDecimal> createBIDLineAmountCr(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_BIDLineAmountCr_QNAME, BigDecimal.class, BIDLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Date", scope = BIDLine.class)
    public JAXBElement<String> createBIDLineDate(String value) {
        return new JAXBElement<String>(_BIDLineDate_QNAME, String.class, BIDLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Particulars", scope = BIDLine.class)
    public JAXBElement<String> createBIDLineParticulars(String value) {
        return new JAXBElement<String>(_BIDLineParticulars_QNAME, String.class, BIDLine.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "Balance", scope = BIDLine.class)
    public JAXBElement<BigDecimal> createBIDLineBalance(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_BIDBalance_QNAME, BigDecimal.class, BIDLine.class, value);
    }

}
