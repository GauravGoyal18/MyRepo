
package com.ipru.estatement.bid.generated;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BIDLine complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BIDLine">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Amount_Cr" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Amount_Dr" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Balance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ModeOfPayment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Particulars" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BIDLine", propOrder = {
    "amountCr",
    "amountDr",
    "balance",
    "date",
    "modeOfPayment",
    "particulars"
})
public class BIDLine {

    @XmlElementRef(name = "Amount_Cr", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> amountCr;
    @XmlElementRef(name = "Amount_Dr", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> amountDr;
    @XmlElementRef(name = "Balance", type = JAXBElement.class)
    protected JAXBElement<BigDecimal> balance;
    @XmlElementRef(name = "Date", type = JAXBElement.class)
    protected JAXBElement<String> date;
    @XmlElementRef(name = "ModeOfPayment", type = JAXBElement.class)
    protected JAXBElement<String> modeOfPayment;
    @XmlElementRef(name = "Particulars", type = JAXBElement.class)
    protected JAXBElement<String> particulars;

    /**
     * Gets the value of the amountCr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getAmountCr() {
        return amountCr;
    }

    /**
     * Sets the value of the amountCr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setAmountCr(JAXBElement<BigDecimal> value) {
        this.amountCr = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the amountDr property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getAmountDr() {
        return amountDr;
    }

    /**
     * Sets the value of the amountDr property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setAmountDr(JAXBElement<BigDecimal> value) {
        this.amountDr = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the balance property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public JAXBElement<BigDecimal> getBalance() {
        return balance;
    }

    /**
     * Sets the value of the balance property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     *     
     */
    public void setBalance(JAXBElement<BigDecimal> value) {
        this.balance = ((JAXBElement<BigDecimal> ) value);
    }

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDate(JAXBElement<String> value) {
        this.date = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the modeOfPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getModeOfPayment() {
        return modeOfPayment;
    }

    /**
     * Sets the value of the modeOfPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setModeOfPayment(JAXBElement<String> value) {
        this.modeOfPayment = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the particulars property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getParticulars() {
        return particulars;
    }

    /**
     * Sets the value of the particulars property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setParticulars(JAXBElement<String> value) {
        this.particulars = ((JAXBElement<String> ) value);
    }

	@Override
	public String toString() {
		return "BIDLine [amountCr=" + amountCr + ", amountDr=" + amountDr
				+ ", balance=" + balance + ", date=" + date
				+ ", modeOfPayment=" + modeOfPayment + ", particulars="
				+ particulars + "]";
	}

}
