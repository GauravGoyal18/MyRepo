
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DetailCorrection complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailCorrection">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="ChangesToBeDone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OldValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NewValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastUpdateDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="UnderWriting" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AvailableInOmnidocs" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PolicyCollectedDefacedAtBranch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DifferenceAppFormPolicyCertificate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailCorrection", propOrder = {
    "isChanged",
    "interactionId",
    "changesToBeDone",
    "oldValue",
    "newValue",
    "lastUpdateDate",
    "underWriting",
    "availableInOmnidocs",
    "policyCollectedDefacedAtBranch",
    "differenceAppFormPolicyCertificate",
    "isUpdated"
})
public class DetailCorrection {

    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionId")
    protected long interactionId;
    @XmlElement(name = "ChangesToBeDone")
    protected String changesToBeDone;
    @XmlElement(name = "OldValue")
    protected String oldValue;
    @XmlElement(name = "NewValue")
    protected String newValue;
    @XmlElement(name = "LastUpdateDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastUpdateDate;
    @XmlElement(name = "UnderWriting")
    protected String underWriting;
    @XmlElement(name = "AvailableInOmnidocs")
    protected String availableInOmnidocs;
    @XmlElement(name = "PolicyCollectedDefacedAtBranch")
    protected String policyCollectedDefacedAtBranch;
    @XmlElement(name = "DifferenceAppFormPolicyCertificate")
    protected String differenceAppFormPolicyCertificate;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionId property.
     * 
     */
    public long getInteractionId() {
        return interactionId;
    }

    /**
     * Sets the value of the interactionId property.
     * 
     */
    public void setInteractionId(long value) {
        this.interactionId = value;
    }

    /**
     * Gets the value of the changesToBeDone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChangesToBeDone() {
        return changesToBeDone;
    }

    /**
     * Sets the value of the changesToBeDone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChangesToBeDone(String value) {
        this.changesToBeDone = value;
    }

    /**
     * Gets the value of the oldValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldValue() {
        return oldValue;
    }

    /**
     * Sets the value of the oldValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldValue(String value) {
        this.oldValue = value;
    }

    /**
     * Gets the value of the newValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewValue() {
        return newValue;
    }

    /**
     * Sets the value of the newValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewValue(String value) {
        this.newValue = value;
    }

    /**
     * Gets the value of the lastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * Sets the value of the lastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdateDate(XMLGregorianCalendar value) {
        this.lastUpdateDate = value;
    }

    /**
     * Gets the value of the underWriting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnderWriting() {
        return underWriting;
    }

    /**
     * Sets the value of the underWriting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnderWriting(String value) {
        this.underWriting = value;
    }

    /**
     * Gets the value of the availableInOmnidocs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvailableInOmnidocs() {
        return availableInOmnidocs;
    }

    /**
     * Sets the value of the availableInOmnidocs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvailableInOmnidocs(String value) {
        this.availableInOmnidocs = value;
    }

    /**
     * Gets the value of the policyCollectedDefacedAtBranch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyCollectedDefacedAtBranch() {
        return policyCollectedDefacedAtBranch;
    }

    /**
     * Sets the value of the policyCollectedDefacedAtBranch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyCollectedDefacedAtBranch(String value) {
        this.policyCollectedDefacedAtBranch = value;
    }

    /**
     * Gets the value of the differenceAppFormPolicyCertificate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDifferenceAppFormPolicyCertificate() {
        return differenceAppFormPolicyCertificate;
    }

    /**
     * Sets the value of the differenceAppFormPolicyCertificate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDifferenceAppFormPolicyCertificate(String value) {
        this.differenceAppFormPolicyCertificate = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

}
