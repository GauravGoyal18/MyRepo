
package com.ipru.spaarc.generated;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Detail_S2TReinstatement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Detail_S2TReinstatement">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsSearch" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="SubDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Decision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RegularMedicals" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReceiptNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LASignature" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="AdversoryPDR" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="HtCms" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="HtFt" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="HtInch" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="Wt" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="Age" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="TobaccoType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TobaccoQty" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="TobaccoDuration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AlcoholType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AlcoholQty" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="AlcoholDuration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Narcotic" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Change_In_ResiStatus" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Change_In_Avocation" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Detail_S2TReinstatement", propOrder = {
    "isSearch",
    "interactionID",
    "subDecision",
    "decision",
    "regularMedicals",
    "receiptNo",
    "laSignature",
    "adversoryPDR",
    "htCms",
    "htFt",
    "htInch",
    "wt",
    "age",
    "tobaccoType",
    "tobaccoQty",
    "tobaccoDuration",
    "alcoholType",
    "alcoholQty",
    "alcoholDuration",
    "narcotic",
    "changeInResiStatus",
    "changeInAvocation",
    "isUpdated"
})
public class DetailS2TReinstatement {

    @XmlElement(name = "IsSearch")
    protected boolean isSearch;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "SubDecision")
    protected String subDecision;
    @XmlElement(name = "Decision")
    protected String decision;
    @XmlElement(name = "RegularMedicals")
    protected String regularMedicals;
    @XmlElement(name = "ReceiptNo")
    protected String receiptNo;
    @XmlElement(name = "LASignature")
    protected boolean laSignature;
    @XmlElement(name = "AdversoryPDR")
    protected boolean adversoryPDR;
    @XmlElement(name = "HtCms", required = true)
    protected BigDecimal htCms;
    @XmlElement(name = "HtFt", required = true)
    protected BigDecimal htFt;
    @XmlElement(name = "HtInch", required = true)
    protected BigDecimal htInch;
    @XmlElement(name = "Wt", required = true)
    protected BigDecimal wt;
    @XmlElement(name = "Age", required = true)
    protected BigDecimal age;
    @XmlElement(name = "TobaccoType")
    protected String tobaccoType;
    @XmlElement(name = "TobaccoQty")
    protected int tobaccoQty;
    @XmlElement(name = "TobaccoDuration")
    protected String tobaccoDuration;
    @XmlElement(name = "AlcoholType")
    protected String alcoholType;
    @XmlElement(name = "AlcoholQty")
    protected int alcoholQty;
    @XmlElement(name = "AlcoholDuration")
    protected String alcoholDuration;
    @XmlElement(name = "Narcotic")
    protected boolean narcotic;
    @XmlElement(name = "Change_In_ResiStatus")
    protected boolean changeInResiStatus;
    @XmlElement(name = "Change_In_Avocation")
    protected boolean changeInAvocation;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;

    /**
     * Gets the value of the isSearch property.
     * 
     */
    public boolean isIsSearch() {
        return isSearch;
    }

    /**
     * Sets the value of the isSearch property.
     * 
     */
    public void setIsSearch(boolean value) {
        this.isSearch = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the subDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubDecision() {
        return subDecision;
    }

    /**
     * Sets the value of the subDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubDecision(String value) {
        this.subDecision = value;
    }

    /**
     * Gets the value of the decision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecision() {
        return decision;
    }

    /**
     * Sets the value of the decision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecision(String value) {
        this.decision = value;
    }

    /**
     * Gets the value of the regularMedicals property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegularMedicals() {
        return regularMedicals;
    }

    /**
     * Sets the value of the regularMedicals property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegularMedicals(String value) {
        this.regularMedicals = value;
    }

    /**
     * Gets the value of the receiptNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptNo() {
        return receiptNo;
    }

    /**
     * Sets the value of the receiptNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptNo(String value) {
        this.receiptNo = value;
    }

    /**
     * Gets the value of the laSignature property.
     * 
     */
    public boolean isLASignature() {
        return laSignature;
    }

    /**
     * Sets the value of the laSignature property.
     * 
     */
    public void setLASignature(boolean value) {
        this.laSignature = value;
    }

    /**
     * Gets the value of the adversoryPDR property.
     * 
     */
    public boolean isAdversoryPDR() {
        return adversoryPDR;
    }

    /**
     * Sets the value of the adversoryPDR property.
     * 
     */
    public void setAdversoryPDR(boolean value) {
        this.adversoryPDR = value;
    }

    /**
     * Gets the value of the htCms property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHtCms() {
        return htCms;
    }

    /**
     * Sets the value of the htCms property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHtCms(BigDecimal value) {
        this.htCms = value;
    }

    /**
     * Gets the value of the htFt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHtFt() {
        return htFt;
    }

    /**
     * Sets the value of the htFt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHtFt(BigDecimal value) {
        this.htFt = value;
    }

    /**
     * Gets the value of the htInch property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHtInch() {
        return htInch;
    }

    /**
     * Sets the value of the htInch property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHtInch(BigDecimal value) {
        this.htInch = value;
    }

    /**
     * Gets the value of the wt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getWt() {
        return wt;
    }

    /**
     * Sets the value of the wt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setWt(BigDecimal value) {
        this.wt = value;
    }

    /**
     * Gets the value of the age property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAge() {
        return age;
    }

    /**
     * Sets the value of the age property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAge(BigDecimal value) {
        this.age = value;
    }

    /**
     * Gets the value of the tobaccoType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTobaccoType() {
        return tobaccoType;
    }

    /**
     * Sets the value of the tobaccoType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTobaccoType(String value) {
        this.tobaccoType = value;
    }

    /**
     * Gets the value of the tobaccoQty property.
     * 
     */
    public int getTobaccoQty() {
        return tobaccoQty;
    }

    /**
     * Sets the value of the tobaccoQty property.
     * 
     */
    public void setTobaccoQty(int value) {
        this.tobaccoQty = value;
    }

    /**
     * Gets the value of the tobaccoDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTobaccoDuration() {
        return tobaccoDuration;
    }

    /**
     * Sets the value of the tobaccoDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTobaccoDuration(String value) {
        this.tobaccoDuration = value;
    }

    /**
     * Gets the value of the alcoholType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlcoholType() {
        return alcoholType;
    }

    /**
     * Sets the value of the alcoholType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlcoholType(String value) {
        this.alcoholType = value;
    }

    /**
     * Gets the value of the alcoholQty property.
     * 
     */
    public int getAlcoholQty() {
        return alcoholQty;
    }

    /**
     * Sets the value of the alcoholQty property.
     * 
     */
    public void setAlcoholQty(int value) {
        this.alcoholQty = value;
    }

    /**
     * Gets the value of the alcoholDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlcoholDuration() {
        return alcoholDuration;
    }

    /**
     * Sets the value of the alcoholDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlcoholDuration(String value) {
        this.alcoholDuration = value;
    }

    /**
     * Gets the value of the narcotic property.
     * 
     */
    public boolean isNarcotic() {
        return narcotic;
    }

    /**
     * Sets the value of the narcotic property.
     * 
     */
    public void setNarcotic(boolean value) {
        this.narcotic = value;
    }

    /**
     * Gets the value of the changeInResiStatus property.
     * 
     */
    public boolean isChangeInResiStatus() {
        return changeInResiStatus;
    }

    /**
     * Sets the value of the changeInResiStatus property.
     * 
     */
    public void setChangeInResiStatus(boolean value) {
        this.changeInResiStatus = value;
    }

    /**
     * Gets the value of the changeInAvocation property.
     * 
     */
    public boolean isChangeInAvocation() {
        return changeInAvocation;
    }

    /**
     * Sets the value of the changeInAvocation property.
     * 
     */
    public void setChangeInAvocation(boolean value) {
        this.changeInAvocation = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

}
