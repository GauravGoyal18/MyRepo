
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DetailFraudRCA complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailFraudRCA">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="StrFraudCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StrGovrnActionAgainst" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PLVCPIVCWC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Govn_CallCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Govn_CallType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Govn_SubType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="FraudProved" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Decision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Decision_Text" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ChannelInvolved" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Others" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesIntimation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RiskIntimation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ActionTakenByRisk" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InterestOffered" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountHit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExceptionReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="KeyLearnings" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MissellingHistory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustomerConcern" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HitCOPQ" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdvisorActive" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ActionTaken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Remarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OtherPersonInvolved" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FakeNumbers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PLVCPIVCFindings" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SysDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SysDeviation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonForFinalDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateOfIncident" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailFraudRCA", propOrder = {
    "strFraudCategory",
    "strGovrnActionAgainst",
    "plvcpivcwc",
    "govnCallCategory",
    "govnCallType",
    "govnSubType",
    "interactionID",
    "fraudProved",
    "decision",
    "decisionText",
    "isUpdated",
    "channelInvolved",
    "others",
    "salesIntimation",
    "riskIntimation",
    "actionTakenByRisk",
    "interestOffered",
    "accountHit",
    "exceptionReason",
    "keyLearnings",
    "missellingHistory",
    "customerConcern",
    "hitCOPQ",
    "advisorActive",
    "actionTaken",
    "remarks",
    "otherPersonInvolved",
    "fakeNumbers",
    "plvcpivcFindings",
    "sysDecision",
    "sysDeviation",
    "reasonForFinalDecision",
    "dateOfIncident"
})
public class DetailFraudRCA {

    @XmlElement(name = "StrFraudCategory")
    protected String strFraudCategory;
    @XmlElement(name = "StrGovrnActionAgainst")
    protected String strGovrnActionAgainst;
    @XmlElement(name = "PLVCPIVCWC")
    protected String plvcpivcwc;
    @XmlElement(name = "Govn_CallCategory")
    protected String govnCallCategory;
    @XmlElement(name = "Govn_CallType")
    protected String govnCallType;
    @XmlElement(name = "Govn_SubType")
    protected String govnSubType;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "FraudProved")
    protected String fraudProved;
    @XmlElement(name = "Decision")
    protected String decision;
    @XmlElement(name = "Decision_Text")
    protected String decisionText;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "ChannelInvolved")
    protected String channelInvolved;
    @XmlElement(name = "Others")
    protected String others;
    @XmlElement(name = "SalesIntimation")
    protected String salesIntimation;
    @XmlElement(name = "RiskIntimation")
    protected String riskIntimation;
    @XmlElement(name = "ActionTakenByRisk")
    protected String actionTakenByRisk;
    @XmlElement(name = "InterestOffered")
    protected String interestOffered;
    @XmlElement(name = "AccountHit")
    protected String accountHit;
    @XmlElement(name = "ExceptionReason")
    protected String exceptionReason;
    @XmlElement(name = "KeyLearnings")
    protected String keyLearnings;
    @XmlElement(name = "MissellingHistory")
    protected String missellingHistory;
    @XmlElement(name = "CustomerConcern")
    protected String customerConcern;
    @XmlElement(name = "HitCOPQ")
    protected String hitCOPQ;
    @XmlElement(name = "AdvisorActive")
    protected String advisorActive;
    @XmlElement(name = "ActionTaken")
    protected String actionTaken;
    @XmlElement(name = "Remarks")
    protected String remarks;
    @XmlElement(name = "OtherPersonInvolved")
    protected String otherPersonInvolved;
    @XmlElement(name = "FakeNumbers")
    protected String fakeNumbers;
    @XmlElement(name = "PLVCPIVCFindings")
    protected String plvcpivcFindings;
    @XmlElement(name = "SysDecision")
    protected String sysDecision;
    @XmlElement(name = "SysDeviation")
    protected String sysDeviation;
    @XmlElement(name = "ReasonForFinalDecision")
    protected String reasonForFinalDecision;
    @XmlElement(name = "DateOfIncident")
    protected String dateOfIncident;

    /**
     * Gets the value of the strFraudCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrFraudCategory() {
        return strFraudCategory;
    }

    /**
     * Sets the value of the strFraudCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrFraudCategory(String value) {
        this.strFraudCategory = value;
    }

    /**
     * Gets the value of the strGovrnActionAgainst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrGovrnActionAgainst() {
        return strGovrnActionAgainst;
    }

    /**
     * Sets the value of the strGovrnActionAgainst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrGovrnActionAgainst(String value) {
        this.strGovrnActionAgainst = value;
    }

    /**
     * Gets the value of the plvcpivcwc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLVCPIVCWC() {
        return plvcpivcwc;
    }

    /**
     * Sets the value of the plvcpivcwc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLVCPIVCWC(String value) {
        this.plvcpivcwc = value;
    }

    /**
     * Gets the value of the govnCallCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGovnCallCategory() {
        return govnCallCategory;
    }

    /**
     * Sets the value of the govnCallCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGovnCallCategory(String value) {
        this.govnCallCategory = value;
    }

    /**
     * Gets the value of the govnCallType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGovnCallType() {
        return govnCallType;
    }

    /**
     * Sets the value of the govnCallType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGovnCallType(String value) {
        this.govnCallType = value;
    }

    /**
     * Gets the value of the govnSubType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGovnSubType() {
        return govnSubType;
    }

    /**
     * Sets the value of the govnSubType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGovnSubType(String value) {
        this.govnSubType = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the fraudProved property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFraudProved() {
        return fraudProved;
    }

    /**
     * Sets the value of the fraudProved property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFraudProved(String value) {
        this.fraudProved = value;
    }

    /**
     * Gets the value of the decision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecision() {
        return decision;
    }

    /**
     * Sets the value of the decision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecision(String value) {
        this.decision = value;
    }

    /**
     * Gets the value of the decisionText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionText() {
        return decisionText;
    }

    /**
     * Sets the value of the decisionText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionText(String value) {
        this.decisionText = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the channelInvolved property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelInvolved() {
        return channelInvolved;
    }

    /**
     * Sets the value of the channelInvolved property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelInvolved(String value) {
        this.channelInvolved = value;
    }

    /**
     * Gets the value of the others property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthers() {
        return others;
    }

    /**
     * Sets the value of the others property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthers(String value) {
        this.others = value;
    }

    /**
     * Gets the value of the salesIntimation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesIntimation() {
        return salesIntimation;
    }

    /**
     * Sets the value of the salesIntimation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesIntimation(String value) {
        this.salesIntimation = value;
    }

    /**
     * Gets the value of the riskIntimation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRiskIntimation() {
        return riskIntimation;
    }

    /**
     * Sets the value of the riskIntimation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRiskIntimation(String value) {
        this.riskIntimation = value;
    }

    /**
     * Gets the value of the actionTakenByRisk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionTakenByRisk() {
        return actionTakenByRisk;
    }

    /**
     * Sets the value of the actionTakenByRisk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionTakenByRisk(String value) {
        this.actionTakenByRisk = value;
    }

    /**
     * Gets the value of the interestOffered property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterestOffered() {
        return interestOffered;
    }

    /**
     * Sets the value of the interestOffered property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterestOffered(String value) {
        this.interestOffered = value;
    }

    /**
     * Gets the value of the accountHit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountHit() {
        return accountHit;
    }

    /**
     * Sets the value of the accountHit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountHit(String value) {
        this.accountHit = value;
    }

    /**
     * Gets the value of the exceptionReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionReason() {
        return exceptionReason;
    }

    /**
     * Sets the value of the exceptionReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionReason(String value) {
        this.exceptionReason = value;
    }

    /**
     * Gets the value of the keyLearnings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKeyLearnings() {
        return keyLearnings;
    }

    /**
     * Sets the value of the keyLearnings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKeyLearnings(String value) {
        this.keyLearnings = value;
    }

    /**
     * Gets the value of the missellingHistory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMissellingHistory() {
        return missellingHistory;
    }

    /**
     * Sets the value of the missellingHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMissellingHistory(String value) {
        this.missellingHistory = value;
    }

    /**
     * Gets the value of the customerConcern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerConcern() {
        return customerConcern;
    }

    /**
     * Sets the value of the customerConcern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerConcern(String value) {
        this.customerConcern = value;
    }

    /**
     * Gets the value of the hitCOPQ property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHitCOPQ() {
        return hitCOPQ;
    }

    /**
     * Sets the value of the hitCOPQ property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHitCOPQ(String value) {
        this.hitCOPQ = value;
    }

    /**
     * Gets the value of the advisorActive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdvisorActive() {
        return advisorActive;
    }

    /**
     * Sets the value of the advisorActive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdvisorActive(String value) {
        this.advisorActive = value;
    }

    /**
     * Gets the value of the actionTaken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionTaken() {
        return actionTaken;
    }

    /**
     * Sets the value of the actionTaken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionTaken(String value) {
        this.actionTaken = value;
    }

    /**
     * Gets the value of the remarks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * Sets the value of the remarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemarks(String value) {
        this.remarks = value;
    }

    /**
     * Gets the value of the otherPersonInvolved property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherPersonInvolved() {
        return otherPersonInvolved;
    }

    /**
     * Sets the value of the otherPersonInvolved property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherPersonInvolved(String value) {
        this.otherPersonInvolved = value;
    }

    /**
     * Gets the value of the fakeNumbers property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFakeNumbers() {
        return fakeNumbers;
    }

    /**
     * Sets the value of the fakeNumbers property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFakeNumbers(String value) {
        this.fakeNumbers = value;
    }

    /**
     * Gets the value of the plvcpivcFindings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLVCPIVCFindings() {
        return plvcpivcFindings;
    }

    /**
     * Sets the value of the plvcpivcFindings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLVCPIVCFindings(String value) {
        this.plvcpivcFindings = value;
    }

    /**
     * Gets the value of the sysDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSysDecision() {
        return sysDecision;
    }

    /**
     * Sets the value of the sysDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSysDecision(String value) {
        this.sysDecision = value;
    }

    /**
     * Gets the value of the sysDeviation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSysDeviation() {
        return sysDeviation;
    }

    /**
     * Sets the value of the sysDeviation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSysDeviation(String value) {
        this.sysDeviation = value;
    }

    /**
     * Gets the value of the reasonForFinalDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonForFinalDecision() {
        return reasonForFinalDecision;
    }

    /**
     * Sets the value of the reasonForFinalDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonForFinalDecision(String value) {
        this.reasonForFinalDecision = value;
    }

    /**
     * Gets the value of the dateOfIncident property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateOfIncident() {
        return dateOfIncident;
    }

    /**
     * Sets the value of the dateOfIncident property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateOfIncident(String value) {
        this.dateOfIncident = value;
    }

}
