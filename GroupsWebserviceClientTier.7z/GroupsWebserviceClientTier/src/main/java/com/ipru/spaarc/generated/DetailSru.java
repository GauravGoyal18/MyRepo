
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DetailSru complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailSru">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DateOfComplaint" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IRDATicketNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfFailureRCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EscalationTypeRCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EscalationType1RCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EscalationType2RCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ErringDepatmentsType0RCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ErringDepatmentsType1RCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ErringDepatmentsType2RCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonForFailureRCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RepeatReasonRCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LasttouchpoinRCA1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LasttouchpoinRCA2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LasttouchpoinRCA3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TouchPointResolutionRCA1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TouchPointResolutionRCA2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TouchPointResolutionRCA3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonForDecChangeRCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonofEscalationRCA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsfeedbackGivenRCA" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsChangeDecision" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsEarlierCustomer" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsUpdateRequired" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="TypeOfFailure" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EscalationType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RootCause" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Contributor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DepttContributor1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="KeyLearning1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonForEscalation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastTouchPoint" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TouchPointResolution" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Escalation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RepeatReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SeniorManagementUpdateRequiredArray" type="{http://generated.spaarc.ipru.com/}ArrayOfAnyType" minOccurs="0"/>
 *         &lt;element name="DepttContributor2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="KeyLearning2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailSru", propOrder = {
    "dateOfComplaint",
    "irdaTicketNo",
    "typeOfFailureRCA",
    "escalationTypeRCA",
    "escalationType1RCA",
    "escalationType2RCA",
    "erringDepatmentsType0RCA",
    "erringDepatmentsType1RCA",
    "erringDepatmentsType2RCA",
    "reasonForFailureRCA",
    "repeatReasonRCA",
    "lasttouchpoinRCA1",
    "lasttouchpoinRCA2",
    "lasttouchpoinRCA3",
    "touchPointResolutionRCA1",
    "touchPointResolutionRCA2",
    "touchPointResolutionRCA3",
    "reasonForDecChangeRCA",
    "reasonofEscalationRCA",
    "isfeedbackGivenRCA",
    "isChangeDecision",
    "isEarlierCustomer",
    "isChanged",
    "isUpdateRequired",
    "interactionID",
    "isUpdated",
    "typeOfFailure",
    "escalationType",
    "rootCause",
    "contributor",
    "depttContributor1",
    "keyLearning1",
    "reasonForEscalation",
    "lastTouchPoint",
    "touchPointResolution",
    "escalation",
    "repeatReason",
    "seniorManagementUpdateRequiredArray",
    "depttContributor2",
    "keyLearning2"
})
public class DetailSru {

    @XmlElement(name = "DateOfComplaint", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateOfComplaint;
    @XmlElement(name = "IRDATicketNo")
    protected String irdaTicketNo;
    @XmlElement(name = "TypeOfFailureRCA")
    protected String typeOfFailureRCA;
    @XmlElement(name = "EscalationTypeRCA")
    protected String escalationTypeRCA;
    @XmlElement(name = "EscalationType1RCA")
    protected String escalationType1RCA;
    @XmlElement(name = "EscalationType2RCA")
    protected String escalationType2RCA;
    @XmlElement(name = "ErringDepatmentsType0RCA")
    protected String erringDepatmentsType0RCA;
    @XmlElement(name = "ErringDepatmentsType1RCA")
    protected String erringDepatmentsType1RCA;
    @XmlElement(name = "ErringDepatmentsType2RCA")
    protected String erringDepatmentsType2RCA;
    @XmlElement(name = "ReasonForFailureRCA")
    protected String reasonForFailureRCA;
    @XmlElement(name = "RepeatReasonRCA")
    protected String repeatReasonRCA;
    @XmlElement(name = "LasttouchpoinRCA1")
    protected String lasttouchpoinRCA1;
    @XmlElement(name = "LasttouchpoinRCA2")
    protected String lasttouchpoinRCA2;
    @XmlElement(name = "LasttouchpoinRCA3")
    protected String lasttouchpoinRCA3;
    @XmlElement(name = "TouchPointResolutionRCA1")
    protected String touchPointResolutionRCA1;
    @XmlElement(name = "TouchPointResolutionRCA2")
    protected String touchPointResolutionRCA2;
    @XmlElement(name = "TouchPointResolutionRCA3")
    protected String touchPointResolutionRCA3;
    @XmlElement(name = "ReasonForDecChangeRCA")
    protected String reasonForDecChangeRCA;
    @XmlElement(name = "ReasonofEscalationRCA")
    protected String reasonofEscalationRCA;
    @XmlElement(name = "IsfeedbackGivenRCA")
    protected boolean isfeedbackGivenRCA;
    @XmlElement(name = "IsChangeDecision")
    protected boolean isChangeDecision;
    @XmlElement(name = "IsEarlierCustomer")
    protected boolean isEarlierCustomer;
    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "IsUpdateRequired")
    protected boolean isUpdateRequired;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "TypeOfFailure")
    protected String typeOfFailure;
    @XmlElement(name = "EscalationType")
    protected String escalationType;
    @XmlElement(name = "RootCause")
    protected String rootCause;
    @XmlElement(name = "Contributor")
    protected String contributor;
    @XmlElement(name = "DepttContributor1")
    protected String depttContributor1;
    @XmlElement(name = "KeyLearning1")
    protected String keyLearning1;
    @XmlElement(name = "ReasonForEscalation")
    protected String reasonForEscalation;
    @XmlElement(name = "LastTouchPoint")
    protected String lastTouchPoint;
    @XmlElement(name = "TouchPointResolution")
    protected String touchPointResolution;
    @XmlElement(name = "Escalation")
    protected String escalation;
    @XmlElement(name = "RepeatReason")
    protected String repeatReason;
    @XmlElement(name = "SeniorManagementUpdateRequiredArray")
    protected ArrayOfAnyType seniorManagementUpdateRequiredArray;
    @XmlElement(name = "DepttContributor2")
    protected String depttContributor2;
    @XmlElement(name = "KeyLearning2")
    protected String keyLearning2;

    /**
     * Gets the value of the dateOfComplaint property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfComplaint() {
        return dateOfComplaint;
    }

    /**
     * Sets the value of the dateOfComplaint property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfComplaint(XMLGregorianCalendar value) {
        this.dateOfComplaint = value;
    }

    /**
     * Gets the value of the irdaTicketNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIRDATicketNo() {
        return irdaTicketNo;
    }

    /**
     * Sets the value of the irdaTicketNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIRDATicketNo(String value) {
        this.irdaTicketNo = value;
    }

    /**
     * Gets the value of the typeOfFailureRCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfFailureRCA() {
        return typeOfFailureRCA;
    }

    /**
     * Sets the value of the typeOfFailureRCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfFailureRCA(String value) {
        this.typeOfFailureRCA = value;
    }

    /**
     * Gets the value of the escalationTypeRCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEscalationTypeRCA() {
        return escalationTypeRCA;
    }

    /**
     * Sets the value of the escalationTypeRCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEscalationTypeRCA(String value) {
        this.escalationTypeRCA = value;
    }

    /**
     * Gets the value of the escalationType1RCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEscalationType1RCA() {
        return escalationType1RCA;
    }

    /**
     * Sets the value of the escalationType1RCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEscalationType1RCA(String value) {
        this.escalationType1RCA = value;
    }

    /**
     * Gets the value of the escalationType2RCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEscalationType2RCA() {
        return escalationType2RCA;
    }

    /**
     * Sets the value of the escalationType2RCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEscalationType2RCA(String value) {
        this.escalationType2RCA = value;
    }

    /**
     * Gets the value of the erringDepatmentsType0RCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErringDepatmentsType0RCA() {
        return erringDepatmentsType0RCA;
    }

    /**
     * Sets the value of the erringDepatmentsType0RCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErringDepatmentsType0RCA(String value) {
        this.erringDepatmentsType0RCA = value;
    }

    /**
     * Gets the value of the erringDepatmentsType1RCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErringDepatmentsType1RCA() {
        return erringDepatmentsType1RCA;
    }

    /**
     * Sets the value of the erringDepatmentsType1RCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErringDepatmentsType1RCA(String value) {
        this.erringDepatmentsType1RCA = value;
    }

    /**
     * Gets the value of the erringDepatmentsType2RCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErringDepatmentsType2RCA() {
        return erringDepatmentsType2RCA;
    }

    /**
     * Sets the value of the erringDepatmentsType2RCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErringDepatmentsType2RCA(String value) {
        this.erringDepatmentsType2RCA = value;
    }

    /**
     * Gets the value of the reasonForFailureRCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonForFailureRCA() {
        return reasonForFailureRCA;
    }

    /**
     * Sets the value of the reasonForFailureRCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonForFailureRCA(String value) {
        this.reasonForFailureRCA = value;
    }

    /**
     * Gets the value of the repeatReasonRCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepeatReasonRCA() {
        return repeatReasonRCA;
    }

    /**
     * Sets the value of the repeatReasonRCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepeatReasonRCA(String value) {
        this.repeatReasonRCA = value;
    }

    /**
     * Gets the value of the lasttouchpoinRCA1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLasttouchpoinRCA1() {
        return lasttouchpoinRCA1;
    }

    /**
     * Sets the value of the lasttouchpoinRCA1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLasttouchpoinRCA1(String value) {
        this.lasttouchpoinRCA1 = value;
    }

    /**
     * Gets the value of the lasttouchpoinRCA2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLasttouchpoinRCA2() {
        return lasttouchpoinRCA2;
    }

    /**
     * Sets the value of the lasttouchpoinRCA2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLasttouchpoinRCA2(String value) {
        this.lasttouchpoinRCA2 = value;
    }

    /**
     * Gets the value of the lasttouchpoinRCA3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLasttouchpoinRCA3() {
        return lasttouchpoinRCA3;
    }

    /**
     * Sets the value of the lasttouchpoinRCA3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLasttouchpoinRCA3(String value) {
        this.lasttouchpoinRCA3 = value;
    }

    /**
     * Gets the value of the touchPointResolutionRCA1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTouchPointResolutionRCA1() {
        return touchPointResolutionRCA1;
    }

    /**
     * Sets the value of the touchPointResolutionRCA1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTouchPointResolutionRCA1(String value) {
        this.touchPointResolutionRCA1 = value;
    }

    /**
     * Gets the value of the touchPointResolutionRCA2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTouchPointResolutionRCA2() {
        return touchPointResolutionRCA2;
    }

    /**
     * Sets the value of the touchPointResolutionRCA2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTouchPointResolutionRCA2(String value) {
        this.touchPointResolutionRCA2 = value;
    }

    /**
     * Gets the value of the touchPointResolutionRCA3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTouchPointResolutionRCA3() {
        return touchPointResolutionRCA3;
    }

    /**
     * Sets the value of the touchPointResolutionRCA3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTouchPointResolutionRCA3(String value) {
        this.touchPointResolutionRCA3 = value;
    }

    /**
     * Gets the value of the reasonForDecChangeRCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonForDecChangeRCA() {
        return reasonForDecChangeRCA;
    }

    /**
     * Sets the value of the reasonForDecChangeRCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonForDecChangeRCA(String value) {
        this.reasonForDecChangeRCA = value;
    }

    /**
     * Gets the value of the reasonofEscalationRCA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonofEscalationRCA() {
        return reasonofEscalationRCA;
    }

    /**
     * Sets the value of the reasonofEscalationRCA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonofEscalationRCA(String value) {
        this.reasonofEscalationRCA = value;
    }

    /**
     * Gets the value of the isfeedbackGivenRCA property.
     * 
     */
    public boolean isIsfeedbackGivenRCA() {
        return isfeedbackGivenRCA;
    }

    /**
     * Sets the value of the isfeedbackGivenRCA property.
     * 
     */
    public void setIsfeedbackGivenRCA(boolean value) {
        this.isfeedbackGivenRCA = value;
    }

    /**
     * Gets the value of the isChangeDecision property.
     * 
     */
    public boolean isIsChangeDecision() {
        return isChangeDecision;
    }

    /**
     * Sets the value of the isChangeDecision property.
     * 
     */
    public void setIsChangeDecision(boolean value) {
        this.isChangeDecision = value;
    }

    /**
     * Gets the value of the isEarlierCustomer property.
     * 
     */
    public boolean isIsEarlierCustomer() {
        return isEarlierCustomer;
    }

    /**
     * Sets the value of the isEarlierCustomer property.
     * 
     */
    public void setIsEarlierCustomer(boolean value) {
        this.isEarlierCustomer = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the isUpdateRequired property.
     * 
     */
    public boolean isIsUpdateRequired() {
        return isUpdateRequired;
    }

    /**
     * Sets the value of the isUpdateRequired property.
     * 
     */
    public void setIsUpdateRequired(boolean value) {
        this.isUpdateRequired = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the typeOfFailure property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfFailure() {
        return typeOfFailure;
    }

    /**
     * Sets the value of the typeOfFailure property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfFailure(String value) {
        this.typeOfFailure = value;
    }

    /**
     * Gets the value of the escalationType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEscalationType() {
        return escalationType;
    }

    /**
     * Sets the value of the escalationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEscalationType(String value) {
        this.escalationType = value;
    }

    /**
     * Gets the value of the rootCause property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRootCause() {
        return rootCause;
    }

    /**
     * Sets the value of the rootCause property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRootCause(String value) {
        this.rootCause = value;
    }

    /**
     * Gets the value of the contributor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContributor() {
        return contributor;
    }

    /**
     * Sets the value of the contributor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContributor(String value) {
        this.contributor = value;
    }

    /**
     * Gets the value of the depttContributor1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepttContributor1() {
        return depttContributor1;
    }

    /**
     * Sets the value of the depttContributor1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepttContributor1(String value) {
        this.depttContributor1 = value;
    }

    /**
     * Gets the value of the keyLearning1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKeyLearning1() {
        return keyLearning1;
    }

    /**
     * Sets the value of the keyLearning1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKeyLearning1(String value) {
        this.keyLearning1 = value;
    }

    /**
     * Gets the value of the reasonForEscalation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonForEscalation() {
        return reasonForEscalation;
    }

    /**
     * Sets the value of the reasonForEscalation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonForEscalation(String value) {
        this.reasonForEscalation = value;
    }

    /**
     * Gets the value of the lastTouchPoint property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastTouchPoint() {
        return lastTouchPoint;
    }

    /**
     * Sets the value of the lastTouchPoint property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastTouchPoint(String value) {
        this.lastTouchPoint = value;
    }

    /**
     * Gets the value of the touchPointResolution property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTouchPointResolution() {
        return touchPointResolution;
    }

    /**
     * Sets the value of the touchPointResolution property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTouchPointResolution(String value) {
        this.touchPointResolution = value;
    }

    /**
     * Gets the value of the escalation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEscalation() {
        return escalation;
    }

    /**
     * Sets the value of the escalation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEscalation(String value) {
        this.escalation = value;
    }

    /**
     * Gets the value of the repeatReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepeatReason() {
        return repeatReason;
    }

    /**
     * Sets the value of the repeatReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepeatReason(String value) {
        this.repeatReason = value;
    }

    /**
     * Gets the value of the seniorManagementUpdateRequiredArray property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public ArrayOfAnyType getSeniorManagementUpdateRequiredArray() {
        return seniorManagementUpdateRequiredArray;
    }

    /**
     * Sets the value of the seniorManagementUpdateRequiredArray property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public void setSeniorManagementUpdateRequiredArray(ArrayOfAnyType value) {
        this.seniorManagementUpdateRequiredArray = value;
    }

    /**
     * Gets the value of the depttContributor2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepttContributor2() {
        return depttContributor2;
    }

    /**
     * Sets the value of the depttContributor2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepttContributor2(String value) {
        this.depttContributor2 = value;
    }

    /**
     * Gets the value of the keyLearning2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKeyLearning2() {
        return keyLearning2;
    }

    /**
     * Sets the value of the keyLearning2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKeyLearning2(String value) {
        this.keyLearning2 = value;
    }

}
