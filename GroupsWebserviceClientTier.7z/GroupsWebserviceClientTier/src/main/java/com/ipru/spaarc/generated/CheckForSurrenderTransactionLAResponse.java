
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="checkForSurrenderTransactionLAResult" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "checkForSurrenderTransactionLAResult"
})
@XmlRootElement(name = "checkForSurrenderTransactionLAResponse")
public class CheckForSurrenderTransactionLAResponse {

    protected boolean checkForSurrenderTransactionLAResult;

    /**
     * Gets the value of the checkForSurrenderTransactionLAResult property.
     * 
     */
    public boolean isCheckForSurrenderTransactionLAResult() {
        return checkForSurrenderTransactionLAResult;
    }

    /**
     * Sets the value of the checkForSurrenderTransactionLAResult property.
     * 
     */
    public void setCheckForSurrenderTransactionLAResult(boolean value) {
        this.checkForSurrenderTransactionLAResult = value;
    }

}
