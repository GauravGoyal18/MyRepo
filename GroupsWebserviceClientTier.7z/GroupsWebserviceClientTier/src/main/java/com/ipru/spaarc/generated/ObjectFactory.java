
package com.ipru.spaarc.generated;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ipru.spaarc.generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AuthenticateInfo_QNAME = new QName("http://tempuri.org/", "AuthenticateInfo");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ipru.spaarc.generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AutoCallLogForIVRRequestResponse }
     * 
     */
    public AutoCallLogForIVRRequestResponse createAutoCallLogForIVRRequestResponse() {
        return new AutoCallLogForIVRRequestResponse();
    }

    /**
     * Create an instance of {@link CheckForSurrenderTransactionLAResponse }
     * 
     */
    public CheckForSurrenderTransactionLAResponse createCheckForSurrenderTransactionLAResponse() {
        return new CheckForSurrenderTransactionLAResponse();
    }

    /**
     * Create an instance of {@link AutoCallLogForESwitch }
     * 
     */
    public AutoCallLogForESwitch createAutoCallLogForESwitch() {
        return new AutoCallLogForESwitch();
    }

    /**
     * Create an instance of {@link Subset }
     * 
     */
    public Subset createSubset() {
        return new Subset();
    }

    /**
     * Create an instance of {@link AuthenticateInfo }
     * 
     */
    public AuthenticateInfo createAuthenticateInfo() {
        return new AuthenticateInfo();
    }

    /**
     * Create an instance of {@link EncryptTripleDESResponse }
     * 
     */
    public EncryptTripleDESResponse createEncryptTripleDESResponse() {
        return new EncryptTripleDESResponse();
    }

    /**
     * Create an instance of {@link DetailPDRMedical }
     * 
     */
    public DetailPDRMedical createDetailPDRMedical() {
        return new DetailPDRMedical();
    }

    /**
     * Create an instance of {@link DetailFraudRCA }
     * 
     */
    public DetailFraudRCA createDetailFraudRCA() {
        return new DetailFraudRCA();
    }

    /**
     * Create an instance of {@link Assignment }
     * 
     */
    public Assignment createAssignment() {
        return new Assignment();
    }

    /**
     * Create an instance of {@link GetOpenCallIDResponse }
     * 
     */
    public GetOpenCallIDResponse createGetOpenCallIDResponse() {
        return new GetOpenCallIDResponse();
    }

    /**
     * Create an instance of {@link DetailPaymentOptions }
     * 
     */
    public DetailPaymentOptions createDetailPaymentOptions() {
        return new DetailPaymentOptions();
    }

    /**
     * Create an instance of {@link DecryptTripleDES }
     * 
     */
    public DecryptTripleDES createDecryptTripleDES() {
        return new DecryptTripleDES();
    }

    /**
     * Create an instance of {@link EncryptTripleDES }
     * 
     */
    public EncryptTripleDES createEncryptTripleDES() {
        return new EncryptTripleDES();
    }

    /**
     * Create an instance of {@link CheckForSurrenderTransactionLA }
     * 
     */
    public CheckForSurrenderTransactionLA createCheckForSurrenderTransactionLA() {
        return new CheckForSurrenderTransactionLA();
    }

    /**
     * Create an instance of {@link AutoCallLogForSurrender }
     * 
     */
    public AutoCallLogForSurrender createAutoCallLogForSurrender() {
        return new AutoCallLogForSurrender();
    }

    /**
     * Create an instance of {@link AutoCallLogForIVRRequest }
     * 
     */
    public AutoCallLogForIVRRequest createAutoCallLogForIVRRequest() {
        return new AutoCallLogForIVRRequest();
    }

    /**
     * Create an instance of {@link AutoCallLogForSurrenderResponse }
     * 
     */
    public AutoCallLogForSurrenderResponse createAutoCallLogForSurrenderResponse() {
        return new AutoCallLogForSurrenderResponse();
    }

    /**
     * Create an instance of {@link SeniorManagementUpdateDetail }
     * 
     */
    public SeniorManagementUpdateDetail createSeniorManagementUpdateDetail() {
        return new SeniorManagementUpdateDetail();
    }

    /**
     * Create an instance of {@link GetCallIDInformation }
     * 
     */
    public GetCallIDInformation createGetCallIDInformation() {
        return new GetCallIDInformation();
    }

    /**
     * Create an instance of {@link ArrayOfReOpenedDetail }
     * 
     */
    public ArrayOfReOpenedDetail createArrayOfReOpenedDetail() {
        return new ArrayOfReOpenedDetail();
    }

    /**
     * Create an instance of {@link DetailS2TTopup }
     * 
     */
    public DetailS2TTopup createDetailS2TTopup() {
        return new DetailS2TTopup();
    }

    /**
     * Create an instance of {@link DetailFreeLook }
     * 
     */
    public DetailFreeLook createDetailFreeLook() {
        return new DetailFreeLook();
    }

    /**
     * Create an instance of {@link ReOpenedDetail }
     * 
     */
    public ReOpenedDetail createReOpenedDetail() {
        return new ReOpenedDetail();
    }

    /**
     * Create an instance of {@link DetailErrorUnitAllocation }
     * 
     */
    public DetailErrorUnitAllocation createDetailErrorUnitAllocation() {
        return new DetailErrorUnitAllocation();
    }

    /**
     * Create an instance of {@link DetailGroupDeathClaim }
     * 
     */
    public DetailGroupDeathClaim createDetailGroupDeathClaim() {
        return new DetailGroupDeathClaim();
    }

    /**
     * Create an instance of {@link AutoCallLog }
     * 
     */
    public AutoCallLog createAutoCallLog() {
        return new AutoCallLog();
    }

    /**
     * Create an instance of {@link AutoCallLogForESwitchRequestResponse }
     * 
     */
    public AutoCallLogForESwitchRequestResponse createAutoCallLogForESwitchRequestResponse() {
        return new AutoCallLogForESwitchRequestResponse();
    }

    /**
     * Create an instance of {@link DetailCustomerServicingDocument }
     * 
     */
    public DetailCustomerServicingDocument createDetailCustomerServicingDocument() {
        return new DetailCustomerServicingDocument();
    }

    /**
     * Create an instance of {@link GetCallLogObjectData }
     * 
     */
    public GetCallLogObjectData createGetCallLogObjectData() {
        return new GetCallLogObjectData();
    }

    /**
     * Create an instance of {@link IRDAEntity }
     * 
     */
    public IRDAEntity createIRDAEntity() {
        return new IRDAEntity();
    }

    /**
     * Create an instance of {@link DetailPayOuts }
     * 
     */
    public DetailPayOuts createDetailPayOuts() {
        return new DetailPayOuts();
    }

    /**
     * Create an instance of {@link DetailCorrection }
     * 
     */
    public DetailCorrection createDetailCorrection() {
        return new DetailCorrection();
    }

    /**
     * Create an instance of {@link DetailClaim }
     * 
     */
    public DetailClaim createDetailClaim() {
        return new DetailClaim();
    }

    /**
     * Create an instance of {@link DetailPolicyCharacteristics }
     * 
     */
    public DetailPolicyCharacteristics createDetailPolicyCharacteristics() {
        return new DetailPolicyCharacteristics();
    }

    /**
     * Create an instance of {@link GetCallLogObjectDataResponse }
     * 
     */
    public GetCallLogObjectDataResponse createGetCallLogObjectDataResponse() {
        return new GetCallLogObjectDataResponse();
    }

    /**
     * Create an instance of {@link DecryptTripleDESResponse }
     * 
     */
    public DecryptTripleDESResponse createDecryptTripleDESResponse() {
        return new DecryptTripleDESResponse();
    }

    /**
     * Create an instance of {@link CallClosure }
     * 
     */
    public CallClosure createCallClosure() {
        return new CallClosure();
    }

    /**
     * Create an instance of {@link AutoCallLogForESwitchRequest }
     * 
     */
    public AutoCallLogForESwitchRequest createAutoCallLogForESwitchRequest() {
        return new AutoCallLogForESwitchRequest();
    }

    /**
     * Create an instance of {@link Journal }
     * 
     */
    public Journal createJournal() {
        return new Journal();
    }

    /**
     * Create an instance of {@link ArrayOfString }
     * 
     */
    public ArrayOfString createArrayOfString() {
        return new ArrayOfString();
    }

    /**
     * Create an instance of {@link DetailExtendedFreelook }
     * 
     */
    public DetailExtendedFreelook createDetailExtendedFreelook() {
        return new DetailExtendedFreelook();
    }

    /**
     * Create an instance of {@link DetailVAM }
     * 
     */
    public DetailVAM createDetailVAM() {
        return new DetailVAM();
    }

    /**
     * Create an instance of {@link DetailATP }
     * 
     */
    public DetailATP createDetailATP() {
        return new DetailATP();
    }

    /**
     * Create an instance of {@link AutoCallLogForESwitchResponse }
     * 
     */
    public AutoCallLogForESwitchResponse createAutoCallLogForESwitchResponse() {
        return new AutoCallLogForESwitchResponse();
    }

    /**
     * Create an instance of {@link CallAttachment }
     * 
     */
    public CallAttachment createCallAttachment() {
        return new CallAttachment();
    }

    /**
     * Create an instance of {@link ArrayOfAnyType }
     * 
     */
    public ArrayOfAnyType createArrayOfAnyType() {
        return new ArrayOfAnyType();
    }

    /**
     * Create an instance of {@link AutoCallLogResponse }
     * 
     */
    public AutoCallLogResponse createAutoCallLogResponse() {
        return new AutoCallLogResponse();
    }

    /**
     * Create an instance of {@link DetailNonPDRXTR }
     * 
     */
    public DetailNonPDRXTR createDetailNonPDRXTR() {
        return new DetailNonPDRXTR();
    }

    /**
     * Create an instance of {@link DetailSru }
     * 
     */
    public DetailSru createDetailSru() {
        return new DetailSru();
    }

    /**
     * Create an instance of {@link CallClosureResponse }
     * 
     */
    public CallClosureResponse createCallClosureResponse() {
        return new CallClosureResponse();
    }

    /**
     * Create an instance of {@link DetailChequePickup }
     * 
     */
    public DetailChequePickup createDetailChequePickup() {
        return new DetailChequePickup();
    }

    /**
     * Create an instance of {@link GetOpenCallID }
     * 
     */
    public GetOpenCallID createGetOpenCallID() {
        return new GetOpenCallID();
    }

    /**
     * Create an instance of {@link DetailMisseling }
     * 
     */
    public DetailMisseling createDetailMisseling() {
        return new DetailMisseling();
    }

    /**
     * Create an instance of {@link CallLog }
     * 
     */
    public CallLog createCallLog() {
        return new CallLog();
    }

    /**
     * Create an instance of {@link DetailS2TReinstatement }
     * 
     */
    public DetailS2TReinstatement createDetailS2TReinstatement() {
        return new DetailS2TReinstatement();
    }

    /**
     * Create an instance of {@link FreshEmailEntity }
     * 
     */
    public FreshEmailEntity createFreshEmailEntity() {
        return new FreshEmailEntity();
    }

    /**
     * Create an instance of {@link DetailClientDetails }
     * 
     */
    public DetailClientDetails createDetailClientDetails() {
        return new DetailClientDetails();
    }

    /**
     * Create an instance of {@link DetailReinstatement }
     * 
     */
    public DetailReinstatement createDetailReinstatement() {
        return new DetailReinstatement();
    }

    /**
     * Create an instance of {@link GetCallIDInformationResponse }
     * 
     */
    public GetCallIDInformationResponse createGetCallIDInformationResponse() {
        return new GetCallIDInformationResponse();
    }

    /**
     * Create an instance of {@link DetailRetention }
     * 
     */
    public DetailRetention createDetailRetention() {
        return new DetailRetention();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthenticateInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://tempuri.org/", name = "AuthenticateInfo")
    public JAXBElement<AuthenticateInfo> createAuthenticateInfo(AuthenticateInfo value) {
        return new JAXBElement<AuthenticateInfo>(_AuthenticateInfo_QNAME, AuthenticateInfo.class, null, value);
    }

}
