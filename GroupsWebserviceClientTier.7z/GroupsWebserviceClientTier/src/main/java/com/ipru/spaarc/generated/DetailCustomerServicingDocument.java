
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DetailCustomerServicingDocument complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailCustomerServicingDocument">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="IPCFY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USFY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IPCMON" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USMON" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailCustomerServicingDocument", propOrder = {
    "isUpdated",
    "isChanged",
    "interactionID",
    "ipcfy",
    "usfy",
    "ipcmon",
    "usmon"
})
public class DetailCustomerServicingDocument {

    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "IPCFY")
    protected String ipcfy;
    @XmlElement(name = "USFY")
    protected String usfy;
    @XmlElement(name = "IPCMON")
    protected String ipcmon;
    @XmlElement(name = "USMON")
    protected String usmon;

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the ipcfy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPCFY() {
        return ipcfy;
    }

    /**
     * Sets the value of the ipcfy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPCFY(String value) {
        this.ipcfy = value;
    }

    /**
     * Gets the value of the usfy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSFY() {
        return usfy;
    }

    /**
     * Sets the value of the usfy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSFY(String value) {
        this.usfy = value;
    }

    /**
     * Gets the value of the ipcmon property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPCMON() {
        return ipcmon;
    }

    /**
     * Sets the value of the ipcmon property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPCMON(String value) {
        this.ipcmon = value;
    }

    /**
     * Gets the value of the usmon property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSMON() {
        return usmon;
    }

    /**
     * Sets the value of the usmon property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSMON(String value) {
        this.usmon = value;
    }

}
