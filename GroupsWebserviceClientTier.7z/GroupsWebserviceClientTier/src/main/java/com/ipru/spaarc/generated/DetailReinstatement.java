
package com.ipru.spaarc.generated;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DetailReinstatement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailReinstatement">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="ShortPremiumAmount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="RevisedPremiumAmount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="AdditionalRequirement1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdditionalRequirement2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdditionalRequirement3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdditionalRequirement4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdditionalRequirement5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="LapsePeriod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DocumentReceived" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DocumentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReInstatementFee" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailReinstatement", propOrder = {
    "isChanged",
    "interactionID",
    "shortPremiumAmount",
    "revisedPremiumAmount",
    "additionalRequirement1",
    "additionalRequirement2",
    "additionalRequirement3",
    "additionalRequirement4",
    "additionalRequirement5",
    "isUpdated",
    "lapsePeriod",
    "documentReceived",
    "documentName",
    "reInstatementFee"
})
public class DetailReinstatement {

    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "ShortPremiumAmount", required = true)
    protected BigDecimal shortPremiumAmount;
    @XmlElement(name = "RevisedPremiumAmount", required = true)
    protected BigDecimal revisedPremiumAmount;
    @XmlElement(name = "AdditionalRequirement1")
    protected String additionalRequirement1;
    @XmlElement(name = "AdditionalRequirement2")
    protected String additionalRequirement2;
    @XmlElement(name = "AdditionalRequirement3")
    protected String additionalRequirement3;
    @XmlElement(name = "AdditionalRequirement4")
    protected String additionalRequirement4;
    @XmlElement(name = "AdditionalRequirement5")
    protected String additionalRequirement5;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "LapsePeriod")
    protected String lapsePeriod;
    @XmlElement(name = "DocumentReceived")
    protected String documentReceived;
    @XmlElement(name = "DocumentName")
    protected String documentName;
    @XmlElement(name = "ReInstatementFee", required = true)
    protected BigDecimal reInstatementFee;

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the shortPremiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getShortPremiumAmount() {
        return shortPremiumAmount;
    }

    /**
     * Sets the value of the shortPremiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setShortPremiumAmount(BigDecimal value) {
        this.shortPremiumAmount = value;
    }

    /**
     * Gets the value of the revisedPremiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getRevisedPremiumAmount() {
        return revisedPremiumAmount;
    }

    /**
     * Sets the value of the revisedPremiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setRevisedPremiumAmount(BigDecimal value) {
        this.revisedPremiumAmount = value;
    }

    /**
     * Gets the value of the additionalRequirement1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalRequirement1() {
        return additionalRequirement1;
    }

    /**
     * Sets the value of the additionalRequirement1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalRequirement1(String value) {
        this.additionalRequirement1 = value;
    }

    /**
     * Gets the value of the additionalRequirement2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalRequirement2() {
        return additionalRequirement2;
    }

    /**
     * Sets the value of the additionalRequirement2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalRequirement2(String value) {
        this.additionalRequirement2 = value;
    }

    /**
     * Gets the value of the additionalRequirement3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalRequirement3() {
        return additionalRequirement3;
    }

    /**
     * Sets the value of the additionalRequirement3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalRequirement3(String value) {
        this.additionalRequirement3 = value;
    }

    /**
     * Gets the value of the additionalRequirement4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalRequirement4() {
        return additionalRequirement4;
    }

    /**
     * Sets the value of the additionalRequirement4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalRequirement4(String value) {
        this.additionalRequirement4 = value;
    }

    /**
     * Gets the value of the additionalRequirement5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalRequirement5() {
        return additionalRequirement5;
    }

    /**
     * Sets the value of the additionalRequirement5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalRequirement5(String value) {
        this.additionalRequirement5 = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the lapsePeriod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLapsePeriod() {
        return lapsePeriod;
    }

    /**
     * Sets the value of the lapsePeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLapsePeriod(String value) {
        this.lapsePeriod = value;
    }

    /**
     * Gets the value of the documentReceived property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentReceived() {
        return documentReceived;
    }

    /**
     * Sets the value of the documentReceived property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentReceived(String value) {
        this.documentReceived = value;
    }

    /**
     * Gets the value of the documentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentName() {
        return documentName;
    }

    /**
     * Sets the value of the documentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentName(String value) {
        this.documentName = value;
    }

    /**
     * Gets the value of the reInstatementFee property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getReInstatementFee() {
        return reInstatementFee;
    }

    /**
     * Sets the value of the reInstatementFee property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setReInstatementFee(BigDecimal value) {
        this.reInstatementFee = value;
    }

}
