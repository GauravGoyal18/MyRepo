
package com.ipru.spaarc.generated;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DetailPayOuts complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailPayOuts">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ChequeSubmitted" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IciciVerified" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExpressPayout" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SysDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SysDeviation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsICICI_Verified" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsCheque_Submitted" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsPan_Updated" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonFreelook" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PLVCPIVCWC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PLVCPIVCFindings" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DecisionAssignmnet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonFreeLookServiceOrOthers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfRetention" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmpCode1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmpCode2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="PaymentMethod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="BankAccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BankName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BranchName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MICRCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IFSC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PayoutHoldTillDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="SignatureVerification" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhotoID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="KYC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssignToRisk" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PayoutReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SurrenderValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SurrenderValuePer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TotalPremium" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InvestedPremium" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SuccessFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PTD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonForFinalDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DecisionText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Decision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApproverName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApproverDesg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesApproval" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CRD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WelcomeKit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Reason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Grade" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerMeet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerBusy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerNotInterest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerNotContactable" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfWaiverOnRetention" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerOut" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerNA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FinancialAssistance" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssistanceAvailed" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfNoFAReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OtherDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ICICIBankAuthenticationOutput" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonforApproval" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PRNNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MReprocessing" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lap_Location" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="loanAccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailPayOuts", propOrder = {
    "chequeSubmitted",
    "iciciVerified",
    "expressPayout",
    "sysDecision",
    "sysDeviation",
    "isICICIVerified",
    "isChequeSubmitted",
    "isPanUpdated",
    "pan",
    "reasonFreelook",
    "plvcpivcwc",
    "plvcpivcFindings",
    "decisionAssignmnet",
    "reasonFreeLookServiceOrOthers",
    "typeOfRetention",
    "empCode1",
    "empCode2",
    "agentName",
    "agentCode",
    "isChanged",
    "interactionId",
    "paymentMethod",
    "amount",
    "bankAccountNo",
    "accountType",
    "bankName",
    "branchName",
    "micrCode",
    "ifsc",
    "payoutHoldTillDate",
    "isUpdated",
    "signatureVerification",
    "photoID",
    "kyc",
    "assignToRisk",
    "payoutReason",
    "surrenderValue",
    "surrenderValuePer",
    "fundValue",
    "totalPremium",
    "investedPremium",
    "successFlag",
    "ptd",
    "reasonForFinalDecision",
    "decisionText",
    "decision",
    "approverName",
    "approverDesg",
    "custAddress",
    "salesApproval",
    "crd",
    "welcomeKit",
    "reason",
    "grade",
    "date",
    "typeOfCustomerMeet",
    "typeOfCustomerBusy",
    "typeOfCustomerNotInterest",
    "typeOfCustomerNotContactable",
    "typeOfWaiverOnRetention",
    "typeOfCustomerOut",
    "typeOfCustomerNA",
    "financialAssistance",
    "assistanceAvailed",
    "typeOfNoFAReason",
    "otherDescription",
    "iciciBankAuthenticationOutput",
    "reasonforApproval",
    "prnNo",
    "mReprocessing",
    "lapLocation",
    "loanAccountNo"
})
public class DetailPayOuts {

    @XmlElement(name = "ChequeSubmitted")
    protected String chequeSubmitted;
    @XmlElement(name = "IciciVerified")
    protected String iciciVerified;
    @XmlElement(name = "ExpressPayout")
    protected String expressPayout;
    @XmlElement(name = "SysDecision")
    protected String sysDecision;
    @XmlElement(name = "SysDeviation")
    protected String sysDeviation;
    @XmlElement(name = "IsICICI_Verified")
    protected String isICICIVerified;
    @XmlElement(name = "IsCheque_Submitted")
    protected String isChequeSubmitted;
    @XmlElement(name = "IsPan_Updated")
    protected String isPanUpdated;
    @XmlElement(name = "PAN")
    protected String pan;
    @XmlElement(name = "ReasonFreelook")
    protected String reasonFreelook;
    @XmlElement(name = "PLVCPIVCWC")
    protected String plvcpivcwc;
    @XmlElement(name = "PLVCPIVCFindings")
    protected String plvcpivcFindings;
    @XmlElement(name = "DecisionAssignmnet")
    protected String decisionAssignmnet;
    @XmlElement(name = "ReasonFreeLookServiceOrOthers")
    protected String reasonFreeLookServiceOrOthers;
    @XmlElement(name = "TypeOfRetention")
    protected String typeOfRetention;
    @XmlElement(name = "EmpCode1")
    protected String empCode1;
    @XmlElement(name = "EmpCode2")
    protected String empCode2;
    @XmlElement(name = "AgentName")
    protected String agentName;
    @XmlElement(name = "AgentCode")
    protected String agentCode;
    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionId")
    protected long interactionId;
    @XmlElement(name = "PaymentMethod")
    protected String paymentMethod;
    @XmlElement(name = "Amount", required = true)
    protected BigDecimal amount;
    @XmlElement(name = "BankAccountNo")
    protected String bankAccountNo;
    @XmlElement(name = "AccountType")
    protected String accountType;
    @XmlElement(name = "BankName")
    protected String bankName;
    @XmlElement(name = "BranchName")
    protected String branchName;
    @XmlElement(name = "MICRCode")
    protected String micrCode;
    @XmlElement(name = "IFSC")
    protected String ifsc;
    @XmlElement(name = "PayoutHoldTillDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar payoutHoldTillDate;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "SignatureVerification")
    protected String signatureVerification;
    @XmlElement(name = "PhotoID")
    protected String photoID;
    @XmlElement(name = "KYC")
    protected String kyc;
    @XmlElement(name = "AssignToRisk")
    protected String assignToRisk;
    @XmlElement(name = "PayoutReason")
    protected String payoutReason;
    @XmlElement(name = "SurrenderValue")
    protected String surrenderValue;
    @XmlElement(name = "SurrenderValuePer")
    protected String surrenderValuePer;
    @XmlElement(name = "FundValue")
    protected String fundValue;
    @XmlElement(name = "TotalPremium")
    protected String totalPremium;
    @XmlElement(name = "InvestedPremium")
    protected String investedPremium;
    @XmlElement(name = "SuccessFlag")
    protected String successFlag;
    @XmlElement(name = "PTD")
    protected String ptd;
    @XmlElement(name = "ReasonForFinalDecision")
    protected String reasonForFinalDecision;
    @XmlElement(name = "DecisionText")
    protected String decisionText;
    @XmlElement(name = "Decision")
    protected String decision;
    @XmlElement(name = "ApproverName")
    protected String approverName;
    @XmlElement(name = "ApproverDesg")
    protected String approverDesg;
    @XmlElement(name = "CustAddress")
    protected String custAddress;
    @XmlElement(name = "SalesApproval")
    protected String salesApproval;
    @XmlElement(name = "CRD")
    protected String crd;
    @XmlElement(name = "WelcomeKit")
    protected String welcomeKit;
    @XmlElement(name = "Reason")
    protected String reason;
    @XmlElement(name = "Grade")
    protected String grade;
    @XmlElement(name = "Date")
    protected String date;
    @XmlElement(name = "TypeOfCustomerMeet")
    protected String typeOfCustomerMeet;
    @XmlElement(name = "TypeOfCustomerBusy")
    protected String typeOfCustomerBusy;
    @XmlElement(name = "TypeOfCustomerNotInterest")
    protected String typeOfCustomerNotInterest;
    @XmlElement(name = "TypeOfCustomerNotContactable")
    protected String typeOfCustomerNotContactable;
    @XmlElement(name = "TypeOfWaiverOnRetention")
    protected String typeOfWaiverOnRetention;
    @XmlElement(name = "TypeOfCustomerOut")
    protected String typeOfCustomerOut;
    @XmlElement(name = "TypeOfCustomerNA")
    protected String typeOfCustomerNA;
    @XmlElement(name = "FinancialAssistance")
    protected String financialAssistance;
    @XmlElement(name = "AssistanceAvailed")
    protected String assistanceAvailed;
    @XmlElement(name = "TypeOfNoFAReason")
    protected String typeOfNoFAReason;
    @XmlElement(name = "OtherDescription")
    protected String otherDescription;
    @XmlElement(name = "ICICIBankAuthenticationOutput")
    protected String iciciBankAuthenticationOutput;
    @XmlElement(name = "ReasonforApproval")
    protected String reasonforApproval;
    @XmlElement(name = "PRNNo")
    protected String prnNo;
    @XmlElement(name = "MReprocessing")
    protected String mReprocessing;
    @XmlElement(name = "lap_Location")
    protected String lapLocation;
    protected String loanAccountNo;

    /**
     * Gets the value of the chequeSubmitted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequeSubmitted() {
        return chequeSubmitted;
    }

    /**
     * Sets the value of the chequeSubmitted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequeSubmitted(String value) {
        this.chequeSubmitted = value;
    }

    /**
     * Gets the value of the iciciVerified property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIciciVerified() {
        return iciciVerified;
    }

    /**
     * Sets the value of the iciciVerified property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIciciVerified(String value) {
        this.iciciVerified = value;
    }

    /**
     * Gets the value of the expressPayout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpressPayout() {
        return expressPayout;
    }

    /**
     * Sets the value of the expressPayout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpressPayout(String value) {
        this.expressPayout = value;
    }

    /**
     * Gets the value of the sysDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSysDecision() {
        return sysDecision;
    }

    /**
     * Sets the value of the sysDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSysDecision(String value) {
        this.sysDecision = value;
    }

    /**
     * Gets the value of the sysDeviation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSysDeviation() {
        return sysDeviation;
    }

    /**
     * Sets the value of the sysDeviation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSysDeviation(String value) {
        this.sysDeviation = value;
    }

    /**
     * Gets the value of the isICICIVerified property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsICICIVerified() {
        return isICICIVerified;
    }

    /**
     * Sets the value of the isICICIVerified property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsICICIVerified(String value) {
        this.isICICIVerified = value;
    }

    /**
     * Gets the value of the isChequeSubmitted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsChequeSubmitted() {
        return isChequeSubmitted;
    }

    /**
     * Sets the value of the isChequeSubmitted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsChequeSubmitted(String value) {
        this.isChequeSubmitted = value;
    }

    /**
     * Gets the value of the isPanUpdated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsPanUpdated() {
        return isPanUpdated;
    }

    /**
     * Sets the value of the isPanUpdated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsPanUpdated(String value) {
        this.isPanUpdated = value;
    }

    /**
     * Gets the value of the pan property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPAN() {
        return pan;
    }

    /**
     * Sets the value of the pan property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPAN(String value) {
        this.pan = value;
    }

    /**
     * Gets the value of the reasonFreelook property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonFreelook() {
        return reasonFreelook;
    }

    /**
     * Sets the value of the reasonFreelook property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonFreelook(String value) {
        this.reasonFreelook = value;
    }

    /**
     * Gets the value of the plvcpivcwc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLVCPIVCWC() {
        return plvcpivcwc;
    }

    /**
     * Sets the value of the plvcpivcwc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLVCPIVCWC(String value) {
        this.plvcpivcwc = value;
    }

    /**
     * Gets the value of the plvcpivcFindings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLVCPIVCFindings() {
        return plvcpivcFindings;
    }

    /**
     * Sets the value of the plvcpivcFindings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLVCPIVCFindings(String value) {
        this.plvcpivcFindings = value;
    }

    /**
     * Gets the value of the decisionAssignmnet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionAssignmnet() {
        return decisionAssignmnet;
    }

    /**
     * Sets the value of the decisionAssignmnet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionAssignmnet(String value) {
        this.decisionAssignmnet = value;
    }

    /**
     * Gets the value of the reasonFreeLookServiceOrOthers property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonFreeLookServiceOrOthers() {
        return reasonFreeLookServiceOrOthers;
    }

    /**
     * Sets the value of the reasonFreeLookServiceOrOthers property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonFreeLookServiceOrOthers(String value) {
        this.reasonFreeLookServiceOrOthers = value;
    }

    /**
     * Gets the value of the typeOfRetention property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfRetention() {
        return typeOfRetention;
    }

    /**
     * Sets the value of the typeOfRetention property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfRetention(String value) {
        this.typeOfRetention = value;
    }

    /**
     * Gets the value of the empCode1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmpCode1() {
        return empCode1;
    }

    /**
     * Sets the value of the empCode1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmpCode1(String value) {
        this.empCode1 = value;
    }

    /**
     * Gets the value of the empCode2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmpCode2() {
        return empCode2;
    }

    /**
     * Sets the value of the empCode2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmpCode2(String value) {
        this.empCode2 = value;
    }

    /**
     * Gets the value of the agentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentName() {
        return agentName;
    }

    /**
     * Sets the value of the agentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentName(String value) {
        this.agentName = value;
    }

    /**
     * Gets the value of the agentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentCode() {
        return agentCode;
    }

    /**
     * Sets the value of the agentCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentCode(String value) {
        this.agentCode = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionId property.
     * 
     */
    public long getInteractionId() {
        return interactionId;
    }

    /**
     * Sets the value of the interactionId property.
     * 
     */
    public void setInteractionId(long value) {
        this.interactionId = value;
    }

    /**
     * Gets the value of the paymentMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * Sets the value of the paymentMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentMethod(String value) {
        this.paymentMethod = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmount(BigDecimal value) {
        this.amount = value;
    }

    /**
     * Gets the value of the bankAccountNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankAccountNo() {
        return bankAccountNo;
    }

    /**
     * Sets the value of the bankAccountNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccountNo(String value) {
        this.bankAccountNo = value;
    }

    /**
     * Gets the value of the accountType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * Sets the value of the accountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountType(String value) {
        this.accountType = value;
    }

    /**
     * Gets the value of the bankName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * Sets the value of the bankName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankName(String value) {
        this.bankName = value;
    }

    /**
     * Gets the value of the branchName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchName() {
        return branchName;
    }

    /**
     * Sets the value of the branchName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchName(String value) {
        this.branchName = value;
    }

    /**
     * Gets the value of the micrCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMICRCode() {
        return micrCode;
    }

    /**
     * Sets the value of the micrCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMICRCode(String value) {
        this.micrCode = value;
    }

    /**
     * Gets the value of the ifsc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIFSC() {
        return ifsc;
    }

    /**
     * Sets the value of the ifsc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIFSC(String value) {
        this.ifsc = value;
    }

    /**
     * Gets the value of the payoutHoldTillDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPayoutHoldTillDate() {
        return payoutHoldTillDate;
    }

    /**
     * Sets the value of the payoutHoldTillDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPayoutHoldTillDate(XMLGregorianCalendar value) {
        this.payoutHoldTillDate = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the signatureVerification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignatureVerification() {
        return signatureVerification;
    }

    /**
     * Sets the value of the signatureVerification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignatureVerification(String value) {
        this.signatureVerification = value;
    }

    /**
     * Gets the value of the photoID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhotoID() {
        return photoID;
    }

    /**
     * Sets the value of the photoID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhotoID(String value) {
        this.photoID = value;
    }

    /**
     * Gets the value of the kyc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKYC() {
        return kyc;
    }

    /**
     * Sets the value of the kyc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKYC(String value) {
        this.kyc = value;
    }

    /**
     * Gets the value of the assignToRisk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignToRisk() {
        return assignToRisk;
    }

    /**
     * Sets the value of the assignToRisk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignToRisk(String value) {
        this.assignToRisk = value;
    }

    /**
     * Gets the value of the payoutReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayoutReason() {
        return payoutReason;
    }

    /**
     * Sets the value of the payoutReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayoutReason(String value) {
        this.payoutReason = value;
    }

    /**
     * Gets the value of the surrenderValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurrenderValue() {
        return surrenderValue;
    }

    /**
     * Sets the value of the surrenderValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurrenderValue(String value) {
        this.surrenderValue = value;
    }

    /**
     * Gets the value of the surrenderValuePer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurrenderValuePer() {
        return surrenderValuePer;
    }

    /**
     * Sets the value of the surrenderValuePer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurrenderValuePer(String value) {
        this.surrenderValuePer = value;
    }

    /**
     * Gets the value of the fundValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundValue() {
        return fundValue;
    }

    /**
     * Sets the value of the fundValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundValue(String value) {
        this.fundValue = value;
    }

    /**
     * Gets the value of the totalPremium property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalPremium() {
        return totalPremium;
    }

    /**
     * Sets the value of the totalPremium property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalPremium(String value) {
        this.totalPremium = value;
    }

    /**
     * Gets the value of the investedPremium property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestedPremium() {
        return investedPremium;
    }

    /**
     * Sets the value of the investedPremium property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestedPremium(String value) {
        this.investedPremium = value;
    }

    /**
     * Gets the value of the successFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuccessFlag() {
        return successFlag;
    }

    /**
     * Sets the value of the successFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuccessFlag(String value) {
        this.successFlag = value;
    }

    /**
     * Gets the value of the ptd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPTD() {
        return ptd;
    }

    /**
     * Sets the value of the ptd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPTD(String value) {
        this.ptd = value;
    }

    /**
     * Gets the value of the reasonForFinalDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonForFinalDecision() {
        return reasonForFinalDecision;
    }

    /**
     * Sets the value of the reasonForFinalDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonForFinalDecision(String value) {
        this.reasonForFinalDecision = value;
    }

    /**
     * Gets the value of the decisionText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionText() {
        return decisionText;
    }

    /**
     * Sets the value of the decisionText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionText(String value) {
        this.decisionText = value;
    }

    /**
     * Gets the value of the decision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecision() {
        return decision;
    }

    /**
     * Sets the value of the decision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecision(String value) {
        this.decision = value;
    }

    /**
     * Gets the value of the approverName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApproverName() {
        return approverName;
    }

    /**
     * Sets the value of the approverName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApproverName(String value) {
        this.approverName = value;
    }

    /**
     * Gets the value of the approverDesg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApproverDesg() {
        return approverDesg;
    }

    /**
     * Sets the value of the approverDesg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApproverDesg(String value) {
        this.approverDesg = value;
    }

    /**
     * Gets the value of the custAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustAddress() {
        return custAddress;
    }

    /**
     * Sets the value of the custAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustAddress(String value) {
        this.custAddress = value;
    }

    /**
     * Gets the value of the salesApproval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesApproval() {
        return salesApproval;
    }

    /**
     * Sets the value of the salesApproval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesApproval(String value) {
        this.salesApproval = value;
    }

    /**
     * Gets the value of the crd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRD() {
        return crd;
    }

    /**
     * Sets the value of the crd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRD(String value) {
        this.crd = value;
    }

    /**
     * Gets the value of the welcomeKit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWelcomeKit() {
        return welcomeKit;
    }

    /**
     * Sets the value of the welcomeKit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWelcomeKit(String value) {
        this.welcomeKit = value;
    }

    /**
     * Gets the value of the reason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReason() {
        return reason;
    }

    /**
     * Sets the value of the reason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReason(String value) {
        this.reason = value;
    }

    /**
     * Gets the value of the grade property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGrade() {
        return grade;
    }

    /**
     * Sets the value of the grade property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGrade(String value) {
        this.grade = value;
    }

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDate(String value) {
        this.date = value;
    }

    /**
     * Gets the value of the typeOfCustomerMeet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerMeet() {
        return typeOfCustomerMeet;
    }

    /**
     * Sets the value of the typeOfCustomerMeet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerMeet(String value) {
        this.typeOfCustomerMeet = value;
    }

    /**
     * Gets the value of the typeOfCustomerBusy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerBusy() {
        return typeOfCustomerBusy;
    }

    /**
     * Sets the value of the typeOfCustomerBusy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerBusy(String value) {
        this.typeOfCustomerBusy = value;
    }

    /**
     * Gets the value of the typeOfCustomerNotInterest property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerNotInterest() {
        return typeOfCustomerNotInterest;
    }

    /**
     * Sets the value of the typeOfCustomerNotInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerNotInterest(String value) {
        this.typeOfCustomerNotInterest = value;
    }

    /**
     * Gets the value of the typeOfCustomerNotContactable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerNotContactable() {
        return typeOfCustomerNotContactable;
    }

    /**
     * Sets the value of the typeOfCustomerNotContactable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerNotContactable(String value) {
        this.typeOfCustomerNotContactable = value;
    }

    /**
     * Gets the value of the typeOfWaiverOnRetention property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfWaiverOnRetention() {
        return typeOfWaiverOnRetention;
    }

    /**
     * Sets the value of the typeOfWaiverOnRetention property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfWaiverOnRetention(String value) {
        this.typeOfWaiverOnRetention = value;
    }

    /**
     * Gets the value of the typeOfCustomerOut property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerOut() {
        return typeOfCustomerOut;
    }

    /**
     * Sets the value of the typeOfCustomerOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerOut(String value) {
        this.typeOfCustomerOut = value;
    }

    /**
     * Gets the value of the typeOfCustomerNA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerNA() {
        return typeOfCustomerNA;
    }

    /**
     * Sets the value of the typeOfCustomerNA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerNA(String value) {
        this.typeOfCustomerNA = value;
    }

    /**
     * Gets the value of the financialAssistance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinancialAssistance() {
        return financialAssistance;
    }

    /**
     * Sets the value of the financialAssistance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinancialAssistance(String value) {
        this.financialAssistance = value;
    }

    /**
     * Gets the value of the assistanceAvailed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssistanceAvailed() {
        return assistanceAvailed;
    }

    /**
     * Sets the value of the assistanceAvailed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssistanceAvailed(String value) {
        this.assistanceAvailed = value;
    }

    /**
     * Gets the value of the typeOfNoFAReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfNoFAReason() {
        return typeOfNoFAReason;
    }

    /**
     * Sets the value of the typeOfNoFAReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfNoFAReason(String value) {
        this.typeOfNoFAReason = value;
    }

    /**
     * Gets the value of the otherDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherDescription() {
        return otherDescription;
    }

    /**
     * Sets the value of the otherDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherDescription(String value) {
        this.otherDescription = value;
    }

    /**
     * Gets the value of the iciciBankAuthenticationOutput property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getICICIBankAuthenticationOutput() {
        return iciciBankAuthenticationOutput;
    }

    /**
     * Sets the value of the iciciBankAuthenticationOutput property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setICICIBankAuthenticationOutput(String value) {
        this.iciciBankAuthenticationOutput = value;
    }

    /**
     * Gets the value of the reasonforApproval property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonforApproval() {
        return reasonforApproval;
    }

    /**
     * Sets the value of the reasonforApproval property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonforApproval(String value) {
        this.reasonforApproval = value;
    }

    /**
     * Gets the value of the prnNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRNNo() {
        return prnNo;
    }

    /**
     * Sets the value of the prnNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRNNo(String value) {
        this.prnNo = value;
    }

    /**
     * Gets the value of the mReprocessing property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMReprocessing() {
        return mReprocessing;
    }

    /**
     * Sets the value of the mReprocessing property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMReprocessing(String value) {
        this.mReprocessing = value;
    }

    /**
     * Gets the value of the lapLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLapLocation() {
        return lapLocation;
    }

    /**
     * Sets the value of the lapLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLapLocation(String value) {
        this.lapLocation = value;
    }

    /**
     * Gets the value of the loanAccountNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanAccountNo() {
        return loanAccountNo;
    }

    /**
     * Sets the value of the loanAccountNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanAccountNo(String value) {
        this.loanAccountNo = value;
    }

}
