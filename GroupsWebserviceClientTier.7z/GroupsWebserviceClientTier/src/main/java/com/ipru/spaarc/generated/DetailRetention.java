
package com.ipru.spaarc.generated;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DetailRetention complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailRetention">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TypeOfRetention" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmpCode1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmpCode2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="ShortPremiumAmount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="RevisedPremiumAmount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="AdditionalRequirement1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdditionalRequirement2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdditionalRequirement3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdditionalRequirement4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdditionalRequirement5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="TypeOfCustomerMeet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerBusy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerNotInterest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerNotContactable" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfWaiverOnRetention" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerOut" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerNA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SurrenderRetained" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lap_Location" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="loanAccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailRetention", propOrder = {
    "typeOfRetention",
    "empCode1",
    "empCode2",
    "agentName",
    "agentCode",
    "isChanged",
    "interactionID",
    "shortPremiumAmount",
    "revisedPremiumAmount",
    "additionalRequirement1",
    "additionalRequirement2",
    "additionalRequirement3",
    "additionalRequirement4",
    "additionalRequirement5",
    "isUpdated",
    "typeOfCustomerMeet",
    "typeOfCustomerBusy",
    "typeOfCustomerNotInterest",
    "typeOfCustomerNotContactable",
    "typeOfWaiverOnRetention",
    "typeOfCustomerOut",
    "typeOfCustomerNA",
    "surrenderRetained",
    "lapLocation",
    "loanAccountNo"
})
public class DetailRetention {

    @XmlElement(name = "TypeOfRetention")
    protected String typeOfRetention;
    @XmlElement(name = "EmpCode1")
    protected String empCode1;
    @XmlElement(name = "EmpCode2")
    protected String empCode2;
    @XmlElement(name = "AgentName")
    protected String agentName;
    @XmlElement(name = "AgentCode")
    protected String agentCode;
    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "ShortPremiumAmount", required = true)
    protected BigDecimal shortPremiumAmount;
    @XmlElement(name = "RevisedPremiumAmount", required = true)
    protected BigDecimal revisedPremiumAmount;
    @XmlElement(name = "AdditionalRequirement1")
    protected String additionalRequirement1;
    @XmlElement(name = "AdditionalRequirement2")
    protected String additionalRequirement2;
    @XmlElement(name = "AdditionalRequirement3")
    protected String additionalRequirement3;
    @XmlElement(name = "AdditionalRequirement4")
    protected String additionalRequirement4;
    @XmlElement(name = "AdditionalRequirement5")
    protected String additionalRequirement5;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "TypeOfCustomerMeet")
    protected String typeOfCustomerMeet;
    @XmlElement(name = "TypeOfCustomerBusy")
    protected String typeOfCustomerBusy;
    @XmlElement(name = "TypeOfCustomerNotInterest")
    protected String typeOfCustomerNotInterest;
    @XmlElement(name = "TypeOfCustomerNotContactable")
    protected String typeOfCustomerNotContactable;
    @XmlElement(name = "TypeOfWaiverOnRetention")
    protected String typeOfWaiverOnRetention;
    @XmlElement(name = "TypeOfCustomerOut")
    protected String typeOfCustomerOut;
    @XmlElement(name = "TypeOfCustomerNA")
    protected String typeOfCustomerNA;
    @XmlElement(name = "SurrenderRetained")
    protected String surrenderRetained;
    @XmlElement(name = "lap_Location")
    protected String lapLocation;
    protected String loanAccountNo;

    /**
     * Gets the value of the typeOfRetention property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfRetention() {
        return typeOfRetention;
    }

    /**
     * Sets the value of the typeOfRetention property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfRetention(String value) {
        this.typeOfRetention = value;
    }

    /**
     * Gets the value of the empCode1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmpCode1() {
        return empCode1;
    }

    /**
     * Sets the value of the empCode1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmpCode1(String value) {
        this.empCode1 = value;
    }

    /**
     * Gets the value of the empCode2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmpCode2() {
        return empCode2;
    }

    /**
     * Sets the value of the empCode2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmpCode2(String value) {
        this.empCode2 = value;
    }

    /**
     * Gets the value of the agentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentName() {
        return agentName;
    }

    /**
     * Sets the value of the agentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentName(String value) {
        this.agentName = value;
    }

    /**
     * Gets the value of the agentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentCode() {
        return agentCode;
    }

    /**
     * Sets the value of the agentCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentCode(String value) {
        this.agentCode = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the shortPremiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getShortPremiumAmount() {
        return shortPremiumAmount;
    }

    /**
     * Sets the value of the shortPremiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setShortPremiumAmount(BigDecimal value) {
        this.shortPremiumAmount = value;
    }

    /**
     * Gets the value of the revisedPremiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getRevisedPremiumAmount() {
        return revisedPremiumAmount;
    }

    /**
     * Sets the value of the revisedPremiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setRevisedPremiumAmount(BigDecimal value) {
        this.revisedPremiumAmount = value;
    }

    /**
     * Gets the value of the additionalRequirement1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalRequirement1() {
        return additionalRequirement1;
    }

    /**
     * Sets the value of the additionalRequirement1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalRequirement1(String value) {
        this.additionalRequirement1 = value;
    }

    /**
     * Gets the value of the additionalRequirement2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalRequirement2() {
        return additionalRequirement2;
    }

    /**
     * Sets the value of the additionalRequirement2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalRequirement2(String value) {
        this.additionalRequirement2 = value;
    }

    /**
     * Gets the value of the additionalRequirement3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalRequirement3() {
        return additionalRequirement3;
    }

    /**
     * Sets the value of the additionalRequirement3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalRequirement3(String value) {
        this.additionalRequirement3 = value;
    }

    /**
     * Gets the value of the additionalRequirement4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalRequirement4() {
        return additionalRequirement4;
    }

    /**
     * Sets the value of the additionalRequirement4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalRequirement4(String value) {
        this.additionalRequirement4 = value;
    }

    /**
     * Gets the value of the additionalRequirement5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalRequirement5() {
        return additionalRequirement5;
    }

    /**
     * Sets the value of the additionalRequirement5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalRequirement5(String value) {
        this.additionalRequirement5 = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the typeOfCustomerMeet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerMeet() {
        return typeOfCustomerMeet;
    }

    /**
     * Sets the value of the typeOfCustomerMeet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerMeet(String value) {
        this.typeOfCustomerMeet = value;
    }

    /**
     * Gets the value of the typeOfCustomerBusy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerBusy() {
        return typeOfCustomerBusy;
    }

    /**
     * Sets the value of the typeOfCustomerBusy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerBusy(String value) {
        this.typeOfCustomerBusy = value;
    }

    /**
     * Gets the value of the typeOfCustomerNotInterest property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerNotInterest() {
        return typeOfCustomerNotInterest;
    }

    /**
     * Sets the value of the typeOfCustomerNotInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerNotInterest(String value) {
        this.typeOfCustomerNotInterest = value;
    }

    /**
     * Gets the value of the typeOfCustomerNotContactable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerNotContactable() {
        return typeOfCustomerNotContactable;
    }

    /**
     * Sets the value of the typeOfCustomerNotContactable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerNotContactable(String value) {
        this.typeOfCustomerNotContactable = value;
    }

    /**
     * Gets the value of the typeOfWaiverOnRetention property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfWaiverOnRetention() {
        return typeOfWaiverOnRetention;
    }

    /**
     * Sets the value of the typeOfWaiverOnRetention property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfWaiverOnRetention(String value) {
        this.typeOfWaiverOnRetention = value;
    }

    /**
     * Gets the value of the typeOfCustomerOut property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerOut() {
        return typeOfCustomerOut;
    }

    /**
     * Sets the value of the typeOfCustomerOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerOut(String value) {
        this.typeOfCustomerOut = value;
    }

    /**
     * Gets the value of the typeOfCustomerNA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerNA() {
        return typeOfCustomerNA;
    }

    /**
     * Sets the value of the typeOfCustomerNA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerNA(String value) {
        this.typeOfCustomerNA = value;
    }

    /**
     * Gets the value of the surrenderRetained property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurrenderRetained() {
        return surrenderRetained;
    }

    /**
     * Sets the value of the surrenderRetained property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurrenderRetained(String value) {
        this.surrenderRetained = value;
    }

    /**
     * Gets the value of the lapLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLapLocation() {
        return lapLocation;
    }

    /**
     * Sets the value of the lapLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLapLocation(String value) {
        this.lapLocation = value;
    }

    /**
     * Gets the value of the loanAccountNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanAccountNo() {
        return loanAccountNo;
    }

    /**
     * Sets the value of the loanAccountNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanAccountNo(String value) {
        this.loanAccountNo = value;
    }

}
