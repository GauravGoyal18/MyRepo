
package com.ipru.spaarc.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOfReOpenedDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfReOpenedDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ReOpenedDetail" type="{http://generated.spaarc.ipru.com/}ReOpenedDetail" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfReOpenedDetail", propOrder = {
    "reOpenedDetail"
})
public class ArrayOfReOpenedDetail {

    @XmlElement(name = "ReOpenedDetail", nillable = true)
    protected List<ReOpenedDetail> reOpenedDetail;

    /**
     * Gets the value of the reOpenedDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reOpenedDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReOpenedDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReOpenedDetail }
     * 
     * 
     */
    public List<ReOpenedDetail> getReOpenedDetail() {
        if (reOpenedDetail == null) {
            reOpenedDetail = new ArrayList<ReOpenedDetail>();
        }
        return this.reOpenedDetail;
    }

}
