
package com.ipru.spaarc.generated;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Detail_S2TTopup complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Detail_S2TTopup">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsSearch" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="TopupType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TopupAmt" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="Decision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SubDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RegularMedicals" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReceiptNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LASignature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdversoryPDR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HtCms" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="HtFt" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="HtInch" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="Wt" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Age" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="TobaccoType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TobaccoQty" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="TobaccoDuration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AlcoholType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AlcoholQty" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="AlcoholDuration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Narcotic" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Change_In_ResiStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Change_In_Avocation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HighRiskOccupation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HighResiStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Payment_Proposer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TPCDocs" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BasicKYC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PEP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EnhancedKYCDone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ListFunds" type="{http://generated.spaarc.ipru.com/}ArrayOfAnyType" minOccurs="0"/>
 *         &lt;element name="TopUpForm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IdProof" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddProof" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Photo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IncomeProof" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PancardCopy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Form60" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Detail_S2TTopup", propOrder = {
    "isSearch",
    "interactionID",
    "topupType",
    "topupAmt",
    "decision",
    "subDecision",
    "regularMedicals",
    "receiptNo",
    "laSignature",
    "adversoryPDR",
    "htCms",
    "htFt",
    "htInch",
    "wt",
    "age",
    "tobaccoType",
    "tobaccoQty",
    "tobaccoDuration",
    "alcoholType",
    "alcoholQty",
    "alcoholDuration",
    "narcotic",
    "changeInResiStatus",
    "changeInAvocation",
    "highRiskOccupation",
    "highResiStatus",
    "paymentProposer",
    "tpcDocs",
    "basicKYC",
    "pep",
    "enhancedKYCDone",
    "isUpdated",
    "listFunds",
    "topUpForm",
    "idProof",
    "addProof",
    "photo",
    "incomeProof",
    "pancardCopy",
    "form60"
})
public class DetailS2TTopup {

    @XmlElement(name = "IsSearch")
    protected boolean isSearch;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "TopupType")
    protected String topupType;
    @XmlElement(name = "TopupAmt", required = true)
    protected BigDecimal topupAmt;
    @XmlElement(name = "Decision")
    protected String decision;
    @XmlElement(name = "SubDecision")
    protected String subDecision;
    @XmlElement(name = "RegularMedicals")
    protected String regularMedicals;
    @XmlElement(name = "ReceiptNo")
    protected String receiptNo;
    @XmlElement(name = "LASignature")
    protected String laSignature;
    @XmlElement(name = "AdversoryPDR")
    protected String adversoryPDR;
    @XmlElement(name = "HtCms", required = true)
    protected BigDecimal htCms;
    @XmlElement(name = "HtFt", required = true)
    protected BigDecimal htFt;
    @XmlElement(name = "HtInch", required = true)
    protected BigDecimal htInch;
    @XmlElement(name = "Wt")
    protected int wt;
    @XmlElement(name = "Age", required = true)
    protected BigDecimal age;
    @XmlElement(name = "TobaccoType")
    protected String tobaccoType;
    @XmlElement(name = "TobaccoQty")
    protected int tobaccoQty;
    @XmlElement(name = "TobaccoDuration")
    protected String tobaccoDuration;
    @XmlElement(name = "AlcoholType")
    protected String alcoholType;
    @XmlElement(name = "AlcoholQty")
    protected int alcoholQty;
    @XmlElement(name = "AlcoholDuration")
    protected String alcoholDuration;
    @XmlElement(name = "Narcotic")
    protected String narcotic;
    @XmlElement(name = "Change_In_ResiStatus")
    protected String changeInResiStatus;
    @XmlElement(name = "Change_In_Avocation")
    protected String changeInAvocation;
    @XmlElement(name = "HighRiskOccupation")
    protected String highRiskOccupation;
    @XmlElement(name = "HighResiStatus")
    protected String highResiStatus;
    @XmlElement(name = "Payment_Proposer")
    protected String paymentProposer;
    @XmlElement(name = "TPCDocs")
    protected String tpcDocs;
    @XmlElement(name = "BasicKYC")
    protected String basicKYC;
    @XmlElement(name = "PEP")
    protected String pep;
    @XmlElement(name = "EnhancedKYCDone")
    protected String enhancedKYCDone;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "ListFunds")
    protected ArrayOfAnyType listFunds;
    @XmlElement(name = "TopUpForm")
    protected String topUpForm;
    @XmlElement(name = "IdProof")
    protected String idProof;
    @XmlElement(name = "AddProof")
    protected String addProof;
    @XmlElement(name = "Photo")
    protected String photo;
    @XmlElement(name = "IncomeProof")
    protected String incomeProof;
    @XmlElement(name = "PancardCopy")
    protected String pancardCopy;
    @XmlElement(name = "Form60")
    protected String form60;

    /**
     * Gets the value of the isSearch property.
     * 
     */
    public boolean isIsSearch() {
        return isSearch;
    }

    /**
     * Sets the value of the isSearch property.
     * 
     */
    public void setIsSearch(boolean value) {
        this.isSearch = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the topupType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTopupType() {
        return topupType;
    }

    /**
     * Sets the value of the topupType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTopupType(String value) {
        this.topupType = value;
    }

    /**
     * Gets the value of the topupAmt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTopupAmt() {
        return topupAmt;
    }

    /**
     * Sets the value of the topupAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTopupAmt(BigDecimal value) {
        this.topupAmt = value;
    }

    /**
     * Gets the value of the decision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecision() {
        return decision;
    }

    /**
     * Sets the value of the decision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecision(String value) {
        this.decision = value;
    }

    /**
     * Gets the value of the subDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubDecision() {
        return subDecision;
    }

    /**
     * Sets the value of the subDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubDecision(String value) {
        this.subDecision = value;
    }

    /**
     * Gets the value of the regularMedicals property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegularMedicals() {
        return regularMedicals;
    }

    /**
     * Sets the value of the regularMedicals property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegularMedicals(String value) {
        this.regularMedicals = value;
    }

    /**
     * Gets the value of the receiptNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptNo() {
        return receiptNo;
    }

    /**
     * Sets the value of the receiptNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptNo(String value) {
        this.receiptNo = value;
    }

    /**
     * Gets the value of the laSignature property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASignature() {
        return laSignature;
    }

    /**
     * Sets the value of the laSignature property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASignature(String value) {
        this.laSignature = value;
    }

    /**
     * Gets the value of the adversoryPDR property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdversoryPDR() {
        return adversoryPDR;
    }

    /**
     * Sets the value of the adversoryPDR property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdversoryPDR(String value) {
        this.adversoryPDR = value;
    }

    /**
     * Gets the value of the htCms property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHtCms() {
        return htCms;
    }

    /**
     * Sets the value of the htCms property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHtCms(BigDecimal value) {
        this.htCms = value;
    }

    /**
     * Gets the value of the htFt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHtFt() {
        return htFt;
    }

    /**
     * Sets the value of the htFt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHtFt(BigDecimal value) {
        this.htFt = value;
    }

    /**
     * Gets the value of the htInch property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHtInch() {
        return htInch;
    }

    /**
     * Sets the value of the htInch property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHtInch(BigDecimal value) {
        this.htInch = value;
    }

    /**
     * Gets the value of the wt property.
     * 
     */
    public int getWt() {
        return wt;
    }

    /**
     * Sets the value of the wt property.
     * 
     */
    public void setWt(int value) {
        this.wt = value;
    }

    /**
     * Gets the value of the age property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAge() {
        return age;
    }

    /**
     * Sets the value of the age property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAge(BigDecimal value) {
        this.age = value;
    }

    /**
     * Gets the value of the tobaccoType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTobaccoType() {
        return tobaccoType;
    }

    /**
     * Sets the value of the tobaccoType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTobaccoType(String value) {
        this.tobaccoType = value;
    }

    /**
     * Gets the value of the tobaccoQty property.
     * 
     */
    public int getTobaccoQty() {
        return tobaccoQty;
    }

    /**
     * Sets the value of the tobaccoQty property.
     * 
     */
    public void setTobaccoQty(int value) {
        this.tobaccoQty = value;
    }

    /**
     * Gets the value of the tobaccoDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTobaccoDuration() {
        return tobaccoDuration;
    }

    /**
     * Sets the value of the tobaccoDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTobaccoDuration(String value) {
        this.tobaccoDuration = value;
    }

    /**
     * Gets the value of the alcoholType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlcoholType() {
        return alcoholType;
    }

    /**
     * Sets the value of the alcoholType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlcoholType(String value) {
        this.alcoholType = value;
    }

    /**
     * Gets the value of the alcoholQty property.
     * 
     */
    public int getAlcoholQty() {
        return alcoholQty;
    }

    /**
     * Sets the value of the alcoholQty property.
     * 
     */
    public void setAlcoholQty(int value) {
        this.alcoholQty = value;
    }

    /**
     * Gets the value of the alcoholDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlcoholDuration() {
        return alcoholDuration;
    }

    /**
     * Sets the value of the alcoholDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlcoholDuration(String value) {
        this.alcoholDuration = value;
    }

    /**
     * Gets the value of the narcotic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNarcotic() {
        return narcotic;
    }

    /**
     * Sets the value of the narcotic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNarcotic(String value) {
        this.narcotic = value;
    }

    /**
     * Gets the value of the changeInResiStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChangeInResiStatus() {
        return changeInResiStatus;
    }

    /**
     * Sets the value of the changeInResiStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChangeInResiStatus(String value) {
        this.changeInResiStatus = value;
    }

    /**
     * Gets the value of the changeInAvocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChangeInAvocation() {
        return changeInAvocation;
    }

    /**
     * Sets the value of the changeInAvocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChangeInAvocation(String value) {
        this.changeInAvocation = value;
    }

    /**
     * Gets the value of the highRiskOccupation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHighRiskOccupation() {
        return highRiskOccupation;
    }

    /**
     * Sets the value of the highRiskOccupation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHighRiskOccupation(String value) {
        this.highRiskOccupation = value;
    }

    /**
     * Gets the value of the highResiStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHighResiStatus() {
        return highResiStatus;
    }

    /**
     * Sets the value of the highResiStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHighResiStatus(String value) {
        this.highResiStatus = value;
    }

    /**
     * Gets the value of the paymentProposer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentProposer() {
        return paymentProposer;
    }

    /**
     * Sets the value of the paymentProposer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentProposer(String value) {
        this.paymentProposer = value;
    }

    /**
     * Gets the value of the tpcDocs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTPCDocs() {
        return tpcDocs;
    }

    /**
     * Sets the value of the tpcDocs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTPCDocs(String value) {
        this.tpcDocs = value;
    }

    /**
     * Gets the value of the basicKYC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasicKYC() {
        return basicKYC;
    }

    /**
     * Sets the value of the basicKYC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasicKYC(String value) {
        this.basicKYC = value;
    }

    /**
     * Gets the value of the pep property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPEP() {
        return pep;
    }

    /**
     * Sets the value of the pep property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPEP(String value) {
        this.pep = value;
    }

    /**
     * Gets the value of the enhancedKYCDone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnhancedKYCDone() {
        return enhancedKYCDone;
    }

    /**
     * Sets the value of the enhancedKYCDone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnhancedKYCDone(String value) {
        this.enhancedKYCDone = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the listFunds property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public ArrayOfAnyType getListFunds() {
        return listFunds;
    }

    /**
     * Sets the value of the listFunds property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public void setListFunds(ArrayOfAnyType value) {
        this.listFunds = value;
    }

    /**
     * Gets the value of the topUpForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTopUpForm() {
        return topUpForm;
    }

    /**
     * Sets the value of the topUpForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTopUpForm(String value) {
        this.topUpForm = value;
    }

    /**
     * Gets the value of the idProof property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdProof() {
        return idProof;
    }

    /**
     * Sets the value of the idProof property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdProof(String value) {
        this.idProof = value;
    }

    /**
     * Gets the value of the addProof property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddProof() {
        return addProof;
    }

    /**
     * Sets the value of the addProof property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddProof(String value) {
        this.addProof = value;
    }

    /**
     * Gets the value of the photo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoto() {
        return photo;
    }

    /**
     * Sets the value of the photo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoto(String value) {
        this.photo = value;
    }

    /**
     * Gets the value of the incomeProof property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncomeProof() {
        return incomeProof;
    }

    /**
     * Sets the value of the incomeProof property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncomeProof(String value) {
        this.incomeProof = value;
    }

    /**
     * Gets the value of the pancardCopy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPancardCopy() {
        return pancardCopy;
    }

    /**
     * Sets the value of the pancardCopy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPancardCopy(String value) {
        this.pancardCopy = value;
    }

    /**
     * Gets the value of the form60 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForm60() {
        return form60;
    }

    /**
     * Sets the value of the form60 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForm60(String value) {
        this.form60 = value;
    }

}
