
package com.ipru.spaarc.generated;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DetailChequePickup complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailChequePickup">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="Address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ContactNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="TimeRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailChequePickup", propOrder = {
    "isChanged",
    "interactionID",
    "address",
    "contactNumber",
    "amount",
    "date",
    "timeRange",
    "isUpdated"
})
public class DetailChequePickup {

    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "Address")
    protected String address;
    @XmlElement(name = "ContactNumber")
    protected String contactNumber;
    @XmlElement(name = "Amount", required = true)
    protected BigDecimal amount;
    @XmlElement(name = "Date", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar date;
    @XmlElement(name = "TimeRange")
    protected String timeRange;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * Gets the value of the contactNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactNumber() {
        return contactNumber;
    }

    /**
     * Sets the value of the contactNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactNumber(String value) {
        this.contactNumber = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmount(BigDecimal value) {
        this.amount = value;
    }

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDate(XMLGregorianCalendar value) {
        this.date = value;
    }

    /**
     * Gets the value of the timeRange property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimeRange() {
        return timeRange;
    }

    /**
     * Sets the value of the timeRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimeRange(String value) {
        this.timeRange = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

}
