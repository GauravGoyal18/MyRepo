
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DetailPolicyCharacteristics complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailPolicyCharacteristics">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="ChangesToBeDone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OldValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NewValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DocsDispatchedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="DocsRecievedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="UnderWriting" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SignatureVerification" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Frequency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="FrequencyDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="RelationCriteria" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LARiskFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PaymentMethod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PaymentType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequeNo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ReceiptNo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ChequeAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="ReceiptDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="BranchCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OthersReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LoanAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lap_Location" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="loanAccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailPolicyCharacteristics", propOrder = {
    "isChanged",
    "interactionID",
    "changesToBeDone",
    "oldValue",
    "newValue",
    "docsDispatchedDate",
    "docsRecievedDate",
    "underWriting",
    "signatureVerification",
    "frequency",
    "isUpdated",
    "frequencyDate",
    "relationCriteria",
    "laRiskFlag",
    "paymentMethod",
    "paymentType",
    "chequeNo",
    "receiptNo",
    "chequeAmount",
    "receiptDate",
    "branchCode",
    "othersReason",
    "loanAmount",
    "lapLocation",
    "loanAccountNo"
})
public class DetailPolicyCharacteristics {

    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "ChangesToBeDone")
    protected String changesToBeDone;
    @XmlElement(name = "OldValue")
    protected String oldValue;
    @XmlElement(name = "NewValue")
    protected String newValue;
    @XmlElement(name = "DocsDispatchedDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar docsDispatchedDate;
    @XmlElement(name = "DocsRecievedDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar docsRecievedDate;
    @XmlElement(name = "UnderWriting")
    protected String underWriting;
    @XmlElement(name = "SignatureVerification")
    protected String signatureVerification;
    @XmlElement(name = "Frequency")
    protected String frequency;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "FrequencyDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar frequencyDate;
    @XmlElement(name = "RelationCriteria")
    protected String relationCriteria;
    @XmlElement(name = "LARiskFlag")
    protected String laRiskFlag;
    @XmlElement(name = "PaymentMethod")
    protected String paymentMethod;
    @XmlElement(name = "PaymentType")
    protected String paymentType;
    @XmlElement(name = "ChequeNo")
    protected int chequeNo;
    @XmlElement(name = "ReceiptNo")
    protected int receiptNo;
    @XmlElement(name = "ChequeAmount")
    protected double chequeAmount;
    @XmlElement(name = "ReceiptDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar receiptDate;
    @XmlElement(name = "BranchCode")
    protected String branchCode;
    @XmlElement(name = "OthersReason")
    protected String othersReason;
    @XmlElement(name = "LoanAmount")
    protected String loanAmount;
    @XmlElement(name = "lap_Location")
    protected String lapLocation;
    protected String loanAccountNo;

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the changesToBeDone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChangesToBeDone() {
        return changesToBeDone;
    }

    /**
     * Sets the value of the changesToBeDone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChangesToBeDone(String value) {
        this.changesToBeDone = value;
    }

    /**
     * Gets the value of the oldValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldValue() {
        return oldValue;
    }

    /**
     * Sets the value of the oldValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldValue(String value) {
        this.oldValue = value;
    }

    /**
     * Gets the value of the newValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewValue() {
        return newValue;
    }

    /**
     * Sets the value of the newValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewValue(String value) {
        this.newValue = value;
    }

    /**
     * Gets the value of the docsDispatchedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDocsDispatchedDate() {
        return docsDispatchedDate;
    }

    /**
     * Sets the value of the docsDispatchedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDocsDispatchedDate(XMLGregorianCalendar value) {
        this.docsDispatchedDate = value;
    }

    /**
     * Gets the value of the docsRecievedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDocsRecievedDate() {
        return docsRecievedDate;
    }

    /**
     * Sets the value of the docsRecievedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDocsRecievedDate(XMLGregorianCalendar value) {
        this.docsRecievedDate = value;
    }

    /**
     * Gets the value of the underWriting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnderWriting() {
        return underWriting;
    }

    /**
     * Sets the value of the underWriting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnderWriting(String value) {
        this.underWriting = value;
    }

    /**
     * Gets the value of the signatureVerification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignatureVerification() {
        return signatureVerification;
    }

    /**
     * Sets the value of the signatureVerification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignatureVerification(String value) {
        this.signatureVerification = value;
    }

    /**
     * Gets the value of the frequency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrequency() {
        return frequency;
    }

    /**
     * Sets the value of the frequency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrequency(String value) {
        this.frequency = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the frequencyDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFrequencyDate() {
        return frequencyDate;
    }

    /**
     * Sets the value of the frequencyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFrequencyDate(XMLGregorianCalendar value) {
        this.frequencyDate = value;
    }

    /**
     * Gets the value of the relationCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationCriteria() {
        return relationCriteria;
    }

    /**
     * Sets the value of the relationCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationCriteria(String value) {
        this.relationCriteria = value;
    }

    /**
     * Gets the value of the laRiskFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLARiskFlag() {
        return laRiskFlag;
    }

    /**
     * Sets the value of the laRiskFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLARiskFlag(String value) {
        this.laRiskFlag = value;
    }

    /**
     * Gets the value of the paymentMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * Sets the value of the paymentMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentMethod(String value) {
        this.paymentMethod = value;
    }

    /**
     * Gets the value of the paymentType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentType() {
        return paymentType;
    }

    /**
     * Sets the value of the paymentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentType(String value) {
        this.paymentType = value;
    }

    /**
     * Gets the value of the chequeNo property.
     * 
     */
    public int getChequeNo() {
        return chequeNo;
    }

    /**
     * Sets the value of the chequeNo property.
     * 
     */
    public void setChequeNo(int value) {
        this.chequeNo = value;
    }

    /**
     * Gets the value of the receiptNo property.
     * 
     */
    public int getReceiptNo() {
        return receiptNo;
    }

    /**
     * Sets the value of the receiptNo property.
     * 
     */
    public void setReceiptNo(int value) {
        this.receiptNo = value;
    }

    /**
     * Gets the value of the chequeAmount property.
     * 
     */
    public double getChequeAmount() {
        return chequeAmount;
    }

    /**
     * Sets the value of the chequeAmount property.
     * 
     */
    public void setChequeAmount(double value) {
        this.chequeAmount = value;
    }

    /**
     * Gets the value of the receiptDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceiptDate() {
        return receiptDate;
    }

    /**
     * Sets the value of the receiptDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReceiptDate(XMLGregorianCalendar value) {
        this.receiptDate = value;
    }

    /**
     * Gets the value of the branchCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchCode() {
        return branchCode;
    }

    /**
     * Sets the value of the branchCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchCode(String value) {
        this.branchCode = value;
    }

    /**
     * Gets the value of the othersReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthersReason() {
        return othersReason;
    }

    /**
     * Sets the value of the othersReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthersReason(String value) {
        this.othersReason = value;
    }

    /**
     * Gets the value of the loanAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanAmount() {
        return loanAmount;
    }

    /**
     * Sets the value of the loanAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanAmount(String value) {
        this.loanAmount = value;
    }

    /**
     * Gets the value of the lapLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLapLocation() {
        return lapLocation;
    }

    /**
     * Sets the value of the lapLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLapLocation(String value) {
        this.lapLocation = value;
    }

    /**
     * Gets the value of the loanAccountNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanAccountNo() {
        return loanAccountNo;
    }

    /**
     * Sets the value of the loanAccountNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanAccountNo(String value) {
        this.loanAccountNo = value;
    }

}
