
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ReOpenedDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReOpenedDetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PLVCPIVCWC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PLVCPIVCFindings" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DecScreen" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FinalDescReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DecisionTaken_Text" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DecisionTaken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdvisorActive" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ActionToBeTaken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ActionRemarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReopenedSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndexReOpened" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ReOpenedDetailID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="Reference2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Owner2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReopenedDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReOpenedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReOpenedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="TypeOfDisposal2" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ExpectedClosureDate2" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IsClosed" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsReOpened" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ClosureType2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReOpenedClosedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ReOpenedClosedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReopenedClosedDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastUpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonForRepeat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChangeInDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonForChange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastUpdatedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IsAcknowledge" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ErringTeam" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AllotedID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReOpenedDetail", propOrder = {
    "plvcpivcwc",
    "plvcpivcFindings",
    "decScreen",
    "finalDescReason",
    "decisionTakenText",
    "decisionTaken",
    "advisorActive",
    "actionToBeTaken",
    "actionRemarks",
    "reopenedSource",
    "indexReOpened",
    "reOpenedDetailID",
    "interactionID",
    "reference2",
    "owner2",
    "reopenedDesc",
    "reOpenedBy",
    "reOpenedDateTime",
    "typeOfDisposal2",
    "expectedClosureDate2",
    "isClosed",
    "isReOpened",
    "closureType2",
    "reOpenedClosedDateTime",
    "reOpenedClosedBy",
    "reopenedClosedDesc",
    "lastUpdatedBy",
    "reasonForRepeat",
    "changeInDecision",
    "reasonForChange",
    "lastUpdatedDateTime",
    "isAcknowledge",
    "erringTeam",
    "allotedID"
})
public class ReOpenedDetail {

    @XmlElement(name = "PLVCPIVCWC")
    protected String plvcpivcwc;
    @XmlElement(name = "PLVCPIVCFindings")
    protected String plvcpivcFindings;
    @XmlElement(name = "DecScreen")
    protected String decScreen;
    @XmlElement(name = "FinalDescReason")
    protected String finalDescReason;
    @XmlElement(name = "DecisionTaken_Text")
    protected String decisionTakenText;
    @XmlElement(name = "DecisionTaken")
    protected String decisionTaken;
    @XmlElement(name = "AdvisorActive")
    protected String advisorActive;
    @XmlElement(name = "ActionToBeTaken")
    protected String actionToBeTaken;
    @XmlElement(name = "ActionRemarks")
    protected String actionRemarks;
    @XmlElement(name = "ReopenedSource")
    protected String reopenedSource;
    @XmlElement(name = "IndexReOpened")
    protected int indexReOpened;
    @XmlElement(name = "ReOpenedDetailID")
    protected long reOpenedDetailID;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "Reference2")
    protected String reference2;
    @XmlElement(name = "Owner2")
    protected String owner2;
    @XmlElement(name = "ReopenedDesc")
    protected String reopenedDesc;
    @XmlElement(name = "ReOpenedBy")
    protected String reOpenedBy;
    @XmlElement(name = "ReOpenedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar reOpenedDateTime;
    @XmlElement(name = "TypeOfDisposal2")
    protected int typeOfDisposal2;
    @XmlElement(name = "ExpectedClosureDate2", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar expectedClosureDate2;
    @XmlElement(name = "IsClosed")
    protected boolean isClosed;
    @XmlElement(name = "IsReOpened")
    protected boolean isReOpened;
    @XmlElement(name = "ClosureType2")
    protected String closureType2;
    @XmlElement(name = "ReOpenedClosedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar reOpenedClosedDateTime;
    @XmlElement(name = "ReOpenedClosedBy")
    protected String reOpenedClosedBy;
    @XmlElement(name = "ReopenedClosedDesc")
    protected String reopenedClosedDesc;
    @XmlElement(name = "LastUpdatedBy")
    protected String lastUpdatedBy;
    @XmlElement(name = "ReasonForRepeat")
    protected String reasonForRepeat;
    @XmlElement(name = "ChangeInDecision")
    protected String changeInDecision;
    @XmlElement(name = "ReasonForChange")
    protected String reasonForChange;
    @XmlElement(name = "LastUpdatedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastUpdatedDateTime;
    @XmlElement(name = "IsAcknowledge")
    protected boolean isAcknowledge;
    @XmlElement(name = "ErringTeam")
    protected String erringTeam;
    @XmlElement(name = "AllotedID")
    protected String allotedID;

    /**
     * Gets the value of the plvcpivcwc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLVCPIVCWC() {
        return plvcpivcwc;
    }

    /**
     * Sets the value of the plvcpivcwc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLVCPIVCWC(String value) {
        this.plvcpivcwc = value;
    }

    /**
     * Gets the value of the plvcpivcFindings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLVCPIVCFindings() {
        return plvcpivcFindings;
    }

    /**
     * Sets the value of the plvcpivcFindings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLVCPIVCFindings(String value) {
        this.plvcpivcFindings = value;
    }

    /**
     * Gets the value of the decScreen property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecScreen() {
        return decScreen;
    }

    /**
     * Sets the value of the decScreen property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecScreen(String value) {
        this.decScreen = value;
    }

    /**
     * Gets the value of the finalDescReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinalDescReason() {
        return finalDescReason;
    }

    /**
     * Sets the value of the finalDescReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinalDescReason(String value) {
        this.finalDescReason = value;
    }

    /**
     * Gets the value of the decisionTakenText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionTakenText() {
        return decisionTakenText;
    }

    /**
     * Sets the value of the decisionTakenText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionTakenText(String value) {
        this.decisionTakenText = value;
    }

    /**
     * Gets the value of the decisionTaken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionTaken() {
        return decisionTaken;
    }

    /**
     * Sets the value of the decisionTaken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionTaken(String value) {
        this.decisionTaken = value;
    }

    /**
     * Gets the value of the advisorActive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdvisorActive() {
        return advisorActive;
    }

    /**
     * Sets the value of the advisorActive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdvisorActive(String value) {
        this.advisorActive = value;
    }

    /**
     * Gets the value of the actionToBeTaken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionToBeTaken() {
        return actionToBeTaken;
    }

    /**
     * Sets the value of the actionToBeTaken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionToBeTaken(String value) {
        this.actionToBeTaken = value;
    }

    /**
     * Gets the value of the actionRemarks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionRemarks() {
        return actionRemarks;
    }

    /**
     * Sets the value of the actionRemarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionRemarks(String value) {
        this.actionRemarks = value;
    }

    /**
     * Gets the value of the reopenedSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReopenedSource() {
        return reopenedSource;
    }

    /**
     * Sets the value of the reopenedSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReopenedSource(String value) {
        this.reopenedSource = value;
    }

    /**
     * Gets the value of the indexReOpened property.
     * 
     */
    public int getIndexReOpened() {
        return indexReOpened;
    }

    /**
     * Sets the value of the indexReOpened property.
     * 
     */
    public void setIndexReOpened(int value) {
        this.indexReOpened = value;
    }

    /**
     * Gets the value of the reOpenedDetailID property.
     * 
     */
    public long getReOpenedDetailID() {
        return reOpenedDetailID;
    }

    /**
     * Sets the value of the reOpenedDetailID property.
     * 
     */
    public void setReOpenedDetailID(long value) {
        this.reOpenedDetailID = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the reference2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReference2() {
        return reference2;
    }

    /**
     * Sets the value of the reference2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReference2(String value) {
        this.reference2 = value;
    }

    /**
     * Gets the value of the owner2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOwner2() {
        return owner2;
    }

    /**
     * Sets the value of the owner2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOwner2(String value) {
        this.owner2 = value;
    }

    /**
     * Gets the value of the reopenedDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReopenedDesc() {
        return reopenedDesc;
    }

    /**
     * Sets the value of the reopenedDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReopenedDesc(String value) {
        this.reopenedDesc = value;
    }

    /**
     * Gets the value of the reOpenedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReOpenedBy() {
        return reOpenedBy;
    }

    /**
     * Sets the value of the reOpenedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReOpenedBy(String value) {
        this.reOpenedBy = value;
    }

    /**
     * Gets the value of the reOpenedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReOpenedDateTime() {
        return reOpenedDateTime;
    }

    /**
     * Sets the value of the reOpenedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReOpenedDateTime(XMLGregorianCalendar value) {
        this.reOpenedDateTime = value;
    }

    /**
     * Gets the value of the typeOfDisposal2 property.
     * 
     */
    public int getTypeOfDisposal2() {
        return typeOfDisposal2;
    }

    /**
     * Sets the value of the typeOfDisposal2 property.
     * 
     */
    public void setTypeOfDisposal2(int value) {
        this.typeOfDisposal2 = value;
    }

    /**
     * Gets the value of the expectedClosureDate2 property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getExpectedClosureDate2() {
        return expectedClosureDate2;
    }

    /**
     * Sets the value of the expectedClosureDate2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setExpectedClosureDate2(XMLGregorianCalendar value) {
        this.expectedClosureDate2 = value;
    }

    /**
     * Gets the value of the isClosed property.
     * 
     */
    public boolean isIsClosed() {
        return isClosed;
    }

    /**
     * Sets the value of the isClosed property.
     * 
     */
    public void setIsClosed(boolean value) {
        this.isClosed = value;
    }

    /**
     * Gets the value of the isReOpened property.
     * 
     */
    public boolean isIsReOpened() {
        return isReOpened;
    }

    /**
     * Sets the value of the isReOpened property.
     * 
     */
    public void setIsReOpened(boolean value) {
        this.isReOpened = value;
    }

    /**
     * Gets the value of the closureType2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClosureType2() {
        return closureType2;
    }

    /**
     * Sets the value of the closureType2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosureType2(String value) {
        this.closureType2 = value;
    }

    /**
     * Gets the value of the reOpenedClosedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReOpenedClosedDateTime() {
        return reOpenedClosedDateTime;
    }

    /**
     * Sets the value of the reOpenedClosedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReOpenedClosedDateTime(XMLGregorianCalendar value) {
        this.reOpenedClosedDateTime = value;
    }

    /**
     * Gets the value of the reOpenedClosedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReOpenedClosedBy() {
        return reOpenedClosedBy;
    }

    /**
     * Sets the value of the reOpenedClosedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReOpenedClosedBy(String value) {
        this.reOpenedClosedBy = value;
    }

    /**
     * Gets the value of the reopenedClosedDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReopenedClosedDesc() {
        return reopenedClosedDesc;
    }

    /**
     * Sets the value of the reopenedClosedDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReopenedClosedDesc(String value) {
        this.reopenedClosedDesc = value;
    }

    /**
     * Gets the value of the lastUpdatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    /**
     * Sets the value of the lastUpdatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastUpdatedBy(String value) {
        this.lastUpdatedBy = value;
    }

    /**
     * Gets the value of the reasonForRepeat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonForRepeat() {
        return reasonForRepeat;
    }

    /**
     * Sets the value of the reasonForRepeat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonForRepeat(String value) {
        this.reasonForRepeat = value;
    }

    /**
     * Gets the value of the changeInDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChangeInDecision() {
        return changeInDecision;
    }

    /**
     * Sets the value of the changeInDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChangeInDecision(String value) {
        this.changeInDecision = value;
    }

    /**
     * Gets the value of the reasonForChange property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonForChange() {
        return reasonForChange;
    }

    /**
     * Sets the value of the reasonForChange property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonForChange(String value) {
        this.reasonForChange = value;
    }

    /**
     * Gets the value of the lastUpdatedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    /**
     * Sets the value of the lastUpdatedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdatedDateTime(XMLGregorianCalendar value) {
        this.lastUpdatedDateTime = value;
    }

    /**
     * Gets the value of the isAcknowledge property.
     * 
     */
    public boolean isIsAcknowledge() {
        return isAcknowledge;
    }

    /**
     * Sets the value of the isAcknowledge property.
     * 
     */
    public void setIsAcknowledge(boolean value) {
        this.isAcknowledge = value;
    }

    /**
     * Gets the value of the erringTeam property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErringTeam() {
        return erringTeam;
    }

    /**
     * Sets the value of the erringTeam property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErringTeam(String value) {
        this.erringTeam = value;
    }

    /**
     * Gets the value of the allotedID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllotedID() {
        return allotedID;
    }

    /**
     * Sets the value of the allotedID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllotedID(String value) {
        this.allotedID = value;
    }

}
