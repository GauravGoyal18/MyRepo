
package com.ipru.spaarc.generated;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Detail_PDRMedical complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Detail_PDRMedical">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SubDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Decision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RegularMedicals" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReceiptNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LASignature" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="AdversoryPDR" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="HtCms" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="HtFt" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="HtInch" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="Wt" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="Age" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="TobaccoType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TobaccoQty" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="TobaccoDuration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AlcoholType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AlcoholQty" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="AlcoholDuration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Narcotic" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Change_In_ResiStatus" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Change_In_Avocation" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="CaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="PDRFormRecieved" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MedicalFormRecieved" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TotalOutPremiumReciept" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ActionRequired" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StopPayment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransferAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Decrease_PremiumStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DecreasePremium" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PremiumAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Frequency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RequestForm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequeStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequePRNNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequeNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequeAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndPRNNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndChequeNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StaleStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StalePRNNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StaleChequeNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StaleAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExceptionStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExceptionPRNNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExceptionChequeNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExceptionAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Detail_PDRMedical", propOrder = {
    "subDecision",
    "decision",
    "regularMedicals",
    "receiptNo",
    "laSignature",
    "adversoryPDR",
    "htCms",
    "htFt",
    "htInch",
    "wt",
    "age",
    "tobaccoType",
    "tobaccoQty",
    "tobaccoDuration",
    "alcoholType",
    "alcoholQty",
    "alcoholDuration",
    "narcotic",
    "changeInResiStatus",
    "changeInAvocation",
    "interactionID",
    "caseType",
    "isUpdated",
    "pdrFormRecieved",
    "medicalFormRecieved",
    "totalOutPremiumReciept",
    "actionRequired",
    "stopPayment",
    "transferAmount",
    "decreasePremiumStatus",
    "decreasePremium",
    "premiumAmount",
    "frequency",
    "requestForm",
    "chequeStatus",
    "chequePRNNo",
    "chequeNo",
    "chequeAmount",
    "indStatus",
    "indPRNNo",
    "indChequeNo",
    "indAmount",
    "staleStatus",
    "stalePRNNo",
    "staleChequeNo",
    "staleAmount",
    "exceptionStatus",
    "exceptionPRNNo",
    "exceptionChequeNo",
    "exceptionAmount"
})
public class DetailPDRMedical {

    @XmlElement(name = "SubDecision")
    protected String subDecision;
    @XmlElement(name = "Decision")
    protected String decision;
    @XmlElement(name = "RegularMedicals")
    protected String regularMedicals;
    @XmlElement(name = "ReceiptNo")
    protected String receiptNo;
    @XmlElement(name = "LASignature")
    protected boolean laSignature;
    @XmlElement(name = "AdversoryPDR")
    protected boolean adversoryPDR;
    @XmlElement(name = "HtCms", required = true)
    protected BigDecimal htCms;
    @XmlElement(name = "HtFt", required = true)
    protected BigDecimal htFt;
    @XmlElement(name = "HtInch", required = true)
    protected BigDecimal htInch;
    @XmlElement(name = "Wt", required = true)
    protected BigDecimal wt;
    @XmlElement(name = "Age", required = true)
    protected BigDecimal age;
    @XmlElement(name = "TobaccoType")
    protected String tobaccoType;
    @XmlElement(name = "TobaccoQty")
    protected int tobaccoQty;
    @XmlElement(name = "TobaccoDuration")
    protected String tobaccoDuration;
    @XmlElement(name = "AlcoholType")
    protected String alcoholType;
    @XmlElement(name = "AlcoholQty")
    protected int alcoholQty;
    @XmlElement(name = "AlcoholDuration")
    protected String alcoholDuration;
    @XmlElement(name = "Narcotic")
    protected boolean narcotic;
    @XmlElement(name = "Change_In_ResiStatus")
    protected boolean changeInResiStatus;
    @XmlElement(name = "Change_In_Avocation")
    protected boolean changeInAvocation;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "CaseType")
    protected String caseType;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "PDRFormRecieved")
    protected String pdrFormRecieved;
    @XmlElement(name = "MedicalFormRecieved")
    protected String medicalFormRecieved;
    @XmlElement(name = "TotalOutPremiumReciept")
    protected String totalOutPremiumReciept;
    @XmlElement(name = "ActionRequired")
    protected String actionRequired;
    @XmlElement(name = "StopPayment")
    protected String stopPayment;
    @XmlElement(name = "TransferAmount")
    protected String transferAmount;
    @XmlElement(name = "Decrease_PremiumStatus")
    protected String decreasePremiumStatus;
    @XmlElement(name = "DecreasePremium")
    protected String decreasePremium;
    @XmlElement(name = "PremiumAmount")
    protected String premiumAmount;
    @XmlElement(name = "Frequency")
    protected String frequency;
    @XmlElement(name = "RequestForm")
    protected String requestForm;
    @XmlElement(name = "ChequeStatus")
    protected String chequeStatus;
    @XmlElement(name = "ChequePRNNo")
    protected String chequePRNNo;
    @XmlElement(name = "ChequeNo")
    protected String chequeNo;
    @XmlElement(name = "ChequeAmount")
    protected String chequeAmount;
    @XmlElement(name = "IndStatus")
    protected String indStatus;
    @XmlElement(name = "IndPRNNo")
    protected String indPRNNo;
    @XmlElement(name = "IndChequeNo")
    protected String indChequeNo;
    @XmlElement(name = "IndAmount")
    protected String indAmount;
    @XmlElement(name = "StaleStatus")
    protected String staleStatus;
    @XmlElement(name = "StalePRNNo")
    protected String stalePRNNo;
    @XmlElement(name = "StaleChequeNo")
    protected String staleChequeNo;
    @XmlElement(name = "StaleAmount")
    protected String staleAmount;
    @XmlElement(name = "ExceptionStatus")
    protected String exceptionStatus;
    @XmlElement(name = "ExceptionPRNNo")
    protected String exceptionPRNNo;
    @XmlElement(name = "ExceptionChequeNo")
    protected String exceptionChequeNo;
    @XmlElement(name = "ExceptionAmount")
    protected String exceptionAmount;

    /**
     * Gets the value of the subDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubDecision() {
        return subDecision;
    }

    /**
     * Sets the value of the subDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubDecision(String value) {
        this.subDecision = value;
    }

    /**
     * Gets the value of the decision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecision() {
        return decision;
    }

    /**
     * Sets the value of the decision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecision(String value) {
        this.decision = value;
    }

    /**
     * Gets the value of the regularMedicals property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegularMedicals() {
        return regularMedicals;
    }

    /**
     * Sets the value of the regularMedicals property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegularMedicals(String value) {
        this.regularMedicals = value;
    }

    /**
     * Gets the value of the receiptNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptNo() {
        return receiptNo;
    }

    /**
     * Sets the value of the receiptNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptNo(String value) {
        this.receiptNo = value;
    }

    /**
     * Gets the value of the laSignature property.
     * 
     */
    public boolean isLASignature() {
        return laSignature;
    }

    /**
     * Sets the value of the laSignature property.
     * 
     */
    public void setLASignature(boolean value) {
        this.laSignature = value;
    }

    /**
     * Gets the value of the adversoryPDR property.
     * 
     */
    public boolean isAdversoryPDR() {
        return adversoryPDR;
    }

    /**
     * Sets the value of the adversoryPDR property.
     * 
     */
    public void setAdversoryPDR(boolean value) {
        this.adversoryPDR = value;
    }

    /**
     * Gets the value of the htCms property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHtCms() {
        return htCms;
    }

    /**
     * Sets the value of the htCms property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHtCms(BigDecimal value) {
        this.htCms = value;
    }

    /**
     * Gets the value of the htFt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHtFt() {
        return htFt;
    }

    /**
     * Sets the value of the htFt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHtFt(BigDecimal value) {
        this.htFt = value;
    }

    /**
     * Gets the value of the htInch property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getHtInch() {
        return htInch;
    }

    /**
     * Sets the value of the htInch property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setHtInch(BigDecimal value) {
        this.htInch = value;
    }

    /**
     * Gets the value of the wt property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getWt() {
        return wt;
    }

    /**
     * Sets the value of the wt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setWt(BigDecimal value) {
        this.wt = value;
    }

    /**
     * Gets the value of the age property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAge() {
        return age;
    }

    /**
     * Sets the value of the age property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAge(BigDecimal value) {
        this.age = value;
    }

    /**
     * Gets the value of the tobaccoType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTobaccoType() {
        return tobaccoType;
    }

    /**
     * Sets the value of the tobaccoType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTobaccoType(String value) {
        this.tobaccoType = value;
    }

    /**
     * Gets the value of the tobaccoQty property.
     * 
     */
    public int getTobaccoQty() {
        return tobaccoQty;
    }

    /**
     * Sets the value of the tobaccoQty property.
     * 
     */
    public void setTobaccoQty(int value) {
        this.tobaccoQty = value;
    }

    /**
     * Gets the value of the tobaccoDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTobaccoDuration() {
        return tobaccoDuration;
    }

    /**
     * Sets the value of the tobaccoDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTobaccoDuration(String value) {
        this.tobaccoDuration = value;
    }

    /**
     * Gets the value of the alcoholType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlcoholType() {
        return alcoholType;
    }

    /**
     * Sets the value of the alcoholType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlcoholType(String value) {
        this.alcoholType = value;
    }

    /**
     * Gets the value of the alcoholQty property.
     * 
     */
    public int getAlcoholQty() {
        return alcoholQty;
    }

    /**
     * Sets the value of the alcoholQty property.
     * 
     */
    public void setAlcoholQty(int value) {
        this.alcoholQty = value;
    }

    /**
     * Gets the value of the alcoholDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlcoholDuration() {
        return alcoholDuration;
    }

    /**
     * Sets the value of the alcoholDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlcoholDuration(String value) {
        this.alcoholDuration = value;
    }

    /**
     * Gets the value of the narcotic property.
     * 
     */
    public boolean isNarcotic() {
        return narcotic;
    }

    /**
     * Sets the value of the narcotic property.
     * 
     */
    public void setNarcotic(boolean value) {
        this.narcotic = value;
    }

    /**
     * Gets the value of the changeInResiStatus property.
     * 
     */
    public boolean isChangeInResiStatus() {
        return changeInResiStatus;
    }

    /**
     * Sets the value of the changeInResiStatus property.
     * 
     */
    public void setChangeInResiStatus(boolean value) {
        this.changeInResiStatus = value;
    }

    /**
     * Gets the value of the changeInAvocation property.
     * 
     */
    public boolean isChangeInAvocation() {
        return changeInAvocation;
    }

    /**
     * Sets the value of the changeInAvocation property.
     * 
     */
    public void setChangeInAvocation(boolean value) {
        this.changeInAvocation = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the caseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaseType() {
        return caseType;
    }

    /**
     * Sets the value of the caseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaseType(String value) {
        this.caseType = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the pdrFormRecieved property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDRFormRecieved() {
        return pdrFormRecieved;
    }

    /**
     * Sets the value of the pdrFormRecieved property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDRFormRecieved(String value) {
        this.pdrFormRecieved = value;
    }

    /**
     * Gets the value of the medicalFormRecieved property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicalFormRecieved() {
        return medicalFormRecieved;
    }

    /**
     * Sets the value of the medicalFormRecieved property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicalFormRecieved(String value) {
        this.medicalFormRecieved = value;
    }

    /**
     * Gets the value of the totalOutPremiumReciept property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalOutPremiumReciept() {
        return totalOutPremiumReciept;
    }

    /**
     * Sets the value of the totalOutPremiumReciept property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalOutPremiumReciept(String value) {
        this.totalOutPremiumReciept = value;
    }

    /**
     * Gets the value of the actionRequired property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionRequired() {
        return actionRequired;
    }

    /**
     * Sets the value of the actionRequired property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionRequired(String value) {
        this.actionRequired = value;
    }

    /**
     * Gets the value of the stopPayment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStopPayment() {
        return stopPayment;
    }

    /**
     * Sets the value of the stopPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStopPayment(String value) {
        this.stopPayment = value;
    }

    /**
     * Gets the value of the transferAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransferAmount() {
        return transferAmount;
    }

    /**
     * Sets the value of the transferAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransferAmount(String value) {
        this.transferAmount = value;
    }

    /**
     * Gets the value of the decreasePremiumStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecreasePremiumStatus() {
        return decreasePremiumStatus;
    }

    /**
     * Sets the value of the decreasePremiumStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecreasePremiumStatus(String value) {
        this.decreasePremiumStatus = value;
    }

    /**
     * Gets the value of the decreasePremium property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecreasePremium() {
        return decreasePremium;
    }

    /**
     * Sets the value of the decreasePremium property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecreasePremium(String value) {
        this.decreasePremium = value;
    }

    /**
     * Gets the value of the premiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremiumAmount() {
        return premiumAmount;
    }

    /**
     * Sets the value of the premiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremiumAmount(String value) {
        this.premiumAmount = value;
    }

    /**
     * Gets the value of the frequency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrequency() {
        return frequency;
    }

    /**
     * Sets the value of the frequency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrequency(String value) {
        this.frequency = value;
    }

    /**
     * Gets the value of the requestForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestForm() {
        return requestForm;
    }

    /**
     * Sets the value of the requestForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestForm(String value) {
        this.requestForm = value;
    }

    /**
     * Gets the value of the chequeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequeStatus() {
        return chequeStatus;
    }

    /**
     * Sets the value of the chequeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequeStatus(String value) {
        this.chequeStatus = value;
    }

    /**
     * Gets the value of the chequePRNNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequePRNNo() {
        return chequePRNNo;
    }

    /**
     * Sets the value of the chequePRNNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequePRNNo(String value) {
        this.chequePRNNo = value;
    }

    /**
     * Gets the value of the chequeNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequeNo() {
        return chequeNo;
    }

    /**
     * Sets the value of the chequeNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequeNo(String value) {
        this.chequeNo = value;
    }

    /**
     * Gets the value of the chequeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequeAmount() {
        return chequeAmount;
    }

    /**
     * Sets the value of the chequeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequeAmount(String value) {
        this.chequeAmount = value;
    }

    /**
     * Gets the value of the indStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndStatus() {
        return indStatus;
    }

    /**
     * Sets the value of the indStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndStatus(String value) {
        this.indStatus = value;
    }

    /**
     * Gets the value of the indPRNNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndPRNNo() {
        return indPRNNo;
    }

    /**
     * Sets the value of the indPRNNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndPRNNo(String value) {
        this.indPRNNo = value;
    }

    /**
     * Gets the value of the indChequeNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndChequeNo() {
        return indChequeNo;
    }

    /**
     * Sets the value of the indChequeNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndChequeNo(String value) {
        this.indChequeNo = value;
    }

    /**
     * Gets the value of the indAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndAmount() {
        return indAmount;
    }

    /**
     * Sets the value of the indAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndAmount(String value) {
        this.indAmount = value;
    }

    /**
     * Gets the value of the staleStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaleStatus() {
        return staleStatus;
    }

    /**
     * Sets the value of the staleStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaleStatus(String value) {
        this.staleStatus = value;
    }

    /**
     * Gets the value of the stalePRNNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStalePRNNo() {
        return stalePRNNo;
    }

    /**
     * Sets the value of the stalePRNNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStalePRNNo(String value) {
        this.stalePRNNo = value;
    }

    /**
     * Gets the value of the staleChequeNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaleChequeNo() {
        return staleChequeNo;
    }

    /**
     * Sets the value of the staleChequeNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaleChequeNo(String value) {
        this.staleChequeNo = value;
    }

    /**
     * Gets the value of the staleAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaleAmount() {
        return staleAmount;
    }

    /**
     * Sets the value of the staleAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaleAmount(String value) {
        this.staleAmount = value;
    }

    /**
     * Gets the value of the exceptionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionStatus() {
        return exceptionStatus;
    }

    /**
     * Sets the value of the exceptionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionStatus(String value) {
        this.exceptionStatus = value;
    }

    /**
     * Gets the value of the exceptionPRNNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionPRNNo() {
        return exceptionPRNNo;
    }

    /**
     * Sets the value of the exceptionPRNNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionPRNNo(String value) {
        this.exceptionPRNNo = value;
    }

    /**
     * Gets the value of the exceptionChequeNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionChequeNo() {
        return exceptionChequeNo;
    }

    /**
     * Sets the value of the exceptionChequeNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionChequeNo(String value) {
        this.exceptionChequeNo = value;
    }

    /**
     * Gets the value of the exceptionAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionAmount() {
        return exceptionAmount;
    }

    /**
     * Sets the value of the exceptionAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionAmount(String value) {
        this.exceptionAmount = value;
    }

}
