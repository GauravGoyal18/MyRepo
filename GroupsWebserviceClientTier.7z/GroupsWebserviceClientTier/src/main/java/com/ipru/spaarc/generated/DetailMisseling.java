
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DetailMisseling complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailMisseling">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="StrFraudCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StrGovrnActionAgainst" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Govn_CallCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Govn_CallType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SysDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SysDeviation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="RepeatReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AnotherPersonConcern" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ActionRemarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StakeholderFeedback" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsActionToBeTaken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsAdvisorActive" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DecesionTakenBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PLVCPIVCWC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PLVCPIVCFindings" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FinalDecision_Text" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FinalDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApproverName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApproverDesignation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ChangeInDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DecisionTaken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Reasonforchangeindecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RepeatCallSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonForFinalDecision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailMisseling", propOrder = {
    "strFraudCategory",
    "strGovrnActionAgainst",
    "govnCallCategory",
    "govnCallType",
    "sysDecision",
    "sysDeviation",
    "isChanged",
    "interactionID",
    "repeatReason",
    "anotherPersonConcern",
    "actionRemarks",
    "stakeholderFeedback",
    "isActionToBeTaken",
    "isAdvisorActive",
    "decesionTakenBy",
    "plvcpivcwc",
    "plvcpivcFindings",
    "finalDecisionText",
    "finalDecision",
    "approverName",
    "approverDesignation",
    "isUpdated",
    "changeInDecision",
    "decisionTaken",
    "reasonforchangeindecision",
    "repeatCallSource",
    "reasonForFinalDecision"
})
public class DetailMisseling {

    @XmlElement(name = "StrFraudCategory")
    protected String strFraudCategory;
    @XmlElement(name = "StrGovrnActionAgainst")
    protected String strGovrnActionAgainst;
    @XmlElement(name = "Govn_CallCategory")
    protected String govnCallCategory;
    @XmlElement(name = "Govn_CallType")
    protected String govnCallType;
    @XmlElement(name = "SysDecision")
    protected String sysDecision;
    @XmlElement(name = "SysDeviation")
    protected String sysDeviation;
    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "RepeatReason")
    protected String repeatReason;
    @XmlElement(name = "AnotherPersonConcern")
    protected String anotherPersonConcern;
    @XmlElement(name = "ActionRemarks")
    protected String actionRemarks;
    @XmlElement(name = "StakeholderFeedback")
    protected String stakeholderFeedback;
    @XmlElement(name = "IsActionToBeTaken")
    protected String isActionToBeTaken;
    @XmlElement(name = "IsAdvisorActive")
    protected String isAdvisorActive;
    @XmlElement(name = "DecesionTakenBy")
    protected String decesionTakenBy;
    @XmlElement(name = "PLVCPIVCWC")
    protected String plvcpivcwc;
    @XmlElement(name = "PLVCPIVCFindings")
    protected String plvcpivcFindings;
    @XmlElement(name = "FinalDecision_Text")
    protected String finalDecisionText;
    @XmlElement(name = "FinalDecision")
    protected String finalDecision;
    @XmlElement(name = "ApproverName")
    protected String approverName;
    @XmlElement(name = "ApproverDesignation")
    protected String approverDesignation;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "ChangeInDecision")
    protected String changeInDecision;
    @XmlElement(name = "DecisionTaken")
    protected String decisionTaken;
    @XmlElement(name = "Reasonforchangeindecision")
    protected String reasonforchangeindecision;
    @XmlElement(name = "RepeatCallSource")
    protected String repeatCallSource;
    @XmlElement(name = "ReasonForFinalDecision")
    protected String reasonForFinalDecision;

    /**
     * Gets the value of the strFraudCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrFraudCategory() {
        return strFraudCategory;
    }

    /**
     * Sets the value of the strFraudCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrFraudCategory(String value) {
        this.strFraudCategory = value;
    }

    /**
     * Gets the value of the strGovrnActionAgainst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrGovrnActionAgainst() {
        return strGovrnActionAgainst;
    }

    /**
     * Sets the value of the strGovrnActionAgainst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrGovrnActionAgainst(String value) {
        this.strGovrnActionAgainst = value;
    }

    /**
     * Gets the value of the govnCallCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGovnCallCategory() {
        return govnCallCategory;
    }

    /**
     * Sets the value of the govnCallCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGovnCallCategory(String value) {
        this.govnCallCategory = value;
    }

    /**
     * Gets the value of the govnCallType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGovnCallType() {
        return govnCallType;
    }

    /**
     * Sets the value of the govnCallType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGovnCallType(String value) {
        this.govnCallType = value;
    }

    /**
     * Gets the value of the sysDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSysDecision() {
        return sysDecision;
    }

    /**
     * Sets the value of the sysDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSysDecision(String value) {
        this.sysDecision = value;
    }

    /**
     * Gets the value of the sysDeviation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSysDeviation() {
        return sysDeviation;
    }

    /**
     * Sets the value of the sysDeviation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSysDeviation(String value) {
        this.sysDeviation = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the repeatReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepeatReason() {
        return repeatReason;
    }

    /**
     * Sets the value of the repeatReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepeatReason(String value) {
        this.repeatReason = value;
    }

    /**
     * Gets the value of the anotherPersonConcern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnotherPersonConcern() {
        return anotherPersonConcern;
    }

    /**
     * Sets the value of the anotherPersonConcern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnotherPersonConcern(String value) {
        this.anotherPersonConcern = value;
    }

    /**
     * Gets the value of the actionRemarks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionRemarks() {
        return actionRemarks;
    }

    /**
     * Sets the value of the actionRemarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionRemarks(String value) {
        this.actionRemarks = value;
    }

    /**
     * Gets the value of the stakeholderFeedback property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStakeholderFeedback() {
        return stakeholderFeedback;
    }

    /**
     * Sets the value of the stakeholderFeedback property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStakeholderFeedback(String value) {
        this.stakeholderFeedback = value;
    }

    /**
     * Gets the value of the isActionToBeTaken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsActionToBeTaken() {
        return isActionToBeTaken;
    }

    /**
     * Sets the value of the isActionToBeTaken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsActionToBeTaken(String value) {
        this.isActionToBeTaken = value;
    }

    /**
     * Gets the value of the isAdvisorActive property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsAdvisorActive() {
        return isAdvisorActive;
    }

    /**
     * Sets the value of the isAdvisorActive property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsAdvisorActive(String value) {
        this.isAdvisorActive = value;
    }

    /**
     * Gets the value of the decesionTakenBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecesionTakenBy() {
        return decesionTakenBy;
    }

    /**
     * Sets the value of the decesionTakenBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecesionTakenBy(String value) {
        this.decesionTakenBy = value;
    }

    /**
     * Gets the value of the plvcpivcwc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLVCPIVCWC() {
        return plvcpivcwc;
    }

    /**
     * Sets the value of the plvcpivcwc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLVCPIVCWC(String value) {
        this.plvcpivcwc = value;
    }

    /**
     * Gets the value of the plvcpivcFindings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPLVCPIVCFindings() {
        return plvcpivcFindings;
    }

    /**
     * Sets the value of the plvcpivcFindings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPLVCPIVCFindings(String value) {
        this.plvcpivcFindings = value;
    }

    /**
     * Gets the value of the finalDecisionText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinalDecisionText() {
        return finalDecisionText;
    }

    /**
     * Sets the value of the finalDecisionText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinalDecisionText(String value) {
        this.finalDecisionText = value;
    }

    /**
     * Gets the value of the finalDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFinalDecision() {
        return finalDecision;
    }

    /**
     * Sets the value of the finalDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFinalDecision(String value) {
        this.finalDecision = value;
    }

    /**
     * Gets the value of the approverName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApproverName() {
        return approverName;
    }

    /**
     * Sets the value of the approverName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApproverName(String value) {
        this.approverName = value;
    }

    /**
     * Gets the value of the approverDesignation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApproverDesignation() {
        return approverDesignation;
    }

    /**
     * Sets the value of the approverDesignation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApproverDesignation(String value) {
        this.approverDesignation = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the changeInDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChangeInDecision() {
        return changeInDecision;
    }

    /**
     * Sets the value of the changeInDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChangeInDecision(String value) {
        this.changeInDecision = value;
    }

    /**
     * Gets the value of the decisionTaken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionTaken() {
        return decisionTaken;
    }

    /**
     * Sets the value of the decisionTaken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionTaken(String value) {
        this.decisionTaken = value;
    }

    /**
     * Gets the value of the reasonforchangeindecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonforchangeindecision() {
        return reasonforchangeindecision;
    }

    /**
     * Sets the value of the reasonforchangeindecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonforchangeindecision(String value) {
        this.reasonforchangeindecision = value;
    }

    /**
     * Gets the value of the repeatCallSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepeatCallSource() {
        return repeatCallSource;
    }

    /**
     * Sets the value of the repeatCallSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepeatCallSource(String value) {
        this.repeatCallSource = value;
    }

    /**
     * Gets the value of the reasonForFinalDecision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonForFinalDecision() {
        return reasonForFinalDecision;
    }

    /**
     * Sets the value of the reasonForFinalDecision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonForFinalDecision(String value) {
        this.reasonForFinalDecision = value;
    }

}
