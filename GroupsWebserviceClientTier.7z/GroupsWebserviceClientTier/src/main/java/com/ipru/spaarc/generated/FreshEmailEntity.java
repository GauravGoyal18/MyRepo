
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FreshEmailEntity complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FreshEmailEntity">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CallID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CategorizerID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Complexity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="QueryType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentAttribute" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VendorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="QueueType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsCSEActioned" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="CSE_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsCheckerActioned" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="CheckerID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JournalID" type="{http://generated.spaarc.ipru.com/}ArrayOfString" minOccurs="0"/>
 *         &lt;element name="HeatHtmlID" type="{http://generated.spaarc.ipru.com/}ArrayOfString" minOccurs="0"/>
 *         &lt;element name="MailConfiguredBy" type="{http://generated.spaarc.ipru.com/}ArrayOfString" minOccurs="0"/>
 *         &lt;element name="IsFreshEmailUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="MailTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MailCC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MailBCC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MailSubject" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MailBody" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MailFrom" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AttachmentPath" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FromFreshEmailPage" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ClosedByAttribute" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClosedByRole" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FreshEmailEntity", propOrder = {
    "callID",
    "categorizerID",
    "complexity",
    "queryType",
    "agentAttribute",
    "vendorCode",
    "queueType",
    "isCSEActioned",
    "cseid",
    "isCheckerActioned",
    "checkerID",
    "journalID",
    "heatHtmlID",
    "mailConfiguredBy",
    "isFreshEmailUpdated",
    "mailTo",
    "mailCC",
    "mailBCC",
    "mailSubject",
    "mailBody",
    "mailFrom",
    "attachmentPath",
    "fromFreshEmailPage",
    "closedByAttribute",
    "closedByRole"
})
public class FreshEmailEntity {

    @XmlElement(name = "CallID")
    protected String callID;
    @XmlElement(name = "CategorizerID")
    protected String categorizerID;
    @XmlElement(name = "Complexity")
    protected String complexity;
    @XmlElement(name = "QueryType")
    protected String queryType;
    @XmlElement(name = "AgentAttribute")
    protected String agentAttribute;
    @XmlElement(name = "VendorCode")
    protected String vendorCode;
    @XmlElement(name = "QueueType")
    protected String queueType;
    @XmlElement(name = "IsCSEActioned")
    protected int isCSEActioned;
    @XmlElement(name = "CSE_ID")
    protected String cseid;
    @XmlElement(name = "IsCheckerActioned")
    protected int isCheckerActioned;
    @XmlElement(name = "CheckerID")
    protected String checkerID;
    @XmlElement(name = "JournalID")
    protected ArrayOfString journalID;
    @XmlElement(name = "HeatHtmlID")
    protected ArrayOfString heatHtmlID;
    @XmlElement(name = "MailConfiguredBy")
    protected ArrayOfString mailConfiguredBy;
    @XmlElement(name = "IsFreshEmailUpdated")
    protected boolean isFreshEmailUpdated;
    @XmlElement(name = "MailTo")
    protected String mailTo;
    @XmlElement(name = "MailCC")
    protected String mailCC;
    @XmlElement(name = "MailBCC")
    protected String mailBCC;
    @XmlElement(name = "MailSubject")
    protected String mailSubject;
    @XmlElement(name = "MailBody")
    protected String mailBody;
    @XmlElement(name = "MailFrom")
    protected String mailFrom;
    @XmlElement(name = "AttachmentPath")
    protected String attachmentPath;
    @XmlElement(name = "FromFreshEmailPage")
    protected int fromFreshEmailPage;
    @XmlElement(name = "ClosedByAttribute")
    protected String closedByAttribute;
    @XmlElement(name = "ClosedByRole")
    protected String closedByRole;

    /**
     * Gets the value of the callID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallID() {
        return callID;
    }

    /**
     * Sets the value of the callID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallID(String value) {
        this.callID = value;
    }

    /**
     * Gets the value of the categorizerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategorizerID() {
        return categorizerID;
    }

    /**
     * Sets the value of the categorizerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategorizerID(String value) {
        this.categorizerID = value;
    }

    /**
     * Gets the value of the complexity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComplexity() {
        return complexity;
    }

    /**
     * Sets the value of the complexity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComplexity(String value) {
        this.complexity = value;
    }

    /**
     * Gets the value of the queryType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQueryType() {
        return queryType;
    }

    /**
     * Sets the value of the queryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQueryType(String value) {
        this.queryType = value;
    }

    /**
     * Gets the value of the agentAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentAttribute() {
        return agentAttribute;
    }

    /**
     * Sets the value of the agentAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentAttribute(String value) {
        this.agentAttribute = value;
    }

    /**
     * Gets the value of the vendorCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVendorCode() {
        return vendorCode;
    }

    /**
     * Sets the value of the vendorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVendorCode(String value) {
        this.vendorCode = value;
    }

    /**
     * Gets the value of the queueType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQueueType() {
        return queueType;
    }

    /**
     * Sets the value of the queueType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQueueType(String value) {
        this.queueType = value;
    }

    /**
     * Gets the value of the isCSEActioned property.
     * 
     */
    public int getIsCSEActioned() {
        return isCSEActioned;
    }

    /**
     * Sets the value of the isCSEActioned property.
     * 
     */
    public void setIsCSEActioned(int value) {
        this.isCSEActioned = value;
    }

    /**
     * Gets the value of the cseid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCSEID() {
        return cseid;
    }

    /**
     * Sets the value of the cseid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCSEID(String value) {
        this.cseid = value;
    }

    /**
     * Gets the value of the isCheckerActioned property.
     * 
     */
    public int getIsCheckerActioned() {
        return isCheckerActioned;
    }

    /**
     * Sets the value of the isCheckerActioned property.
     * 
     */
    public void setIsCheckerActioned(int value) {
        this.isCheckerActioned = value;
    }

    /**
     * Gets the value of the checkerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckerID() {
        return checkerID;
    }

    /**
     * Sets the value of the checkerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckerID(String value) {
        this.checkerID = value;
    }

    /**
     * Gets the value of the journalID property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfString }
     *     
     */
    public ArrayOfString getJournalID() {
        return journalID;
    }

    /**
     * Sets the value of the journalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfString }
     *     
     */
    public void setJournalID(ArrayOfString value) {
        this.journalID = value;
    }

    /**
     * Gets the value of the heatHtmlID property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfString }
     *     
     */
    public ArrayOfString getHeatHtmlID() {
        return heatHtmlID;
    }

    /**
     * Sets the value of the heatHtmlID property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfString }
     *     
     */
    public void setHeatHtmlID(ArrayOfString value) {
        this.heatHtmlID = value;
    }

    /**
     * Gets the value of the mailConfiguredBy property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfString }
     *     
     */
    public ArrayOfString getMailConfiguredBy() {
        return mailConfiguredBy;
    }

    /**
     * Sets the value of the mailConfiguredBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfString }
     *     
     */
    public void setMailConfiguredBy(ArrayOfString value) {
        this.mailConfiguredBy = value;
    }

    /**
     * Gets the value of the isFreshEmailUpdated property.
     * 
     */
    public boolean isIsFreshEmailUpdated() {
        return isFreshEmailUpdated;
    }

    /**
     * Sets the value of the isFreshEmailUpdated property.
     * 
     */
    public void setIsFreshEmailUpdated(boolean value) {
        this.isFreshEmailUpdated = value;
    }

    /**
     * Gets the value of the mailTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailTo() {
        return mailTo;
    }

    /**
     * Sets the value of the mailTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailTo(String value) {
        this.mailTo = value;
    }

    /**
     * Gets the value of the mailCC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailCC() {
        return mailCC;
    }

    /**
     * Sets the value of the mailCC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailCC(String value) {
        this.mailCC = value;
    }

    /**
     * Gets the value of the mailBCC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailBCC() {
        return mailBCC;
    }

    /**
     * Sets the value of the mailBCC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailBCC(String value) {
        this.mailBCC = value;
    }

    /**
     * Gets the value of the mailSubject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailSubject() {
        return mailSubject;
    }

    /**
     * Sets the value of the mailSubject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailSubject(String value) {
        this.mailSubject = value;
    }

    /**
     * Gets the value of the mailBody property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailBody() {
        return mailBody;
    }

    /**
     * Sets the value of the mailBody property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailBody(String value) {
        this.mailBody = value;
    }

    /**
     * Gets the value of the mailFrom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailFrom() {
        return mailFrom;
    }

    /**
     * Sets the value of the mailFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailFrom(String value) {
        this.mailFrom = value;
    }

    /**
     * Gets the value of the attachmentPath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachmentPath() {
        return attachmentPath;
    }

    /**
     * Sets the value of the attachmentPath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachmentPath(String value) {
        this.attachmentPath = value;
    }

    /**
     * Gets the value of the fromFreshEmailPage property.
     * 
     */
    public int getFromFreshEmailPage() {
        return fromFreshEmailPage;
    }

    /**
     * Sets the value of the fromFreshEmailPage property.
     * 
     */
    public void setFromFreshEmailPage(int value) {
        this.fromFreshEmailPage = value;
    }

    /**
     * Gets the value of the closedByAttribute property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClosedByAttribute() {
        return closedByAttribute;
    }

    /**
     * Sets the value of the closedByAttribute property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosedByAttribute(String value) {
        this.closedByAttribute = value;
    }

    /**
     * Gets the value of the closedByRole property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClosedByRole() {
        return closedByRole;
    }

    /**
     * Sets the value of the closedByRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosedByRole(String value) {
        this.closedByRole = value;
    }

}
