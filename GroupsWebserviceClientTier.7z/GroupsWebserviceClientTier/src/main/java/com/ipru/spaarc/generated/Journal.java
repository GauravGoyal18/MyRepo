
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Journal complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Journal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CreatedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IsEMMJournal" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="HeatHtmlID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MailStatusEMM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsDeleted" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="JournalID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="HEATSeq" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="InteractionId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="CreatedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JournalType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Notes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsCreated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsCreated_New" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsJournalSaved" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="HeatEmailID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="TO_Receip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CC_Receip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClosedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="CallEntryDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="CallSaveDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ShowInALReport" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Guid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CliNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcdNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Journal", propOrder = {
    "createdDateTime",
    "isEMMJournal",
    "heatHtmlID",
    "mailStatusEMM",
    "isDeleted",
    "isChanged",
    "journalID",
    "heatSeq",
    "interactionId",
    "createdBy",
    "journalType",
    "notes",
    "isCreated",
    "isCreatedNew",
    "isJournalSaved",
    "heatEmailID",
    "toReceip",
    "ccReceip",
    "closedDateTime",
    "callEntryDateTime",
    "callSaveDateTime",
    "showInALReport",
    "guid",
    "cliNo",
    "acdNumber"
})
public class Journal {

    @XmlElement(name = "CreatedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createdDateTime;
    @XmlElement(name = "IsEMMJournal")
    protected boolean isEMMJournal;
    @XmlElement(name = "HeatHtmlID")
    protected String heatHtmlID;
    @XmlElement(name = "MailStatusEMM")
    protected String mailStatusEMM;
    @XmlElement(name = "IsDeleted")
    protected boolean isDeleted;
    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "JournalID")
    protected long journalID;
    @XmlElement(name = "HEATSeq")
    protected int heatSeq;
    @XmlElement(name = "InteractionId")
    protected long interactionId;
    @XmlElement(name = "CreatedBy")
    protected String createdBy;
    @XmlElement(name = "JournalType")
    protected String journalType;
    @XmlElement(name = "Notes")
    protected String notes;
    @XmlElement(name = "IsCreated")
    protected boolean isCreated;
    @XmlElement(name = "IsCreated_New")
    protected boolean isCreatedNew;
    @XmlElement(name = "IsJournalSaved")
    protected boolean isJournalSaved;
    @XmlElement(name = "HeatEmailID")
    protected long heatEmailID;
    @XmlElement(name = "TO_Receip")
    protected String toReceip;
    @XmlElement(name = "CC_Receip")
    protected String ccReceip;
    @XmlElement(name = "ClosedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar closedDateTime;
    @XmlElement(name = "CallEntryDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar callEntryDateTime;
    @XmlElement(name = "CallSaveDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar callSaveDateTime;
    @XmlElement(name = "ShowInALReport")
    protected boolean showInALReport;
    @XmlElement(name = "Guid")
    protected String guid;
    @XmlElement(name = "CliNo")
    protected String cliNo;
    @XmlElement(name = "AcdNumber")
    protected String acdNumber;

    /**
     * Gets the value of the createdDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreatedDateTime() {
        return createdDateTime;
    }

    /**
     * Sets the value of the createdDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreatedDateTime(XMLGregorianCalendar value) {
        this.createdDateTime = value;
    }

    /**
     * Gets the value of the isEMMJournal property.
     * 
     */
    public boolean isIsEMMJournal() {
        return isEMMJournal;
    }

    /**
     * Sets the value of the isEMMJournal property.
     * 
     */
    public void setIsEMMJournal(boolean value) {
        this.isEMMJournal = value;
    }

    /**
     * Gets the value of the heatHtmlID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHeatHtmlID() {
        return heatHtmlID;
    }

    /**
     * Sets the value of the heatHtmlID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHeatHtmlID(String value) {
        this.heatHtmlID = value;
    }

    /**
     * Gets the value of the mailStatusEMM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailStatusEMM() {
        return mailStatusEMM;
    }

    /**
     * Sets the value of the mailStatusEMM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailStatusEMM(String value) {
        this.mailStatusEMM = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     */
    public boolean isIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     */
    public void setIsDeleted(boolean value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the journalID property.
     * 
     */
    public long getJournalID() {
        return journalID;
    }

    /**
     * Sets the value of the journalID property.
     * 
     */
    public void setJournalID(long value) {
        this.journalID = value;
    }

    /**
     * Gets the value of the heatSeq property.
     * 
     */
    public int getHEATSeq() {
        return heatSeq;
    }

    /**
     * Sets the value of the heatSeq property.
     * 
     */
    public void setHEATSeq(int value) {
        this.heatSeq = value;
    }

    /**
     * Gets the value of the interactionId property.
     * 
     */
    public long getInteractionId() {
        return interactionId;
    }

    /**
     * Sets the value of the interactionId property.
     * 
     */
    public void setInteractionId(long value) {
        this.interactionId = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the journalType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJournalType() {
        return journalType;
    }

    /**
     * Sets the value of the journalType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJournalType(String value) {
        this.journalType = value;
    }

    /**
     * Gets the value of the notes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotes() {
        return notes;
    }

    /**
     * Sets the value of the notes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotes(String value) {
        this.notes = value;
    }

    /**
     * Gets the value of the isCreated property.
     * 
     */
    public boolean isIsCreated() {
        return isCreated;
    }

    /**
     * Sets the value of the isCreated property.
     * 
     */
    public void setIsCreated(boolean value) {
        this.isCreated = value;
    }

    /**
     * Gets the value of the isCreatedNew property.
     * 
     */
    public boolean isIsCreatedNew() {
        return isCreatedNew;
    }

    /**
     * Sets the value of the isCreatedNew property.
     * 
     */
    public void setIsCreatedNew(boolean value) {
        this.isCreatedNew = value;
    }

    /**
     * Gets the value of the isJournalSaved property.
     * 
     */
    public boolean isIsJournalSaved() {
        return isJournalSaved;
    }

    /**
     * Sets the value of the isJournalSaved property.
     * 
     */
    public void setIsJournalSaved(boolean value) {
        this.isJournalSaved = value;
    }

    /**
     * Gets the value of the heatEmailID property.
     * 
     */
    public long getHeatEmailID() {
        return heatEmailID;
    }

    /**
     * Sets the value of the heatEmailID property.
     * 
     */
    public void setHeatEmailID(long value) {
        this.heatEmailID = value;
    }

    /**
     * Gets the value of the toReceip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOReceip() {
        return toReceip;
    }

    /**
     * Sets the value of the toReceip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOReceip(String value) {
        this.toReceip = value;
    }

    /**
     * Gets the value of the ccReceip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCCReceip() {
        return ccReceip;
    }

    /**
     * Sets the value of the ccReceip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCCReceip(String value) {
        this.ccReceip = value;
    }

    /**
     * Gets the value of the closedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getClosedDateTime() {
        return closedDateTime;
    }

    /**
     * Sets the value of the closedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setClosedDateTime(XMLGregorianCalendar value) {
        this.closedDateTime = value;
    }

    /**
     * Gets the value of the callEntryDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCallEntryDateTime() {
        return callEntryDateTime;
    }

    /**
     * Sets the value of the callEntryDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCallEntryDateTime(XMLGregorianCalendar value) {
        this.callEntryDateTime = value;
    }

    /**
     * Gets the value of the callSaveDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCallSaveDateTime() {
        return callSaveDateTime;
    }

    /**
     * Sets the value of the callSaveDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCallSaveDateTime(XMLGregorianCalendar value) {
        this.callSaveDateTime = value;
    }

    /**
     * Gets the value of the showInALReport property.
     * 
     */
    public boolean isShowInALReport() {
        return showInALReport;
    }

    /**
     * Sets the value of the showInALReport property.
     * 
     */
    public void setShowInALReport(boolean value) {
        this.showInALReport = value;
    }

    /**
     * Gets the value of the guid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGuid() {
        return guid;
    }

    /**
     * Sets the value of the guid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGuid(String value) {
        this.guid = value;
    }

    /**
     * Gets the value of the cliNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCliNo() {
        return cliNo;
    }

    /**
     * Sets the value of the cliNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCliNo(String value) {
        this.cliNo = value;
    }

    /**
     * Gets the value of the acdNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcdNumber() {
        return acdNumber;
    }

    /**
     * Sets the value of the acdNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcdNumber(String value) {
        this.acdNumber = value;
    }

}
