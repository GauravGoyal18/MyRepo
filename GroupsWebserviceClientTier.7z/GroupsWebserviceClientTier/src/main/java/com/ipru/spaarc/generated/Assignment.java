
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Assignment complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Assignment">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="InvtgCityID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="InvtgStateID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsAssignmentResolved" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="AssignorNotes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsDeleted" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="AssignmentID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="HEATSeq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssignedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssignedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ResolvedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResolvedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="AssigneeGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LoginID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssigneeSubGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Assignee" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssigneeEMail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResolveAssignment" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="LastUpdateDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Notes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsCreated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsAssignmentSaved" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="SessionID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CloseDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssignmentChangeValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Decision" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DecisionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Assignment", propOrder = {
    "invtgCityID",
    "invtgStateID",
    "isAssignmentResolved",
    "assignorNotes",
    "isDeleted",
    "isChanged",
    "assignmentID",
    "interactionID",
    "heatSeq",
    "assignedBy",
    "assignedDateTime",
    "resolvedBy",
    "resolvedDateTime",
    "assigneeGroup",
    "loginID",
    "assigneeSubGroup",
    "assignee",
    "assigneeEMail",
    "resolveAssignment",
    "lastUpdateDate",
    "notes",
    "isUpdated",
    "isCreated",
    "isAssignmentSaved",
    "sessionID",
    "closeDescription",
    "assignmentChangeValue",
    "decision",
    "decisionName"
})
public class Assignment {

    @XmlElement(name = "InvtgCityID")
    protected int invtgCityID;
    @XmlElement(name = "InvtgStateID")
    protected String invtgStateID;
    @XmlElement(name = "IsAssignmentResolved")
    protected boolean isAssignmentResolved;
    @XmlElement(name = "AssignorNotes")
    protected String assignorNotes;
    @XmlElement(name = "IsDeleted")
    protected boolean isDeleted;
    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "AssignmentID")
    protected long assignmentID;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "HEATSeq")
    protected String heatSeq;
    @XmlElement(name = "AssignedBy")
    protected String assignedBy;
    @XmlElement(name = "AssignedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar assignedDateTime;
    @XmlElement(name = "ResolvedBy")
    protected String resolvedBy;
    @XmlElement(name = "ResolvedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar resolvedDateTime;
    @XmlElement(name = "AssigneeGroup")
    protected String assigneeGroup;
    @XmlElement(name = "LoginID")
    protected String loginID;
    @XmlElement(name = "AssigneeSubGroup")
    protected String assigneeSubGroup;
    @XmlElement(name = "Assignee")
    protected String assignee;
    @XmlElement(name = "AssigneeEMail")
    protected String assigneeEMail;
    @XmlElement(name = "ResolveAssignment")
    protected boolean resolveAssignment;
    @XmlElement(name = "LastUpdateDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastUpdateDate;
    @XmlElement(name = "Notes")
    protected String notes;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "IsCreated")
    protected boolean isCreated;
    @XmlElement(name = "IsAssignmentSaved")
    protected boolean isAssignmentSaved;
    @XmlElement(name = "SessionID")
    protected String sessionID;
    @XmlElement(name = "CloseDescription")
    protected String closeDescription;
    @XmlElement(name = "AssignmentChangeValue")
    protected String assignmentChangeValue;
    @XmlElement(name = "Decision")
    protected String decision;
    @XmlElement(name = "DecisionName")
    protected String decisionName;

    /**
     * Gets the value of the invtgCityID property.
     * 
     */
    public int getInvtgCityID() {
        return invtgCityID;
    }

    /**
     * Sets the value of the invtgCityID property.
     * 
     */
    public void setInvtgCityID(int value) {
        this.invtgCityID = value;
    }

    /**
     * Gets the value of the invtgStateID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvtgStateID() {
        return invtgStateID;
    }

    /**
     * Sets the value of the invtgStateID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvtgStateID(String value) {
        this.invtgStateID = value;
    }

    /**
     * Gets the value of the isAssignmentResolved property.
     * 
     */
    public boolean isIsAssignmentResolved() {
        return isAssignmentResolved;
    }

    /**
     * Sets the value of the isAssignmentResolved property.
     * 
     */
    public void setIsAssignmentResolved(boolean value) {
        this.isAssignmentResolved = value;
    }

    /**
     * Gets the value of the assignorNotes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignorNotes() {
        return assignorNotes;
    }

    /**
     * Sets the value of the assignorNotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignorNotes(String value) {
        this.assignorNotes = value;
    }

    /**
     * Gets the value of the isDeleted property.
     * 
     */
    public boolean isIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the isDeleted property.
     * 
     */
    public void setIsDeleted(boolean value) {
        this.isDeleted = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the assignmentID property.
     * 
     */
    public long getAssignmentID() {
        return assignmentID;
    }

    /**
     * Sets the value of the assignmentID property.
     * 
     */
    public void setAssignmentID(long value) {
        this.assignmentID = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the heatSeq property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHEATSeq() {
        return heatSeq;
    }

    /**
     * Sets the value of the heatSeq property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHEATSeq(String value) {
        this.heatSeq = value;
    }

    /**
     * Gets the value of the assignedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignedBy() {
        return assignedBy;
    }

    /**
     * Sets the value of the assignedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignedBy(String value) {
        this.assignedBy = value;
    }

    /**
     * Gets the value of the assignedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAssignedDateTime() {
        return assignedDateTime;
    }

    /**
     * Sets the value of the assignedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAssignedDateTime(XMLGregorianCalendar value) {
        this.assignedDateTime = value;
    }

    /**
     * Gets the value of the resolvedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResolvedBy() {
        return resolvedBy;
    }

    /**
     * Sets the value of the resolvedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResolvedBy(String value) {
        this.resolvedBy = value;
    }

    /**
     * Gets the value of the resolvedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getResolvedDateTime() {
        return resolvedDateTime;
    }

    /**
     * Sets the value of the resolvedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setResolvedDateTime(XMLGregorianCalendar value) {
        this.resolvedDateTime = value;
    }

    /**
     * Gets the value of the assigneeGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssigneeGroup() {
        return assigneeGroup;
    }

    /**
     * Sets the value of the assigneeGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssigneeGroup(String value) {
        this.assigneeGroup = value;
    }

    /**
     * Gets the value of the loginID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoginID() {
        return loginID;
    }

    /**
     * Sets the value of the loginID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoginID(String value) {
        this.loginID = value;
    }

    /**
     * Gets the value of the assigneeSubGroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssigneeSubGroup() {
        return assigneeSubGroup;
    }

    /**
     * Sets the value of the assigneeSubGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssigneeSubGroup(String value) {
        this.assigneeSubGroup = value;
    }

    /**
     * Gets the value of the assignee property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignee() {
        return assignee;
    }

    /**
     * Sets the value of the assignee property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignee(String value) {
        this.assignee = value;
    }

    /**
     * Gets the value of the assigneeEMail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssigneeEMail() {
        return assigneeEMail;
    }

    /**
     * Sets the value of the assigneeEMail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssigneeEMail(String value) {
        this.assigneeEMail = value;
    }

    /**
     * Gets the value of the resolveAssignment property.
     * 
     */
    public boolean isResolveAssignment() {
        return resolveAssignment;
    }

    /**
     * Sets the value of the resolveAssignment property.
     * 
     */
    public void setResolveAssignment(boolean value) {
        this.resolveAssignment = value;
    }

    /**
     * Gets the value of the lastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * Sets the value of the lastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdateDate(XMLGregorianCalendar value) {
        this.lastUpdateDate = value;
    }

    /**
     * Gets the value of the notes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotes() {
        return notes;
    }

    /**
     * Sets the value of the notes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotes(String value) {
        this.notes = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the isCreated property.
     * 
     */
    public boolean isIsCreated() {
        return isCreated;
    }

    /**
     * Sets the value of the isCreated property.
     * 
     */
    public void setIsCreated(boolean value) {
        this.isCreated = value;
    }

    /**
     * Gets the value of the isAssignmentSaved property.
     * 
     */
    public boolean isIsAssignmentSaved() {
        return isAssignmentSaved;
    }

    /**
     * Sets the value of the isAssignmentSaved property.
     * 
     */
    public void setIsAssignmentSaved(boolean value) {
        this.isAssignmentSaved = value;
    }

    /**
     * Gets the value of the sessionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionID() {
        return sessionID;
    }

    /**
     * Sets the value of the sessionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionID(String value) {
        this.sessionID = value;
    }

    /**
     * Gets the value of the closeDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCloseDescription() {
        return closeDescription;
    }

    /**
     * Sets the value of the closeDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCloseDescription(String value) {
        this.closeDescription = value;
    }

    /**
     * Gets the value of the assignmentChangeValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignmentChangeValue() {
        return assignmentChangeValue;
    }

    /**
     * Sets the value of the assignmentChangeValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignmentChangeValue(String value) {
        this.assignmentChangeValue = value;
    }

    /**
     * Gets the value of the decision property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecision() {
        return decision;
    }

    /**
     * Sets the value of the decision property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecision(String value) {
        this.decision = value;
    }

    /**
     * Gets the value of the decisionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionName() {
        return decisionName;
    }

    /**
     * Sets the value of the decisionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionName(String value) {
        this.decisionName = value;
    }

}
