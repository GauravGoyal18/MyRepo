
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DetailClientDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailClientDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FakeNumbers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Address3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Address4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Landmark" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NewValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MobileNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HomeNumber1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HomeNumber2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfficeNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DoNotCall" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="AutoResponse" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="StdHome1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StdHome2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StdOffice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExtOffice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfficeEmailId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FaxNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PinCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="State" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsLetterPref" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsSMSPref" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsEmailPref" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Templatename" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailClientDetails", propOrder = {
    "fakeNumbers",
    "emailTo",
    "isChanged",
    "interactionID",
    "address1",
    "address2",
    "address3",
    "address4",
    "landmark",
    "newValue",
    "emailID",
    "mobileNo",
    "homeNumber1",
    "homeNumber2",
    "officeNumber",
    "doNotCall",
    "autoResponse",
    "isUpdated",
    "stdHome1",
    "stdHome2",
    "stdOffice",
    "extOffice",
    "officeEmailId",
    "faxNo",
    "pinCode",
    "state",
    "city",
    "isLetterPref",
    "isSMSPref",
    "isEmailPref",
    "templatename"
})
public class DetailClientDetails {

    @XmlElement(name = "FakeNumbers")
    protected String fakeNumbers;
    @XmlElement(name = "EmailTo")
    protected String emailTo;
    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "Address1")
    protected String address1;
    @XmlElement(name = "Address2")
    protected String address2;
    @XmlElement(name = "Address3")
    protected String address3;
    @XmlElement(name = "Address4")
    protected String address4;
    @XmlElement(name = "Landmark")
    protected String landmark;
    @XmlElement(name = "NewValue")
    protected String newValue;
    @XmlElement(name = "EmailID")
    protected String emailID;
    @XmlElement(name = "MobileNo")
    protected String mobileNo;
    @XmlElement(name = "HomeNumber1")
    protected String homeNumber1;
    @XmlElement(name = "HomeNumber2")
    protected String homeNumber2;
    @XmlElement(name = "OfficeNumber")
    protected String officeNumber;
    @XmlElement(name = "DoNotCall")
    protected boolean doNotCall;
    @XmlElement(name = "AutoResponse")
    protected boolean autoResponse;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "StdHome1")
    protected String stdHome1;
    @XmlElement(name = "StdHome2")
    protected String stdHome2;
    @XmlElement(name = "StdOffice")
    protected String stdOffice;
    @XmlElement(name = "ExtOffice")
    protected String extOffice;
    @XmlElement(name = "OfficeEmailId")
    protected String officeEmailId;
    @XmlElement(name = "FaxNo")
    protected String faxNo;
    @XmlElement(name = "PinCode")
    protected String pinCode;
    @XmlElement(name = "State")
    protected String state;
    @XmlElement(name = "City")
    protected String city;
    @XmlElement(name = "IsLetterPref")
    protected boolean isLetterPref;
    @XmlElement(name = "IsSMSPref")
    protected boolean isSMSPref;
    @XmlElement(name = "IsEmailPref")
    protected boolean isEmailPref;
    @XmlElement(name = "Templatename")
    protected String templatename;

    /**
     * Gets the value of the fakeNumbers property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFakeNumbers() {
        return fakeNumbers;
    }

    /**
     * Sets the value of the fakeNumbers property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFakeNumbers(String value) {
        this.fakeNumbers = value;
    }

    /**
     * Gets the value of the emailTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailTo() {
        return emailTo;
    }

    /**
     * Sets the value of the emailTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailTo(String value) {
        this.emailTo = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the address1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * Sets the value of the address1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress1(String value) {
        this.address1 = value;
    }

    /**
     * Gets the value of the address2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * Sets the value of the address2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress2(String value) {
        this.address2 = value;
    }

    /**
     * Gets the value of the address3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress3() {
        return address3;
    }

    /**
     * Sets the value of the address3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress3(String value) {
        this.address3 = value;
    }

    /**
     * Gets the value of the address4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress4() {
        return address4;
    }

    /**
     * Sets the value of the address4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress4(String value) {
        this.address4 = value;
    }

    /**
     * Gets the value of the landmark property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLandmark() {
        return landmark;
    }

    /**
     * Sets the value of the landmark property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLandmark(String value) {
        this.landmark = value;
    }

    /**
     * Gets the value of the newValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewValue() {
        return newValue;
    }

    /**
     * Sets the value of the newValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewValue(String value) {
        this.newValue = value;
    }

    /**
     * Gets the value of the emailID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailID() {
        return emailID;
    }

    /**
     * Sets the value of the emailID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailID(String value) {
        this.emailID = value;
    }

    /**
     * Gets the value of the mobileNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobileNo() {
        return mobileNo;
    }

    /**
     * Sets the value of the mobileNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobileNo(String value) {
        this.mobileNo = value;
    }

    /**
     * Gets the value of the homeNumber1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomeNumber1() {
        return homeNumber1;
    }

    /**
     * Sets the value of the homeNumber1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomeNumber1(String value) {
        this.homeNumber1 = value;
    }

    /**
     * Gets the value of the homeNumber2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomeNumber2() {
        return homeNumber2;
    }

    /**
     * Sets the value of the homeNumber2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomeNumber2(String value) {
        this.homeNumber2 = value;
    }

    /**
     * Gets the value of the officeNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfficeNumber() {
        return officeNumber;
    }

    /**
     * Sets the value of the officeNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfficeNumber(String value) {
        this.officeNumber = value;
    }

    /**
     * Gets the value of the doNotCall property.
     * 
     */
    public boolean isDoNotCall() {
        return doNotCall;
    }

    /**
     * Sets the value of the doNotCall property.
     * 
     */
    public void setDoNotCall(boolean value) {
        this.doNotCall = value;
    }

    /**
     * Gets the value of the autoResponse property.
     * 
     */
    public boolean isAutoResponse() {
        return autoResponse;
    }

    /**
     * Sets the value of the autoResponse property.
     * 
     */
    public void setAutoResponse(boolean value) {
        this.autoResponse = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the stdHome1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdHome1() {
        return stdHome1;
    }

    /**
     * Sets the value of the stdHome1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdHome1(String value) {
        this.stdHome1 = value;
    }

    /**
     * Gets the value of the stdHome2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdHome2() {
        return stdHome2;
    }

    /**
     * Sets the value of the stdHome2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdHome2(String value) {
        this.stdHome2 = value;
    }

    /**
     * Gets the value of the stdOffice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdOffice() {
        return stdOffice;
    }

    /**
     * Sets the value of the stdOffice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdOffice(String value) {
        this.stdOffice = value;
    }

    /**
     * Gets the value of the extOffice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtOffice() {
        return extOffice;
    }

    /**
     * Sets the value of the extOffice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtOffice(String value) {
        this.extOffice = value;
    }

    /**
     * Gets the value of the officeEmailId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfficeEmailId() {
        return officeEmailId;
    }

    /**
     * Sets the value of the officeEmailId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfficeEmailId(String value) {
        this.officeEmailId = value;
    }

    /**
     * Gets the value of the faxNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaxNo() {
        return faxNo;
    }

    /**
     * Sets the value of the faxNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaxNo(String value) {
        this.faxNo = value;
    }

    /**
     * Gets the value of the pinCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPinCode() {
        return pinCode;
    }

    /**
     * Sets the value of the pinCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPinCode(String value) {
        this.pinCode = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the isLetterPref property.
     * 
     */
    public boolean isIsLetterPref() {
        return isLetterPref;
    }

    /**
     * Sets the value of the isLetterPref property.
     * 
     */
    public void setIsLetterPref(boolean value) {
        this.isLetterPref = value;
    }

    /**
     * Gets the value of the isSMSPref property.
     * 
     */
    public boolean isIsSMSPref() {
        return isSMSPref;
    }

    /**
     * Sets the value of the isSMSPref property.
     * 
     */
    public void setIsSMSPref(boolean value) {
        this.isSMSPref = value;
    }

    /**
     * Gets the value of the isEmailPref property.
     * 
     */
    public boolean isIsEmailPref() {
        return isEmailPref;
    }

    /**
     * Sets the value of the isEmailPref property.
     * 
     */
    public void setIsEmailPref(boolean value) {
        this.isEmailPref = value;
    }

    /**
     * Gets the value of the templatename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplatename() {
        return templatename;
    }

    /**
     * Sets the value of the templatename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplatename(String value) {
        this.templatename = value;
    }

}
