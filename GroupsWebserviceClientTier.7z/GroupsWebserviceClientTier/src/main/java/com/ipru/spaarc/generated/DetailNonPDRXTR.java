
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Detail_Non_PDR_XTR complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Detail_Non_PDR_XTR">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="CaseType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ForeClosurePayout" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Documents_Submitted" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="XRTConsent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SurrenderForm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TotalOutPremiumReciept" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransferAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TopUp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Decrease_Premium_Status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Premium_Amount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Frequency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RecieptNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NoOfFunds" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TopupForm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundCode1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundCode2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundCode3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundCode4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundCode5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundCode6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundCode7" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundCode8" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount7" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount8" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RequestForm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequeStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequePRNNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequeNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequeAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndPRNNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndChequeNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StaleStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StalePRNNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StaleChequeNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StaleAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExceptionStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExceptionPRNNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExceptionChequeNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExceptionAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Detail_Non_PDR_XTR", propOrder = {
    "interactionID",
    "caseType",
    "foreClosurePayout",
    "documentsSubmitted",
    "isUpdated",
    "xrtConsent",
    "surrenderForm",
    "totalOutPremiumReciept",
    "transferAmount",
    "topUp",
    "decreasePremiumStatus",
    "premiumAmount",
    "frequency",
    "recieptNumber",
    "noOfFunds",
    "topupForm",
    "fundCode1",
    "fundCode2",
    "fundCode3",
    "fundCode4",
    "fundCode5",
    "fundCode6",
    "fundCode7",
    "fundCode8",
    "amount1",
    "amount2",
    "amount3",
    "amount4",
    "amount5",
    "amount6",
    "amount7",
    "amount8",
    "requestForm",
    "chequeStatus",
    "chequePRNNo",
    "chequeNo",
    "chequeAmount",
    "indStatus",
    "indPRNNo",
    "indChequeNo",
    "indAmount",
    "staleStatus",
    "stalePRNNo",
    "staleChequeNo",
    "staleAmount",
    "exceptionStatus",
    "exceptionPRNNo",
    "exceptionChequeNo",
    "exceptionAmount"
})
public class DetailNonPDRXTR {

    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "CaseType")
    protected String caseType;
    @XmlElement(name = "ForeClosurePayout")
    protected String foreClosurePayout;
    @XmlElement(name = "Documents_Submitted")
    protected String documentsSubmitted;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "XRTConsent")
    protected String xrtConsent;
    @XmlElement(name = "SurrenderForm")
    protected String surrenderForm;
    @XmlElement(name = "TotalOutPremiumReciept")
    protected String totalOutPremiumReciept;
    @XmlElement(name = "TransferAmount")
    protected String transferAmount;
    @XmlElement(name = "TopUp")
    protected String topUp;
    @XmlElement(name = "Decrease_Premium_Status")
    protected String decreasePremiumStatus;
    @XmlElement(name = "Premium_Amount")
    protected String premiumAmount;
    @XmlElement(name = "Frequency")
    protected String frequency;
    @XmlElement(name = "RecieptNumber")
    protected String recieptNumber;
    @XmlElement(name = "NoOfFunds")
    protected String noOfFunds;
    @XmlElement(name = "TopupForm")
    protected String topupForm;
    @XmlElement(name = "FundCode1")
    protected String fundCode1;
    @XmlElement(name = "FundCode2")
    protected String fundCode2;
    @XmlElement(name = "FundCode3")
    protected String fundCode3;
    @XmlElement(name = "FundCode4")
    protected String fundCode4;
    @XmlElement(name = "FundCode5")
    protected String fundCode5;
    @XmlElement(name = "FundCode6")
    protected String fundCode6;
    @XmlElement(name = "FundCode7")
    protected String fundCode7;
    @XmlElement(name = "FundCode8")
    protected String fundCode8;
    @XmlElement(name = "Amount1")
    protected String amount1;
    @XmlElement(name = "Amount2")
    protected String amount2;
    @XmlElement(name = "Amount3")
    protected String amount3;
    @XmlElement(name = "Amount4")
    protected String amount4;
    @XmlElement(name = "Amount5")
    protected String amount5;
    @XmlElement(name = "Amount6")
    protected String amount6;
    @XmlElement(name = "Amount7")
    protected String amount7;
    @XmlElement(name = "Amount8")
    protected String amount8;
    @XmlElement(name = "RequestForm")
    protected String requestForm;
    @XmlElement(name = "ChequeStatus")
    protected String chequeStatus;
    @XmlElement(name = "ChequePRNNo")
    protected String chequePRNNo;
    @XmlElement(name = "ChequeNo")
    protected String chequeNo;
    @XmlElement(name = "ChequeAmount")
    protected String chequeAmount;
    @XmlElement(name = "IndStatus")
    protected String indStatus;
    @XmlElement(name = "IndPRNNo")
    protected String indPRNNo;
    @XmlElement(name = "IndChequeNo")
    protected String indChequeNo;
    @XmlElement(name = "IndAmount")
    protected String indAmount;
    @XmlElement(name = "StaleStatus")
    protected String staleStatus;
    @XmlElement(name = "StalePRNNo")
    protected String stalePRNNo;
    @XmlElement(name = "StaleChequeNo")
    protected String staleChequeNo;
    @XmlElement(name = "StaleAmount")
    protected String staleAmount;
    @XmlElement(name = "ExceptionStatus")
    protected String exceptionStatus;
    @XmlElement(name = "ExceptionPRNNo")
    protected String exceptionPRNNo;
    @XmlElement(name = "ExceptionChequeNo")
    protected String exceptionChequeNo;
    @XmlElement(name = "ExceptionAmount")
    protected String exceptionAmount;

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the caseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaseType() {
        return caseType;
    }

    /**
     * Sets the value of the caseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaseType(String value) {
        this.caseType = value;
    }

    /**
     * Gets the value of the foreClosurePayout property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForeClosurePayout() {
        return foreClosurePayout;
    }

    /**
     * Sets the value of the foreClosurePayout property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForeClosurePayout(String value) {
        this.foreClosurePayout = value;
    }

    /**
     * Gets the value of the documentsSubmitted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentsSubmitted() {
        return documentsSubmitted;
    }

    /**
     * Sets the value of the documentsSubmitted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentsSubmitted(String value) {
        this.documentsSubmitted = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the xrtConsent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXRTConsent() {
        return xrtConsent;
    }

    /**
     * Sets the value of the xrtConsent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXRTConsent(String value) {
        this.xrtConsent = value;
    }

    /**
     * Gets the value of the surrenderForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurrenderForm() {
        return surrenderForm;
    }

    /**
     * Sets the value of the surrenderForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurrenderForm(String value) {
        this.surrenderForm = value;
    }

    /**
     * Gets the value of the totalOutPremiumReciept property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalOutPremiumReciept() {
        return totalOutPremiumReciept;
    }

    /**
     * Sets the value of the totalOutPremiumReciept property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalOutPremiumReciept(String value) {
        this.totalOutPremiumReciept = value;
    }

    /**
     * Gets the value of the transferAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransferAmount() {
        return transferAmount;
    }

    /**
     * Sets the value of the transferAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransferAmount(String value) {
        this.transferAmount = value;
    }

    /**
     * Gets the value of the topUp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTopUp() {
        return topUp;
    }

    /**
     * Sets the value of the topUp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTopUp(String value) {
        this.topUp = value;
    }

    /**
     * Gets the value of the decreasePremiumStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecreasePremiumStatus() {
        return decreasePremiumStatus;
    }

    /**
     * Sets the value of the decreasePremiumStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecreasePremiumStatus(String value) {
        this.decreasePremiumStatus = value;
    }

    /**
     * Gets the value of the premiumAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremiumAmount() {
        return premiumAmount;
    }

    /**
     * Sets the value of the premiumAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremiumAmount(String value) {
        this.premiumAmount = value;
    }

    /**
     * Gets the value of the frequency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrequency() {
        return frequency;
    }

    /**
     * Sets the value of the frequency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrequency(String value) {
        this.frequency = value;
    }

    /**
     * Gets the value of the recieptNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecieptNumber() {
        return recieptNumber;
    }

    /**
     * Sets the value of the recieptNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecieptNumber(String value) {
        this.recieptNumber = value;
    }

    /**
     * Gets the value of the noOfFunds property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoOfFunds() {
        return noOfFunds;
    }

    /**
     * Sets the value of the noOfFunds property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoOfFunds(String value) {
        this.noOfFunds = value;
    }

    /**
     * Gets the value of the topupForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTopupForm() {
        return topupForm;
    }

    /**
     * Sets the value of the topupForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTopupForm(String value) {
        this.topupForm = value;
    }

    /**
     * Gets the value of the fundCode1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCode1() {
        return fundCode1;
    }

    /**
     * Sets the value of the fundCode1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCode1(String value) {
        this.fundCode1 = value;
    }

    /**
     * Gets the value of the fundCode2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCode2() {
        return fundCode2;
    }

    /**
     * Sets the value of the fundCode2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCode2(String value) {
        this.fundCode2 = value;
    }

    /**
     * Gets the value of the fundCode3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCode3() {
        return fundCode3;
    }

    /**
     * Sets the value of the fundCode3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCode3(String value) {
        this.fundCode3 = value;
    }

    /**
     * Gets the value of the fundCode4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCode4() {
        return fundCode4;
    }

    /**
     * Sets the value of the fundCode4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCode4(String value) {
        this.fundCode4 = value;
    }

    /**
     * Gets the value of the fundCode5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCode5() {
        return fundCode5;
    }

    /**
     * Sets the value of the fundCode5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCode5(String value) {
        this.fundCode5 = value;
    }

    /**
     * Gets the value of the fundCode6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCode6() {
        return fundCode6;
    }

    /**
     * Sets the value of the fundCode6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCode6(String value) {
        this.fundCode6 = value;
    }

    /**
     * Gets the value of the fundCode7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCode7() {
        return fundCode7;
    }

    /**
     * Sets the value of the fundCode7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCode7(String value) {
        this.fundCode7 = value;
    }

    /**
     * Gets the value of the fundCode8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundCode8() {
        return fundCode8;
    }

    /**
     * Sets the value of the fundCode8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundCode8(String value) {
        this.fundCode8 = value;
    }

    /**
     * Gets the value of the amount1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmount1() {
        return amount1;
    }

    /**
     * Sets the value of the amount1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmount1(String value) {
        this.amount1 = value;
    }

    /**
     * Gets the value of the amount2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmount2() {
        return amount2;
    }

    /**
     * Sets the value of the amount2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmount2(String value) {
        this.amount2 = value;
    }

    /**
     * Gets the value of the amount3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmount3() {
        return amount3;
    }

    /**
     * Sets the value of the amount3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmount3(String value) {
        this.amount3 = value;
    }

    /**
     * Gets the value of the amount4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmount4() {
        return amount4;
    }

    /**
     * Sets the value of the amount4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmount4(String value) {
        this.amount4 = value;
    }

    /**
     * Gets the value of the amount5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmount5() {
        return amount5;
    }

    /**
     * Sets the value of the amount5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmount5(String value) {
        this.amount5 = value;
    }

    /**
     * Gets the value of the amount6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmount6() {
        return amount6;
    }

    /**
     * Sets the value of the amount6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmount6(String value) {
        this.amount6 = value;
    }

    /**
     * Gets the value of the amount7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmount7() {
        return amount7;
    }

    /**
     * Sets the value of the amount7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmount7(String value) {
        this.amount7 = value;
    }

    /**
     * Gets the value of the amount8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmount8() {
        return amount8;
    }

    /**
     * Sets the value of the amount8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmount8(String value) {
        this.amount8 = value;
    }

    /**
     * Gets the value of the requestForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestForm() {
        return requestForm;
    }

    /**
     * Sets the value of the requestForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestForm(String value) {
        this.requestForm = value;
    }

    /**
     * Gets the value of the chequeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequeStatus() {
        return chequeStatus;
    }

    /**
     * Sets the value of the chequeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequeStatus(String value) {
        this.chequeStatus = value;
    }

    /**
     * Gets the value of the chequePRNNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequePRNNo() {
        return chequePRNNo;
    }

    /**
     * Sets the value of the chequePRNNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequePRNNo(String value) {
        this.chequePRNNo = value;
    }

    /**
     * Gets the value of the chequeNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequeNo() {
        return chequeNo;
    }

    /**
     * Sets the value of the chequeNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequeNo(String value) {
        this.chequeNo = value;
    }

    /**
     * Gets the value of the chequeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequeAmount() {
        return chequeAmount;
    }

    /**
     * Sets the value of the chequeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequeAmount(String value) {
        this.chequeAmount = value;
    }

    /**
     * Gets the value of the indStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndStatus() {
        return indStatus;
    }

    /**
     * Sets the value of the indStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndStatus(String value) {
        this.indStatus = value;
    }

    /**
     * Gets the value of the indPRNNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndPRNNo() {
        return indPRNNo;
    }

    /**
     * Sets the value of the indPRNNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndPRNNo(String value) {
        this.indPRNNo = value;
    }

    /**
     * Gets the value of the indChequeNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndChequeNo() {
        return indChequeNo;
    }

    /**
     * Sets the value of the indChequeNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndChequeNo(String value) {
        this.indChequeNo = value;
    }

    /**
     * Gets the value of the indAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndAmount() {
        return indAmount;
    }

    /**
     * Sets the value of the indAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndAmount(String value) {
        this.indAmount = value;
    }

    /**
     * Gets the value of the staleStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaleStatus() {
        return staleStatus;
    }

    /**
     * Sets the value of the staleStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaleStatus(String value) {
        this.staleStatus = value;
    }

    /**
     * Gets the value of the stalePRNNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStalePRNNo() {
        return stalePRNNo;
    }

    /**
     * Sets the value of the stalePRNNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStalePRNNo(String value) {
        this.stalePRNNo = value;
    }

    /**
     * Gets the value of the staleChequeNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaleChequeNo() {
        return staleChequeNo;
    }

    /**
     * Sets the value of the staleChequeNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaleChequeNo(String value) {
        this.staleChequeNo = value;
    }

    /**
     * Gets the value of the staleAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaleAmount() {
        return staleAmount;
    }

    /**
     * Sets the value of the staleAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaleAmount(String value) {
        this.staleAmount = value;
    }

    /**
     * Gets the value of the exceptionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionStatus() {
        return exceptionStatus;
    }

    /**
     * Sets the value of the exceptionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionStatus(String value) {
        this.exceptionStatus = value;
    }

    /**
     * Gets the value of the exceptionPRNNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionPRNNo() {
        return exceptionPRNNo;
    }

    /**
     * Sets the value of the exceptionPRNNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionPRNNo(String value) {
        this.exceptionPRNNo = value;
    }

    /**
     * Gets the value of the exceptionChequeNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionChequeNo() {
        return exceptionChequeNo;
    }

    /**
     * Sets the value of the exceptionChequeNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionChequeNo(String value) {
        this.exceptionChequeNo = value;
    }

    /**
     * Gets the value of the exceptionAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExceptionAmount() {
        return exceptionAmount;
    }

    /**
     * Sets the value of the exceptionAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExceptionAmount(String value) {
        this.exceptionAmount = value;
    }

}
