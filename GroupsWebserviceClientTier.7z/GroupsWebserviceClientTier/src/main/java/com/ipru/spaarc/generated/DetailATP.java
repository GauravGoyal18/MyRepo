
package com.ipru.spaarc.generated;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DetailATP complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailATP">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="FromFund" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ToFund" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="RequestMonthlyCycleDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ATPRequestReceivedToDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ATPRequestReceivedByDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailATP", propOrder = {
    "interactionID",
    "fromFund",
    "toFund",
    "amount",
    "requestMonthlyCycleDate",
    "atpRequestReceivedToDate",
    "atpRequestReceivedByDate",
    "isUpdated",
    "isChanged"
})
public class DetailATP {

    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "FromFund")
    protected String fromFund;
    @XmlElement(name = "ToFund")
    protected String toFund;
    @XmlElement(name = "Amount", required = true)
    protected BigDecimal amount;
    @XmlElement(name = "RequestMonthlyCycleDate")
    protected String requestMonthlyCycleDate;
    @XmlElement(name = "ATPRequestReceivedToDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar atpRequestReceivedToDate;
    @XmlElement(name = "ATPRequestReceivedByDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar atpRequestReceivedByDate;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "IsChanged")
    protected boolean isChanged;

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the fromFund property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromFund() {
        return fromFund;
    }

    /**
     * Sets the value of the fromFund property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromFund(String value) {
        this.fromFund = value;
    }

    /**
     * Gets the value of the toFund property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToFund() {
        return toFund;
    }

    /**
     * Sets the value of the toFund property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToFund(String value) {
        this.toFund = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmount(BigDecimal value) {
        this.amount = value;
    }

    /**
     * Gets the value of the requestMonthlyCycleDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestMonthlyCycleDate() {
        return requestMonthlyCycleDate;
    }

    /**
     * Sets the value of the requestMonthlyCycleDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestMonthlyCycleDate(String value) {
        this.requestMonthlyCycleDate = value;
    }

    /**
     * Gets the value of the atpRequestReceivedToDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getATPRequestReceivedToDate() {
        return atpRequestReceivedToDate;
    }

    /**
     * Sets the value of the atpRequestReceivedToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setATPRequestReceivedToDate(XMLGregorianCalendar value) {
        this.atpRequestReceivedToDate = value;
    }

    /**
     * Gets the value of the atpRequestReceivedByDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getATPRequestReceivedByDate() {
        return atpRequestReceivedByDate;
    }

    /**
     * Sets the value of the atpRequestReceivedByDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setATPRequestReceivedByDate(XMLGregorianCalendar value) {
        this.atpRequestReceivedByDate = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

}
