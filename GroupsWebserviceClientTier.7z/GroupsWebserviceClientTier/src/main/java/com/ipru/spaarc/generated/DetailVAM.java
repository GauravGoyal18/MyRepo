
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Detail_VAM complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Detail_VAM">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsEmpanel" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Detail_VAM", propOrder = {
    "isEmpanel"
})
public class DetailVAM {

    @XmlElement(name = "IsEmpanel")
    protected boolean isEmpanel;

    /**
     * Gets the value of the isEmpanel property.
     * 
     */
    public boolean isIsEmpanel() {
        return isEmpanel;
    }

    /**
     * Sets the value of the isEmpanel property.
     * 
     */
    public void setIsEmpanel(boolean value) {
        this.isEmpanel = value;
    }

}
