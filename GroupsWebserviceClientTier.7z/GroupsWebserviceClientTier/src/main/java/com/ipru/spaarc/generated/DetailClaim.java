
package com.ipru.spaarc.generated;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DetailClaim complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailClaim">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="DateOfDeath" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Remarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="PrimaryLife" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClaimType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PaymentMethod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="BankAccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BankName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BranchName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MICRCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IFSC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PayoutHoldTillDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="SignatureVerification" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhotoID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="KYC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssignToRisk" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PayoutReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerMeet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerBusy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerNotInterest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerNotContactable" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfWaiverOnRetention" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerOut" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfCustomerNA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailClaim", propOrder = {
    "isChanged",
    "interactionID",
    "dateOfDeath",
    "remarks",
    "isUpdated",
    "primaryLife",
    "claimType",
    "agentName",
    "agentCode",
    "paymentMethod",
    "amount",
    "bankAccountNo",
    "accountType",
    "bankName",
    "branchName",
    "micrCode",
    "ifsc",
    "payoutHoldTillDate",
    "signatureVerification",
    "photoID",
    "kyc",
    "assignToRisk",
    "payoutReason",
    "typeOfCustomerMeet",
    "typeOfCustomerBusy",
    "typeOfCustomerNotInterest",
    "typeOfCustomerNotContactable",
    "typeOfWaiverOnRetention",
    "typeOfCustomerOut",
    "typeOfCustomerNA"
})
public class DetailClaim {

    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "DateOfDeath", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateOfDeath;
    @XmlElement(name = "Remarks")
    protected String remarks;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "PrimaryLife")
    protected String primaryLife;
    @XmlElement(name = "ClaimType")
    protected String claimType;
    @XmlElement(name = "AgentName")
    protected String agentName;
    @XmlElement(name = "AgentCode")
    protected String agentCode;
    @XmlElement(name = "PaymentMethod")
    protected String paymentMethod;
    @XmlElement(name = "Amount", required = true)
    protected BigDecimal amount;
    @XmlElement(name = "BankAccountNo")
    protected String bankAccountNo;
    @XmlElement(name = "AccountType")
    protected String accountType;
    @XmlElement(name = "BankName")
    protected String bankName;
    @XmlElement(name = "BranchName")
    protected String branchName;
    @XmlElement(name = "MICRCode")
    protected String micrCode;
    @XmlElement(name = "IFSC")
    protected String ifsc;
    @XmlElement(name = "PayoutHoldTillDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar payoutHoldTillDate;
    @XmlElement(name = "SignatureVerification")
    protected String signatureVerification;
    @XmlElement(name = "PhotoID")
    protected String photoID;
    @XmlElement(name = "KYC")
    protected String kyc;
    @XmlElement(name = "AssignToRisk")
    protected String assignToRisk;
    @XmlElement(name = "PayoutReason")
    protected String payoutReason;
    @XmlElement(name = "TypeOfCustomerMeet")
    protected String typeOfCustomerMeet;
    @XmlElement(name = "TypeOfCustomerBusy")
    protected String typeOfCustomerBusy;
    @XmlElement(name = "TypeOfCustomerNotInterest")
    protected String typeOfCustomerNotInterest;
    @XmlElement(name = "TypeOfCustomerNotContactable")
    protected String typeOfCustomerNotContactable;
    @XmlElement(name = "TypeOfWaiverOnRetention")
    protected String typeOfWaiverOnRetention;
    @XmlElement(name = "TypeOfCustomerOut")
    protected String typeOfCustomerOut;
    @XmlElement(name = "TypeOfCustomerNA")
    protected String typeOfCustomerNA;

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the dateOfDeath property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfDeath() {
        return dateOfDeath;
    }

    /**
     * Sets the value of the dateOfDeath property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfDeath(XMLGregorianCalendar value) {
        this.dateOfDeath = value;
    }

    /**
     * Gets the value of the remarks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * Sets the value of the remarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemarks(String value) {
        this.remarks = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the primaryLife property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryLife() {
        return primaryLife;
    }

    /**
     * Sets the value of the primaryLife property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryLife(String value) {
        this.primaryLife = value;
    }

    /**
     * Gets the value of the claimType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimType() {
        return claimType;
    }

    /**
     * Sets the value of the claimType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimType(String value) {
        this.claimType = value;
    }

    /**
     * Gets the value of the agentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentName() {
        return agentName;
    }

    /**
     * Sets the value of the agentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentName(String value) {
        this.agentName = value;
    }

    /**
     * Gets the value of the agentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentCode() {
        return agentCode;
    }

    /**
     * Sets the value of the agentCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentCode(String value) {
        this.agentCode = value;
    }

    /**
     * Gets the value of the paymentMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * Sets the value of the paymentMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentMethod(String value) {
        this.paymentMethod = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmount(BigDecimal value) {
        this.amount = value;
    }

    /**
     * Gets the value of the bankAccountNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankAccountNo() {
        return bankAccountNo;
    }

    /**
     * Sets the value of the bankAccountNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAccountNo(String value) {
        this.bankAccountNo = value;
    }

    /**
     * Gets the value of the accountType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * Sets the value of the accountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountType(String value) {
        this.accountType = value;
    }

    /**
     * Gets the value of the bankName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * Sets the value of the bankName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankName(String value) {
        this.bankName = value;
    }

    /**
     * Gets the value of the branchName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchName() {
        return branchName;
    }

    /**
     * Sets the value of the branchName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchName(String value) {
        this.branchName = value;
    }

    /**
     * Gets the value of the micrCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMICRCode() {
        return micrCode;
    }

    /**
     * Sets the value of the micrCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMICRCode(String value) {
        this.micrCode = value;
    }

    /**
     * Gets the value of the ifsc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIFSC() {
        return ifsc;
    }

    /**
     * Sets the value of the ifsc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIFSC(String value) {
        this.ifsc = value;
    }

    /**
     * Gets the value of the payoutHoldTillDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPayoutHoldTillDate() {
        return payoutHoldTillDate;
    }

    /**
     * Sets the value of the payoutHoldTillDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPayoutHoldTillDate(XMLGregorianCalendar value) {
        this.payoutHoldTillDate = value;
    }

    /**
     * Gets the value of the signatureVerification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignatureVerification() {
        return signatureVerification;
    }

    /**
     * Sets the value of the signatureVerification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignatureVerification(String value) {
        this.signatureVerification = value;
    }

    /**
     * Gets the value of the photoID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhotoID() {
        return photoID;
    }

    /**
     * Sets the value of the photoID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhotoID(String value) {
        this.photoID = value;
    }

    /**
     * Gets the value of the kyc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKYC() {
        return kyc;
    }

    /**
     * Sets the value of the kyc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKYC(String value) {
        this.kyc = value;
    }

    /**
     * Gets the value of the assignToRisk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignToRisk() {
        return assignToRisk;
    }

    /**
     * Sets the value of the assignToRisk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignToRisk(String value) {
        this.assignToRisk = value;
    }

    /**
     * Gets the value of the payoutReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayoutReason() {
        return payoutReason;
    }

    /**
     * Sets the value of the payoutReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayoutReason(String value) {
        this.payoutReason = value;
    }

    /**
     * Gets the value of the typeOfCustomerMeet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerMeet() {
        return typeOfCustomerMeet;
    }

    /**
     * Sets the value of the typeOfCustomerMeet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerMeet(String value) {
        this.typeOfCustomerMeet = value;
    }

    /**
     * Gets the value of the typeOfCustomerBusy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerBusy() {
        return typeOfCustomerBusy;
    }

    /**
     * Sets the value of the typeOfCustomerBusy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerBusy(String value) {
        this.typeOfCustomerBusy = value;
    }

    /**
     * Gets the value of the typeOfCustomerNotInterest property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerNotInterest() {
        return typeOfCustomerNotInterest;
    }

    /**
     * Sets the value of the typeOfCustomerNotInterest property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerNotInterest(String value) {
        this.typeOfCustomerNotInterest = value;
    }

    /**
     * Gets the value of the typeOfCustomerNotContactable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerNotContactable() {
        return typeOfCustomerNotContactable;
    }

    /**
     * Sets the value of the typeOfCustomerNotContactable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerNotContactable(String value) {
        this.typeOfCustomerNotContactable = value;
    }

    /**
     * Gets the value of the typeOfWaiverOnRetention property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfWaiverOnRetention() {
        return typeOfWaiverOnRetention;
    }

    /**
     * Sets the value of the typeOfWaiverOnRetention property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfWaiverOnRetention(String value) {
        this.typeOfWaiverOnRetention = value;
    }

    /**
     * Gets the value of the typeOfCustomerOut property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerOut() {
        return typeOfCustomerOut;
    }

    /**
     * Sets the value of the typeOfCustomerOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerOut(String value) {
        this.typeOfCustomerOut = value;
    }

    /**
     * Gets the value of the typeOfCustomerNA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfCustomerNA() {
        return typeOfCustomerNA;
    }

    /**
     * Sets the value of the typeOfCustomerNA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfCustomerNA(String value) {
        this.typeOfCustomerNA = value;
    }

}
