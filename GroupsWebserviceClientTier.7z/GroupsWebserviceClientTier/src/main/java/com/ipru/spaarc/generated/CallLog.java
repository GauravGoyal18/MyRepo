
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for CallLog complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CallLog">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BatchID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="TYPEOFDISPOSAL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLAIMRECIEVEDAMOUNT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINTTYPEID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINTSTATUSID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RecordID" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="IsBREProcess" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="HoldingMail1Flag" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="HoldingMail2Flag" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="HoldingMail2Fields" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="routingTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="documents" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="count_of_supporting" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="supporting_attached" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="scanned_status" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="RMCAssignToBranch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Tracker" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndexAssignment" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="IndexJournal" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsCallOpen" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsUnsaved" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsCreated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="SessionId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="ClientType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CallID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CALLCATEGORY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OLDCALLCATEGORY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Category" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Sentiments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ModeOfComplaint" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ControlMActioned" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="TatDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OldCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ComplaintReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Location1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsArchived" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="CallType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SubType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Owner" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TAT" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ExpectedClosureDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Reference" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Source" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CallStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CallDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClosureDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OLDPOLICY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OLDCLIENTTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClosureType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReceivedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ModBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReceivedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="AssignToBranch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RepeatStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EscalationStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DefectReason" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClosedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClosedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IsUpdatingInHeat" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsUpdatingInHeat_New" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="LastUpdateBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastUpdatedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ModDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ModTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Closed" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsCallSaved" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Assignment" type="{http://generated.spaarc.ipru.com/}ArrayOfAnyType" minOccurs="0"/>
 *         &lt;element name="Journal" type="{http://generated.spaarc.ipru.com/}ArrayOfAnyType" minOccurs="0"/>
 *         &lt;element name="Subset" type="{http://generated.spaarc.ipru.com/}Subset" minOccurs="0"/>
 *         &lt;element name="heat_Gen" type="{http://generated.spaarc.ipru.com/}ArrayOfAnyType" minOccurs="0"/>
 *         &lt;element name="aTGRcvdEmailID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Details" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/>
 *         &lt;element name="IsDetailAdded" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ModeOfDispatch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CallAlerts" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ACDNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GUID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLINO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VerificationDone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsModeOfDispatchChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsCallAlertsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ReceivedbyBranch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Subject" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BranchInteractionID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ATGCallFlag" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Aging" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="CallSourceRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EscDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="State" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgingHHMM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AllotedId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="QueueType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VendorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CallEntryDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IsFreshMailCall" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsCallToBeTracked" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="OriginalTokenNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CSE_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FeedBack" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WebserviceResponse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MasterCallType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsSatisfied" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsLapse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsDisposed" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="DisposeBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DisposeDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ReOpenedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReOpenedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="TokenNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IRDATAT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLOSURE_REQUEST_LETTER_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IRDAEXPECTEDCLOSUREDATE" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ACKNOWLEDGE" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="CHKACKNOWLEDGE" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="OnLineSales" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReOpenedSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserAreaCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINTIDDESCOMBINATIONERROR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INVALIDPOLICYNUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INVALIDAPPLICATIONNUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PINCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ISALREADYCALLSAVED" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IrdaEntiry" type="{http://generated.spaarc.ipru.com/}IRDA_Entity" minOccurs="0"/>
 *         &lt;element name="USERID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SFINCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FirstClosedDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ReopenedDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReopenedClosedDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JournalNotes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserArea_Code" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ModeOfClosure" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SurrenderValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SurrenderValuePer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TotalPremium" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InvestedPremium" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SuccessFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PTD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SchAppntDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ReSchAppntDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="AddressOption" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="E_advMobNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EIA" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IRCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EPolicies" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Existing_EIA_Flag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FreshEmail" type="{http://generated.spaarc.ipru.com/}FreshEmailEntity" minOccurs="0"/>
 *         &lt;element name="IsFreshEmailCall" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="LstReOpenedDetail" type="{http://generated.spaarc.ipru.com/}ArrayOfReOpenedDetail" minOccurs="0"/>
 *         &lt;element name="IndexReOpened" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="PrevIndexReOpened" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="IsReOpened" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="AutoCallLogWSErrorMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Attachment1" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="Attachment1Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OriginalTAT" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ResCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RepeatCust" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Attachment" type="{http://generated.spaarc.ipru.com/}ArrayOfAnyType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CallLog", propOrder = {
    "batchID",
    "typeofdisposal",
    "claimrecievedamount",
    "complainttypeid",
    "complaintstatusid",
    "recordID",
    "isBREProcess",
    "holdingMail1Flag",
    "holdingMail2Flag",
    "holdingMail2Fields",
    "routingTo",
    "documents",
    "countOfSupporting",
    "supportingAttached",
    "scannedStatus",
    "rmcAssignToBranch",
    "tracker",
    "indexAssignment",
    "indexJournal",
    "isChanged",
    "isCallOpen",
    "isUnsaved",
    "isCreated",
    "interactionID",
    "sessionId",
    "clientType",
    "callID",
    "callcategory",
    "oldcallcategory",
    "category",
    "sentiments",
    "modeOfComplaint",
    "controlMActioned",
    "tatDate",
    "oldCategory",
    "complaintReason",
    "location1",
    "isArchived",
    "callType",
    "subType",
    "owner",
    "tat",
    "expectedClosureDateTime",
    "reference",
    "source",
    "callStatus",
    "callDesc",
    "closureDesc",
    "oldpolicy",
    "oldclienttype",
    "closureType",
    "receivedBy",
    "modBy",
    "receivedDateTime",
    "assignToBranch",
    "repeatStatus",
    "escalationStatus",
    "defectReason",
    "closedBy",
    "closedDateTime",
    "isUpdatingInHeat",
    "isUpdatingInHeatNew",
    "lastUpdateBy",
    "lastUpdatedDateTime",
    "modDate",
    "modTime",
    "closed",
    "isCallSaved",
    "isUpdated",
    "assignment",
    "journal",
    "subset",
    "heatGen",
    "atgRcvdEmailID",
    "details",
    "isDetailAdded",
    "modeOfDispatch",
    "callAlerts",
    "acdno",
    "guid",
    "clino",
    "verificationDone",
    "isModeOfDispatchChanged",
    "isCallAlertsChanged",
    "receivedbyBranch",
    "subject",
    "branchInteractionID",
    "atgCallFlag",
    "aging",
    "callSourceRef",
    "emailType",
    "escDate",
    "state",
    "agingHHMM",
    "allotedId",
    "queueType",
    "vendorCode",
    "callEntryDateTime",
    "isFreshMailCall",
    "isCallToBeTracked",
    "originalTokenNumber",
    "cseid",
    "feedBack",
    "webserviceResponse",
    "masterCallType",
    "isSatisfied",
    "isLapse",
    "isDisposed",
    "disposeBy",
    "disposeDateTime",
    "reOpenedBy",
    "reOpenedDateTime",
    "tokenNumber",
    "irdatat",
    "closurerequestletterdate",
    "irdaexpectedclosuredate",
    "acknowledge",
    "chkacknowledge",
    "onLineSales",
    "reOpenedSource",
    "userAreaCode",
    "complaintiddescombinationerror",
    "invalidpolicynumber",
    "invalidapplicationnumber",
    "pincode",
    "isalreadycallsaved",
    "irdaEntiry",
    "userid",
    "sfinCode",
    "firstClosedDateTime",
    "reopenedDesc",
    "reopenedClosedDesc",
    "journalNotes",
    "xxxUserAreaCode",
    "modeOfClosure",
    "surrenderValue",
    "surrenderValuePer",
    "fundValue",
    "totalPremium",
    "investedPremium",
    "successFlag",
    "ptd",
    "schAppntDate",
    "reSchAppntDate",
    "addressOption",
    "address",
    "eAdvMobNumber",
    "eia",
    "irCode",
    "ePolicies",
    "existingEIAFlag",
    "freshEmail",
    "isFreshEmailCall",
    "lstReOpenedDetail",
    "indexReOpened",
    "prevIndexReOpened",
    "isReOpened",
    "autoCallLogWSErrorMsg",
    "attachment1",
    "attachment1Name",
    "originalTAT",
    "resCode",
    "repeatCust",
    "attachment"
})
public class CallLog {

    @XmlElement(name = "BatchID")
    protected long batchID;
    @XmlElement(name = "TYPEOFDISPOSAL")
    protected String typeofdisposal;
    @XmlElement(name = "CLAIMRECIEVEDAMOUNT")
    protected String claimrecievedamount;
    @XmlElement(name = "COMPLAINTTYPEID")
    protected String complainttypeid;
    @XmlElement(name = "COMPLAINTSTATUSID")
    protected String complaintstatusid;
    @XmlElement(name = "RecordID")
    protected int recordID;
    @XmlElement(name = "IsBREProcess")
    protected boolean isBREProcess;
    @XmlElement(name = "HoldingMail1Flag")
    protected int holdingMail1Flag;
    @XmlElement(name = "HoldingMail2Flag")
    protected int holdingMail2Flag;
    @XmlElement(name = "HoldingMail2Fields")
    protected String holdingMail2Fields;
    protected String routingTo;
    protected int documents;
    @XmlElement(name = "count_of_supporting")
    protected String countOfSupporting;
    @XmlElement(name = "supporting_attached")
    protected String supportingAttached;
    @XmlElement(name = "scanned_status")
    protected int scannedStatus;
    @XmlElement(name = "RMCAssignToBranch")
    protected String rmcAssignToBranch;
    @XmlElement(name = "Tracker")
    protected String tracker;
    @XmlElement(name = "IndexAssignment")
    protected int indexAssignment;
    @XmlElement(name = "IndexJournal")
    protected int indexJournal;
    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "IsCallOpen")
    protected boolean isCallOpen;
    @XmlElement(name = "IsUnsaved")
    protected boolean isUnsaved;
    @XmlElement(name = "IsCreated")
    protected boolean isCreated;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "SessionId")
    protected long sessionId;
    @XmlElement(name = "ClientType")
    protected String clientType;
    @XmlElement(name = "CallID")
    protected String callID;
    @XmlElement(name = "CALLCATEGORY")
    protected String callcategory;
    @XmlElement(name = "OLDCALLCATEGORY")
    protected String oldcallcategory;
    @XmlElement(name = "Category")
    protected String category;
    @XmlElement(name = "Sentiments")
    protected String sentiments;
    @XmlElement(name = "ModeOfComplaint")
    protected String modeOfComplaint;
    @XmlElement(name = "ControlMActioned")
    protected boolean controlMActioned;
    @XmlElement(name = "TatDate")
    protected String tatDate;
    @XmlElement(name = "OldCategory")
    protected String oldCategory;
    @XmlElement(name = "ComplaintReason")
    protected String complaintReason;
    @XmlElement(name = "Location1")
    protected String location1;
    @XmlElement(name = "IsArchived")
    protected boolean isArchived;
    @XmlElement(name = "CallType")
    protected String callType;
    @XmlElement(name = "SubType")
    protected String subType;
    @XmlElement(name = "Owner")
    protected String owner;
    @XmlElement(name = "TAT")
    protected int tat;
    @XmlElement(name = "ExpectedClosureDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar expectedClosureDateTime;
    @XmlElement(name = "Reference")
    protected String reference;
    @XmlElement(name = "Source")
    protected String source;
    @XmlElement(name = "CallStatus")
    protected String callStatus;
    @XmlElement(name = "CallDesc")
    protected String callDesc;
    @XmlElement(name = "ClosureDesc")
    protected String closureDesc;
    @XmlElement(name = "OLDPOLICY")
    protected String oldpolicy;
    @XmlElement(name = "OLDCLIENTTYPE")
    protected String oldclienttype;
    @XmlElement(name = "ClosureType")
    protected String closureType;
    @XmlElement(name = "ReceivedBy")
    protected String receivedBy;
    @XmlElement(name = "ModBy")
    protected String modBy;
    @XmlElement(name = "ReceivedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar receivedDateTime;
    @XmlElement(name = "AssignToBranch")
    protected String assignToBranch;
    @XmlElement(name = "RepeatStatus")
    protected String repeatStatus;
    @XmlElement(name = "EscalationStatus")
    protected String escalationStatus;
    @XmlElement(name = "DefectReason")
    protected String defectReason;
    @XmlElement(name = "ClosedBy")
    protected String closedBy;
    @XmlElement(name = "ClosedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar closedDateTime;
    @XmlElement(name = "IsUpdatingInHeat")
    protected boolean isUpdatingInHeat;
    @XmlElement(name = "IsUpdatingInHeat_New")
    protected boolean isUpdatingInHeatNew;
    @XmlElement(name = "LastUpdateBy")
    protected String lastUpdateBy;
    @XmlElement(name = "LastUpdatedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastUpdatedDateTime;
    @XmlElement(name = "ModDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar modDate;
    @XmlElement(name = "ModTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar modTime;
    @XmlElement(name = "Closed")
    protected boolean closed;
    @XmlElement(name = "IsCallSaved")
    protected boolean isCallSaved;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "Assignment")
    protected ArrayOfAnyType assignment;
    @XmlElement(name = "Journal")
    protected ArrayOfAnyType journal;
    @XmlElement(name = "Subset")
    protected Subset subset;
    @XmlElement(name = "heat_Gen")
    protected ArrayOfAnyType heatGen;
    @XmlElement(name = "aTGRcvdEmailID")
    protected String atgRcvdEmailID;
    @XmlElement(name = "Details")
    protected Object details;
    @XmlElement(name = "IsDetailAdded")
    protected boolean isDetailAdded;
    @XmlElement(name = "ModeOfDispatch")
    protected String modeOfDispatch;
    @XmlElement(name = "CallAlerts")
    protected String callAlerts;
    @XmlElement(name = "ACDNO")
    protected String acdno;
    @XmlElement(name = "GUID")
    protected String guid;
    @XmlElement(name = "CLINO")
    protected String clino;
    @XmlElement(name = "VerificationDone")
    protected String verificationDone;
    @XmlElement(name = "IsModeOfDispatchChanged")
    protected boolean isModeOfDispatchChanged;
    @XmlElement(name = "IsCallAlertsChanged")
    protected boolean isCallAlertsChanged;
    @XmlElement(name = "ReceivedbyBranch")
    protected String receivedbyBranch;
    @XmlElement(name = "Subject")
    protected String subject;
    @XmlElement(name = "BranchInteractionID")
    protected String branchInteractionID;
    @XmlElement(name = "ATGCallFlag")
    protected int atgCallFlag;
    @XmlElement(name = "Aging")
    protected int aging;
    @XmlElement(name = "CallSourceRef")
    protected String callSourceRef;
    @XmlElement(name = "EmailType")
    protected String emailType;
    @XmlElement(name = "EscDate")
    protected String escDate;
    @XmlElement(name = "State")
    protected String state;
    @XmlElement(name = "AgingHHMM")
    protected String agingHHMM;
    @XmlElement(name = "AllotedId")
    protected String allotedId;
    @XmlElement(name = "QueueType")
    protected String queueType;
    @XmlElement(name = "VendorCode")
    protected String vendorCode;
    @XmlElement(name = "CallEntryDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar callEntryDateTime;
    @XmlElement(name = "IsFreshMailCall")
    protected boolean isFreshMailCall;
    @XmlElement(name = "IsCallToBeTracked")
    protected boolean isCallToBeTracked;
    @XmlElement(name = "OriginalTokenNumber")
    protected String originalTokenNumber;
    @XmlElement(name = "CSE_ID")
    protected String cseid;
    @XmlElement(name = "FeedBack")
    protected String feedBack;
    @XmlElement(name = "WebserviceResponse")
    protected String webserviceResponse;
    @XmlElement(name = "MasterCallType")
    protected String masterCallType;
    @XmlElement(name = "IsSatisfied")
    protected String isSatisfied;
    @XmlElement(name = "IsLapse")
    protected String isLapse;
    @XmlElement(name = "IsDisposed")
    protected boolean isDisposed;
    @XmlElement(name = "DisposeBy")
    protected String disposeBy;
    @XmlElement(name = "DisposeDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar disposeDateTime;
    @XmlElement(name = "ReOpenedBy")
    protected String reOpenedBy;
    @XmlElement(name = "ReOpenedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar reOpenedDateTime;
    @XmlElement(name = "TokenNumber")
    protected String tokenNumber;
    @XmlElement(name = "IRDATAT")
    protected String irdatat;
    @XmlElement(name = "CLOSURE_REQUEST_LETTER_DATE")
    protected String closurerequestletterdate;
    @XmlElement(name = "IRDAEXPECTEDCLOSUREDATE", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar irdaexpectedclosuredate;
    @XmlElement(name = "ACKNOWLEDGE")
    protected boolean acknowledge;
    @XmlElement(name = "CHKACKNOWLEDGE")
    protected boolean chkacknowledge;
    @XmlElement(name = "OnLineSales")
    protected String onLineSales;
    @XmlElement(name = "ReOpenedSource")
    protected String reOpenedSource;
    @XmlElement(name = "UserAreaCode")
    protected String userAreaCode;
    @XmlElement(name = "COMPLAINTIDDESCOMBINATIONERROR")
    protected String complaintiddescombinationerror;
    @XmlElement(name = "INVALIDPOLICYNUMBER")
    protected String invalidpolicynumber;
    @XmlElement(name = "INVALIDAPPLICATIONNUMBER")
    protected String invalidapplicationnumber;
    @XmlElement(name = "PINCODE")
    protected String pincode;
    @XmlElement(name = "ISALREADYCALLSAVED")
    protected boolean isalreadycallsaved;
    @XmlElement(name = "IrdaEntiry")
    protected IRDAEntity irdaEntiry;
    @XmlElement(name = "USERID")
    protected String userid;
    @XmlElement(name = "SFINCode")
    protected String sfinCode;
    @XmlElement(name = "FirstClosedDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar firstClosedDateTime;
    @XmlElement(name = "ReopenedDesc")
    protected String reopenedDesc;
    @XmlElement(name = "ReopenedClosedDesc")
    protected String reopenedClosedDesc;
    @XmlElement(name = "JournalNotes")
    protected String journalNotes;
    @XmlElement(name = "UserArea_Code")
    protected String xxxUserAreaCode;
    @XmlElement(name = "ModeOfClosure")
    protected String modeOfClosure;
    @XmlElement(name = "SurrenderValue")
    protected String surrenderValue;
    @XmlElement(name = "SurrenderValuePer")
    protected String surrenderValuePer;
    @XmlElement(name = "FundValue")
    protected String fundValue;
    @XmlElement(name = "TotalPremium")
    protected String totalPremium;
    @XmlElement(name = "InvestedPremium")
    protected String investedPremium;
    @XmlElement(name = "SuccessFlag")
    protected String successFlag;
    @XmlElement(name = "PTD")
    protected String ptd;
    @XmlElement(name = "SchAppntDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar schAppntDate;
    @XmlElement(name = "ReSchAppntDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar reSchAppntDate;
    @XmlElement(name = "AddressOption")
    protected String addressOption;
    @XmlElement(name = "Address")
    protected String address;
    @XmlElement(name = "E_advMobNumber")
    protected String eAdvMobNumber;
    @XmlElement(name = "EIA")
    protected String eia;
    @XmlElement(name = "IRCode")
    protected String irCode;
    @XmlElement(name = "EPolicies")
    protected String ePolicies;
    @XmlElement(name = "Existing_EIA_Flag")
    protected String existingEIAFlag;
    @XmlElement(name = "FreshEmail")
    protected FreshEmailEntity freshEmail;
    @XmlElement(name = "IsFreshEmailCall")
    protected boolean isFreshEmailCall;
    @XmlElement(name = "LstReOpenedDetail")
    protected ArrayOfReOpenedDetail lstReOpenedDetail;
    @XmlElement(name = "IndexReOpened")
    protected int indexReOpened;
    @XmlElement(name = "PrevIndexReOpened")
    protected int prevIndexReOpened;
    @XmlElement(name = "IsReOpened")
    protected boolean isReOpened;
    @XmlElement(name = "AutoCallLogWSErrorMsg")
    protected String autoCallLogWSErrorMsg;
    @XmlElement(name = "Attachment1")
    protected byte[] attachment1;
    @XmlElement(name = "Attachment1Name")
    protected String attachment1Name;
    @XmlElement(name = "OriginalTAT")
    protected int originalTAT;
    @XmlElement(name = "ResCode")
    protected String resCode;
    @XmlElement(name = "RepeatCust")
    protected boolean repeatCust;
    @XmlElement(name = "Attachment")
    protected ArrayOfAnyType attachment;

    /**
     * Gets the value of the batchID property.
     * 
     */
    public long getBatchID() {
        return batchID;
    }

    /**
     * Sets the value of the batchID property.
     * 
     */
    public void setBatchID(long value) {
        this.batchID = value;
    }

    /**
     * Gets the value of the typeofdisposal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTYPEOFDISPOSAL() {
        return typeofdisposal;
    }

    /**
     * Sets the value of the typeofdisposal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTYPEOFDISPOSAL(String value) {
        this.typeofdisposal = value;
    }

    /**
     * Gets the value of the claimrecievedamount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLAIMRECIEVEDAMOUNT() {
        return claimrecievedamount;
    }

    /**
     * Sets the value of the claimrecievedamount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLAIMRECIEVEDAMOUNT(String value) {
        this.claimrecievedamount = value;
    }

    /**
     * Gets the value of the complainttypeid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTTYPEID() {
        return complainttypeid;
    }

    /**
     * Sets the value of the complainttypeid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTTYPEID(String value) {
        this.complainttypeid = value;
    }

    /**
     * Gets the value of the complaintstatusid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTSTATUSID() {
        return complaintstatusid;
    }

    /**
     * Sets the value of the complaintstatusid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTSTATUSID(String value) {
        this.complaintstatusid = value;
    }

    /**
     * Gets the value of the recordID property.
     * 
     */
    public int getRecordID() {
        return recordID;
    }

    /**
     * Sets the value of the recordID property.
     * 
     */
    public void setRecordID(int value) {
        this.recordID = value;
    }

    /**
     * Gets the value of the isBREProcess property.
     * 
     */
    public boolean isIsBREProcess() {
        return isBREProcess;
    }

    /**
     * Sets the value of the isBREProcess property.
     * 
     */
    public void setIsBREProcess(boolean value) {
        this.isBREProcess = value;
    }

    /**
     * Gets the value of the holdingMail1Flag property.
     * 
     */
    public int getHoldingMail1Flag() {
        return holdingMail1Flag;
    }

    /**
     * Sets the value of the holdingMail1Flag property.
     * 
     */
    public void setHoldingMail1Flag(int value) {
        this.holdingMail1Flag = value;
    }

    /**
     * Gets the value of the holdingMail2Flag property.
     * 
     */
    public int getHoldingMail2Flag() {
        return holdingMail2Flag;
    }

    /**
     * Sets the value of the holdingMail2Flag property.
     * 
     */
    public void setHoldingMail2Flag(int value) {
        this.holdingMail2Flag = value;
    }

    /**
     * Gets the value of the holdingMail2Fields property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldingMail2Fields() {
        return holdingMail2Fields;
    }

    /**
     * Sets the value of the holdingMail2Fields property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldingMail2Fields(String value) {
        this.holdingMail2Fields = value;
    }

    /**
     * Gets the value of the routingTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoutingTo() {
        return routingTo;
    }

    /**
     * Sets the value of the routingTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoutingTo(String value) {
        this.routingTo = value;
    }

    /**
     * Gets the value of the documents property.
     * 
     */
    public int getDocuments() {
        return documents;
    }

    /**
     * Sets the value of the documents property.
     * 
     */
    public void setDocuments(int value) {
        this.documents = value;
    }

    /**
     * Gets the value of the countOfSupporting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountOfSupporting() {
        return countOfSupporting;
    }

    /**
     * Sets the value of the countOfSupporting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountOfSupporting(String value) {
        this.countOfSupporting = value;
    }

    /**
     * Gets the value of the supportingAttached property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSupportingAttached() {
        return supportingAttached;
    }

    /**
     * Sets the value of the supportingAttached property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSupportingAttached(String value) {
        this.supportingAttached = value;
    }

    /**
     * Gets the value of the scannedStatus property.
     * 
     */
    public int getScannedStatus() {
        return scannedStatus;
    }

    /**
     * Sets the value of the scannedStatus property.
     * 
     */
    public void setScannedStatus(int value) {
        this.scannedStatus = value;
    }

    /**
     * Gets the value of the rmcAssignToBranch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRMCAssignToBranch() {
        return rmcAssignToBranch;
    }

    /**
     * Sets the value of the rmcAssignToBranch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRMCAssignToBranch(String value) {
        this.rmcAssignToBranch = value;
    }

    /**
     * Gets the value of the tracker property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTracker() {
        return tracker;
    }

    /**
     * Sets the value of the tracker property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTracker(String value) {
        this.tracker = value;
    }

    /**
     * Gets the value of the indexAssignment property.
     * 
     */
    public int getIndexAssignment() {
        return indexAssignment;
    }

    /**
     * Sets the value of the indexAssignment property.
     * 
     */
    public void setIndexAssignment(int value) {
        this.indexAssignment = value;
    }

    /**
     * Gets the value of the indexJournal property.
     * 
     */
    public int getIndexJournal() {
        return indexJournal;
    }

    /**
     * Sets the value of the indexJournal property.
     * 
     */
    public void setIndexJournal(int value) {
        this.indexJournal = value;
    }

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the isCallOpen property.
     * 
     */
    public boolean isIsCallOpen() {
        return isCallOpen;
    }

    /**
     * Sets the value of the isCallOpen property.
     * 
     */
    public void setIsCallOpen(boolean value) {
        this.isCallOpen = value;
    }

    /**
     * Gets the value of the isUnsaved property.
     * 
     */
    public boolean isIsUnsaved() {
        return isUnsaved;
    }

    /**
     * Sets the value of the isUnsaved property.
     * 
     */
    public void setIsUnsaved(boolean value) {
        this.isUnsaved = value;
    }

    /**
     * Gets the value of the isCreated property.
     * 
     */
    public boolean isIsCreated() {
        return isCreated;
    }

    /**
     * Sets the value of the isCreated property.
     * 
     */
    public void setIsCreated(boolean value) {
        this.isCreated = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the sessionId property.
     * 
     */
    public long getSessionId() {
        return sessionId;
    }

    /**
     * Sets the value of the sessionId property.
     * 
     */
    public void setSessionId(long value) {
        this.sessionId = value;
    }

    /**
     * Gets the value of the clientType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientType() {
        return clientType;
    }

    /**
     * Sets the value of the clientType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientType(String value) {
        this.clientType = value;
    }

    /**
     * Gets the value of the callID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallID() {
        return callID;
    }

    /**
     * Sets the value of the callID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallID(String value) {
        this.callID = value;
    }

    /**
     * Gets the value of the callcategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCALLCATEGORY() {
        return callcategory;
    }

    /**
     * Sets the value of the callcategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCALLCATEGORY(String value) {
        this.callcategory = value;
    }

    /**
     * Gets the value of the oldcallcategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOLDCALLCATEGORY() {
        return oldcallcategory;
    }

    /**
     * Sets the value of the oldcallcategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOLDCALLCATEGORY(String value) {
        this.oldcallcategory = value;
    }

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategory(String value) {
        this.category = value;
    }

    /**
     * Gets the value of the sentiments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSentiments() {
        return sentiments;
    }

    /**
     * Sets the value of the sentiments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSentiments(String value) {
        this.sentiments = value;
    }

    /**
     * Gets the value of the modeOfComplaint property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModeOfComplaint() {
        return modeOfComplaint;
    }

    /**
     * Sets the value of the modeOfComplaint property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModeOfComplaint(String value) {
        this.modeOfComplaint = value;
    }

    /**
     * Gets the value of the controlMActioned property.
     * 
     */
    public boolean isControlMActioned() {
        return controlMActioned;
    }

    /**
     * Sets the value of the controlMActioned property.
     * 
     */
    public void setControlMActioned(boolean value) {
        this.controlMActioned = value;
    }

    /**
     * Gets the value of the tatDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTatDate() {
        return tatDate;
    }

    /**
     * Sets the value of the tatDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTatDate(String value) {
        this.tatDate = value;
    }

    /**
     * Gets the value of the oldCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldCategory() {
        return oldCategory;
    }

    /**
     * Sets the value of the oldCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldCategory(String value) {
        this.oldCategory = value;
    }

    /**
     * Gets the value of the complaintReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComplaintReason() {
        return complaintReason;
    }

    /**
     * Sets the value of the complaintReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComplaintReason(String value) {
        this.complaintReason = value;
    }

    /**
     * Gets the value of the location1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocation1() {
        return location1;
    }

    /**
     * Sets the value of the location1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocation1(String value) {
        this.location1 = value;
    }

    /**
     * Gets the value of the isArchived property.
     * 
     */
    public boolean isIsArchived() {
        return isArchived;
    }

    /**
     * Sets the value of the isArchived property.
     * 
     */
    public void setIsArchived(boolean value) {
        this.isArchived = value;
    }

    /**
     * Gets the value of the callType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallType() {
        return callType;
    }

    /**
     * Sets the value of the callType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallType(String value) {
        this.callType = value;
    }

    /**
     * Gets the value of the subType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubType() {
        return subType;
    }

    /**
     * Sets the value of the subType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubType(String value) {
        this.subType = value;
    }

    /**
     * Gets the value of the owner property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOwner() {
        return owner;
    }

    /**
     * Sets the value of the owner property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOwner(String value) {
        this.owner = value;
    }

    /**
     * Gets the value of the tat property.
     * 
     */
    public int getTAT() {
        return tat;
    }

    /**
     * Sets the value of the tat property.
     * 
     */
    public void setTAT(int value) {
        this.tat = value;
    }

    /**
     * Gets the value of the expectedClosureDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getExpectedClosureDateTime() {
        return expectedClosureDateTime;
    }

    /**
     * Sets the value of the expectedClosureDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setExpectedClosureDateTime(XMLGregorianCalendar value) {
        this.expectedClosureDateTime = value;
    }

    /**
     * Gets the value of the reference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReference() {
        return reference;
    }

    /**
     * Sets the value of the reference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReference(String value) {
        this.reference = value;
    }

    /**
     * Gets the value of the source property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSource() {
        return source;
    }

    /**
     * Sets the value of the source property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSource(String value) {
        this.source = value;
    }

    /**
     * Gets the value of the callStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallStatus() {
        return callStatus;
    }

    /**
     * Sets the value of the callStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallStatus(String value) {
        this.callStatus = value;
    }

    /**
     * Gets the value of the callDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallDesc() {
        return callDesc;
    }

    /**
     * Sets the value of the callDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallDesc(String value) {
        this.callDesc = value;
    }

    /**
     * Gets the value of the closureDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClosureDesc() {
        return closureDesc;
    }

    /**
     * Sets the value of the closureDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosureDesc(String value) {
        this.closureDesc = value;
    }

    /**
     * Gets the value of the oldpolicy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOLDPOLICY() {
        return oldpolicy;
    }

    /**
     * Sets the value of the oldpolicy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOLDPOLICY(String value) {
        this.oldpolicy = value;
    }

    /**
     * Gets the value of the oldclienttype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOLDCLIENTTYPE() {
        return oldclienttype;
    }

    /**
     * Sets the value of the oldclienttype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOLDCLIENTTYPE(String value) {
        this.oldclienttype = value;
    }

    /**
     * Gets the value of the closureType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClosureType() {
        return closureType;
    }

    /**
     * Sets the value of the closureType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosureType(String value) {
        this.closureType = value;
    }

    /**
     * Gets the value of the receivedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceivedBy() {
        return receivedBy;
    }

    /**
     * Sets the value of the receivedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceivedBy(String value) {
        this.receivedBy = value;
    }

    /**
     * Gets the value of the modBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModBy() {
        return modBy;
    }

    /**
     * Sets the value of the modBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModBy(String value) {
        this.modBy = value;
    }

    /**
     * Gets the value of the receivedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReceivedDateTime() {
        return receivedDateTime;
    }

    /**
     * Sets the value of the receivedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReceivedDateTime(XMLGregorianCalendar value) {
        this.receivedDateTime = value;
    }

    /**
     * Gets the value of the assignToBranch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssignToBranch() {
        return assignToBranch;
    }

    /**
     * Sets the value of the assignToBranch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssignToBranch(String value) {
        this.assignToBranch = value;
    }

    /**
     * Gets the value of the repeatStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRepeatStatus() {
        return repeatStatus;
    }

    /**
     * Sets the value of the repeatStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRepeatStatus(String value) {
        this.repeatStatus = value;
    }

    /**
     * Gets the value of the escalationStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEscalationStatus() {
        return escalationStatus;
    }

    /**
     * Sets the value of the escalationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEscalationStatus(String value) {
        this.escalationStatus = value;
    }

    /**
     * Gets the value of the defectReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefectReason() {
        return defectReason;
    }

    /**
     * Sets the value of the defectReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefectReason(String value) {
        this.defectReason = value;
    }

    /**
     * Gets the value of the closedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClosedBy() {
        return closedBy;
    }

    /**
     * Sets the value of the closedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosedBy(String value) {
        this.closedBy = value;
    }

    /**
     * Gets the value of the closedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getClosedDateTime() {
        return closedDateTime;
    }

    /**
     * Sets the value of the closedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setClosedDateTime(XMLGregorianCalendar value) {
        this.closedDateTime = value;
    }

    /**
     * Gets the value of the isUpdatingInHeat property.
     * 
     */
    public boolean isIsUpdatingInHeat() {
        return isUpdatingInHeat;
    }

    /**
     * Sets the value of the isUpdatingInHeat property.
     * 
     */
    public void setIsUpdatingInHeat(boolean value) {
        this.isUpdatingInHeat = value;
    }

    /**
     * Gets the value of the isUpdatingInHeatNew property.
     * 
     */
    public boolean isIsUpdatingInHeatNew() {
        return isUpdatingInHeatNew;
    }

    /**
     * Sets the value of the isUpdatingInHeatNew property.
     * 
     */
    public void setIsUpdatingInHeatNew(boolean value) {
        this.isUpdatingInHeatNew = value;
    }

    /**
     * Gets the value of the lastUpdateBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastUpdateBy() {
        return lastUpdateBy;
    }

    /**
     * Sets the value of the lastUpdateBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastUpdateBy(String value) {
        this.lastUpdateBy = value;
    }

    /**
     * Gets the value of the lastUpdatedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    /**
     * Sets the value of the lastUpdatedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdatedDateTime(XMLGregorianCalendar value) {
        this.lastUpdatedDateTime = value;
    }

    /**
     * Gets the value of the modDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModDate() {
        return modDate;
    }

    /**
     * Sets the value of the modDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModDate(XMLGregorianCalendar value) {
        this.modDate = value;
    }

    /**
     * Gets the value of the modTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getModTime() {
        return modTime;
    }

    /**
     * Sets the value of the modTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setModTime(XMLGregorianCalendar value) {
        this.modTime = value;
    }

    /**
     * Gets the value of the closed property.
     * 
     */
    public boolean isClosed() {
        return closed;
    }

    /**
     * Sets the value of the closed property.
     * 
     */
    public void setClosed(boolean value) {
        this.closed = value;
    }

    /**
     * Gets the value of the isCallSaved property.
     * 
     */
    public boolean isIsCallSaved() {
        return isCallSaved;
    }

    /**
     * Sets the value of the isCallSaved property.
     * 
     */
    public void setIsCallSaved(boolean value) {
        this.isCallSaved = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the assignment property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public ArrayOfAnyType getAssignment() {
        return assignment;
    }

    /**
     * Sets the value of the assignment property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public void setAssignment(ArrayOfAnyType value) {
        this.assignment = value;
    }

    /**
     * Gets the value of the journal property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public ArrayOfAnyType getJournal() {
        return journal;
    }

    /**
     * Sets the value of the journal property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public void setJournal(ArrayOfAnyType value) {
        this.journal = value;
    }

    /**
     * Gets the value of the subset property.
     * 
     * @return
     *     possible object is
     *     {@link Subset }
     *     
     */
    public Subset getSubset() {
        return subset;
    }

    /**
     * Sets the value of the subset property.
     * 
     * @param value
     *     allowed object is
     *     {@link Subset }
     *     
     */
    public void setSubset(Subset value) {
        this.subset = value;
    }

    /**
     * Gets the value of the heatGen property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public ArrayOfAnyType getHeatGen() {
        return heatGen;
    }

    /**
     * Sets the value of the heatGen property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public void setHeatGen(ArrayOfAnyType value) {
        this.heatGen = value;
    }

    /**
     * Gets the value of the atgRcvdEmailID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getATGRcvdEmailID() {
        return atgRcvdEmailID;
    }

    /**
     * Sets the value of the atgRcvdEmailID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setATGRcvdEmailID(String value) {
        this.atgRcvdEmailID = value;
    }

    /**
     * Gets the value of the details property.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getDetails() {
        return details;
    }

    /**
     * Sets the value of the details property.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setDetails(Object value) {
        this.details = value;
    }

    /**
     * Gets the value of the isDetailAdded property.
     * 
     */
    public boolean isIsDetailAdded() {
        return isDetailAdded;
    }

    /**
     * Sets the value of the isDetailAdded property.
     * 
     */
    public void setIsDetailAdded(boolean value) {
        this.isDetailAdded = value;
    }

    /**
     * Gets the value of the modeOfDispatch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModeOfDispatch() {
        return modeOfDispatch;
    }

    /**
     * Sets the value of the modeOfDispatch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModeOfDispatch(String value) {
        this.modeOfDispatch = value;
    }

    /**
     * Gets the value of the callAlerts property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallAlerts() {
        return callAlerts;
    }

    /**
     * Sets the value of the callAlerts property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallAlerts(String value) {
        this.callAlerts = value;
    }

    /**
     * Gets the value of the acdno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACDNO() {
        return acdno;
    }

    /**
     * Sets the value of the acdno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACDNO(String value) {
        this.acdno = value;
    }

    /**
     * Gets the value of the guid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGUID() {
        return guid;
    }

    /**
     * Sets the value of the guid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGUID(String value) {
        this.guid = value;
    }

    /**
     * Gets the value of the clino property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLINO() {
        return clino;
    }

    /**
     * Sets the value of the clino property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLINO(String value) {
        this.clino = value;
    }

    /**
     * Gets the value of the verificationDone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVerificationDone() {
        return verificationDone;
    }

    /**
     * Sets the value of the verificationDone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVerificationDone(String value) {
        this.verificationDone = value;
    }

    /**
     * Gets the value of the isModeOfDispatchChanged property.
     * 
     */
    public boolean isIsModeOfDispatchChanged() {
        return isModeOfDispatchChanged;
    }

    /**
     * Sets the value of the isModeOfDispatchChanged property.
     * 
     */
    public void setIsModeOfDispatchChanged(boolean value) {
        this.isModeOfDispatchChanged = value;
    }

    /**
     * Gets the value of the isCallAlertsChanged property.
     * 
     */
    public boolean isIsCallAlertsChanged() {
        return isCallAlertsChanged;
    }

    /**
     * Sets the value of the isCallAlertsChanged property.
     * 
     */
    public void setIsCallAlertsChanged(boolean value) {
        this.isCallAlertsChanged = value;
    }

    /**
     * Gets the value of the receivedbyBranch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceivedbyBranch() {
        return receivedbyBranch;
    }

    /**
     * Sets the value of the receivedbyBranch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceivedbyBranch(String value) {
        this.receivedbyBranch = value;
    }

    /**
     * Gets the value of the subject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubject() {
        return subject;
    }

    /**
     * Sets the value of the subject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubject(String value) {
        this.subject = value;
    }

    /**
     * Gets the value of the branchInteractionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchInteractionID() {
        return branchInteractionID;
    }

    /**
     * Sets the value of the branchInteractionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchInteractionID(String value) {
        this.branchInteractionID = value;
    }

    /**
     * Gets the value of the atgCallFlag property.
     * 
     */
    public int getATGCallFlag() {
        return atgCallFlag;
    }

    /**
     * Sets the value of the atgCallFlag property.
     * 
     */
    public void setATGCallFlag(int value) {
        this.atgCallFlag = value;
    }

    /**
     * Gets the value of the aging property.
     * 
     */
    public int getAging() {
        return aging;
    }

    /**
     * Sets the value of the aging property.
     * 
     */
    public void setAging(int value) {
        this.aging = value;
    }

    /**
     * Gets the value of the callSourceRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallSourceRef() {
        return callSourceRef;
    }

    /**
     * Sets the value of the callSourceRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallSourceRef(String value) {
        this.callSourceRef = value;
    }

    /**
     * Gets the value of the emailType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailType() {
        return emailType;
    }

    /**
     * Sets the value of the emailType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailType(String value) {
        this.emailType = value;
    }

    /**
     * Gets the value of the escDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEscDate() {
        return escDate;
    }

    /**
     * Sets the value of the escDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEscDate(String value) {
        this.escDate = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the agingHHMM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgingHHMM() {
        return agingHHMM;
    }

    /**
     * Sets the value of the agingHHMM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgingHHMM(String value) {
        this.agingHHMM = value;
    }

    /**
     * Gets the value of the allotedId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllotedId() {
        return allotedId;
    }

    /**
     * Sets the value of the allotedId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllotedId(String value) {
        this.allotedId = value;
    }

    /**
     * Gets the value of the queueType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQueueType() {
        return queueType;
    }

    /**
     * Sets the value of the queueType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQueueType(String value) {
        this.queueType = value;
    }

    /**
     * Gets the value of the vendorCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVendorCode() {
        return vendorCode;
    }

    /**
     * Sets the value of the vendorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVendorCode(String value) {
        this.vendorCode = value;
    }

    /**
     * Gets the value of the callEntryDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCallEntryDateTime() {
        return callEntryDateTime;
    }

    /**
     * Sets the value of the callEntryDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCallEntryDateTime(XMLGregorianCalendar value) {
        this.callEntryDateTime = value;
    }

    /**
     * Gets the value of the isFreshMailCall property.
     * 
     */
    public boolean isIsFreshMailCall() {
        return isFreshMailCall;
    }

    /**
     * Sets the value of the isFreshMailCall property.
     * 
     */
    public void setIsFreshMailCall(boolean value) {
        this.isFreshMailCall = value;
    }

    /**
     * Gets the value of the isCallToBeTracked property.
     * 
     */
    public boolean isIsCallToBeTracked() {
        return isCallToBeTracked;
    }

    /**
     * Sets the value of the isCallToBeTracked property.
     * 
     */
    public void setIsCallToBeTracked(boolean value) {
        this.isCallToBeTracked = value;
    }

    /**
     * Gets the value of the originalTokenNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalTokenNumber() {
        return originalTokenNumber;
    }

    /**
     * Sets the value of the originalTokenNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalTokenNumber(String value) {
        this.originalTokenNumber = value;
    }

    /**
     * Gets the value of the cseid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCSEID() {
        return cseid;
    }

    /**
     * Sets the value of the cseid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCSEID(String value) {
        this.cseid = value;
    }

    /**
     * Gets the value of the feedBack property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeedBack() {
        return feedBack;
    }

    /**
     * Sets the value of the feedBack property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeedBack(String value) {
        this.feedBack = value;
    }

    /**
     * Gets the value of the webserviceResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWebserviceResponse() {
        return webserviceResponse;
    }

    /**
     * Sets the value of the webserviceResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWebserviceResponse(String value) {
        this.webserviceResponse = value;
    }

    /**
     * Gets the value of the masterCallType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMasterCallType() {
        return masterCallType;
    }

    /**
     * Sets the value of the masterCallType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMasterCallType(String value) {
        this.masterCallType = value;
    }

    /**
     * Gets the value of the isSatisfied property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsSatisfied() {
        return isSatisfied;
    }

    /**
     * Sets the value of the isSatisfied property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsSatisfied(String value) {
        this.isSatisfied = value;
    }

    /**
     * Gets the value of the isLapse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsLapse() {
        return isLapse;
    }

    /**
     * Sets the value of the isLapse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsLapse(String value) {
        this.isLapse = value;
    }

    /**
     * Gets the value of the isDisposed property.
     * 
     */
    public boolean isIsDisposed() {
        return isDisposed;
    }

    /**
     * Sets the value of the isDisposed property.
     * 
     */
    public void setIsDisposed(boolean value) {
        this.isDisposed = value;
    }

    /**
     * Gets the value of the disposeBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisposeBy() {
        return disposeBy;
    }

    /**
     * Sets the value of the disposeBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisposeBy(String value) {
        this.disposeBy = value;
    }

    /**
     * Gets the value of the disposeDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDisposeDateTime() {
        return disposeDateTime;
    }

    /**
     * Sets the value of the disposeDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDisposeDateTime(XMLGregorianCalendar value) {
        this.disposeDateTime = value;
    }

    /**
     * Gets the value of the reOpenedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReOpenedBy() {
        return reOpenedBy;
    }

    /**
     * Sets the value of the reOpenedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReOpenedBy(String value) {
        this.reOpenedBy = value;
    }

    /**
     * Gets the value of the reOpenedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReOpenedDateTime() {
        return reOpenedDateTime;
    }

    /**
     * Sets the value of the reOpenedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReOpenedDateTime(XMLGregorianCalendar value) {
        this.reOpenedDateTime = value;
    }

    /**
     * Gets the value of the tokenNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTokenNumber() {
        return tokenNumber;
    }

    /**
     * Sets the value of the tokenNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTokenNumber(String value) {
        this.tokenNumber = value;
    }

    /**
     * Gets the value of the irdatat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIRDATAT() {
        return irdatat;
    }

    /**
     * Sets the value of the irdatat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIRDATAT(String value) {
        this.irdatat = value;
    }

    /**
     * Gets the value of the closurerequestletterdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLOSUREREQUESTLETTERDATE() {
        return closurerequestletterdate;
    }

    /**
     * Sets the value of the closurerequestletterdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLOSUREREQUESTLETTERDATE(String value) {
        this.closurerequestletterdate = value;
    }

    /**
     * Gets the value of the irdaexpectedclosuredate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getIRDAEXPECTEDCLOSUREDATE() {
        return irdaexpectedclosuredate;
    }

    /**
     * Sets the value of the irdaexpectedclosuredate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setIRDAEXPECTEDCLOSUREDATE(XMLGregorianCalendar value) {
        this.irdaexpectedclosuredate = value;
    }

    /**
     * Gets the value of the acknowledge property.
     * 
     */
    public boolean isACKNOWLEDGE() {
        return acknowledge;
    }

    /**
     * Sets the value of the acknowledge property.
     * 
     */
    public void setACKNOWLEDGE(boolean value) {
        this.acknowledge = value;
    }

    /**
     * Gets the value of the chkacknowledge property.
     * 
     */
    public boolean isCHKACKNOWLEDGE() {
        return chkacknowledge;
    }

    /**
     * Sets the value of the chkacknowledge property.
     * 
     */
    public void setCHKACKNOWLEDGE(boolean value) {
        this.chkacknowledge = value;
    }

    /**
     * Gets the value of the onLineSales property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOnLineSales() {
        return onLineSales;
    }

    /**
     * Sets the value of the onLineSales property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOnLineSales(String value) {
        this.onLineSales = value;
    }

    /**
     * Gets the value of the reOpenedSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReOpenedSource() {
        return reOpenedSource;
    }

    /**
     * Sets the value of the reOpenedSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReOpenedSource(String value) {
        this.reOpenedSource = value;
    }

    /**
     * Gets the value of the userAreaCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserAreaCode() {
        return userAreaCode;
    }

    /**
     * Sets the value of the userAreaCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserAreaCode(String value) {
        this.userAreaCode = value;
    }

    /**
     * Gets the value of the complaintiddescombinationerror property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTIDDESCOMBINATIONERROR() {
        return complaintiddescombinationerror;
    }

    /**
     * Sets the value of the complaintiddescombinationerror property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTIDDESCOMBINATIONERROR(String value) {
        this.complaintiddescombinationerror = value;
    }

    /**
     * Gets the value of the invalidpolicynumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINVALIDPOLICYNUMBER() {
        return invalidpolicynumber;
    }

    /**
     * Sets the value of the invalidpolicynumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINVALIDPOLICYNUMBER(String value) {
        this.invalidpolicynumber = value;
    }

    /**
     * Gets the value of the invalidapplicationnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINVALIDAPPLICATIONNUMBER() {
        return invalidapplicationnumber;
    }

    /**
     * Sets the value of the invalidapplicationnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINVALIDAPPLICATIONNUMBER(String value) {
        this.invalidapplicationnumber = value;
    }

    /**
     * Gets the value of the pincode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPINCODE() {
        return pincode;
    }

    /**
     * Sets the value of the pincode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPINCODE(String value) {
        this.pincode = value;
    }

    /**
     * Gets the value of the isalreadycallsaved property.
     * 
     */
    public boolean isISALREADYCALLSAVED() {
        return isalreadycallsaved;
    }

    /**
     * Sets the value of the isalreadycallsaved property.
     * 
     */
    public void setISALREADYCALLSAVED(boolean value) {
        this.isalreadycallsaved = value;
    }

    /**
     * Gets the value of the irdaEntiry property.
     * 
     * @return
     *     possible object is
     *     {@link IRDAEntity }
     *     
     */
    public IRDAEntity getIrdaEntiry() {
        return irdaEntiry;
    }

    /**
     * Sets the value of the irdaEntiry property.
     * 
     * @param value
     *     allowed object is
     *     {@link IRDAEntity }
     *     
     */
    public void setIrdaEntiry(IRDAEntity value) {
        this.irdaEntiry = value;
    }

    /**
     * Gets the value of the userid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERID() {
        return userid;
    }

    /**
     * Sets the value of the userid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERID(String value) {
        this.userid = value;
    }

    /**
     * Gets the value of the sfinCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSFINCode() {
        return sfinCode;
    }

    /**
     * Sets the value of the sfinCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSFINCode(String value) {
        this.sfinCode = value;
    }

    /**
     * Gets the value of the firstClosedDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFirstClosedDateTime() {
        return firstClosedDateTime;
    }

    /**
     * Sets the value of the firstClosedDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFirstClosedDateTime(XMLGregorianCalendar value) {
        this.firstClosedDateTime = value;
    }

    /**
     * Gets the value of the reopenedDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReopenedDesc() {
        return reopenedDesc;
    }

    /**
     * Sets the value of the reopenedDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReopenedDesc(String value) {
        this.reopenedDesc = value;
    }

    /**
     * Gets the value of the reopenedClosedDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReopenedClosedDesc() {
        return reopenedClosedDesc;
    }

    /**
     * Sets the value of the reopenedClosedDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReopenedClosedDesc(String value) {
        this.reopenedClosedDesc = value;
    }

    /**
     * Gets the value of the journalNotes property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJournalNotes() {
        return journalNotes;
    }

    /**
     * Sets the value of the journalNotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJournalNotes(String value) {
        this.journalNotes = value;
    }

    /**
     * Gets the value of the xxxUserAreaCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXxxUserAreaCode() {
        return xxxUserAreaCode;
    }

    /**
     * Sets the value of the xxxUserAreaCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXxxUserAreaCode(String value) {
        this.xxxUserAreaCode = value;
    }

    /**
     * Gets the value of the modeOfClosure property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModeOfClosure() {
        return modeOfClosure;
    }

    /**
     * Sets the value of the modeOfClosure property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModeOfClosure(String value) {
        this.modeOfClosure = value;
    }

    /**
     * Gets the value of the surrenderValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurrenderValue() {
        return surrenderValue;
    }

    /**
     * Sets the value of the surrenderValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurrenderValue(String value) {
        this.surrenderValue = value;
    }

    /**
     * Gets the value of the surrenderValuePer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurrenderValuePer() {
        return surrenderValuePer;
    }

    /**
     * Sets the value of the surrenderValuePer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurrenderValuePer(String value) {
        this.surrenderValuePer = value;
    }

    /**
     * Gets the value of the fundValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundValue() {
        return fundValue;
    }

    /**
     * Sets the value of the fundValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundValue(String value) {
        this.fundValue = value;
    }

    /**
     * Gets the value of the totalPremium property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalPremium() {
        return totalPremium;
    }

    /**
     * Sets the value of the totalPremium property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalPremium(String value) {
        this.totalPremium = value;
    }

    /**
     * Gets the value of the investedPremium property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvestedPremium() {
        return investedPremium;
    }

    /**
     * Sets the value of the investedPremium property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvestedPremium(String value) {
        this.investedPremium = value;
    }

    /**
     * Gets the value of the successFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuccessFlag() {
        return successFlag;
    }

    /**
     * Sets the value of the successFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuccessFlag(String value) {
        this.successFlag = value;
    }

    /**
     * Gets the value of the ptd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPTD() {
        return ptd;
    }

    /**
     * Sets the value of the ptd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPTD(String value) {
        this.ptd = value;
    }

    /**
     * Gets the value of the schAppntDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSchAppntDate() {
        return schAppntDate;
    }

    /**
     * Sets the value of the schAppntDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSchAppntDate(XMLGregorianCalendar value) {
        this.schAppntDate = value;
    }

    /**
     * Gets the value of the reSchAppntDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getReSchAppntDate() {
        return reSchAppntDate;
    }

    /**
     * Sets the value of the reSchAppntDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setReSchAppntDate(XMLGregorianCalendar value) {
        this.reSchAppntDate = value;
    }

    /**
     * Gets the value of the addressOption property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressOption() {
        return addressOption;
    }

    /**
     * Sets the value of the addressOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressOption(String value) {
        this.addressOption = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * Gets the value of the eAdvMobNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEAdvMobNumber() {
        return eAdvMobNumber;
    }

    /**
     * Sets the value of the eAdvMobNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEAdvMobNumber(String value) {
        this.eAdvMobNumber = value;
    }

    /**
     * Gets the value of the eia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEIA() {
        return eia;
    }

    /**
     * Sets the value of the eia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEIA(String value) {
        this.eia = value;
    }

    /**
     * Gets the value of the irCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIRCode() {
        return irCode;
    }

    /**
     * Sets the value of the irCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIRCode(String value) {
        this.irCode = value;
    }

    /**
     * Gets the value of the ePolicies property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEPolicies() {
        return ePolicies;
    }

    /**
     * Sets the value of the ePolicies property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEPolicies(String value) {
        this.ePolicies = value;
    }

    /**
     * Gets the value of the existingEIAFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExistingEIAFlag() {
        return existingEIAFlag;
    }

    /**
     * Sets the value of the existingEIAFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExistingEIAFlag(String value) {
        this.existingEIAFlag = value;
    }

    /**
     * Gets the value of the freshEmail property.
     * 
     * @return
     *     possible object is
     *     {@link FreshEmailEntity }
     *     
     */
    public FreshEmailEntity getFreshEmail() {
        return freshEmail;
    }

    /**
     * Sets the value of the freshEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link FreshEmailEntity }
     *     
     */
    public void setFreshEmail(FreshEmailEntity value) {
        this.freshEmail = value;
    }

    /**
     * Gets the value of the isFreshEmailCall property.
     * 
     */
    public boolean isIsFreshEmailCall() {
        return isFreshEmailCall;
    }

    /**
     * Sets the value of the isFreshEmailCall property.
     * 
     */
    public void setIsFreshEmailCall(boolean value) {
        this.isFreshEmailCall = value;
    }

    /**
     * Gets the value of the lstReOpenedDetail property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfReOpenedDetail }
     *     
     */
    public ArrayOfReOpenedDetail getLstReOpenedDetail() {
        return lstReOpenedDetail;
    }

    /**
     * Sets the value of the lstReOpenedDetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfReOpenedDetail }
     *     
     */
    public void setLstReOpenedDetail(ArrayOfReOpenedDetail value) {
        this.lstReOpenedDetail = value;
    }

    /**
     * Gets the value of the indexReOpened property.
     * 
     */
    public int getIndexReOpened() {
        return indexReOpened;
    }

    /**
     * Sets the value of the indexReOpened property.
     * 
     */
    public void setIndexReOpened(int value) {
        this.indexReOpened = value;
    }

    /**
     * Gets the value of the prevIndexReOpened property.
     * 
     */
    public int getPrevIndexReOpened() {
        return prevIndexReOpened;
    }

    /**
     * Sets the value of the prevIndexReOpened property.
     * 
     */
    public void setPrevIndexReOpened(int value) {
        this.prevIndexReOpened = value;
    }

    /**
     * Gets the value of the isReOpened property.
     * 
     */
    public boolean isIsReOpened() {
        return isReOpened;
    }

    /**
     * Sets the value of the isReOpened property.
     * 
     */
    public void setIsReOpened(boolean value) {
        this.isReOpened = value;
    }

    /**
     * Gets the value of the autoCallLogWSErrorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutoCallLogWSErrorMsg() {
        return autoCallLogWSErrorMsg;
    }

    /**
     * Sets the value of the autoCallLogWSErrorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutoCallLogWSErrorMsg(String value) {
        this.autoCallLogWSErrorMsg = value;
    }

    /**
     * Gets the value of the attachment1 property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getAttachment1() {
        return attachment1;
    }

    /**
     * Sets the value of the attachment1 property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setAttachment1(byte[] value) {
        this.attachment1 = ((byte[]) value);
    }

    /**
     * Gets the value of the attachment1Name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAttachment1Name() {
        return attachment1Name;
    }

    /**
     * Sets the value of the attachment1Name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAttachment1Name(String value) {
        this.attachment1Name = value;
    }

    /**
     * Gets the value of the originalTAT property.
     * 
     */
    public int getOriginalTAT() {
        return originalTAT;
    }

    /**
     * Sets the value of the originalTAT property.
     * 
     */
    public void setOriginalTAT(int value) {
        this.originalTAT = value;
    }

    /**
     * Gets the value of the resCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResCode() {
        return resCode;
    }

    /**
     * Sets the value of the resCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResCode(String value) {
        this.resCode = value;
    }

    /**
     * Gets the value of the repeatCust property.
     * 
     */
    public boolean isRepeatCust() {
        return repeatCust;
    }

    /**
     * Sets the value of the repeatCust property.
     * 
     */
    public void setRepeatCust(boolean value) {
        this.repeatCust = value;
    }

    /**
     * Gets the value of the attachment property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public ArrayOfAnyType getAttachment() {
        return attachment;
    }

    /**
     * Sets the value of the attachment property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public void setAttachment(ArrayOfAnyType value) {
        this.attachment = value;
    }

}
