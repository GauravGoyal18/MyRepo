
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DetailPaymentOptions complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailPaymentOptions">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="OldPaymentMethod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NewPaymentMethod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OldFrequency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NewFrequency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BankName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MicrCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountHolderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PDCChequeNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PDCDispatchedToFINOPSDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="PDCRecievedToFINOPSDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailPaymentOptions", propOrder = {
    "isChanged",
    "interactionId",
    "oldPaymentMethod",
    "newPaymentMethod",
    "oldFrequency",
    "newFrequency",
    "bankName",
    "micrCode",
    "accountNo",
    "accountType",
    "accountHolderName",
    "pdcChequeNo",
    "pdcDispatchedToFINOPSDate",
    "pdcRecievedToFINOPSDate",
    "isUpdated"
})
public class DetailPaymentOptions {

    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionId")
    protected long interactionId;
    @XmlElement(name = "OldPaymentMethod")
    protected String oldPaymentMethod;
    @XmlElement(name = "NewPaymentMethod")
    protected String newPaymentMethod;
    @XmlElement(name = "OldFrequency")
    protected String oldFrequency;
    @XmlElement(name = "NewFrequency")
    protected String newFrequency;
    @XmlElement(name = "BankName")
    protected String bankName;
    @XmlElement(name = "MicrCode")
    protected String micrCode;
    @XmlElement(name = "AccountNo")
    protected String accountNo;
    @XmlElement(name = "AccountType")
    protected String accountType;
    @XmlElement(name = "AccountHolderName")
    protected String accountHolderName;
    @XmlElement(name = "PDCChequeNo")
    protected String pdcChequeNo;
    @XmlElement(name = "PDCDispatchedToFINOPSDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar pdcDispatchedToFINOPSDate;
    @XmlElement(name = "PDCRecievedToFINOPSDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar pdcRecievedToFINOPSDate;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionId property.
     * 
     */
    public long getInteractionId() {
        return interactionId;
    }

    /**
     * Sets the value of the interactionId property.
     * 
     */
    public void setInteractionId(long value) {
        this.interactionId = value;
    }

    /**
     * Gets the value of the oldPaymentMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldPaymentMethod() {
        return oldPaymentMethod;
    }

    /**
     * Sets the value of the oldPaymentMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldPaymentMethod(String value) {
        this.oldPaymentMethod = value;
    }

    /**
     * Gets the value of the newPaymentMethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewPaymentMethod() {
        return newPaymentMethod;
    }

    /**
     * Sets the value of the newPaymentMethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewPaymentMethod(String value) {
        this.newPaymentMethod = value;
    }

    /**
     * Gets the value of the oldFrequency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldFrequency() {
        return oldFrequency;
    }

    /**
     * Sets the value of the oldFrequency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldFrequency(String value) {
        this.oldFrequency = value;
    }

    /**
     * Gets the value of the newFrequency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewFrequency() {
        return newFrequency;
    }

    /**
     * Sets the value of the newFrequency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewFrequency(String value) {
        this.newFrequency = value;
    }

    /**
     * Gets the value of the bankName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * Sets the value of the bankName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankName(String value) {
        this.bankName = value;
    }

    /**
     * Gets the value of the micrCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMicrCode() {
        return micrCode;
    }

    /**
     * Sets the value of the micrCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMicrCode(String value) {
        this.micrCode = value;
    }

    /**
     * Gets the value of the accountNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNo() {
        return accountNo;
    }

    /**
     * Sets the value of the accountNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNo(String value) {
        this.accountNo = value;
    }

    /**
     * Gets the value of the accountType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * Sets the value of the accountType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountType(String value) {
        this.accountType = value;
    }

    /**
     * Gets the value of the accountHolderName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountHolderName() {
        return accountHolderName;
    }

    /**
     * Sets the value of the accountHolderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountHolderName(String value) {
        this.accountHolderName = value;
    }

    /**
     * Gets the value of the pdcChequeNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDCChequeNo() {
        return pdcChequeNo;
    }

    /**
     * Sets the value of the pdcChequeNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDCChequeNo(String value) {
        this.pdcChequeNo = value;
    }

    /**
     * Gets the value of the pdcDispatchedToFINOPSDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPDCDispatchedToFINOPSDate() {
        return pdcDispatchedToFINOPSDate;
    }

    /**
     * Sets the value of the pdcDispatchedToFINOPSDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPDCDispatchedToFINOPSDate(XMLGregorianCalendar value) {
        this.pdcDispatchedToFINOPSDate = value;
    }

    /**
     * Gets the value of the pdcRecievedToFINOPSDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPDCRecievedToFINOPSDate() {
        return pdcRecievedToFINOPSDate;
    }

    /**
     * Sets the value of the pdcRecievedToFINOPSDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPDCRecievedToFINOPSDate(XMLGregorianCalendar value) {
        this.pdcRecievedToFINOPSDate = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

}
