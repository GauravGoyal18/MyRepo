
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IRDA_Entity complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IRDA_Entity">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BRANCH_CODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CALLID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INTERACTIONID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USER_NAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FIRST_NAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MIDDLE_NAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LAST_NAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GENDER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DATE_OF_BIRTH" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ADDRESS1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ADDRESS2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ADDRESS3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CITY_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DISTRICT_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="STATE_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PIN_CODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="E_MAIL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TELEPHONE_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MOBILE_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FAX_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USER_TYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ORGANIZATION_NAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DESIGNATION" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PAN_CARD_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VOTER_ID_CARD_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RATION_CARD_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PASSPORT_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IRDA_TOKEN_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ENTITY_COMPLAINT_REF_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINT_STATUS_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="STATUS_CHANGE_DATETIME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INSURANCE_TYPE_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="POLICY_TYPE_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINT_TYPE_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINT_DESCRIPTION_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINT_DETAILS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOURCE_OF_COMPLAINT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOURCE_OF_COMPLAINTID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINT_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINT_RECEIPT_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINT_REGISTRATION_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="POLICY_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PROPOSAL_OR_COVER_NOTE_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OTHER_REF_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CERTIFICATE_NUBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DOCUMENT_TYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RECEIPT_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BOC_OR_COLLECTION_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PROPOSAL_CHEQUE_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PREMIUM_PAYMENT_REF_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="POLICYHOLDER_OR_CLAIMANT_NAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLAIM_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLAIM_INTIMATION_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLAIM_AMOUNT_REQUESTED" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLAIM_RECEIVED_AMOUNT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLAIM_PAYMENT_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLAIM_PAYMENT_CHEQUE_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DATE_OF_HONORING_SERVICE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INSURER_RESOLUTION_LETTER_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TYPE_OF_DISPOSAL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ADDITIONAL_INFORMATION" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IS_COMPLAINANT_INFORMED" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IS_CLOSURE_ACCEPTED" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLOSURE_REQUEST_LATTER_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLOSURE_VIOLATION_REMARKS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="REGULATORY_IMPROVEMENT_SUGGESTION" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLOSURE_ACTION_SUGGESTED" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PRIORITY_HANDLING_DETAILS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PRIORITY_HANDLING" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="REMARKSCOMPLAINT_AGAINST_TYPE_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INTERMEDIARY_NAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INTERMEDIARY_LICENSE_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BROKER_LICENSE_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CHEQUENO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TURN_AROUND_TIME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="REMARKS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMPLAINT_AGAINST_TYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ERRORCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLAIM_PAYMENT_CHEQUE_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BATCHID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IS_ESCALATED" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IS_AUTO_ESCALATED" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OTHERS_CLSR_ADDITIONAL_INFO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AGAINST_ENTITY_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IRDA_Entity", propOrder = {
    "branchcode",
    "callid",
    "interactionid",
    "username",
    "firstname",
    "middlename",
    "lastname",
    "gender",
    "dateofbirth",
    "address1",
    "address2",
    "address3",
    "cityid",
    "districtid",
    "stateid",
    "pincode",
    "email",
    "telephonenumber",
    "mobilenumber",
    "faxnumber",
    "usertype",
    "organizationname",
    "designation",
    "pancardnumber",
    "voteridcardnumber",
    "rationcardnumber",
    "passportnumber",
    "irdatokennumber",
    "entitycomplaintrefnumber",
    "complaintstatusid",
    "statuschangedatetime",
    "insurancetypeid",
    "policytypeid",
    "complainttypeid",
    "complaintdescriptionid",
    "complaintdetails",
    "sourceofcomplaint",
    "sourceofcomplaintid",
    "complaintdate",
    "complaintreceiptdate",
    "complaintregistrationdate",
    "policynumber",
    "proposalorcovernotenumber",
    "otherrefnumber",
    "certificatenuber",
    "documenttype",
    "receiptnumber",
    "bocorcollectionnumber",
    "proposalchequenumber",
    "premiumpaymentrefnumber",
    "policyholderorclaimantname",
    "claimnumber",
    "claimintimationdate",
    "claimamountrequested",
    "claimreceivedamount",
    "claimpaymentdate",
    "claimpaymentchequenumber",
    "dateofhonoringservice",
    "insurerresolutionletterdate",
    "typeofdisposal",
    "additionalinformation",
    "iscomplainantinformed",
    "isclosureaccepted",
    "closurerequestlatterdate",
    "closureviolationremarks",
    "regulatoryimprovementsuggestion",
    "closureactionsuggested",
    "priorityhandlingdetails",
    "priorityhandling",
    "remarkscomplaintagainsttypeid",
    "intermediaryname",
    "intermediarylicensenumber",
    "brokerlicensenumber",
    "chequeno",
    "turnaroundtime",
    "remarks",
    "complaintagainsttype",
    "errorcode",
    "claimpaymentchequedate",
    "batchid",
    "isescalated",
    "isautoescalated",
    "othersclsradditionalinfo",
    "againstentityid"
})
public class IRDAEntity {

    @XmlElement(name = "BRANCH_CODE")
    protected String branchcode;
    @XmlElement(name = "CALLID")
    protected String callid;
    @XmlElement(name = "INTERACTIONID")
    protected String interactionid;
    @XmlElement(name = "USER_NAME")
    protected String username;
    @XmlElement(name = "FIRST_NAME")
    protected String firstname;
    @XmlElement(name = "MIDDLE_NAME")
    protected String middlename;
    @XmlElement(name = "LAST_NAME")
    protected String lastname;
    @XmlElement(name = "GENDER")
    protected String gender;
    @XmlElement(name = "DATE_OF_BIRTH")
    protected String dateofbirth;
    @XmlElement(name = "ADDRESS1")
    protected String address1;
    @XmlElement(name = "ADDRESS2")
    protected String address2;
    @XmlElement(name = "ADDRESS3")
    protected String address3;
    @XmlElement(name = "CITY_ID")
    protected String cityid;
    @XmlElement(name = "DISTRICT_ID")
    protected String districtid;
    @XmlElement(name = "STATE_ID")
    protected String stateid;
    @XmlElement(name = "PIN_CODE")
    protected String pincode;
    @XmlElement(name = "E_MAIL")
    protected String email;
    @XmlElement(name = "TELEPHONE_NUMBER")
    protected String telephonenumber;
    @XmlElement(name = "MOBILE_NUMBER")
    protected String mobilenumber;
    @XmlElement(name = "FAX_NUMBER")
    protected String faxnumber;
    @XmlElement(name = "USER_TYPE")
    protected String usertype;
    @XmlElement(name = "ORGANIZATION_NAME")
    protected String organizationname;
    @XmlElement(name = "DESIGNATION")
    protected String designation;
    @XmlElement(name = "PAN_CARD_NUMBER")
    protected String pancardnumber;
    @XmlElement(name = "VOTER_ID_CARD_NUMBER")
    protected String voteridcardnumber;
    @XmlElement(name = "RATION_CARD_NUMBER")
    protected String rationcardnumber;
    @XmlElement(name = "PASSPORT_NUMBER")
    protected String passportnumber;
    @XmlElement(name = "IRDA_TOKEN_NUMBER")
    protected String irdatokennumber;
    @XmlElement(name = "ENTITY_COMPLAINT_REF_NUMBER")
    protected String entitycomplaintrefnumber;
    @XmlElement(name = "COMPLAINT_STATUS_ID")
    protected String complaintstatusid;
    @XmlElement(name = "STATUS_CHANGE_DATETIME")
    protected String statuschangedatetime;
    @XmlElement(name = "INSURANCE_TYPE_ID")
    protected String insurancetypeid;
    @XmlElement(name = "POLICY_TYPE_ID")
    protected String policytypeid;
    @XmlElement(name = "COMPLAINT_TYPE_ID")
    protected String complainttypeid;
    @XmlElement(name = "COMPLAINT_DESCRIPTION_ID")
    protected String complaintdescriptionid;
    @XmlElement(name = "COMPLAINT_DETAILS")
    protected String complaintdetails;
    @XmlElement(name = "SOURCE_OF_COMPLAINT")
    protected String sourceofcomplaint;
    @XmlElement(name = "SOURCE_OF_COMPLAINTID")
    protected String sourceofcomplaintid;
    @XmlElement(name = "COMPLAINT_DATE")
    protected String complaintdate;
    @XmlElement(name = "COMPLAINT_RECEIPT_DATE")
    protected String complaintreceiptdate;
    @XmlElement(name = "COMPLAINT_REGISTRATION_DATE")
    protected String complaintregistrationdate;
    @XmlElement(name = "POLICY_NUMBER")
    protected String policynumber;
    @XmlElement(name = "PROPOSAL_OR_COVER_NOTE_NUMBER")
    protected String proposalorcovernotenumber;
    @XmlElement(name = "OTHER_REF_NUMBER")
    protected String otherrefnumber;
    @XmlElement(name = "CERTIFICATE_NUBER")
    protected String certificatenuber;
    @XmlElement(name = "DOCUMENT_TYPE")
    protected String documenttype;
    @XmlElement(name = "RECEIPT_NUMBER")
    protected String receiptnumber;
    @XmlElement(name = "BOC_OR_COLLECTION_NUMBER")
    protected String bocorcollectionnumber;
    @XmlElement(name = "PROPOSAL_CHEQUE_NUMBER")
    protected String proposalchequenumber;
    @XmlElement(name = "PREMIUM_PAYMENT_REF_NUMBER")
    protected String premiumpaymentrefnumber;
    @XmlElement(name = "POLICYHOLDER_OR_CLAIMANT_NAME")
    protected String policyholderorclaimantname;
    @XmlElement(name = "CLAIM_NUMBER")
    protected String claimnumber;
    @XmlElement(name = "CLAIM_INTIMATION_DATE")
    protected String claimintimationdate;
    @XmlElement(name = "CLAIM_AMOUNT_REQUESTED")
    protected String claimamountrequested;
    @XmlElement(name = "CLAIM_RECEIVED_AMOUNT")
    protected String claimreceivedamount;
    @XmlElement(name = "CLAIM_PAYMENT_DATE")
    protected String claimpaymentdate;
    @XmlElement(name = "CLAIM_PAYMENT_CHEQUE_NUMBER")
    protected String claimpaymentchequenumber;
    @XmlElement(name = "DATE_OF_HONORING_SERVICE")
    protected String dateofhonoringservice;
    @XmlElement(name = "INSURER_RESOLUTION_LETTER_DATE")
    protected String insurerresolutionletterdate;
    @XmlElement(name = "TYPE_OF_DISPOSAL")
    protected String typeofdisposal;
    @XmlElement(name = "ADDITIONAL_INFORMATION")
    protected String additionalinformation;
    @XmlElement(name = "IS_COMPLAINANT_INFORMED")
    protected String iscomplainantinformed;
    @XmlElement(name = "IS_CLOSURE_ACCEPTED")
    protected String isclosureaccepted;
    @XmlElement(name = "CLOSURE_REQUEST_LATTER_DATE")
    protected String closurerequestlatterdate;
    @XmlElement(name = "CLOSURE_VIOLATION_REMARKS")
    protected String closureviolationremarks;
    @XmlElement(name = "REGULATORY_IMPROVEMENT_SUGGESTION")
    protected String regulatoryimprovementsuggestion;
    @XmlElement(name = "CLOSURE_ACTION_SUGGESTED")
    protected String closureactionsuggested;
    @XmlElement(name = "PRIORITY_HANDLING_DETAILS")
    protected String priorityhandlingdetails;
    @XmlElement(name = "PRIORITY_HANDLING")
    protected String priorityhandling;
    @XmlElement(name = "REMARKSCOMPLAINT_AGAINST_TYPE_ID")
    protected String remarkscomplaintagainsttypeid;
    @XmlElement(name = "INTERMEDIARY_NAME")
    protected String intermediaryname;
    @XmlElement(name = "INTERMEDIARY_LICENSE_NUMBER")
    protected String intermediarylicensenumber;
    @XmlElement(name = "BROKER_LICENSE_NUMBER")
    protected String brokerlicensenumber;
    @XmlElement(name = "CHEQUENO")
    protected String chequeno;
    @XmlElement(name = "TURN_AROUND_TIME")
    protected String turnaroundtime;
    @XmlElement(name = "REMARKS")
    protected String remarks;
    @XmlElement(name = "COMPLAINT_AGAINST_TYPE")
    protected String complaintagainsttype;
    @XmlElement(name = "ERRORCODE")
    protected String errorcode;
    @XmlElement(name = "CLAIM_PAYMENT_CHEQUE_DATE")
    protected String claimpaymentchequedate;
    @XmlElement(name = "BATCHID")
    protected String batchid;
    @XmlElement(name = "IS_ESCALATED")
    protected String isescalated;
    @XmlElement(name = "IS_AUTO_ESCALATED")
    protected String isautoescalated;
    @XmlElement(name = "OTHERS_CLSR_ADDITIONAL_INFO")
    protected String othersclsradditionalinfo;
    @XmlElement(name = "AGAINST_ENTITY_ID")
    protected String againstentityid;

    /**
     * Gets the value of the branchcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBRANCHCODE() {
        return branchcode;
    }

    /**
     * Sets the value of the branchcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBRANCHCODE(String value) {
        this.branchcode = value;
    }

    /**
     * Gets the value of the callid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCALLID() {
        return callid;
    }

    /**
     * Sets the value of the callid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCALLID(String value) {
        this.callid = value;
    }

    /**
     * Gets the value of the interactionid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINTERACTIONID() {
        return interactionid;
    }

    /**
     * Sets the value of the interactionid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINTERACTIONID(String value) {
        this.interactionid = value;
    }

    /**
     * Gets the value of the username property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERNAME() {
        return username;
    }

    /**
     * Sets the value of the username property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERNAME(String value) {
        this.username = value;
    }

    /**
     * Gets the value of the firstname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFIRSTNAME() {
        return firstname;
    }

    /**
     * Sets the value of the firstname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFIRSTNAME(String value) {
        this.firstname = value;
    }

    /**
     * Gets the value of the middlename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMIDDLENAME() {
        return middlename;
    }

    /**
     * Sets the value of the middlename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMIDDLENAME(String value) {
        this.middlename = value;
    }

    /**
     * Gets the value of the lastname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTNAME() {
        return lastname;
    }

    /**
     * Sets the value of the lastname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTNAME(String value) {
        this.lastname = value;
    }

    /**
     * Gets the value of the gender property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGENDER() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGENDER(String value) {
        this.gender = value;
    }

    /**
     * Gets the value of the dateofbirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDATEOFBIRTH() {
        return dateofbirth;
    }

    /**
     * Sets the value of the dateofbirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDATEOFBIRTH(String value) {
        this.dateofbirth = value;
    }

    /**
     * Gets the value of the address1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRESS1() {
        return address1;
    }

    /**
     * Sets the value of the address1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRESS1(String value) {
        this.address1 = value;
    }

    /**
     * Gets the value of the address2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRESS2() {
        return address2;
    }

    /**
     * Sets the value of the address2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRESS2(String value) {
        this.address2 = value;
    }

    /**
     * Gets the value of the address3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRESS3() {
        return address3;
    }

    /**
     * Sets the value of the address3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRESS3(String value) {
        this.address3 = value;
    }

    /**
     * Gets the value of the cityid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCITYID() {
        return cityid;
    }

    /**
     * Sets the value of the cityid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCITYID(String value) {
        this.cityid = value;
    }

    /**
     * Gets the value of the districtid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDISTRICTID() {
        return districtid;
    }

    /**
     * Sets the value of the districtid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDISTRICTID(String value) {
        this.districtid = value;
    }

    /**
     * Gets the value of the stateid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATEID() {
        return stateid;
    }

    /**
     * Sets the value of the stateid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATEID(String value) {
        this.stateid = value;
    }

    /**
     * Gets the value of the pincode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPINCODE() {
        return pincode;
    }

    /**
     * Sets the value of the pincode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPINCODE(String value) {
        this.pincode = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEMAIL() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEMAIL(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the telephonenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTELEPHONENUMBER() {
        return telephonenumber;
    }

    /**
     * Sets the value of the telephonenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTELEPHONENUMBER(String value) {
        this.telephonenumber = value;
    }

    /**
     * Gets the value of the mobilenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMOBILENUMBER() {
        return mobilenumber;
    }

    /**
     * Sets the value of the mobilenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMOBILENUMBER(String value) {
        this.mobilenumber = value;
    }

    /**
     * Gets the value of the faxnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFAXNUMBER() {
        return faxnumber;
    }

    /**
     * Sets the value of the faxnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFAXNUMBER(String value) {
        this.faxnumber = value;
    }

    /**
     * Gets the value of the usertype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERTYPE() {
        return usertype;
    }

    /**
     * Sets the value of the usertype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERTYPE(String value) {
        this.usertype = value;
    }

    /**
     * Gets the value of the organizationname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getORGANIZATIONNAME() {
        return organizationname;
    }

    /**
     * Sets the value of the organizationname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setORGANIZATIONNAME(String value) {
        this.organizationname = value;
    }

    /**
     * Gets the value of the designation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDESIGNATION() {
        return designation;
    }

    /**
     * Sets the value of the designation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDESIGNATION(String value) {
        this.designation = value;
    }

    /**
     * Gets the value of the pancardnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPANCARDNUMBER() {
        return pancardnumber;
    }

    /**
     * Sets the value of the pancardnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPANCARDNUMBER(String value) {
        this.pancardnumber = value;
    }

    /**
     * Gets the value of the voteridcardnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVOTERIDCARDNUMBER() {
        return voteridcardnumber;
    }

    /**
     * Sets the value of the voteridcardnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVOTERIDCARDNUMBER(String value) {
        this.voteridcardnumber = value;
    }

    /**
     * Gets the value of the rationcardnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRATIONCARDNUMBER() {
        return rationcardnumber;
    }

    /**
     * Sets the value of the rationcardnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRATIONCARDNUMBER(String value) {
        this.rationcardnumber = value;
    }

    /**
     * Gets the value of the passportnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPASSPORTNUMBER() {
        return passportnumber;
    }

    /**
     * Sets the value of the passportnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPASSPORTNUMBER(String value) {
        this.passportnumber = value;
    }

    /**
     * Gets the value of the irdatokennumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIRDATOKENNUMBER() {
        return irdatokennumber;
    }

    /**
     * Sets the value of the irdatokennumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIRDATOKENNUMBER(String value) {
        this.irdatokennumber = value;
    }

    /**
     * Gets the value of the entitycomplaintrefnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getENTITYCOMPLAINTREFNUMBER() {
        return entitycomplaintrefnumber;
    }

    /**
     * Sets the value of the entitycomplaintrefnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setENTITYCOMPLAINTREFNUMBER(String value) {
        this.entitycomplaintrefnumber = value;
    }

    /**
     * Gets the value of the complaintstatusid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTSTATUSID() {
        return complaintstatusid;
    }

    /**
     * Sets the value of the complaintstatusid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTSTATUSID(String value) {
        this.complaintstatusid = value;
    }

    /**
     * Gets the value of the statuschangedatetime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATUSCHANGEDATETIME() {
        return statuschangedatetime;
    }

    /**
     * Sets the value of the statuschangedatetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATUSCHANGEDATETIME(String value) {
        this.statuschangedatetime = value;
    }

    /**
     * Gets the value of the insurancetypeid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINSURANCETYPEID() {
        return insurancetypeid;
    }

    /**
     * Sets the value of the insurancetypeid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINSURANCETYPEID(String value) {
        this.insurancetypeid = value;
    }

    /**
     * Gets the value of the policytypeid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOLICYTYPEID() {
        return policytypeid;
    }

    /**
     * Sets the value of the policytypeid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOLICYTYPEID(String value) {
        this.policytypeid = value;
    }

    /**
     * Gets the value of the complainttypeid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTTYPEID() {
        return complainttypeid;
    }

    /**
     * Sets the value of the complainttypeid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTTYPEID(String value) {
        this.complainttypeid = value;
    }

    /**
     * Gets the value of the complaintdescriptionid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTDESCRIPTIONID() {
        return complaintdescriptionid;
    }

    /**
     * Sets the value of the complaintdescriptionid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTDESCRIPTIONID(String value) {
        this.complaintdescriptionid = value;
    }

    /**
     * Gets the value of the complaintdetails property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTDETAILS() {
        return complaintdetails;
    }

    /**
     * Sets the value of the complaintdetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTDETAILS(String value) {
        this.complaintdetails = value;
    }

    /**
     * Gets the value of the sourceofcomplaint property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOURCEOFCOMPLAINT() {
        return sourceofcomplaint;
    }

    /**
     * Sets the value of the sourceofcomplaint property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOURCEOFCOMPLAINT(String value) {
        this.sourceofcomplaint = value;
    }

    /**
     * Gets the value of the sourceofcomplaintid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOURCEOFCOMPLAINTID() {
        return sourceofcomplaintid;
    }

    /**
     * Sets the value of the sourceofcomplaintid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOURCEOFCOMPLAINTID(String value) {
        this.sourceofcomplaintid = value;
    }

    /**
     * Gets the value of the complaintdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTDATE() {
        return complaintdate;
    }

    /**
     * Sets the value of the complaintdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTDATE(String value) {
        this.complaintdate = value;
    }

    /**
     * Gets the value of the complaintreceiptdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTRECEIPTDATE() {
        return complaintreceiptdate;
    }

    /**
     * Sets the value of the complaintreceiptdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTRECEIPTDATE(String value) {
        this.complaintreceiptdate = value;
    }

    /**
     * Gets the value of the complaintregistrationdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTREGISTRATIONDATE() {
        return complaintregistrationdate;
    }

    /**
     * Sets the value of the complaintregistrationdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTREGISTRATIONDATE(String value) {
        this.complaintregistrationdate = value;
    }

    /**
     * Gets the value of the policynumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOLICYNUMBER() {
        return policynumber;
    }

    /**
     * Sets the value of the policynumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOLICYNUMBER(String value) {
        this.policynumber = value;
    }

    /**
     * Gets the value of the proposalorcovernotenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPROPOSALORCOVERNOTENUMBER() {
        return proposalorcovernotenumber;
    }

    /**
     * Sets the value of the proposalorcovernotenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPROPOSALORCOVERNOTENUMBER(String value) {
        this.proposalorcovernotenumber = value;
    }

    /**
     * Gets the value of the otherrefnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOTHERREFNUMBER() {
        return otherrefnumber;
    }

    /**
     * Sets the value of the otherrefnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOTHERREFNUMBER(String value) {
        this.otherrefnumber = value;
    }

    /**
     * Gets the value of the certificatenuber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCERTIFICATENUBER() {
        return certificatenuber;
    }

    /**
     * Sets the value of the certificatenuber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCERTIFICATENUBER(String value) {
        this.certificatenuber = value;
    }

    /**
     * Gets the value of the documenttype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDOCUMENTTYPE() {
        return documenttype;
    }

    /**
     * Sets the value of the documenttype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDOCUMENTTYPE(String value) {
        this.documenttype = value;
    }

    /**
     * Gets the value of the receiptnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECEIPTNUMBER() {
        return receiptnumber;
    }

    /**
     * Sets the value of the receiptnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECEIPTNUMBER(String value) {
        this.receiptnumber = value;
    }

    /**
     * Gets the value of the bocorcollectionnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBOCORCOLLECTIONNUMBER() {
        return bocorcollectionnumber;
    }

    /**
     * Sets the value of the bocorcollectionnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBOCORCOLLECTIONNUMBER(String value) {
        this.bocorcollectionnumber = value;
    }

    /**
     * Gets the value of the proposalchequenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPROPOSALCHEQUENUMBER() {
        return proposalchequenumber;
    }

    /**
     * Sets the value of the proposalchequenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPROPOSALCHEQUENUMBER(String value) {
        this.proposalchequenumber = value;
    }

    /**
     * Gets the value of the premiumpaymentrefnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPREMIUMPAYMENTREFNUMBER() {
        return premiumpaymentrefnumber;
    }

    /**
     * Sets the value of the premiumpaymentrefnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPREMIUMPAYMENTREFNUMBER(String value) {
        this.premiumpaymentrefnumber = value;
    }

    /**
     * Gets the value of the policyholderorclaimantname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOLICYHOLDERORCLAIMANTNAME() {
        return policyholderorclaimantname;
    }

    /**
     * Sets the value of the policyholderorclaimantname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOLICYHOLDERORCLAIMANTNAME(String value) {
        this.policyholderorclaimantname = value;
    }

    /**
     * Gets the value of the claimnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLAIMNUMBER() {
        return claimnumber;
    }

    /**
     * Sets the value of the claimnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLAIMNUMBER(String value) {
        this.claimnumber = value;
    }

    /**
     * Gets the value of the claimintimationdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLAIMINTIMATIONDATE() {
        return claimintimationdate;
    }

    /**
     * Sets the value of the claimintimationdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLAIMINTIMATIONDATE(String value) {
        this.claimintimationdate = value;
    }

    /**
     * Gets the value of the claimamountrequested property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLAIMAMOUNTREQUESTED() {
        return claimamountrequested;
    }

    /**
     * Sets the value of the claimamountrequested property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLAIMAMOUNTREQUESTED(String value) {
        this.claimamountrequested = value;
    }

    /**
     * Gets the value of the claimreceivedamount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLAIMRECEIVEDAMOUNT() {
        return claimreceivedamount;
    }

    /**
     * Sets the value of the claimreceivedamount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLAIMRECEIVEDAMOUNT(String value) {
        this.claimreceivedamount = value;
    }

    /**
     * Gets the value of the claimpaymentdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLAIMPAYMENTDATE() {
        return claimpaymentdate;
    }

    /**
     * Sets the value of the claimpaymentdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLAIMPAYMENTDATE(String value) {
        this.claimpaymentdate = value;
    }

    /**
     * Gets the value of the claimpaymentchequenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLAIMPAYMENTCHEQUENUMBER() {
        return claimpaymentchequenumber;
    }

    /**
     * Sets the value of the claimpaymentchequenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLAIMPAYMENTCHEQUENUMBER(String value) {
        this.claimpaymentchequenumber = value;
    }

    /**
     * Gets the value of the dateofhonoringservice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDATEOFHONORINGSERVICE() {
        return dateofhonoringservice;
    }

    /**
     * Sets the value of the dateofhonoringservice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDATEOFHONORINGSERVICE(String value) {
        this.dateofhonoringservice = value;
    }

    /**
     * Gets the value of the insurerresolutionletterdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINSURERRESOLUTIONLETTERDATE() {
        return insurerresolutionletterdate;
    }

    /**
     * Sets the value of the insurerresolutionletterdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINSURERRESOLUTIONLETTERDATE(String value) {
        this.insurerresolutionletterdate = value;
    }

    /**
     * Gets the value of the typeofdisposal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTYPEOFDISPOSAL() {
        return typeofdisposal;
    }

    /**
     * Sets the value of the typeofdisposal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTYPEOFDISPOSAL(String value) {
        this.typeofdisposal = value;
    }

    /**
     * Gets the value of the additionalinformation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDITIONALINFORMATION() {
        return additionalinformation;
    }

    /**
     * Sets the value of the additionalinformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDITIONALINFORMATION(String value) {
        this.additionalinformation = value;
    }

    /**
     * Gets the value of the iscomplainantinformed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISCOMPLAINANTINFORMED() {
        return iscomplainantinformed;
    }

    /**
     * Sets the value of the iscomplainantinformed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISCOMPLAINANTINFORMED(String value) {
        this.iscomplainantinformed = value;
    }

    /**
     * Gets the value of the isclosureaccepted property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISCLOSUREACCEPTED() {
        return isclosureaccepted;
    }

    /**
     * Sets the value of the isclosureaccepted property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISCLOSUREACCEPTED(String value) {
        this.isclosureaccepted = value;
    }

    /**
     * Gets the value of the closurerequestlatterdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLOSUREREQUESTLATTERDATE() {
        return closurerequestlatterdate;
    }

    /**
     * Sets the value of the closurerequestlatterdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLOSUREREQUESTLATTERDATE(String value) {
        this.closurerequestlatterdate = value;
    }

    /**
     * Gets the value of the closureviolationremarks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLOSUREVIOLATIONREMARKS() {
        return closureviolationremarks;
    }

    /**
     * Sets the value of the closureviolationremarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLOSUREVIOLATIONREMARKS(String value) {
        this.closureviolationremarks = value;
    }

    /**
     * Gets the value of the regulatoryimprovementsuggestion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREGULATORYIMPROVEMENTSUGGESTION() {
        return regulatoryimprovementsuggestion;
    }

    /**
     * Sets the value of the regulatoryimprovementsuggestion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREGULATORYIMPROVEMENTSUGGESTION(String value) {
        this.regulatoryimprovementsuggestion = value;
    }

    /**
     * Gets the value of the closureactionsuggested property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLOSUREACTIONSUGGESTED() {
        return closureactionsuggested;
    }

    /**
     * Sets the value of the closureactionsuggested property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLOSUREACTIONSUGGESTED(String value) {
        this.closureactionsuggested = value;
    }

    /**
     * Gets the value of the priorityhandlingdetails property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRIORITYHANDLINGDETAILS() {
        return priorityhandlingdetails;
    }

    /**
     * Sets the value of the priorityhandlingdetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRIORITYHANDLINGDETAILS(String value) {
        this.priorityhandlingdetails = value;
    }

    /**
     * Gets the value of the priorityhandling property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRIORITYHANDLING() {
        return priorityhandling;
    }

    /**
     * Sets the value of the priorityhandling property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRIORITYHANDLING(String value) {
        this.priorityhandling = value;
    }

    /**
     * Gets the value of the remarkscomplaintagainsttypeid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREMARKSCOMPLAINTAGAINSTTYPEID() {
        return remarkscomplaintagainsttypeid;
    }

    /**
     * Sets the value of the remarkscomplaintagainsttypeid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREMARKSCOMPLAINTAGAINSTTYPEID(String value) {
        this.remarkscomplaintagainsttypeid = value;
    }

    /**
     * Gets the value of the intermediaryname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINTERMEDIARYNAME() {
        return intermediaryname;
    }

    /**
     * Sets the value of the intermediaryname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINTERMEDIARYNAME(String value) {
        this.intermediaryname = value;
    }

    /**
     * Gets the value of the intermediarylicensenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINTERMEDIARYLICENSENUMBER() {
        return intermediarylicensenumber;
    }

    /**
     * Sets the value of the intermediarylicensenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINTERMEDIARYLICENSENUMBER(String value) {
        this.intermediarylicensenumber = value;
    }

    /**
     * Gets the value of the brokerlicensenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBROKERLICENSENUMBER() {
        return brokerlicensenumber;
    }

    /**
     * Sets the value of the brokerlicensenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBROKERLICENSENUMBER(String value) {
        this.brokerlicensenumber = value;
    }

    /**
     * Gets the value of the chequeno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHEQUENO() {
        return chequeno;
    }

    /**
     * Sets the value of the chequeno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHEQUENO(String value) {
        this.chequeno = value;
    }

    /**
     * Gets the value of the turnaroundtime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTURNAROUNDTIME() {
        return turnaroundtime;
    }

    /**
     * Sets the value of the turnaroundtime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTURNAROUNDTIME(String value) {
        this.turnaroundtime = value;
    }

    /**
     * Gets the value of the remarks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREMARKS() {
        return remarks;
    }

    /**
     * Sets the value of the remarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREMARKS(String value) {
        this.remarks = value;
    }

    /**
     * Gets the value of the complaintagainsttype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPLAINTAGAINSTTYPE() {
        return complaintagainsttype;
    }

    /**
     * Sets the value of the complaintagainsttype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPLAINTAGAINSTTYPE(String value) {
        this.complaintagainsttype = value;
    }

    /**
     * Gets the value of the errorcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getERRORCODE() {
        return errorcode;
    }

    /**
     * Sets the value of the errorcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setERRORCODE(String value) {
        this.errorcode = value;
    }

    /**
     * Gets the value of the claimpaymentchequedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLAIMPAYMENTCHEQUEDATE() {
        return claimpaymentchequedate;
    }

    /**
     * Sets the value of the claimpaymentchequedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLAIMPAYMENTCHEQUEDATE(String value) {
        this.claimpaymentchequedate = value;
    }

    /**
     * Gets the value of the batchid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBATCHID() {
        return batchid;
    }

    /**
     * Sets the value of the batchid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBATCHID(String value) {
        this.batchid = value;
    }

    /**
     * Gets the value of the isescalated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISESCALATED() {
        return isescalated;
    }

    /**
     * Sets the value of the isescalated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISESCALATED(String value) {
        this.isescalated = value;
    }

    /**
     * Gets the value of the isautoescalated property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISAUTOESCALATED() {
        return isautoescalated;
    }

    /**
     * Sets the value of the isautoescalated property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISAUTOESCALATED(String value) {
        this.isautoescalated = value;
    }

    /**
     * Gets the value of the othersclsradditionalinfo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOTHERSCLSRADDITIONALINFO() {
        return othersclsradditionalinfo;
    }

    /**
     * Sets the value of the othersclsradditionalinfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOTHERSCLSRADDITIONALINFO(String value) {
        this.othersclsradditionalinfo = value;
    }

    /**
     * Gets the value of the againstentityid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAGAINSTENTITYID() {
        return againstentityid;
    }

    /**
     * Sets the value of the againstentityid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAGAINSTENTITYID(String value) {
        this.againstentityid = value;
    }

}
