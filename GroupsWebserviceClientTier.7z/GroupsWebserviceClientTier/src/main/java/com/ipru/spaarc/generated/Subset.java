
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Subset complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Subset">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ArrClinicName" type="{http://generated.spaarc.ipru.com/}ArrayOfAnyType" minOccurs="0"/>
 *         &lt;element name="LandMark" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MemberCompanyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StarClub" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BlackListStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentTerminationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="DtLastMod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PolicyNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ConfigCustId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Hni" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Platform" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Uin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResidenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Address1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Address2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Address3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Address4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PinCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="State" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BirthDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="MemberStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MemberClientID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MemberName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MemberEMPID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MemberMobileNumb" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CompanyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CompanyCodeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Master_InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="METerminationDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ArrContactedBy" type="{http://generated.spaarc.ipru.com/}ArrayOfAnyType" minOccurs="0"/>
 *         &lt;element name="ApplicationNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PolicyStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProductName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AssigneeStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HNI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NRI" type="{http://microsoft.com/wsdl/types/}char"/>
 *         &lt;element name="LoginBranchName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdvisorName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Orphan" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionID" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="Phone1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Phone2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Phone3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Contact" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ConfigCustID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProdCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PruCustID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Salutation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MobileNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BranchName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AsigneeStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SMName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClientType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Category" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClinicName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DocPin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClinicArea" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AreaCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SendASMS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ARD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UMFName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ServiceBranchName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Result" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClientIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MasterPolicyNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ISolutionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DNC" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="VVIP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Subset", propOrder = {
    "arrClinicName",
    "landMark",
    "custID",
    "memberCompanyName",
    "starClub",
    "blackListStatus",
    "agentTerminationDate",
    "dtLastMod",
    "policyNo",
    "configCustId",
    "xxxHni",
    "status",
    "platform",
    "uin",
    "residenceNumber",
    "address1",
    "address2",
    "address3",
    "address4",
    "pinCode",
    "state",
    "birthDate",
    "memberStatus",
    "memberClientID",
    "memberName",
    "memberEMPID",
    "memberMobileNumb",
    "companyName",
    "companyCodeName",
    "masterInteractionID",
    "meTerminationDate",
    "arrContactedBy",
    "applicationNumber",
    "policyStatus",
    "productName",
    "assigneeStatus",
    "name",
    "hni",
    "nri",
    "loginBranchName",
    "advisorName",
    "agentType",
    "orphan",
    "isUpdated",
    "interactionID",
    "phone1",
    "phone2",
    "phone3",
    "custType",
    "contact",
    "city",
    "configCustID",
    "prodCode",
    "pruCustID",
    "salutation",
    "firstName",
    "lastName",
    "mobileNo",
    "emailID",
    "branchName",
    "agentID",
    "agentCode",
    "asigneeStatus",
    "smName",
    "clientType",
    "category",
    "clinicName",
    "docPin",
    "clinicArea",
    "areaCode",
    "sendASMS",
    "ard",
    "rcd",
    "umfName",
    "serviceBranchName",
    "result",
    "clientIndicator",
    "masterPolicyNo",
    "iSolutionName",
    "dnc",
    "vvip"
})
public class Subset {

    @XmlElement(name = "ArrClinicName")
    protected ArrayOfAnyType arrClinicName;
    @XmlElement(name = "LandMark")
    protected String landMark;
    @XmlElement(name = "CustID")
    protected String custID;
    @XmlElement(name = "MemberCompanyName")
    protected String memberCompanyName;
    @XmlElement(name = "StarClub")
    protected String starClub;
    @XmlElement(name = "BlackListStatus")
    protected String blackListStatus;
    @XmlElement(name = "AgentTerminationDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar agentTerminationDate;
    @XmlElement(name = "DtLastMod")
    protected String dtLastMod;
    @XmlElement(name = "PolicyNo")
    protected String policyNo;
    @XmlElement(name = "ConfigCustId")
    protected String configCustId;
    @XmlElement(name = "Hni")
    protected String xxxHni;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "Platform")
    protected String platform;
    @XmlElement(name = "Uin")
    protected String uin;
    @XmlElement(name = "ResidenceNumber")
    protected String residenceNumber;
    @XmlElement(name = "Address1")
    protected String address1;
    @XmlElement(name = "Address2")
    protected String address2;
    @XmlElement(name = "Address3")
    protected String address3;
    @XmlElement(name = "Address4")
    protected String address4;
    @XmlElement(name = "PinCode")
    protected String pinCode;
    @XmlElement(name = "State")
    protected String state;
    @XmlElement(name = "BirthDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar birthDate;
    @XmlElement(name = "MemberStatus")
    protected String memberStatus;
    @XmlElement(name = "MemberClientID")
    protected String memberClientID;
    @XmlElement(name = "MemberName")
    protected String memberName;
    @XmlElement(name = "MemberEMPID")
    protected String memberEMPID;
    @XmlElement(name = "MemberMobileNumb")
    protected String memberMobileNumb;
    @XmlElement(name = "CompanyName")
    protected String companyName;
    @XmlElement(name = "CompanyCodeName")
    protected String companyCodeName;
    @XmlElement(name = "Master_InteractionID")
    protected long masterInteractionID;
    @XmlElement(name = "METerminationDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar meTerminationDate;
    @XmlElement(name = "ArrContactedBy")
    protected ArrayOfAnyType arrContactedBy;
    @XmlElement(name = "ApplicationNumber")
    protected String applicationNumber;
    @XmlElement(name = "PolicyStatus")
    protected String policyStatus;
    @XmlElement(name = "ProductName")
    protected String productName;
    @XmlElement(name = "AssigneeStatus")
    protected String assigneeStatus;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "HNI")
    protected String hni;
    @XmlElement(name = "NRI")
    protected int nri;
    @XmlElement(name = "LoginBranchName")
    protected String loginBranchName;
    @XmlElement(name = "AdvisorName")
    protected String advisorName;
    @XmlElement(name = "AgentType")
    protected String agentType;
    @XmlElement(name = "Orphan")
    protected String orphan;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;
    @XmlElement(name = "InteractionID")
    protected long interactionID;
    @XmlElement(name = "Phone1")
    protected String phone1;
    @XmlElement(name = "Phone2")
    protected String phone2;
    @XmlElement(name = "Phone3")
    protected String phone3;
    @XmlElement(name = "CustType")
    protected String custType;
    @XmlElement(name = "Contact")
    protected String contact;
    @XmlElement(name = "City")
    protected String city;
    @XmlElement(name = "ConfigCustID")
    protected String configCustID;
    @XmlElement(name = "ProdCode")
    protected String prodCode;
    @XmlElement(name = "PruCustID")
    protected String pruCustID;
    @XmlElement(name = "Salutation")
    protected String salutation;
    @XmlElement(name = "FirstName")
    protected String firstName;
    @XmlElement(name = "LastName")
    protected String lastName;
    @XmlElement(name = "MobileNo")
    protected String mobileNo;
    @XmlElement(name = "EmailID")
    protected String emailID;
    @XmlElement(name = "BranchName")
    protected String branchName;
    @XmlElement(name = "AgentID")
    protected String agentID;
    @XmlElement(name = "AgentCode")
    protected String agentCode;
    @XmlElement(name = "AsigneeStatus")
    protected String asigneeStatus;
    @XmlElement(name = "SMName")
    protected String smName;
    @XmlElement(name = "ClientType")
    protected String clientType;
    @XmlElement(name = "Category")
    protected String category;
    @XmlElement(name = "ClinicName")
    protected String clinicName;
    @XmlElement(name = "DocPin")
    protected String docPin;
    @XmlElement(name = "ClinicArea")
    protected String clinicArea;
    @XmlElement(name = "AreaCode")
    protected String areaCode;
    @XmlElement(name = "SendASMS")
    protected String sendASMS;
    @XmlElement(name = "ARD")
    protected String ard;
    @XmlElement(name = "RCD")
    protected String rcd;
    @XmlElement(name = "UMFName")
    protected String umfName;
    @XmlElement(name = "ServiceBranchName")
    protected String serviceBranchName;
    @XmlElement(name = "Result")
    protected String result;
    @XmlElement(name = "ClientIndicator")
    protected String clientIndicator;
    @XmlElement(name = "MasterPolicyNo")
    protected String masterPolicyNo;
    @XmlElement(name = "ISolutionName")
    protected String iSolutionName;
    @XmlElement(name = "DNC")
    protected boolean dnc;
    @XmlElement(name = "VVIP")
    protected String vvip;

    /**
     * Gets the value of the arrClinicName property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public ArrayOfAnyType getArrClinicName() {
        return arrClinicName;
    }

    /**
     * Sets the value of the arrClinicName property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public void setArrClinicName(ArrayOfAnyType value) {
        this.arrClinicName = value;
    }

    /**
     * Gets the value of the landMark property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLandMark() {
        return landMark;
    }

    /**
     * Sets the value of the landMark property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLandMark(String value) {
        this.landMark = value;
    }

    /**
     * Gets the value of the custID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustID() {
        return custID;
    }

    /**
     * Sets the value of the custID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustID(String value) {
        this.custID = value;
    }

    /**
     * Gets the value of the memberCompanyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberCompanyName() {
        return memberCompanyName;
    }

    /**
     * Sets the value of the memberCompanyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberCompanyName(String value) {
        this.memberCompanyName = value;
    }

    /**
     * Gets the value of the starClub property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStarClub() {
        return starClub;
    }

    /**
     * Sets the value of the starClub property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStarClub(String value) {
        this.starClub = value;
    }

    /**
     * Gets the value of the blackListStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBlackListStatus() {
        return blackListStatus;
    }

    /**
     * Sets the value of the blackListStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBlackListStatus(String value) {
        this.blackListStatus = value;
    }

    /**
     * Gets the value of the agentTerminationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getAgentTerminationDate() {
        return agentTerminationDate;
    }

    /**
     * Sets the value of the agentTerminationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setAgentTerminationDate(XMLGregorianCalendar value) {
        this.agentTerminationDate = value;
    }

    /**
     * Gets the value of the dtLastMod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDtLastMod() {
        return dtLastMod;
    }

    /**
     * Sets the value of the dtLastMod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDtLastMod(String value) {
        this.dtLastMod = value;
    }

    /**
     * Gets the value of the policyNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyNo() {
        return policyNo;
    }

    /**
     * Sets the value of the policyNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyNo(String value) {
        this.policyNo = value;
    }

    /**
     * Gets the value of the configCustId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigCustId() {
        return configCustId;
    }

    /**
     * Sets the value of the configCustId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigCustId(String value) {
        this.configCustId = value;
    }

    /**
     * Gets the value of the xxxHni property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXxxHni() {
        return xxxHni;
    }

    /**
     * Sets the value of the xxxHni property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXxxHni(String value) {
        this.xxxHni = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the platform property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlatform() {
        return platform;
    }

    /**
     * Sets the value of the platform property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlatform(String value) {
        this.platform = value;
    }

    /**
     * Gets the value of the uin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUin() {
        return uin;
    }

    /**
     * Sets the value of the uin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUin(String value) {
        this.uin = value;
    }

    /**
     * Gets the value of the residenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResidenceNumber() {
        return residenceNumber;
    }

    /**
     * Sets the value of the residenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResidenceNumber(String value) {
        this.residenceNumber = value;
    }

    /**
     * Gets the value of the address1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * Sets the value of the address1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress1(String value) {
        this.address1 = value;
    }

    /**
     * Gets the value of the address2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * Sets the value of the address2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress2(String value) {
        this.address2 = value;
    }

    /**
     * Gets the value of the address3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress3() {
        return address3;
    }

    /**
     * Sets the value of the address3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress3(String value) {
        this.address3 = value;
    }

    /**
     * Gets the value of the address4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress4() {
        return address4;
    }

    /**
     * Sets the value of the address4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress4(String value) {
        this.address4 = value;
    }

    /**
     * Gets the value of the pinCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPinCode() {
        return pinCode;
    }

    /**
     * Sets the value of the pinCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPinCode(String value) {
        this.pinCode = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the birthDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBirthDate() {
        return birthDate;
    }

    /**
     * Sets the value of the birthDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBirthDate(XMLGregorianCalendar value) {
        this.birthDate = value;
    }

    /**
     * Gets the value of the memberStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberStatus() {
        return memberStatus;
    }

    /**
     * Sets the value of the memberStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberStatus(String value) {
        this.memberStatus = value;
    }

    /**
     * Gets the value of the memberClientID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberClientID() {
        return memberClientID;
    }

    /**
     * Sets the value of the memberClientID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberClientID(String value) {
        this.memberClientID = value;
    }

    /**
     * Gets the value of the memberName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberName() {
        return memberName;
    }

    /**
     * Sets the value of the memberName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberName(String value) {
        this.memberName = value;
    }

    /**
     * Gets the value of the memberEMPID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberEMPID() {
        return memberEMPID;
    }

    /**
     * Sets the value of the memberEMPID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberEMPID(String value) {
        this.memberEMPID = value;
    }

    /**
     * Gets the value of the memberMobileNumb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberMobileNumb() {
        return memberMobileNumb;
    }

    /**
     * Sets the value of the memberMobileNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberMobileNumb(String value) {
        this.memberMobileNumb = value;
    }

    /**
     * Gets the value of the companyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * Sets the value of the companyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyName(String value) {
        this.companyName = value;
    }

    /**
     * Gets the value of the companyCodeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyCodeName() {
        return companyCodeName;
    }

    /**
     * Sets the value of the companyCodeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyCodeName(String value) {
        this.companyCodeName = value;
    }

    /**
     * Gets the value of the masterInteractionID property.
     * 
     */
    public long getMasterInteractionID() {
        return masterInteractionID;
    }

    /**
     * Sets the value of the masterInteractionID property.
     * 
     */
    public void setMasterInteractionID(long value) {
        this.masterInteractionID = value;
    }

    /**
     * Gets the value of the meTerminationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMETerminationDate() {
        return meTerminationDate;
    }

    /**
     * Sets the value of the meTerminationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMETerminationDate(XMLGregorianCalendar value) {
        this.meTerminationDate = value;
    }

    /**
     * Gets the value of the arrContactedBy property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public ArrayOfAnyType getArrContactedBy() {
        return arrContactedBy;
    }

    /**
     * Sets the value of the arrContactedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public void setArrContactedBy(ArrayOfAnyType value) {
        this.arrContactedBy = value;
    }

    /**
     * Gets the value of the applicationNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationNumber() {
        return applicationNumber;
    }

    /**
     * Sets the value of the applicationNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationNumber(String value) {
        this.applicationNumber = value;
    }

    /**
     * Gets the value of the policyStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyStatus() {
        return policyStatus;
    }

    /**
     * Sets the value of the policyStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyStatus(String value) {
        this.policyStatus = value;
    }

    /**
     * Gets the value of the productName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the value of the productName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductName(String value) {
        this.productName = value;
    }

    /**
     * Gets the value of the assigneeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssigneeStatus() {
        return assigneeStatus;
    }

    /**
     * Sets the value of the assigneeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssigneeStatus(String value) {
        this.assigneeStatus = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the hni property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHNI() {
        return hni;
    }

    /**
     * Sets the value of the hni property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHNI(String value) {
        this.hni = value;
    }

    /**
     * Gets the value of the nri property.
     * 
     */
    public int getNRI() {
        return nri;
    }

    /**
     * Sets the value of the nri property.
     * 
     */
    public void setNRI(int value) {
        this.nri = value;
    }

    /**
     * Gets the value of the loginBranchName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoginBranchName() {
        return loginBranchName;
    }

    /**
     * Sets the value of the loginBranchName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoginBranchName(String value) {
        this.loginBranchName = value;
    }

    /**
     * Gets the value of the advisorName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdvisorName() {
        return advisorName;
    }

    /**
     * Sets the value of the advisorName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdvisorName(String value) {
        this.advisorName = value;
    }

    /**
     * Gets the value of the agentType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentType() {
        return agentType;
    }

    /**
     * Sets the value of the agentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentType(String value) {
        this.agentType = value;
    }

    /**
     * Gets the value of the orphan property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrphan() {
        return orphan;
    }

    /**
     * Sets the value of the orphan property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrphan(String value) {
        this.orphan = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

    /**
     * Gets the value of the interactionID property.
     * 
     */
    public long getInteractionID() {
        return interactionID;
    }

    /**
     * Sets the value of the interactionID property.
     * 
     */
    public void setInteractionID(long value) {
        this.interactionID = value;
    }

    /**
     * Gets the value of the phone1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhone1() {
        return phone1;
    }

    /**
     * Sets the value of the phone1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhone1(String value) {
        this.phone1 = value;
    }

    /**
     * Gets the value of the phone2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhone2() {
        return phone2;
    }

    /**
     * Sets the value of the phone2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhone2(String value) {
        this.phone2 = value;
    }

    /**
     * Gets the value of the phone3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhone3() {
        return phone3;
    }

    /**
     * Sets the value of the phone3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhone3(String value) {
        this.phone3 = value;
    }

    /**
     * Gets the value of the custType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustType() {
        return custType;
    }

    /**
     * Sets the value of the custType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustType(String value) {
        this.custType = value;
    }

    /**
     * Gets the value of the contact property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContact() {
        return contact;
    }

    /**
     * Sets the value of the contact property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContact(String value) {
        this.contact = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the configCustID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfigCustID() {
        return configCustID;
    }

    /**
     * Sets the value of the configCustID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfigCustID(String value) {
        this.configCustID = value;
    }

    /**
     * Gets the value of the prodCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdCode() {
        return prodCode;
    }

    /**
     * Sets the value of the prodCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdCode(String value) {
        this.prodCode = value;
    }

    /**
     * Gets the value of the pruCustID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPruCustID() {
        return pruCustID;
    }

    /**
     * Sets the value of the pruCustID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPruCustID(String value) {
        this.pruCustID = value;
    }

    /**
     * Gets the value of the salutation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalutation() {
        return salutation;
    }

    /**
     * Sets the value of the salutation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalutation(String value) {
        this.salutation = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the mobileNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobileNo() {
        return mobileNo;
    }

    /**
     * Sets the value of the mobileNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobileNo(String value) {
        this.mobileNo = value;
    }

    /**
     * Gets the value of the emailID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailID() {
        return emailID;
    }

    /**
     * Sets the value of the emailID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailID(String value) {
        this.emailID = value;
    }

    /**
     * Gets the value of the branchName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchName() {
        return branchName;
    }

    /**
     * Sets the value of the branchName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchName(String value) {
        this.branchName = value;
    }

    /**
     * Gets the value of the agentID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentID() {
        return agentID;
    }

    /**
     * Sets the value of the agentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentID(String value) {
        this.agentID = value;
    }

    /**
     * Gets the value of the agentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentCode() {
        return agentCode;
    }

    /**
     * Sets the value of the agentCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentCode(String value) {
        this.agentCode = value;
    }

    /**
     * Gets the value of the asigneeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAsigneeStatus() {
        return asigneeStatus;
    }

    /**
     * Sets the value of the asigneeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAsigneeStatus(String value) {
        this.asigneeStatus = value;
    }

    /**
     * Gets the value of the smName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSMName() {
        return smName;
    }

    /**
     * Sets the value of the smName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSMName(String value) {
        this.smName = value;
    }

    /**
     * Gets the value of the clientType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientType() {
        return clientType;
    }

    /**
     * Sets the value of the clientType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientType(String value) {
        this.clientType = value;
    }

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategory(String value) {
        this.category = value;
    }

    /**
     * Gets the value of the clinicName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClinicName() {
        return clinicName;
    }

    /**
     * Sets the value of the clinicName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClinicName(String value) {
        this.clinicName = value;
    }

    /**
     * Gets the value of the docPin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocPin() {
        return docPin;
    }

    /**
     * Sets the value of the docPin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocPin(String value) {
        this.docPin = value;
    }

    /**
     * Gets the value of the clinicArea property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClinicArea() {
        return clinicArea;
    }

    /**
     * Sets the value of the clinicArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClinicArea(String value) {
        this.clinicArea = value;
    }

    /**
     * Gets the value of the areaCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAreaCode() {
        return areaCode;
    }

    /**
     * Sets the value of the areaCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAreaCode(String value) {
        this.areaCode = value;
    }

    /**
     * Gets the value of the sendASMS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendASMS() {
        return sendASMS;
    }

    /**
     * Sets the value of the sendASMS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendASMS(String value) {
        this.sendASMS = value;
    }

    /**
     * Gets the value of the ard property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getARD() {
        return ard;
    }

    /**
     * Sets the value of the ard property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setARD(String value) {
        this.ard = value;
    }

    /**
     * Gets the value of the rcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRCD() {
        return rcd;
    }

    /**
     * Sets the value of the rcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRCD(String value) {
        this.rcd = value;
    }

    /**
     * Gets the value of the umfName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUMFName() {
        return umfName;
    }

    /**
     * Sets the value of the umfName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUMFName(String value) {
        this.umfName = value;
    }

    /**
     * Gets the value of the serviceBranchName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceBranchName() {
        return serviceBranchName;
    }

    /**
     * Sets the value of the serviceBranchName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceBranchName(String value) {
        this.serviceBranchName = value;
    }

    /**
     * Gets the value of the result property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResult() {
        return result;
    }

    /**
     * Sets the value of the result property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResult(String value) {
        this.result = value;
    }

    /**
     * Gets the value of the clientIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientIndicator() {
        return clientIndicator;
    }

    /**
     * Sets the value of the clientIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientIndicator(String value) {
        this.clientIndicator = value;
    }

    /**
     * Gets the value of the masterPolicyNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMasterPolicyNo() {
        return masterPolicyNo;
    }

    /**
     * Sets the value of the masterPolicyNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMasterPolicyNo(String value) {
        this.masterPolicyNo = value;
    }

    /**
     * Gets the value of the iSolutionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISolutionName() {
        return iSolutionName;
    }

    /**
     * Sets the value of the iSolutionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISolutionName(String value) {
        this.iSolutionName = value;
    }

    /**
     * Gets the value of the dnc property.
     * 
     */
    public boolean isDNC() {
        return dnc;
    }

    /**
     * Sets the value of the dnc property.
     * 
     */
    public void setDNC(boolean value) {
        this.dnc = value;
    }

    /**
     * Gets the value of the vvip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVVIP() {
        return vvip;
    }

    /**
     * Sets the value of the vvip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVVIP(String value) {
        this.vvip = value;
    }

}
