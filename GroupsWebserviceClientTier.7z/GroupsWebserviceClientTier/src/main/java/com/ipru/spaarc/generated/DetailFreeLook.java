
package com.ipru.spaarc.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for DetailFreeLook complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetailFreeLook">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IsChanged" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InteractionId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="ChangesToBeDone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OldValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NewValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApprovalTaken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SignatureVerificationDone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UnderWriting" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PolicyCollectedDefacedAtBranch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LetterDispatchedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="DifferenceAppFormPolicyCertificate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IsUpdated" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetailFreeLook", propOrder = {
    "isChanged",
    "interactionId",
    "changesToBeDone",
    "oldValue",
    "newValue",
    "approvalTaken",
    "signatureVerificationDone",
    "underWriting",
    "policyCollectedDefacedAtBranch",
    "letterDispatchedDate",
    "differenceAppFormPolicyCertificate",
    "isUpdated"
})
public class DetailFreeLook {

    @XmlElement(name = "IsChanged")
    protected boolean isChanged;
    @XmlElement(name = "InteractionId")
    protected long interactionId;
    @XmlElement(name = "ChangesToBeDone")
    protected String changesToBeDone;
    @XmlElement(name = "OldValue")
    protected String oldValue;
    @XmlElement(name = "NewValue")
    protected String newValue;
    @XmlElement(name = "ApprovalTaken")
    protected String approvalTaken;
    @XmlElement(name = "SignatureVerificationDone")
    protected String signatureVerificationDone;
    @XmlElement(name = "UnderWriting")
    protected String underWriting;
    @XmlElement(name = "PolicyCollectedDefacedAtBranch")
    protected String policyCollectedDefacedAtBranch;
    @XmlElement(name = "LetterDispatchedDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar letterDispatchedDate;
    @XmlElement(name = "DifferenceAppFormPolicyCertificate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar differenceAppFormPolicyCertificate;
    @XmlElement(name = "IsUpdated")
    protected boolean isUpdated;

    /**
     * Gets the value of the isChanged property.
     * 
     */
    public boolean isIsChanged() {
        return isChanged;
    }

    /**
     * Sets the value of the isChanged property.
     * 
     */
    public void setIsChanged(boolean value) {
        this.isChanged = value;
    }

    /**
     * Gets the value of the interactionId property.
     * 
     */
    public long getInteractionId() {
        return interactionId;
    }

    /**
     * Sets the value of the interactionId property.
     * 
     */
    public void setInteractionId(long value) {
        this.interactionId = value;
    }

    /**
     * Gets the value of the changesToBeDone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChangesToBeDone() {
        return changesToBeDone;
    }

    /**
     * Sets the value of the changesToBeDone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChangesToBeDone(String value) {
        this.changesToBeDone = value;
    }

    /**
     * Gets the value of the oldValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldValue() {
        return oldValue;
    }

    /**
     * Sets the value of the oldValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldValue(String value) {
        this.oldValue = value;
    }

    /**
     * Gets the value of the newValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewValue() {
        return newValue;
    }

    /**
     * Sets the value of the newValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewValue(String value) {
        this.newValue = value;
    }

    /**
     * Gets the value of the approvalTaken property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApprovalTaken() {
        return approvalTaken;
    }

    /**
     * Sets the value of the approvalTaken property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApprovalTaken(String value) {
        this.approvalTaken = value;
    }

    /**
     * Gets the value of the signatureVerificationDone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignatureVerificationDone() {
        return signatureVerificationDone;
    }

    /**
     * Sets the value of the signatureVerificationDone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignatureVerificationDone(String value) {
        this.signatureVerificationDone = value;
    }

    /**
     * Gets the value of the underWriting property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnderWriting() {
        return underWriting;
    }

    /**
     * Sets the value of the underWriting property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnderWriting(String value) {
        this.underWriting = value;
    }

    /**
     * Gets the value of the policyCollectedDefacedAtBranch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyCollectedDefacedAtBranch() {
        return policyCollectedDefacedAtBranch;
    }

    /**
     * Sets the value of the policyCollectedDefacedAtBranch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyCollectedDefacedAtBranch(String value) {
        this.policyCollectedDefacedAtBranch = value;
    }

    /**
     * Gets the value of the letterDispatchedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLetterDispatchedDate() {
        return letterDispatchedDate;
    }

    /**
     * Sets the value of the letterDispatchedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLetterDispatchedDate(XMLGregorianCalendar value) {
        this.letterDispatchedDate = value;
    }

    /**
     * Gets the value of the differenceAppFormPolicyCertificate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDifferenceAppFormPolicyCertificate() {
        return differenceAppFormPolicyCertificate;
    }

    /**
     * Sets the value of the differenceAppFormPolicyCertificate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDifferenceAppFormPolicyCertificate(XMLGregorianCalendar value) {
        this.differenceAppFormPolicyCertificate = value;
    }

    /**
     * Gets the value of the isUpdated property.
     * 
     */
    public boolean isIsUpdated() {
        return isUpdated;
    }

    /**
     * Sets the value of the isUpdated property.
     * 
     */
    public void setIsUpdated(boolean value) {
        this.isUpdated = value;
    }

}
