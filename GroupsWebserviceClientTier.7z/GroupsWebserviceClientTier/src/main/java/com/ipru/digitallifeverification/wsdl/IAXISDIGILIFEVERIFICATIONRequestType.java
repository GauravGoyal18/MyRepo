
package com.ipru.digitallifeverification.wsdl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IAXIS_DIGILIFE_VERIFICATIONRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IAXIS_DIGILIFE_VERIFICATIONRequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IAXIS_DIGILIFE_VERIFICATIONRequestElement">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CONTRACT_ID" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement(name = "IAXIS_DIGILIFE_VERIFICATIONRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IAXIS_DIGILIFE_VERIFICATIONRequestType", propOrder = {
    "iaxisdigilifeverificationRequestElement"
})
public class IAXISDIGILIFEVERIFICATIONRequestType {

    @XmlElement(name = "IAXIS_DIGILIFE_VERIFICATIONRequestElement", required = true)
    protected IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement iaxisdigilifeverificationRequestElement;

    /**
     * Gets the value of the iaxisdigilifeverificationRequestElement property.
     * 
     * @return
     *     possible object is
     *     {@link IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement }
     *     
     */
    public IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement getIAXISDIGILIFEVERIFICATIONRequestElement() {
        return iaxisdigilifeverificationRequestElement;
    }

    /**
     * Sets the value of the iaxisdigilifeverificationRequestElement property.
     * 
     * @param value
     *     allowed object is
     *     {@link IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement }
     *     
     */
    public void setIAXISDIGILIFEVERIFICATIONRequestElement(IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement value) {
        this.iaxisdigilifeverificationRequestElement = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="CONTRACT_ID" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "contractid"
    })
    public static class IAXISDIGILIFEVERIFICATIONRequestElement {

        @XmlElement(name = "CONTRACT_ID")
        protected String contractid;

        /**
         * Gets the value of the contractid property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCONTRACTID() {
            return contractid;
        }

        /**
         * Sets the value of the contractid property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCONTRACTID(String value) {
            this.contractid = value;
        }

    }

}
