@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.informatica.com/")
package com.ipru.digitallifeverification.informatica;
