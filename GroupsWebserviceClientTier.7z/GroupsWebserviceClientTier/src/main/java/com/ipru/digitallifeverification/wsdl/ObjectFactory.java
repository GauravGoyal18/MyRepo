
package com.ipru.digitallifeverification.wsdl;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.informatica.wsdl package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _IAXISDIGILIFEVERIFICATIONRequest_QNAME = new QName("http://www.informatica.com/wsdl/", "IAXIS_DIGILIFE_VERIFICATIONRequest");
    private final static QName _IAXISDIGILIFEVERIFICATIONResponse_QNAME = new QName("http://www.informatica.com/wsdl/", "IAXIS_DIGILIFE_VERIFICATIONResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.informatica.wsdl
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link IAXISDIGILIFEVERIFICATIONRequestType }
     * 
     */
    public IAXISDIGILIFEVERIFICATIONRequestType createIAXISDIGILIFEVERIFICATIONRequestType() {
        return new IAXISDIGILIFEVERIFICATIONRequestType();
    }

    /**
     * Create an instance of {@link IAXISDIGILIFEVERIFICATIONResponseType }
     * 
     */
    public IAXISDIGILIFEVERIFICATIONResponseType createIAXISDIGILIFEVERIFICATIONResponseType() {
        return new IAXISDIGILIFEVERIFICATIONResponseType();
    }

    /**
     * Create an instance of {@link IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement }
     * 
     */
    public IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement createIAXISDIGILIFEVERIFICATIONRequestTypeIAXISDIGILIFEVERIFICATIONRequestElement() {
        return new IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement();
    }

    /**
     * Create an instance of {@link IAXISDIGILIFEVERIFICATIONResponseType.IAXISDIGILIFEVERIFICATIONResponseElement }
     * 
     */
    public IAXISDIGILIFEVERIFICATIONResponseType.IAXISDIGILIFEVERIFICATIONResponseElement createIAXISDIGILIFEVERIFICATIONResponseTypeIAXISDIGILIFEVERIFICATIONResponseElement() {
        return new IAXISDIGILIFEVERIFICATIONResponseType.IAXISDIGILIFEVERIFICATIONResponseElement();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IAXISDIGILIFEVERIFICATIONRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.informatica.com/wsdl/", name = "IAXIS_DIGILIFE_VERIFICATIONRequest")
    public JAXBElement<IAXISDIGILIFEVERIFICATIONRequestType> createIAXISDIGILIFEVERIFICATIONRequest(IAXISDIGILIFEVERIFICATIONRequestType value) {
        return new JAXBElement<IAXISDIGILIFEVERIFICATIONRequestType>(_IAXISDIGILIFEVERIFICATIONRequest_QNAME, IAXISDIGILIFEVERIFICATIONRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IAXISDIGILIFEVERIFICATIONResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.informatica.com/wsdl/", name = "IAXIS_DIGILIFE_VERIFICATIONResponse")
    public JAXBElement<IAXISDIGILIFEVERIFICATIONResponseType> createIAXISDIGILIFEVERIFICATIONResponse(IAXISDIGILIFEVERIFICATIONResponseType value) {
        return new JAXBElement<IAXISDIGILIFEVERIFICATIONResponseType>(_IAXISDIGILIFEVERIFICATIONResponse_QNAME, IAXISDIGILIFEVERIFICATIONResponseType.class, null, value);
    }

}
