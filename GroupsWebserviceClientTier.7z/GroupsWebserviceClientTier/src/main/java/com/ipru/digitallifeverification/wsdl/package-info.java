@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.informatica.com/wsdl/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ipru.digitallifeverification.wsdl;
