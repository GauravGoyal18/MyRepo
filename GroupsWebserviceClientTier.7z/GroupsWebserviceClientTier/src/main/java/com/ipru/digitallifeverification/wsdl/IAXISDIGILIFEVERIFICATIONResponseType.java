
package com.ipru.digitallifeverification.wsdl;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for IAXIS_DIGILIFE_VERIFICATIONResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IAXIS_DIGILIFE_VERIFICATIONResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IAXIS_DIGILIFE_VERIFICATIONResponseElement" maxOccurs="unbounded">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FIRST_NAME" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="CONTRACT_ID" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="POLICY_ID" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="TRUST_NAME" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="DATE_OF_BIRTH" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="PAN_NO" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="PHONE_MOBILE" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="NEWFIELD7" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="NEWFIELD8" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="NEWFIELD9" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="NEWFIELD10" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}dateTime">
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                   &lt;element name="NEWFIELD11" minOccurs="0">
 *                     &lt;simpleType>
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                         &lt;maxLength value="500"/>
 *                       &lt;/restriction>
 *                     &lt;/simpleType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement(name = "IAXIS_DIGILIFE_VERIFICATIONResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IAXIS_DIGILIFE_VERIFICATIONResponseType", propOrder = {
    "iaxisdigilifeverificationResponseElement"
})
public class IAXISDIGILIFEVERIFICATIONResponseType {

    @XmlElement(name = "IAXIS_DIGILIFE_VERIFICATIONResponseElement", required = true)
    protected List<IAXISDIGILIFEVERIFICATIONResponseType.IAXISDIGILIFEVERIFICATIONResponseElement> iaxisdigilifeverificationResponseElement;

    /**
     * Gets the value of the iaxisdigilifeverificationResponseElement property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the iaxisdigilifeverificationResponseElement property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIAXISDIGILIFEVERIFICATIONResponseElement().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IAXISDIGILIFEVERIFICATIONResponseType.IAXISDIGILIFEVERIFICATIONResponseElement }
     * 
     * 
     */
    public List<IAXISDIGILIFEVERIFICATIONResponseType.IAXISDIGILIFEVERIFICATIONResponseElement> getIAXISDIGILIFEVERIFICATIONResponseElement() {
        if (iaxisdigilifeverificationResponseElement == null) {
            iaxisdigilifeverificationResponseElement = new ArrayList<IAXISDIGILIFEVERIFICATIONResponseType.IAXISDIGILIFEVERIFICATIONResponseElement>();
        }
        return this.iaxisdigilifeverificationResponseElement;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FIRST_NAME" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="CONTRACT_ID" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="POLICY_ID" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="TRUST_NAME" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="DATE_OF_BIRTH" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="PAN_NO" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="PHONE_MOBILE" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="NEWFIELD7" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="NEWFIELD8" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="NEWFIELD9" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="NEWFIELD10" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}dateTime">
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *         &lt;element name="NEWFIELD11" minOccurs="0">
     *           &lt;simpleType>
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *               &lt;maxLength value="500"/>
     *             &lt;/restriction>
     *           &lt;/simpleType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "firstname",
        "contractid",
        "policyid",
        "trustname",
        "dateofbirth",
        "panno",
        "phonemobile",
        "newfield7",
        "newfield8",
        "newfield9",
        "newfield10",
        "newfield11"
    })
    public static class IAXISDIGILIFEVERIFICATIONResponseElement {

        @XmlElement(name = "FIRST_NAME")
        protected String firstname;
        @XmlElement(name = "CONTRACT_ID")
        protected String contractid;
        @XmlElement(name = "POLICY_ID")
        protected String policyid;
        @XmlElement(name = "TRUST_NAME")
        protected String trustname;
        @XmlElement(name = "DATE_OF_BIRTH")
        protected String dateofbirth;
        @XmlElement(name = "PAN_NO")
        protected String panno;
        @XmlElement(name = "PHONE_MOBILE")
        protected String phonemobile;
        @XmlElement(name = "NEWFIELD7")
        protected String newfield7;
        @XmlElement(name = "NEWFIELD8")
        protected String newfield8;
        @XmlElement(name = "NEWFIELD9")
        protected String newfield9;
        @XmlElement(name = "NEWFIELD10")
        protected XMLGregorianCalendar newfield10;
        @XmlElement(name = "NEWFIELD11")
        protected String newfield11;

        /**
         * Gets the value of the firstname property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFIRSTNAME() {
            return firstname;
        }

        /**
         * Sets the value of the firstname property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFIRSTNAME(String value) {
            this.firstname = value;
        }

        /**
         * Gets the value of the contractid property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCONTRACTID() {
            return contractid;
        }

        /**
         * Sets the value of the contractid property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCONTRACTID(String value) {
            this.contractid = value;
        }

        /**
         * Gets the value of the policyid property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPOLICYID() {
            return policyid;
        }

        /**
         * Sets the value of the policyid property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPOLICYID(String value) {
            this.policyid = value;
        }

        /**
         * Gets the value of the trustname property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTRUSTNAME() {
            return trustname;
        }

        /**
         * Sets the value of the trustname property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTRUSTNAME(String value) {
            this.trustname = value;
        }

        /**
         * Gets the value of the dateofbirth property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDATEOFBIRTH() {
            return dateofbirth;
        }

        /**
         * Sets the value of the dateofbirth property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDATEOFBIRTH(String value) {
            this.dateofbirth = value;
        }

        /**
         * Gets the value of the panno property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPANNO() {
            return panno;
        }

        /**
         * Sets the value of the panno property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPANNO(String value) {
            this.panno = value;
        }

        /**
         * Gets the value of the phonemobile property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPHONEMOBILE() {
            return phonemobile;
        }

        /**
         * Sets the value of the phonemobile property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPHONEMOBILE(String value) {
            this.phonemobile = value;
        }

        /**
         * Gets the value of the newfield7 property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNEWFIELD7() {
            return newfield7;
        }

        /**
         * Sets the value of the newfield7 property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNEWFIELD7(String value) {
            this.newfield7 = value;
        }

        /**
         * Gets the value of the newfield8 property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNEWFIELD8() {
            return newfield8;
        }

        /**
         * Sets the value of the newfield8 property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNEWFIELD8(String value) {
            this.newfield8 = value;
        }

        /**
         * Gets the value of the newfield9 property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNEWFIELD9() {
            return newfield9;
        }

        /**
         * Sets the value of the newfield9 property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNEWFIELD9(String value) {
            this.newfield9 = value;
        }

        /**
         * Gets the value of the newfield10 property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getNEWFIELD10() {
            return newfield10;
        }

        /**
         * Sets the value of the newfield10 property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setNEWFIELD10(XMLGregorianCalendar value) {
            this.newfield10 = value;
        }

        /**
         * Gets the value of the newfield11 property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNEWFIELD11() {
            return newfield11;
        }

        /**
         * Sets the value of the newfield11 property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNEWFIELD11(String value) {
            this.newfield11 = value;
        }

		@Override
		public String toString() {
			return "IAXISDIGILIFEVERIFICATIONResponseElement [firstname="
					+ firstname + ", contractid=" + contractid + ", policyid="
					+ policyid + ", trustname=" + trustname + ", dateofbirth="
					+ dateofbirth + ", panno=" + panno + ", phonemobile="
					+ phonemobile + ", newfield7=" + newfield7 + ", newfield8="
					+ newfield8 + ", newfield9=" + newfield9 + ", newfield10="
					+ newfield10 + ", newfield11=" + newfield11 + "]";
		}
        
        

    }

}
