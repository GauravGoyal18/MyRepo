package com.ipru.ecamptransaction.bean;

import java.util.List;

public class EcampJsonBean {

	private String campaign;
	private List<String> dynParam;

	public String getCampaign() {
		return campaign;
	}

	public void setCampaign(String campaign) {
		this.campaign = campaign;
	}

	public List<String> getDynParam() {
		return dynParam;
	}

	public void setDynParam(List<String> dynParam) {
		this.dynParam = dynParam;
	}

}
