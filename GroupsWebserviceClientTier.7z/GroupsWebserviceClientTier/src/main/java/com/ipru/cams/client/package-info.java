@javax.xml.bind.annotation.XmlSchema(namespace = "http://client.cams.ipru.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ipru.cams.client;
