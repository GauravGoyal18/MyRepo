package com.estatement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.ipru.groups.utilities.DateUtil;

public class ClickPSSWebService2  {

	/**
	 * @param args
	 */

	private String policyNo = "";
	private String customerId = "";
	private String toDate = "";
	private String fromDate = "";
	private String templateId;
	private String loanAcNO;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public String getLoanAcNO() {
		return loanAcNO;
	}

	public void setLoanAcNO(String loanAcNO) {
		this.loanAcNO = loanAcNO;
	}
	
	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClickPSSWebService clickPSSWebService = new ClickPSSWebService();
		try {

			clickPSSWebService.setPolicyNo(SecurePassword.encode("00012043"));

			clickPSSWebService.setCustomerId(SecurePassword.encode("00002023"));

			clickPSSWebService.setTemplateId(SecurePassword.encode("T040"));

			URLEncoder.encode(clickPSSWebService.getTemplateId(), "UTF-8");
			URLEncoder.encode(clickPSSWebService.getCustomerId(), "UTF-8");
			URLEncoder.encode(clickPSSWebService.getPolicyNo(), "UTF-8");
			URLEncoder.encode(clickPSSWebService.getToDate(), "UTF-8");
			URLEncoder.encode(clickPSSWebService.getFromDate(), "UTF-8");

			URL url = new URL("http://10.51.0.72:9090/CRMWS/resources/tokenWS/getTokenWithEncryptedData");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			
			 * conn.setRequestProperty("templateId",
			 * clickPSSWebService.getTemplateId());
			 * conn.setRequestProperty("customerId",
			 * clickPSSWebService.getCustomerId());
			 * conn.setRequestProperty("policyNo",
			 * clickPSSWebService.getPolicyNo());
			 

			Map<String, Object> requestMap = new HashMap<String, Object>(1);
			requestMap.put("templateId", clickPSSWebService.getTemplateId());
			requestMap.put("customerId", clickPSSWebService.getCustomerId());
			requestMap.put("policyNo", clickPSSWebService.getPolicyNo());
			requestMap.put("classObj", clickPSSWebService);
			requestMap.put("requestUrl","http://10.51.0.72:9090/CRMWS/resources/tokenWS/getTokenWithEncryptedData");
			invokeGenericRestClient(requestMap);
			//invokeRestClientThroughHttpUrlConnection(requestMap,"http://10.51.0.72:9090/CRMWS/resources/tokenWS/getTokenWithEncryptedData");
			validateIssuanceDateForClickPSS(new Date(), "01/12/2016","dd/MM/yyyy");

			
			 * String POST_PARAMS =
			 * "templateId=50886AAE5080D703&fromDate=&toDate=&policyNo=780A8BA878C313550C7728E9D8E0F8A5&customerId=620067FE437C278E0C7728E9D8E0F8A5"
			 * ; //System.out.println(conn.getURL());
			 * 
			 * // For POST only - START conn.setDoOutput(true); OutputStream os
			 * = conn.getOutputStream(); os.write(POST_PARAMS.getBytes());
			 * os.flush(); os.close(); // For POST only - END
			 * 
			 * if (conn.getResponseCode() != 200) { throw new
			 * RuntimeException("Failed : HTTP error code : " +
			 * conn.getResponseCode()); }
			 * 
			 * BufferedReader br = new BufferedReader(new InputStreamReader(
			 * (conn.getInputStream())));
			 * 
			 * String output; ////System.out.println("Output from Server .... \n");
			 * while ((output = br.readLine()) != null) {
			 * //System.out.println(output); }
			 * 
			 * conn.disconnect();
			 * 
			 * } catch (MalformedURLException e) {
			 * 
			 * e.printStackTrace();
			 * 
			 * } catch (IOException e) {
			 * 
			 * e.printStackTrace();
			 

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}*/

	@Override
	public String toString() {
		return "ClickPSSWebService2 [policyNo=" + policyNo + ", customerId=" + customerId + ", toDate=" + toDate + ", fromDate=" + fromDate + ", templateId=" + templateId + ", loanAcNO=" + loanAcNO
				+ "]";
	}

	

	public String toRawPayload() {
		return "policyNo=" + policyNo + "&customerId=" + customerId
				+ "&toDate=" + toDate + "&fromDate=" + fromDate
				+ "&templateId=" + templateId + "&loanAcNO=" + loanAcNO;
	}

	

	/*public static Object invokeGenericRestClient(Map<String, Object> requestMap) {
		String method = "invokeGenericRestClient";
		//FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"method starts");
		String response = null;
		String clickPSSResponseUrl = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			String uri = (String) requestMap.get("requestUrl");
			String strDataJson = ((ClickPSSWebService) requestMap.get("classObj")).toRawPayload();
			
			headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
			RestTemplate restTemplate = new RestTemplate();
			////System.out.println("Json ---"+ strDataJson);
//			FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"ClickPSS request string  "+ strDataJson);
			HttpEntity<String> requestEntity = new HttpEntity<String>(strDataJson, headers);
			
			////System.out.println("entity1 ---" + requestEntity);
			response = restTemplate.postForObject(uri, requestEntity,String.class);
			String[] responseArray = response.split("url : ");
			if(responseArray.length > 1)
				clickPSSResponseUrl = responseArray[1];
			//System.out.println(clickPSSResponseUrl);
//			FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"ClickPSS redirection URL "+ clickPSSResponseUrl);
		} catch (Exception e) {
			e.printStackTrace();
//			FLogger.error("CSR.PolicyStatements", "ClickPSSWebService", method,"Exception occured " + e.getMessage());
		}
//		FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"method ends");
		return clickPSSResponseUrl;

	}
*/
	public static Object invokeRestClientThroughHttpUrlConnection(
			Map<String, Object> requestMap, String Url) {
		String method = "invokeRestClientThroughHttpUrlConnection";
//		FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"method starts");
		String response = null;
		try {
			URL url = new URL(Url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			String requestParams = ((ClickPSSWebService2) requestMap
					.get("classObj")).toRawPayload();
			// For POST only - START
			conn.setDoOutput(true);
			OutputStream os = conn.getOutputStream();
			os.write(requestParams.getBytes());
			os.flush();
			os.close();
			// For POST only - END

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			response = br.readLine();
			////System.out.println("Output from Server .... \n");
			while ((response) != null) {
				//System.out.println(response);
			}

			conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();
//			FLogger.error("CSR.PolicyStatements", "ClickPSSWebService", method,"MalformedURLException occured " + e.getMessage());

		} catch (IOException e) {

			e.printStackTrace();
//			FLogger.error("CSR.PolicyStatements", "ClickPSSWebService", method,"IOException occured " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
//			FLogger.error("CSR.PolicyStatements", "ClickPSSWebService", method,"Exception occured " + e.getMessage());
		}
//		FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"method ends");
		return response;
	}

	public static boolean validateIssuanceDateForClickPSS(
			Date policyIssuanceDate, String clickPSSBoundaryDate,String dateFormat) {
		String method = "validateIssuanceDateForClickPSS";
//		FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"method starts");
		boolean issueDateIsValidForClickPSS = Boolean.FALSE;
		try {
			if (policyIssuanceDate != null) {
				/*Date date = null;*/
				if (StringUtils.isNotBlank(clickPSSBoundaryDate)) {
					/*date = DateUtil.formatStrDate(clickPSSBoundaryDate,
							"dd/MM/yyyy");*/
					String polIssuanceDate = DateUtil.formatDate(policyIssuanceDate  , dateFormat);
					int dateDifference = DateUtil.compareDateStrings(polIssuanceDate, clickPSSBoundaryDate, dateFormat);
					/*
					 * if(policyIssuanceDate.equals(date)) flag = Boolean.TRUE;
					 * else if(policyIssuanceDate.after(date))
					 * issueDateIsValidForClickPSS = Boolean.TRUE; else
					 * issueDateIsValidForClickPSS = Boolean.FALSE; }
					 */

					/*
					 * if policuIssueDate is greater or equals to the given date
					 * then it is valid for ClickPSS functionality
					 */
					if (dateDifference < 0) {
						issueDateIsValidForClickPSS = Boolean.FALSE;
					} else {
						issueDateIsValidForClickPSS = Boolean.TRUE;
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
//			FLogger.error("CSR.PolicyStatements", "ClickPSSWebService", method,"Exception occured " + e.getMessage());
		}
//		FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"method ends");
		return issueDateIsValidForClickPSS;
	}

}

