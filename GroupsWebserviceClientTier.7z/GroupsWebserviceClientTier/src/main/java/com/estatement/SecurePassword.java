package com.estatement;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;

/**
 * 
 */
 public class SecurePassword {
	private final static String Algorithm = "DES";
	private final static String PASSWORD_CRYPT_KEY = "__f5ads_";
//	static {
//		//Security.addProvider(new com.sun.crypto.provider.SunJCE());
//	}

	public static String byte2hex(final byte[] b) {
		String hs = "";
		for (final byte element : b) {
                  //  ////System.out.println("element "+element +" "+(element & 0xff)+" "+Integer.toHexString(element & 0xff));
			final String s2 = Integer.toHexString(element & 0xff);
			if (s2.length() == 1) {
                           
				hs = new StringBuilder().append(hs).append("0").append(s2).toString();
			} else {

				hs = new StringBuilder().append(hs).append(s2).toString();
			}
		}
		return hs.toUpperCase();
	}

	public static String decode(final String input) throws Exception {
		final SecretKey deskey = new javax.crypto.spec.SecretKeySpec(SecurePassword.getKey(), SecurePassword.Algorithm);
		final Cipher c1 = Cipher.getInstance(SecurePassword.Algorithm);
		c1.init(Cipher.DECRYPT_MODE, deskey);
		final byte[] clearByte = c1.doFinal(SecurePassword.hex2byte(input));
		return new String(clearByte);
	}

	public static String encode(final String input) throws Exception {
		final SecretKey deskey = new javax.crypto.spec.SecretKeySpec(SecurePassword.getKey(), SecurePassword.Algorithm);
		final Cipher c1 = Cipher.getInstance(SecurePassword.Algorithm);
		c1.init(Cipher.ENCRYPT_MODE, deskey);
		final byte[] cipherByte = c1.doFinal(input.getBytes());
		return SecurePassword.byte2hex(cipherByte);
	}

	public static byte[] getKey() throws Exception {
		return SecurePassword.PASSWORD_CRYPT_KEY.getBytes();
	}

	public static byte[] hex2byte(final String h) {
		final byte[] ret = new byte[h.length() / 2];
		for (int i = 0; i < ret.length; i++) {
			ret[i] = Integer.decode(new StringBuilder().append("#").append(h.substring(2 * i, 2 * i + 2)).toString()).byteValue();
		}
		return ret;
	}
        public static void main(String[] args) throws Exception {
//         String text="";
//fullpdf
//            byte[] bytes = text.getBytes();
//            //System.out.println(SecurePassword.decode("B3E2FA23070ACB8AA4E2DE5D00620FD1"));
            //System.out.println(SecurePassword.encode("13506350"));
            //System.out.println(SecurePassword.decode(SecurePassword.encode("13506350")));
           // String byte2hex = byte2hex(bytes);
           // //System.out.println(byte2hex);
     }
}

