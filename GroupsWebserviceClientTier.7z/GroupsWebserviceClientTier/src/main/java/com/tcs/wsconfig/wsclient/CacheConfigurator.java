package com.tcs.wsconfig.wsclient;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.exception.WebServiceClientException;
import com.tcs.logger.FLogger;

public final class CacheConfigurator {

	private CacheConfigurator() {
		super();
	}

	private static CacheManager cacheManagerInstance;

	public static final String CONSTANT_WS_CONFIG_CACHE_NAME = "wsConfigCache";
	//public static final String FILE_PATH = MasterPropertiesFileLoader.CONSTANT_SOL_DOC_PATH_PROPERTIES.getProperty("EHCACHE_CONFIG");
//public static final String FILE_PATH = "D:\\Abhinay_Data\\DIGI_Drive_WorkSpace\\IPruConfig\\CacheConfig\\ehcache.xml";
//	public static final String FILE_PATH = "D:\\Kashmira\\Workspace\\Groups\\GroupsUAT10Nov2016\\GroupsIPruConfig\\CacheConfig\\ehcache.xml";
	public static final String FILE_PATH = GroupConstants.CONSTANT_C + MasterPropertiesFileLoader.CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH.get("Cache_Path");
	
	

	public static CacheManager getCacheManagerInstance() throws Exception {
		if (cacheManagerInstance == null) {
			synchronized(CONSTANT_WS_CONFIG_CACHE_NAME){
			InputStream fis = null;
			try {
				fis = new FileInputStream(new File(FILE_PATH).getAbsolutePath());
				cacheManagerInstance = CacheManager.create(fis);

			}
			catch (FileNotFoundException e) {
				FLogger.error("WebServiceLogger", "CacheConfigurator", "getCacheManagerInstance", "Error occurred while creating CacheManager", e);
				throw e;
			}
			finally {
				if (fis != null) {
					try {
						fis.close();
					}
					catch (IOException e) {
						FLogger.error("WebServiceLogger", "CacheConfigurator", "getCacheManagerInstance", "Error occurred while closing stream", e);
					}
				}
			}

		}
		}
		return cacheManagerInstance;
	}

	/**
	 * Do not create a singleton when using this method
	 * 
	 * @return
	 * @throws Exception
	 */
	public static Ehcache getWsConfigCache() throws Exception {
		return getCacheManagerInstance().getEhcache(CONSTANT_WS_CONFIG_CACHE_NAME);//wsConfigCache
	}

	public static void reloadWsConfigCache(Map<String, Object> wsConfigMap) throws Exception {
		FLogger.info("WebServiceLogger", "CacheConfigurator", "reloadWsConfigCache", "Entering method");
		if (MapUtils.isEmpty(wsConfigMap)) {
			FLogger.error("WebServiceLogger", "CacheConfigurator", "reloadWsConfigCache", "Input Map is Empty");
			throw new WebServiceClientException("Input Map is Empty");
		}
		Ehcache reloadedWsConfigCache = getWsConfigCache();
		FLogger.info("WebServiceLogger", "CacheConfigurator", "reloadWsConfigCache", "Removing all entries of the cache::" + CONSTANT_WS_CONFIG_CACHE_NAME);
		reloadedWsConfigCache.removeAll();
		FLogger.info("WebServiceLogger", "CacheConfigurator", "reloadWsConfigCache", "Removed successfully all entries of the cache::" + CONSTANT_WS_CONFIG_CACHE_NAME);
		Set<Entry<String, Object>> wsConfigMapEntrys = wsConfigMap.entrySet();
		boolean isLoadedAtleastOne = false;
		for (Entry<String, Object> entry : wsConfigMapEntrys) {
			if (entry != null) {
				Element cacheElement = new Element(entry.getKey(), entry.getValue());
				FLogger.debug("WebServiceLogger", "CacheConfigurator", "reloadWsConfigCache", "Putting Key::" + entry.getKey() + "::of the cache::" + CONSTANT_WS_CONFIG_CACHE_NAME);
				reloadedWsConfigCache.put(cacheElement);
				if (!isLoadedAtleastOne) {
					isLoadedAtleastOne = true;
				}
			}
		}
		if (isLoadedAtleastOne) {
			getWsConfigCache();
		}
		FLogger.info("WebServiceLogger", "CacheConfigurator", "reloadWsConfigCache", "Leaving method");
	}

	/**
	 * Get Value for WsConfigCache
	 * 
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static Serializable getCacheElementValue(Serializable key) throws Exception {
		if (key == null || (key instanceof String && StringUtils.isBlank(String.valueOf(key)))) {
			FLogger.error("WebServiceLogger", "CacheConfigurator", "getCacheElementValue", "Input key not found::" + CONSTANT_WS_CONFIG_CACHE_NAME);
			throw new WebServiceClientException("Input key found is null/blank/empty");
		}

		FLogger.info("WebServiceLogger", "CacheConfigurator", "getCacheElementValue", CONSTANT_WS_CONFIG_CACHE_NAME + "::Get Value for key::" + key.toString());
		if (getWsConfigCache().get(key) == null)
			return null;
		return (Serializable) getWsConfigCache().get(key).getObjectValue();
	}

	/**
	 * Get Value in a specific Cache
	 * 
	 * @param key
	 * @param cacheName
	 * @return
	 * @throws Exception
	 */
	public static Serializable getCacheElementValue(Serializable key, String cacheName) throws Exception {
		if (key == null || (key instanceof String && StringUtils.isBlank(String.valueOf(key)))) {
			FLogger.error("WebServiceLogger", "CacheConfigurator", "getCacheElementValue", "Input key not found::" + cacheName);
			throw new WebServiceClientException("Input key found is null/blank/empty");
		}
		Ehcache cache = getCacheManagerInstance().getEhcache(cacheName);
		if (cache == null) {
			FLogger.error("WebServiceLogger", "CacheConfigurator", "getCacheElementValue", "Cache configuration not found::" + cacheName);
			throw new WebServiceClientException("Cache configuration not found");
		}
		
		if (cache.get(key) == null)
			return null;
		return (Serializable) cache.get(key).getObjectValue();
	}
	
	

}
