package com.tcs.wsconfig.wsclient;

import java.io.Serializable;

public class ClientProxy implements Serializable{

	private String ntlm;
	private String proxyHost;
	private String proxyPort;
	private String proxyUName;
	private String proxyProperty;
	private String winFullCompName;
	private String winDomin;
	
	public String getNtlm() {
		return ntlm;
	}
	public void setNtlm(String ntlm) {
		this.ntlm = ntlm;
	}
	public String getProxyHost() {
		return proxyHost;
	}
	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}
	public String getProxyPort() {
		return proxyPort;
	}
	public void setProxyPort(String proxyPort) {
		this.proxyPort = proxyPort;
	}
	public String getProxyUName() {
		return proxyUName;
	}
	public void setProxyUName(String proxyUName) {
		this.proxyUName = proxyUName;
	}
	public String getProxyProperty() {
		return proxyProperty;
	}
	public void setProxyProperty(String proxyProperty) {
		this.proxyProperty = proxyProperty;
	}
	public String getWinFullCompName() {
		return winFullCompName;
	}
	public void setWinFullCompName(String winFullCompName) {
		this.winFullCompName = winFullCompName;
	}
	public String getWinDomin() {
		return winDomin;
	}
	public void setWinDomin(String winDomin) {
		this.winDomin = winDomin;
	}
	

	
	
	

}
