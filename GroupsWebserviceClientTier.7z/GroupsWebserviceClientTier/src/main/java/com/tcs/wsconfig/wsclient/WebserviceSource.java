package com.tcs.wsconfig.wsclient;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.tcs.wsconfig.generated.Header;
import com.tcs.wsconfig.generated.Headers;

public class WebserviceSource implements Serializable, Comparable<WebserviceSource> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String url;
	private String hostname;
	private int port;
	private String wsType;
	private boolean isSecured;
	private String userName;
	private String property;
	private String wsName;
	private int priority;
	private String methodType;
	private ClientProxy proxy;
	private boolean useSSL;
	private List<Header> headerList;
	private List<Headers> headerLists;
	private int connTimeOut;
	private int socktTimeOut;
	private boolean useProxy;
	private Map<String, String> getParameters;
	private String customSecurityHeaderVal;

	// private boolean isUnmarshalNeeded;
	// private String unmarshalNeeded;

	public String getCustomSecurityHeaderVal() {
		return customSecurityHeaderVal;
	}

	public void setCustomSecurityHeaderVal(String customSecurityHeaderVal) {
		this.customSecurityHeaderVal = customSecurityHeaderVal;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getWsType() {
		return wsType;
	}

	public void setWsType(String wsType) {
		this.wsType = wsType;
	}

	public boolean isSecured() {
		return isSecured;
	}

	public void setSecured(boolean isSecured) {
		this.isSecured = isSecured;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getWsName() {
		return wsName;
	}

	public void setWsName(String wsName) {
		this.wsName = wsName;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getMethodType() {
		return methodType;
	}

	public void setMethodType(String methodType) {
		this.methodType = methodType;
	}

	public ClientProxy getProxy() {
		return proxy;
	}

	public void setProxy(ClientProxy proxy) {
		this.proxy = proxy;
	}

	public boolean isUseSSL() {
		return useSSL;
	}

	public void setUseSSL(boolean useSSL) {
		this.useSSL = useSSL;
	}

	public List<Header> getHeaderList() {
		return headerList;
	}

	public void setHeaderList(List<Header> headerList) {
		this.headerList = headerList;
	}

	public int getConnTimeOut() {
		return connTimeOut;
	}

	public void setConnTimeOut(int connTimeOut) {
		this.connTimeOut = connTimeOut;
	}

	public int getSocktTimeOut() {
		return socktTimeOut;
	}

	public void setSocktTimeOut(int socktTimeOut) {
		this.socktTimeOut = socktTimeOut;
	}

	public boolean isUseProxy() {
		return useProxy;
	}

	public void setUseProxy(boolean useProxy) {
		this.useProxy = useProxy;
	}

	public Map<String, String> getGetParameters() {
		return getParameters;
	}

	public void setGetParameters(Map<String, String> getParameters) {
		this.getParameters = getParameters;
	}

	/*
	 * public boolean isUnmarshalNeeded() { return isUnmarshalNeeded; } public
	 * void setUnmarshalNeeded(boolean isUnmarshalNeeded) {
	 * this.isUnmarshalNeeded = isUnmarshalNeeded; } public String
	 * getUnmarshalNeeded() { return unmarshalNeeded; } public void
	 * setUnmarshalNeeded(String unmarshalNeeded) { this.unmarshalNeeded =
	 * unmarshalNeeded; }
	 */

	@Override
	public int compareTo(WebserviceSource o) {
		if (priority == o.priority) {
			return 0;
		}
		else if (priority > o.priority) {
			return 1;
		}
		else {
			return -1;
		}

	}

	public List<Headers> getHeaderLists() {
		return headerLists;
	}

	public void setHeaderLists(List<Headers> headerLists) {
		this.headerLists = headerLists;
	}

}
