package com.tcs.wsconfig.wsclient;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.net.ssl.SSLContext;
import javax.net.ssl.X509TrustManager;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.ProxyAuthenticationStrategy;
import org.apache.http.message.BasicNameValuePair;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.google.gson.JsonObject;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.GroupsJsonUtils;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.exception.WebServiceClientException;
import com.tcs.logger.FLogger;
import com.tcs.wsconfig.generated.Header;


@SuppressWarnings("deprecation")
public class WebServiceClient {

	private static final String CLASS_NAME = "WebServiceClient";
	private static JAXBContext instance;
	private static Properties webServiceProperties = new Properties();
	// private static TransformerFactory instanceTransformerFactory;
	private static Transformer instanceTransformer;
	private static DocumentBuilderFactory instanceDocumentBuilderFactory;
	private static WebServiceClient webServiceClient;
	private static MessageFactory messageFactoryInstance;
	private static Document documentInstance;
	private static final String CUSTOMHEADER="XXXCustomSecurityHeader";

	static {
		FileInputStream fis = null;
		if (MasterPropertiesFileLoader.CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH != null) {
			webServiceProperties = MasterPropertiesFileLoader.CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH;
		}
		else {
			try {
				fis=new FileInputStream(GroupConstants.CONSTANT_WEBSERVICE);
				webServiceProperties.load(fis);
				
			//	webServiceProperties.load(new FileInputStream("D:/Kashmira/Workspace/Groups/GroupsUAT10Nov2016/GroupsIPruConfig/WebserviceClient/webserviceclient.properties"));

				// webServiceProperties.load(new
				// FileInputStream("D:/Kashmira/Workspace/Groups/GroupsUAT10Nov2016/GroupsIPruConfig/Group/webserviceclient.properties"));
			}
			catch (FileNotFoundException e) {
				FLogger.error("WebServiceLogger", "WebServiceClient", "WebServiceClient", e.getMessage(), e);
			}
			catch (IOException e) {
				FLogger.error("WebServiceLogger", "WebServiceClient", "WebServiceClient", e.getMessage(), e);
			}
			
			finally {
				try {
					if(fis!=null)
						fis.close();
				}
				catch (Exception e) {
					FLogger.error("GROUPLoggerError", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
							"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
					e.printStackTrace();
				} finally {
					fis=null;
				}
			}
		}

	}

	public static MessageFactory getMessageFactoryInstance() throws SOAPException {
		if (messageFactoryInstance == null) {
			synchronized (CLASS_NAME) {
				messageFactoryInstance = MessageFactory.newInstance();
			}
		}
		return messageFactoryInstance;
	}

	public static WebServiceClient getInstance() {
		if (webServiceClient == null) {
			synchronized (CLASS_NAME) {
				webServiceClient = new WebServiceClient();
			}
		}
		return webServiceClient;
	}

	public static Document getDocumentInstance(boolean flag) throws ParserConfigurationException {

		if (documentInstance == null) {
			synchronized (CLASS_NAME) {

				DocumentBuilderFactory dbf = WebServiceClient.getDocumentBuilderFactoryInstance();
				dbf.setNamespaceAware(flag);
				documentInstance = dbf.newDocumentBuilder().newDocument();
			}
		}
		return documentInstance;
	}

	public static Transformer getTransformerInstance() throws TransformerConfigurationException {
		/*
		 * if(instanceTransformerFactory == null){ instanceTransformerFactory =
		 * TransformerFactory.newInstance(); } else {
		 */

		if (instanceTransformer == null) {
			synchronized (CLASS_NAME) {

				instanceTransformer = TransformerFactory.newInstance().newTransformer();
			}
		}
		// }
		return instanceTransformer;
	}

	public static DocumentBuilderFactory getDocumentBuilderFactoryInstance() {
		if (instanceDocumentBuilderFactory == null) {
			synchronized (CLASS_NAME) {
				instanceDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
			}
		}

		return instanceDocumentBuilderFactory;
	}

	public static JAXBContext initContext() {
		FileInputStream fis = null;
		try {
			 
			if (instance == null) {
				/*
				 * Properties jaxbProp = MasterPropertiesFileLoader.
				 * CONSTANT_CONTEXT_WEB_SERVICES_PROPERTIES;
				 */
				synchronized (CLASS_NAME) {
					Properties jaxbProp = null;
					if (jaxbProp == null) {
						jaxbProp = new Properties();
						// jaxbProp.load(new
						// FileInputStream(MasterPropertiesFileLoader.CONSTANT_CACHE_JAXBCONTEXT));
						// jaxbProp.load(new
						// FileInputStream("D:/Rohit Sidana/Eclipse Workspaces/Groups Digi UAT/GroupsIPruConfig/CacheConfig/jaxbInstance.properties"));
						fis=new FileInputStream(GroupConstants.CONSTANT_C + webServiceProperties.getProperty("jaxbInstance"));
						jaxbProp.load(fis);
					}
					instance = JAXBContext.newInstance(jaxbProp.getProperty("GRP_contextPath"));
				}
			}
		}
		catch (JAXBException e) {
			e.printStackTrace();
			FLogger.error("WebServiceLogger", "WebServiceClient", "initContext", "Error occurred while creating JAXBContext Instance", e);
		}
		catch (FileNotFoundException e) {
			FLogger.error("WebServiceLogger", "WebServiceClient", "initContext", "Error occurred while loading Properties file", e);
		}
		catch (IOException e) {
			FLogger.error("WebServiceLogger", "WebServiceClient", "initContext", "Error occurred while loading Properties file", e);
		}
		finally {
			try {
				if(fis!=null)
					fis.close();
			}
			catch (Exception e) {
				FLogger.error("GROUPLoggerError", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
						"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
				e.printStackTrace();
			} finally {
				fis=null;
			}
		}
		return instance;
	}

	private static SOAPMessage getSoapMessageFromString(String xml) throws SOAPException, IOException {
		FLogger.info("WebServiceLogger", "WebServiceClient", "getSoapMessageFromString", "Method Start");
		// Singleton
		MessageFactory factory = WebServiceClient.getMessageFactoryInstance();
		SOAPMessage message = factory.createMessage(new MimeHeaders(), new ByteArrayInputStream(xml.getBytes(Charset.forName("UTF-8"))));
		FLogger.info("WebServiceLogger", "WebServiceClient", "getSoapMessageFromString", "Method End");
		return message;
	}

	public static Object unmarshal(String replyData, WebserviceSource webserviceSource) throws JAXBException, SOAPException, IOException, SAXException, TransformerConfigurationException, TransformerException, TransformerFactoryConfigurationError, ParserConfigurationException {
		FLogger.info("WebServiceLogger", "WebServiceClient", "unmarshal", "Method Start");
		String message = replyData;
		instance = initContext();
		Object replyObj = null;
		Unmarshaller unmarshal = instance.createUnmarshaller();
		InputSource inStream = new InputSource();

		if (StringUtils.isNotBlank(webserviceSource.getWsType()) && StringUtils.equalsIgnoreCase(webserviceSource.getWsType(), "SOAP")) {
			SOAPMessage soapMessage = getSoapMessageFromString(replyData);
			SOAPPart soapPart = soapMessage.getSOAPPart();
			SOAPBody element = soapPart.getEnvelope().getBody();
			DOMSource source = new DOMSource(element.getFirstChild());
			StringWriter stringResult = new StringWriter();
			WebServiceClient.getTransformerInstance().transform(source, new StreamResult(stringResult));
			message = stringResult.toString();
			inStream.setCharacterStream(new StringReader(message));
			replyObj = unmarshal.unmarshal(inStream);
		}
		else {
			unmarshal = instance.createUnmarshaller();
			inStream = new InputSource();
			inStream.setCharacterStream(new StringReader(message));
			replyObj = unmarshal.unmarshal(inStream);
		}

		FLogger.info("WebServiceLogger", "WebServiceClient", "unmarshal", "Method End");
		return replyObj;
	}

	public Object invokeWsUsingHttpClient(Object request, WebserviceSource webserviceSource) throws Exception {
		FLogger.info("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClient", "Method Start");
		getCustomSecurityHeaderValue(webserviceSource);

		Object responseObj = null;
		// Get request
		if (StringUtils.isNotBlank(webserviceSource.getWsType()) && StringUtils.equals(webserviceSource.getMethodType(), "GET")) {
			responseObj = invokeWsUsingHttpClientGET(request, webserviceSource);
		}
		else {
			// Post Request
			responseObj = invokeWsUsingHttpClientPOST(request, webserviceSource);

		}
		FLogger.info("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClient", "Method End");
		return responseObj;
	}

	private static RequestConfig connectionTimeout(WebserviceSource webserviceSource) {
		FLogger.info("WebServiceLogger", "WebServiceClient", "connectionTimeout", "Method Start");
		Integer connTimeout = webserviceSource.getConnTimeOut();
		Integer socketTimeout = webserviceSource.getSocktTimeOut();

		if (connTimeout == null || connTimeout == 0) {
			webServiceProperties.getProperty("connTimeout");
			// connTimeout = 5000;
		}

		if (socketTimeout == null || socketTimeout == 0) {
			webServiceProperties.getProperty("socketTimeout");
			// socketTimeout = 30000;
		}

		RequestConfig params = RequestConfig.custom().setConnectTimeout(connTimeout).setSocketTimeout(socketTimeout).build();

		FLogger.info("WebServiceLogger", "WebServiceClient", "connectionTimeout", "Method End");
		return params;

	}

	private static HttpClientBuilder sslProperty(HttpClientBuilder clientBuilder) throws KeyManagementException, NoSuchAlgorithmException {
		FLogger.info("WebServiceLogger", "WebServiceClient", "sslProperty", "Method Start");
		javax.net.ssl.SSLContext sslcontext = null;
		//sslcontext = SSLContexts.custom().useSSL().build();
		sslcontext= SSLContext.getInstance("TLSv1.2");
		sslcontext.init(null, new X509TrustManager[] { new X509TrustManager() {

			@Override
			public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
			}

			@Override
			public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
			}

			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[] {};
			}
		} }, new SecureRandom());

		clientBuilder.setSSLSocketFactory(new SSLConnectionSocketFactory(sslcontext, SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER));
		clientBuilder.useSystemProperties();
		FLogger.info("WebServiceLogger", "WebServiceClient", "sslProperty", "Method End");
		return clientBuilder;
	}

	public static Object invokeWsUsingHttpClientGET(Object request, WebserviceSource webserviceSource) throws Exception {
		FLogger.info("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientGET", "Method Start");
		StringBuilder responseStr;
		Object responseObj = null;
		Boolean useSSL = webserviceSource.isUseSSL();
		String targetUri = webserviceSource.getUrl();// http://10.50.37.138:9443/digital/FundPerformaceWS
		Boolean useProxy = webserviceSource.isUseProxy();

		HttpClientBuilder clientBuilder = HttpClientBuilder.create();

		RequestConfig params = connectionTimeout(webserviceSource);

		if (useSSL) {

			clientBuilder = sslProperty(clientBuilder);
		}

		if (StringUtils.isNotBlank(targetUri)) {

			if (useProxy) {

				clientBuilder = proxySettings(clientBuilder, webserviceSource);

			}

			URIBuilder uriBuilder = new URIBuilder(webserviceSource.getUrl());

			for (Map.Entry<String, String> entry : webserviceSource.getGetParameters().entrySet()) {
				uriBuilder.setParameter(entry.getKey(), entry.getValue());
			}

			HttpGet getRequest = new HttpGet(uriBuilder.build());
			getRequest.setConfig(params);

			CloseableHttpClient client = clientBuilder.build();
			CloseableHttpResponse response = null;

			try {

				response = invokeWebService(webserviceSource, client, getRequest, null);
					
				if(response != null && response.getStatusLine()!=null){
					if(response.getStatusLine().getStatusCode() == 200){
						String contentTypeHeaderValue = getContentTypeHeaderValue(webserviceSource);
	
						responseStr = fetchResponseString(response);
	
						if (StringUtils.containsIgnoreCase(contentTypeHeaderValue, webServiceProperties.getProperty("XML"))) {
	
							responseObj = unmarshalJSON(responseStr.toString(), webserviceSource);
	
						}
						else if (StringUtils.containsIgnoreCase(contentTypeHeaderValue, webServiceProperties.getProperty("JSON"))) {
	
							responseObj = unmarshal(responseStr.toString(), webserviceSource);
	
						}
						else {
						// Throw Exception
							FLogger.info("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientGET", "Content type header is neither xml nor json");
							throw new WebServiceClientException("Content type header is neither xml nor json");
						}
					}else {
						FLogger.error("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientGET","Response received is null::"+response.getStatusLine().getStatusCode());
						throw new WebServiceClientException("Exception occurred at WebserviceEnd", String.valueOf(response.getStatusLine().getStatusCode()));
					}
				} else {
					FLogger.error("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientGET","Response received is null");
					throw new WebServiceClientException("No Response received from webservice");
				}
				

			}//try
			catch (WebServiceClientException e) {
				handleServiceException(e,webserviceSource);
			}
			catch (ClientProtocolException e) {
				handleServiceException(e,webserviceSource);
			}
			catch (IOException e) {
				handleServiceException(e,webserviceSource);
			}
			catch (Exception e) {
				handleServiceException(e,webserviceSource);
			}
			finally {
				try {
					if (response != null)
						response.close();
					client.close();
				}
				catch (IOException e) {
					handleServiceException(e,webserviceSource);
				}
			}

		}
		else {
			// Add logger
			FLogger.info("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientGET", "TargetUri is Blank/Null/empty");
			throw new WebServiceClientException("TargetUri is Blank/Null/empty");
		}

		FLogger.info("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientGET", "Method End");
		return responseObj;
	}

	// jsonObject to String
	private static String marshalJSON(JsonObject jsonObject, WebserviceSource webserviceSource) {

		if (jsonObject != null) {
			return jsonObject.toString();
		}
		return null;
	}

	// String to Object
	/*private static Object unmarshalJSON(String responseStr, WebserviceSource webserviceSource) {
		if (StringUtils.isNotBlank(responseStr) && JSONUtils.mayBeJSON(responseStr)) {
			if (responseStr.startsWith("[") && responseStr.endsWith("]")) {
				//System.out.println(responseStr.trim());
				//System.out.println(JSONArray.fromObject(responseStr.trim()));
				return JSONArray.fromObject(responseStr.trim());
			}
			return JSONObject.fromObject(responseStr.trim());

		}
		return responseStr;
	}*/
	private static Object unmarshalJSON(String responseStr, WebserviceSource webserviceSource) {
		if (StringUtils.isNotBlank(responseStr) && GroupsJsonUtils.getInstance().isJsonValid(responseStr)) {
			if (responseStr.startsWith("[") && responseStr.endsWith("]")) {
//				return JSONArray.fromObject(responseStr.trim());
				return GroupsJsonUtils.getInstance().getJsonArray(responseStr);
			}
			return GroupsJsonUtils.getInstance().getJsonObject(responseStr);

		}
		return responseStr;
	}

	public static String marshal(Object requestData, Class<?> classType, WebserviceSource webserviceSource) throws JAXBException, SAXException, IOException, ParserConfigurationException, SOAPException, WebServiceClientException {
		FLogger.info("WebServiceLogger", "WebServiceClient", "marshal", "Method Start");
		String payload = null;
		String output = null;
		String securityHeader = "";
		String soapEnvelope = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+ "<soapenv:Header>%s</soapenv:Header><soapenv:Body>%s</soapenv:Body></soapenv:Envelope>";

		instance = initContext();
		StringWriter writer = new StringWriter();
		Marshaller marshaller = instance.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
		marshaller.marshal(requestData, writer);

		Document doc = WebServiceClient.getDocumentInstance(true);

		if (doc != null) {
			payload = writer.toString();
		}
		if (StringUtils.isNotBlank(webserviceSource.getWsType()) && StringUtils.equals(webserviceSource.getWsType(), "SOAP")) {
			if (webserviceSource.isSecured()) {
				if (StringUtils.containsIgnoreCase(webserviceSource.getCustomSecurityHeaderVal(), "INFORMATICA")) {
					securityHeader = builderSecurityHeaderInformatica(webserviceSource);
				}
				else if (StringUtils.containsIgnoreCase(webserviceSource.getCustomSecurityHeaderVal(), "SPAARC")) {
					securityHeader = builderSecurityHeaderSpaarc(webserviceSource);
				}
				else {
					// Throw Exception
					FLogger.info("WebServiceLogger", "WebServiceClient", "marshal", "Exception");
					throw new WebServiceClientException("Webservice Exception");
				}
			}
			output = String.format(soapEnvelope, securityHeader, payload);
		}
		else {
			output = payload;
		}

		FLogger.info("WebServiceLogger", "WebServiceClient", "marshal", "Method End");
		////System.out.println(output);
		return output;

	}

	public static String builderSecurityHeaderInformatica(WebserviceSource webserviceSource) {

		FLogger.info("WebServiceLogger", "WebServiceClient", "builderSecurityHeaderInformatica", "Method End");
		return "<ns0:Security xmlns:ns0=\"http://www.informatica.com/\"><UsernameToken><Username>" + webserviceSource.getUserName() + "</Username><Password>" + webserviceSource.getProperty()
				+ "</Password></UsernameToken></ns0:Security>";
	}

	public static String builderSecurityHeaderSpaarc(WebserviceSource webserviceSource) {

		return "<AuthenticateInfo xmlns=\"http://tempuri.org/\"><UserID>" + webserviceSource.getUserName() + "</UserID><Password>" + webserviceSource.getProperty() + "</Password></AuthenticateInfo>";
	}

	private static ArrayList<NameValuePair> generateRequestHttpEntity(Map<String, String> requestMap) throws Exception {

		FLogger.info("WebServiceLogger", "WebServiceClient", "generateRequestHttpEntity", "Method Start");
		if (MapUtils.isEmpty(requestMap)) {
			throw new WebServiceClientException("ToMobileNumber or message Text is empty");
		}

		ArrayList<NameValuePair> requestBodies = new ArrayList<NameValuePair>();
		for (Entry<String, String> mapEntry : requestMap.entrySet()) {
			if (mapEntry != null) {
				requestBodies.add(new BasicNameValuePair(mapEntry.getKey(), mapEntry.getValue()));
			}
		}
		FLogger.info("WebServiceLogger", "WebServiceClient", "generateRequestHttpEntity", "Method End");
		return requestBodies;
	}

	public static Object invokeWsUsingHttpClientPOST(Object request, WebserviceSource webserviceSource) throws WebServiceClientException,Exception {
		FLogger.info("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientPOST", "Method Start");
		Object responseObj = null;
		String requestStr = null;
		StringBuilder responseStr;
		Boolean useSSL = webserviceSource.isUseSSL();
		String targetUri = webserviceSource.getUrl();
		Boolean useProxy = webserviceSource.isUseProxy();
		HashMap<String, Object> map = null;
		ArrayList<NameValuePair> requestBodies =null;

		String contentTypeHeaderValue = getContentTypeHeaderValue(webserviceSource);
		if (StringUtils.containsIgnoreCase(contentTypeHeaderValue, "XML")) {
			requestStr = marshal(request, request.getClass(), webserviceSource);
			/*requestStr = "<soap:Envelope  xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema'>"
						  +" <soap:Header>"
						    +"  <ns0:Security xmlns:ns0='http://www.informatica.com/'>"
						    	+"    <UsernameToken>"
						          +"  <Username>WS_ineo</Username>"
						         +"   <Password>WS_ineo</Password>"
						       +"  </UsernameToken>"
						   +"   </ns0:Security>"
						  +" </soap:Header>"
						  +" <soap:Body  xmlns:ns0='http://www.informatica.com/wsdl/'> "
						    +"  <ns0:IAXIS_DIGILIFE_VERIFICATIONRequest >"
						      +"   <ns0:IAXIS_DIGILIFE_VERIFICATIONRequestElement>"
						      +"      <ns0:CONTRACT_ID>3966</ns0:CONTRACT_ID>"
						      +"   </ns0:IAXIS_DIGILIFE_VERIFICATIONRequestElement>"
						     +" </ns0:IAXIS_DIGILIFE_VERIFICATIONRequest>"
						  +" </soap:Body>"
						+"</soap:Envelope>";*/

		}
		else if (StringUtils.containsIgnoreCase(contentTypeHeaderValue, "JSON")) {
			if(request==null){
				if(webserviceSource.getGetParameters()!=null){
					requestBodies = generateRequestHttpEntity(webserviceSource.getGetParameters());
				}
				
			}else
			if (request.getClass() == String.class) {
				requestStr = (String) request;
			}
		
			else {
				// Throw Exception
				FLogger.info("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientPOST", "Invalid Class Type");
				throw new WebServiceClientException("Invalid Class Type");
			}
		}
		else if (StringUtils.containsIgnoreCase(contentTypeHeaderValue, "x-www-form-urlencoded")) {
			requestBodies = generateRequestHttpEntity(webserviceSource.getGetParameters());
			
		}

		HttpClientBuilder clientBuilder = HttpClientBuilder.create();

		RequestConfig params = connectionTimeout(webserviceSource);

		if (useSSL) {
			clientBuilder = sslProperty(clientBuilder);
		}

		if (StringUtils.isNotBlank(targetUri)) {

			if (useProxy) {

				clientBuilder = proxySettings(clientBuilder, webserviceSource);
			}
			HttpPost postRequest = new HttpPost(targetUri);
			postRequest.setConfig(params);// timeout

			if (CollectionUtils.isNotEmpty(webserviceSource.getHeaderList())) {
				for (Header header : webserviceSource.getHeaderList()) {
					if (StringUtils.isNotBlank(header.getKey()) && (!StringUtils.equalsIgnoreCase(header.getKey(),CUSTOMHEADER))) {
						postRequest.addHeader(header.getKey(), header.getVal());
					}
				}
			}
			if(StringUtils.isNotBlank(requestStr)) {
				
				postRequest.setEntity(new StringEntity(requestStr));
			} else if (CollectionUtils.isNotEmpty(requestBodies)){
				postRequest.setEntity(new UrlEncodedFormEntity(requestBodies));
			}
			
			
			CloseableHttpClient client = clientBuilder.build();
			CloseableHttpResponse response = null;

			try {

				response = invokeWebService(webserviceSource, client, null, postRequest);
			//	////System.out.println("response:"+response);

				if(response != null && response.getStatusLine()!=null){
					if(response.getStatusLine().getStatusCode() == 200){
						
						responseStr = fetchResponseString(response);
		
						if (StringUtils.containsIgnoreCase(contentTypeHeaderValue, "XML")) {
							responseObj = unmarshal(responseStr.toString(), webserviceSource);
						}
						else if (StringUtils.containsIgnoreCase(contentTypeHeaderValue, "JSON")) {
							responseObj = unmarshalJSON(responseStr.toString(), webserviceSource);
						}else if (StringUtils.containsIgnoreCase(contentTypeHeaderValue, "x-www-form-urlencoded")) {
							responseObj = unmarshalJSON(responseStr.toString(), webserviceSource);
						}
					}else {
						responseStr = fetchResponseString(response);

						FLogger.error("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientGET","Response received is null::"+response.getStatusLine().getStatusCode());
						FLogger.error("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientGET"," Response Obj is :"+responseStr);
						throw new WebServiceClientException("Exception occurred at WebserviceEnd", String.valueOf(response.getStatusLine().getStatusCode()));
					}
				} else {
					FLogger.error("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientGET","Response received is null");
					throw new WebServiceClientException("No Response received from webservice");
				}


			}
			catch (WebServiceClientException e) {
				handleServiceException(e,webserviceSource);
			}

			catch (ClientProtocolException e) {
				handleServiceException(e,webserviceSource);
			}
			catch (IOException e) {
				handleServiceException(e,webserviceSource);
			}
			catch (Exception e) {
				handleServiceException(e,webserviceSource);
			}
			finally {
				try {
					if (response != null)
						response.close();
					client.close();
				}
				catch (IOException e) {
					handleServiceException(e,webserviceSource);
				}
			}

		}
		else {
			FLogger.info("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientPOST", "TargetUri is Blank/Null/empty");
			throw new WebServiceClientException("TargetUri is Blank/Null/empty");
		}

		FLogger.info("WebServiceLogger", "WebServiceClient", "invokeWsUsingHttpClientPOST", "Method end");
		return responseObj;
	}

	private static HttpClientBuilder proxySettings(HttpClientBuilder clientBuilder, WebserviceSource webserviceSource) {
		FLogger.info("WebServiceLogger", "WebServiceClient", "proxySettings", "Method Start");
		String proxyHost = webserviceSource.getProxy().getProxyHost();
		String proxyPort = webserviceSource.getProxy().getProxyPort();
		HttpHost proxy = new HttpHost(proxyHost, Integer.parseInt(proxyPort));
		clientBuilder.setProxy(proxy);
		clientBuilder.setProxyAuthenticationStrategy(new ProxyAuthenticationStrategy());
		// NTLM authentication when running the application local
		String proxyEnv = webserviceSource.getProxy().getNtlm();

		if (StringUtils.isNotBlank(proxyEnv) && StringUtils.equalsIgnoreCase(proxyEnv, "Y")) {
			String win_username = webserviceSource.getProxy().getProxyUName();
			String win_password = webserviceSource.getProxy().getProxyProperty();
			String win_full_computer_name = webserviceSource.getProxy().getWinFullCompName();
			String win_domain = webserviceSource.getProxy().getWinDomin();
			Credentials cred = new NTCredentials(win_username, win_password, win_full_computer_name, win_domain);
			CredentialsProvider credsProvider = new BasicCredentialsProvider();
			credsProvider.setCredentials(new AuthScope(proxyHost, Integer.parseInt(proxyPort)), cred);
			clientBuilder.setDefaultCredentialsProvider(credsProvider);
		}
		FLogger.info("WebServiceLogger", "WebServiceClient", "proxySettings", "Method End");
		return clientBuilder;

	}

	private static void handleServiceException(Exception e, WebserviceSource source) throws WebServiceClientException {
		FLogger.error("WebServiceLogger", "WebServiceClient", "handleServiceException", "Some error occurred while calling the webservice:: "+source.getUrl(), e);
		if(e instanceof WebServiceClientException){
			if(e!=null && ( StringUtils.isNotBlank(e.getMessage()) ) &&  ( StringUtils.isNotBlank(((WebServiceClientException) e).getStatusCode()))){
					handleServiceException(e, source, ((WebServiceClientException) e).getStatusCode());
			} 			
			
		}else {
			if(StringUtils.isNotBlank(e.getMessage())){
				throw new WebServiceClientException(e.getMessage());
			}else {
				throw new WebServiceClientException(e);
			}
		}
		
	}
	
	private static void handleServiceException(Exception e, WebserviceSource source, String statuscode) throws WebServiceClientException {
		if(StringUtils.isBlank(statuscode)){
			handleServiceException(e, source);
			return;
		}
		String EXCEPTION_MESSAGE = null;
		switch (statuscode) {
			case "500":
				EXCEPTION_MESSAGE = "Exception occurred at webservice end";
				FLogger.error("WebServiceLogger", "WebServiceClient", "handleServiceException", EXCEPTION_MESSAGE+"::"+statuscode+"::"+source.getUrl(), e);
				break;
			case "404":
				EXCEPTION_MESSAGE = "Webservice is down";
				FLogger.error("WebServiceLogger", "WebServiceClient", "handleServiceException", EXCEPTION_MESSAGE+"::"+statuscode+"::"+source.getUrl(), e);
				break;
			default:
				EXCEPTION_MESSAGE="Some exception occurred at webservice end";
				FLogger.error("WebServiceLogger", "WebServiceClient", "handleServiceException", EXCEPTION_MESSAGE+":: Status Code ::: "+statuscode + "::" +source.getUrl(), e);
				break;
				
		}
		throw new WebServiceClientException(EXCEPTION_MESSAGE);
		// e.printStackTrace();
	}

	private static String getContentTypeHeaderValue(WebserviceSource source) {
		FLogger.info("WebServiceLogger", "WebServiceClient", "getContentTypeHeaderValue", "Method Start");

		String headerValue = null;
		if (CollectionUtils.isNotEmpty(source.getHeaderList())) {
			for (Header header : source.getHeaderList()) {
				if (header != null && (StringUtils.equalsIgnoreCase(header.getKey(), "Content-Type")||StringUtils.equalsIgnoreCase(header.getKey(), "Accept"))) {
					headerValue = header.getVal();
				}
			}
		}
		FLogger.info("WebServiceLogger", "WebServiceClient", "getContentTypeHeaderValue", "Method End");

		return headerValue;

	}

	private static void getCustomSecurityHeaderValue(WebserviceSource source) {
		FLogger.info("WebServiceLogger", "WebServiceClient", "getCustomSecurityHeaderValue", "Method Start");
		String customSecHeaderValue = null;
		if (CollectionUtils.isNotEmpty(source.getHeaderList())) {
			Iterator<Header> itr = source.getHeaderList().iterator();
			while (itr.hasNext()) {
				Header header = itr.next();
				if (header != null && StringUtils.equalsIgnoreCase(header.getKey(), "XXXCustomSecurityHeader")) {
					customSecHeaderValue = header.getVal();
					//itr.remove();
					source.setCustomSecurityHeaderVal(customSecHeaderValue);
					break;
				}
			}
		}
		FLogger.info("WebServiceLogger", "WebServiceClient", "getCustomSecurityHeaderValue", "Method End");
	}

	
	private static CloseableHttpResponse invokeWebService(WebserviceSource webserviceSource, CloseableHttpClient client, HttpGet getRequest, HttpPost postRequest) throws ClientProtocolException, IOException {
		FLogger.info("WebServiceLogger", "WebServiceClient","invokeWebService", "Method Start");
		CloseableHttpResponse response = null;
		
		String 	schemeName =null;
		if(postRequest != null && (webserviceSource==null || webserviceSource.getHostname()==null || !webserviceSource.getHostname().contains("https:"))){
			schemeName=postRequest.getURI().getScheme();
		}
		if(getRequest != null && (webserviceSource==null || webserviceSource.getHostname()==null || !webserviceSource.getHostname().contains("https:"))){
			schemeName=getRequest.getURI().getScheme();
		}
		HttpHost target = null;
		
		if(schemeName!=null)
		{
			target = new HttpHost(webserviceSource.getHostname(), webserviceSource.getPort(),schemeName);
		}
		else
		{
			target = new HttpHost(webserviceSource.getHostname(), webserviceSource.getPort());
		}
		
		
		//HttpHost target = new HttpHost(webserviceSource.getHostname(), webserviceSource.getPort());
		long startTime = System.currentTimeMillis();
		if (getRequest != null) {
			response = client.execute(target, getRequest);
		}
		else if (postRequest != null) {
			response = client.execute(target, postRequest);
		}
		FLogger.info("WebServiceLogger", "WebServiceClient","invokeWebService", "Method End");
		return response;
}

	private static StringBuilder fetchResponseString(CloseableHttpResponse response) throws ClientProtocolException, IOException {
		FLogger.info("WebServiceLogger", "WebServiceClient", "fetchResponseString", "Method Start");
		BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

		StringBuilder responseStr = new StringBuilder();
		String line = "";
		while ((line = br.readLine()) != null) {
			responseStr.append(line);
		}
		FLogger.info("WebServiceLogger", "WebServiceClient", "fetchResponseString", "Method End");
		return responseStr;
	}

	/*public static Object invokeGenericRestClient(Map<String, Object> requestMap) {
		//String method = "invokeGenericRestClient";
		//FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"method starts");
		String response = null;
		String clickPSSResponseUrl = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			String uri = (String) requestMap.get("requestUrl");//http://10.51.0.72:9090/CRMWS/resources/tokenWS/getTokenWithEncryptedData
			String strDataJson = ((ClickPSSWebService) requestMap.get("classObj")).toRawPayload();//policyNo=24208A141BDDF0580C7728E9D8E0F8A5&customerId=338B10D0F8A781C70C7728E9D8E0F8A5&toDate=&fromDate=&templateId=B6474B0EF6139F81
			
			headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
			RestTemplate restTemplate = new RestTemplate();
			////System.out.println("Json ---"+ strDataJson);
//			FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"ClickPSS request string  "+ strDataJson);
			HttpEntity<String> requestEntity = new HttpEntity<String>(strDataJson, headers);
			
			////System.out.println("entity1 ---" + requestEntity);
			response = restTemplate.postForObject(uri, requestEntity,String.class);
			String[] responseArray = response.split("url : ");
			if(responseArray.length > 1)
				clickPSSResponseUrl = responseArray[1];
			//System.out.println(clickPSSResponseUrl);
//			FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"ClickPSS redirection URL "+ clickPSSResponseUrl);
		} catch (Exception e) {
			e.printStackTrace();
//			FLogger.error("CSR.PolicyStatements", "ClickPSSWebService", method,"Exception occured " + e.getMessage());
		}
//		FLogger.info("CSR.PolicyStatements", "ClickPSSWebService", method,"method ends");
		return clickPSSResponseUrl;

	}
*/
	public static Object invokeWsUsingHttpClient1(List<WebserviceSource> webList,Object request) throws Exception {
        FLogger.info("WebServiceLogger", "CsrWebServiceClient","invokeWsUsingHttpClient", "Method Start");
        Object responseObj = null;


        if (CollectionUtils.isNotEmpty(webList)) {
            for (WebserviceSource source : webList) {
                if (source !=null) {
                    responseObj = WebServiceClient.invokeWsUsingHttpClient1(request,source);
                }
            }
        }

        return responseObj;
    } 
	
	public static Object invokeWsUsingHttpClient1(Object request, WebserviceSource webserviceSource) throws Exception {
        FLogger.info("WebServiceLogger", "CsrWebServiceClient","invokeWsUsingHttpClient", "Method Start");
        getCustomSecurityHeaderValue(webserviceSource);


        Object responseObj = null;
        // Get request
        if (StringUtils.isNotBlank(webserviceSource.getWsType()) && StringUtils.equals(webserviceSource.getMethodType(), "GET")) {
            responseObj = invokeWsUsingHttpClientGET(request, webserviceSource);
        }
        else {
            // Post Request
            responseObj = invokeWsUsingHttpClientPOST(request, webserviceSource);

        }
        FLogger.info("WebServiceLogger", "CsrWebServiceClient","invokeWsUsingHttpClient", "Method End");
        return responseObj;
    }
}
