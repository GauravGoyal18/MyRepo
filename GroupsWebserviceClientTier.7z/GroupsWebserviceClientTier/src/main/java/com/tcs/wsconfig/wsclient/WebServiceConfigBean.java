package com.tcs.wsconfig.wsclient;

import java.io.Serializable;

public class WebServiceConfigBean implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Boolean isSoapMsgFrmtReqd = Boolean.TRUE;
	private Boolean isSoapWSSecured = Boolean.TRUE;
	private Boolean useProxy = Boolean.FALSE;
	private Boolean useSSL = Boolean.FALSE;
	
	public Boolean getIsSoapMsgFrmtReqd() {
		return isSoapMsgFrmtReqd;
	}
	public void setIsSoapMsgFrmtReqd(Boolean isSoapMsgFrmtReqd) {
		this.isSoapMsgFrmtReqd = isSoapMsgFrmtReqd;
	}
	public Boolean getIsSoapWSSecured() {
		return isSoapWSSecured;
	}
	public void setIsSoapWSSecured(Boolean isSoapWSSecured) {
		this.isSoapWSSecured = isSoapWSSecured;
	}
	public Boolean getUseProxy() {
		return useProxy;
	}
	public void setUseProxy(Boolean useProxy) {
		this.useProxy = useProxy;
	}
	public Boolean getUseSSL() {
		return useSSL;
	}
	public void setUseSSL(Boolean useSSL) {
		this.useSSL = useSSL;
	}
	
	
	
	 
	 
}
