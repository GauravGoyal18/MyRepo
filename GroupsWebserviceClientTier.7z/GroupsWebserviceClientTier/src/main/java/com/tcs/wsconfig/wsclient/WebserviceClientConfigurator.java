package com.tcs.wsconfig.wsclient;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.estatement.ClickPSSWebService;
import com.estatement.SecurePassword;
import com.google.gson.Gson;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.GroupsJsonUtils;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.beans.ParamObj;
import com.tcs.beans.PrePopulateBean;
import com.tcs.beans.SwitchToRequest;
import com.tcs.configuration.Environment;
import com.tcs.exception.WebServiceClientException;
import com.tcs.logger.FLogger;
import com.tcs.wsconfig.generated.Endpoint;
import com.tcs.wsconfig.generated.EndpointSource;
import com.tcs.wsconfig.generated.Proxy;
import com.tcs.wsconfig.generated.Target;
import com.tcs.wsconfig.generated.WebServiceConfig;

// import com.tcs.wsconfig.generated.WebServiceConfig;

public final class WebserviceClientConfigurator {

	
	//public static final String CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH = "D:\\Kashmira\\Workspace\\Groups\\GroupsUAT10Nov2016\\GroupsIPruConfig\\WebserviceClient\\wsconfig.xml";
	//public static final String CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH = MasterPropertiesFileLoader.CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH;
	//private static Properties webServiceProperties = new Properties();
	
	private static WebserviceClientConfigurator instanceWebserviceClientConfigurator; 
	
	public static synchronized WebserviceClientConfigurator getInstance(){
        if(instanceWebserviceClientConfigurator == null){
        	
        	instanceWebserviceClientConfigurator = new WebserviceClientConfigurator();
        }
        
        return instanceWebserviceClientConfigurator;
    }
	
	
	
	private static JAXBContext instance;
	
/*	static{
	
		if (MasterPropertiesFileLoader.CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH != null) {
			webServiceProperties = MasterPropertiesFileLoader.CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH;
		}
		else {
			try {
				
				webServiceProperties.load(new FileInputStream(GroupConstants.CONSTANT_WEBSERVICE));
				
//				webServiceProperties.load(new FileInputStream("D:/maven_workspace/groups/local-uat/GroupsIPruConfig/WebserviceClient/webserviceclient.properties"));
			}
			catch (FileNotFoundException e) {
				FLogger.error("WebServiceLogger", "CsrWebServiceClient", "CsrWebServiceClient", e.getMessage(), e);
			}
			catch (IOException e) {
				FLogger.error("WebServiceLogger", "CsrWebServiceClient", "CsrWebServiceClient", e.getMessage(), e);
			}
		}	
	}*/

	public WebserviceClientConfigurator() {
		super();

	}

	public static JAXBContext initContext() {
		try {
			if (instance == null) {
				synchronized (Environment.HELPER) {
					instance = JAXBContext.newInstance("com.tcs.wsconfig.generated");
				}
			}
		}
		catch (JAXBException e) {
			FLogger.error("WebServiceLogger", "CsrWebServiceClient", "initContext", "Error occurred while creating JAXBContext Instance", e);
		}
		return instance;
	}

	public static Map<String, Object> generateWsConfigMap(WebServiceConfig config) throws WebServiceClientException,Exception {
		FLogger.info("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Entered method");
		if (config == null) {
			FLogger.error("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Input config is null");
			throw new WebServiceClientException("Input config is null");
		}
		if (config.getEndpoints() == null) {
			FLogger.error("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Endpoints Not found in config");
			throw new WebServiceClientException("Endpoints Not found in config");
		}

		List<Proxy> proxyList = config.getProxyConfigurations().getProxy();

		List<Endpoint> endpoints = config.getEndpoints().getEndpoint();
		if (endpoints == null || endpoints.isEmpty()) {
			FLogger.error("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Endpoints List Not found in Endpoint object");
			throw new WebServiceClientException("Endpoints List Not found in Endpoint object");
		}
		Map<String, Object> wsConfigMap = new HashMap<String, Object>(0);
		for (Endpoint endpoint : endpoints) {
			if (endpoint != null) {
				List<EndpointSource> sources = endpoint.getEndpointSource();
				if (sources == null || sources.isEmpty()) {
					FLogger.error("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Sources List not found");
					throw new WebServiceClientException("Sources List not found");
				}
				List<WebserviceSource> wsSources = new ArrayList<WebserviceSource>(0);
				for (EndpointSource endpointSource : sources) {
					if (endpointSource != null && StringUtils.equalsIgnoreCase("Y", endpointSource.getIsActive())) {
						Target target = endpointSource.getTarget();
						if (target == null) {
							FLogger.error("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Target not found in source. Target for source is required");
							throw new WebServiceClientException("Target not found in source. Target for source is required");
						}
						WebserviceSource wsSource = new WebserviceSource();
						if (StringUtils.isNotBlank(endpointSource.getWsName())) {//FundPerformaceWS
							wsSource.setUrl(target.getUrl() + "/" + endpointSource.getWsName());
						}
						else {
							wsSource.setUrl(target.getUrl());
						}

						wsSource.setHostname(target.getHostname());
						wsSource.setPort(target.getPort());
						wsSource.setSecured("Y".equalsIgnoreCase(target.getIsSecured()) ? true : false);
						wsSource.setWsType(target.getWsType());

						if (endpointSource.getHeaders() != null && CollectionUtils.isNotEmpty(endpointSource.getHeaders().getHeader())) {
							wsSource.setHeaderList(endpointSource.getHeaders().getHeader());
						}
						else if (endpointSource.getTarget().getHeaders() != null && CollectionUtils.isNotEmpty(endpointSource.getTarget().getHeaders().getHeader())) {
							wsSource.setHeaderList(endpointSource.getTarget().getHeaders().getHeader());
						}
						else {
							wsSource.setHeaderList(null);
						}

						if (StringUtils.isNotEmpty(endpointSource.getTarget().getUsessl())) {
							if (StringUtils.equalsIgnoreCase("Y", endpointSource.getTarget().getUsessl())) {
								wsSource.setUseSSL(true);
							}
							else {
								wsSource.setUseSSL(false);
							}
						}
						else {
							wsSource.setUseSSL(false);
						}

						if (StringUtils.isNotEmpty(endpointSource.getMethodType())) {
							wsSource.setMethodType(endpointSource.getMethodType());
						}
						else {
							wsSource.setMethodType("POST");
						}

						if (endpointSource.getConxnTo() != null && endpointSource.getConxnTo() != 0) {
							wsSource.setConnTimeOut(endpointSource.getConxnTo());
						}
						else {
							wsSource.setConnTimeOut(config.getDefaultConfigurations().getDefaults().getDefault().get(0).getVal());
						}
						if (endpointSource.getSockTo() != null && endpointSource.getSockTo() != 0) {
							wsSource.setSocktTimeOut(endpointSource.getSockTo());
						}
						else {
							wsSource.setSocktTimeOut(config.getDefaultConfigurations().getDefaults().getDefault().get(1).getVal());
						}

						if (endpointSource.getTarget().getProxy() != null) {
							ClientProxy proxy = new ClientProxy();
							if (StringUtils.isNotEmpty(endpointSource.getTarget().getProxy().getNtlm()))
								proxy.setNtlm(endpointSource.getTarget().getProxy().getNtlm());

							if (StringUtils.isNotEmpty(endpointSource.getTarget().getProxy().getProxyHost()))
								proxy.setProxyHost(endpointSource.getTarget().getProxy().getProxyHost());

							proxy.setProxyPort("" + endpointSource.getTarget().getProxy().getProxyPort());

							if (StringUtils.isNotEmpty(endpointSource.getTarget().getProxy().getProxyProperty()))
								proxy.setProxyProperty(endpointSource.getTarget().getProxy().getProxyProperty());

							if (StringUtils.isNotEmpty(endpointSource.getTarget().getProxy().getProxyUName()))
								proxy.setProxyUName(endpointSource.getTarget().getProxy().getProxyUName());

							if (StringUtils.isNotEmpty(endpointSource.getTarget().getProxy().getWinDomain()))
								proxy.setWinDomin(endpointSource.getTarget().getProxy().getWinDomain());

							if (StringUtils.isNotEmpty(endpointSource.getTarget().getProxy().getWinFullCompName()))
								proxy.setWinFullCompName(endpointSource.getTarget().getProxy().getWinFullCompName());

							wsSource.setProxy(proxy);
							wsSource.setUseProxy(true);
						}

						if (wsSource.isSecured()) {
							wsSource.setUserName(target.getUserName());
							wsSource.setProperty(target.getProperty());
						}
						wsSource.setPriority(endpointSource.getPriority());
						wsSource.setWsName(endpointSource.getWsName());
						wsSources.add(wsSource);
					}
				}
				if (wsSources.isEmpty()) {
					FLogger.error("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Webservicesource list found empty");
					throw new WebServiceClientException("Webservicesource list found empty");
				}
				FLogger.info("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Sorting sources wrt priority asc.");
				Collections.sort(wsSources);
				wsConfigMap.put(endpoint.getId(), new ArrayList<WebserviceSource>(wsSources));
				wsSources = null; // Making ready for cleanup.
			}

		}
		if (wsConfigMap.isEmpty()) {
			FLogger.error("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "WsConfigMap found empty");
			throw new WebServiceClientException("WsConfigMap found empty");
		}
		FLogger.info("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Exited method");
		return wsConfigMap;
	}

	/**
	 * Use this method in Admin Panel and MasterDataLoader
	 * 
	 * @throws Exception
	 */
	public static void reloadWsConfig() throws Exception {
		FLogger.info("WebServiceLogger", "WebserviceClientConfigurator", "reloadWsConfig", "Start method");
		//fetch JaxB instance
		initContext();
		FileInputStream fis = null;
		try {
			 // unmarshaller obj to convert xml data to java content tree
			Unmarshaller unmarshal = instance.createUnmarshaller();
			
			fis = new FileInputStream((String)GroupConstants.CONSTANT_C + Environment.HELPER.getWsClientXmlFile("webserviceconfigpath_"+GroupConstants.CONSTANT_ENVIRONMENT));
			//fis = new FileInputStream((String) GroupConstants.CONSTANT_C + webServiceProperties.get("webserviceconfigpath"));//wsconfig.xml
		//	fis = new FileInputStream("D:/maven_workspace/groups/local-uat/GroupsIPruConfig/WebserviceClient/wsconfig.xml");//wsconfig.xml
			
			// unmarshaller xml data to java content tree
			WebServiceConfig config = (WebServiceConfig) unmarshal.unmarshal(fis);
			
			Map<String, Object> wsConfigMap = WebserviceClientConfigurator.generateWsConfigMap(config);
			CacheConfigurator.reloadWsConfigCache(wsConfigMap);
			FLogger.info("WebServiceLogger", "WebserviceClientConfigurator", "reloadWsConfig", "Exited method");
		}
		catch (JAXBException e) {
			FLogger.error("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Unmarshalling error");
			throw e;
		}
		catch (FileNotFoundException e) {
			FLogger.error("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "File Not Found");
			throw e;
		}
		catch (Exception e) {
			FLogger.error("WebServiceLogger", "WebserviceClientConfigurator", "generateWsConfigMap", "Exception occurred");
			throw e;
		}
		finally {
			if (fis != null) {
				try {
					fis.close();
				}
				catch (IOException e) {
					FLogger.error("WebServiceLogger", "CacheConfigurator", "getCacheManagerInstance", "Error occurred while closing stream", e);
				}
			}
		}

	}

/*	public static void main1(String[] args) throws Exception {
		reloadWsConfig();


		CONTRACTDETAILSNEWRequestType contractDetailsRequest = new CONTRACTDETAILSNEWRequestType();
		CONTRACTDETAILSNEWRequestElement contractDetailsReqElement = new CONTRACTDETAILSNEWRequestElement();
		contractDetailsReqElement.setINPUTKEY("00068202");
		contractDetailsReqElement.setINQUIRYLEVEL("1");
		contractDetailsRequest
				.setCONTRACTDETAILSNEWRequestElement(contractDetailsReqElement);

		WebServiceConfigBean configBean = new WebServiceConfigBean();
		JAXBElement<CONTRACTDETAILSNEWResponseType> responseObj = null;
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("FUNDPERFORMANCE");
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					//System.out.println(ToStringBuilder
							.reflectionToString(webserviceSource));

					responseObj = (JAXBElement<CONTRACTDETAILSNEWResponseType>) CsrWebServiceClient
							.invokeWsUsingHttpClient(contractDetailsRequest,
									webserviceSource);

					////System.out.println("Response :"
							+ responseObj.getValue()
									.getCONTRACTDETAILSNEWResponseElement()
									.get(0).getAPPLICATIONKEY());

				}
			}
		}
		////System.out.println("done");
	}*/
	
	
	 /* public static void main(String[] args) throws Exception 
	  {
		  
		   reloadWsConfig();
		    List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("NSEAndProductDetails");
			//List<String> paramList=new ArrayList<String>();
			//ParamObj paramObj = new ParamObj();
		   // paramObj.setParam(paramList);
		    Object output = null;
		    PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality("nscHolidays");
			//prePopulateBean.setParamObj(paramObj);
		    
		    Gson gson = new Gson();
	        String s = gson.toJson(prePopulateBean);
	        
	        //Object object = unmarshalJSON(s);
			
			if (CollectionUtils.isNotEmpty(list)) {
				for (WebserviceSource webserviceSource : list) {
					if (webserviceSource != null) {
						
						//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
						output = (Object)CsrWebServiceClient.invokeWsUsingHttpClient(s,webserviceSource);
					////System.out.println("Response  :"+output.toString());
					}
				}
			}
			
			Gson gson1 = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
			list = gson1.fromJson(output.toString(), new TypeToken<List<NSEHolidaysVO>>() {
			}.getType());
			////System.out.println("done");
	}*/
	
	
	  /*public static void main(String[] args) throws Exception 
	  {
		  //working FUNDPERFORMANCE GET
		  FLogger.info("WebServiceLogger", "WebserviceClientConfigurator", "main", "Method start");
		  ////System.out.println("GEETTTTTTTTTT");
	    reloadWsConfig();
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("FUNDPERFORMANCE");
		Map map = new HashMap<String, String>();
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					map.put("fundCodes", "MMAF,PDPE");
					
					webserviceSource.setGetParameters(map);
					//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
				Object output = (Object)WebServiceClient.getInstance().invokeWsUsingHttpClient(null,webserviceSource);
				//System.out.println(output);
				////System.out.println("Response123  :"+output);
				}
			}
		}
		////System.out.println("done");
	}*/
	
	  /*public static void main(String[] args) throws Exception 
	  {
		//FundNav Working
		////System.out.println("POOOSSSTTTT");
	    reloadWsConfig();
	    List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("GroupsServices");
		List<String> paramList=new ArrayList<String>();

		paramList.add("00000348");//policynumber
		paramList.add("ME11443");//client
		
		
		
		paramList.add("00002285");//policynumber
		paramList.add("22539298");//client
		
		
		ParamObj paramObj=new ParamObj();
	    paramObj.setParam(paramList);
		 
		SwitchToRequest switchToRequest=new SwitchToRequest();
	    switchToRequest.setParamObj(paramObj);
	    
	    Gson gson = new Gson();
        String s = gson.toJson(switchToRequest);
        
        //json String to java object
        //SwitchToRequest switchToRequestJsonObject = gson.fromJson(s, SwitchToRequest.class);
        //Object switchToRequestJsonObject = unmarshalJSON(s);

		
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					
					//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
					//Object output = (Object)CsrWebServiceClient.invokeWsUsingHttpClient(s,webserviceSource);
					Object output = (Object)WebServiceClient.getInstance().invokeWsUsingHttpClient(s,webserviceSource);
				////System.out.println("Response 123 :"+output);
				}
			}
		}
		////System.out.println("done");
	}*/
	
	public static void main(String[] args) throws Exception 
	  {
		  //ProductDetails Working
		Object output = null;
	    reloadWsConfig();
	    List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("NSEAndProductDetails");
		Map map = new HashMap<String, String>();
		List<String> paramList=new ArrayList<String>();

		paramList.add("00000348");//policynumber
		 
		ParamObj paramObj=new ParamObj();
	    paramObj.setParam(paramList);
		 
		PrePopulateBean prePopulateBean=new PrePopulateBean();
    	prePopulateBean.setFunctionality("switchProductCode");
    	prePopulateBean.setParamObj(paramObj);
	    
	    Gson gson = new Gson();
      String s = gson.toJson(prePopulateBean);
      
      //json String to java object
      //SwitchToRequest switchToRequestJsonObject = gson.fromJson(s, SwitchToRequest.class);
     // Object switchToRequestJsonObject = unmarshalJSON(s);

		
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					
					//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
					//Object output = (Object)CsrWebServiceClient.invokeWsUsingHttpClient(s,webserviceSource);
					output = (Object)WebServiceClient.getInstance().invokeWsUsingHttpClient(s,webserviceSource);
				////System.out.println("Response  :"+output);
				}
			}
		}
		////System.out.println("done");
		
		//List<ProductDetailsVO> productDetailsVOList=gson.fromJson(output.toString(), new TypeToken<List<ProductDetailsVO>>(){}.getType());
	}
	
	
/*	public static void main(String[] args) throws Exception 
	  {  //Prefund working
	    reloadWsConfig();
	    Object output = null;
	    List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("PreFundDetails");
		List<String> paramList=new ArrayList<String>();
		Set<String> fundCodes =new HashSet<String>();
		fundCodes.add("DBT");
		fundCodes.add("BLN");
		
		paramList.add("00000348");//policynumber
		paramList.add("ME11443");//client
		 
		ParamObj paramObj=new ParamObj();
	    paramObj.setParam(paramList);
		 
		SwitchToRequest switchToRequest=new SwitchToRequest();
	    switchToRequest.setParamObj(paramObj);
	    switchToRequest.setFundCodes(fundCodes);
	    
	    Gson gson = new Gson();
        String s = gson.toJson(switchToRequest);
        
        //json String to java object
        //SwitchToRequest switchToRequestJsonObject = gson.fromJson(s, SwitchToRequest.class);
        //Object switchToRequestJsonObject = unmarshalJSON(s);

		
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					
					//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
					//Object output = (Object)CsrWebServiceClient.invokeWsUsingHttpClient(s,webserviceSource);
					 output = (Object)CsrWebServiceClient.getInstance().invokeWsUsingHttpClient(s,webserviceSource);
					 ////System.out.println("\nResponse  :"+output);
				}
			}
		}
		////System.out.println("done");
		List<SwitchPreFundDetailsVO> switchPreFundDetailsVOList= new ArrayList<SwitchPreFundDetailsVO>();
		Gson gson1 = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		try{
		if(output!=null )
		{	
			String s1 = output.toString();
			//s1 = s1.replace("[", "");
			//s1 = s1.replace("]", "");
			switchPreFundDetailsVOList = gson1.fromJson(s1, new TypeToken<List<SwitchPreFundDetailsVO>>(){}.getType());
		}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}*/
	  
	private static Object unmarshalJSON(String responseStr) {
		if (StringUtils.isNotBlank(responseStr) && GroupsJsonUtils.getInstance().isJsonValid(responseStr)) {
			if (responseStr.startsWith("[") && responseStr.endsWith("]")) {
//				return JSONArray.fromObject(responseStr.trim());
				return GroupsJsonUtils.getInstance().getJsonArray(responseStr);
			}
			return GroupsJsonUtils.getInstance().getJsonObject(responseStr);

		}
		return responseStr;
	}
		
		/*
		public static void main(String[] args) throws Exception{
			 reloadWsConfig();
			
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForMemberDataCount", "Method start");
			////System.out.println("invokePrePopulateDetailsForMemberDataCount callledddd");


			List<String> paramList = new ArrayList();
			paramList.add("00002285");
			paramList.add("0");
			
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality("memberList");
			
			prePopulateBean.setParamObj(paramObj);
			////System.out.println(" Prepop bean :"+prePopulateBean.toString());

			String requestString =new Gson().toJson(prePopulateBean);
			////System.out.println("requestString requestString requestString requestString requestString :"+requestString);
			Object output=null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.prePopulateCount.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {
						////System.out.println("webserviceSource is not null ");
						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
						////System.out.println(" OUTPUT IS :"+output);
					}
				}
			}
			
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForMemberData", "Method end");


			//System.out.println(output.toString());	

		}*/
		
		
		
		

		
		/*public static void main(String[] args) throws Exception {
			  //  //BID  Working new
		    reloadWsConfig();
		    PortalBIDUnitwiseResponse output = null;
		    List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("bidEstatement");
			
		    String[] format = new String[]{"dd/MM/yyyy"};
		    Calendar fromCal = Calendar.getInstance();
		    fromCal.setTime(DateUtils.parseDate("01/04/2016", format));
		    
		    Calendar toCal = Calendar.getInstance();
		    toCal.setTime(DateUtils.parseDate("31/03/2017", format));
			
		    

			GregorianCalendar fromGregCal = new GregorianCalendar(fromCal.get(Calendar.YEAR), fromCal.get(Calendar.MONTH), fromCal.get(Calendar.DAY_OF_MONTH));
			XMLGregorianCalendar fromGregXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(fromGregCal);
			
			GregorianCalendar toGregCal = new GregorianCalendar(toCal.get(Calendar.YEAR), toCal.get(Calendar.MONTH), toCal.get(Calendar.DAY_OF_MONTH));
			XMLGregorianCalendar toGregXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(toGregCal);
			
			//for (int j=0;j<=5;j++){
			SecureRandom sr = new SecureRandom();
			String i = String.valueOf(Math.abs(sr.nextInt()/10000));
			//System.out.println(i);
		    ObjectFactory factory = new ObjectFactory();
	        
		    PortalBIDUnitwise abc = factory.createPortalBIDUnitwise();
//		    abc.setPolicyKey(new BigDecimal("00002468"));
		    abc.setPolicyKey(new BigDecimal("5329"));
		    abc.setUnitCode(factory.createPortalBIDUnitwiseUnitCode("1"));
		    abc.setStartDt(fromGregXmlCal);
		    abc.setEndDt(toGregXmlCal);
		    abc.setRequestId(factory.createPortalBIDUnitwiseRequestId(i));
		    abc.setUserID(factory.createPortalBIDUnitwiseUserID("test"));
		    
			
			if (CollectionUtils.isNotEmpty(list)) {
				for (WebserviceSource webserviceSource : list) {
					if (webserviceSource != null) {
						
						//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
						 output = (PortalBIDUnitwiseResponse)WebServiceClient.getInstance().invokeWsUsingHttpClient(abc,webserviceSource);
						 ////System.out.println("\nResponse  :"+output);
						 
						// List<BID> bidList = output.getPortalBIDUnitwiseResult().getValue().getBidAsOnDate().getValue().getBID();
						 List<BIDLine> bidLineList = output.getPortalBIDUnitwiseResult().getValue().getBIDLine();
						 int k=0;
						 for(BIDLine bidLine :bidLineList){
							 //System.out.println(++k);
							 //System.out.println(bidLine.getAmountCr().getName() + ":" + bidLine.getAmountCr().getValue());
							 //System.out.println(bidLine.getAmountDr().getName() + ":" + bidLine.getAmountDr().getValue());
							 //System.out.println(bidLine.getBalance().getName() + ":" + bidLine.getBalance().getValue());
							 //System.out.println(bidLine.getDate().getName() + ":" + bidLine.getDate().getValue());
							 //System.out.println(bidLine.getModeOfPayment().getName() + ":" + bidLine.getModeOfPayment().getValue());
							 //System.out.println(bidLine.getParticulars().getName() + ":" + bidLine.getParticulars().getValue());
							 
						 }
					}
				}
			}
			////System.out.println("done");
			
		
		//}
		}*/
		/*public static void main(String[] args) throws Exception {
			  //BID Not Working
		    reloadWsConfig();
		    Object output = null;
		    List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("bidSummary");
			
		    
		   
		    String[] format = new String[]{"dd/MM/yyyy"};
		    Calendar fromCal = Calendar.getInstance();
		    fromCal.setTime(DateUtils.parseDate("01/04/2016", format));
		    
		    Calendar toCal = Calendar.getInstance();
		    toCal.setTime(DateUtils.parseDate("31/03/2017", format));
			
		    

			GregorianCalendar fromGregCal = new GregorianCalendar(fromCal.get(Calendar.YEAR), fromCal.get(Calendar.MONTH), fromCal.get(Calendar.DAY_OF_MONTH));
			XMLGregorianCalendar fromGregXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(fromGregCal);
			
			GregorianCalendar toGregCal = new GregorianCalendar(toCal.get(Calendar.YEAR), toCal.get(Calendar.MONTH), toCal.get(Calendar.DAY_OF_MONTH));
			XMLGregorianCalendar toGregXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(toGregCal);
			
			for (int j=0;j<=5;j++){
			SecureRandom sr = new SecureRandom();
			String i = String.valueOf(Math.abs(sr.nextInt()/10000));
			//System.out.println(i);
		    ObjectFactory factory = new ObjectFactory();
	        
		    PortalPolicySnapshot policySnapshot = factory.createPortalPolicySnapshot();
		    
		    //BigDecimal bigDecimal = new BigDecimal("5329");
		    //bigDecimal = bigDecimal.setScale(0);
		    ////System.out.println(bigDecimal);
		    policySnapshot.setPolicyKey(factory.createPortalPolicySnapshotPolicyKey(new BigDecimal("5329")));
		    policySnapshot.setRequestId(factory.createPortalPolicySnapshotRequestId("5698580123"));
		    policySnapshot.setUnitCode(factory.createPortalPolicySnapshotUnitCode("1"));
		    policySnapshot.setUserId(factory.createPortalPolicySnapshotUserId("test"));
			
			if (CollectionUtils.isNotEmpty(list)) {
				for (WebserviceSource webserviceSource : list) {
					if (webserviceSource != null) {
						
						//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
						 output = (Object)WebServiceClient.getInstance().invokeWsUsingHttpClient(policySnapshot,webserviceSource);
						 ////System.out.println("\nResponse  :"+output);
					}
				}
			}
			////System.out.println("done");
			
		
		}
		}
*/

		/*public static void main(String[] args) throws Exception {
			  //BID Working new
		    reloadWsConfig();
		    PortalPolicySnapshotResponse output = null;
		    List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("BIDSummary");
			
		    
		   
		    String[] format = new String[]{"dd/MM/yyyy"};
		    Calendar fromCal = Calendar.getInstance();
		    fromCal.setTime(DateUtils.parseDate("01/04/2016", format));
		    
		    Calendar toCal = Calendar.getInstance();
		    toCal.setTime(DateUtils.parseDate("31/03/2017", format));
			
		    

			GregorianCalendar fromGregCal = new GregorianCalendar(fromCal.get(Calendar.YEAR), fromCal.get(Calendar.MONTH), fromCal.get(Calendar.DAY_OF_MONTH));
			XMLGregorianCalendar fromGregXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(fromGregCal);
			
			GregorianCalendar toGregCal = new GregorianCalendar(toCal.get(Calendar.YEAR), toCal.get(Calendar.MONTH), toCal.get(Calendar.DAY_OF_MONTH));
			XMLGregorianCalendar toGregXmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(toGregCal);
			
			//for (int j=0;j<=5;j++){
			SecureRandom sr = new SecureRandom();
			String i = String.valueOf(Math.abs(sr.nextInt()/10000));
			//System.out.println(i);
		    ObjectFactory factory = new ObjectFactory();
	        
		    PortalPolicySnapshot policySnapshot = factory.createPortalPolicySnapshot();
		    
		    //BigDecimal bigDecimal = new BigDecimal("5329");
		    //bigDecimal = bigDecimal.setScale(0);
		    ////System.out.println(bigDecimal);
		    policySnapshot.setPolicyKey(factory.createPortalPolicySnapshotPolicyKey(new BigDecimal("5329")));
		    policySnapshot.setRequestId(factory.createPortalPolicySnapshotRequestId("5698580123"));
		    policySnapshot.setUnitCode(factory.createPortalPolicySnapshotUnitCode("1"));
		    policySnapshot.setUserId(factory.createPortalPolicySnapshotUserId("test"));
			
			if (CollectionUtils.isNotEmpty(list)) {
				for (WebserviceSource webserviceSource : list) {
					if (webserviceSource != null) {
						//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
						output = (PortalPolicySnapshotResponse)WebServiceClient.getInstance().invokeWsUsingHttpClient(policySnapshot,webserviceSource);
						////System.out.println("\nResponse  :"+output);
						List<BID> bidList = output.getPortalPolicySnapshotResult().getValue().getBidAsOnDate().getValue().getBID();
						
						for(BID bid : bidList){
							//System.out.println(bid.getBalance().getName() + ":" + bid.getBalance().getValue());
							//System.out.println(bid.getUnitName().getName() + ":" + bid.getUnitName().getValue());
						}
					}
				}
			}
			////System.out.println("done");
			
		
		//}
		}
		*/
		
/*		public static void main(String[] args) throws Exception {
			  //emailCampaignNew
		    reloadWsConfig();
		    PortalPolicySnapshotResponse output = null;
		    List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("emailCampaignNew");
			
		    
			Form form = new Form();
			form.add("auth","{\"user\":\"ecamp\",\"password\":\"group@ipru\",\"appName\":\"Group\"}");
			form.add("jsonString","{\"campaign\" : \"ServicewebpageAcknowledgment\", \"dynParam\" : [\""+ callID + "\",\"" + policyNo+ "\",\"" + emailId + "\"]}");
		    
		    
		    
		    
		   
		   
			//for (int j=0;j<=5;j++){
			SecureRandom sr = new SecureRandom();
			String i = String.valueOf(Math.abs(sr.nextInt()/10000));
			//System.out.println(i);
		    ObjectFactory factory = new ObjectFactory();
	        
		    PortalPolicySnapshot policySnapshot = factory.createPortalPolicySnapshot();
		    
		    //BigDecimal bigDecimal = new BigDecimal("5329");
		    //bigDecimal = bigDecimal.setScale(0);
		    ////System.out.println(bigDecimal);
		    policySnapshot.setPolicyKey(factory.createPortalPolicySnapshotPolicyKey(new BigDecimal("5329")));
		    policySnapshot.setRequestId(factory.createPortalPolicySnapshotRequestId("5698580123"));
		    policySnapshot.setUnitCode(factory.createPortalPolicySnapshotUnitCode("1"));
		    policySnapshot.setUserId(factory.createPortalPolicySnapshotUserId("test"));
			
			if (CollectionUtils.isNotEmpty(list)) {
				for (WebserviceSource webserviceSource : list) {
					if (webserviceSource != null) {
						//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
						output = (PortalPolicySnapshotResponse)WebServiceClient.getInstance().invokeWsUsingHttpClient(policySnapshot,webserviceSource);
						////System.out.println("\nResponse  :"+output);
						List<BID> bidList = output.getPortalPolicySnapshotResult().getValue().getBidAsOnDate().getValue().getBID();
						
						for(BID bid : bidList){
							//System.out.println(bid.getBalance().getName() + ":" + bid.getBalance().getValue());
							//System.out.println(bid.getUnitName().getName() + ":" + bid.getUnitName().getValue());
						}
					}
				}
			}
			////System.out.println("done");
			
		
		//}
		}*/
		
		
		
	/*public static void main(String[] args) throws Exception {
	
		  //ClickPSS working
		
		ClickPSSWebService clickPSSWebService = new ClickPSSWebService();
		
		clickPSSWebService.setPolicyNo(SecurePassword.encode("00012043"));
	
		clickPSSWebService.setCustomerId(SecurePassword.encode("00002023"));
	
		clickPSSWebService.setTemplateId(SecurePassword.encode("T040"));
	
	
	
		Map<String, String> requestMap = new HashMap<String, String>(1);
		requestMap.put("policyNo", clickPSSWebService.getPolicyNo());
		requestMap.put("customerId", clickPSSWebService.getCustomerId());
		requestMap.put("toDate", "");
		requestMap.put("fromDate", "");
		requestMap.put("templateId", clickPSSWebService.getTemplateId());
		
		
	
	
		String output = null;
		reloadWsConfig();
	
		  List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("ClickPSS");
		  String clickPSSResponseUrl = null;
			if (CollectionUtils.isNotEmpty(list)) {
				for (WebserviceSource webserviceSource : list) {
					if (webserviceSource != null) {
						
						webserviceSource.setGetParameters(requestMap);
						
						
						output = (String) WebServiceClient.getInstance().invokeWsUsingHttpClient(null, webserviceSource);
						String[] responseArray = output.split("url : ");
						if(responseArray.length > 1)
							clickPSSResponseUrl = responseArray[1];
						//System.out.println(clickPSSResponseUrl);
						//System.out.println(output);
					}
				}
			}
}*/
		
		
/*	public static void main(String[] args) throws Exception 
	  {
		  //Portfolio Working
		Object output = null;
	    reloadWsConfig();
	    List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("PrePopulateDetails");
		Map map = new HashMap<String, String>();
		List<String> paramList=new ArrayList<String>();

		//contributionTillDateForTrust : policynumber:00000360
		//contributionTillDateForMember : policynumber:00000360 ,employeeid:1011 ,o/p: amount:99276017.93
		//payoutTilldate: policynumber:00001698 ,o/p: amount:4295064.3954
		//bonusForTrust :policynumber:00001698 ,o/p: amount:29630376.805
		//bonusForMember : policynumber:00001701 ,employeeid:46742 ,o/p: amount:8865.9996
		
		//adjustmentForTrust :policynumber:00000535 ,o/p: [{"un1":"-25044897","un2":"111642673","amount":null,"units":null,"navValue":null}]
		//adjustmentForMember : policynumber:00000073 ,employeeid:104931 ,o/p: "un1":"-20624.34","un2":"2349850.63"
		
		//annualBonusForTrust : policynumber:00000535 , o/p : amount":"55861379.61"
		//annualBonusForMember :  policynumber:00000430 ,employeeid:110731 ,o/p: amt: 735063.16
		
		//totalFundForTrust : 00000013 , o/p: units":"2111.245"
		//totalFundForMember : policynumber: 00000013, employeeid: 18 ,o/p: "units":"974.654",
		
		//dcurrentNav :13/05/2003,DBT, o/p : "navValue":"10.31"
//		paramList.add("00002285");//policynumber
//		paramList.add("21847");//employeeid
		
		//paramList.add("00002285");
//		paramList.add("DBT");//policynumber
		
		
		paramList.add("17/02/2017");
		paramList.add("GCGSTF3");
		
		
		ParamObj paramObj=new ParamObj();
	    paramObj.setParam(paramList);
		 
		PrePopulateBean prePopulateBean=new PrePopulateBean();
		prePopulateBean.setFunctionality("dcurrentNav");
		prePopulateBean.setParamObj(paramObj);
	    
	    Gson gson = new Gson();
	    String s = gson.toJson(prePopulateBean);
    

		
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					
					//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
					output = (Object)WebServiceClient.getInstance().invokeWsUsingHttpClient(s,webserviceSource);
				////System.out.println("Response  :"+output);
				}
			}
		}
		////System.out.println("done");
		
		//List<ProductDetailsVO> productDetailsVOList=gson.fromJson(output.toString(), new TypeToken<List<ProductDetailsVO>>(){}.getType());
	}*/
	
	

	  /*public static void main(String[] args) throws Exception 
	  {
		//Fund Performance Chart WORKING FUNE
		  ////System.out.println("GEETTTTTTTTTT");
	    reloadWsConfig();
//		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("DigitalFundPerformance");
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("DigitalFundPerformanceChart");
		Map map = new HashMap<String, String>();
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					
//					MMAF&startDate=12-MAY-17&endDate=18-MAY-17
					Date currentDate = new Date();
					Calendar cal = new GregorianCalendar();
					cal.setTime(currentDate);
					cal.add(Calendar.DAY_OF_MONTH, -1);
					currentDate = cal.getTime();
					cal.add(Calendar.DAY_OF_MONTH, -6);
					Date endDate = cal.getTime();
			
					SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
					
					map.put("fundCode", "MMAF");
					map.put("startDate", (dateFormat.format(endDate).toString().toUpperCase()));
					map.put("endDate", dateFormat.format(currentDate).toString().toUpperCase());
					
					
					webserviceSource.setGetParameters(map);
					//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
					Object output = (Object)WebServiceClient.getInstance().invokeWsUsingHttpClient(null,webserviceSource);
					//System.out.println(output);
					////System.out.println("Response123  :"+output);
				}
			}
		}
		////System.out.println("done");
	}*/
	  
	/*public static void main(String[] args) throws Exception {
		//DigitalFundPerformance NOT WORKING
		  ////System.out.println("GEETTTTTTTTTT");
	    reloadWsConfig();
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("DigitalFundPerformance");
		Map map = new HashMap<String, String>();
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					
					
					List<String> fundCode = new ArrayList<String>();
					fundCode.add("MMAF");
					
					

					StringBuffer fundListEncoded = new StringBuffer();

					Iterator it = fundCode.iterator();
					while (it.hasNext()) {

						fundListEncoded.append(it.next().toString());

						if (it.hasNext()) {
							fundListEncoded.append(",");
						}
					}
					byte[] encoded = Base64.encodeBase64(fundListEncoded.toString().getBytes());
					map.put("fundCode", new String(encoded));
					
					Date endDate = new Date();
					Calendar cal = new GregorianCalendar();
					cal.setTime(endDate);
					cal.add(Calendar.DAY_OF_MONTH, -1);
					endDate = cal.getTime();
					cal.add(Calendar.DAY_OF_MONTH, -6);
					Date startDate = cal.getTime();

					SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
					
					map.put("startDate", (new String(Base64.encodeBase64(dateFormat.format(startDate).toString().toUpperCase().getBytes()))));
					
					map.put("endDate", (new String(Base64.encodeBase64(dateFormat.format(endDate).toString().toUpperCase().getBytes()))));
					
					
					
					
					
					
					webserviceSource.setGetParameters(map);
					//System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
					Object output = (Object)WebServiceClient.getInstance().invokeWsUsingHttpClient(null,webserviceSource);
					//System.out.println(output);
					////System.out.println("Response123  :"+output);
				}
			}
		}
		////System.out.println("done");
	}*/

}
