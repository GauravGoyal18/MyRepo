package com.tcs.wsconfig.wsclient;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Security")

public class Security {
	

	private UsernameToken Usernametoken;

	public UsernameToken getUsernameToken() {
		return Usernametoken;
	}

	public void setUsernameToken(UsernameToken Usernametoken) {
		this.Usernametoken = Usernametoken;
	}
}
 