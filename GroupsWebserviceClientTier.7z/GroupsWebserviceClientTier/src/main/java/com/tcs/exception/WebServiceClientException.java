package com.tcs.exception;

public class WebServiceClientException extends Exception{

	private static final long serialVersionUID = 1L;
	private String message;
	private String statusCode;

	public WebServiceClientException() {
		super();
	}

	public WebServiceClientException(String strErrorMessage) {
		super(strErrorMessage);
		setMessage(strErrorMessage);
	}
	
	public WebServiceClientException(String strErrorMessage,String statusCode) {
		this(strErrorMessage);
		setStatusCode(statusCode);
	}

	public WebServiceClientException(Throwable cause) {
		super(cause.getMessage(), cause);
		setMessage(cause.getMessage());
	}

	public WebServiceClientException(String msg, Throwable cause) {
		super(msg, cause);
		setMessage(msg);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
