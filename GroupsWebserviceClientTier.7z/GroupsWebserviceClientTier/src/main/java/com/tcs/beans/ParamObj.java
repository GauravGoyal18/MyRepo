package com.tcs.beans;

import java.io.Serializable;
import java.util.List;
import java.util.Map;



public class ParamObj implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<String> param;
	private List<Object> param1;
	private Map<String,Object> paramMap;
	
	public List<String> getParam() {
		return param;
	}
	public void setParam(List<String> param) {
		this.param = param;
	}
	public List<Object> getParam1() {
		return param1;
	}
	public void setParam1(List<Object> param1) {
		this.param1 = param1;
	}
	public Map<String, Object> getParamMap() {
		return paramMap;
	}
	public void setParamMap(Map<String, Object> paramMap) {
		this.paramMap = paramMap;
	}




	@Override
	public String toString() {
		return "ParamObj [param=" + param + ", param1=" + param1
				+ ", paramMap=" + paramMap + "]";
	}



	
	
}
