package com.tcs.beans;

public enum WebServiceNameEnum {
	
			FUNDPERFORMANCE("FUNDPERFORMANCE"),GroupsServices("GroupsServices"),NSEAndProductDetails("NSEAndProductDetails"),PreFundDetails("PreFundDetails"),
			SpaarcAutoCallLog("SpaarcAutoCallLog"),DropDownDetails("DropDownDetails"),PrePopulateDetails("PrePopulateDetails"),EmailCampaign("emailCampaign"),
			prePopulateCount("prePopulateCount"),BIDSummary("BIDSummary"),AnnuityCalculator("AnnuityCalculator"),BidStatement("BidStatement"),
			DigitalFundPerformanceChart("DigitalFundPerformanceChart"),DigitalFundPerformance("DigitalFundPerformance"),BROKER("BROKER"),
			EmailAttachment("EmailAttachment"),FscDetails("FscDetails"),CLICKPSSENCRYPTEDDATA_UAT("CLICKPSSENCRYPTEDDATA_UAT"),GETTOKENWITHENCRYPTEDDATA("GETTOKENWITHENCRYPTEDDATA"),DIGILIFE_VERIFICATION("DIGILIFE_VERIFICATION");
			


			private final String webServiceName;

			WebServiceNameEnum(String webServiceName) {
				this.webServiceName = webServiceName;
			}

			public String getWebServiceName() {
				return webServiceName;
			}
			
}
