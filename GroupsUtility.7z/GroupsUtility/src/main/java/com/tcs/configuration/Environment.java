/**
 * 
 */
package com.tcs.configuration;

import static com.ipru.groups.utilities.GroupConstants.CONSTANT_C;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.logger.FLogger;
import com.tcs.root.properties.Rootproperties;

/**
 * @author Susanta Ghosh
 */
public enum Environment {

	HELPER, SIT, UAT, DR_PRIMARY, DR_SECONDARY, PROD_PRIMARY, PROD_SECONDARY, DR_PREPROD_PRIMARY, DR_PREPROD_SECONDARY;

	/**
	 * SIT - For SIT UAT - For UAT DR_PRIMARY - Webesrvices pointing to
	 * Production environment, to be used during DR Activity on the Primary DR
	 * Server DR_SECONDARY - Webesrvices pointing to Production environment, to
	 * be used during DR Activity on the Secondary DR Server DR_PREPROD_PRIMARY
	 * - Webservices pointing to UAT/Preprod environment, to be used during
	 * Preprod on Primary DR Server DR_PREPROD_SECONDARY - Webservices pointing
	 * to UAT/Preprod environment, to be used during Preprod on Secondary DR
	 * Server PROD_PRIMARY - Webservices pointing to Production environment, to
	 * be used during production on Primary Production Server PROD_SECONDARY -
	 * Webservices pointing to Production environment, to be used during
	 * production on Secondary Production Server
	 */
	Environment() {

		// ////System.out.println("Environment Constructor Called......");

	}

	private static Properties wsClientProps;

	public String getPath(Environment e, String constantname) {
		String path = CONSTANT_C + "/" + constantname + "_" + e + ".properties";
		return path;
	}

	public String getFilePath(String environment) {

		// TODO Auto-generated method stub

		Properties p = new Properties();
		InputStream st = Rootproperties.class.getResourceAsStream("configdirectory.properties");
		try {
			p.load(st);
			String config = p.getProperty("IMAGE_PATH_".concat(environment));
			return config;
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			return null;
		}

	}

	public String getMode() {

		// TODO Auto-generated method stub

		Properties p = new Properties();
		InputStream st = Rootproperties.class.getResourceAsStream("configdirectory.properties");
		try {
			p.load(st);
			String config = p.getProperty("MODE");
			// ////System.out.println("Rooooooooottttttt path ---------------:::::>>>>>>>>"+p.getProperty("MODE"));
			return config;
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public String getEnvironmentFile(String environment, String param) {
		// TODO Auto-generated method stub
		if (getMode() != null)
			return getPath(valueOf(getMode().concat(environment)), param);
		else
			return getPath(valueOf(environment), param);
		// return null;
	}

	public String getWsClientXmlFile(String keyValue) {
		String path = "";
		FileInputStream file = null;
		if (MasterPropertiesFileLoader.CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH != null) {
			wsClientProps = MasterPropertiesFileLoader.CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH;
		}
		else {
			try {
				file=new FileInputStream(GroupConstants.CONSTANT_WEBSERVICE);
				wsClientProps.load(file);
				
//				webServiceProperties.load(new FileInputStream("D:/maven_workspace/groups/local-uat/GroupsIPruConfig/WebserviceClient/webserviceclient.properties"));
			}
			catch (FileNotFoundException e) {
			}
			catch (IOException e) {
			}
			finally
			{
				try {
					if(file!=null)
					file.close();
				}
				catch (Exception e) {
					
					FLogger.error("GROUPLogger", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
							"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
					
				} finally {
					file=null;
				}
			}
		}

		path = wsClientProps.getProperty(keyValue);
		return path;
	}

}
