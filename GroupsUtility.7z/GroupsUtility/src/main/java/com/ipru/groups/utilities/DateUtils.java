package com.ipru.groups.utilities;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class DateUtils {
	
	public static String[] possibleFormats = null;
	
	static
	{
		possibleFormats = new String[]{"dd/MM/yyyy","dd-MM-yyyy"};
	}
	
	public static String changeFormatOfDateString(String inputDateStr, String existingFormat, String requiredFormat) {
		DateFormat dfParse = new SimpleDateFormat(existingFormat);
		DateFormat dfFormat = new SimpleDateFormat(requiredFormat);
		Date tempDate = null;

		String modifiedDate = "";
		if (inputDateStr != null && !("").equalsIgnoreCase(inputDateStr)) {
			try {
				tempDate = dfParse.parse(inputDateStr);
				modifiedDate = dfFormat.format(tempDate);
			}
			catch (java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return modifiedDate;
	}
	
	
	/**
	 * Method formatDate. This method formats the given date in provided format
	 * It accept the message to be logged as a parameter.
	 * 
	 * @param Date
	 *            date
	 * @param String
	 *            format
	 * @return String - formatted date
	 */
	public static String formatDate(Date date, String format) {
		String formattedDate = "";
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			sdf.setLenient(false);
			formattedDate = sdf.format(date);
		}
		return formattedDate;
	}	
	
	/**
	 * 
	 * @param dateToValidate
	 * @param dateFormat
	 * @return
	 */
	public static Boolean isThisDateValid(String dateToValidate, String dateFormat)
	{		
		SimpleDateFormat sdf = null;
		
		if(StringUtils.isBlank(dateToValidate))
			return Boolean.FALSE;

		sdf = new SimpleDateFormat(dateFormat) ;
		sdf.setLenient(false);
		
	    try {
	        Date d = sdf.parse(dateToValidate) ;
	        ////System.out.println(d);
	    } catch (ParseException e) {	    	
	        e.printStackTrace();
	        return Boolean.FALSE;
	    }	
	    
	    return Boolean.TRUE;
	}
	
	/**
	 * 
	 * @param dateToValidate
	 * @return
	 */
	public static Boolean validateDate(String dateToValidate)
	{
		Boolean retVal = Boolean.FALSE;
		int index =0 ;

		if(StringUtils.isBlank(dateToValidate))
		{
			return Boolean.FALSE;
		}
		
		while(retVal == Boolean.FALSE && index < possibleFormats.length)
		{
			retVal = isThisDateValid(dateToValidate, possibleFormats[index++]);
		}
		
		return retVal;
	}


}
