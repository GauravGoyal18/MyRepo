package com.ipru.groups.utilities;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import javax.xml.bind.DatatypeConverter;


public class EncryptionPBEMD5DES {
	public static int iterationCount = 450;
	/*public static BASE64Encoder bEncoder = new BASE64Encoder();
	public static BASE64Decoder bDecoder = new BASE64Decoder();*/

	public static String encrypt(String strData, String password, int iteration) throws Exception {
		byte[] salt = { (byte) 0xA9, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x35, (byte) 0xE3, (byte) 0x03 };

		PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray(), salt, iteration);
		PBEParameterSpec paramSpec = new PBEParameterSpec(keySpec.getSalt(), keySpec.getIterationCount());
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
		SecretKey key = keyFactory.generateSecret(keySpec);
		Cipher cipher = Cipher.getInstance(key.getAlgorithm());
		cipher.init(Cipher.ENCRYPT_MODE, key, paramSpec);
		byte[] enc_data = cipher.doFinal(strData.getBytes());

//		return bEncoder.encodeBuffer(enc_data);
		return DatatypeConverter.printBase64Binary(enc_data);
	}

	public static String decrypt(String encStr, String password, int iteration) throws Exception {
		byte[] salt = { (byte) 0xA9, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x35, (byte) 0xE3, (byte) 0x03 };
//		byte[] enc_data = bDecoder.decodeBuffer(encStr);
		byte[] enc_data = DatatypeConverter.parseBase64Binary(encStr);
		PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray(), salt, iteration);
		PBEParameterSpec paramSpec = new PBEParameterSpec(keySpec.getSalt(), keySpec.getIterationCount());
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndDES");
		SecretKey key = keyFactory.generateSecret(keySpec);
		Cipher cipher = Cipher.getInstance(key.getAlgorithm());
		cipher.init(Cipher.DECRYPT_MODE, key, paramSpec);
		byte[] dec_data = cipher.doFinal(enc_data);
		return new String(dec_data);
	}

	public static void main(String args[]) throws Exception {
		String data = "{\"role\":\"SPAARC\",\"websiteSource\":\"SPAARC\",\"reqFunc\":\"eStatements\",\"subFunc\":\"ppc\",\"encryptedFlag\":\"Y\",\"loginSource\":\"BOPS\",\"autoLoginConsumerUserIdentifier\":\"IPRU26488\"}";
		// String
		// data="{'role':'SPAARC','websiteSource':'SPAARC','reqFunc':'eStatements','subFunc':'ppc','encryptedFlag':'Y','loginSource':'BOPS','autoLoginConsumerUserIdentifier':'IPRU26488'}";
		String encryptData = encrypt(data, "WEBSITE123", 1);
		//System.out.println(encryptData);
//		String encode = GroupSecurityUtil.encodeBase64(encryptData);

//		//System.out.println(encode + " encryptData *****************************");
		/*
		 * String enc_data =
		 * encrypt("This is test dsadasdadsadsadasd","test",iterationCount);
		 * ////System.out.println("Encoded string::"+enc_data); String decodeStr =
		 * decrypt(enc_data, "test", iterationCount);
		 * ////System.out.println("Decoded string::"+decodeStr);
		 */
		// String
		// testString="ZUNwQWQwNExXMXFVYXp4TGVqY01WMDhIWVlHTjN3TWJNTVZwS2ZDSHlvd2d0NTRzTUVqRDR4U3RQS3p4SWV4L004Wmh2eFhpbW5LNA0KZXZqY0V3eGRPYkdHbzZYczlQSUNJTGxrM05mRmtxYTNhUXJmU0FyWXdzRkRSaU9KYmNCYmhBLzFlWXdlZTExemQvYUxIYkt4Q04xTg0KUW02dmptcEZIWUwyRklBcjdBR3hSU091YlVHRWpGOTk3TFVXcmpIcW5tNGxHbGRIMFdlU3paQ0RIOHE2UEc2QWdkMHN4QXJNZU4xZw0KOHB5RXl5d2RPMWV1M21FdkZLdWRQY08wWmlzcjJ4a1pYN0VQQ3ZvWEppNUVsV2I2VUNtQzhiZk5UN2Rrbjk3VE9QVSsraGs9DQo";
//		String testString = "TVh3TFBjODZ6dHg2b2w2ZVZMQlp6bUFMSHYzTW9jeHl0MTNUT3lCUHA5LzUzNDIxK3hKQzg2S0tIWWJCeGNSQkFZNEZsR2NkbWRkQQ0KTEZoZmpsdldrRk5BRHJYUU1HWHkrczhTQmJoL3F5a1Nyd2hzcHJYTkUvaVczNXdRd0MvakdWNjRub1A5cmpRTCtIdFBUZGFBYVNycg0KMHlwaGErRFJ0YzJ3S3IvblpQRW9VT0crWnY0Zko1c0QweGRSN0Zxb0VaMHhTUlpYSlZBWlBMdEMvc0FGdjBXdnpxWTdpNFlvN0JNQw0KcW12UzNYajVHRnFLNlFXN3ZMRXU1RzZrd0MrajdkaWhQcFdUV3ltbzU4VVpZd294YVE9PQ0K";
//		String testString = decrypt(GroupSecurityUtil.decodeBase64(encode), "WEBSITE123", 1);
		String testString = decrypt(encryptData, "WEBSITE123", 1);
		////System.out.println("testString " + testString);
	}

}