package com.ipru.groups.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;

public class MasterPropertiesFileLoader {
	private static final long serialVersionUID = 1L;
	
	public static Properties propertyFileLoader(String fileName) throws Exception{
		Properties prop = new Properties();
		FileInputStream fis = null;
		
		
		try {
			fis = new FileInputStream(fileName);
			prop.load(fis);
		} 
		catch (Exception e) 
		{
			FLogger.error("GROUPLoggerError", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
					"Properties file not found "+fileName+"Exception Ocurred: "+e.getMessage());
			e.printStackTrace();
			throw new ServiceException("5000");
		}
		finally {
			try {
				if(fis!=null)
					fis.close();
			}
			catch (Exception e) {
				FLogger.error("GROUPLoggerError", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
						"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
				e.printStackTrace();
			} finally {
				fis=null;
			}
		}
		
		
		return prop;
		}
	
	
	public static Properties getProperties(Properties prop,String path) {
		FileInputStream fis=null;
		StringBuilder strBuilder=new StringBuilder("Get properties invoked with path=");
		strBuilder.append(path).append(" and prop=").append(prop);
		
		FLogger.debug("GROUPLogger","MasterPropertiesFileLoader","getProperties(Properties prop,String path)",strBuilder.toString());
		strBuilder.setLength(0);
		if(prop==null)
		{
			prop =new Properties();
			try {
					fis=new FileInputStream(path);
					prop.load(fis);					
			} catch (FileNotFoundException e) {
				strBuilder.append("Properties file not found for path=").append(path);
				FLogger.error("GROUPLogger", "MasterPropertiesFileLoader", "getProperties(Properties prop,String path)",
						strBuilder.toString(),e);
				strBuilder.setLength(0);
			} catch (IOException e) {
				strBuilder.append("IOException occured for path=").append(path);
				FLogger.error("GROUPLogger", "MasterPropertiesFileLoader", "getProperties(Properties prop,String path)",
						strBuilder.toString(),e);
			} finally {
				try {
					fis.close();
				}
				catch (Exception e) {
					strBuilder.append("Exception occured while closing fis for path=").append(path);
					FLogger.error("GROUPLogger", "MasterPropertiesFileLoader", "getProperties(Properties prop,String path)",
							strBuilder.toString(),e);
					strBuilder.setLength(0);
				} finally {
					fis=null;
				}
			}
		}
		strBuilder.append("Returning prop for path=").append(path);
		FLogger.debug("GROUPLogger","MasterPropertiesFileLoader","getProperties(Properties prop,String path)",strBuilder.toString());
		strBuilder.setLength(0);
		return prop;
		
	}
	
	//added by ajay for csr
	public static  Properties CONSTANT_WEBSERVICES_URI_PROPERTIES = null;
	
	public static  Properties CONSTANT_IPRUCONFIG_WEBSERVICEURI_PROPERTIES = null;
	public static  Properties CONSTANT_SERVER_PATH_PROPERTIES = null;
	public static  Properties CONSTANT_PAN_VERIFICATION_PROPERTIES = null;
	public static  Properties CONSTANT_AGE_CAL_LOGIC_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_IPADDRESS_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_LEADINSERTERROR_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_CALCCLASSES_PROPERTIES = null;
	public static  Properties CONSTANT_LDAP_LOGIN_PROPERTIES = null;
	public static  Properties CONSTANT_PS_MYBUSINESS_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_EBI_TERMS_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_STATEMAPPING_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_CITYMAPPING_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_BRE_MAPPING_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_PRODUCTMAPPING_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_PRODUCTCodeMAPPING_PROPERTIES = null;
	public static Properties CONSTANT_IPRUCONFIG_STORYCODEMAPPING_PROPERTIES = null;
	
	
	public static  Properties CONSTANT_IPRUCONFIG_ProductCodeUINMapping_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_COMPONENTMAPPING_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_OCCUPATIONMAPPING_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_DEFAULTMCAVALUE_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_APPLICATION_PROPERTIES_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_APPLICATION_PREFERANCE_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_COMMON_MQ_PROPERTIES = null;
	public static  Properties CONSTANT_PDF_PROPERTIES_PROPERTIES = null;
	public static  Properties CONSTANT_CASH_ADVANTAGE_PDF_PROPERTIES = null;
	public static  Properties CONSTANT_SALESCHANNEL_PROPERTIES = null;
	public static  Properties CONSTANT_OTC_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_APPFRM_TITLES_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_APPFRM_STATE_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_APPFRM_CITY_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES = null;
	public static Properties CONSTANT_IPRUCONFIG_LOGIN_TABLET_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_THIRDPARTY_CONSTANTS_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_LDAP_PROPERTIES = null;
	
	public static  Properties CONSTANT_PROFILEUPDATE_PROPERTIES=null;
	public static  Properties CONSTANT_NOMINEEUPDATE_PROPERTIES=null;
	public static  Properties CONSTANT_TRACKER_PROPERTIES=null;
	public static  Properties CONSTANT_SOL_DOC_PATH_PROPERTIES = null;
	public static  Properties CONSTANT_IPRUCONFIG_PRODUCT_CODE_LIST_PROPERTIES = null;
	
	public static  Properties CONSTANT_DOC_APPROVE_STATUS_PROPERTIES = null;
	
	public static  Properties CONSTANT_IPRUCONFIG_APP_FORM_OCC_PROPERTIES=null;
	public static  Properties CONSTANT_ESB_PROPERTIES=null;
	public static Properties CONSTANT_CACHE_MODE_TERACOTTA_PROPERTIES=null;
	public static Properties CONSTANT_CACHE_MODE_CSEBI_PRODUCTCODE_PROPERTIES=null;
	public static Properties JS_CSS_VERSION_PROPERITES=null;
	public static  Properties CONSTANT_IPRUCONFIG_VALIDATEAPPFORM_PROPERTIES = null;
	public static Properties CONSTANT_APPLICATIONFORMRESOURCES_PROPERTIES = null;  //Added by pratheek for partner integration
	public static Properties CONSTANT_APPLICATIONFORMRESOURCES_DIGI_PROPERTIES = null;
	public static Properties CONSTANT_APPLICATIONFORMCHANNELS_PROPERTIES = null;  // Added by pratheek for channel identification
	public static Properties CONSTANT_FUND_PROJECTION_PROPERTIES = null;
	public static Properties CONSTANT_EMAIL_SMS_CMPGN_PROPERTIES =null;
	//public static Properties CONSTANT_MENU_GENERATOR =null;
	
	public static Properties CONSTANT_CAMPAIGNNAME_MAPPING_PROPERTIES=null; //Added by danesh Sending Email,SMS
	
	public static Properties CONSTANT_PASALOGIN_PROPERTIES=null; //Added by apurv for pasa login
	
	public static Properties CONSTANT_PERFIOS_PROPERTIES =null; //Added by Aakash - Perfios Flow
	public static  Properties CONSTANT_OTP_MANAGER_PROPERTIES = null;
	
	public static  Properties CONSTANT_USER_VO_PROPERTIES = null;
	
	public static Properties CONSTANT_COMMON_PAYMENT_PROPERTIES=null;
	
	public static Properties CONSTANT_BULKSMS_WSCLIENT_PROPERTIES=null;
	public static Properties CONSTANT_PARTNER_SERVICING_PROPERTIES=null;
	
	public static Properties CONSTANT_EXCEPTION_CODE_PROPERTIES=null;// added by Ajay for exception code
	
	public static Properties CONSTANT_APPLICATION_FORM_BSNS_PRM_ARRAY_MAPPING=null; // added by arvind edoc changes 
	public static Properties CONSTANT_APPLICATION_FORM_BSNS_PRM_MAPPING=null;
	public static Properties CONSTANT_IPADDRESS_OBTAINED_MAPPING_PROPERTIES=null;//added by neha for google analytics
	
	public static Properties CONSTANT_IPROTECT_EMPLOYEE_PDF_PROPERTIES=null; //Added by pratheek for iprotect employee pdf
	// Added by Gaurav for BOL Integration - START
	public static Properties CONSTANT_BOL_INTEGRATION_PROPERTIES=null; 
	// Added by Gaurav for BOL Integration - END
	
	//Added by Kaushik for policy pre pop
	public static  Properties CONSTANT_POLICY_PRE_POPULATION_PROPERTIES = null;
	
	// added by samaksha for new lead
		public static Properties CONSTANT_NEW_LEAD_PROPERTIES = null;
		public static Properties CONSTANT_LEAD_PDF = null;
		
	public static  Properties CONSTANT_POLICY_AGENT_DETAILS_PROPERTIES = null;
	
	public static Properties CONSTANT_ISENSE_PROPERTIES = null;
	
	//Added by Hiren Sonawala for Security Fixes of Jcryption.
	public static Properties CONSTANT_JCRYPTION_URL = null;
	
	//Added by Tamanna
	public static Properties CONSTANT_SALES_DATA_ENTRY_PROPERTIES = null;
	
	//Added by Madhav
	public static Properties CONSTANT_SEND_OTP_PROPERTIES = null;
	// added by samaksha for microsite
	public static Properties CONSTANT_MICROSITE_PROPERTIES = null;
	
	//Added by Sudha Suman for Corporate Agent Servicing
	public static Properties CONSTANT_CSR_CA_SERVICING_PROPERTIES = null;
	
	//Added by Ketki for DigiDrive : for PreEbi JSON properties
	public static Properties CONSTANT_CONTEXT_WEB_SERVICES_PROPERTIES = null;
	public static Properties CONSTANT_PREEBIJSON_PROPERTIES = null;
	public static Properties CONSTANT_LIFESTAGE_PROPERTIES = null;
	public static Properties CONSTANT_NEED_ROLESOURCEMAPPING_PROPERTIES = null;
	public static Properties CONSTANT_ECSPAYOUT_DEFAULT_VALUES_PROPERTIES	= null;
	public static Properties CONSTANT_PAYMENT_MODES_DESC_PROPERTIES = null;
	//public static Properties CONSTANT_IPRUCONFIG_EBIPRODUCTUTILITY = null;
	public static Properties CONSTANT_IPRUCONFIG_CUSTOMISOLPRODUCTUTILITY = null;
	
	//Added by Tamanna for DigiDrive : for ACR, SAFE and CCR
	public static Properties CONSTANT_REPORT_PROPERTIES=null;
	
	//Added by Nikhil for EBI 
//	public static Properties CONSTANT_IPRUCONFIG_EBIPRODUCTUTILITY_PROPERTIES = null;
	public static Properties CONSTANT_IPRUCONFIG_EBIBACKENDVALIDATION_PROPERTIES =null;
	public static Properties CONSTANT_USER_MGMT_PROPERTIES = null;	// Added for User Management
	
	//Added By Ritika For PASA properties at EBI saving
	public static Properties CONSTANT_PASA_PDF_PROPERTIES = null;
	
	// Added By Sidana for ServiceWebPage at length validation.
	public static Properties CONSTANT_SERVICEWEBPAGE_LENGTH_PROPERTIES = null;
	
	public static Properties CONSTANT_REST= null;
	
	public static Properties CONSTANT_FUND_PERFORMANCE_WS= null;
	
	public static Properties CONSTANT_DIGITAL_WEB_SERVICE= null;
	
	public static Properties CONSTANT_EMAILMOBILE_LENGTH_PROPERTIES = null;
	
	public static Properties CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH = null;
	
	public static Properties CONSTANT_TEMPLATE_PROPERTIES = null;
	
	public static Properties CONSTANT_SPAARC_PROPERTIES = null;
	
	public static  Properties CONSTANT_PMJJBY_PROPERTIES=null;
	
	public static Properties CONSTANT_NONDEATH_CLAIMEMAILSEND=null;
	
	public static Properties CONSTANT_NONDEATH_EXCELVALIDATION=null;
	
	public static  Properties CONSTANT_SWITCHTRACKER_PROPERTIES=null;
	
	public static Properties CONSTANT_BROKER_PROPERTIES=null;
	
	public static Properties SSOGROUP_LOGIN_PROPERTIES=null;
	
	public static Properties SIGNUP_PROPERTIES=null;
	
	public static Properties HONEYBEE_PROPERTIES=null;
	
	public static void loadMasterPropertiesFile() throws Exception {
		
		// TODO Auto-generated constructor stub
		// loading static properties files
	//	CONSTANT_IPRUCONFIG_EBIPRODUCTUTILITY=propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_EBIPRODUCTUTILITY);
	//	CONSTANT_IPRUCONFIG_CUSTOMISOLPRODUCTUTILITY=propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_CUSTOMISOLPRODUCTUTILITY);
	//	CONSTANT_LIFESTAGE_PROPERTIES=propertyFileLoader(GroupCommonConstants.CONSTANT_LIFESTAGE);		
	//	CONSTANT_NEED_ROLESOURCEMAPPING_PROPERTIES=propertyFileLoader(GroupCommonConstants.CONSTANT_NEED_ROLESOURCEMAPPING);
	//	CONSTANT_IPRUCONFIG_WEBSERVICEURI_PROPERTIES =propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_WEBSERVICEURI);
		CONSTANT_IPADDRESS_OBTAINED_MAPPING_PROPERTIES =propertyFileLoader(GroupConstants.CONSTANT_IPADDRESS_OBTAINED_MAPPING);
		CONSTANT_OTP_MANAGER_PROPERTIES=propertyFileLoader(GroupConstants.CONSTANT_OTP_MANAGER_MAPPING);
		 CONSTANT_SERVER_PATH_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_SERVER_PATH);
	//	 CONSTANT_PAN_VERIFICATION_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_PAN_VERIFICATION);
	//	 CONSTANT_AGE_CAL_LOGIC_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_AGE_CAL_LOGIC);
		 CONSTANT_IPRUCONFIG_IPADDRESS_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_IPRUCONFIG_IPADDRESS);
	//	 CONSTANT_IPRUCONFIG_LEADINSERTERROR_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_LEADINSERTERROR);
	//	 CONSTANT_IPRUCONFIG_CALCCLASSES_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_CALCCLASSES);
		 CONSTANT_LDAP_LOGIN_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_LDAP_LOGIN);
	//	 CONSTANT_PS_MYBUSINESS_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_PS_MYBUSINESS);
//		 CONSTANT_IPRUCONFIG_EBI_TERMS_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_EBI_TERMS);
		// CONSTANT_IPRUCONFIG_STATEMAPPING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_STATEMAPPING);
		// CONSTANT_IPRUCONFIG_CITYMAPPING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_CITYMAPPING);
		// CONSTANT_IPRUCONFIG_BRE_MAPPING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_BRE_MAPPING);
		// CONSTANT_IPRUCONFIG_PRODUCTMAPPING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_PRODUCTMAPPING);
		// CONSTANT_IPRUCONFIG_PRODUCTCodeMAPPING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_PRODUCTCodeMAPPING);
		// CONSTANT_IPRUCONFIG_STORYCODEMAPPING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_STORYCODEMAPPING);
		 CONSTANT_CACHE_MODE_TERACOTTA_PROPERTIES= propertyFileLoader(GroupConstants.CONSTANT_CACHE_MODE_TERACOTTA);
		 CONSTANT_CONTEXT_WEB_SERVICES_PROPERTIES= propertyFileLoader(GroupConstants.CONSTANT_CACHE_JAXBCONTEXT);
		// Added by Gaurav for BOL Integration - START
		//CONSTANT_BOL_INTEGRATION_PROPERTIES=propertyFileLoader(GroupCommonConstants.BOL_INTEGRATION_PROPERTIES);
		// Added by Gaurav for BOL Integration - END
		
		// CONSTANT_IPRUCONFIG_ProductCodeUINMapping_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_ProductCodeUINMapping);
		// CONSTANT_IPRUCONFIG_COMPONENTMAPPING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_COMPONENTMAPPING);
	//	 CONSTANT_IPRUCONFIG_OCCUPATIONMAPPING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_OCCUPATIONMAPPING);
		// CONSTANT_IPRUCONFIG_DEFAULTMCAVALUE_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_DEFAULTMCAVALUE);
		// CONSTANT_IPRUCONFIG_APPLICATION_PROPERTIES_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_APPLICATION_PROPERTIES);
		// CONSTANT_IPRUCONFIG_APPLICATION_PREFERANCE_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_APPLICATION_PREFERANCE_PROPERTIES);
		// CONSTANT_IPRUCONFIG_COMMON_MQ_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_COMMON_MQ);
	//	 CONSTANT_PDF_PROPERTIES_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_PDF_PROPERTIES);
	//	 CONSTANT_CASH_ADVANTAGE_PDF_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_CASH_ADVANTAGE_PDF);
	//	 CONSTANT_SALESCHANNEL_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_SALESCHANNEL);
		 CONSTANT_OTC_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_OTC);
		 CONSTANT_IPRUCONFIG_APPFRM_TITLES_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_IPRUCONFIG_APPFRM_TITLES);
	//	 CONSTANT_IPRUCONFIG_APPFRM_STATE_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_APPFRM_STATE);
	//	 CONSTANT_IPRUCONFIG_APPFRM_CITY_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_APPFRM_CITY);
		 /*for non logged in userVo creation***/
		 CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
		 CONSTANT_IPRUCONFIG_LOGIN_TABLET_PROPERTIES = propertyFileLoader(GroupConstants.CONST_TABLET_IPRUCONFIG_CONSTANTS);

		 /*for non logged in third party integration userVo creation***/
		 CONSTANT_IPRUCONFIG_THIRDPARTY_CONSTANTS_PROPERTIES =  propertyFileLoader(GroupConstants.CONSTANT_IPRUCONFIG_THIRDPARTY_CONSTANTS);
		// CONSTANT_IPRUCONFIG_VALIDATEAPPFORM_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_VALIDATEAPPFORM);
		 CONSTANT_IPRUCONFIG_LDAP_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_IPRUCONFIG_LDAP);
		
		 CONSTANT_PROFILEUPDATE_PROPERTIES=propertyFileLoader(GroupConstants.CONSTANT_PROFILEUPLOAD);
		 CONSTANT_NOMINEEUPDATE_PROPERTIES=propertyFileLoader(GroupConstants.CONSTANT_NOMINEEUPDATE);
		 CONSTANT_TRACKER_PROPERTIES=propertyFileLoader(GroupConstants.CONSTANT_TRACKER);
		 CONSTANT_SERVICEWEBPAGE_LENGTH_PROPERTIES=propertyFileLoader(GroupConstants.CONSTANT_SERVICEWEBPAGE_LENGTH);
		 //CONSTANT_SOL_DOC_PATH_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_SOL_DOC_PATH);
	//	 CONSTANT_APPLICATIONFORMRESOURCES_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_APPLICATION_FORM_RESOURCES);
	//	 CONSTANT_APPLICATIONFORMRESOURCES_DIGI_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_APPLICATION_FORM_RESOURCES_DIGIDRIVE);
	//	 CONSTANT_APPLICATIONFORMCHANNELS_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_APPLICATION_FORM_CHANNELS);
	//	 CONSTANT_IPRUCONFIG_PRODUCT_CODE_LIST_PROPERTIES=propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_PRODUCT_CODE_LIST);
		
	//	 CONSTANT_DOC_APPROVE_STATUS_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_DOC_APPROVE_STATUS);
		 
	//	 CONSTANT_IPRUCONFIG_APP_FORM_OCC_PROPERTIES=propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_APP_FORM_OCC);
		 CONSTANT_ESB_PROPERTIES=propertyFileLoader(GroupConstants.CONSTANT_ESB);
		// CONSTANT_SHORTCODE_MAPPING = propertyFileLoader(CsrConstants.CONSTANT_SHORTCODE_MAPPING);
		 JS_CSS_VERSION_PROPERITES=propertyFileLoader(GroupConstants.VersionFile);
		 //Ankita for CS EBI Flow
	//	 CONSTANT_CACHE_MODE_CSEBI_PRODUCTCODE_PROPERTIES=propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_CSEBI_PRODUCTCODE);
		 
		 //added by ajay for csr
	//	 CONSTANT_WEBSERVICES_URI_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_WEBSERVICES_URI);
		// CONSTANT_FUND_PROJECTION_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_FUND_PROJECTION);
		 
		 //Added by Danesh for Sending Email,SMS
		// CONSTANT_CAMPAIGNNAME_MAPPING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_CAMPAIGNNAME_MAPPING);
		 CONSTANT_EMAIL_SMS_CMPGN_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_EMAIL_SMS_CMPGN);
		 //CONSTANT_MENU_GENERATOR = propertyFileLoader(GroupCommonConstants.CONSTANT_MENU_GENERATOR);
		 
		// CONSTANT_PASALOGIN_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_PASALOGIN_PROPERTIES);
		 
		 //Added by Aakash - Perfios Flow
		// CONSTANT_PERFIOS_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_PERFIOS_BANK_TRANSACTION);
		 
		 //added for SOL-BOL Merger
		 
		 //////System.out.println("GroupCommonConstants.CONSTANT_USER_VO "+GroupCommonConstants.CONSTANT_USER_VO);
		 CONSTANT_USER_VO_PROPERTIES  = propertyFileLoader(GroupConstants.CONSTANT_USER_VO);
		 
		// CONSTANT_COMMON_PAYMENT_PROPERTIES= propertyFileLoader(GroupCommonConstants.CONSTANT_COMMON_PAYMENT_PROPERTIES);
		 CONSTANT_BULKSMS_WSCLIENT_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_BULKSMS_WSCLIENT_PROPERTIES);
		//added by arvnd edoc
		// CONSTANT_APPLICATION_FORM_BSNS_PRM_ARRAY_MAPPING=propertyFileLoader(GroupCommonConstants.CONSTANT_APPLICATION_FORM_BSNS_PRM_ARRAY_MAPPING);
		// CONSTANT_APPLICATION_FORM_BSNS_PRM_MAPPING=propertyFileLoader(GroupCommonConstants.CONSTANT_APPLICATION_FORM_BSNS_PRM_MAPPING);
		 
		// CONSTANT_IPROTECT_EMPLOYEE_PDF_PROPERTIES=propertyFileLoader(GroupCommonConstants.IPROTECTEMP_PDF_PROPERTIES);
	//	 CONSTANT_PARTNER_SERVICING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_PARTNER_SERVICING_PROPERTIES);
	//	 CONSTANT_ISENSE_PROPERTIES=propertyFileLoader(GroupCommonConstants.CONSTANT_ISENSE_PROPERTIES);
	//	 //Added by Kaushik for policy pre pop
	//	 CONSTANT_POLICY_PRE_POPULATION_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_POLICY_PRE_POPULATION_PROPERTIES);
	//	 CONSTANT_POLICY_AGENT_DETAILS_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_POLICY_AGENT_DETAILS_PROPERTIES);
	//	 //added by samaksha
	//	 CONSTANT_NEW_LEAD_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_NEW_LEAD_PROPERTIES);
	//	 CONSTANT_LEAD_PDF = propertyFileLoader(GroupCommonConstants.CONSTANT_LEAD_PDF);
			
		 //added by Ajay
		 CONSTANT_EXCEPTION_CODE_PROPERTIES=propertyFileLoader(GroupConstants.CONSTANT_EXCEPTION_CODE);
		 
		 //Added by Hiren Sonawala
		 CONSTANT_JCRYPTION_URL = propertyFileLoader(GroupConstants.CONSTANT_JCRYPTION_URL_MAPPING);
			
		 //Added by Tamanna
//		 CONSTANT_SALES_DATA_ENTRY_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_SALES_DATA_ENTRY_PROPERTIES);
			
		 //Added by Madhav		
		 CONSTANT_SEND_OTP_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_SEND_OTP);
		 // added by samaksha for microsite
//			CONSTANT_MICROSITE_PROPERTIES =  propertyFileLoader(GroupCommonConstants.CONSTANT_MICROSITE_PROPERTIES);
		
		//Added by Sudha Suman for Corporate Agent Servicing
	//	CONSTANT_CSR_CA_SERVICING_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_CSR_CA_SERVICING_PROPERTIES);
			
		//Added by Ketki for DigiDrive : for PreEbi JSON properties
//		CONSTANT_PREEBIJSON_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_PREEBIJSON);
//		
//		CONSTANT_ECSPAYOUT_DEFAULT_VALUES_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_ECSPAYOUT_DEFAULT_VALUES);
		
//		CONSTANT_PAYMENT_MODES_DESC_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_PAYMENT_MODES_DESC_PROPERTIES);
//		
//		CONSTANT_REPORT_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_REPORT_PROPERTIES);
		
		//Added by Nikhil for EBI :  
//		CONSTANT_IPRUCONFIG_EBIPRODUCTUTILITY_PROPERTIES = propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_EBIPRODUCTUTILITY);
//		CONSTANT_IPRUCONFIG_EBIBACKENDVALIDATION_PROPERTIES =propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_EBIBACKENDVALIDATION);
		
		CONSTANT_USER_MGMT_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_USER_MGMT_PROPERTIES); // Added for User Management
		
		//By Ritika
//		CONSTANT_PASA_PDF_PROPERTIES = propertyFileLoader(GroupCommonConstants.PASA_PDF_PROPERTIES);
		
		CONSTANT_REST = propertyFileLoader(GroupConstants.REST);
		
		CONSTANT_FUND_PERFORMANCE_WS = propertyFileLoader(GroupConstants.CONSTANT_FUND_PERFORMANCE_WS);
	
		CONSTANT_DIGITAL_WEB_SERVICE = propertyFileLoader(GroupConstants.DIGITAL_WEBSERVICE);
		
		CONSTANT_EMAILMOBILE_LENGTH_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_EMAILMOBILE);
		
		CONSTANT_WEBSERVICE_CLIENT_CONFIG_XML_PATH = propertyFileLoader(GroupConstants.CONSTANT_WEBSERVICE);
		
		CONSTANT_TEMPLATE_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_TEMPLATE_PROP);
		
		CONSTANT_SPAARC_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_SPAARC_PROP);
		
		CONSTANT_PMJJBY_PROPERTIES= propertyFileLoader(GroupConstants.CONSTANT_PMJJBY);
		
		CONSTANT_NONDEATH_CLAIMEMAILSEND=propertyFileLoader(GroupConstants.CONSTANT_NONDEATH_CLAIMEMAILSEND);
		
		CONSTANT_NONDEATH_EXCELVALIDATION=propertyFileLoader(GroupConstants.CONSTANT_NONDEATH_EXCELVALIDATION);
		
		CONSTANT_SWITCHTRACKER_PROPERTIES= propertyFileLoader(GroupConstants.CONSTANT_SWITCHTRACKER);
		
		CONSTANT_BROKER_PROPERTIES=propertyFileLoader(GroupConstants.CONSTANT_BROKER);
		
		SSOGROUP_LOGIN_PROPERTIES=propertyFileLoader(GroupConstants.SSOGROUP_LOGIN);
		
		SIGNUP_PROPERTIES=propertyFileLoader(GroupConstants.CONSTANT_SIGNUP);
		
		HONEYBEE_PROPERTIES=propertyFileLoader(GroupConstants.CONSTANT_HONEYBEE);
	}

	
	
}
