package com.ipru.groups.utilities;

import static com.tcs.configuration.Environment.HELPER;
import static com.tcs.PropertyLoader.PropertyLoader.configdirectory;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.tcs.logger.FLogger;

public final class GroupConstants {

	private static Properties group_propertyinstance;
	
//	public final static String CONSTANT_C ="D://NomineeUpdateWorkspace/GroupsIPruConfig";
//	public final static String CONSTANT_ENVIRONMENT="UAT";
	
	
	
	public final static String CONSTANT_C =configdirectory;
	//public final static String CONSTANT_C ="D:/maven_workspace/groups/local-uat/GroupsIPruConfig";
	public final static String CONSTANT_ENVIRONMENT=System.getProperty("ENV");
//	public final static String CONSTANT_ENVIRONMENT="UAT";
	

	public final static String CONSTANT_ENV_DOC_PATH = HELPER.getFilePath(CONSTANT_ENVIRONMENT);
	
	public final static String CONSTANT_LDAP_LOGIN = CONSTANT_C+ "/ldapAutoLogin.properties";

	public final static String CONSTANT_CACHE_MODE_TERACOTTA = CONSTANT_C+ "/CacheConfig/CachingMode.properties";

	public final static String CONSTANT_EXCEPTION_CODE=CONSTANT_C+ "/Exception.properties";
	
	public final static String CONSTANT_CACHE_JAXBCONTEXT = CONSTANT_C+ "/WebserviceClient/jaxbInstance.properties";
	
	
	public static final String CONSTANT_IPRUCONFIG_CONSTANTS =CONSTANT_C+ "/constants.properties";
	
	public static final String CONST_TABLET_IPRUCONFIG_CONSTANTS = CONSTANT_C + "/tabletLogin.properties";
	
	public final static String CONSTANT_OTC = CONSTANT_C+ "/OTC.properties";
	public final static String CONSTANT_IPRUCONFIG_APPFRM_TITLES = CONSTANT_C+ "/appTitles.properties";
	
	public final static String CONSTANT_BULKSMS_WSCLIENT_PROPERTIES = CONSTANT_C+ "/SendSmsWSClient.properties";
	
	public static final String CONSTANT_FILE_UPLOAD = CONSTANT_C + "/fileUpload.properties";
	
	public final static String CONSTANT_IPRUCONFIG_IPADDRESS = CONSTANT_C+ "/ipAddress.properties";
	
	public static final String CONSTANT_CSRFURL_PROPERITIES=CONSTANT_C+ "/csrfURL.properties";
	
	public static final String CONSTANT_SERVER_PATH = CONSTANT_C+ "/serverPath.properties";
	
	public static final String CONSTANT_TEMPLATE_PROP = CONSTANT_C + "/Group/templates.properties";
	
	public static final String CONSTANT_DOCUMENT_UPLOAD_PATH = CONSTANT_ENV_DOC_PATH+"/"+getPathFromProperty("CONSTANT_group_upload_docs");
	
	public static final String CONSTANT_DOCUMENT_UPLOADDOC_PATH = getPathFromProperty("CONSTANT_group_upload_docs");
	
	public static final String CONSTANT_IPRUCONFIG_THIRDPARTY_CONSTANTS =CONSTANT_C+ "/thirdePartyConstants.properties";
	
	public static Properties CONSTANT_WEBSERVICES_URI_PROPERTIES = null;
	
	public static final String CONSTANT_IPRUCONFIG_LDAP =CONSTANT_C+ "/ldap.properties";
	
	public static final String CONSTANT_NOMINEEUPDATE=CONSTANT_C+ "/NomineeUpdatePojoData.properties";
	
	
	public static final String CONSTANT_TRACKER=CONSTANT_C+ "/TrackerStatus.properties";
	public static final String CONSTANT_PROFILEUPLOAD=CONSTANT_C+ "/profileUpdate.properties";
	
	public static final String CONSTANT_SERVICEWEBPAGE_LENGTH = CONSTANT_C + "/serviceWebPageLength.properties";
    
	public static final String CONFIG_PROPERTIES = CONSTANT_C+"/Configuration.properties";

	public final static String CONSTANT_ESB=CONSTANT_C+"/ESB.properties";
	public final static String VersionFile=CONSTANT_C+"/Version.properties";
	public static final String CONSTANT_IPADDRESS_OBTAINED_MAPPING = CONSTANT_C+"/domainName.properties";
	
	public static final String CONSTANT_EMAIL_SMS_CMPGN=CONSTANT_C+ "/emailSMSCampaign.properties";
	public final static String CONSTANT_USER_VO = CONSTANT_C+ "/UserVo.properties";
	
	public static final String CONTENT_SECURITY_POLICY_PROPERTIES = CONSTANT_C + "/contentSecurityConfi.properties";
	
	public static final String CONSTANT_WHITELISTURL_XSS_PROPERTIES = CONSTANT_C + "/whitelisturlxss.properties";
	
	public final static String CONSTANT_USER_MGMT_PROPERTIES = CONSTANT_C + "/userManagement.properties"; // Added for User Management
	
	public static final String CONSTANT_JCRYPTION_URL_MAPPING = CONSTANT_C + "/Group/JcryptionUrl.properties"; // Added
	public static final String INVALIDTAE_SESSION = "invalidate";
	
	public static final String CONTINUE_SESSION = "continue";
	
	public static final String CONSTANT_SEND_OTP = CONSTANT_C + "/SendOtpProperties.properties";
	
	
	// Added by Sidana for OTP
	public final static String CONSTANT_OTP_MANAGER_MAPPING=CONSTANT_C+ "/group_otpmanager.properties";
	//public final static String CONSTANT_CACHE_JAXBCONTEXT = CONSTANT_C+ "/CacheConfig/jaxbInstance.properties";	
	
	// Added by Sidana for Spaarc Call Log Scheduler
	public static final String CONSTANT_SPAARC_OBJECT_DOCS_PATH = CONSTANT_ENV_DOC_PATH +"/"+getPathFromProperty("CONSTANT_SPAARC_OBJECT_DOCS");
	
	public static final String CONSTANT_SPAARC_OBJECT_DOCS_PATH_NEW = getPathFromProperty("CONSTANT_SPAARC_OBJECT_DOCS");

	
	public static final String CONSTANT_PMJJBY_DOCS_PATH = CONSTANT_ENV_DOC_PATH +"/"+getPathFromProperty("CONSTANT_pmjjby_upload_docs");
	
	public static final String REST = CONSTANT_C + "/Group/Rest.properties";
	
	
	public static final String CONSTANT_FUND_PERFORMANCE_WS = CONSTANT_C + "/Group/fundPerformance.properties";
	
	
	public static final String DIGITAL_WEBSERVICE = CONSTANT_C + "/Group/DigitalWebService.properties";
	
	public static final String CONSTANT_EMAILMOBILE = CONSTANT_C + "/Group/otpEmailMobileLength.properties";
	
	public static final String CONSTANT_WEBSERVICE = CONSTANT_C + "/WebserviceClient/webserviceclient.properties";
	

	
	public static final String CONSTANT_SPAARC_PROP = CONSTANT_C + "/Group/spaarcDetails.properties";
	
	public static final String CONSTANT_PMJJBY=CONSTANT_C+ "/constantPMJJBY.properties";
	
	public static final String CONSTANT_SWITCHTRACKER=CONSTANT_C+ "/constantswitchTracker.properties";
	
	public static final String CONSTANT_NONDEATH_CLAIMEMAILSEND=CONSTANT_C+"/nonDeathClaimEmailsend.properties";
	
	
	public static final String CONSTANT_NONDEATH_EXCELVALIDATION=CONSTANT_C+"/excelValidationSchedular.properties";
	
	
	public static final String CONSTANT_BROKER=CONSTANT_C+"/brokerPortal.properties";
	
	public static final String SSOGROUP_LOGIN=CONSTANT_C+"/SSOGroupLogin.properties";

	public static final String CONSTANT_RESET_PASSWORD = CONSTANT_C+"/resetPassword.properties";
	
	public static final String CONSTANT_SIGNUP=CONSTANT_C+"/SignUp.properties";
	
	public static final String CONSTANT_HONEYBEE = CONSTANT_C +"/honeybeesftp.properties";
	
	
	public static String getPathFromProperty(String keyValue) {
		String path = "";
		FileInputStream fis=null;
		if (group_propertyinstance == null) {
			group_propertyinstance = new Properties();
			try {
				fis=new FileInputStream(CONSTANT_TEMPLATE_PROP);
				group_propertyinstance.load(fis);

			}
			catch (FileNotFoundException e) {
			
				FLogger.error("GROUPLogger", "MasterPropertiesFileLoader", "getProperties(Properties prop,String path)",e.getMessage());
				
			}
			catch (IOException e) {
				
				FLogger.error("GROUPLogger", "MasterPropertiesFileLoader", "getProperties(Properties prop,String path)","",e);
			}
			finally {
			try {
				if(fis!=null)
					fis.close();
			}
			catch (Exception e) {
				FLogger.error("GROUPLogger", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
						"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
				e.printStackTrace();
			} finally {
				fis=null;
			}
			}
			
		}
		path = group_propertyinstance.getProperty(keyValue);
		return path;
	}
	
	
	
	
}
