package com.ipru.groups.utilities;

import java.io.UnsupportedEncodingException;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.StringUtils;

public class EncodingUtility {
	public static final String CONSTANT_DOCUMENT_PATH_ENCRYPTION_KEY = "tSuop678hdegncJDFHFNSJWJDFFUROQW8384JFJCNDHSJ";
	public static String encodeBase64(String input) {
		byte[] inputBytes = input.getBytes();
		return DatatypeConverter.printBase64Binary(inputBytes);
	}

	public static String decodeBase64(String input) throws UnsupportedEncodingException {
		byte[] inputBytes = null;
		String result = null;
		if (StringUtils.isNotEmpty(input) && StringUtils.isNotBlank(input)) {
			inputBytes = DatatypeConverter.parseBase64Binary(input);
			result = new String(inputBytes, "UTF-8");
		}
		return result;

	}
	
	public static void main(String a)
	{
		String res = EncodingUtility.encodeBase64("D:\\Image\\Groups\\Digital Life Verification");	
		System.out.println("-----"+res);	
	}
		
}
