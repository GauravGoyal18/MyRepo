
package com.ipru.groups.utilities;

import java.io.FileInputStream;
import java.util.Properties;

import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;

public class GroupMasterPropertiesFileLoader {

	
	public static Properties CONSTANT_FILE_UPLOAD_PROPERTIES = null;
	

	public static void loadMasterPropertiesFile() throws ServiceException {

		// TODO Auto-generated constructor stub
		// loading static properties files
		
		CONSTANT_FILE_UPLOAD_PROPERTIES = propertyFileLoader(GroupConstants.CONSTANT_FILE_UPLOAD);
		
	}

	public static Properties propertyFileLoader(String fileName) throws ServiceException {
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream(fileName));
		}
		catch (Exception e) {
			FLogger.debug("GROUPLogger", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)", "Exception Ocurred: " + e.getMessage());
			GroupCommonUtils.logException("GROUPLogger", "CsrMasterPropertiesFileLoader", "propertyFileLoader", "Exception..", e);

			throw new ServiceException("5000");
		}
		return prop;
	}


}

