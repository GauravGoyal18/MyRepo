package com.ipru.groups.utilities;

/**
 * Sneha Pawar
 * 
 * @author IPRU24171 Interface for previledges to check it has read access or
 *         not
 */

public interface PreviledgeInterface {
	String getPriviledgeValue();
}
