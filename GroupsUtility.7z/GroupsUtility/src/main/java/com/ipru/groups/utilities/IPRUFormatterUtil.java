package com.ipru.groups.utilities;

/**
 * IPRUFormatterUtil.java is a utility class used to perform basic utility
 * functions required in the various methods . It is a wrapper class which is
 * used for basic formatting, date conversions , data type conversions etc .
 */

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

public final class IPRUFormatterUtil {

	private static final String ONLY_NUMBER_REGEX = "[0-9]+";

	public IPRUFormatterUtil() {
	}

	/**
	 * This method takes a string as an argument.It checks whether the String
	 * value equal to ' null '. If so , it assigns "" value to the String . If
	 * not , it uses the trim() and returns the trimmed String back to the
	 * calling method . It is advisable that every String inputed must use this
	 * method so as to avoid NullPointerException.
	 * 
	 * @param:String
	 * @return:String containing formatted String
	 */
	public static String convertStringToNotNull(String strInputString) {

		String l_strOutputString = ""; /*
										 * String to be given back to the
										 * calling method
										 */

		if (strInputString != null) /*
									 * Checks if the inputed String is null or
									 * not
									 */
		{
			l_strOutputString = strInputString.trim(); /*
														 * Trims the value of
														 * string
														 */
			if (l_strOutputString.contains("\'")) {
				l_strOutputString = l_strOutputString.replaceAll("\'", "''");
			}
		}

		return l_strOutputString;
	}

	// End of convertStringToNotNull

	/**
	 * This method takes a string as an argument. It checks whether the String
	 * is null or not. If not, it parses the integer value present in the String
	 * to appropriate integer value .Checks for NumberFormatException . In case
	 * of NumberFormatException ,it returns back Integer.MIN_VALUE
	 * 
	 * @param: String
	 * @return int parsed integer value
	 */
	public static int parseIntegerUtil(String strInputString) {

		int l_iOutputVal = Integer.MIN_VALUE; // Assign minimum value to the
												// temporary local variable

		String l_strMidString = convertStringToNotNull(strInputString);  // Check
																		// for
																		// not
																		// null

		try {
			l_iOutputVal = Integer.parseInt(l_strMidString);  // Parse the String
																// to integer
																// value
		}
		catch (NumberFormatException objNumberFormatException) {
			// CRLoggerUtil.logMessage(CRLoggerUtil.getExceptionStackTrace(objNumberFormatException),
			// CRFormatHandlerUtil.getCurrentMethodName(), 'X');
			l_iOutputVal = Integer.MIN_VALUE;
		}
		finally {
			// Do Nothing
		}

		return l_iOutputVal;
	}

	// End of parseIntegerUtil

	/**
	 * This method takes a string as an argument. It checks whether the String
	 * is null or not. If not, it parses the long value present in the String to
	 * appropriate long value .Checks for NumberFormatException . In case of
	 * NumberFormatException ,it returns back Long.MIN_VALUE
	 * 
	 * @param : String
	 * @value : long parsed long value
	 */
	public static long parseLongUtil(String strInputString) {

		long l_lOutputVal = Long.MIN_VALUE; // Assign minimum value to the
											// temporary local variable

		String l_strMidString = convertStringToNotNull(strInputString);  // Check
																		// for
																		// not
																		// null

		try {
			l_lOutputVal = Long.parseLong(l_strMidString);  // Parse the String
															// to long value
		}
		catch (NumberFormatException objNumberFormatException) {
			// CRLoggerUtil.logMessage(CRLoggerUtil.getExceptionStackTrace(objNumberFormatException),
			// CRFormatHandlerUtil.getCurrentMethodName(), 'X');
			l_lOutputVal = Long.MIN_VALUE;
		}
		finally {
			// Do Nothing
		}

		return l_lOutputVal;
	}

	// End of parseLongUtil

	/**
	 * This method takes a string as an argument. It checks whether the String
	 * is null or not. If not, it parses the float value present in the String
	 * to appropriate float value .Checks for NumberFormatException . In case of
	 * NumberFormatException ,it returns back Float.MIN_VALUE
	 * 
	 * @param: String
	 * @return: float parsed float value
	 */
	public static float parseFloatUtil(String strInputString) {

		float l_fOutputVal = Float.MIN_VALUE; // Assign minimum value to the
												// temporary local variable

		String l_strMidString = convertStringToNotNull(strInputString);  // Check
																		// for
																		// not
																		// null

		try {
			l_fOutputVal = Float.parseFloat(l_strMidString);  // Parse the String
																// to float
																// value
		}
		catch (NumberFormatException objNumberFormatException) {
			// CRLoggerUtil.logMessage(CRLoggerUtil.getExceptionStackTrace(objNumberFormatException),
			// CRFormatHandlerUtil.getCurrentMethodName(), 'X');
			l_fOutputVal = Float.MIN_VALUE;
		}
		finally {
			// Do Nothing
		}

		return l_fOutputVal;
	}

	// End of parseFloatUtil

	/**
	 * This method takes a string as an argument. It checks whether the String
	 * is null or not. If not, it parses the double value present in the String
	 * to appropriate double value .Checks for NumberFormatException . In case
	 * of NumberFormatException ,it returns back Double.MIN_VALUE
	 * 
	 * @param : String
	 * @return : double parsed double value
	 */
	public static double parseDoubleUtil(String strInputString) {

		double l_dOutputVal = Double.MIN_VALUE; // Assign minimum value to the
												// temporary local variable

		String l_strMidString = convertStringToNotNull(strInputString);  // Check
																		// for
																		// not
																		// null

		try {
			l_dOutputVal = Double.parseDouble(l_strMidString);  // Parse the
																// String to
																// double value
		}
		catch (NumberFormatException objNumberFormatException) {
			// CRLoggerUtil.logMessage(CRLoggerUtil.getExceptionStackTrace(objNumberFormatException),
			// CRFormatHandlerUtil.getCurrentMethodName(), 'X');
			l_dOutputVal = Double.MIN_VALUE;
		}
		finally {
			// Do Nothing
		}

		return l_dOutputVal;
	}

	// End of parseDoubleUtil

	/**
	 * This method takes as an input , a String and parses out the first
	 * character from it in UPPERCASE.
	 * 
	 * @param : String
	 * @return : char
	 */
	public static char parseCharUtil(String strInputString) {

		char l_cCharacter = 0;
		if (strInputString.length() == 1) {
			// Get the character from the String which will be default at
			// position 0
			l_cCharacter = strInputString.charAt(0);
		}
		else {
			// Input the first character from the String assuming the convention
			// that 'Y' corresponds to Yes ,'N'corresponds to No etc
			// CRLoggerUtil.logMessage("Since the length of String is greater than 1 , I have no choice but to take its first character.",getCurrentMethodName(),'A');
			l_cCharacter = strInputString.charAt(0);
		}

		// Standardize the character to upper case .

		l_cCharacter = Character.toUpperCase(l_cCharacter);

		return l_cCharacter;
	}

	// End of method

	/**
	 * This method takes an input String and converts it into java.sql.Date
	 * format . It does all the validations such as not null and outputs the
	 * date in (DD/MM/YYYY) format It returns system date if String cannot be
	 * converted to date i.e. if String not inputed in DD/MM/YYYY format
	 * 
	 * @param : String
	 * @return : java.sql.Date which is date in dd/mm/yyyy format
	 */

	public static Date formatDateForDBInsert(String strInputString, String l_strDateFormat) {

		Date l_objOutputDate = null;
		String l_strMidString = "";
		SimpleDateFormat objSimpleDateFormat = null;

		l_strMidString = convertStringToNotNull(strInputString);

		objSimpleDateFormat = new SimpleDateFormat(l_strDateFormat);

		try {
			l_objOutputDate = new java.sql.Date(objSimpleDateFormat.parse(l_strMidString).getTime());
		}
		catch (ParseException objParseException) {

			// Since I could not do the parsing , I have no choice but to
			// default
			// Date value to system date.I am doing so to avoid exceptions which
			// may occur during
			// insertion of this date into database

			l_objOutputDate = new Date(System.currentTimeMillis()); // Get
																	// current
																	// system
																	// time
			try {
				l_objOutputDate = (Date) objSimpleDateFormat.parse(objSimpleDateFormat.format(l_objOutputDate)); // Converts
																													// system
																													// date
																													// int
																													// DD/MM/YYYY
																													// format

			}
			catch (ParseException l_objParseException2) {

			}
			finally {
				// Do Nothing
			}
		}
		finally {
			// Do Nothing
		}

		if (l_objOutputDate == null) {
			l_objOutputDate = new java.sql.Date(Calendar.getInstance().getTime().getTime());
		}

		return l_objOutputDate;
	}

	// End of formatDateForDBInsert

	/**
	 * This method takes as input java.sql.Date and returns the String in
	 * dd/mm/yyyy format
	 * 
	 * @param : java.sql.Date
	 * @param : String
	 * @return : String
	 */

	public static String convertDateToStringForDBInsert(java.sql.Date objDate, String l_strDateFormat) {

		java.sql.Date l_objOutputDate;
		String l_strMidString = "";
		SimpleDateFormat l_objSimpleDateFormat = null;

		if (objDate != null) {

			l_objSimpleDateFormat = new SimpleDateFormat(l_strDateFormat);

			try {
				l_strMidString = l_objSimpleDateFormat.format(objDate);
			}
			catch (Exception objException) {

				// Since I could not do the parsing , I have no choice but to
				// default
				// Date value to system date.I am doing so to avoid exceptions
				// which may occur during
				// insertion of this date into database

				l_objOutputDate = new Date(System.currentTimeMillis()); // Get
																		// current
																		// system
																		// time
				try {
					l_strMidString = l_objSimpleDateFormat.format(l_objOutputDate); // Converts
																					// system
																					// date
																					// into
																					// DD/MM/YYYY
																					// format
																					// String

				}
				catch (Exception objException2) {
					// Log in case of exception in case of format conversion of
					// system date

					// CRLoggerUtil.logMessage(CRLoggerUtil.getExceptionStackTrace(objException2),
					// CRFormatHandlerUtil.getCurrentMethodName(), 'X');
				}
				finally {
					// Do Nothing
				}
			}
			finally {
				// Do Nothing
			}
		}

		return l_strMidString;
	}

	// End of method

	/**
	 * This method takes as input java.sql.Timestamp and returns the String in
	 * dd-mm-yyyy format
	 * 
	 * @param : java.sql.Date
	 * @return : String
	 */

	public static String convertTimestampToStringForDBInsert(java.sql.Timestamp objTimestamp, String l_strDateFormat) {

		java.sql.Timestamp l_objOutputDate;
		String l_strMidString = "";
		SimpleDateFormat l_objSimpleDateFormat = null;

		if (objTimestamp != null) {

			l_objSimpleDateFormat = new SimpleDateFormat(l_strDateFormat);

			try {
				l_strMidString = l_objSimpleDateFormat.format(objTimestamp);
			}
			catch (Exception objException) {

				// Since I could not do the parsing , I have no choice but to
				// default
				// Date value to system date.I am doing so to avoid exceptions
				// which may occur during
				// insertion of this date into database

				l_objOutputDate = new Timestamp(System.currentTimeMillis()); // Get
																				// current
																				// system
																				// time
				try {
					l_strMidString = l_objSimpleDateFormat.format(l_objOutputDate); // Converts
																					// system
																					// date
																					// into
																					// DD/MM/YYYY
																					// format
																					// String

				}
				catch (Exception objException2) {
					// Log in case of exception in case of format conversion of
					// system date

					// CRLoggerUtil.logMessage(CRLoggerUtil.getExceptionStackTrace(objException2),
					// CRFormatHandlerUtil.getCurrentMethodName(), 'X');
				}
				finally {
					// Do Nothing
				}
			}
			finally {
				// Do Nothing
			}
		}

		return l_strMidString;
	}

	// End of method

	/**
	 * This method returns the current server system date in mm/dd/yyyy format
	 * String. This method can be used for age calculations.
	 * 
	 * @return String
	 */
	public static String getSysDateInString(String l_strDateFormat) {

		String strSysDate = "";
		java.util.Date l_objOutputDate;
		String l_strMidString = "";
		SimpleDateFormat objSimpleDateFormat = null;

		if (convertStringToNotNull(l_strDateFormat).equals("")) {
			l_strDateFormat = "dd/MM/yyyy";
		}

		l_objOutputDate = Calendar.getInstance().getTime();
		if (l_objOutputDate != null) {

			objSimpleDateFormat = new SimpleDateFormat(l_strDateFormat);

			try {
				l_strMidString = objSimpleDateFormat.format(l_objOutputDate);
			}
			catch (Exception objException) {

				// Since I could not do the parsing , I have no choice but to
				// default
				// Date value to system date.I am doing so to avoid exceptions
				// which may occur during
				// insertion of this date into database

				l_objOutputDate = new Date(System.currentTimeMillis()); // Get
																		// current
																		// system
																		// time
				try {
					l_strMidString = objSimpleDateFormat.format(l_objOutputDate); // Converts
																					// system
																					// date
																					// into
																					// DD/MM/YYYY
																					// format
																					// String

				}
				catch (Exception objException2) {
					// Log in case of exception in case of format conversion of
					// system date

					// CRLoggerUtil.logMessage(CRLoggerUtil.getExceptionStackTrace(objException2),
					// CRFormatHandlerUtil.getCurrentMethodName(), 'X');
				}
				finally {
					// Do Nothing
				}
			}
			finally {
				// Do Nothing
			}
		}

		return l_strMidString;

	}

	/**
	 * This is a static utility method which is used to get the JAVA server
	 * timestamp and return it back to the calling method which can then use the
	 * server timestamp for various purposes.The method returns the server time
	 * stamp accurate upto the seconds. eg :dd-MM-yyyy HH:mm:ss
	 * 
	 * @return String
	 */

	public static String getServerTimeStamp(String l_strTimestampFormat) {

		String l_strServerTimeStamp = "";
		// Create a calendar object of type gregorian calendar
		Calendar l_objCalendar = new GregorianCalendar();
		// Define the formatter string in appropriate format to convert the date
		// to the
		// String format

		if (convertStringToNotNull(l_strTimestampFormat).equals("")) {
			l_strTimestampFormat = "dd-MM-yyyy HH:mm:ss";
		}
		Format l_objFormatter = new java.text.SimpleDateFormat(l_strTimestampFormat);

		// Used to add the calendar date object into the calendar
		l_objCalendar.add(Calendar.DATE, 0);
		// Used to format the date object into the appropriate String format
		l_strServerTimeStamp = l_objFormatter.format(l_objCalendar.getTime());

		return l_strServerTimeStamp;
	}

	/**
	 * This is a static utility method which is used to get the JAVA server
	 * timestamp object and return it back to the calling method which can then
	 * use the server timestamp for various purposes.This method is useful for
	 * entering the java timestamp especially for database insertion
	 * operations.The method returns the server time stamp accurate upto
	 * milliseconds.
	 * 
	 * @return Timestamp
	 */

	public static Timestamp getServerTimeStampObject() {

		// Declare the java server timestamp reference
		Timestamp l_objServerTimeStamp = null;

		// Generate the new timestamp object by passing the current millisecond
		// time as an argument in the
		// constructor to return the timestamp object which can then be directly
		// saved in the database
		l_objServerTimeStamp = new Timestamp(System.currentTimeMillis());

		// Return the timestamp object
		return l_objServerTimeStamp;
	}

	/**
	 * This method is a utility method which is used to convert the inputted
	 * date which is in form of the string into SQL Date.This method returns
	 * java.sql.Date and if the string returns the error.
	 * 
	 * @param : java.sql.Date
	 * @return : String
	 * @throws ParseException
	 */

	public static java.sql.Date convertStringToDateForDBInsert(String l_strInputDate, String l_strDateFormat) throws ParseException {

		java.sql.Date l_objOutputDate = null;

		SimpleDateFormat l_objSimpleDateFormat = null;

		if (!convertStringToNotNull(l_strInputDate).equalsIgnoreCase("") && !convertStringToNotNull(l_strInputDate).equalsIgnoreCase("-")) {

			l_objSimpleDateFormat = new SimpleDateFormat(l_strDateFormat);

			try {
				l_objOutputDate = new java.sql.Date(l_objSimpleDateFormat.parse(l_strInputDate).getTime());
			}
			catch (ParseException l_objException) {

				throw l_objException;
			}
			finally {
				// Do Nothing
			}
		}

		return l_objOutputDate;
	}

	// End of method

	/**
	 * This function is used to generate the hash value of a String based on a
	 * certain internal hash generation algorithm.
	 * 
	 * @param The
	 *            String whose hash is to be generated
	 * @return The hash value of the passed String
	 */
	public static String getStringHash(String l_strOriginalValue) throws NoSuchAlgorithmException {
		// Log Message

		// Initializations
		String l_strHash = "";
		MessageDigest l_objMessage = null;

		l_objMessage = MessageDigest.getInstance("MD5");
		l_objMessage.update(l_strOriginalValue.getBytes(), 0, l_strOriginalValue.length());
		l_strHash = new BigInteger(1, l_objMessage.digest()).toString(16);

		return l_strHash;
	}

	/**
	 * This function is used to get Timestamp as a String in dd-mm-yyyy HH:mm:ss
	 * format
	 * 
	 * @param l_objTimestamp
	 * @return The Timestamp as a formatted String
	 */
	public static String getFormattedDateAsStringFromTimestamp(java.sql.Timestamp l_objTimestamp) {
		String l_strTimestamp = "";

		String l_strDate = "";
		String l_strTime = "";

		l_strDate = l_objTimestamp.toString().split(" ")[0];
		l_strTime = l_objTimestamp.toString().split(" ")[1];

		l_strTimestamp = l_strDate.split("-")[2] + "-" + l_strDate.split("-")[1] + "-" + l_strDate.split("-")[0] + " " + l_strTime;

		return l_strTimestamp;
	}

	/**
	 * Function to convert the amount to comma separated amount
	 * 
	 * @param l_strInputAmountToFormat
	 * @return l_strFormattedAmount
	 */
	public static String formatAmount(String l_strInputAmountToFormat) {

		boolean l_boolMinusAmount = false;
		String l_strMinusSeperateAmount = "";
		if (l_strInputAmountToFormat.contains("-")) {
			l_strMinusSeperateAmount = l_strInputAmountToFormat.split("-")[1];

			l_boolMinusAmount = true;
			l_strInputAmountToFormat = l_strMinusSeperateAmount;

		}

		String[] l_strSplitAmount = null;
		String l_strAmountToFormat = "";
		String l_strSplittedAmount = "";
		int l_icount;
		String l_strFormattedAmount = "";

		if (l_strInputAmountToFormat.contains(".")) {

			l_strSplitAmount = l_strInputAmountToFormat.split("\\.");

			l_strSplittedAmount = l_strSplitAmount[0];

			l_strAmountToFormat = l_strSplittedAmount;
		}
		else {
			l_strAmountToFormat = l_strInputAmountToFormat;
		}

		int i_lLength = l_strAmountToFormat.length();

		if (i_lLength > 3) {
			if (i_lLength > 5) {
				if (i_lLength % 2 == 0)
					l_icount = 0;

				else
					l_icount = 1;

				for (int i_lIndex = 0; i_lIndex < i_lLength - 3; i_lIndex++) {

					if (l_icount % 2 == 0)
						l_strFormattedAmount += l_strAmountToFormat.charAt(i_lIndex) + ",";
					else
						l_strFormattedAmount += l_strAmountToFormat.charAt(i_lIndex);
					l_icount++;
				}

				l_strFormattedAmount += l_strAmountToFormat.substring(i_lLength - 3, i_lLength);

			}

			else {

				l_strFormattedAmount += l_strAmountToFormat.substring(0, i_lLength - 3) + "," + l_strAmountToFormat.substring(i_lLength - 3, i_lLength);

			}

		}
		else
			l_strFormattedAmount = l_strAmountToFormat;

		if (l_strInputAmountToFormat.contains("."))
			l_strFormattedAmount = l_strFormattedAmount + "." + l_strSplitAmount[1];

		if (l_boolMinusAmount)
			l_strFormattedAmount = "-" + l_strFormattedAmount;

		return l_strFormattedAmount;
	}

	/**
	 * Function to get the difference between two Dates.
	 * 
	 * @param l_objDate1
	 * @param l_objDate2
	 * @return l_dDays
	 */
	public static double checkDaysBetweenTwoDates(java.sql.Date l_objDate1, java.sql.Date l_objDate2) throws ParseException {

		l_objDate1 = IPRUFormatterUtil.convertStringToDateForDBInsert(IPRUFormatterUtil.convertDateToStringForDBInsert(l_objDate1, "dd/MM/yyyy"), "dd/MM/yyyy");
		l_objDate2 = IPRUFormatterUtil.convertStringToDateForDBInsert(IPRUFormatterUtil.convertDateToStringForDBInsert(l_objDate2, "dd/MM/yyyy"), "dd/MM/yyyy");

		double l_dDays = 0;
		double l_dOneDayValue = 1000 * 60 * 60 * 24;

		l_dDays = Math.floor((l_objDate2.getTime() - l_objDate1.getTime()) / (l_dOneDayValue));

		return l_dDays;
	}

	// END OF METHOD

	public static String getFieldValueFromSerializedForm(String l_strFieldId, String l_strSerializedForm) {
		String l_strFieldValue = "";

		if (l_strSerializedForm != null) {
			if (!l_strSerializedForm.equalsIgnoreCase("null")) {
				int l_iIndexOfFieldId = l_strSerializedForm.indexOf(l_strFieldId);
				int l_iIndexOfNextEqualTo = l_strSerializedForm.indexOf("=", l_iIndexOfFieldId);
				int l_iIndexOfNextAmpersand = l_strSerializedForm.indexOf("&", l_iIndexOfFieldId);
				l_strFieldValue = l_strSerializedForm.substring((l_iIndexOfNextEqualTo + 1), l_iIndexOfNextAmpersand);
			}
		}

		return l_strFieldValue;
	}

	// END OF METHOD

	/**
	 * This method is used to find out whether the transaction that is being
	 * sent is of the digitization type or not. For digitization integration,we
	 * have incorporated 3 flags - B,S,A.
	 */
	public static boolean isDigitizationFlag(String digitizationFlag) {
		// Declare local variables here
		String[] digiArray = new String[] { "B", "S", "A", "D" }; // Accepted
																	// digitization
																	// flags
		boolean isDigiFlag = false; // Digi flag to send boolean value back to
									// calling method

		// Clean up code
		digitizationFlag = IPRUFormatterUtil.convertStringToNotNull(digitizationFlag);

		// Iterate on flags. If flag value matches, send true
		for (int l_iCounter = 0; l_iCounter < digiArray.length; l_iCounter++) {
			if (digitizationFlag.equalsIgnoreCase(digiArray[l_iCounter])) {
				isDigiFlag = true;
				break;
			}
		}

		return isDigiFlag;
	}

	// End of method

	/**
	 * This method is a static utility method used for formatting the amount ie.
	 * usually into string in the appropriate form required by the calling
	 * method. The user must define the format type in order to utilize this
	 * method
	 * 
	 * @param String
	 * @param String
	 * @return String
	 */
	public static String getFormattedAmountNew(String strInputString, String strFormatType) {
		String strFormattedString = "";
		double dInputString = Double.parseDouble(strInputString);
		NumberFormat formatter = new DecimalFormat(strFormatType);
		strFormattedString = formatter.format(dInputString);
		return strFormattedString;
	}

	// End of method

	/**
	 * This method is a public static method which formats the input address
	 * component and fits to a particular max address fields in a row. This
	 * method internally calls an offset manager method which adjusts the offset
	 * in order to avoid cutting words. This method also takes a displacement
	 * variable and returns a formatted address.
	 * 
	 * @param String
	 * @param int
	 * @return String
	 */
	public static String getFormattedAddressComponent(String strInputString, int iDisplacement) {
		strInputString = IPRUFormatterUtil.convertStringToNotNull(strInputString);

		// ////System.out.println("Input length "+ strInputString.length());

		if (strInputString.length() > iDisplacement) {
			String strLocalString = "";
			int iOffset = 0;
			for (; strInputString.length() > iOffset;) {

				int iTempOffset = iOffset + iDisplacement;
				int extraOffset = 0;

				if (iTempOffset < strInputString.length())
					extraOffset = findNextSpaceOffset(strInputString.substring(iTempOffset, strInputString.length()), ' ');

				// ////System.out.println("Offset "+(iOffset+iDisplacement));

				if (strLocalString.equals("")) {
					strLocalString = IPRUFormatterUtil.convertStringToNotNull(strInputString.substring(iOffset, iDisplacement))
							+ IPRUFormatterUtil.convertStringToNotNull(strInputString.substring(iTempOffset, iTempOffset + extraOffset));
				}
				else {
					if ((strInputString.length() - iOffset) > iDisplacement) {
						strLocalString = strLocalString + "\n" + IPRUFormatterUtil.convertStringToNotNull(strInputString.substring(iOffset, iTempOffset))
								+ IPRUFormatterUtil.convertStringToNotNull(strInputString.substring(iTempOffset, (iTempOffset + extraOffset)));
					}
					else {
						strLocalString = strLocalString + "\n" + IPRUFormatterUtil.convertStringToNotNull(strInputString.substring(iOffset, strInputString.length()));
					}
				}

				iOffset = iTempOffset + extraOffset;
				// ////System.out.println("Diff " +(strInputString.length() -
				// iOffset));
			}

			strInputString = strLocalString;
		}

		return strInputString;
	}

	// End of method

	/**
	 * This method is a public utility method which will find the next special
	 * character in a particular string This method takes the string and the
	 * special character to be searched and returns its offset value back to the
	 * calling method.
	 * 
	 * @param strRemainingString
	 * @return
	 */
	public static int findNextSpaceOffset(String strRemainingString, char cSpecialCharacter) {
		char[] splittedString = strRemainingString.toCharArray();
		int counter = 0;

		for (char c : splittedString) {
			if (c == cSpecialCharacter) {
				break;
			}
			counter++;
		}
		// ////System.out.println("Counter Value : " +counter);
		return counter;
	}

	// End of method
	/**
	 * Added by Ajay
	 * 
	 * @param numberString
	 * @param precision
	 */
	public static String precisionFormat(String numberString, int precision) {

		double f = Double.parseDouble(numberString);
		String returnVal = String.format("%." + precision + "f", new BigDecimal(f));
		return returnVal;
	}

	public static void main(String args[]) throws Exception {
		//System.out.println();
	}

	/**
	 * Method to make the string not null and remove the spaces which are
	 * present as string parameter in bean. This method takes a generic type as
	 * argument find all the string fields and convert it to not null and remove
	 * the spaces if present.
	 * 
	 * @author VivekGrewal554674(TCS)
	 * @param obj
	 * @return T (that is bean whose parameters has to be trimmed)
	 */
	public static <XYZ> XYZ trimSpacesOfBean(XYZ obj) {
		@SuppressWarnings("unchecked")
		Class<XYZ> beanClass = (Class<XYZ>) obj.getClass();
		Field[] fields = beanClass.getDeclaredFields();
		for (Field field : fields) {
			if (field.getType() == String.class) {
				String fieldName = field.getName().substring(0, 1).toUpperCase() + field.getName().substring(1);
				Method getterMethod = null;
				Method setterMethod = null;
				try {
					getterMethod = beanClass.getDeclaredMethod("get" + fieldName);
					String parameter = (String) getterMethod.invoke(obj);
					setterMethod = beanClass.getDeclaredMethod("set" + fieldName, String.class);
					setterMethod.invoke(obj, convertStringToNotNull(parameter));
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
			else
				continue;
		}
		return obj;
	}

	/**
	 * Method to check for number it will return true if str is a positive
	 * number else it will return false
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isPositiveNumber(String str) {
		try {
			double d = Double.parseDouble(str);
			if (d < 0)
				return false;
		}
		catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

	public static boolean isNumber(String value) {
		if (StringUtils.isNotBlank(value) && value.trim().matches(ONLY_NUMBER_REGEX)) {
			return true;
		}
		else {
			return false;
		}
	}

	public static String[] getValuesSeparatedByComas(String policysWithComaSeprate) {
		String[] policyNumbers = null;
		if (policysWithComaSeprate != null && !policysWithComaSeprate.equals(""))
			policyNumbers = policysWithComaSeprate.split(",");

		return policyNumbers;
	}

	/**
	 * It format add comma in inputed currency.
	 * 
	 * @param number
	 * @return
	 */
	public static String formatCurrency(String number) {
		if (number != null && number != "" && !number.trim().equalsIgnoreCase("null")) {

			String s = "";
			String ammount = number;
			boolean flag = false;
			String fraction = "";

			if (ammount.contains(".")) {
				fraction = ammount.substring(ammount.indexOf('.'));
				s = ammount.substring(0, ammount.indexOf('.'));
				flag = true;

			}
			else {
				s = ammount;
			}
			if (s.length() <= 3) {
				return s + fraction;

			}

			StringBuilder aux1 = new StringBuilder("");
			StringBuilder aux3 = new StringBuilder("");
			StringBuilder aux4 = new StringBuilder("");

			int j = 0;
			for (int i = 0; i < s.length() - 3; i++) {
				aux1.append(s.charAt(i));
			}

			int k = aux1.length() - 1;
			for (int i = 0; i < aux1.length(); i++) {

				if (j < 2) {
					aux3.append(aux1.charAt(k));
					j++;
					--k;
				}
				else {
					aux3.append(",");
					--i;
					j = 0;
				}
			}

			aux3.reverse();

			// FOR ,000
			for (int i = (s.length() - 3); i < s.length(); i++) {
				aux4.append(s.charAt(i));
			}

			aux3.append("," + aux4);

			ammount = aux3 + fraction;
			flag = false;

			return ammount;
		}
		else {
			return "-";
		}

	}

	/**
	 * This method convert set precision for input string
	 * 
	 * @param inputString
	 * @param precisionCount
	 * @return
	 */
	public static String precisionFormatOld(String inputString, int precisionCount) {
		Double tempDouble = 0.00;
		Double precisionDouble = 0.00;
		String precisionString = "";
		String decimalFormat = "#.";

		if (!("" + inputString).equalsIgnoreCase("null")) {
			try {
				for (int count = 0; count < precisionCount; count++) {
					decimalFormat += "#";
				}
				DecimalFormat newFormat = new DecimalFormat(decimalFormat);
				tempDouble = Double.parseDouble(inputString);
				precisionDouble = Double.valueOf(newFormat.format(tempDouble));
				if (precisionCount == 0) {
					precisionString = "" + precisionDouble.intValue();
				}
				else {
					precisionString = precisionDouble.toString();
				}
				String fraction = "";
				if (precisionString.indexOf('.') != -1) {
					fraction = precisionString.substring(precisionString.indexOf('.') + 1, precisionString.length());
				}

				if (fraction != "" && fraction.length() != precisionCount) {
					String temp = "";
					while (fraction.length() != precisionCount) {
						temp = temp + "0";
						precisionCount--;
					}
					precisionString = precisionString + temp;
				}
				return precisionString;

			}
			catch (NumberFormatException e) {
				return precisionString = "";
			}
		}
		else {
			return "";
		}

	}

	/**
	 * This method convert set precision for input Double
	 * 
	 * @param number
	 * @param precision
	 * @return
	 */
	public static double precisionFormat(double number, int precision) {
		double prec = Math.pow(10, precision);
		int integerPart = (int) number;
		double fractionalPart = number - integerPart;
		fractionalPart *= prec;
		int fractPart = (int) fractionalPart;
		fractionalPart = (double) (integerPart) + (double) (fractPart) / prec;
		return fractionalPart;
	}

	/**
	 * It format name, convert initial letters capital
	 * 
	 * @param name
	 * @return
	 */
	public static String formatName(String name) {

		if (name != null && !("").equalsIgnoreCase(name) && !("null").equalsIgnoreCase(name) && !("-").equalsIgnoreCase(name)) {
			name = name.trim();
			name = name.toLowerCase();

			String[] nameArray;
			nameArray = name.split(" ");
			String temp = null;
			String temp1 = null;
			String temp2 = null;
			String formattedName = "";
			for (int i = 0; i < nameArray.length; i++) {
				temp = nameArray[i];
				temp1 = "";
				for (int j = 0; j < temp.length(); j++) {
					temp2 = temp.substring(j + 1, temp.length());
					if (!(".").equalsIgnoreCase(temp.substring(j, j + 1))) {
						temp1 = temp1 + (temp.substring(j, j + 1)).toUpperCase() + temp2;
						break;
					}
					else {
						temp1 = temp1 + temp.substring(j, j + 1);
					}
				}

				formattedName = formattedName + " " + temp1;
			}

			// ////System.out.println("name>>"+formattedName.trim());
			formattedName = formattedName.trim();
			formattedName = formattedName.replaceAll("\\.\\.", "");
			return formattedName.trim();
		}
		else {
			return "";
		}
	}

	public static List<String> trimSpacesInList(List<String> arrayList) {
		List<String> returnList = null;
		if (CollectionUtils.isNotEmpty(arrayList)) {
			for (String string : arrayList) {
				if (returnList == null) {
					returnList = new ArrayList<String>(1);
				}
				returnList.add(StringUtils.trim(string));
			}
		}
		return returnList;
	}

	public static String dateConvertor(String str_date) {
		String date4 = "";
		DateFormat formatter;
		if (!StringUtils.equalsIgnoreCase(str_date, "-")) {
			try {
				java.util.Date date3;
				formatter = new SimpleDateFormat("dd MMM yyyy");

				date3 = (java.util.Date) formatter.parse(str_date);
				SimpleDateFormat weekday = new SimpleDateFormat("yyyy-MM-dd");
				date4 = weekday.format(date3);
			}
			catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		else {
			date4 = "-";
		}
		return date4;
	}

	/**
	 * Method to generate xml from json
	 * 
	 * @author VivekGrewal(554674)
	 * @param json
	 * @return
	 */
	/*public static String toXml(String json) {
		JSONObject objJson = null;
		try {
			objJson = new JSONObject(json);
		}
		catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			return XML.toString(objJson);
		}
		catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
		 * XMLSerializer serializer=new XMLSerializer(); JSON jsonBean =
		 * serializer.read(json); return jsonBean.toString();
		 
	}*/

	/**
	 * Method to round a double with places after dot
	 * 
	 * @param valueString
	 * @param places
	 * @return
	 */
	public static String round(String valueString, int places) {
		double value = Double.parseDouble(valueString);
		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.toString();
	}

	@SuppressWarnings("deprecation")
	public static java.sql.Date getSwitchDate() {
		java.sql.Date switchDate = new java.sql.Date(System.currentTimeMillis());
		java.util.Date currentDateTime = new java.util.Date();
		java.util.Date expectedSwitchTime = new java.util.Date();
		expectedSwitchTime.setHours(15);
		expectedSwitchTime.setMinutes(0);
		expectedSwitchTime.setSeconds(0);
		if (currentDateTime.getTime() > expectedSwitchTime.getTime())
			switchDate.setDate(switchDate.getDate() + 1);
		return switchDate;
	}

	/**
	 * Helper method to get start date of Current Financial year based on
	 * current date.
	 * 
	 * @return
	 * @throws Exception
	 */
	public static java.util.Date getStartDate4CurrentFY() throws Exception {
		java.util.Date startFyDate = null;
		Calendar currentCal = Calendar.getInstance();
		currentCal.setLenient(false);
		// Determining start Date of Financial Year
		int startYr = 0;
		switch (currentCal.get(Calendar.MONTH)) {
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
				// Dec
				startYr = currentCal.get(Calendar.YEAR);
				break;
			case 0:
			case 1:
			case 2:
				// Mar
				startYr = currentCal.get(Calendar.YEAR) - 1;
				break;
			default:
				break;
		}

		if (startYr != 0) {

			String[] datePattern = new String[] { "dd/MM/yyyy" };
			try {
				startFyDate = DateUtils.parseDate("01/04/" + startYr, datePattern);
			}
			catch (ParseException e) {
				e.printStackTrace();
				throw e;
			}

		}
		return startFyDate;
	}

	/**
	 * Helper method to get end date of Current Financial year based on current
	 * date.
	 * 
	 * @return
	 * @throws Exception
	 */
	public static java.util.Date getEndDate4CurrentFY() throws Exception {
		Calendar currentCal = Calendar.getInstance();
		currentCal.setLenient(false);
		java.util.Date endFyDate = null;
		// Determining current Financial Year
		int endYr = 0;
		switch (currentCal.get(Calendar.MONTH)) {
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
				// Dec
				endYr = currentCal.get(Calendar.YEAR) + 1;
				break;
			case 0:
			case 1:
			case 2:
				// Mar
				endYr = currentCal.get(Calendar.YEAR);
				break;
			default:
				break;
		}

		if (endYr != 0) {

			String[] datePattern = new String[] { "dd/MM/yyyy" };
			try {
				endFyDate = DateUtils.parseDate("31/03/" + endYr, datePattern);
			}
			catch (ParseException e) {
				e.printStackTrace();
				throw e;
			}

		}
		return endFyDate;

	}

	/**
	 * This method gets presentDateFormat and convert it to the reqDateFormat.<br>
	 * 
	 * @param presentDateFormat
	 * @param reqDateFormat
	 * @param date
	 * @return String formattedDate
	 */
	public static String getFormattedDate(String presentDateFormat, String requiredDateFormat, String date) {
		if (StringUtils.isNotBlank(presentDateFormat) && StringUtils.isNotBlank(requiredDateFormat) && StringUtils.isNotBlank(date)) {
			SimpleDateFormat formatter = null;
			java.util.Date tatDate = null;
			String formattedDate = null;
			try {
				formatter = new SimpleDateFormat(presentDateFormat);
				tatDate = formatter.parse(date);
				formattedDate = DateUtil.formatDate(tatDate, requiredDateFormat);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			return formattedDate;
		}
		return null;
	}

	// MD5 to SHA256 Changes

	public static String convertToHex(byte[] data) {
		StringBuffer buf = new StringBuffer();

		try {
			for (int i = 0; i < data.length; i++) {
				int halfbyte = (data[i] >>> 4) & 0x0F;
				int two_halfs = 0;
				do {
					if ((0 <= halfbyte) && (halfbyte <= 9))
						buf.append((char) ('0' + halfbyte));
					else
						buf.append((char) ('a' + (halfbyte - 10)));
					halfbyte = data[i] & 0x0F;
				} while (two_halfs++ < 1);
			}
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
		return buf.toString();
	}

	public static Long getSecondsDifference(java.util.Date startDate, java.util.Date endDate) {
		 ////System.out.println("in getSecondsDifference method :: "+ startDate+ "  ::  " + endDate);
		
		if (startDate != null && endDate != null) {
			// in milliseconds
			Long diff = endDate.getTime() - startDate.getTime();
			////System.out.println("Diff : "+diff);
			return diff / 1000;
		}
		return null;
	}
}
// End of the class

