package com.ipru.groups.utilities;

public final class SessionKeyConstants {

	private SessionKeyConstants() {
		super();
	}

	public static final String CUSTOMER_SESSION_KEY = "csr_customerProfileObj";

	public static final String USER_SESSION_KEY = "userVO";

	public static final String POLICY_LIST_SESSION_KEY = "csr_policyList";

	public static final String CSR_CLIENT_ID_KEY = "csr_custId";

	public static final String POLICYPO_LIST_SESSION_KEY = "csr_policyListForDisplay";

	public static final String ROLE_SCR_ACCESS_MAP = "roleScreenAccessMap";

	public static final String CSR_OTP_VERFCN_STATUS = "CSR_OTP_VERFCN_STATUS";

	public static final String ROLES_RULES_MATRIX = "rolesRulesMatrix";

	public static final String CSR_FMS_ADVR_ADV_CODE_SEARCH = "csr_fms_advr_adv_code_search";

	public static final String CSR_FMS_MISC_RECP_SEARCH = "csr_fms_misc_recp_search";

	public static final String CSR_FMS_NEW_BIZ_RECP_SEARCH = "csr_fms_new_biz__recp_search";

	public static final String CSR_PAYMENT_SECURED_POST_FLAG = "csr_isSecuredPaymentEnable"; // Added
																								// by
																								// Hiren
																								// Sonawala
																								// for
																								// Maintaining
																								// Jcryption
																								// by
																								// Secured
																								// Post
																								// Flag

	public static final String SLBL_PAYMENT_SECURED_POST_FLAG = "slbl_isSecuredPaymentEnable";

	public static final String CSR_PASA_FLAG = "csr_pasaFlag";

	public static final String IS_CONTRACT_DETAILS_CALLED = "isContractDetailsCalled";

	public static final String CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED = "isTransactionOTPValid";

	public static final String PS_CSR_SOURCING_AGENT_ID = "ps_csr_sourcing_agnt_id";

	public static final String POLICY_DISPLAY_JSON = "policyDisplayJson";

	public static final String DISPLAY_LIST = "displayListDB";

	public static final String TRANSFEROFFUNDSBEAN = "TransferofFundsbean"; // Added
																			// by
																			// Hiren
																			// Sonawala
																			// for
																			// Discontinued
																			// Fund
																			// Reinvestment
}
