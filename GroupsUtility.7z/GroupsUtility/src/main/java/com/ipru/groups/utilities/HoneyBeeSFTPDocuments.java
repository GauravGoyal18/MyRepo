package com.ipru.groups.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.tcs.logger.FLogger;

public class HoneyBeeSFTPDocuments {

	private static final String CLASS_NAME = "HoneyBeeSFTPDocuments";
	private static HoneyBeeSFTPDocuments single_instance = null;
	
	private Properties prop = new Properties();

	public HoneyBeeSFTPDocuments() {
		try {
			if (MasterPropertiesFileLoader.HONEYBEE_PROPERTIES != null) {
				prop = MasterPropertiesFileLoader.HONEYBEE_PROPERTIES;
			} else {
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(GroupConstants.CONSTANT_HONEYBEE);
					prop.load(fis);
				} catch (Exception e) {
					FLogger.info(CLASS_NAME, "HoneyBeeSFTP", "HoneyBeeSFTP",
							"Exception occured while loading SIGNUP_PROPERTIES file");
				} finally {
					if (fis != null) {
						fis.close();
						fis = null;
					}
				}

			}
		} catch (FileNotFoundException e) {
			FLogger.info(CLASS_NAME, "HoneyBeeSFTP", "HoneyBeeSFTP",
					"File not found exception found at the time of loading properties",e);
			e.printStackTrace();
		} catch (IOException e) {
			FLogger.info(CLASS_NAME, "HoneyBeeSFTP", "HoneyBeeSFTP",
					"IOException found at the time of loading properties",e);
			e.printStackTrace();
		}
	}

	public  boolean uploadFileToSFTP(String LOGGER_NAME,String srcPath,String contractId)
	{
		Boolean flag =false;
		final String METHOD_NAME = "uploadFileToSFTP";
		FLogger.info(LOGGER_NAME,CLASS_NAME,METHOD_NAME,"Method Start");
		int port =Integer.parseInt(prop.getProperty("SFTPPORT"));
		JSch jsch = new JSch();
        Session session = null;
        try {
            session = jsch.getSession(prop.getProperty("AUTHKEY"),prop.getProperty("SFTPHOST"),port);
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.setPassword(prop.getProperty("AUTHVAL"));
            session.connect();
            Channel channel = session.openChannel("sftp");
            channel.connect();
            ChannelSftp sftpChannel = (ChannelSftp) channel;
            String currentDir=prop.getProperty("SFTPDESINATIONPATH");
            String newDir=contractId;
            String destPath= currentDir+"/"+newDir;
            SftpATTRS attrs=null;
            try{
            	attrs = sftpChannel.stat(destPath);	
            }
            catch(Exception e)
            {
            	e.printStackTrace();
            }
            if (attrs != null) {
            	sftpChannel.put(srcPath,destPath);
            	flag=true;
            } else {
                sftpChannel.cd(currentDir);
                sftpChannel.mkdir(newDir);
                sftpChannel.put(srcPath,destPath);
                flag=true;
            }
            sftpChannel.exit();
        } catch (JSchException e) {
        	flag=false;
            e.printStackTrace();  
        } catch (SftpException e) {
        	flag=false;
            e.printStackTrace();
        }catch(Exception e)
        {
        	flag=false;
        	e.printStackTrace();
        	FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Some error occured or web service down", e);
        	
        }
        return flag;
	}

	public static HoneyBeeSFTPDocuments getSingleton() {
		
		if(single_instance==null)
		{
			single_instance = new HoneyBeeSFTPDocuments();
		}
		return single_instance;
	}
}
