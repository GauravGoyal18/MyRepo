package com.ipru.groups.utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

public class GroupsJsonUtils {
	private static final String CLASSNAME = GroupsJsonUtils.class
			.getCanonicalName();
	private static GroupsJsonUtils instance;

	private GroupsJsonUtils() {

	}

	public static GroupsJsonUtils getInstance() {
		if (instance == null) {
			synchronized (CLASSNAME) {
				instance = new GroupsJsonUtils();
			}
		}
		return instance;
	}

	private JsonParser jsonParser;

	public JsonParser getSingletonParser() {
		if (jsonParser == null) {
			synchronized (this) {
				jsonParser = new JsonParser();
			}
			;
		}
		return jsonParser;
	}

	public JsonObject getJsonObject(String json) {
		return (JsonObject) getSingletonParser().parse(json);
	}

	public JsonArray getJsonArray(String key, JsonObject jsonObject) {
		return jsonObject.getAsJsonArray(key);
	}
	
	public JsonArray getJsonArray(String json){
		return (JsonArray) getSingletonParser().parse(json);
	}

	public JsonElement getJsonElement(String key, JsonObject jsonObject) {

		return jsonObject.get(key);

	}

	public boolean isJsonValid(String json) {
		JsonElement object =  getSingletonParser().parse(json);
		if (object != null) {
			return true;
		}
		return false;
	}
	
	public  Map<String, Object> jsonToMap(JsonObject json) throws Exception {
	    Map<String, Object> retMap = new HashMap<String, Object>();

	    if(json != null) {
	        retMap = toMap(json);
	    }
	    return retMap;
	}

	public Map<String, Object> toMap(JsonObject object) throws Exception {
	    Map<String, Object> map = new HashMap<String, Object>();

	    Iterator<Entry<String, JsonElement>> keysItr = object.entrySet().iterator();
	    while(keysItr.hasNext()) {
	        Entry<String,JsonElement> entry = keysItr.next();
	    	String key = entry.getKey();
	    	Object value = object.get(key);
	        if(value!=null && value instanceof JsonElement){
	        if(((JsonElement)value).isJsonArray()) {
	            value = toList((JsonArray) value);
	        }

	        else if(((JsonElement)value).isJsonObject()) {
	            value = toMap((JsonObject) value);
	        }else if (value instanceof JsonPrimitive){
	        	value = convertJsonPrimitive2Object((JsonPrimitive)value);
	        }
	        map.put(key, value);
	        }
	        
	    }
	    return map;
	}

	public List<Object> toList(JsonArray array) throws Exception {
	    List<Object> list = new ArrayList<Object>();
	    for(int i = 0; i < array.size(); i++) {
	        Object value = array.get(i);
	        if(value != null && value instanceof JsonElement){
	        	if(((JsonElement)value).isJsonArray()) {
	            value = toList((JsonArray) value);
	        }

	        else if(((JsonElement)value).isJsonObject()) {
	            value = toMap((JsonObject) value);
	        }else if (value instanceof JsonPrimitive){
	        	value = convertJsonPrimitive2Object((JsonPrimitive)value);
	        }
	        list.add(value);
	    }
	    
	}
	    return list;

}
	
	private Object convertJsonPrimitive2Object(JsonPrimitive primitive){
		if(primitive.isString()){
			return primitive.getAsString();
		}
		return primitive;
	}
}
