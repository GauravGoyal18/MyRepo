package com.ipru.groups.utilities;

public class StatisticsUtilities {
	public static void addTimeTakenInWebService(long pTimeTaken) {
        Statistics lStatistics;
        lStatistics = (Statistics) ThreadHelper.getInstance().getObject("statistics");
        if(lStatistics !=null){
        lStatistics.addToTimeTakenInWebService(pTimeTaken);
        lStatistics.incrementNumberOfWebServiceInvocations();
        }
   }
   public static void addTimeTakenInDAO(long pTimeTaken) {
        Statistics lStatistics;
        lStatistics = (Statistics) ThreadHelper.getInstance().getObject("statistics");
        if(lStatistics!=null){
        	lStatistics.addToTimeTakenInDAO(pTimeTaken);
            lStatistics.incrementNumberOfDAOInvocations();	
        }
        
   }  

}
