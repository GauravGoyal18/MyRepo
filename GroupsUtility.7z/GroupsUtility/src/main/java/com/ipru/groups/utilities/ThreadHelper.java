package com.ipru.groups.utilities;

import java.util.HashMap;
import java.util.Map;

public class ThreadHelper {
	private static ThreadHelper threadHelper = new ThreadHelper();
    private Map <Long, Map<String, Object>> mapOfThreadObjects = new HashMap <Long, Map<String, Object>>();
    public static ThreadHelper getInstance() {
        return threadHelper;
    }
    public Object getObject(String pObjectName) {
        Object lObject = null;
        if (mapOfThreadObjects.get(Thread.currentThread().getId()) != null) {
            lObject = mapOfThreadObjects.get(Thread.currentThread().getId()).get(pObjectName);
        }
        return lObject;
    }
    public void setObject(Object pObject, String pObjectName) {
        Map <String, Object> lThreadObjects;
        lThreadObjects = mapOfThreadObjects.get(Thread.currentThread().getId());
        if (lThreadObjects == null) {
            lThreadObjects = new HashMap <String, Object>();
            mapOfThreadObjects.put(Thread.currentThread().getId(), lThreadObjects);
        }
        lThreadObjects.put(pObjectName, pObject);
    }
    public void clear(Thread pThread) {
        mapOfThreadObjects.remove(pThread.getId());
    }  

}
