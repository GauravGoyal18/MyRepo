package com.ipru.groups.utilities;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.tcs.logger.FLogger;

public final class GroupCommonUtils {
	private static String STR_CURR_DATE = DateUtil.formatDate(new Date(), "dd MMM yyyy");
//	public static final List<String> GENDERS = Collections.unmodifiableList(Arrays.asList(new String[]{"Male","Female"}));
	public static Gson gsonInstance;

	public static Gson getGsonInstance() {
		if (gsonInstance == null) {
			gsonInstance = new Gson();
		}
		return gsonInstance;
	}

	public static String stringifyException(Exception exception) {

		StringWriter errors = new StringWriter();
		exception.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}

	public static void logException(String logCategory, String className, String methodName, String errorDescription, Exception exception, String... extraLoggingData) {
		FLogger.error(logCategory, className, methodName, errorDescription, exception);
	}

	public static String createDirWithTodaysDate(String path) {
		
		FLogger.info("GROUPLogger", "GroupCommonUtils", "createDirWithTodaysDate", "Doc Save Path with date"+path);
		Date d = new Date();
		File file = null;
		try {
			path = path.replaceFirst("\\$\\{DateFolder\\}", DateUtil.formatDate(d, "ddMMyyyy"));
			file = new File(path);
			if (!file.isDirectory()) {
				file.mkdirs();
			}
		}
		finally {
			d = null;
			file = null;
		}
		return path;
	}

	public static void logException(String logCategory, String className, String methodName, String errorDescription, Throwable e, String... extraLoggingData) {
		FLogger.error(logCategory, className, methodName, errorDescription, e);
		// TODO Auto-generated method stub

	}

	/**
	 * @author Rajvinder
	 * @param strDate
	 * @param years
	 * @return
	 * @throws Throwable
	 */
	public static Boolean isCurrDateGreaterThanGvnDate(String strDate, int years) throws Exception {
		try {

			if (StringUtils.isNotBlank(strDate)) {
				String strSubDt = getCalculatedDate(strDate, "dd MMM yyyy", years);
				int res = DateUtil.compareDateStrings(strSubDt, STR_CURR_DATE, "dd MMM yyyy");

				if (res <= 0) // Current Date is greater than the last few years
								// date(maturity date)
					return Boolean.TRUE;
			}
		}
		catch (Exception e) {
			throw e;
		}
		return Boolean.FALSE;
	}

	/**
	 * @author Rajvinder
	 * @param strDate
	 * @param format
	 * @param yearDiff
	 * @return
	 * @throws Exception
	 */
	public static String getCalculatedDate(String strDate, String format, Integer yearDiff) throws Exception {
		if (StringUtils.isBlank(strDate) || StringUtils.isBlank(format) || yearDiff == null) {
			throw new Exception("Date parameters found empty");
		}
		Date dtCalc = DateUtil.formatStrDate(strDate, format);
		Date diffInDate = DateUtil.AddOrSubYrsCurrDate(dtCalc, yearDiff);
		String strDiffInDt = DateUtil.formatDate(diffInDate, "dd MMM yyyy");
		return strDiffInDt;
	}

	public static BigDecimal ConvertToXDecimalPoint(BigDecimal value, int decimals) {
		BigDecimal bigDecimal = BigDecimal.ZERO;
		if (value != null) {
			bigDecimal = value.setScale(decimals, BigDecimal.ROUND_HALF_UP);
		}
		return bigDecimal;
	}

	public static String ConvertToXDecimalPoint(String value, int decimals) {
		String convertValue = "0.00";
		BigDecimal bigDecimal = null;
		if (StringUtils.isNotBlank(value)) {
			bigDecimal = new BigDecimal(value);
			bigDecimal = bigDecimal.setScale(decimals, BigDecimal.ROUND_HALF_UP);
			convertValue = bigDecimal.toString();
		}
		else {
			convertValue = value;
		}
		return convertValue;
	}

	public static void main(String[] args) {

		try {

			String strDate = "20 AUG 2019";

			// String
			// newDate=(strDate.substring(0,strDate.length()-2)+"20"+strDate.substring(strDate.length()-2));

			//System.out.println(GroupCommonUtils.isCurrDateGreaterThanGvnDate(strDate, -5));
		}
		catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static Date getCurrentDate() {

		return Calendar.getInstance().getTime();
	}
	
	
	public static String getGenderBasedOnTitle(String title){
		if(StringUtils.isNotBlank(title)) {
		return getGenders().get(title);
		}
		return title;
		
	}
	
	public static String getTitleBasedOnGender(String title){
		if(StringUtils.isNotBlank(title)) {
		return getTitleFromFrontEnd().get(title);
		}
		return title;
		
	}
	
	
	

	public static String getActiveFromFrontEnd(String title){
		if(StringUtils.isNotBlank(title)) {
		return getActiveFromFrontEnd().get(title);
		}
		return title;
		
	}
	
	public static String getActiveFromWebService(String title){
		if(StringUtils.isNotBlank(title)) {
		return getActiveFromWebService().get(title);
		}
		return title;
		
	}
	
	
	private static final Map<String,String> getTitleFromFrontEnd(){
		Map<String,String> genders = new HashMap<String, String>(1);
		genders.put("Male", "Mr");
		genders.put("Female","Ms");
		return genders;
	}
	
	private static final Map<String,String> getGenders(){
		Map<String,String> genders = new HashMap<String, String>(1);
		genders.put("Mr", "Male");
		genders.put("Ms", "Female");
		return genders;
	}
	
	private static final Map<String,String> getActiveFromWebService(){
		Map<String,String> active = new HashMap<String, String>(1);
		active.put("active", "true");
		active.put("deactive", "false");
		return active;
	}
	private static final Map<String,String> getActiveFromFrontEnd(){
		Map<String,String> active = new HashMap<String, String>(1);
		active.put("true", "active");
		active.put("false", "deactive");
		return active;
	}

	

}
