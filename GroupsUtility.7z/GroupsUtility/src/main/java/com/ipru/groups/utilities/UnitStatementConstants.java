package com.ipru.groups.utilities;

public class UnitStatementConstants {
	
	
	public final static String OpeningBalance = "Opening Balance";
	public  final static String Contribution = "SA Contribution";
	public final static String Claim = "Gratuity Claim";
	public final static String SwitchFund = "Switch Fund";
	public  final static String STOFIN = "STOF In";
	public  final static String SwitchIn= "Switch In";
	public  final static String SwitchOut= "Switch Out";
	public  final static String STOFOUT= "STOF OUT";
	public  final static String UJV= "Unit JV";
	public  final static String ClosingBalance = "Closing Balance";
	
	public final static String AdjustmentsofUnits="Adjustments of Units";
	
	public final static int twelveMonthConstant=-12;
	
	
	
	public final static String ddmmyyyy="dd/mm/yyyy";
	
	public UnitStatementConstants() {
		super();
		// TODO Auto-generated constructor stub
	}

}
