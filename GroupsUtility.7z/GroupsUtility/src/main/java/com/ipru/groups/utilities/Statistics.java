package com.ipru.groups.utilities;

public class Statistics {
	private String URL;
    private long totalTimeTaken;
    private long timeTakenInWebService;
    private long timeTakenInDAO;
    private int numberOfWebServiceInvocations;
    private int numberOfDAOInvocations;

    public Statistics (String pURL) {
         URL = pURL;
    }
    public String getURL() {
        return URL;
    }
    public long getTotalTimeTaken () {
        return totalTimeTaken;
    }
    public void setTotalTimeTaken (long pTotalTimeTaken) {
        totalTimeTaken = pTotalTimeTaken;
    }
    public long getTimeTakenInWebService () {
        return timeTakenInWebService;
    }
    public long getTimeTakenInDAO () {
        return timeTakenInDAO;
    }
    public int getNumberOfWebServiceInvocations() {
        return numberOfWebServiceInvocations;
    }
    public int getNumberOfDAOInvocations() {
        return numberOfDAOInvocations;
    }
    public void incrementNumberOfWebServiceInvocations() {
        numberOfWebServiceInvocations += 1;
    }
    public void addToTimeTakenInWebService(long pTimeTaken) {
        timeTakenInWebService += pTimeTaken;
    }
    public void incrementNumberOfDAOInvocations() {
        numberOfDAOInvocations += 1;
    }
    public void addToTimeTakenInDAO(long pTimeTaken) {
        timeTakenInDAO += pTimeTaken;
    } 

}
