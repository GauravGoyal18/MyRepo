package com.ipru.groups.utilities;

import java.util.concurrent.ConcurrentHashMap;

	
public class ContextKeyConstants {
	private ContextKeyConstants() {
		super();
	}
			
			//Added By Jagrati
			public static final String CONCURRENT_SESSION_MAP_CONTEXT = "concurrentsessionMap_context";
			// added by chintan
			//CsrMasterDataLoader constants..
			public static final String ROLES_RULES_MATRIX_CONTEXT = "csr_contextRolesRulesMatrix";
			public static final String CSR_POLICY_STATUS_LIST = "csr_policyStatusList";
			public static final String CSR_PREM_STATUS_LIST = "csr_premStatusList";
			public static final String CSR_OPPORTUNITY_LOSS_PRODUCTS = "csr_opportunityLossProducts";
			public static final String CSR_SIELIGIBLE_BANKCARD_LIST = "csr_SIEligibleBankCardList";
			public static final String CSR_DASHBOARD_GRID_LIST = "csr_dashboardGridList";
			public static final String CSR_PAYMENT_MODE_MASTER_LIST = "csr_paymentModeMasterList";
			
			//MasterDataLoader constants..
			public static final String UID_DETAILS_MAP = "UID_DETAILS_MAP";
			public static final String EBI_BUSINESSPARAM = "ebi_businessParam";
			public static final String EBI_BUSINESS_DEFAULTVALUES = "ebi_businessdefaultvalues";
			public static final String LEAD_BUSINESS_PARAM = "lead_businessParam";
			public static final String BUSINESS_PARAMETERS_JSON = "businessParametersJson";
			public static final String EBIGOALS_BUSINESSPARAM = "ebigoals_businessParam";
			public static final String FOLLOWUP_STATUSLIST = "followup_statuslist";
			public static final String FOLLOWUP_REASONLIST = "followup_reasonlist";
			public static final String FOLLOWUP_TYPELIST = "followup_typelist";
			public static final String EBI_PRODUCTLIST = "ebi_productList";
			public static final String CALC_BUSINESSPARAM = "calc_businessParam";
			public static final String PERFIOS_BANKLIST = "perfiosBankList";
			public static final String MY_OVERVIEW_WDGT_MAP = "myOverviewWdgtMap";
			public static final String DFLT_SCREEN_WDGTMAP = "dfltScreenWdgtMap";
			public static final String DFLT_SCREEN_CONFIGMAP = "dfltScreenConfigMap";
			public static final String LIST_PAGE_AARAY = "list_page_array";
			public static final String URL_BUSINESSPARAM = "url_businessParam";
			public static final String SOURCE_FIELD_BEAN_MAP = "source_field_bean_map";
			public static final String APPFORM_FIELDS = "appForm_Fields";
			public static final String PRODUCT_TEMPLATEMAPPING = "productTemplateMapping";
			public static final String ESIGNPAD_ACCESSMATRIX = "ESignPadAccessMatrix";
			public static final String CHANNEL_MASTER = "channelMaster";
			public static final String APPFORM_TEMPLATES_JSON = "appFormTemplatesJson";
			public static final String NSE_HOLIDAYS = "nseHolidays";
			public static final String DISPLAY_LIST_DB = "displayListDB";
			public static final String FIELDACCESSMAPPING_LIST = "fieldAccessMappingVoList";
			public static final String PRODUCT_MASTER_LIST = "productMasterList";
			public static final String FUND_MASTER_LIST = "fundMasterList";
			public static final String PRODUCT_FUND_MASTER_LIST = "productFundMasterList";
			public static final String PRODUCT_SWITCH_AMOUNT_MASTER_LIST = "productSwitchAmountMasterList";
			public static final String POLICY_VALID_MASTER_LIST = "policyValid";
			
			public static final String CONTEXT_KEY_BIZRESPONSE="bizRes";
			
			public static final String FUNCTIONALITY_LIST = "functionalityVOList";
			public static final String GST_POLICY_LIST = "gstPolicyList";
			public static final String POLICY_PRODUCT_FUND_MASTER_LIST = "policyProductFundMasterList";
			
}
