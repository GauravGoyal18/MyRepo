package com.ipru.groups.utilities;

/**
 * @author IPRU24171
 */
public final class PriviledgeConstants {

	public enum PriviledgeFunctionalityConstants implements PreviledgeInterface {

		TOPUPDATE("TOPUPDATE"), PREMDATE("PREMDATE"), SWITCHDATE("SWCHDATE"), CIPSDATE("CIPSDATE"),ATPATSDATE("ATPATSDATE"), ISCUSTTYPELOGIN("isCustTypeLogin"),BOPSROLEALLOW("isBOPSRoleAllow"),
		AGENTROLEALLOW("isAgentRoleAllow"),SPAARCROLEALLOW("isSpaarcRoleAllow"),CUSTOMERROLEALLOW("isCustomerRoleAllow"),BSVCROLEALLOW("isBsvcRoleAllow"),UNSECCUSTROLEALLOW("isUnsecRoleAllow"),
		UNSEC_EMAIL_MOB("csr_unsec_email_mob"),ASSIGNEE_BOPS("isBOPSRoleAllowforAssignee"), NODATA_CUSTOMERVIEW("csr_noDataCustomerView"), NODATA_BRANCHVIEW("csr_noDataBranchView"), NODATA_CAVIEW("csr_noDataCAView"),
		NODATA_AGENTVIEW("csr_noDataAgentView"), NODATA_DEFAULTVIEW("csr_noDataDefaultView"),ASSIGNEEALLOW("_ASSIGNEE_ALLOW");

		private final String cutoffTimeForTransaction;

		PriviledgeFunctionalityConstants(String cutoffTimeForTransaction) {
			this.cutoffTimeForTransaction = cutoffTimeForTransaction;
		}

		@Override
		public String getPriviledgeValue() {
			// TODO Auto-generated method stub
			return cutoffTimeForTransaction;
		}

	}

	public enum PriviledgeFunctionalitySubTypeConstants implements PreviledgeInterface {

		TPUP_CUTOFFTIME_3PM("CUTOFFTIME_3PM", PriviledgeFunctionalityConstants.TOPUPDATE), 
		TPUP_CUTOFFTIME_530PM("CUTOFFTIME_530PM", PriviledgeFunctionalityConstants.TOPUPDATE), 
		SWCH_CUTOFFTIME_3PM("CUTOFFTIME_3PM", PriviledgeFunctionalityConstants.SWITCHDATE), 
		SWCH_CUTOFFTIME_530PM("CUTOFFTIME_530PM", PriviledgeFunctionalityConstants.SWITCHDATE), 
		PREM_CUTOFFTIME_3PM("CUTOFFTIME_3PM", PriviledgeFunctionalityConstants.PREMDATE), 
		PREM_CUTOFFTIME_530PM("CUTOFFTIME_530PM", PriviledgeFunctionalityConstants.PREMDATE), 
		CIPS_CUTOFFTIME_3PM("CUTOFFTIME_3PM", PriviledgeFunctionalityConstants.CIPSDATE), 
		CIPS_CUTOFFTIME_530PM("CUTOFFTIME_530PM", PriviledgeFunctionalityConstants.CIPSDATE),
		ATP_CUTOFFTIME_3PM("CUTOFFTIME_3PM", PriviledgeFunctionalityConstants.ATPATSDATE), 
		ATP_CUTOFFTIME_530PM("CUTOFFTIME_530PM", PriviledgeFunctionalityConstants.ATPATSDATE), 
		
		;

		private final String functionalityPriviledgeValue;
		private final PriviledgeFunctionalityConstants functionalityType;

		private PriviledgeFunctionalitySubTypeConstants(String functionalityPriviledgeValue, PriviledgeFunctionalityConstants functionalityType) {
			this.functionalityPriviledgeValue = functionalityPriviledgeValue;
			this.functionalityType = functionalityType;
		}

		public String getfunctionalityPriviledgeValue() {
			return functionalityPriviledgeValue;
		}

		@Override
		public String getPriviledgeValue() {
			// TODO Auto-generated method stub
			return functionalityType.getPriviledgeValue();
		}

	}
	public enum PriviledgeFunctionalitySubTypeConstantsNew implements PreviledgeInterface
	{
		SWCH_ASSIGNEE_ALLOW("SWCH_ASSIGNEE_ALLOW",PriviledgeFunctionalityConstants.ASSIGNEEALLOW),
		CIPS_ASSIGNEE_ALLOW("CIPS_ASSIGNEE_ALLOW",PriviledgeFunctionalityConstants.ASSIGNEEALLOW),
		ATP_ASSIGNEE_ALLOW("ATP_ASSIGNEE_ALLOW",PriviledgeFunctionalityConstants.ASSIGNEEALLOW),
		PREM_ASSIGNEE_ALLOW("PREM_ASSIGNEE_ALLOW",PriviledgeFunctionalityConstants.ASSIGNEEALLOW),
		TOPUP_ASSIGNEE_ALLOW("TOPUP_ASSIGNEE_ALLOW",PriviledgeFunctionalityConstants.ASSIGNEEALLOW)
		;
		private final String functionalityPriviledgeValue;
		private final PriviledgeFunctionalityConstants functionalityType;
		private PriviledgeFunctionalitySubTypeConstantsNew(String functionalityPriviledgeValue, PriviledgeFunctionalityConstants functionalityType) {
			this.functionalityPriviledgeValue = functionalityPriviledgeValue;
			this.functionalityType = functionalityType;
		}

		public String getfunctionalityPriviledgeValue() {
			return functionalityPriviledgeValue;
		}
		@Override
		public String getPriviledgeValue() {
			return functionalityType.getPriviledgeValue();
		}
	}
	public PriviledgeConstants() {
		super();
	}

	/*
	 * public static void main(String[] args) {
	 * ////System.out.println("All drink types"); for
	 * (PriviledgeConstantsForfunctionality type :
	 * PriviledgeConstantsForfunctionality.values()) { displayType(type);
	 * //System.out.println(); } ////System.out.println("All drinks"); for
	 * (PriviledgeConstantsForSubType drink :
	 * PriviledgeConstantsForSubType.values()) { displayDrink(drink);
	 * //System.out.println(); }
	 * displayValue(PriviledgeConstantsForfunctionality.TOPUPDATE); } private
	 * static void displayValue(PriviledgeConstantsForfunctionality valuetoget)
	 * { // TODO Auto-generated method stub List<PriviledgeConstantsForSubType>
	 * sdfsdfsdf=new ArrayList<PriviledgeConstantsForSubType>(1); for
	 * (PriviledgeConstantsForSubType iterable_element :
	 * PriviledgeConstantsForSubType.values()) {
	 * if(StringUtils.equalsIgnoreCase(iterable_element.getPriviledgeValue(),
	 * valuetoget.getPriviledgeValue())) { sdfsdfsdf.add(iterable_element);
	 * ////System.out.println("dfjsdfjgs.........."+iterable_element);
	 * System.out.println
	 * ("sdfksd...."+iterable_element.getfunctionalityPriviledgeValue()); } } }
	 * private static void displayDrink(PriviledgeConstantsForSubType drink) {
	 * displayType(drink); System.out.print(" - ");
	 * System.out.print(drink.getfunctionalityPriviledgeValue()); } private
	 * static void displayType(priviledgeInterface displayable) {
	 * System.out.print(displayable.getPriviledgeValue()); }
	 */
}
