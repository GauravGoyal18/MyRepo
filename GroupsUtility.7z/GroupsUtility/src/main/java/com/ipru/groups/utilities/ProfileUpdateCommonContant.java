package com.ipru.groups.utilities;

public class ProfileUpdateCommonContant {
	private ProfileUpdateCommonContant()
	{
		super();
	}
	public static final String CLASS_NAME = CommonValidationUtil.class.getName();
	public static final String authorized_firstName= "authorisedSignatoryChangeFirstName";
	public static final String authorized_middleName= "authorisedSignatoryChangeMiddleName";
	public static final String authorized_number= "autherisedSigChangeMobileNumber";
	
}
