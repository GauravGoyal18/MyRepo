package com.ipru.groups.utilities;

import java.security.MessageDigest;

import javax.xml.bind.DatatypeConverter;

import com.tcs.logger.FLogger;

/**
 * Encryption Utility
 * @author Sushma
 *
 */
public final class EncryptionUtil {
	
	private static final String LOGCATEGORY="securityLogger";
	private static final String CLAZZNAME=EncryptionUtil.class.getCanonicalName();
	
	private static final String MD5 = "MD5";
	private static final String SHA_256 = "SHA-256";
	
	
	private EncryptionUtil(){
		
	}
	/**
	 * Hashing with MD5. Original Implementation
	 * @param subject
	 * @return
	 */
	public static String encryptMD5  (String subject) {
		FLogger.info(LOGCATEGORY, CLAZZNAME, "encryptMD5(subject)", "in method encryptMD5 to encrypt ");
		byte[] md5hash = null;
		String strenc = null;
		try {
			MessageDigest md = MessageDigest.getInstance(MD5);
			md.update(subject.getBytes("iso-8859-1"), 0, subject.length());
			md5hash = md.digest();
		}
		catch (Exception ex) {
		FLogger.error(LOGCATEGORY, CLAZZNAME, "encryptMD5(subject)", "Error occurred ", ex);
		}
		strenc = IPRUFormatterUtil.convertToHex(md5hash);
		return strenc;
		
		
	}
	
	/**
	 * Hashing with MD5. Overloaded with charset
	 * @param subject
	 * @return
	 */
	public static String encryptMD5 (String subject, String charset) throws Exception{
		try {
			MessageDigest md = MessageDigest.getInstance(MD5);
			md.update(subject.getBytes(charset), 0, subject.length());
			byte[] md5hash = md.digest();
			return IPRUFormatterUtil.convertToHex(md5hash);
		}
		catch (Exception ex) {
			FLogger.error(LOGCATEGORY, CLAZZNAME, "encryptMD5(subject,charset)", "Error occurred ", ex);
			
		}
		return null;
	}
	/**
	 * @param subject
	 * @return
	 * @throws Exception
	 */
	public static String encryptSHA256 (String subject){
		try {
			MessageDigest md = MessageDigest.getInstance(SHA_256);
			md.update(subject.getBytes("UTF-8"));
			byte[] hash = md.digest();
			return IPRUFormatterUtil.convertToHex(hash);
		}
		catch (Exception ex) {
			FLogger.error(LOGCATEGORY, CLAZZNAME, "encryptSHA256(subject)", "Error occurred ", ex);
		}
		return null;
		
	}
	
	
	/**
	 * @param subject
	 * @param charset
	 * @return
	 * @throws Exception
	 */
	public static String encryptSHA256 (String subject, String charset){
		
		try {
			MessageDigest md = MessageDigest.getInstance(SHA_256);
			md.update(subject.getBytes(charset));
			byte[] hash = md.digest();
			return IPRUFormatterUtil.convertToHex(hash);
		}
		catch (Exception ex) {
			FLogger.error(LOGCATEGORY, CLAZZNAME, "encryptSHA256(subject,charset)", "Error occurred ", ex);
		}
		return null;
		
	}
	
	public static void main(String[] args) throws Exception {
		String password = "Test@1234";
		//////System.out.println("SHA-256 iso-8859-1::"+EncryptionUtil.encryptSHA256(password,"iso-8859-1"));
		//////System.out.println("SHA-256::"+EncryptionUtil.encryptSHA256(password));
		//////System.out.println("MD5::"+EncryptionUtil.encryptMD5(password)); //Original
		//////System.out.println("MD5 UTF-8::"+EncryptionUtil.encryptMD5(password,"UTF-8"));
		
		////System.out.println("SHA-256::"+EncryptionUtil.encryptSHA256(password));
String s1 = "h3bxCOJHqx4rMjBCwEnCZkB8gfutQb3h6N/Bu2b9Jn4=";
		String s = "cfffcb27b571a181a1ff30f23037d7c5";
//System.out.println(EncryptionUtil.encryptSHA256(password).length()+"::"+EncryptionUtil.encryptMD5(password).length());
	}
}
