package com.ipru.groups.utilities;



import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
/**
 * Helper utility used by Customer Servicing module initially for Model Validations on Form Submits.<br/>
 * For all Return boolean methods if Test is passed returns true, else validation fails then returns false.
 * <b>Note:<br/>
 * In case of new changes, please check impact of existing helper methods<br/> as these can be used throughout the application.</b>

 *
 */
public final class CommonValidationUtil {
	
	private CommonValidationUtil()
	{
		super();
	}
	private static final String CLASS_NAME = CommonValidationUtil.class.getName();
	private static final Integer POLICY_NUMBER_LENGTH= 8;
	private static final String EMAIL_PATTERN=GroupFormValidationConstant.EMAILID_VALIDATION;
	private static final String PAN_NUMBER_PATTERN = GroupFormValidationConstant.PAN_VALIDATION;
	private static final String EMPTY_STRING="";
//	private static final String ADDRESS_LINES_PATTERN = "^[a-zA-Z0-9,.\\-'/\\s]+$";
	private static final String ADDRESS_LINES_PATTERN =GroupFormValidationConstant.ADDRESS_LINE_ONE_VALIDATION;
	private static final String VALIDATE_PAN_REGEX = "^[\\w]{3}(A|B|C|F|G|H|L|J|T|P)[\\w]\\d{4}[\\w]$";
	private static final String PAN_EXCEPTION_RESPONSE_GENERIC="The PAN quoted by the customer has not been verified as the PAN Web Service is offline";
	/**
	 * Validates if input String is AlphaNumeric (Spaces and Special characters not allowed)
	 * @param input
	 * @return
	 */
	public static boolean ValidateAlpha(String input) {
		boolean flag = false;
		if(StringUtils.isAlpha(input)){
			flag = true;
		}
		return flag;

	}
	
	/**
	 * Validates if input String is Alpha (Spaces are allowed)
	 * @param input
	 * @return
	 */
	
	
	public static boolean ValidateAlphaWithSpace(String input) {
		boolean flag = false;
		if(StringUtils.isAlphaSpace(input)){
			flag = true;
		}
		return flag;

	}
	
	
	
	
	/**
	 * Validates if input String is Alpha (Two or more Spaces are allowed)
	 * @param input
	 * @return
	 */
	
	
	public static boolean ValidateAlphaWithNonMultipleSpace(String input) {
	boolean flag = false;
	
	if(!input.contains("  "))
	{
		flag = true;
	}
	
	return flag;
	}
	
	

	
	
	/**
	 * validates alphabetic input string if it is non mandatory/mandatory case 
	 * @param input
	 * @param isRequired
	 * @return
	 */
	public static boolean ValidateAlpha(String input, boolean isRequired) {
		boolean flag = false;
		
		//mandatory case
		if(isRequired)
		{
			flag = ValidateRequired(input);
		}
		else
		{
			if(StringUtils.isBlank(input) || StringUtils.isAlpha(input))
			{
				return flag = true;
			}
		}
		
		if(flag && StringUtils.isAlpha(input))
		{
			return flag = true;
		}
		else //======Added by Hiren Sonawala=========//
		{
			flag=false;
		}
		
		return flag;
		
		}
	/**
	 * validates for numeric input string if it is non mandatory/mandatory case
	 * @param input
	 * @param isRequired
	 * @return
	 */
	public static boolean ValidateNumeric(String input, boolean isRequired)
	{
		boolean flag = false;
		
		if(isRequired)
		{
			//Mandatory Case
			flag = ValidateRequired(input);
		}else {
			//Non Mandatory Case
			if(StringUtils.isBlank(input)||StringUtils.isNumeric(input)){
				return flag =true;
			}
		}
		//Generic Validation
		/*if(flag&&StringUtils.isNumeric(input)){
			return flag = true;
		}*/
		if(flag&&NumberUtils.isNumber(input)){
			return flag = true;
		}
		else //======Added by Hiren Sonawala=========//
		{
			flag=false;
		}

		return flag;
	}
	/**
	 * Validates if input String is Numeric (Decimal numbers will return false)
	 * @param input
	 * @return
	 */
	public static boolean ValidateNumeric(String input) {
		boolean flag = false;
		
		if(StringUtils.isNumeric(input)){
			flag = true;
		}
		return flag;

	}
	
public static boolean ValidateAddress(String addressLine){
		
		boolean flag = true;
		
		if(!(CommonValidationUtil.ValidateRequired(addressLine)) || !(isMatchedPattern(addressLine, ADDRESS_LINES_PATTERN))  ){
			return false;
		}
		
		return flag;
	}



public static boolean validateRoadSector(String addressLine){
	
	boolean flag = true;
	
	if(!(CommonValidationUtil.ValidateRequired(addressLine)) || !(isMatchedPattern(addressLine, ADDRESS_LINES_PATTERN))  ){
		return false;
	}
	
	return flag;
}
	/**
	 * Validates if input String is AlphaNumeric (Spaces and Special characters not allowed)
	 * @param input
	 * @return
	 */
	public static boolean ValidateAlphaNumeric(String input) {
		boolean flag = false;
		if(!(StringUtils.isAlpha(input)) && !(StringUtils.isNumeric(input)) && StringUtils.isAlphanumeric(input) ){
			flag = true;
		}
		return flag;

	}

	/**
	 * Validates input String for Minimum length
	 * @param input - String to be tested
	 * @param length - Minimum Length Expected
	 * @return
	 */
	
	public static boolean ValidateAlphaNumeric(String input,boolean isRequired) {
		boolean flag = false;
		if(isRequired)
		{
			flag = ValidateRequired(input);
		}
		else
		{
			if(StringUtils.isBlank(input) || ( !(StringUtils.isAlpha(input)) && !(StringUtils.isNumeric(input)) && StringUtils.isAlphanumeric(input) ) )
					{
						return flag = true;
					}
		}
		if(flag && !(StringUtils.isAlpha(input)) && !(StringUtils.isNumeric(input)) && StringUtils.isAlphanumeric(input) )
		{
			return flag = true;
		}
		else //======Added by Hiren Sonawala=========//
		{
			flag=false;
		}

		
		return flag;

	}
	/**
	 * Validates input String for Minimum length
	 * @param input - String to be tested
	 * @param length - Minimum Length Expected
	 * @return
	 */
	public static boolean ValidateMinLength(String input,Integer length) {
		
		boolean flag = false;
		if(length != null && Integer.valueOf(input.length())>=length){
			flag = true;
		}
		return flag;
	}
	
	/**
	 * validates min length for non mandatory and mandatory cases.
	 * @param input
	 * @param length
	 * @param isRequired
	 * @return
	 */
public static boolean ValidateMinLength(String input,Integer length,boolean isRequired) {
		
	boolean flag = false;
	// for non mandatory
		if(isRequired)
		{
			flag = ValidateRequired(input);
		}
		else
		{
			if(StringUtils.isBlank(input) || (length != null && Integer.valueOf(input.length())>=length))
			{
				return flag = true;
			}
		}
		//for mandatory fields
		if(flag && (length != null && Integer.valueOf(input.length())>=length))
		{
			return flag = true;	
		}
		else //======Added by Hiren Sonawala=========//
		{
			flag=false;
		}

	
		return flag;
	}
	/**
	 * Validates input String for Maximum length
	 * @param input - String to be tested
	 * @param length - Maximum Length Expected
	 * @return
	 */
	public static boolean ValidateMaxLength(String input,Integer length) {
		boolean flag = false;
		
		if(length!=null && Integer.valueOf(input.length())<=length)
		{
			flag = true;
			
		}
		return flag;
	}
	
	/**
	 * validates max lengths for both mandatory and non mandatory fields.
	 * @param input
	 * @param length
	 * @param isRequired
	 * @return
	 */
	public static boolean ValidateMaxLength(String input,Integer length,boolean isRequired) {
		
		boolean flag = false;
		
		//mandatory case
			if(isRequired)
			{
				flag = ValidateRequired(input);
			}
			else
			{
				if(StringUtils.isBlank(input) || (length!=null && Integer.valueOf(input.length())<=length))
				{
					return true;
				}
			}
			//non mandatory case
			if(flag && (StringUtils.isBlank(input) || (length!=null && Integer.valueOf(input.length())<=length)) )
			{
			return flag = true;
			}
			else //======Added by Hiren Sonawala=========//
			{
				flag=false;
			}
		return flag;
	}
	/**
	 * Validates for both minimum and maximum lengths for the input string.<br/>
	 * If both Min and Max Lengths are given the same then exact Length can be tested.
	 * @param input - Input String to be validated
	 * @param minLength - Minimum Expected Length
	 * @param maxLength - Maximum Expected Length
	 * @return
	 */
	public static boolean ValidateLengths(String input, Integer minLength, Integer maxLength){
		boolean flag = false;
		
		if(minLength!=null && maxLength!=null && ValidateMinLength(input, minLength) && ValidateMaxLength(input, maxLength))
		{
			flag = true;
			
		}
		return flag;
	}
	/**
	 * validates min. length and max. length form mandatory and non mandatory fields 
	 * @param input
	 * @param minLength
	 * @param maxLength
	 * @param isRequired
	 * @return
	 */
	public static boolean ValidateLengths(String input, Integer minLength, Integer maxLength,boolean isRequired){
		boolean flag = false;
		
		if(minLength!=null && maxLength!=null && ValidateMinLength(input, minLength,isRequired) && ValidateMaxLength(input, maxLength,isRequired))
		{
			flag = true;
			
		}
		return flag;
	}
	
	
	/**
	 * Validates input String for Mandatory Test (Also checks for Null/Blank/Empty)
	 * @param input
	 * @return
	 */
	public static boolean ValidateRequired(String input) {
		boolean flag = false;
		if(StringUtils.isNotBlank(input))
		{
			flag = true;
			
		}
		return flag;
	}

	
	public static boolean validateDate(String toDate,String fromDate) throws Exception {
		boolean flag = false;
		Date requestedToDate,requestedFromDate,systemdate;
		

		if(StringUtils.isNotBlank(toDate) && StringUtils.isNotBlank(fromDate))
		{
			SimpleDateFormat format = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
			requestedToDate=format.parse(toDate);
			requestedFromDate=format.parse(fromDate);
			systemdate=new Date();
		
			if(requestedToDate.equals(requestedFromDate) && systemdate.after(requestedToDate)){				
				flag=true;
			}else if(requestedToDate.after(requestedFromDate) && systemdate.after(requestedToDate)){
				flag=true;
			}
		}
		return flag;
	}
	

	/**
	 * Validates input Object for Mandatory Test 
	 * <ul>
	 * <li>checks if input Object is null - returns  false</li>
	 * <li>checks if input Object is instance of String, runs Mandatory Test of String</li>
	 * <li>checks if input Object is instance of Collections, runs Mandatory Test of Collections</li>
	 * </ul> 
	 * @param input
	 * @return
	 */
	public static boolean ValidateRequired(Object input) {
		boolean flag = false;
		
		if(input instanceof String){
			return ValidateRequired(input);
		}
		if(input instanceof Collections){
			if (CollectionUtils.isEmpty((Collection<?>) input)){
				return flag;
			}
		}
		return true;
	}
	
	

	
	/**
	 * Validates Policy Number
	 * @param policyNo - Policy Number to test
	 * @param isRequired 
	 * @return
	 */
	public static boolean ValidatePolicyNumber(String policyNo, boolean isRequired) {
		boolean flag = false;
		if(isRequired){
			flag = ValidateRequired(policyNo);
		}
		if(flag || !isRequired){
			if (ValidateNumeric(policyNo)&&ValidateLengths(policyNo, POLICY_NUMBER_LENGTH, POLICY_NUMBER_LENGTH)){
				flag = true;
			} else {
				flag = false;
			}
		}
		return flag;
		
	}
	

	
	
	/**
	 * Validates Mobile Number
	 * @param mobileNumber
	 * @param isRequired
	 * @param length
	 * @return
	 */
	public static boolean ValidateMobileNumber(String mobileNumber, boolean isRequired, Integer length) {
		boolean flag = false;
		if(isRequired){
			flag = ValidateRequired(mobileNumber);
		}
		if(flag || !isRequired){
			if (ValidateNumeric(mobileNumber)&&ValidateLengths(mobileNumber, length, length)){
				flag = true;
			} else {
				flag = false;
			}
		}
		return flag;
		
	}
	
	/**
	 * Validates Email 
	 * @param email
	 * @param isRequired
	 * @param maxLength
	 * @return
	 */
	public static boolean ValidateEmail(String email, boolean isRequired, Integer maxLength){
		boolean flag = false;
		if(isRequired){
			flag = ValidateRequired(email);
		}
		if(flag || !isRequired){
			if(ValidateMaxLength(email, maxLength)){
				flag = isMatchedPattern(email, GroupFormValidationConstant.EMAILID_VALIDATION);
			}else {
				flag = false;
			}
		}
		return flag;
	}
	
	/**
	 * Validates PAN Number
	 * @param panNumber
	 * @param isRequired
	 * @return
	 */
	public static boolean ValidatePAN(String panNumber, boolean isRequired){
		boolean flag = false;
		if(isRequired){
			flag = ValidateRequired(panNumber);
		}
		if(flag || !isRequired){
			if(ValidateLengths(panNumber, 10, 10)){
				flag = isMatchedPattern(panNumber, PAN_NUMBER_PATTERN);
			}else {
				flag = false;
			}
		}
		return flag;
	}
	
	/**
	 * Validates PAN Number
	 * @param panNumber
	 * @param isRequired
	 * @return
	 */
	public static boolean ValidatePANWithRegex(String panNumber, boolean isRequired) {
		boolean flag = false;
		if (isRequired) {
			flag = ValidateRequired(panNumber);
		}
		if (flag || !isRequired) {
			if (ValidateLengths(panNumber, 10, 10)) {
				flag = isMatchedPattern(panNumber, VALIDATE_PAN_REGEX);
			}
			else {
				flag = false;
			}
		}
		return flag;
	}
	
	/**
	 * Validates Address Lines
	 * @param addressLine
	 * @param isRequired
	 * @param minLength
	 * @param maxLength
	 * @return
	 */
	/*public static boolean validateFlatBuilding(String addressLine, boolean isRequired, Integer minLength, Integer maxLength){
		boolean flag = false;
		

			if(validateFlatBuilding(addressLine,minLength, maxLength)){
				flag = (isMatchedPattern(addressLine, ADDRESS_LINES_PATTERN));
			}else {
				flag = false;
		//	}
		}
		return flag;
	}*/
	

	/**
	 * Validates Pin Code. If length provided is null, default 6 is taken.
	 * @param pINCode
	 * @param isRequired
	 * @param length
	 * @return
	 */
	public static boolean ValidatePINCode(String pINCode, boolean isRequired, Integer length) {
		boolean flag = false;
		if(isRequired){
			flag = ValidateRequired(pINCode);
		}
		if(flag || !isRequired){
			if (length==null){
				length = 6;
			}
			if (ValidateNumeric(pINCode)&&ValidateLengths(pINCode, length, length)){
				flag = true;
			} else {
				flag = false;
			}
		}
		return flag;
		
	}
	
	
	
	
	/**
	 * Helper Utility to check for Regex Patterns
	 * @param input
	 * @param regexPattern
	 * @return
	 */
	public static boolean isMatchedPattern (String input, String regexPattern) {
		Pattern pattern = null;
		Matcher matcher = null;
		
		if(regexPattern!=null){
			pattern = Pattern.compile(regexPattern);
			if (pattern!=null){
			matcher = pattern.matcher(input);
			if(matcher!=null)
				return matcher.matches();
			}
		}
		return false;
	}
	
	/**
	 * Helper Utility to find for Regex Patterns
	 * @param input
	 * @param regexPattern
	 * @return
	 */
	public static boolean findPattern (String input, String regexPattern) {
		Pattern pattern = null;
		Matcher matcher = null;
		
		if(regexPattern!=null){
			pattern = Pattern.compile(regexPattern);
			if (pattern!=null){
			matcher = pattern.matcher(input);
			if(matcher!=null)
				return matcher.find();
			}
		}
		return false;
	}

	public static boolean isDobValid18Years(Date dob)
	{
	Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR,-18);
	Date currentDate=cal.getTime();
		if(currentDate.compareTo(dob)>=0)
			return true;
		return false;
	}
}
