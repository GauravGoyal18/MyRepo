package com.ipru.groups.utilities;

public class GroupFormValidationConstant 
{
	
	
	public static final String ADDRESS_LINE_ONE_VALIDATION="^[a-zA-Z0-9']+(\\s?[.\\/\\-,']?\\s?[a-zA-Z0-9']+)*$";
	public static final String ADDRESS_LINE_TWO_VALIDATION="^[a-zA-Z0-9']+(\\s?[.\\/\\-,']?[a-zA-Z0-9']+)*$";
	public static final String ADDRESS_LINE_THREE_VALIDATION="^[a-zA-Z0-9']+(\\s?[.\\/\\-,']?[a-zA-Z0-9']+)*$";
	public static final String ADDRESS_LINE_FOUR_VALIDATION="^([a-zA-Z0-9]([a-zA-Z0-9\\/\\-,.\\s\']*))+$";
	public static final String ADDRESS_LINE_FIVE_VALIDATION="^[a-zA-Z']+(\\s[a-zA-Z']+){0,3}$";
	public static final String IFSC_VALIDATION="^[A-Za-z]{3}\\d{13}$";
	public static final String EMAILID_VALIDATION="^([a-zA-Z0-9])+([_\\.]?[a-zA-Z0-9]+)?([_\\.]?[a-zA-Z0-9]+)?\\@([a-zA-Z0-9\\-])+(\\.([a-zA-Z]{2,12})){1,3}$";
	public static final String PROPERTY_LOCATED_CITY_VALIDATION="^([a-zA-Z0-9]([a-zA-Z0-9\\/\\-&,.\\s\']*))+$";
	public static final String NRI_EMPLOYER_VALIDATION="^([a-zA-Z0-9]([a-zA-Z0-9 ']*))+$";
	public static final String NRI_PURPOSE_VALIDATION="^([a-zA-Z0-9]([a-zA-Z0-9 ']*))+$";
	public static final String NRI_TRVL_DETAILS="^([a-zA-Z0-9]([a-zA-Z0-9 ']*))+$";
	public static final String POLICY_DESC_VALIDATION="^([a-zA-Z0-9]([a-zA-Z0-9\\/\\-&,.\\s\']*))+$";
	public static final String PASSPORT_NO_VALIDATION = "^[A-Za-z0-9]{1,15}$";
	public static final String TIN_VALIDATION="^[A-Za-z0-9]*$";
	public static final String ACR_VALIDATION = "^[a-zA-Z0-9\\_]*$";
	public static final String NAME_VALIDATION = "^(?!(?:\\S*\\s){4})(?!.*([A-Za-z])\\1{2})([A-Za-z]*)([A-Za-z]+((\\s){0,1}))*([A-Za-z])+$";
	public static final String ALPHA_VALIDATION = "^([A-Za-z]*)([A-Za-z]+((\\s){0,1}))*([A-Za-z])+$";
	public static final String CITY_VALIDATION = "^([A-Za-z]*)([A-Za-z]+((\\s){0,1}))*([A-Za-z])+$";
	public static final String EMAIL_VALIDATION = "^[A-Za-z0-9._-]+@[A-Za-z0-9._-]+\\.[A-Za-z]*$";
	public static final String THREE_CONSEC_IDENTICAL_CHAR_VALIDATION = "(.)\1\1\1";
	public static final String NUMBER_VALIDATION = "^[0-9]*$";
	public static final String MOBILE_VALIDATION = "^(?![0]{2})[\\d]{10,14}$";
	public static final String INDIAN_MOBILE_VALIDATION="^[7-9]+[\\d]{9}$";
	public static final String MOBILE_MASKED_VALIDATION = "^[0-9xX]{10}$";
	public static final String BENEFITSHARE_VALIDATION = "^[1-9]?[0-9]{1}$|^100$";
	public static final String PERCENTAGE_VALIDATION = "^[1-9]?[0-9]{1}$|^100$";
	//public static final String ANNUALINCOME_VALIDATION = "^[0-9,]*$";
	public static final String ANNUALINCOME_VALIDATION = "^([1-9]|[1-9][0-9]{1}|[1-9][0-9]{2}|[1-9][0-9]{3}|[1-9][0-9]{4}|[1-9][0-9]{5}|[1-9][0-9]{6}|[1-9][0-9]{7}|[1-4][0-9]{8}|500000000)$";
	public static final String OCCUPATION_DESC_VALIDATION = "^([a-zA-Z0-9])([a-zA-Z0-9\\/\\-&,.\\']+((\\s){0,1}))*[a-zA-Z0-9]+$";
	public static final String ADDRESS_VALIDATION = "^[a-zA-Z0-9']+(\\s?[.\\/\\-,']?\\s?[a-zA-Z0-9']+)*$";
	public static final String LANDMARK_VALIDATION = "^([a-zA-Z0-9]([a-zA-Z0-9\\/\\-,.\\s\']*))+$";
	public static final String ORGANIZATION_DESC_VALIDATION = "^([a-zA-Z0-9])([a-zA-Z0-9\\/\\-&,.\\']+((\\s){0,1}))*[a-zA-Z0-9]+$";
	public static final String ORGANIZATION_NAME_VALIDATION = "^([a-zA-Z0-9])([a-zA-Z0-9\\/\\-&,.\\']+((\\s){0,1}))*[a-zA-Z0-9]+$";
	public static final String INDUSTRY_DESC_VALIDATION = "^([a-zA-Z0-9])([a-zA-Z0-9\\/\\-&,.\\']+((\\s){0,1}))*[a-zA-Z0-9]+$";
	public static final String DESIGNATION_VALIDATION = "^([a-zA-Z0-9]([a-zA-Z0-9 ']*))+$";
	public static final String PAN_VALIDATION = "^[A-Z]{3}[P]{1}[A-Z]{1}\\d{4}[A-Z]{1}$";
	public static final String COMPANYPAN_VALIDATION = "^[A-Z]{5}\\d{4}[A-Z]{1}$";
	public static final String NRI_TRVL_DETAILS_VALIDATION = "^([a-zA-Z0-9]([a-zA-Z0-9\\/\\-&,.\\s\']*))+$";
	public static final String LAN_VALIDATION = "^[A-Za-z0-9]*$";
	public static final String TRAVEL_DTLS_VALIDATION = "^([a-zA-Z0-9]([a-zA-Z0-9 ']*))+$";
	public static final String SOURCE_OF_FUNDS_VALIDATION = "^[a-zA-Z']+(\\s[a-zA-Z']+){0,3}$";
	public static final String HEALTH_REMARKS_VALIDATION = "^([a-zA-Z0-9](\\s?[a-zA-Z0-9\\']*))+((\\s){0,1})*[a-zA-Z0-9]$";
	public static final String ALPHANUMSPACE_VALIDATION = "^([a-zA-Z0-9]([a-zA-Z0-9\\s]*))+$";
	public static final String ALPHANUMARIC_VALIDATION = "^[a-zA-Z0-9]+(\\s[a-zA-Z0-9]+){0,3}$";
	public static final String SPECIALCHAR_VALIDATION = "^[a-zA-Z0-9]+(\\s[a-zA-Z0-9\\/\\-&,.\']+){0,3}$";
	public static final String SR_VALIDATION = "^[sS]{1}[rR]{1}\\d{9}$";
	public static final String DECIMAL_VALIDATION = "^[0-9]+(\\.[0-9]{1,2})$"; 
	public static final String DOB_VALIDATION = "^(0[1-9]|1\\d|2\\d|3[01])\\/(0[1-9]|1[0-2])\\/(19|20)\\d{2}$";
	public static final String NAMENOSPACE_VALIDATION = "^(?!(?:\\S*\\s){4})(?!.*([A-Za-z])\\1{3})([A-Za-z]*)([A-Za-z]+((\\s){0,1}))*([A-Za-z])+$";
	public static final String APPNOALPHANUMARIC_VALIDATION = "^(?:[0-9]+[a-z]|[a-z]+[0-9])[a-z0-9]*$";
	public static final String EIA_ACCOUNTNUMBER_VALIDATION="^[A-Za-z]{3}\\d{13}$";
	public static final String DECIMAL_UPTO_TWO_DIGIT="^[0-9]*\\.[0-9][0-9]$";//^[789][0-9]{9}
	public static final String GSTIN_OR_UIN="[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9 A-Z]{1}[Z|z]{1}[0-9 A-Z]{1}";//added for GST	
	
	//Added by Jigar Start
	public static final String SALUTATION_REGEX = "^[a-zA-Z]+\\.?$";
	public static final String FULL_NAME_STRING_REGEX="^[A-Za-z']+( [A-Za-z']+)*$";
	public static final String SUBSCRIBE_EMAIL_REGEX = "^([\\w-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([\\w-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
	public static final String LANDLINE_REGEX="^[0-9]\\d{1,7}\\d{6,7}$";
	public static final String PINCODE_VALIDATION = "^\\d{6,7}$";
	public static final String FAX_REGEX = "^\\+?[0-9]{7,15}$";	
	public static final String NRI_REGEX="(([+][(]?[0-9]{1,3}[)]?)|([(]?[0-9]{4}[)]?))\\s*[)]?[-\\s\\.]?[(]?[0-9]{1,3}[)]?([-\\s\\.]?[0-9]{3})([-\\s\\.]?[0-9]{3,4})";

	public static final int ZERO_LENGTH=0;
	public static final int ONE_LENGTH=1;
	public static final int THIRTY_LENGTH=30;
	public static final int TEN_LENGTH_=10;
	public static final int FOURTEN_LENGTH=14;
	public static final int TWO_LENGTH=2;
	public static final int FOUR_LENGTH=4;
	public static final int SIX_LENGTH=6;
	public static final int ELEVEN_LENGTH=11;
	public static final int TWENTYFIVE_LENGTH=25;
	public static final int THIRTEN_LENGTH=13;
	public static final int TWELVELENGTH=12;
	public static final int FIFTEN_LENGTH=15;
	public static final int HUNDREDLENGTH=100;
	public static final int THREE_LENGTH=3;
	public static final int FIFTY_LENGTH=50;
	public static final int EIGHT_LENGTH=8;
	public static final int TWENTY_LENGTH=20;
	public static final int SIXTEN_LENGTH=16;
	public static final int SIXTY_LENGTH=60;
	public static final int FOURTY_LENGTH=40;
	public static final int FOURTYTWO_LENGTH = 42;
	public static final int NINETYNINE_LENGTH = 99;
		
	public static final int MAX_RANGE_HEIGHT_FEET = 7;
	public static final int MAX_RANGE_WEIGHT = 500;
	
	
	public static final String IFSC_CODE_VALIDATION_FORGROUP="[A-Z|a-z]{4}[0][\\d]{6}$";
	public static final String ACCOUNTNUMBER_VALIDATION_FORGROUP="^[0-9]*$";
	public static final String MOBILENUMBER_VALIDATION_FORGROUP="^[789][0-9]{9}$";
	public static final String MICR_CODE_VALIDATION_FORGROUP="^[0-9]{9}$";
	
	public static final String DOUBLE_VALIDATION_FORGROUP="^[-+]?\\d+(\\.{0,1}(\\d+?))?$";
	
	public static final String DATEVALIDATION="^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$";

	public static final String BANK_BRANCH_VALIDATION="^[A-Za-z]+(?:[\\s-,][A-Za-z]+)*$";
	
	public static final String INDIANLANDLINE="^[\\d]{3,4}[\\-\\s]*[\\d]{6,7}$";
	
	public static final String INDIAN_MOBILE_LANDLINE_VALIDATION = "^([6-9]+[\\d]{9})|^([0]{1}[\\]{1}[0-9]{9,10})$";
	
}
