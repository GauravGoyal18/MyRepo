package com.ipru.groups.utilities;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/**
 * DateUtil 
 * @author Patni
 * @version 1.0
 *
 */

public class DateUtil {
	
	// Date Format Conversion
	private static final String INPUT_DATE_FORMAT = "MMddyyyy";

	/**
	 * Method formatDate. 
	 * This method returns current date in provided format
	 * 
	 * @param None
	 * @return String - formatted date
	 */
	public static String formatDate() {
		SimpleDateFormat formatter = new SimpleDateFormat(INPUT_DATE_FORMAT);
		Date currentDate = new Date();
		String dateString = formatter.format(currentDate);
		return dateString;
	}

	/**
	 * Method formatDateYYYYMMDD. 
	 * This method returns current date in yyyyMMdd Format
	 * 
	 * @param None
	 * @return String - formatted date
	 */

	public static String formatDateYYYYMMDD() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		Date currentDate = new Date();
		String dateString = formatter.format(currentDate);
		return dateString;
	}
	
	/**
	 * Method getYear. 
	 * This method returns year of current date in YYYY format
	 * 
	 * @param None
	 * @return String - year
	 */

	public static String getYear() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
		Date currentDate = new Date();
		String dateString = formatter.format(currentDate);
		return dateString;
	}
	
	/**
	 * Method getMonth. 
	 * This method returns cmonth of current date
	 * 
	 * @param None
	 * @return String - month
	 */

	
	public static String getMonth() {
		SimpleDateFormat formatter = new SimpleDateFormat("MM");
		Date currentDate = new Date();
		String dateString = formatter.format(currentDate);
		return dateString;
	}


	/**
	 * Method formatDate. This method formats the given date in provided format
	 * It accept the message to be logged as a parameter.
	 * 
	 * @param Date
	 *            date
	 * @param String
	 *            format
	 * @return String - formatted date
	 */
	public static String formatDate(Date date, String format) {
		String formattedDate = "";
		if (date != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			sdf.setLenient(false);
			formattedDate = sdf.format(date);
		}
		return formattedDate;
	}

	public static double dayDiff(Date fromDate, Date toDate) {

	long MILLSECS_PER_DAY = 24*60*60*1000; // milisec
	double diff	 = (toDate.getTime() - fromDate.getTime() )/ MILLSECS_PER_DAY ;
	//////System.out.println("Day diff ============================== "+ diff);
	return diff;
	}
	
	/**
	 * @param strDate1
	 * @param strDate2
	 * @param dateFormat
	 * @return comparison result
	 * @throws ParseException
	 * This method compares two date strings and returns the comparison result in integer
	 * <br/>1)If strDate1 is after strDate2 the result>0
	 * <br/>2)If strDate1 is before strDate2 the result<0
	 * <br/>3)If strDate1 is same as strDate2 the result=0
	 */
	public static Integer compareDateStrings(String strDate1,String strDate2,String dateFormat) throws ParseException
	{
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		Date date1=sdf.parse(strDate1);
		Date date2=sdf.parse(strDate2);
		
		return date1.compareTo(date2);
	}
	
	/**
	 * @param date1
	 * @param date2
	 * @return difference in years
	 * This method calculate difference between two dates in years
	 */
	public static Integer calculateDiffInYears(Date date1,Date date2)
	{
		Calendar startDate=Calendar.getInstance();
		Calendar endDate=Calendar.getInstance();
		
		startDate.setTime(date1);
		endDate.setTime(date2);
		
		int yearDiff = endDate.get(Calendar.YEAR) - startDate.get(Calendar.YEAR);  
		if (endDate.get(Calendar.MONTH) < startDate.get(Calendar.MONTH)) 
		{
			yearDiff--;  
		}
		else if (endDate.get(Calendar.MONTH) == startDate.get(Calendar.MONTH) && endDate.get(Calendar.DAY_OF_MONTH) < startDate.get(Calendar.DAY_OF_MONTH)) 
		{
			yearDiff--;  
		}
		return yearDiff; 
	}
	
	/**
	 * @param dob
	 * @return age
	 * This method calculates the age for given Date of birth
	 */
	public static Integer calculateAge(Date dob)
	{
		return calculateDiffInYears(dob, new Date());
	}
	
	public static void main(String[] args) {
		Date currentDate=new Date();
		Date dob=null;
		String strDob="12 Dec 1990";
		SimpleDateFormat sdf=new SimpleDateFormat("dd MMM yyyy");
		try {
			dob=sdf.parse(strDob);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			GroupCommonUtils.logException("GROUPLogger", "DateUtil", "main", "ParseException Occurred..", e);
		}
		
		if(dob!=null)
		{
			////System.out.println(calculateDiffInYears(null,null));
		}
	}

	public static Date AddOrSubYrsCurrDate(Date date, int years)
	{
		if(date!=null)
		{
			Calendar cal = Calendar.getInstance();
		    // Substract 1 year from the calendar
			cal.setTime(date);
		    cal.add(Calendar.YEAR, years);
		    return cal.getTime();
		}
		return null;
	}
	
	/**
	 * @author Rajvinder Kaur
	 * @param date
	 * @param days
	 * @return
	 */
	public static Date AddOrSubDaysFmDate(Date date, int days)
	{
		if(date!=null)
		{
			Calendar cal = Calendar.getInstance();
		    // Substract 1 year from the calendar
			cal.setTime(date);
		    cal.add(Calendar.DATE, days);
		    return cal.getTime();
		}
		return null;
	}
	
	/**
	 * @author Rajvinder Kaur
	 * @param strDate
	 * @param format
	 * @return
	 */
	public static Date formatStrDate(String strDate, String format)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date parseDt = null;
		try 
		{
	      parseDt = sdf.parse(strDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return parseDt;
	}
}
