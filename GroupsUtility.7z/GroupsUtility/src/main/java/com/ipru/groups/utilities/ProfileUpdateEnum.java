package com.ipru.groups.utilities;


public enum ProfileUpdateEnum {
	
	/*for displayPage
	companyAddressChange,
	contactPersonChange,
	authorizedSignatoryChange,
	bankAccountDetailsChange,
	
	CompanyAddressChange
	companyAddress_addressType_new,
	companyAddress_sameAs_new,
	companyAddress_address1_new,
	companyAddress_address2_new,
	companyAddress_address3_new,
	companyAddress_country_new,
	companyAddress_state_new,
	companyAddress_city_new,
	companyAddress_pincode_new,
	companyAddress_AuthorityTrusteeName_new,
	CompanyAddressChangeNew
	companyAddress_addressType,
	companyAddress_sameAs,
	companyAddress_address1,
	companyAddress_address2,
	companyAddress_address3,
	companyAddress_country,
	companyAddress_state,
	companyAddress_city,
	companyAddress_pincode,
	companyAddress_AuthorityTrusteeName,


	ContactPersonChange
	contactPerson_title,
	contactPerson_firstName,
	contactPerson_middleName,
	contactPerson_lastName,
	contactPerson_Designation,
	contactPerson_DesignationOther,
	contactPerson_emailId,
	contactPerson_phoneType,
	contactPerson_countryCode,
	contactPerson_areaCode,
	contactPerson_number,
	contactPerson_extension,
	ContactPersonChangeNew
	contactPerson_title_new,
	contactPerson_firstName_new,
	contactPerson_middleName_new,
	contactPerson_lastName_new,
	contactPerson_Designation_new,
	contactPerson_DesignationOther_new,
	contactPerson_emailId_new,
	contactPerson_phoneType_new,
	contactPerson_countryCode_new,
	contactPerson_areaCode_new,
	contactPerson_number_new,
	contactPerson_extension_new,
	
		AuthSignChange
	authorized_title,
	authorized_firstName,
	authorized_middleName,
	authorized_lastName,
	authorized_active,
	authorized_type,
	authorized_emailId,
	authorized_phoneType,
	authorized_countryCode,
	authorized_areaCode,
	authorized_number,
	authorized_extension,
	authorized_documentFileName,
		AuthSignChangeNew
	authorized_title_new,
	authorized_firstName_new,
	authorized_middleName_new,
	authorized_lastName_new,
	authorized_active_new,
	authorized_type_new,
	authorized_emailId_new,
	authorized_phoneType_new,
	authorized_countryCode_new,
	authorized_areaCode_new,
	authorized_number_new,
	authorized_extension_new,
	authorized_documentFileName_new,
	
	BankAccountDetails
	bankAccount_bankName,
	bankAccount_accountNumber,
	bankAccount_MICRCode,
	bankAccount_IFSCCode,
	bankAccount_address1,
	bankAccount_address2,
	bankAccount_address3,
	bankAccount_documentName,
	BankAccountDetailsNew
	bankAccount_bankName_new,
	bankAccount_accountNumber_new,
	bankAccount_MICRCode_new,
	bankAccount_IFSCCode_new,
	bankAccount_address1_new,
	bankAccount_address2_new,
	bankAccount_address3_new,
	bankAccount_documentName_new,*/
	

	
	

	addressType
	
	
	
	
}
