package com.ipru.otp.dao;

import com.ipru.groups.interceptor.GroupBaseDao;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;

public class ProcedureDao extends GroupBaseDao<RoleScreenAccessMappingVO, Integer> {

	public ProcedureDao(String p_StrModuleName) {
		super(p_StrModuleName);
		// TODO Auto-generated constructor stub
	}

}
