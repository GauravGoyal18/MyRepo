package com.ipru.otp.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ipru.bulksms.SMSTrackerService;
import com.ipru.bulksms.SMSTrackerServiceImpl;
import com.ipru.bulksms.SmsServiceException;
import com.ipru.bulksms.beans.smsresponse.ResponseMessageBO;
import com.ipru.bulksms.beans.smsresponse.SmsResponseBO;
import com.ipru.ecamptransaction.InsertTransactions;
import com.ipru.ecamptransaction.InsertTransactionsResponse;
import com.ipru.groups.service.WebserviceInvoke;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.IPRUFormatterUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.GroupEmailSmsVO;
import com.ipru.groups.vo.OTPMasterBean;
import com.ipru.groups.vo.OTPNumberAuditTrailBean;
import com.ipru.groups.vo.OTPNumberBean;
import com.ipru.groups.vo.OTPNumberFunctionality;
import com.ipru.groups.vo.OtpSmsTransactionVO;
import com.ipru.otp.dao.OTPManagerDao;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.service.BaseService;

public class OTPManagerService extends BaseService {

	private OTPManagerDao dao = null;
	private Properties otpProperties = new Properties();
	private static final String CLASS_NAME = OTPManagerService.class.getName();

	/**
	 * Constructor to initialise properties
	 */
	public OTPManagerService() {
		FileInputStream file = null;
		if (MasterPropertiesFileLoader.CONSTANT_OTP_MANAGER_PROPERTIES != null) {
			
			otpProperties = MasterPropertiesFileLoader.CONSTANT_OTP_MANAGER_PROPERTIES;
			
			//////System.out.println(" in if  otpProperties::"+otpProperties.getProperty("OTP_MAX_LIFECYCLE_VALUE"));
		}
		else {
			try {
				
				file=new FileInputStream(GroupConstants.CONSTANT_OTP_MANAGER_MAPPING);

				otpProperties.load(file);
				
			//	////System.out.println(" in else  otpProperties::"+otpProperties);

			}
			catch (FileNotFoundException e) {
				FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, e.getMessage(), e);
			}
			catch (IOException e) {
				FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, e.getMessage(), e);
			}
			finally {
				try {
					if(file!=null)
					file.close();
				}
				catch (Exception e) {
					
					FLogger.error("OTPError", CLASS_NAME,CLASS_NAME,"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
					
				} finally {
					file=null;
				}
			}
		}
	}

	/**
	 * Method to get DAO object
	 * 
	 * @return
	 */
	private OTPManagerDao getDao() {
		if (dao == null)
			dao = new OTPManagerDao("GroupSecurity");
		return dao;
	}

	/**
	 * Method to generate random 6 digits number.
	 * 
	 * @return
	 */
	private String getOTP() {
		char[] numbers = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
		String otp = "";
		Random rand = new Random();
		for (int i = 0; i < 6; i++) {
			int idx = rand.nextInt(numbers.length);
			otp += numbers[idx];
		}

		return otp;
	}

	/**
	 * Method to generate OTP. This method generates otp on the combination of
	 * advisor code and customer id. This method first checks for already
	 * available request in database. If the request is already exist then it
	 * will update the database with new OTP and if the request does not exist
	 * then it will create a new request.
	 * 
	 * @author VivekGrewal554674(TCS)
	 * @param otpBean
	 * @return
	 */
	public boolean generateOTP(OTPMasterBean otpMaster) {
		FLogger.info("OTPLogger", CLASS_NAME, "generateOTP", "method start");
		dao = this.getDao();
		Session session = null;
		Transaction txn = null;
		String otp = null;
		boolean isOTPGenerated = Boolean.FALSE;
		OTPNumberBean otpBean = null;
		OTPNumberFunctionality otpFunc = null;
		OTPNumberBean otpRequest = null;
		OTPNumberAuditTrailBean auditBean = null;
		try {
			// getting otp bean
			otpBean = otpMaster.getOtpBean();
			otpFunc = otpMaster.getOtpFunc();
			// getting audit bean
			auditBean = otpMaster.getAuditBean();
			// otp request from db
			session = dao.getSession();
			txn = session.beginTransaction();
			otpRequest = dao.getOTPRequest(otpBean, session);
			txn.commit();
			// if no otp request exist in db
			if (otpProperties.getProperty("OTP_ENV") != null && StringUtils.equalsIgnoreCase(otpProperties.getProperty("OTP_ENV"), "UAT")) {
				// otp = "123456";
				otp = this.getOTP();
			}
			else {
				otp = this.getOTP();
			}
			if (otpRequest == null) {

				FLogger.info("OTPLogger", CLASS_NAME, "generateOTP", "OTP Generation request not present in DB for advisor code : " + otpBean.getAdvisorCode() + " and custId : " + otpBean.getCustId()
						+ " and Login Role : " + otpBean.getLoginRole());
				// generate random 6 digits otp
				
				FLogger.info("OTPLogger", CLASS_NAME, "generateOTP", "OTP Number generated : " + otp);
				session = dao.getSession();
				txn = session.beginTransaction();
				// setting otp in OTP_NO table
				otpFunc.setOtpNumber(otp);
				// set otp status as Open
				otpFunc.setOtpStatus(otpProperties.getProperty("OPEN_STATUS"));
				otpFunc.setOtpCreatedDate(new Timestamp(System.currentTimeMillis()));
				otpFunc.setOtpUpdatedDate(new Timestamp(System.currentTimeMillis()));
				otpFunc.setMailSentFlag("N");
				otpFunc.setSmsSentFlag("N");
				// setting Policy No in OTP_no table by Sudha Suman
				// otpFunc.setIdentifierCode(otpFunc.getIdentifierCode());

				// set otp number in audit table
				auditBean.setOtpNumber(otp);
				dao.saveOTPRequest(otpBean, session);
				otpFunc.setOtpTransactionId(otpBean.getTransactionId());
				dao.saveOTPFuncRequest(otpFunc, session);
				FLogger.info("OTPLogger", CLASS_NAME, "generateOTP", "OTP generated with transactionID : " + otpBean.getTransactionId());
				auditBean.setTransactionId(otpBean.getTransactionId());
				dao.saveOTPAuditRequest(auditBean, session);
				txn.commit();
				isOTPGenerated = Boolean.TRUE;
			}
			else {
				// generate random 6 digits otp
				FLogger.info("OTPLogger", CLASS_NAME, "generateOTP", "OTP Number generated : " + otp);
				session = dao.getSession();
				txn = session.beginTransaction();
				// setting otp in OTP_NO table
				otpFunc.setOtpNumber(otp);
				// set otp status as Open
				otpFunc.setOtpStatus(otpProperties.getProperty("OPEN_STATUS"));
				otpFunc.setAttempts(0);
				otpFunc.setOtpCreatedDate(new Timestamp(System.currentTimeMillis()));
				
				otpFunc.setOtpUpdatedDate(new Timestamp(System.currentTimeMillis()));
				
				// set otp number in audit table
				auditBean.setOtpNumber(otp);
				otpFunc.setMailSentFlag("N");
				otpFunc.setSmsSentFlag("N");
				// setting Policy No in OTP_no table by Sudha Suman
				// otpFunc.setPolicyNo(otpFunc.getPolicyNo());
				otpRequest.setAdvisorName(otpBean.getAdvisorName());
				otpRequest.setAdvisorCode(otpBean.getAdvisorCode());
				otpRequest.setLoginRole(otpBean.getLoginRole());
				otpRequest.setEmail1(otpBean.getEmail1());
				otpRequest.setEmail2(otpBean.getEmail2());
				otpRequest.setMobile(otpBean.getMobile());

				dao.updateOTPRequest(otpRequest, session);
				otpFunc.setOtpTransactionId(otpRequest.getTransactionId());
				dao.saveOTPFuncRequest(otpFunc, session);
				auditBean.setTransactionId(otpRequest.getTransactionId());
				dao.saveOTPAuditRequest(auditBean, session);
				txn.commit();
				isOTPGenerated = Boolean.TRUE;
			}
			if (isOTPGenerated && StringUtils.equalsIgnoreCase(otpProperties.getProperty("ENABLE_OTP_IPRU_MOBILE_WS"), "Y")) {
				sendOTPInstantSMS(session, otpBean, otpRequest, otpFunc, otp);
			}

		}
		catch (Exception e) {
			txn.rollback();
			StringWriter errors = new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, errors.toString(), e);
		}
		FLogger.info("OTPLogger", CLASS_NAME, "generateOTP", "isOTPGenerated : " + isOTPGenerated);
		FLogger.info("OTPLogger", CLASS_NAME, "generateOTP", "method end");
		return isOTPGenerated;
	}

	/**
	 * Method to validate otp entered by user. This method follows following
	 * steps:<br/>
	 * <b>Step 1.</b>Check whether an otp is generated for advisor code and
	 * customer id and is open.<br/>
	 * <b>Step 2.</b>If there is no open otp request present for advisor code
	 * and customer id combination then set status code as 2 and error message.<br/>
	 * <b>Step 3.</b>If there is an open request exist for advisor code and
	 * customer id combination then follow step 4 and 5.<br/>
	 * <b>Step 4.</b>If entered otp matches with the otp present in db then call
	 * updateStatusForCorrectOTP.<br/>
	 * <b>Step 5.</b>If entered otp does not match with the otp present in db
	 * then call updateStatusForInCorrectOTP.<br/>
	 * 
	 * @author VivekGrewal554674(TCS)
	 * @param otpMaster
	 * @return
	 */
	public Map<String, String> validateOTP(OTPMasterBean otpMaster) {
		FLogger.info("OTPLogger", CLASS_NAME, "validateOTP", "method start");
		OTPNumberBean otpBean = otpMaster.getOtpBean();
		OTPNumberAuditTrailBean auditBean = otpMaster.getAuditBean();
		dao = this.getDao();
		Map<String, String> responseMap = new HashMap<String, String>();
		Session session = null;
		Transaction txn = null;
		try {
			session = dao.getSession();
			txn = session.beginTransaction();
			OTPNumberBean otpRequest = dao.getOTPRequest(otpBean, session);
			txn.commit();
			responseMap.put("VERFCN_STATUS", otpProperties.getProperty("VERIFICATION_FAILED"));
			if (otpRequest == null) {
				FLogger.info("CSR.OTP", CLASS_NAME, "validateOTP", "OTP request does not exist in DB for advisor code : " + otpBean.getAdvisorCode() + " and custId : " + otpBean.getCustId());
				responseMap.put("STATUS_CODE", otpProperties.getProperty("NO_REQUEST_EXIST_CODE"));// 2
				responseMap.put("STATUS_MSG", otpProperties.getProperty("NO_REQUEST_EXIST_MSG"));
			}
			else {
				session = dao.getSession();
				txn = session.beginTransaction();
				OTPNumberFunctionality otpFunc = dao.getOTPFuncRequest(otpRequest, session);
				txn.commit();
				if (otpFunc == null) {
					FLogger.info("OTPLogger", CLASS_NAME, "validateOTP", "OTP Functionality request does not exist in DB for advisor code : " + otpBean.getAdvisorCode() + " and custId : "
							+ otpBean.getCustId());
					responseMap.put("STATUS_CODE", otpProperties.getProperty("NO_REQUEST_EXIST_CODE"));// 2
					responseMap.put("STATUS_MSG", otpProperties.getProperty("NO_REQUEST_EXIST_MSG"));
				}
				else {
					session = dao.getSession();
					txn = session.beginTransaction();
					if (otpFunc.getOtpStatus().equals(otpProperties.getProperty("DEACTIVATED_STATUS"))) {
						FLogger.info("OTPLogger", CLASS_NAME, "validateOTP", "Maximum number of attempts exceeded for advisor code : " + otpBean.getAdvisorCode() + " and custId : "
								+ otpBean.getCustId());
						responseMap.put("STATUS_CODE", otpProperties.getProperty("OTP_MAX_EXCEEDED_CODE"));// 3
						responseMap.put("STATUS_MSG", otpProperties.getProperty("OTP_MAX_EXCEEDED_MSG"));
					}
					else if (otpFunc.getOtpStatus().equals(otpProperties.getProperty("EXPIRED_STATUS"))) {
						FLogger.info("OTPLogger", CLASS_NAME, "validateOTP", "OTP expired for advisor code : " + otpBean.getAdvisorCode() + " and custId : " + otpBean.getCustId());
						responseMap.put("STATUS_CODE", otpProperties.getProperty("OTP_EXPIRED_CODE"));// 4
						responseMap.put("STATUS_MSG", otpProperties.getProperty("OTP_EXPIRED_MSG"));
					}
					else {
						FLogger.info("OTPLogger", CLASS_NAME, "validateOTP", "OTP status is for advisor code : " + otpBean.getAdvisorCode() + " and custId : " + otpBean.getCustId());
						otpMaster.setOtpBean(otpRequest);
						otpMaster.setOtpFunc(otpFunc);
						FLogger.info("OTPLogger", CLASS_NAME, "validateOTP", "OTP in DB : " + otpFunc.getOtpNumber());
						FLogger.info("OTPLogger", CLASS_NAME, "validateOTP", "OTP entered : " + auditBean.getOtpNumberEntered());
						FLogger.info("OTPLogger", CLASS_NAME, "validateOTP", "OTP attempts : " + otpFunc.getAttempts());
						if (otpFunc.getAttempts() >= Integer.parseInt(otpProperties.getProperty("MAX_ATTEMPTS"))) {

							otpFunc.setOtpStatus(otpProperties.getProperty("DEACTIVATED_STATUS"));
							responseMap.put("STATUS_CODE", otpProperties.getProperty("OTP_MAX_EXCEEDED_CODE"));// 3
							responseMap.put("STATUS_MSG", otpProperties.getProperty("OTP_MAX_EXCEEDED_MSG"));
						}
						else {
							if (otpFunc.getOtpNumber() != null && otpFunc.getOtpNumber().equals(auditBean.getOtpNumberEntered())) {
								otpFunc.setAttempts(otpFunc.getAttempts() + 1);
								responseMap.put("STATUS_CODE", otpProperties.getProperty("OTP_MATCHES_CODE"));// 0
								responseMap.put("STATUS_MSG", otpProperties.getProperty("OTP_MATCHES_MSG"));
								responseMap.put("VERFCN_STATUS", otpProperties.getProperty("VERIFICATION_PASSED"));
								otpFunc.setOtpStatus(otpProperties.getProperty("EXPIRED_STATUS"));
							}
							else {
								otpFunc.setAttempts(otpFunc.getAttempts() + 1);
								responseMap.put("STATUS_CODE", otpProperties.getProperty("OTP_MIS_MATCH_CODE"));// 1
								responseMap.put("STATUS_MSG", otpProperties.getProperty("OTP_MIS_MATCHES_MSG"));
							}
						}
					}
					auditBean.setOtpNumber(otpFunc.getOtpNumber());
					auditBean.setTransactionId(otpFunc.getTransactionId());
					dao.saveOTPAuditRequest(auditBean, session);
					dao.updateOTPRequest(otpRequest, session);
					dao.saveOrUpdateOTPFuncRequest(otpFunc, session);
					txn.commit();
					FLogger.info("OTPLogger", CLASS_NAME, "validateOTP", "OTP transaction update successfully.");
				}
			}
		}
		catch (Exception e) {
			txn.rollback();
			FLogger.error("OTPError", CLASS_NAME, "validateOTP", e.getMessage(), e);
		}
		finally {
			if (session != null && session.isOpen()) {
				session.flush();
				session.close();
			}
		}
		return responseMap;
	}

	private Boolean sendOTPInstantSMS(Session session, OTPNumberBean otpBean, OTPNumberBean otpRequest, OTPNumberFunctionality otpFunc, String otp) {
		FLogger.info("OTPLogger", CLASS_NAME, "sendOTPInstantSMS", "Entered Method");
		Boolean isInstantSMSSent = Boolean.FALSE;
		Boolean isInstantEmailSent = Boolean.FALSE;
		List<ResponseMessageBO> smsResponses = null;
		Transaction txn = null;
		String messageText = null;
		// Send SMS
		SMSTrackerService smsService = new SMSTrackerServiceImpl();
		List<String> toMobileNumbers = null;
		Long transactionId = null;
		String mobileNo = null;
		String policyNumber = null;
		String requesterName = null;
		FileInputStream file = null;

		try {
			if (otpRequest == null) {
				policyNumber = otpFunc.getIdentifierCode();
				requesterName = otpBean.getAdvisorName();
				transactionId = Long.valueOf(otpBean.getTransactionId());
				mobileNo = otpBean.getMobile();
			}
			else {
				policyNumber = otpFunc.getIdentifierCode();
				requesterName = otpRequest.getAdvisorName();
				transactionId = Long.valueOf(otpRequest.getTransactionId());
				mobileNo = otpRequest.getMobile();
			}
			if (StringUtils.isBlank(otpProperties.getProperty(otpFunc.getFunctionality()))
					|| StringUtils.equalsIgnoreCase(otpProperties.getProperty("GENERIC_FUNCTIONALITY_PASA"), otpFunc.getFunctionality())) {
				messageText = MessageFormat.format(otpProperties.getProperty("GENERATE_OTP_MOBILE_MESSAGE_TEXT"), otp);
			}
			else {
				messageText = MessageFormat.format(otpProperties.getProperty("FUNCTIONALITY_OTP_MOBILE_MESSAGE_TEXT"), otp, otpProperties.getProperty(otpFunc.getFunctionality()), policyNumber);
			}
			String otMobileNumbersFrmProperty = otpProperties.getProperty("OTP_MOBILE_NOS");

			if (otpProperties.getProperty("OTP_ENV") != null && StringUtils.equalsIgnoreCase(otpProperties.getProperty("OTP_ENV"), "UAT")) {
				/*
				 * if (StringUtils.isNotBlank(otMobileNumbersFrmProperty)) {
				 * toMobileNumbers =
				 * Arrays.asList(otMobileNumbersFrmProperty.split(",")); }
				 */
				if (StringUtils.equalsIgnoreCase(otpProperties.getProperty("SEND_OTP_TO_TEMP_MOBILE_NOS_FOR_PROD"), "Y")) {
					if (StringUtils.isNotBlank(otMobileNumbersFrmProperty)) {
						toMobileNumbers = Arrays.asList(otMobileNumbersFrmProperty.split(","));// Asked
																								// to
																								// send
																								// to
																								// dummy
																								// numbers/support
																								// numbers
																								// even
																								// in
																								// case
																								// of
																								// Prod
																								// env
					}
				}
				if (CollectionUtils.isEmpty(toMobileNumbers)) {
					toMobileNumbers = new ArrayList<String>(1);
				}

				toMobileNumbers.add(mobileNo);
				/* messageText = messageText + " for testing..."; */
			}
			else {
				// Case of Prod
				if (StringUtils.equalsIgnoreCase(otpProperties.getProperty("SEND_OTP_TO_TEMP_MOBILE_NOS_FOR_PROD"), "Y")) {
					if (StringUtils.isNotBlank(otMobileNumbersFrmProperty)) {
						toMobileNumbers = Arrays.asList(otMobileNumbersFrmProperty.split(","));// Asked
																								// to
																								// send
																								// to
																								// dummy
																								// numbers/support
																								// numbers
																								// even
																								// in
																								// case
																								// of
																								// Prod
																								// env
					}
				}
				if (CollectionUtils.isEmpty(toMobileNumbers)) {
					toMobileNumbers = new ArrayList<String>(1);
				}

				toMobileNumbers.add(mobileNo);

			}

			if (CollectionUtils.isNotEmpty(toMobileNumbers)) {
				for (String mobileNumber : toMobileNumbers) {
					if (StringUtils.isNotBlank(mobileNumber)) {
						
						SmsResponseBO responseObj = null;
						Properties otpProp = new Properties();
						
						file=new FileInputStream(GroupConstants.CONSTANT_OTP_MANAGER_MAPPING);
						otpProp.load(file);
						String flag = otpProp.getProperty("SEND_OTP_USING_HTTP_CLIENT");
						if (StringUtils.isNotBlank(flag) && StringUtils.equalsIgnoreCase(flag, "Y")) {
							FLogger.info("OTPLogger", CLASS_NAME, "sendOTPInstantSMS", "Send SMS using HttpClient API");
							responseObj = smsService.sendSmsBySingleMsgApiUsingHttpClient(messageText, mobileNumber);
						}
						else {
							FLogger.info("OTPLogger", CLASS_NAME, "sendOTPInstantSMS", "Send SMS using Jersey API");
							responseObj = smsService.sendSmsBySingleMsgApi(messageText, mobileNumber);
						}
						if (responseObj != null) {
							String[] submitDateFormat = new String[] { "yyyy-MM-d H:mm:ss" };
							smsResponses = responseObj.getMessages();
							if (StringUtils.isNotBlank(responseObj.getReqErrorCode()) || StringUtils.isNotBlank(responseObj.getReqErrorDesc())) {
								session = dao.getSession();
								txn = session.beginTransaction();
								FLogger.error("OTPError", CLASS_NAME, "generateOTP", "Request Error Code::" + responseObj.getReqErrorCode());
								OtpSmsTransactionVO otpSmsTransaction = new OtpSmsTransactionVO();
								otpSmsTransaction.setSentOTP(otp);
								otpSmsTransaction.setOtpTransactionId(transactionId);
								otpSmsTransaction.setRequestSubmitDate(Calendar.getInstance().getTime());
								otpSmsTransaction.setRequestErrorCode(responseObj.getReqErrorCode());
								otpSmsTransaction.setRequestErrorDesc(responseObj.getReqErrorDesc());
								otpSmsTransaction.setSmsRequestId(responseObj.getRequestId());
								otpSmsTransaction.setSentMobileNumber(mobileNumber);
								if (CollectionUtils.isNotEmpty(responseObj.getMessages())) {
									for (ResponseMessageBO smsResponseBO : smsResponses) {
										if (smsResponseBO != null && StringUtils.isNotBlank(smsResponseBO.getTransactionId())) {
											otpSmsTransaction.setSmsTransactionId(smsResponseBO.getTransactionId());
											break;
										}
									}
								}
								dao.saveOTPSmsTransaction(otpSmsTransaction, session);
								txn.commit();
								isInstantSMSSent = Boolean.TRUE;
							}
							else if (CollectionUtils.isNotEmpty(smsResponses)) {
								session = dao.getSession();
								txn = session.beginTransaction();
								for (ResponseMessageBO smsResponseBO : smsResponses) {
									if (smsResponseBO != null) {
										OtpSmsTransactionVO otpSmsTransaction = new OtpSmsTransactionVO();
										otpSmsTransaction.setOtpTransactionId(transactionId);
//										otpSmsTransaction.setRequestSubmitDate(DateUtils.parseDate(smsResponseBO.getSubmitDate(), submitDateFormat));
										otpSmsTransaction.setRequestSubmitDate(Calendar.getInstance().getTime());
										otpSmsTransaction.setResponseErrorCode(smsResponseBO.getErrorCode());
										otpSmsTransaction.setResponseErrorDesc(smsResponseBO.getErrorDesc());
										otpSmsTransaction.setSentOTP(otp);
										otpSmsTransaction.setOstMessageId(smsResponseBO.getMsgId());
										otpSmsTransaction.setSmsTransactionId(smsResponseBO.getTransactionId());
										otpSmsTransaction.setSmsRequestId(responseObj.getRequestId());
										otpSmsTransaction.setSentMobileNumber(mobileNumber);
										dao.saveOTPSmsTransaction(otpSmsTransaction, session);
										txn.commit();
									}
								}
								isInstantSMSSent = Boolean.TRUE;
							}
						}
					}
				}

			}
		}
		/*catch (ParseException e) {
			if (txn != null) {
				txn.rollback();
			}
			FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, e.getMessage());
			handleException(e);
			isInstantSMSSent = Boolean.TRUE;
		}*/
		catch (SmsServiceException e) {
			FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, e.getMessage());
			handleException(e);
			isInstantSMSSent = Boolean.FALSE;
		}
		catch (FileNotFoundException e) {
			FLogger.info("OTPError", CLASS_NAME, CLASS_NAME, e.toString());
			handleException(e);
			isInstantSMSSent = Boolean.FALSE;
		}
		catch (IOException e) {
			FLogger.info("OTPError", CLASS_NAME, CLASS_NAME, e.toString());
			handleException(e);
			isInstantSMSSent = Boolean.FALSE;
		}
		catch (Exception e) {
			if (txn != null) {
				txn.rollback();
			}
			FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, e.getMessage());
			handleException(e);
			isInstantSMSSent = Boolean.FALSE;
		}
		finally {
			try {
				if(file!=null)
					file.close();
			}
			catch (Exception e) {
				FLogger.error("OTPError", CLASS_NAME,CLASS_NAME,
						"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
				e.printStackTrace();
			} finally {
				file=null;
			}
			}

		/**
		 * Code for sending email on real time
		 */

		try {
			otpFunc.setOtpNumber(otp);
			/*
			 * Temporary commented by Nishant need to uncomment it
			 */
			if (StringUtils.equalsIgnoreCase(otpProperties.getProperty("SEND_EMAIL_FLAG"), "Y"))
				isInstantEmailSent = new OTPManagerService().sendEmail(otpBean, otpFunc);
		}
		catch (Exception e) {
			FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, e.getMessage());
			// e.printStackTrace();
		}

		try {
			session = dao.getSession();
			txn = session.beginTransaction();
			otpFunc.setSmsSentFlag(otpProperties.getProperty(String.valueOf(isInstantSMSSent)));
			otpFunc.setMailSentFlag(otpProperties.getProperty(String.valueOf(isInstantEmailSent)));
			if (otpRequest == null) {
				dao.updateOTPRequest(otpBean, session);
				dao.saveOrUpdateOTPFuncRequest(otpFunc, session);
			}
			else {
				dao.updateOTPRequest(otpRequest, session);
				dao.saveOrUpdateOTPFuncRequest(otpFunc, session);
			}
			txn.commit();
		}
		catch (Exception e) {
			FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, e.getMessage());
			// e.printStackTrace();
		}
		finally {
			if (session != null && session.isOpen()) {
				session.flush();
				session.close();
			}
		}

		FLogger.info("OTPLogger", CLASS_NAME, "sendOTPInstantSMS", "Exited Method");
		return isInstantSMSSent;
	}

	private void handleException(Exception e) {

		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, errors.toString());
	}

	private Boolean sendEmail(OTPNumberBean otpBean, OTPNumberFunctionality otpFunc) throws Exception {
		FLogger.info("OTPLogger", CLASS_NAME, "sendEmail", "Method Start");
		GroupEmailSmsVO obj_emailSmsVo = new GroupEmailSmsVO();
		otpBean = IPRUFormatterUtil.trimSpacesOfBean(otpBean);
		otpFunc = IPRUFormatterUtil.trimSpacesOfBean(otpFunc);
		Boolean mailSentFlag = Boolean.FALSE;
		String env = otpProperties.getProperty("OTP_ENV");
		String emailCmpgn = otpProperties.getProperty("OTP_EMAIL_CAMPAIGN_NAME");
		String personalEmailId = null;
		String txnUpdate1 = null;
		String custName = null;
		String functionality = null;

		/*if (StringUtils.equalsIgnoreCase(env, "UAT")) {
			personalEmailId = otpProperties.getProperty("tempEmail");
		}
		else if (StringUtils.equalsIgnoreCase(env, "PROD")) {
			personalEmailId = otpBean.getPersonalEmail();
		}*/
		
		personalEmailId = otpBean.getPersonalEmail();

		// Setting name
		if (StringUtils.isNotBlank(otpBean.getCustomerName())) {
			custName = otpBean.getCustomerName().trim();

		}
		if (StringUtils.isBlank(custName)) {
			custName = otpProperties.getProperty("DEFAULT_CUSTOMER_NAME");
		}

		// Setting functionality
		if (StringUtils.isBlank(otpFunc.getFunctionality())) {
			functionality = otpProperties.getProperty("DEFAULT_FUNCTIONALITY");
		}
		else {
			functionality = otpProperties.getProperty(otpFunc.getFunctionality().trim());
						
			functionality = otpProperties.getProperty(functionality+"_FUNCTIONALITY",otpProperties.getProperty("DEFAULT_FUNCTIONALITY"));
		}

		obj_emailSmsVo.setParam1(custName);
		obj_emailSmsVo.setParam2(functionality);
		
		if("FORGOT_PWD".equals(otpFunc.getFunctionality().trim())){
			obj_emailSmsVo.setParam3("");
			obj_emailSmsVo.setParam5("");
		} else {
			obj_emailSmsVo.setParam3(otpFunc.getIdentifierCode());
			obj_emailSmsVo.setParam5(otpFunc.getIdentifierCode());
		}
		
		obj_emailSmsVo.setParam4(otpFunc.getOtpNumber());
		
		if (StringUtils.isNotBlank(personalEmailId)) {
			obj_emailSmsVo.setParam6(personalEmailId);
			obj_emailSmsVo.setContactId(personalEmailId);
//			txnUpdate1 = triggerEmailSms(emailCmpgn, obj_emailSmsVo);
			WebserviceInvoke webserviceInvoke = WebserviceInvoke.getInstance();
			try {
				txnUpdate1 = webserviceInvoke.invokeEmailCampaignWebService(emailCmpgn, obj_emailSmsVo,"OTPLogger");
				FLogger.info("OTPLogger", CLASS_NAME, "sendEmail", "Email campaign : "+txnUpdate1);
			} catch (Exception e) {
				FLogger.error("OTPLogger", CLASS_NAME, "sendEmail", "Exception came while calling email webservice : ",e);
				e.printStackTrace();
			//	throw e;
			}
		}
		if (StringUtils.startsWith(txnUpdate1, otpProperties.getProperty("OTP_SUCCESS"))) {
			mailSentFlag = Boolean.TRUE;
		}
		FLogger.info("OTPLogger", CLASS_NAME, "sendEmail", "Method Ends with mail sent flag : " + mailSentFlag);
		return mailSentFlag;
	}
	//TODO: Rohit Sidana: To add dependency of new Webservice Client 
	public String triggerEmailSms(String campaignName, GroupEmailSmsVO emailSms_obj) throws IOException, ServiceException {
		FLogger.info("OTPLogger", CLASS_NAME, "triggerEmailSms", "Method Start");
		InsertTransactions request = new InsertTransactions();
		request.setCampaign(campaignName);

		final String URI = otpProperties.getProperty("EmailSmsWebserviceUriProd");
		ArrayList<String> dynamicParamArray = (ArrayList<String>) request.getDynamicParam();
		dynamicParamArray.add(emailSms_obj.getParam1());// Customer Name
		dynamicParamArray.add(emailSms_obj.getParam2());// Functionality
		dynamicParamArray.add(emailSms_obj.getParam3());// Policy Number
		dynamicParamArray.add(emailSms_obj.getParam4());// policy number
		dynamicParamArray.add(emailSms_obj.getParam5());// Email id
		dynamicParamArray.add(emailSms_obj.getParam6());
		dynamicParamArray.add(emailSms_obj.getParam7());
		dynamicParamArray.add(emailSms_obj.getParam8());
		dynamicParamArray.add(emailSms_obj.getParam9());
		dynamicParamArray.add(emailSms_obj.getParam10());
		dynamicParamArray.add(emailSms_obj.getParam11());
		dynamicParamArray.add(emailSms_obj.getParam12());
		dynamicParamArray.add(emailSms_obj.getParam13());
		dynamicParamArray.add(emailSms_obj.getParam14());
		dynamicParamArray.add(emailSms_obj.getParam15());
		dynamicParamArray.add(emailSms_obj.getParam16());
		dynamicParamArray.add(emailSms_obj.getParam17());
		dynamicParamArray.add(emailSms_obj.getParam18());
		dynamicParamArray.add(emailSms_obj.getParam19());
		dynamicParamArray.add(emailSms_obj.getParam20());
		dynamicParamArray.add(emailSms_obj.getParam21());
		dynamicParamArray.add(emailSms_obj.getParam22());
		dynamicParamArray.add(emailSms_obj.getParam23());
		dynamicParamArray.add(emailSms_obj.getParam24());
		dynamicParamArray.add(emailSms_obj.getParam25());
		dynamicParamArray.add(emailSms_obj.getParam26());
		dynamicParamArray.add(emailSms_obj.getParam27());
		dynamicParamArray.add(emailSms_obj.getParam28());
		dynamicParamArray.add(null);// Email ID

		String result = "";

		InsertTransactionsResponse response = null;
		try {
			long startTime = System.currentTimeMillis();
			FLogger.info("OTPLogger", CLASS_NAME, "triggerEmailSms", "webservice start time in miliseconds..." + startTime);

			String connTimeout = otpProperties.getProperty("EMAIL_WEBSERVICE_CONN_TIMEOUT");
			int connTimeoutMs = Integer.parseInt(connTimeout) * 1000;
			String wsTimeout = otpProperties.getProperty("EMAIL_WEBSERVICE_WS_TIMEOUT");
			int wsTimeoutMs = Integer.parseInt(wsTimeout) * 1000;
			FLogger.info("OTPLogger", CLASS_NAME, "triggerEmailSms", "connTimeoutMs::" + connTimeoutMs + " wsTimeoutMs::" + wsTimeoutMs);
//			response = (InsertTransactionsResponse) WebServiceClient.invokeWSTimeout(request, "com.ipru.ecamptransaction", URI, true, connTimeoutMs, wsTimeoutMs);
			FLogger.info("OTPLogger", CLASS_NAME, "triggerEmailSms", "connTimeoutMs::" + connTimeoutMs + " wsTimeoutMs::" + wsTimeoutMs);
		}
		catch (Exception e) {
			// e.printStackTrace();
			FLogger.error("OTPError", CLASS_NAME, "triggerEmailSms", e.getMessage(), e);
		}

		if (response != null && response.getInsertTransactionsReturn() != null) {
			result = response.getInsertTransactionsReturn();
		}
		FLogger.info("OTPLogger", CLASS_NAME, "triggerEmailSms", "Method Ends");
		return result;

	}

	public void updateStatusToExpired() throws Exception {
		
		////System.out.println("  updateStatusToExpired    method");
		FLogger.info("OTPLogger", CLASS_NAME, "updateStatusToExpired", "Method Start");

		Transaction txn = null;
		Session session = null;
		try {
					
			dao = getDao();
			session = dao.getSession();
			txn=session.beginTransaction();	
			
			List<OTPNumberFunctionality> openMailOtps = dao.getOpenOTPs(session);
			if(CollectionUtils.isNotEmpty(openMailOtps)){
				for (OTPNumberFunctionality openOtp : openMailOtps) {
					////System.out.println("openOtp :: "+ openOtp);
					if(openOtp!=null){
						Long maxLifeCycle = Long.getLong(otpProperties.getProperty("OTP_MAX_LIFECYCLE_VALUE"));
						
						Long OTP_MOBILE_NOS = Long.getLong(otpProperties.getProperty("OTP_MOBILE_NOS"));
						
						
						//////System.out.println("OTP_MAX_LIFECYCLE_VALUE======::"+otpProperties.getProperty("OTP_MAX_LIFECYCLE_VALUE"));
                         Double maxLifeCycleotp=Double.parseDouble(otpProperties.getProperty("OTP_MAX_LIFECYCLE_VALUE"));
                         long maxLifeCycleotplong = Long.parseLong(otpProperties.getProperty("OTP_MAX_LIFECYCLE_VALUE"));

						////System.out.println("doubleee::"+maxLifeCycleotp+"maxLifeCycleotplong= long==="+maxLifeCycleotplong);
						if(IPRUFormatterUtil.getSecondsDifference(openOtp.getOtpCreatedDate(), Calendar.getInstance().getTime())>=maxLifeCycleotplong){
							
							////System.out.println(" ::in if ::");
                            openOtp.setOtpStatus(otpProperties.getProperty("OTP_EXPIRE_STATUS"));
                            openOtp.setOtpUpdatedDate(new Timestamp(System.currentTimeMillis()));
							dao.updateOtp(session, openOtp);
						}
					}
				}
				txn.commit();
			}
		}
		catch (Exception e) {
			txn.rollback();
			FLogger.error("OTPError", CLASS_NAME, "updateStatusToExpired", "Error occurred in updateToExpired");
			FLogger.error("OTPError", CLASS_NAME, "updateStatusToExpired", e.getMessage());
			throw e;

		}
		finally {
			if (session != null && session.isOpen()) {
				session.flush();
				session.close();
			}
			session = null;
		}

		FLogger.info("OTPLogger", CLASS_NAME, "updateStatusToExpired", "Method Ends");
	}

}
