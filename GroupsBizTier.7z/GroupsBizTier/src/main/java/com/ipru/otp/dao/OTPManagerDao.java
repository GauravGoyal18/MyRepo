package com.ipru.otp.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;

import com.ipru.groups.interceptor.GroupBaseDao;
import com.ipru.groups.vo.OTPNumberAuditTrailBean;
import com.ipru.groups.vo.OTPNumberBean;
import com.ipru.groups.vo.OTPNumberFunctionality;
import com.ipru.groups.vo.OtpSmsTransactionVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.tcs.dao.hibernate.BaseDAOHibernateImpl;
import com.tcs.logger.FLogger;

public class OTPManagerDao extends GroupBaseDao<RoleScreenAccessMappingVO, Integer> {

	public OTPManagerDao(String p_StrModuleName) {
		super(p_StrModuleName);
	}

	/**
	 * Method to save the otp generation request in OTP_NO
	 * 
	 * @author VivekGrewal554674(TCS)
	 * @param otpBean
	 * @param session
	 */
	public void saveOTPRequest(OTPNumberBean otpBean, Session session) {
		session.save(otpBean);
	}

	public void saveOTPFuncRequest(OTPNumberFunctionality otpFunc, Session session) {
		session.save(otpFunc);
	}

	/**
	 * Method to save the otp generation request in OTP_NO
	 * 
	 * @author VivekGrewal554674(TCS)
	 * @param otpBean
	 * @param session
	 */
	public void saveOTPAuditRequest(OTPNumberAuditTrailBean otpAuditBean, Session session) {
		session.save(otpAuditBean);
	}

	/**
	 * Method to get open OTP request for advisor code and customer id
	 * combination.
	 * 
	 * @author VivekGrewal554674(TCS)
	 * @param otpBean
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public OTPNumberBean getOpenOTPRequest(OTPNumberBean otpBean, Session session) throws Exception {
		OTPNumberBean openOTPBean = null;
		try {
			List<OTPNumberBean> openOTPList = session.getNamedQuery("getOpenOTPRequest").setString("advisorCode", otpBean.getAdvisorCode()).setString("custId", otpBean.getCustId()).list();
			if (openOTPList != null && !openOTPList.isEmpty())
				openOTPBean = openOTPList.get(0);
		}
		catch (Exception e) {
			FLogger.error("CSR.OTP", "OTPManagerDao", "getOpenOTPRequest",e.getMessage(),e);
			throw new Exception(e);
		}

		return openOTPBean;
	}

	/**
	 * Method to get OTP request for advisor code and customer id combination.
	 * 
	 * @author VivekGrewal554674(TCS)
	 * @param otpBean
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public OTPNumberBean getOTPRequest(OTPNumberBean otpBean, Session session) throws Exception {
		OTPNumberBean otpRequest = null;
		try {
			List<OTPNumberBean> otpList = session.getNamedQuery("getOTPRequest").setString("advisorCode", otpBean.getAdvisorCode()).setString("custId", otpBean.getCustId()).setString("loginRole", otpBean.getLoginRole()).list();
			if (otpList != null && !otpList.isEmpty())
				otpRequest = otpList.get(0);
		}
		catch (Exception e) {
			FLogger.error("CSR.OTP", "OTPManagerDao", "getOTPRequest",e.getMessage(),e);
			throw new Exception(e);
		}

		return otpRequest;
	}

	/**
	 * Method to get OTPRequest specific to Functionality
	 * 
	 * @author VivekGrewal554674(TCS)
	 * @param otpBean
	 * @param session
	 * @return otpFunc
	 */
	@SuppressWarnings("unchecked")
	public OTPNumberFunctionality getOTPFuncRequest(OTPNumberBean otpBean, Session session) throws Exception {

		OTPNumberFunctionality otpFunc = null;
		try {
			String query = session.getNamedQuery("getOTPFunctionalityRequestSQL").getQueryString();
			List<OTPNumberFunctionality> otpFuncList = (ArrayList<OTPNumberFunctionality>) session.createSQLQuery(query).addEntity("O", OTPNumberFunctionality.class).setParameter("otpTransactionId", otpBean.getTransactionId()).list();
			if (otpFuncList != null && !otpFuncList.isEmpty())
				otpFunc = otpFuncList.get(0);
		}
		catch (Exception e) {
			FLogger.error("CSR.OTP", "OTPManagerDao", "getOTPFuncRequest",e.getMessage(),e);
			throw new Exception(e);
		}

		return otpFunc;
	}

	public void updateOTPRequest(OTPNumberBean otpBean, Session session) {
		try {
			session.update(otpBean);
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void saveOrUpdateOTPFuncRequest(OTPNumberFunctionality otpFunc, Session session) {
		session.saveOrUpdate(otpFunc);
	}

	public void saveOTPSmsTransaction(OtpSmsTransactionVO otpSmsTransaction, Session session) {
		session.save(otpSmsTransaction);
	}
	
	@SuppressWarnings("unchecked")
	public List<OTPNumberFunctionality> getOpenOTPs(Session session)throws Exception{
//		LoggerUtil.info(CLASS_NAME, "getOpenOTPs", "Method start");
		List<OTPNumberFunctionality> openOtpList=null;
		
		try{
			openOtpList =(List<OTPNumberFunctionality>)session.getNamedQuery("getOpenStatusData").list();
		}
		catch(Exception e)
		{
//			LoggerUtil.error(CLASS_NAME, "getOpenOTPs", e);
			throw e;
		}
		
//		LoggerUtil.info(CLASS_NAME, "getOpenOTPs", "Method end");
		return openOtpList;
	}
	
	public boolean updateOtp(Session session, OTPNumberFunctionality otpFunc) throws Exception
	{
//		LoggerUtil.info(CLASS_NAME, "updateOtp", "Method start");
		boolean isUpdated=Boolean.FALSE;
		
		try{			
			session.merge(otpFunc);
			isUpdated=Boolean.TRUE;
		}
		catch(Exception e)
		{
//			LoggerUtil.error(CLASS_NAME, "updateOtp", "Unable to update otp");
//			LoggerUtil.error(CLASS_NAME, "updateOtp", e);
			throw e;
		}
		
//		LoggerUtil.info(CLASS_NAME, "updateOtp", "Method end");
		return isUpdated;
	}
	
}
