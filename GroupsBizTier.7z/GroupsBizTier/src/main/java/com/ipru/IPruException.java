package com.ipru;

// import com.ipru.generic.po.StatusPO;
import com.tcs.exception.ServiceException;

public class IPruException extends Exception {

	private static final long serialVersionUID = 1L;
	private String status = null;
	private String statusCode = null;
	private String message = null;
	private String redirectUrl = null;
	private String exceptionType = null;

	public IPruException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "{\"IPruException\":{\"status\":\"" + status + "\",\"statusCode\":\"" + statusCode + "\",\"message\":\"" + message + "\",\"redirectUrl\":\"" + redirectUrl + "\",\"exceptionType\":\""
				+ exceptionType + "\"}}";
	}

	public IPruException(String status, String statusCode) {
		super();
		this.status = status;
		this.statusCode = statusCode;
	}

	public IPruException(String status, String statusCode, String message) {
		super();
		this.status = status;
		this.statusCode = statusCode;
		this.message = message;
	}

	public IPruException(String status, String statusCode, String message, String redirectUrl, String exceptionType) {
		super();
		this.status = status;
		this.statusCode = statusCode;
		this.message = message;
		this.redirectUrl = redirectUrl;
		this.exceptionType = exceptionType;
	}

	/*
	 * public IPruException(StatusPO statusPO){ setStatus(statusPO.getStatus());
	 * setStatusCode(statusPO.getStatusCode());
	 * setMessage(statusPO.getMessage());
	 * setRedirectUrl(statusPO.getRedirectUrl());
	 * setExceptionType(statusPO.getExceptionType()); }
	 */

	public IPruException(ServiceException se) {
		setStatus(se.getStatus());
		setStatusCode(se.getErrorCode());
		setMessage(se.getMessage());
		setRedirectUrl(se.getRedirectUrl());
		setExceptionType(se.getExceptionType());
	}

	public String getStatusCode() {
		return this.statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getExceptionType() {
		return exceptionType;
	}

	public void setExceptionType(String exceptionType) {
		this.exceptionType = exceptionType;
	}

	public String getRedirectUrl() {
		return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

}
