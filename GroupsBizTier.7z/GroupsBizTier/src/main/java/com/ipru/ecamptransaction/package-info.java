@javax.xml.bind.annotation.XmlSchema(namespace = "http://EcampTransaction.ipru.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.ipru.ecamptransaction;
