
package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;

public class NewTabCoiPO implements Serializable {

	private String policynumber;
	private String customerId;
	private String templateId;
	private String loanAcNO;
	private String employeeid;
	
	
	public String getEmployeeId() {
		return employeeid;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeid = employeeId;
	}
	public String getpolicynumber() {
		return policynumber;
	}
	public void setpolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	
	public String getLoanAcNO() {
		return loanAcNO;
	}
	public void setLoanAcNO(String loanAcNO) {
		this.loanAcNO = loanAcNO;
	}
	

	
	@Override
	public String toString() {
		return "NewTabCoiPO [policynumber=" + policynumber + ", customerId=" + customerId + ", templateId=" + templateId + ", loanAcNO=" + loanAcNO + ", employeeid=" + employeeid + "]";
	}
	public String toRawPayload() {
		return "policynumber=" + policynumber + "&customerId=" + customerId
				+ "&templateId=" + templateId + "&loanAcNO=" + loanAcNO + "&employeeid=" + employeeid;
	}


	
}
