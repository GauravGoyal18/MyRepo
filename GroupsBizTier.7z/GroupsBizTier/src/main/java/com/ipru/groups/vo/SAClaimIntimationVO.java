package com.ipru.groups.vo;

import java.io.Serializable;

public class SAClaimIntimationVO implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	private long refId;
	private String policyNo;
	private String trustName;
	private String empId;
	private String empName;
	private String panNumber;
	
	private String typeOfClaim;
	private String dateType;
	private String rulesOfSchemeValue;
	private String rulesOfSchemeId;
	private String payeeName;
	
	private String purchaseOption;
	private String nameOfFundComp;
	
	private String freqOfPayment;
	
	private String annuityOptionValue;
	
	private String annuityOptionId;
	
	private String compBuildName;
	private String flatUnitNo;
	private String streetArea;
	private String state;
	private String city;
	private String pincode;
	private String mobileNumber;

	private String emailId;
	
	private String bankName;
	private String branch;
	private String accountNumber;
	private String bankContactNumber;
	private String modeOfPayment;
	private String micr;
	private String ifsc;
	private String createdBy;
	
	private SAClaimIntiBenfVO beneficiary = new SAClaimIntiBenfVO();
	private SAClaimIntiSpouseVO spouse =  new SAClaimIntiSpouseVO();
	public long getRefId() {
		return refId;
	}
	public void setRefId(long refId) {
		this.refId = refId;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getTrustName() {
		return trustName;
	}
	public void setTrustName(String trustName) {
		this.trustName = trustName;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getTypeOfClaim() {
		return typeOfClaim;
	}
	public void setTypeOfClaim(String typeOfClaim) {
		this.typeOfClaim = typeOfClaim;
	}
	public String getDateType() {
		return dateType;
	}
	public void setDateType(String dateType) {
		this.dateType = dateType;
	}
	public String getRulesOfSchemeValue() {
		return rulesOfSchemeValue;
	}
	public void setRulesOfSchemeValue(String rulesOfSchemeValue) {
		this.rulesOfSchemeValue = rulesOfSchemeValue;
	}
	public String getRulesOfSchemeId() {
		return rulesOfSchemeId;
	}
	public void setRulesOfSchemeId(String rulesOfSchemeId) {
		this.rulesOfSchemeId = rulesOfSchemeId;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getPurchaseOption() {
		return purchaseOption;
	}
	public void setPurchaseOption(String purchaseOption) {
		this.purchaseOption = purchaseOption;
	}
	public String getNameOfFundComp() {
		return nameOfFundComp;
	}
	public void setNameOfFundComp(String nameOfFundComp) {
		this.nameOfFundComp = nameOfFundComp;
	}
	public String getFreqOfPayment() {
		return freqOfPayment;
	}
	public void setFreqOfPayment(String freqOfPayment) {
		this.freqOfPayment = freqOfPayment;
	}
	public String getAnnuityOptionValue() {
		return annuityOptionValue;
	}
	public void setAnnuityOptionValue(String annuityOptionValue) {
		this.annuityOptionValue = annuityOptionValue;
	}
	public String getAnnuityOptionId() {
		return annuityOptionId;
	}
	public void setAnnuityOptionId(String annuityOptionId) {
		this.annuityOptionId = annuityOptionId;
	}
	public String getCompBuildName() {
		return compBuildName;
	}
	public void setCompBuildName(String compBuildName) {
		this.compBuildName = compBuildName;
	}
	public String getFlatUnitNo() {
		return flatUnitNo;
	}
	public void setFlatUnitNo(String flatUnitNo) {
		this.flatUnitNo = flatUnitNo;
	}
	public String getStreetArea() {
		return streetArea;
	}
	public void setStreetArea(String streetArea) {
		this.streetArea = streetArea;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBankContactNumber() {
		return bankContactNumber;
	}
	public void setBankContactNumber(String bankContactNumber) {
		this.bankContactNumber = bankContactNumber;
	}
	public String getModeOfPayment() {
		return modeOfPayment;
	}
	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}
	public String getMicr() {
		return micr;
	}
	public void setMicr(String micr) {
		this.micr = micr;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public SAClaimIntiBenfVO getBeneficiary() {
		return beneficiary;
	}
	public void setBeneficiary(SAClaimIntiBenfVO beneficiary) {
		this.beneficiary = beneficiary;
	}
	public SAClaimIntiSpouseVO getSpouse() {
		return spouse;
	}
	public void setSpouse(SAClaimIntiSpouseVO spouse) {
		this.spouse = spouse;
	}
	@Override
	public String toString() {
		return "SAClaimIntimationVO [refId=" + refId + ", policyNo=" + policyNo
				+ ", trustName=" + trustName + ", empId=" + empId
				+ ", empName=" + empName + ", panNumber=" + panNumber
				+ ", typeOfClaim=" + typeOfClaim + ", dateType=" + dateType
				+ ", rulesOfSchemeValue=" + rulesOfSchemeValue
				+ ", rulesOfSchemeId=" + rulesOfSchemeId + ", payeeName="
				+ payeeName + ", purchaseOption=" + purchaseOption
				+ ", nameOfFundComp=" + nameOfFundComp + ", freqOfPayment="
				+ freqOfPayment + ", annuityOptionValue=" + annuityOptionValue
				+ ", annuityOptionId=" + annuityOptionId + ", compBuildName="
				+ compBuildName + ", flatUnitNo=" + flatUnitNo
				+ ", streetArea=" + streetArea + ", state=" + state + ", city="
				+ city + ", pincode=" + pincode + ", mobileNumber="
				+ mobileNumber + ", emailId=" + emailId + ", bankName="
				+ bankName + ", branch=" + branch + ", accountNumber="
				+ accountNumber + ", bankContactNumber=" + bankContactNumber
				+ ", modeOfPayment=" + modeOfPayment + ", micr=" + micr
				+ ", ifsc=" + ifsc + ", createdBy=" + createdBy
				+ ", beneficiary=" + beneficiary + ", spouse=" + spouse + "]";
	}
	
	
	
}
