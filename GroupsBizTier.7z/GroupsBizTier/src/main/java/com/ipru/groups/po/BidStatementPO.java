package com.ipru.groups.po;

public class BidStatementPO extends GroupsBasePo{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private String fromDate;
	private String toDate;
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	@Override
	public String toString() {
		return "BidStatementPO [fromDate=" + fromDate + ", toDate=" + toDate
				+ "]";
	}
	
}
