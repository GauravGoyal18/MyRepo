package com.ipru.groups.vo;

import java.io.Serializable;

public class DocumentUploadVo implements Serializable{
private String docName;
private String docSize;
private String errorMsg;
private String docType;
private String moduleType;
private String clientId;
private String contentType;
private String docPath;
private String policyNo;
private String role;
private String docFileType;
public String getDocName() {
	return docName;
}
public void setDocName(String docName) {
	this.docName = docName;
}
public String getDocSize() {
	return docSize;
}
public void setDocSize(String docSize) {
	this.docSize = docSize;
}
public String getErrorMsg() {
	return errorMsg;
}
public void setErrorMsg(String errorMsg) {
	this.errorMsg = errorMsg;
}
public String getDocType() {
	return docType;
}
public void setDocType(String docType) {
	this.docType = docType;
}
public String getModuleType() {
	return moduleType;
}
public void setModuleType(String moduleType) {
	this.moduleType = moduleType;
}
public String getClientId() {
	return clientId;
}
public void setClientId(String clientId) {
	this.clientId = clientId;
}
public String getContentType() {
	return contentType;
}
public void setContentType(String contentType) {
	this.contentType = contentType;
}
public String getDocPath() {
	return docPath;
}
public void setDocPath(String docPath) {
	this.docPath = docPath;
}
public String getPolicyNo() {
	return policyNo;
}
public void setPolicyNo(String policyNo) {
	this.policyNo = policyNo;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public String getDocFileType() {
	return docFileType;
}
public void setDocFileType(String docFileType) {
	this.docFileType = docFileType;
}



}
