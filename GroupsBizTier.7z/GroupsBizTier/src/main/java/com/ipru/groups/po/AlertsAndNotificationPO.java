package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;

public class AlertsAndNotificationPO implements Serializable {

	private long id;
	private Date notificationDate;
	private String alertsAndNotifications;
	private String policyNumber;
	private String role;

	public AlertsAndNotificationPO() {
		super();
	}

	public AlertsAndNotificationPO(long id, Date notificationDate, String alertsAndNotifications, String policyNumber, String role) {
		super();
		this.id = id;
		this.notificationDate = notificationDate;
		this.alertsAndNotifications = alertsAndNotifications;
		this.policyNumber = policyNumber;
		this.role = role;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getNotificationDate() {
		return notificationDate;
	}

	public void setNotificationDate(Date notificationDate) {
		this.notificationDate = notificationDate;
	}

	public String getAlertsAndNotifications() {
		return alertsAndNotifications;
	}

	public void setAlertsAndNotifications(String alertsAndNotifications) {
		this.alertsAndNotifications = alertsAndNotifications;
	}

	@Override
	public String toString() {
		return "AlertsAndNotificationPO [id=" + id + ", notificationDate=" + notificationDate + ", alertsAndNotifications=" + alertsAndNotifications + ", policyNumber=" + policyNumber + ", role="
				+ role + "]";
	}
}
