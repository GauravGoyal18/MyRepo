package com.ipru.groups.enums;

public enum NomineeUpdateAppointeeEnum {

	apointeeDob, apointeeRelation, apointeeGender, apointeeFirstappointeeName, apointeeLasttappointeeName;
}
