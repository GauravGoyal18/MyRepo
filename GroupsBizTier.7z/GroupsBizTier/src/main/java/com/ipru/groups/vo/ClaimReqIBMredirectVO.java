package com.ipru.groups.vo;

public class ClaimReqIBMredirectVO extends GroupsBaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long requestId;
	private Long isClaimReq;
	private Long isClaimAnnuityReq;

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public Long getIsClaimReq() {
		return isClaimReq;
	}

	public void setIsClaimReq(Long isClaimReq) {
		this.isClaimReq = isClaimReq;
	}

	public Long getIsClaimAnnuityReq() {
		return isClaimAnnuityReq;
	}

	public void setIsClaimAnnuityReq(Long isClaimAnnuityReq) {
		this.isClaimAnnuityReq = isClaimAnnuityReq;
	}

	@Override
	public String toString() {
		return "ClaimReqIBMredirectVO [requestId=" + requestId + ", isClaimReq=" + isClaimReq + ", isClaimAnnuityReq=" + isClaimAnnuityReq + "]";
	}

}
