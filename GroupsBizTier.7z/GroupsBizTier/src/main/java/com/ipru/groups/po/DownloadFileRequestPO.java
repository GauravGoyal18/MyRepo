package com.ipru.groups.po;

import java.io.Serializable;

public class DownloadFileRequestPO implements Serializable{
private long timeToken;
private String fileId;
private String fileName;
public long getTimeToken() {
	return timeToken;
}
public void setTimeToken(long timeToken) {
	this.timeToken = timeToken;
}
public String getFileId() {
	return fileId;
}
public void setFileId(String fileId) {
	this.fileId = fileId;
}
public String getFileName() {
	return fileName;
}
public void setFileName(String fileName) {
	this.fileName = fileName;
}
@Override
public String toString() {
	return "DownloadFileRequestPO [timeToken=" + timeToken + ", fileId="
			+ fileId + ", fileName=" + fileName + "]";
}

}
