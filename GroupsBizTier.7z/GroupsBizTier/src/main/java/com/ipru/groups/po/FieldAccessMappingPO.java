package com.ipru.groups.po;

import com.tcs.web.po.BasePO;


public class FieldAccessMappingPO extends BasePO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long rdId;
//	private String rdRole;
	private String rdComponent;
	private String rdFlow;
	private long rdParentComponentId;
	private long rdOpId;
	private String opShowEdit;
	private String opShowDisabled;
	private String opShow;
	private String opShowSubmit;
	private String opMandatory;
	private long rdComponentPosId;

	public FieldAccessMappingPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FieldAccessMappingPO(long rdId, String rdRole, String rdComponent, String rdFlow, long rdParentComponentId, long rdOpId, String opShowEdit, String opShowDisabled, String opShow, String opShowSubmit, String opMandatory, long rdComponentPosId) {
		super();
		this.rdId = rdId;
//		this.rdRole = rdRole;
		this.rdComponent = rdComponent;
		this.rdFlow = rdFlow;
		this.rdParentComponentId = rdParentComponentId;
		this.rdOpId = rdOpId;
		this.opShowEdit = opShowEdit;
		this.opShowDisabled = opShowDisabled;
		this.opShow = opShow;
		this.opShowSubmit = opShowSubmit;
		this.opMandatory = opMandatory;
		this.rdComponentPosId = rdComponentPosId;
	}

	public long getRdId() {
		return rdId;
	}

	public void setRdId(long rdId) {
		this.rdId = rdId;
	}

	/*public String getRdRole() {
		return rdRole;
	}

	public void setRdRole(String rdRole) {
		this.rdRole = rdRole;
	}*/

	public String getRdComponent() {
		return rdComponent;
	}

	public void setRdComponent(String rdComponent) {
		this.rdComponent = rdComponent;
	}

	public String getRdFlow() {
		return rdFlow;
	}

	public void setRdFlow(String rdFlow) {
		this.rdFlow = rdFlow;
	}

	public long getRdParentComponentId() {
		return rdParentComponentId;
	}

	public void setRdParentComponentId(long rdParentComponentId) {
		this.rdParentComponentId = rdParentComponentId;
	}

	public long getRdOpId() {
		return rdOpId;
	}

	public void setRdOpId(long rdOpId) {
		this.rdOpId = rdOpId;
	}

	public String getOpShowEdit() {
		return opShowEdit;
	}

	public void setOpShowEdit(String opShowEdit) {
		this.opShowEdit = opShowEdit;
	}

	public String getOpShowDisabled() {
		return opShowDisabled;
	}

	public void setOpShowDisabled(String opShowDisabled) {
		this.opShowDisabled = opShowDisabled;
	}

	public String getOpShow() {
		return opShow;
	}

	public void setOpShow(String opShow) {
		this.opShow = opShow;
	}

	public String getOpShowSubmit() {
		return opShowSubmit;
	}

	public void setOpShowSubmit(String opShowSubmit) {
		this.opShowSubmit = opShowSubmit;
	}

	public String getOpMandatory() {
		return opMandatory;
	}

	public void setOpMandatory(String opMandatory) {
		this.opMandatory = opMandatory;
	}

	public long getRdComponentPosId() {
		return rdComponentPosId;
	}

	public void setRdComponentPosId(long rdComponentPosId) {
		this.rdComponentPosId = rdComponentPosId;
	}

	@Override
	public String toString() {
		return "FieldAccessMappingPO [rdId=" + rdId + ", rdComponent="
				+ rdComponent + ", rdFlow=" + rdFlow + ", rdParentComponentId="
				+ rdParentComponentId + ", rdOpId=" + rdOpId + ", opShowEdit="
				+ opShowEdit + ", opShowDisabled=" + opShowDisabled
				+ ", opShow=" + opShow + ", opShowSubmit=" + opShowSubmit
				+ ", opMandatory=" + opMandatory + ", rdComponentPosId="
				+ rdComponentPosId + "]";
	}

	/*@Override
	public String toString() {
		return "FieldAccessMappingPO [rdId=" + rdId + ", rdRole=" + rdRole + ", rdComponent=" + rdComponent + ", rdFlow=" + rdFlow + ", rdParentComponentId=" + rdParentComponentId + ", rdOpId="
				+ rdOpId + ", opShowEdit=" + opShowEdit + ", opShowDisabled=" + opShowDisabled + ", opShow=" + opShow + ", opShowSubmit=" + opShowSubmit + ", opMandatory=" + opMandatory
				+ ", rdComponentPosId=" + rdComponentPosId + "]";
	}*/
	
	

}
