package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.ipru.groups.po.profileupdate.CompanyAddressPO;

public class ProfileUpdateSubmitPO implements Serializable{

	private List<UploadFilePO> uploadFileList;
	private Map<String, ProfileUpdateDetailsPo> profileUpdateMap;
	private Map<String, String> profileUpdateEditMap;
	private List<CompanyAddressPO> companyAddressPolist;
	private CompanyAddressPO companyAddressPoData;

	

	




	// getter And Setter
	


	public CompanyAddressPO getCompanyAddressPoData() {
		return companyAddressPoData;
	}






	public void setCompanyAddressPoData(CompanyAddressPO companyAddressPoData) {
		this.companyAddressPoData = companyAddressPoData;
	}






	public Map<String, ProfileUpdateDetailsPo> getProfileUpdateMap() {
		return profileUpdateMap;
	}

	




	public List<CompanyAddressPO> getCompanyAddressPolist() {
		return companyAddressPolist;
	}






	public void setCompanyAddressPolist(List<CompanyAddressPO> companyAddressPolist) {
		this.companyAddressPolist = companyAddressPolist;
	}






	public void setProfileUpdateMap(
			Map<String, ProfileUpdateDetailsPo> profileUpdateMap) {
		this.profileUpdateMap = profileUpdateMap;
	}

	public void setUploadFileList(List<UploadFilePO> uploadFileList) {
		this.uploadFileList = uploadFileList;
	}

	public List<UploadFilePO> getUploadFileList() {
		return uploadFileList;
	}

	public Map<String, String> getProfileUpdateEditMap() {
		return profileUpdateEditMap;
	}

	public void setProfileUpdateEditMap(Map<String, String> profileUpdateEditMap) {
		this.profileUpdateEditMap = profileUpdateEditMap;
	}

}
