package com.ipru.groups.grpswitch.bean;

import java.io.Serializable;

import com.ipru.groups.po.GroupsBasePo;

public class SwitchDetailsPO extends GroupsBasePo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long switchDetailsId;
	private String fundTransfer;
	private String targetFund;
	private String unitsOrAmount;
	private String value;
	public Long getSwitchDetailsId() {
		return switchDetailsId;
	}
	public void setSwitchDetailsId(Long switchDetailsId) {
		this.switchDetailsId = switchDetailsId;
	}
	public String getFundTransfer() {
		return fundTransfer;
	}
	public void setFundTransfer(String fundTransfer) {
		this.fundTransfer = fundTransfer;
	}
	public String getTargetFund() {
		return targetFund;
	}
	public void setTargetFund(String targetFund) {
		this.targetFund = targetFund;
	}
	public String getUnitsOrAmount() {
		return unitsOrAmount;
	}
	public void setUnitsOrAmount(String unitsOrAmount) {
		this.unitsOrAmount = unitsOrAmount;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
	
	
	

}

