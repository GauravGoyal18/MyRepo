package com.ipru.groups.po;

import java.io.Serializable;

import com.tcs.web.po.BasePO;

public class NomineeUpdateRelationPo extends BasePO {

	private Long id;
	private String key;
	private String value;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public synchronized String getKey() {
		return key;
	}

	public synchronized void setKey(String key) {
		this.key = key;
	}

	public synchronized String getValue() {
		return value;
	}

	public synchronized void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "NomineeUpdateRelationVo [id=" + id + ", key=" + key + ", value=" + value + "]";
	}

}
