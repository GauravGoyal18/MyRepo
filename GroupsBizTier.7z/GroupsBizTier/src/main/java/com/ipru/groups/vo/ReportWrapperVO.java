package com.ipru.groups.vo;

import java.util.ArrayList;
import java.util.List;

import com.ipru.groups.po.CustomerDetailsPO;
import com.ipru.groups.po.TransactionDetailsPO;
import com.tcs.web.vo.BaseVO;

public class ReportWrapperVO extends BaseVO{
	
private static final long serialVersionUID = 1L;
	
	private String Year;
	private String firstDate;
	private String lastDate;
	private String policyNo;
	private String clientId;
	private String trustName;
	private String memberEmpid;
	private CustomerDetailsVO customerDetailsVO;
	private TransactionDetailsVO transactionDetailsVO;
	List lsTransReport = new ArrayList();
//	private SummaryDO summaryDO;
//	private PremiumDO premiumDO;
	private String role;
	private String firstPoint;
	private String lastPoint;
	private boolean flag ;

	private String close_balance=null;

	
	@Override
	public String toString() {
		return "ReportWrapperVO [Year=" + Year + ", firstDate=" + firstDate
				+ ", lastDate=" + lastDate + ", policyNo=" + policyNo
				+ ", clientId=" + clientId + ", trustName=" + trustName
				+ ", memberEmpid=" + memberEmpid + ", customerDetailsVO="
				+ customerDetailsVO + ", transactionDetailsVO="
				+ transactionDetailsVO + ", lsTransReport=" + lsTransReport
				+ ", role=" + role + ", firstPoint=" + firstPoint
				+ ", lastPoint=" + lastPoint + ", flag=" + flag
				+ ", close_balance=" + close_balance + "]";
	}

	public CustomerDetailsVO getCustomerDetailsVO() {
		return customerDetailsVO;
	}

	public void setCustomerDetailsVO(CustomerDetailsVO customerDetailsVO) {
		this.customerDetailsVO = customerDetailsVO;
	}

	public TransactionDetailsVO getTransactionDetailsVO() {
		return transactionDetailsVO;
	}

	public void setTransactionDetailsVO(TransactionDetailsVO transactionDetailsVO) {
		this.transactionDetailsVO = transactionDetailsVO;
	}

	public String getYear() {
		return Year;
	}

	public void setYear(String year) {
		Year = year;
	}

	public String getFirstDate() {
		return firstDate;
	}

	public void setFirstDate(String firstDate) {
		this.firstDate = firstDate;
	}

	public String getLastDate() {
		return lastDate;
	}

	public void setLastDate(String lastDate) {
		this.lastDate = lastDate;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getTrustName() {
		return trustName;
	}

	public void setTrustName(String trustName) {
		this.trustName = trustName;
	}

	public String getMemberEmpid() {
		return memberEmpid;
	}

	public void setMemberEmpid(String memberEmpid) {
		this.memberEmpid = memberEmpid;
	}

	

	public List getLsTransReport() {
		return lsTransReport;
	}

	public void setLsTransReport(List lsTransReport) {
		this.lsTransReport = lsTransReport;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getFirstPoint() {
		return firstPoint;
	}

	public void setFirstPoint(String firstPoint) {
		this.firstPoint = firstPoint;
	}

	public String getLastPoint() {
		return lastPoint;
	}

	public void setLastPoint(String lastPoint) {
		this.lastPoint = lastPoint;
	}

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public String getClose_balance() {
		return close_balance;
	}

	public void setClose_balance(String close_balance) {
		this.close_balance = close_balance;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	} 

}
