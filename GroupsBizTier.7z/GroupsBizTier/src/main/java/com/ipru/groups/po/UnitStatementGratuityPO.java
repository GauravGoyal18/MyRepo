package com.ipru.groups.po;

import com.tcs.web.po.BasePO;

public class UnitStatementGratuityPO extends BasePO{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String startDate;
	private String endDate;
	private String clientId;
	private String clientName;
	
	
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	@Override
	public String toString() {
		return "UnitStatementGratuityPO [startDate=" + startDate + ", endDate="
				+ endDate + ", clientId=" + clientId + ", clientName="
				+ clientName + "]";
	}
	
	
	

}
