package com.ipru.groups.vo;

import java.util.List;
import java.util.Map;

import com.ipru.security.user.PolicyDetails;
import com.tcs.vo.BaseVO;

public class DashboardDetailsVO extends BaseVO {

	private static final long serialVersionUID = 1L;
	private List<PolicyDetailsVO> policyDetailList;
	private PolicyDetails selectedPolicy;

	public DashboardDetailsVO() {
		super();
	}

	public PolicyDetails getSelectedPolicy() {
		return selectedPolicy;
	}

	public void setSelectedPolicy(PolicyDetails selectedPolicy) {
		this.selectedPolicy = selectedPolicy;
	}

	public List<PolicyDetailsVO> getPolicyDetailList() {
		return policyDetailList;
	}

	public void setPolicyDetailList(List<PolicyDetailsVO> policyDetailList) {
		this.policyDetailList = policyDetailList;
	}

}
