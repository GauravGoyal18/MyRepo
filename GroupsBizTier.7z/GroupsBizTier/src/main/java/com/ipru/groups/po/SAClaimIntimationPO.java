package com.ipru.groups.po;

import java.io.Serializable;

import com.ipru.groups.vo.SAClaimIntiBenfVO;


public class SAClaimIntimationPO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	
	private String policyNo;
	private String trustName;
	private String empId;
	private String empName;
	private boolean firstTime;
	
	
	public boolean isFirstTime() {
		return firstTime;
	}
	public void setFirstTime(boolean firstTime) {
		this.firstTime = firstTime;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getTrustName() {
		return trustName;
	}
	public void setTrustName(String trustName) {
		this.trustName = trustName;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	
	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	@Override
	public String toString() {
		return "SAClaimIntimationPO [policyNo=" + policyNo + ", trustName="
				+ trustName + ", empId=" + empId + ", empName=" + empName
				+ ", firstTime=" + firstTime + "]";
	}
	

}
