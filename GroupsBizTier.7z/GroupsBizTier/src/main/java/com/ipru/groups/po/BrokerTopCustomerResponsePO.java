package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Date;

import com.ipru.groups.grpswitch.bean.SwitchFundDetailsPO;

public class BrokerTopCustomerResponsePO implements Serializable {

private static final long serialVersionUID = 1L;
	
	private String policynumber;
	private String statusKey;
	private String productName;
	private String branchCode;
	private String clientName;
	private String premiumAmount;
	private String rcd;
	
	public String getPolicynumber() {
		return policynumber;
	}
	public void setPolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}
	public String getStatusKey() {
		return statusKey;
	}
	public void setStatusKey(String statusKey) {
		this.statusKey = statusKey;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	
	
	public String getRcd() {
		return rcd;
	}
	public void setRcd(String rcd) {
		this.rcd = rcd;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "BrokerTopCustomerResponsePO [policynumber=" + policynumber + ", statusKey=" + statusKey + ", productName=" + productName + ", branchCode=" + branchCode + ", clientName=" + clientName
				+ ", premiumAmount=" + premiumAmount + ", rcd=" + rcd + "]";
	}
	
	
	
	
	
	
	
	

}
