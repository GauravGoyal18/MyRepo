package com.ipru.groups.po;

import java.io.Serializable;

public class ServiceWebPageMenuPO implements Serializable {

	private Long requestMenuID;
	private String requestMenuName;
	private String formatLink;

	public ServiceWebPageMenuPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceWebPageMenuPO(Long requestMenuID, String requestMenuName, String formatLink) {
		super();
		this.requestMenuID = requestMenuID;
		this.requestMenuName = requestMenuName;
		this.formatLink = formatLink;
	}

	public Long getRequestMenuID() {
		return requestMenuID;
	}

	public void setRequestMenuID(Long requestMenuID) {
		this.requestMenuID = requestMenuID;
	}

	public String getRequestMenuName() {
		return requestMenuName;
	}

	public void setRequestMenuName(String requestMenuName) {
		this.requestMenuName = requestMenuName;
	}

	public String getFormatLink() {
		return formatLink;
	}

	public void setFormatLink(String formatLink) {
		this.formatLink = formatLink;
	}

	@Override
	public String toString() {
		return "ServiceWebPageMenuPO [requestMenuID=" + requestMenuID + ", requestMenuName=" + requestMenuName + ", formatLink=" + formatLink + "]";
	}

}
