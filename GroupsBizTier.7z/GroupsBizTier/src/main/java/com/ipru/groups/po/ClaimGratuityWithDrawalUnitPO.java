package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

import com.tcs.web.po.BasePO;

public class ClaimGratuityWithDrawalUnitPO  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private long withDrawalId;
	private String planName;
	private int withdrawalPercent;
	
	
	
	public long getWithDrawalId() {
		return withDrawalId;
	}
	public void setWithDrawalId(long withDrawalId) {
		this.withDrawalId = withDrawalId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public int getWithdrawalPercent() {
		return withdrawalPercent;
	}
	public void setWithdrawalPercent(int withdrawalPercent) {
		this.withdrawalPercent = withdrawalPercent;
	}
	@Override
	public String toString() {
		return "ClaimGratuityWithDrawalUnitVO [withDrawalId=" + withDrawalId + ", planName=" + planName + ", withdrawalPercent=" + withdrawalPercent + "]";
	}
	
	
	private static ClaimGratuityWithDrawalUnitPO instance;
	 private static final String CLASSNAME = ClaimGratuityWithDrawalUnitPO.class .getCanonicalName();
         
	/*private ClaimGratuityWithDrawalUnitPO() {
	
	}
	

	 public static ClaimGratuityWithDrawalUnitPO getInstance() {
      if (instance == null) {
                      synchronized (CLASSNAME) {
                                      instance = new ClaimGratuityWithDrawalUnitPO();
                      }
      }
      return instance;
	
	
	
}*/

	

}
