package com.ipru.groups.po;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FundPerformancePO extends GroupsBasePo{
	
	private static final long serialVersionUID = 1L;
	
	
	private List<String> x ;
	private List<Double> y ;
	private List<Double> yy ;
	private String benchMarkSNIF;
	
	
	public String getBenchMarkSNIF() {
		return benchMarkSNIF;
	}
	public void setBenchMarkSNIF(String benchMarkSNIF) {
		this.benchMarkSNIF = benchMarkSNIF;
	}
	public List<Double> getYy() {
		return yy;
	}
	public void setYy(List<Double> yy) {
		this.yy = yy;
	}
	
	public List<String> getX() {
		return x;
	}
	public void setX(List<String> x) {
		this.x = x;
	}
	public List<Double> getY() {
		return y;
	}
	public void setY(List<Double> y) {
		this.y = y;
	}
	


}

