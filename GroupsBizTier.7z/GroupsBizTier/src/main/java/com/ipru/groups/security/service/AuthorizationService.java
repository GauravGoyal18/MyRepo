package com.ipru.groups.security.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.security.dao.AuthorizationDAO;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;
import com.tcs.service.BaseService;

public class AuthorizationService extends BaseService{
	
	private AuthorizationDAO authorizationDAO=null;
	private final String CLASS_NAME="AuthorizationService";
	
	/**
	 * Method to get the object for dao class
	 * @return
	 */
	private AuthorizationDAO getDao()
	{
		if(authorizationDAO==null)
			authorizationDAO=new AuthorizationDAO("GroupSecurity");
		return authorizationDAO;
	}
	
	public List<RoleScreenAccessMappingVO> getAccessMatrixForAccessGroup(String accessGroup, String policyNo) throws Throwable
	{
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForAccessGroup", "method starts");
		authorizationDAO=this.getDao();
		List<RoleScreenAccessMappingVO> getAccessMatrixForAccessGroup=authorizationDAO.getAccessMatrix(accessGroup, policyNo);
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForAccessGroup", "method ends");
		return getAccessMatrixForAccessGroup;
	}
	
	public IPruUser getAccessMatrixForAccessGroup(IPruUser userVO) throws Throwable{
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForAccessGroup", "method starts");
		authorizationDAO=this.getDao();
		
		userVO = authorizationDAO.getAccessMatrixForAccessGroup(userVO);
		
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForAccessGroup", "method ends");
		return userVO;
	}
	
	public List<RoleScreenAccessMappingVO> getAccessMatrixForScreenCode(String screenCode) throws Throwable
	{
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForScreenCode", "method starts");
		authorizationDAO=this.getDao();
		List<RoleScreenAccessMappingVO> getAccessMatrixForScreenCode=authorizationDAO.getAccessMatrix(screenCode, null);
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForScreenCode", "method ends");
		return getAccessMatrixForScreenCode;
	}
	
	/*public RoleScreenAccessMappingVO getAccessMatrixForAccessGroupAndScreenCode(String accessGroup, String screenCode) throws Throwable
	{
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForAccessGroupAndScreenCode", "method starts");
		authorizationDAO=this.getDao();
		RoleScreenAccessMappingVO getAccessMatrixForAccessGroupAndScreenCode=authorizationDAO.getAccessMatrix(accessGroup, screenCode);
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForAccessGroupAndScreenCode", "method ends");
		return getAccessMatrixForAccessGroupAndScreenCode;
	}
	
	public List<RoleScreenAccessMappingVO> getAccessMatrixForESignPad(List<String> screenCodeLst) throws Throwable {
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForESignPad", "method starts");
		authorizationDAO = this.getDao();
		List<RoleScreenAccessMappingVO> lst_ESignAccessMatrixScreen = new ArrayList<RoleScreenAccessMappingVO>();
		try{
			lst_ESignAccessMatrixScreen = authorizationDAO.getAccessMatrixForESignPad(screenCodeLst);
		}
		catch(Exception e){
			FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForESignPad", "Exception Occured::"+e.getMessage());
			e.printStackTrace();
		}
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForESignPad", "method ends");
		return lst_ESignAccessMatrixScreen;
	}
	*/
	public List<RoleScreenAccessMappingVO> getAccessMatrix() throws Throwable
	{
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrix", "method starts");
		authorizationDAO=this.getDao();
		List<RoleScreenAccessMappingVO> getAccessMatrix=authorizationDAO.getAccessMatrix();
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrix", "method ends");
		return getAccessMatrix;
	}
	
	/*public RoleScreenAccessMappingVO getAccessMatrixForAccessGroupAndScreenCodeAndDevice(String accessGroup, String screenCode,String device) throws Throwable {
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForAccessGroupAndScreenCodeAndDevice", "method starts");
		authorizationDAO = this.getDao();
		RoleScreenAccessMappingVO getAccessMatrixForAccessGroupAndScreenCode = authorizationDAO.getAccessMatrix(accessGroup, screenCode, device);
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForAccessGroupAndScreenCodeAndDevice", "method ends");
		return getAccessMatrixForAccessGroupAndScreenCode;
	}*/

	/**
	 * Added By Sushma - Access matrix in CRUD form
	 * @param accessGroup
	 * @return
	 * @throws Throwable
	 */
	public Map<String,String> getAccessMatrixMapForAccessGroup(String accessGroup) throws Throwable {
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixMapForAccessGroup", "method starts");		
		List<RoleScreenAccessMappingVO> lstRoleScreens= this.getAccessMatrixForAccessGroup(accessGroup, null);
		Iterator<RoleScreenAccessMappingVO> itr = lstRoleScreens.iterator();
		Map<String,String> mAccessMatrix = new HashMap<String, String>();
		StringBuilder strCrud = null;	
		while(itr.hasNext())
		{
			strCrud = new StringBuilder() ;
			final RoleScreenAccessMappingVO roleScreen = itr.next();
			if(StringUtils.equalsIgnoreCase(roleScreen.getHasCreate(),"yes"))
				strCrud.append("C");
			
			if(StringUtils.equalsIgnoreCase(roleScreen.getHasRead(),"yes"))
				strCrud.append("R");
			
			if(StringUtils.equalsIgnoreCase(roleScreen.getHasUpdate(),"yes"))
				strCrud.append("U");
			
			if(StringUtils.equalsIgnoreCase(roleScreen.getHasDelete(),"yes"))
				strCrud.append("D");
			
			if(StringUtils.equalsIgnoreCase(roleScreen.getRoleLandingPage(),"yes"))
				strCrud.append("L");
			
			mAccessMatrix.put(roleScreen.getScreenCode(), strCrud.toString());
			strCrud = null;
		}
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixMapForAccessGroup", "method ends");
		itr = null;
		lstRoleScreens = null;
		return mAccessMatrix;
	}

	public List<RoleScreenAccessMappingVO> getAccessMatrixForAccessGroupSSO(String roles) throws Throwable {
		// TODO Auto-generated method stub
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForAccessGroupSSO", "method starts");
		authorizationDAO=this.getDao();
		List<RoleScreenAccessMappingVO> getAccessMatrixForAccessGroup=authorizationDAO.getAccessMatrixSSO(roles);
		FLogger.info("securityLogger", CLASS_NAME, "getAccessMatrixForAccessGroupSSO", "method ends");
		return getAccessMatrixForAccessGroup;
	}
}
