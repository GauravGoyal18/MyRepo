package com.ipru.groups.vo;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class FundDataGratuityVO implements Serializable {

	private String funddesc;
	private double units;
	private double navValue;
	private double totalAmount;
	private String sfin;

	public String getFunddesc() {
		return funddesc;
	}

	public void setFunddesc(String funddesc) {
		this.funddesc = funddesc;
	}

	public double getUnits() {
		return units;
	}

	public void setUnits(double units) {
		this.units = units;
	}

	public double getNavValue() {
		return navValue;
	}

	public void setNavValue(double navValue) {
		this.navValue = navValue;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getSfin() {
		return sfin;
	}

	public void setSfin(String sfin) {
		this.sfin = sfin;
	}

	@Override
	public String toString() {
		return "FundDataGratuityVO [funddesc=" + funddesc + ", units=" + units
				+ ", navValue=" + navValue + ", totalAmount=" + totalAmount
				+ ", sfin=" + sfin + "]";
	}

}
