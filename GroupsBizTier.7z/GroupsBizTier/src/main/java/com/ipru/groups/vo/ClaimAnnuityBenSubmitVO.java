package com.ipru.groups.vo;

import java.util.Date;

public class ClaimAnnuityBenSubmitVO extends GroupsBaseVO {

	private Long benId;

	private String benName;
	private String benDob;
	private String gender;
	private String relWithAnnty;
	private String appointeeName;
	private String relWithBen;

	private Long allocationPer;
	private String address1;
	private String address2;
	private String address3;
	private String state;
	private String city;
	private String pinCode;
	private String landlineNo;
	private String mobileNo;

	private String maritalStatus;
	private Date requstedTime;
	private Long claimTxnId;
	private String beneficiaryPos;

	public String getBeneficiaryPos() {
		return beneficiaryPos;
	}

	public void setBeneficiaryPos(String beneficiaryPos) {
		this.beneficiaryPos = beneficiaryPos;
	}

	public Long getBenId() {
		return benId;
	}

	public void setBenId(Long benId) {
		this.benId = benId;
	}

	public String getBenName() {
		return benName;
	}

	public void setBenName(String benName) {
		this.benName = benName;
	}

	public String getBenDob() {
		return benDob;
	}

	public void setBenDob(String benDob) {
		this.benDob = benDob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRelWithAnnty() {
		return relWithAnnty;
	}

	public void setRelWithAnnty(String relWithAnnty) {
		this.relWithAnnty = relWithAnnty;
	}

	public String getAppointeeName() {
		return appointeeName;
	}

	public void setAppointeeName(String appointeeName) {
		this.appointeeName = appointeeName;
	}

	public String getRelWithBen() {
		return relWithBen;
	}

	public void setRelWithBen(String relWithBen) {
		this.relWithBen = relWithBen;
	}

	public Long getAllocationPer() {
		return allocationPer;
	}

	public void setAllocationPer(Long allocationPer) {
		this.allocationPer = allocationPer;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getLandlineNo() {
		return landlineNo;
	}

	public void setLandlineNo(String landlineNo) {
		this.landlineNo = landlineNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public Date getRequstedTime() {
		return requstedTime;
	}

	public void setRequstedTime(Date requstedTime) {
		this.requstedTime = requstedTime;
	}

	public Long getClaimTxnId() {
		return claimTxnId;
	}

	public void setClaimTxnId(Long claimTxnId) {
		this.claimTxnId = claimTxnId;
	}

}
