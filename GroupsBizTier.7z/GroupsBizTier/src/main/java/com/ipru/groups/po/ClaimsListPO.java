package com.ipru.groups.po;

import java.util.List;

public class ClaimsListPO extends GroupsBasePo {

	private List<ClaimsSubmitPO> addClaims;

	public List<ClaimsSubmitPO> getAddClaims() {
		return addClaims;
	}

	public void setAddClaims(List<ClaimsSubmitPO> addClaims) {
		this.addClaims = addClaims;
	}

}
