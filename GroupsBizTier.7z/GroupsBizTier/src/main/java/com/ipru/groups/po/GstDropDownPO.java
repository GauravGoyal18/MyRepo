package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class GstDropDownPO implements Serializable {

	/*
	 * private List cob; private List custType; private List state; private List
	 * stateCode;
	 */
	private List cob;
	private List custType;
	private List state;
	private List registrationStatusList;
	private Map stateAndStateCode;
	private String policyNo;

	public Map getStateAndStateCode() {
		return stateAndStateCode;
	}

	public void setStateAndStateCode(Map stateAndStateCode) {
		this.stateAndStateCode = stateAndStateCode;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public List getState() {
		return state;
	}

	public void setState(List state) {
		this.state = state;
	}

	public List getCob() {
		return cob;
	}

	public void setCob(List cob) {
		this.cob = cob;
	}

	public List getCustType() {
		return custType;
	}

	public void setCustType(List custType) {
		this.custType = custType;
	}

	public List getRegistrationStatusList() {
		return registrationStatusList;
	}

	public void setRegistrationStatusList(List registrationStatusList) {
		this.registrationStatusList = registrationStatusList;
	}

}
