package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class PolicyProductFundMasterVO extends BaseVO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long ppfmId;
	private String ppfmPolicyNo;
	private String ppfmProductCode;
	private String ppfmFundCode;
	private String ppfmFundName;
	private String isActive;
	private String isCapital;
	private String isReturnGuarantee;
	private String ppfmAssetType;

	public long getPpfmId() {
		return ppfmId;
	}

	public void setPpfmId(long ppfmId) {
		this.ppfmId = ppfmId;
	}

	public String getPpfmPolicyNo() {
		return ppfmPolicyNo;
	}

	public void setPpfmPolicyNo(String ppfmPolicyNo) {
		this.ppfmPolicyNo = ppfmPolicyNo;
	}

	public String getPpfmProductCode() {
		return ppfmProductCode;
	}

	public void setPpfmProductCode(String ppfmProductCode) {
		this.ppfmProductCode = ppfmProductCode;
	}

	public String getPpfmFundCode() {
		return ppfmFundCode;
	}

	public void setPpfmFundCode(String ppfmFundCode) {
		this.ppfmFundCode = ppfmFundCode;
	}

	public String getPpfmFundName() {
		return ppfmFundName;
	}

	public void setPpfmFundName(String ppfmFundName) {
		this.ppfmFundName = ppfmFundName;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getIsCapital() {
		return isCapital;
	}

	public void setIsCapital(String isCapital) {
		this.isCapital = isCapital;
	}

	public String getIsReturnGuarantee() {
		return isReturnGuarantee;
	}

	public void setIsReturnGuarantee(String isReturnGuarantee) {
		this.isReturnGuarantee = isReturnGuarantee;
	}

	public String getPpfmAssetType() {
		return ppfmAssetType;
	}

	public void setPpfmAssetType(String ppfmAssetType) {
		this.ppfmAssetType = ppfmAssetType;
	}

}
