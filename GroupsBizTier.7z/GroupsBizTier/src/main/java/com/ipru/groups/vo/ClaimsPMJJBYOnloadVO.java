package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class ClaimsPMJJBYOnloadVO extends GroupsBaseVO {

	
	private String schemeName;
	private String accountNumber;
	private String polHolderName;
	

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPolHolderName() {
		return polHolderName;
	}

	public void setPolHolderName(String polHolderName) {
		this.polHolderName = polHolderName;
	}

}
