package com.ipru.groups.po;

import java.io.Serializable;

import com.tcs.vo.BaseVO;

public class RetirementCalenderRequestPO extends BaseVO {
	
	private String policyNumber;
	private String role;
	

	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	
	@Override
	public String toString() {
		return "RetirementCalenderRequestPO [policyNumber=" + policyNumber
				+ ", role=" + role + "]";
	}
}
