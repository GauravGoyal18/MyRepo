package com.ipru.groups.po;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ipru.groups.param.obj.ParamObj;



@XmlRootElement
public class PrePopulateBean{

	private String className;
	private String functionality;
	private ParamObj paramObj;
	private String max;
	
	
	@Override
	public String toString() {
		return "PrePopulateBean [className=" + className + ", functionality="
				+ functionality + ", paramObj=" + paramObj + ", max=" + max
				+ "]";
	}

	public String getMax() {
		return max;
	}

	public void setMax(String max) {
		this.max = max;
	}

	@XmlElement
	public ParamObj getParamObj() {
		return paramObj;
	}

	public void setParamObj(ParamObj paramObj) {
		this.paramObj = paramObj;
	}

	@XmlElement
	public String getFunctionality() {
		return functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}

	@XmlElement
	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public PrePopulateBean(String className, String functionality) {
		super();
		this.className = className;
		this.functionality = functionality;
	}

	public PrePopulateBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}

