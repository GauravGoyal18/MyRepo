package com.ipru.groups.po;

import java.util.List;
import java.util.Map;

import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.tcs.vo.BaseVO;

public class ProfileUpdateLoadRequestPO extends BaseVO {
	private static final long serialVersionUID = 1L;
	private String policyNo;
	private String role;
	private String clientId;

	private String screenName;
	private List<RoleScreenAccessMappingVO> accessMappingList;
	private List<FieldAccessMappingVO> fieldAccessMappingList;

	public ProfileUpdateLoadRequestPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<FieldAccessMappingVO> getFieldAccessMappingList() {
		return fieldAccessMappingList;
	}

	public void setFieldAccessMappingList(
			List<FieldAccessMappingVO> fieldAccessMappingList) {
		this.fieldAccessMappingList = fieldAccessMappingList;
	}

	public ProfileUpdateLoadRequestPO(String policyNo, String role,
			String clientId, String screenName,
			List<RoleScreenAccessMappingVO> accessMappingList,
			List<FieldAccessMappingVO> fieldAccessMappingList) {
		super();
		this.policyNo = policyNo;
		this.role = role;
		this.clientId = clientId;
		this.screenName = screenName;
		this.accessMappingList = accessMappingList;
		this.fieldAccessMappingList = fieldAccessMappingList;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public List<RoleScreenAccessMappingVO> getAccessMappingList() {
		return accessMappingList;
	}

	public void setAccessMappingList(
			List<RoleScreenAccessMappingVO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}

	@Override
	public String toString() {
		return "ProfileUpdateLoadRequestPO [policyNo=" + policyNo + ", role="
				+ role + ", clientId=" + clientId + ", screenName="
				+ screenName + ", accessMappingList=" + accessMappingList
				+ ", fieldAccessMappingList=" + fieldAccessMappingList + "]";
	}

}
