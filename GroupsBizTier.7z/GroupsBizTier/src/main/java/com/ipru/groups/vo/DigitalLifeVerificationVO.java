package com.ipru.groups.vo;

import java.util.Date;
import java.util.List;

import com.ipru.groups.po.UploadFilePO;

public class DigitalLifeVerificationVO extends GroupsBaseVO implements ISpaarcCallLog {

	private static final long serialVersionUID = 1L;
	private long requestId;
	private String contractid;
	private String firstname;
	private String policyid;
	private String masterPolNo;
	private String trustname;
	private String dateofbirth;
	private String panno;
	private long phonemobile;
	private String createdDate;
	private FunctionalityMasterVO functionality;
	private List<UploadFileVO> uploadFileList;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getContractid() {
		return contractid;
	}
	public void setContractid(String contractid) {
		this.contractid = contractid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getPolicyid() {
		return policyid;
	}
	public void setPolicyid(String policyid) {
		this.policyid = policyid;
	}
	public String getMasterPolNo() {
		return masterPolNo;
	}
	public void setMasterPolNo(String masterPolNo) {
		this.masterPolNo = masterPolNo;
	}
	public String getTrustname() {
		return trustname;
	}
	public void setTrustname(String trustname) {
		this.trustname = trustname;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getPanno() {
		return panno;
	}
	public void setPanno(String panno) {
		this.panno = panno;
	}
	public long getPhonemobile() {
		return phonemobile;
	}
	public void setPhonemobile(long phonemobile) {
		this.phonemobile = phonemobile;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}
	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}
	public List<UploadFileVO> getUploadFileList() {
		return uploadFileList;
	}
	public void setUploadFileList(List<UploadFileVO> uploadFileList) {
		this.uploadFileList = uploadFileList;
	}
	@Override
	public String toString() {
		return "DigitalLifeVerificationVO [requestId=" + requestId
				+ ", contractid=" + contractid + ", firstname=" + firstname
				+ ", policyid=" + policyid + ", masterPolNo=" + masterPolNo
				+ ", trustname=" + trustname + ", dateofbirth=" + dateofbirth
				+ ", panno=" + panno + ", phonemobile=" + phonemobile
				+ ", createdDate=" + createdDate + ", functionality="
				+ functionality + ", uploadFileList=" + uploadFileList + "]";
	}
	@Override
	public String getFunctionalityReqId() {
		return String.valueOf(getRequestId());
	}






}
