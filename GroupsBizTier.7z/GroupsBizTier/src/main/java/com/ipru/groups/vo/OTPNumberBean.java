package com.ipru.groups.vo;

import java.io.Serializable;
import java.sql.Timestamp;

public class OTPNumberBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private long transactionId = 0;
	private String advisorCode = "";
	private String advisorName = "";
	private String custId = "";
	private String email1 = "";
	private String email2 = "";
	private String personalEmail = "";
	private String mobile = "";
	private String customerName = "";
	private String loginRole = "";
	private Timestamp otpCreatedDate = null;

	public String getLoginRole() {
		return loginRole;
	}

	public void setLoginRole(String loginRole) {
		this.loginRole = loginRole;
	}

	public Timestamp getOtpCreatedDate() {
		return otpCreatedDate;
	}

	public void setOtpCreatedDate(Timestamp otpCreatedDate) {
		this.otpCreatedDate = otpCreatedDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public String getAdvisorCode() {
		return advisorCode;
	}

	public void setAdvisorCode(String advisorCode) {
		this.advisorCode = advisorCode;
	}

	public String getAdvisorName() {
		return advisorName;
	}

	public void setAdvisorName(String advisorName) {
		this.advisorName = advisorName;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getEmail1() {
		return email1;
	}

	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	public String getEmail2() {
		return email2;
	}

	public void setEmail2(String email2) {
		this.email2 = email2;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPersonalEmail() {
		return personalEmail;
	}

	public void setPersonalEmail(String personalEmail) {
		this.personalEmail = personalEmail;
	}

	/*
	 * public Set<OtpSmsTransactionVO> getoTPSmsTransactions() { return
	 * oTPSmsTransactions; } public void
	 * setoTPSmsTransactions(Set<OtpSmsTransactionVO> oTPSmsTransactions) {
	 * this.oTPSmsTransactions = oTPSmsTransactions; }
	 */

	// private Set<OtpSmsTransactionVO> oTPSmsTransactions;

}
