package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

public class MemberDataListPO implements Serializable {

	private List memberPOList;
	private String policyNo;
	private String role;
	private String memberType;
	private String productType;

	public MemberDataListPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberDataListPO(List memberPOList, String policyNo, String role,
			String memberType, String productType) {
		super();
		this.memberPOList = memberPOList;
		this.policyNo = policyNo;
		this.role = role;
		this.memberType = memberType;
		this.productType = productType;
	}

	public List getMemberPOList() {
		return memberPOList;
	}

	public void setMemberPOList(List memberPOList) {
		this.memberPOList = memberPOList;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	@Override
	public String toString() {
		return "MemberDataListPO [memberPOList=" + memberPOList + ", policyNo="
				+ policyNo + ", role=" + role + ", memberType=" + memberType
				+ ", productType=" + productType + "]";
	}

}
