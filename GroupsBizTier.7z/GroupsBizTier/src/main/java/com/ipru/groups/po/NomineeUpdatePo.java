package com.ipru.groups.po;

import com.tcs.web.po.BasePO;

public class NomineeUpdatePo extends BasePO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String beneficaryName;
	private String dob;
	private String relation;
	private String gender;
	private int sharePer;

	/*
	 * private String address1; private String address2; private int pincode;
	 */
	public String getBeneficaryName() {
		return beneficaryName;
	}

	public void setBeneficaryName(String beneficaryName) {
		this.beneficaryName = beneficaryName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public synchronized int getSharePer() {
		return sharePer;
	}

	public synchronized void setSharePer(int sharePer) {
		this.sharePer = sharePer;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "NomineeUpdatePo [beneficaryName=" + beneficaryName + ", dob=" + dob + ", relation=" + relation + ", gender=" + gender + ", sharePer=" + sharePer + "]";
	}

}
