package com.ipru.groups.vo;

import com.tcs.web.vo.BaseVO;

public class RetirementCalenderRequestVO extends BaseVO {
	
	private String policyNumber;
	private String role;

	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "RetirementCalenderRequestVO [policyNumber=" + policyNumber
				+ ", role=" + role + "]";
	}
	
	
	

}
