package com.ipru.groups.po;

import java.util.Set;

public class NomineePMJJBYSubmitPO extends GroupsBasePo {
	
	private static final long serialVersionUID = 1L;
	
	private String schemeName;
	private String accountNumber;
	private String effectiveDate;

	private Set<NomineeBenPMJJBYSubmitPO> beneficiary;


	public Set<NomineeBenPMJJBYSubmitPO> getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(Set<NomineeBenPMJJBYSubmitPO> beneficiary) {
		this.beneficiary = beneficiary;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	

	

}
