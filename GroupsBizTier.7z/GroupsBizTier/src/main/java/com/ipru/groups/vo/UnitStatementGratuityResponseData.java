package com.ipru.groups.vo;

import java.util.ArrayList;
import java.util.Map;

import com.tcs.vo.BaseVO;

public class UnitStatementGratuityResponseData extends BaseVO{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Map<String,ArrayList<UnitStatementGratuityFundDetailsVO>> gratutyFundMapData;
	private String closingBalance;
	
	
	
	
	public Map<String, ArrayList<UnitStatementGratuityFundDetailsVO>> getGratutyFundMapData() {
		return gratutyFundMapData;
	}
	public void setGratutyFundMapData(
			Map<String, ArrayList<UnitStatementGratuityFundDetailsVO>> gratutyFundMapData) {
		this.gratutyFundMapData = gratutyFundMapData;
	}
	public String getClosingBalance() {
		return closingBalance;
	}
	public void setClosingBalance(String closingBalance) {
		this.closingBalance = closingBalance;
	}
	@Override
	public String toString() {
		return "UnitStatementGratuityResponseData [gratutyFundMapData="
				+ gratutyFundMapData + ", closingBalance=" + closingBalance
				+ "]";
	}
	
	

}
