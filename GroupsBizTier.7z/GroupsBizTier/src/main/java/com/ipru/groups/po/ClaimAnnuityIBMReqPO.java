package com.ipru.groups.po;

public class ClaimAnnuityIBMReqPO extends GroupsBasePo {
	
	
	private String employeeId;

	@Override
	public String toString() {
		return "ClaimAnnuityReqPO [employeeId=" + employeeId + "]";
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	

}
