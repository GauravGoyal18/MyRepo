package com.ipru.groups.vo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.ipru.groups.po.ClaimsBenPMJJBYSubmitPO;
import com.ipru.groups.po.UploadFilePO;

public class ClaimsPMJJBYSubmitVO extends GroupsBaseVO implements ISpaarcCallLog {

	private Long requestId;
	private String schemeName;
	private String accountNumber;
	private String polHolderName;
	private String claimDate;
	private String deathDate;
	private String deathReason;
	private FunctionalityMasterVO functionality;
	private Set<ClaimsBenPMJJBYSubmitVO> beneficiary;
	private List<UploadFileVO> claimForm = new ArrayList<UploadFileVO>();
	private List<UploadFileVO> deathCertificate = new ArrayList<UploadFileVO>(0);
	private List<UploadFileVO> cancelledCheque = new ArrayList<UploadFileVO>(0);

	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}

	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}

	public Set<ClaimsBenPMJJBYSubmitVO> getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(Set<ClaimsBenPMJJBYSubmitVO> beneficiary) {
		this.beneficiary = beneficiary;
	}

	public List<UploadFileVO> getClaimForm() {
		return claimForm;
	}

	public void setClaimForm(List<UploadFileVO> claimForm) {
		this.claimForm = claimForm;
	}

	public List<UploadFileVO> getDeathCertificate() {
		return deathCertificate;
	}

	public void setDeathCertificate(List<UploadFileVO> deathCertificate) {
		this.deathCertificate = deathCertificate;
	}

	public List<UploadFileVO> getCancelledCheque() {
		return cancelledCheque;
	}

	public void setCancelledCheque(List<UploadFileVO> cancelledCheque) {
		this.cancelledCheque = cancelledCheque;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPolHolderName() {
		return polHolderName;
	}

	public void setPolHolderName(String polHolderName) {
		this.polHolderName = polHolderName;
	}

	public String getClaimDate() {
		return claimDate;
	}

	public void setClaimDate(String claimDate) {
		this.claimDate = claimDate;
	}

	public String getDeathDate() {
		return deathDate;
	}

	public void setDeathDate(String deathDate) {
		this.deathDate = deathDate;
	}

	public String getDeathReason() {
		return deathReason;
	}

	public void setDeathReason(String deathReason) {
		this.deathReason = deathReason;
	}

	@Override
	public String getFunctionalityReqId() {
		// TODO Auto-generated method stub
		return String.valueOf(this.requestId);
	}

}
