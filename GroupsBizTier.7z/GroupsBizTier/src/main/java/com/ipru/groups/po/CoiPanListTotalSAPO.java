package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

public class CoiPanListTotalSAPO implements Serializable {

	private List<CoiPannoPO> coiPOList;
	private String totalSumAssured;

	public List<CoiPannoPO> getCoiPOList() {
		return coiPOList;
	}

	public void setCoiPOList(List<CoiPannoPO> coiPOList) {
		this.coiPOList = coiPOList;
	}

	public String getTotalSumAssured() {
		return totalSumAssured;
	}

	public void setTotalSumAssured(String totalSumAssured) {
		this.totalSumAssured = totalSumAssured;
	}

}
