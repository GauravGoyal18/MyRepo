package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ipru.groups.vo.ClaimGratuityVO;
import com.tcs.web.po.BasePO;

public class ClaimGratuityPO  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private long requestId;
	private String policyNumber;
	private String trustieeName;
	private String claimType;
	private String employeeName;
	private String memberId;
	private String dob;
	private String doj;
	
	private String dor;
	private String lwd;
	private long lastDrawnSalary;
	private String disability;
	private String monthOfService;
	private String dateOfDeath;
	private String causeOfClaim;
	
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String state;
	private String city;
	private String majorMinor;
	private String beneficiaryFirstName;
	private String beneficiaryMiddleName;
	private String beneficiarySurName;
	private String beneficiaryRelation;
	private String appointeeFirstName;
	private String appointeeMiddleName;
	private String appointeeSurName;
	private String appointeeRelation;
	private String claimCause;
	private String docList;
	private Set<ClaimGratuityWithDrawalUnitPO> withdrawalUnit=new HashSet<ClaimGratuityWithDrawalUnitPO>();
	private long amountPaid;
	private String payeeName;
	private Set<ClaimGratuityLeavePO> leaveArray=new HashSet<ClaimGratuityLeavePO>();
	private boolean firstTimeUser;
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getTrustieeName() {
		return trustieeName;
	}
	public void setTrustieeName(String trustieeName) {
		this.trustieeName = trustieeName;
	}
	public String getClaimType() {
		return claimType;
	}
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getDor() {
		return dor;
	}
	public void setDor(String dor) {
		this.dor = dor;
	}
	public String getLwd() {
		return lwd;
	}
	public void setLwd(String lwd) {
		this.lwd = lwd;
	}
	public long getLastDrawnSalary() {
		return lastDrawnSalary;
	}
	public void setLastDrawnSalary(long lastDrawnSalary) {
		this.lastDrawnSalary = lastDrawnSalary;
	}
	public String getDisability() {
		return disability;
	}
	public void setDisability(String disability) {
		this.disability = disability;
	}
	public String getMonthOfService() {
		return monthOfService;
	}
	public void setMonthOfService(String monthOfService) {
		this.monthOfService = monthOfService;
	}
	public String getDateOfDeath() {
		return dateOfDeath;
	}
	public void setDateOfDeath(String dateOfDeath) {
		this.dateOfDeath = dateOfDeath;
	}
	public String getCauseOfClaim() {
		return causeOfClaim;
	}
	public void setCauseOfClaim(String causeOfClaim) {
		this.causeOfClaim = causeOfClaim;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getMajorMinor() {
		return majorMinor;
	}
	public void setMajorMinor(String majorMinor) {
		this.majorMinor = majorMinor;
	}
	
	public String getBeneficiaryFirstName() {
		return beneficiaryFirstName;
	}
	public void setBeneficiaryFirstName(String beneficiaryFirstName) {
		this.beneficiaryFirstName = beneficiaryFirstName;
	}
	public String getBeneficiaryMiddleName() {
		return beneficiaryMiddleName;
	}
	public void setBeneficiaryMiddleName(String beneficiaryMiddleName) {
		this.beneficiaryMiddleName = beneficiaryMiddleName;
	}
	public String getBeneficiarySurName() {
		return beneficiarySurName;
	}
	public void setBeneficiarySurName(String beneficiarySurName) {
		this.beneficiarySurName = beneficiarySurName;
	}
	public String getBeneficiaryRelation() {
		return beneficiaryRelation;
	}
	public void setBeneficiaryRelation(String beneficiaryRelation) {
		this.beneficiaryRelation = beneficiaryRelation;
	}
	public String getAppointeeFirstName() {
		return appointeeFirstName;
	}
	public void setAppointeeFirstName(String appointeeFirstName) {
		this.appointeeFirstName = appointeeFirstName;
	}
	public String getAppointeeMiddleName() {
		return appointeeMiddleName;
	}
	public void setAppointeeMiddleName(String appointeeMiddleName) {
		this.appointeeMiddleName = appointeeMiddleName;
	}
	public String getAppointeeSurName() {
		return appointeeSurName;
	}
	public void setAppointeeSurName(String appointeeSurName) {
		this.appointeeSurName = appointeeSurName;
	}
	public String getAppointeeRelation() {
		return appointeeRelation;
	}
	public void setAppointeeRelation(String appointeeRelation) {
		this.appointeeRelation = appointeeRelation;
	}
	public String getClaimCause() {
		return claimCause;
	}
	public void setClaimCause(String claimCause) {
		this.claimCause = claimCause;
	}
	public String getDocList() {
		return docList;
	}
	public void setDocList(String docList) {
		this.docList = docList;
	}
	public Set<ClaimGratuityWithDrawalUnitPO> getWithdrawalUnit() {
		return withdrawalUnit;
	}
	public void setWithdrawalUnit(Set<ClaimGratuityWithDrawalUnitPO> withdrawalUnit) {
		this.withdrawalUnit = withdrawalUnit;
	}
	public long getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(long amountPaid) {
		this.amountPaid = amountPaid;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public Set<ClaimGratuityLeavePO> getLeaveArray() {
		return leaveArray;
	}
	public void setLeaveArray(Set<ClaimGratuityLeavePO> leaveArray) {
		this.leaveArray = leaveArray;
	}
	
	public Boolean getFirstTimeUser() {
		return firstTimeUser;
	}
	public void setFirstTimeUser(Boolean firstTimeUser) {
		this.firstTimeUser = firstTimeUser;
	}
	@Override
	public String toString() {
		return "ClaimGratuityPO [requestId=" + requestId + ", policyNumber=" + policyNumber + ", trustieeName=" + trustieeName + ", claimType=" + claimType + ", employeeName=" + employeeName
				+ ", memberId=" + memberId + ", dob=" + dob + ", doj=" + doj + ", dor=" + dor + ", lwd=" + lwd + ", lastDrawnSalary=" + lastDrawnSalary + ", disability=" + disability
				+ ", monthOfService=" + monthOfService + ", dateOfDeath=" + dateOfDeath + ", causeOfClaim=" + causeOfClaim + ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2
				+ ", addressLine3=" + addressLine3 + ", state=" + state + ", city=" + city + ", majorMinor=" + majorMinor + ", beneficiaryFirstName=" + beneficiaryFirstName
				+ ", beneficiaryMiddleName=" + beneficiaryMiddleName + ", beneficiarySurName=" + beneficiarySurName + ", beneficiaryRelation=" + beneficiaryRelation + ", appointeeFirstName="
				+ appointeeFirstName + ", appointeeMiddleName=" + appointeeMiddleName + ", appointeeSurName=" + appointeeSurName + ", appointeeRelation=" + appointeeRelation + ", claimCause="
				+ claimCause + ", docList=" + docList + ", withdrawalUnit=" + withdrawalUnit + ", amountPaid=" + amountPaid + ", payeeName=" + payeeName + ", leaveArray=" + leaveArray
				+ ", firstTimeUser=" + firstTimeUser + "]";
	}
	
	
	
	
/*
	private static ClaimGratuityPO instance;
	 private static final String CLASSNAME = ClaimGratuityPO.class .getCanonicalName();
           
	private ClaimGratuityPO() {
	
	}
	

	 public static ClaimGratuityPO getInstance() {
        if (instance == null) {
                        synchronized (CLASSNAME) {
                                        instance = new ClaimGratuityPO();
                        }
        }
        return instance;

	 }*/

}
