package com.ipru.groups.po;

import java.util.Date;

import com.tcs.web.po.BasePO;

public class CustomerDetailsPO extends BasePO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Date transactionDate;
	
	private String trustName;
	private String memberName;
	private String address1;
	private String address2;
	private String address3;
	private String address4;
	private String address5;
	private String address6;

	private String policyType;
	private String empID;
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTrustName() {
		return trustName;
	}
	public void setTrustName(String trustName) {
		this.trustName = trustName;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getAddress4() {
		return address4;
	}
	public void setAddress4(String address4) {
		this.address4 = address4;
	}
	public String getAddress5() {
		return address5;
	}
	public void setAddress5(String address5) {
		this.address5 = address5;
	}
	public String getAddress6() {
		return address6;
	}
	public void setAddress6(String address6) {
		this.address6 = address6;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "CustomerDetailsPO [transactionDate=" + transactionDate
				+ ", trustName=" + trustName + ", memberName=" + memberName
				+ ", address1=" + address1 + ", address2=" + address2
				+ ", address3=" + address3 + ", address4=" + address4
				+ ", address5=" + address5 + ", address6=" + address6
				+ ", policyType=" + policyType + ", empID=" + empID + "]";
	}
	
	
	

}
