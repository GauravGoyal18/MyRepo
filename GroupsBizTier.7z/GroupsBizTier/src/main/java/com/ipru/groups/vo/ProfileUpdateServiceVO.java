package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;

public class ProfileUpdateServiceVO implements Serializable {
	private List<ProfileUpdateDetailsVo> getProfileUpdateDetailsVoList;
	
	private List<UploadFileVO>  getUploadFileVOList;
	
	private long functionalityId;

	public List<ProfileUpdateDetailsVo> getGetProfileUpdateDetailsVoList() {
		return getProfileUpdateDetailsVoList;
	}

	public void setGetProfileUpdateDetailsVoList(
			List<ProfileUpdateDetailsVo> getProfileUpdateDetailsVoList) {
		this.getProfileUpdateDetailsVoList = getProfileUpdateDetailsVoList;
	}

	public List<UploadFileVO> getGetUploadFileVOList() {
		return getUploadFileVOList;
	}

	public void setGetUploadFileVOList(List<UploadFileVO> getUploadFileVOList) {
		this.getUploadFileVOList = getUploadFileVOList;
	}

	public long getFunctionalityId() {
		return functionalityId;
	}

	public void setFunctionalityId(long functionalityId) {
		this.functionalityId = functionalityId;
	}

	@Override
	public String toString() {
		return "ProfileUpdateServiceVO [getProfileUpdateDetailsVoList="
				+ getProfileUpdateDetailsVoList + ", getUploadFileVOList="
				+ getUploadFileVOList + ", functionalityId=" + functionalityId
				+ "]";
	}
	

}
