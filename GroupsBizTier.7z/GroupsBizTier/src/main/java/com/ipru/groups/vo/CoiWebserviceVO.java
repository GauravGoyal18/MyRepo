package com.ipru.groups.vo;

public class CoiWebserviceVO extends GroupsBaseVO{

	private String policyCount;
	private String renewalNo;
	private String clientStatus;
	
	

	
	public String getClientStatus() {
		return clientStatus;
	}
	public void setClientStatus(String clientStatus) {
		this.clientStatus = clientStatus;
	}
	public String getPolicyCount() {
		return policyCount;
	}
	public void setPolicyCount(String policyCount) {
		this.policyCount = policyCount;
	}
	public String getRenewalNo() {
		return renewalNo;
	}
	public void setRenewalNo(String renewalNo) {
		this.renewalNo = renewalNo;
	}
	@Override
	public String toString() {
		return "CoiWebserviceVO [policyCount=" + policyCount + ", renewalNo="
				+ renewalNo + ", clientStatus=" + clientStatus + "]";
	}
	
}
