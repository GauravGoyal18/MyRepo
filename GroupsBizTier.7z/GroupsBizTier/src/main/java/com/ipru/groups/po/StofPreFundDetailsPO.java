package com.ipru.groups.po;

import java.util.Date;

import com.ipru.groups.grpswitch.bean.SwitchTransactionPO;
import com.tcs.web.po.BasePO;

public class StofPreFundDetailsPO extends BasePO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fundCode;
	private String fundNAV;
	private Date fundNAVEffectiveDate;
	private String preFundUnit;
	private String preFundAmount;

	public synchronized String getFundCode() {
		return fundCode;
	}

	public synchronized void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}

	public synchronized String getFundNAV() {
		return fundNAV;
	}

	public synchronized void setFundNAV(String fundNAV) {
		this.fundNAV = fundNAV;
	}

	public synchronized Date getFundNAVEffectiveDate() {
		return fundNAVEffectiveDate;
	}

	public synchronized void setFundNAVEffectiveDate(Date fundNAVEffectiveDate) {
		this.fundNAVEffectiveDate = fundNAVEffectiveDate;
	}

	public synchronized String getPreFundUnit() {
		return preFundUnit;
	}

	public synchronized void setPreFundUnit(String preFundUnit) {
		this.preFundUnit = preFundUnit;
	}

	public synchronized String getPreFundAmount() {
		return preFundAmount;
	}

	public synchronized void setPreFundAmount(String preFundAmount) {
		this.preFundAmount = preFundAmount;
	}

	@Override
	public String toString() {
		return "StofPreFundDetailsPO [fundCode=" + fundCode + ", fundNAV=" + fundNAV + ", fundNAVEffectiveDate=" + fundNAVEffectiveDate + ", preFundUnit=" + preFundUnit + ", preFundAmount="
				+ preFundAmount + "]";
	}

}
