package com.ipru.groups.grpswitch.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.ipru.groups.po.GroupsBasePo;
import com.ipru.groups.vo.ProductSwitchAmountVO;

public class SwitchFundDetailsPO extends GroupsBasePo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long switchFundDetailsId;
	private String fromFundCode;
	private String toFundCode;
	private String fromFundName;
	private String toFundName;
	private String switchType;
	
	
	/*private String transferNAV;   
	private String transferUnit;  
	private String transferAmount;*/
	
	private String fromNAV;   
	private String fromUnit;  
	private String fromAmount;
	private String toNAV;   
	private String toUnit;  
	private String toAmount;
	
/*	private String remainingFromUnit;  
	private String remainingFromAmount;
	private String remainingToUnit;  
	private String remainingToAmount;*/
	
	private SwitchTransactionPO switchTransactionPO;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;

	private String unitsOrAmount;
	
	//tofundNAV
	//remfromfundunit
	//remfromfundamt
	
	
	public String getFromFundName() {
		return fromFundName;
	}
	public void setFromFundName(String fromFundName) {
		this.fromFundName = fromFundName;
	}
	public String getToFundName() {
		return toFundName;
	}
	public void setToFundName(String toFundName) {
		this.toFundName = toFundName;
	}
	public Long getSwitchFundDetailsId() {
		return switchFundDetailsId;
	}
	public void setSwitchFundDetailsId(Long switchFundDetailsId) {
		this.switchFundDetailsId = switchFundDetailsId;
	}
	public String getFromFundCode() {
		return fromFundCode;
	}
	public void setFromFundCode(String fromFundCode) {
		this.fromFundCode = fromFundCode;
	}
	public String getToFundCode() {
		return toFundCode;
	}
	public void setToFundCode(String toFundCode) {
		this.toFundCode = toFundCode;
	}
	public String getSwitchType() {
		return switchType;
	}
	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}
	public String getFromNAV() {
		return fromNAV;
	}
	public void setFromNAV(String fromNAV) {
		this.fromNAV = fromNAV;
	}
	public String getFromUnit() {
		return fromUnit;
	}
	public void setFromUnit(String fromUnit) {
		this.fromUnit = fromUnit;
	}
	public String getFromAmount() {
		return fromAmount;
	}
	public void setFromAmount(String fromAmount) {
		this.fromAmount = fromAmount;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public SwitchTransactionPO getSwitchTransactionPO() {
		return switchTransactionPO;
	}
	public void setSwitchTransactionPO(SwitchTransactionPO switchTransactionPO) {
		this.switchTransactionPO = switchTransactionPO;
	}
	public String getToNAV() {
		return toNAV;
	}
	public void setToNAV(String toNAV) {
		this.toNAV = toNAV;
	}
	public String getToUnit() {
		return toUnit;
	}
	public void setToUnit(String toUnit) {
		this.toUnit = toUnit;
	}
	public String getToAmount() {
		return toAmount;
	}
	public void setToAmount(String toAmount) {
		this.toAmount = toAmount;
	}
	

/*	public String getRemainingFromUnit() {
		return remainingFromUnit;
	}
	public void setRemainingFromUnit(String remainingFromUnit) {
		this.remainingFromUnit = remainingFromUnit;
	}
	public String getRemainingFromAmount() {
		return remainingFromAmount;
	}
	public void setRemainingFromAmount(String remainingFromAmount) {
		this.remainingFromAmount = remainingFromAmount;
	}
	public String getRemainingToUnit() {
		return remainingToUnit;
	}
	public void setRemainingToUnit(String remainingToUnit) {
		this.remainingToUnit = remainingToUnit;
	}
	public String getRemainingToAmount() {
		return remainingToAmount;
	}
	public void setRemainingToAmount(String remainingToAmount) {
		this.remainingToAmount = remainingToAmount;
	}*/
	
	
/*	public String getTransferNAV() {
		return transferNAV;
	}
	public void setTransferNAV(String transferNAV) {
		this.transferNAV = transferNAV;
	}
	public String getTransferUnit() {
		return transferUnit;
	}
	public void setTransferUnit(String transferUnit) {
		this.transferUnit = transferUnit;
	}
	public String getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(String transferAmount) {
		this.transferAmount = transferAmount;
	}*/
/*	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((fromFundName == null) ? 0 : fromFundName.hashCode());
		result = prime * result
				+ ((toFundName == null) ? 0 : toFundName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SwitchFundDetailsPO other = (SwitchFundDetailsPO) obj;
		if (fromFundName == null) {
			if (other.fromFundName != null)
				return false;
		} else if (!fromFundName.equals(other.fromFundName))
			return false;
		if (toFundName == null) {
			if (other.toFundName != null)
				return false;
		} else if (!toFundName.equals(other.toFundName))
			return false;
		return true;
	}*/
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((fromFundCode == null) ? 0 : fromFundCode.hashCode());
		result = prime * result
				+ ((toFundCode == null) ? 0 : toFundCode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SwitchFundDetailsPO other = (SwitchFundDetailsPO) obj;
		if (fromFundCode == null) {
			if (other.fromFundCode != null)
				return false;
		} else if (!fromFundCode.equals(other.fromFundCode))
			return false;
		if (toFundCode == null) {
			if (other.toFundCode != null)
				return false;
		} else if (!toFundCode.equals(other.toFundCode))
			return false;
		return true;
	}
	public String getUnitsOrAmount() {
		return unitsOrAmount;
	}
	public void setUnitsOrAmount(String unitsOrAmount) {
		this.unitsOrAmount = unitsOrAmount;
	}


}

