package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;

public class ClaimsExcelValidationPO implements Serializable {

	private long requestId;
	private Date currentDate;
	private String errormessage;
	private String approvalStatus;
	private long customerTrxnId;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public Date getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
	public String getErrormessage() {
		return errormessage;
	}
	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}
	
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public long getCustomerTrxnId() {
		return customerTrxnId;
	}
	public void setCustomerTrxnId(long customerTrxnId) {
		this.customerTrxnId = customerTrxnId;
	}

	
}
