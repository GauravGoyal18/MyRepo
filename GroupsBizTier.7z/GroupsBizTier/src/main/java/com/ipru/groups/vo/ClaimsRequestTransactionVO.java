package com.ipru.groups.vo;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClaimsRequestTransactionVO extends GroupsBaseVO implements ISpaarcCallLog {

	private static final long serialVersionUID = 1L;
	private FunctionalityMasterVO functionality;
	private long customerTrxnId;
	private String unitId;
	private String memberId;
	private Date currentDate;
	private Date approvalDate;
	private String claimType;
	private String approvalStatus;
	private long noOfApprovalReq;
	private long noOfApprovalDone;
	private String spaarcSentFlag;
	private String excelCount;
	private Set<UploadFileVO> uploadFileVOSet = new HashSet<UploadFileVO>(0);
	private Set<ClaimsRequestVO> claimsRequestVOSet = new HashSet<ClaimsRequestVO>(0);
	private Set<ClaimsBeneficiaryVO> claimsBeneficiaryVOSet = new HashSet<ClaimsBeneficiaryVO>(0);
	private Set<ClaimsApprovalVO> claimsApprovalVoSet = new HashSet<ClaimsApprovalVO>(0);

	public String getExcelCount() {
		return excelCount;
	}

	public void setExcelCount(String excelCount) {
		this.excelCount = excelCount;
	}

	public Set<ClaimsApprovalVO> getClaimsApprovalVoSet() {
		return claimsApprovalVoSet;
	}

	public void setClaimsApprovalVoSet(Set<ClaimsApprovalVO> claimsApprovalVoSet) {
		this.claimsApprovalVoSet = claimsApprovalVoSet;
	}

	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}

	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}

	public long getCustomerTrxnId() {
		return customerTrxnId;
	}

	public void setCustomerTrxnId(long customerTrxnId) {
		this.customerTrxnId = customerTrxnId;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	public Set<UploadFileVO> getUploadFileVOSet() {
		return uploadFileVOSet;
	}

	public void setUploadFileVOSet(Set<UploadFileVO> uploadFileVOSet) {
		this.uploadFileVOSet = uploadFileVOSet;
	}

	public Set<ClaimsRequestVO> getClaimsRequestVOSet() {
		return claimsRequestVOSet;
	}

	public void setClaimsRequestVOSet(Set<ClaimsRequestVO> claimsRequestVOSet) {
		this.claimsRequestVOSet = claimsRequestVOSet;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Set<ClaimsBeneficiaryVO> getClaimsBeneficiaryVOSet() {
		return claimsBeneficiaryVOSet;
	}

	public void setClaimsBeneficiaryVOSet(Set<ClaimsBeneficiaryVO> claimsBeneficiaryVOSet) {
		this.claimsBeneficiaryVOSet = claimsBeneficiaryVOSet;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public Date getApprovalDate() {
		return approvalDate;
	}

	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}

	public long getNoOfApprovalReq() {
		return noOfApprovalReq;
	}

	public void setNoOfApprovalReq(long noOfApprovalReq) {
		this.noOfApprovalReq = noOfApprovalReq;
	}

	public long getNoOfApprovalDone() {
		return noOfApprovalDone;
	}

	public void setNoOfApprovalDone(long noOfApprovalDone) {
		this.noOfApprovalDone = noOfApprovalDone;
	}

	@Override
	public String getFunctionalityReqId() {

		return String.valueOf(this.customerTrxnId);
	}

	public String getSpaarcSentFlag() {
		return spaarcSentFlag;
	}

	public void setSpaarcSentFlag(String spaarcSentFlag) {
		this.spaarcSentFlag = spaarcSentFlag;
	}

	/*
	 * @Override public String toString() { return
	 * "ClaimsRequestTransactionVO [functionality=" + functionality +
	 * ", customerTrxnId=" + customerTrxnId + ", unitId=" + unitId +
	 * ", memberId=" + memberId + ", currentDate=" + currentDate +
	 * ", UploadFileVOList=" + UploadFileVOList + ", claimsRequestVOSet=" +
	 * claimsRequestVOSet + ", claimsBeneficiaryVOSet=" + claimsBeneficiaryVOSet
	 * + ", claimsApprovalVoSet=" + claimsApprovalVoSet + "]"; }
	 */

}
