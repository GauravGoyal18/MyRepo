package com.ipru.groups.vo;

import java.util.Date;

import com.ipru.groups.grpswitch.bean.SwitchTransactionVO;
import com.tcs.vo.BaseVO;

public class StofPreFundDetailsVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long stofPreFundDetailsId;
	private String fundCode;
	private String fundNAV;
	private String fundNAVEffectiveDate;
	private String preFundUnit;
	private String preFundAmount;
	private StofSubmitTransactionVO stofSubmitTransactionVO;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;

	public Long getStofPreFundDetailsId() {
		return stofPreFundDetailsId;
	}

	public void setStofPreFundDetailsId(Long stofPreFundDetailsId) {
		this.stofPreFundDetailsId = stofPreFundDetailsId;
	}

	public String getFundCode() {
		return fundCode;
	}

	public void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}

	public String getFundNAV() {
		return fundNAV;
	}

	public void setFundNAV(String fundNAV) {
		this.fundNAV = fundNAV;
	}

	public String getFundNAVEffectiveDate() {
		return fundNAVEffectiveDate;
	}

	public void setFundNAVEffectiveDate(String fundNAVEffectiveDate) {
		this.fundNAVEffectiveDate = fundNAVEffectiveDate;
	}

	public String getPreFundUnit() {
		return preFundUnit;
	}

	public void setPreFundUnit(String preFundUnit) {
		this.preFundUnit = preFundUnit;
	}

	public String getPreFundAmount() {
		return preFundAmount;
	}

	public void setPreFundAmount(String preFundAmount) {
		this.preFundAmount = preFundAmount;
	}

	public StofSubmitTransactionVO getStofSubmitTransactionVO() {
		return stofSubmitTransactionVO;
	}

	public void setStofSubmitTransactionVO(StofSubmitTransactionVO stofSubmitTransactionVO) {
		this.stofSubmitTransactionVO = stofSubmitTransactionVO;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
}
