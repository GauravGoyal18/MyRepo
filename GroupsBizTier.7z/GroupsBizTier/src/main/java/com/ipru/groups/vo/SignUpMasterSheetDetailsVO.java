package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;

public class SignUpMasterSheetDetailsVO implements Serializable {

	private String policyNo;
	private String empId;
	private String title;
	private String empName;
	private String dateOfJoiningScheme;
	private String status;
	private String dob;
	private String lastTransactionDate;
	private String clientId;
	private String clientCode;
	private String clientName;
	private String panNumber;
	private Long workPhone;
	private Long homePhone;
	private String workEmailId;
	private String homeEmailId;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getDateOfJoiningScheme() {
		return dateOfJoiningScheme;
	}

	public void setDateOfJoiningScheme(String dateOfJoiningScheme) {
		this.dateOfJoiningScheme = dateOfJoiningScheme;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getLastTransactionDate() {
		return lastTransactionDate;
	}

	public void setLastTransactionDate(String lastTransactionDate) {
		this.lastTransactionDate = lastTransactionDate;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientCode() {
		return clientCode;
	}

	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public Long getWorkPhone() {
		return workPhone;
	}

	public void setWorkPhone(Long workPhone) {
		this.workPhone = workPhone;
	}

	public Long getHomePhone() {
		return homePhone;
	}

	public void setHomePhone(Long homePhone) {
		this.homePhone = homePhone;
	}

	public String getWorkEmailId() {
		return workEmailId;
	}

	public void setWorkEmailId(String workEmailId) {
		this.workEmailId = workEmailId;
	}

	public String getHomeEmailId() {
		return homeEmailId;
	}

	public void setHomeEmailId(String homeEmailId) {
		this.homeEmailId = homeEmailId;
	}

}
