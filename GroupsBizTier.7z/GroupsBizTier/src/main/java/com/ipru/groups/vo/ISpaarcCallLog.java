package com.ipru.groups.vo;

import java.util.List;



public interface ISpaarcCallLog {
	
	public FunctionalityMasterVO getFunctionality();
	public String getFunctionalityReqId();
	public String getPolicyNo();
	public String getClientId();
	public String getProductType();
	public String getRole();
	public String getMemberType();
}
