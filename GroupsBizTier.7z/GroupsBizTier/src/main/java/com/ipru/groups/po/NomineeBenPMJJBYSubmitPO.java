package com.ipru.groups.po;

import com.ipru.groups.vo.NomineeBenPMJJBYSubmitVO;

public class NomineeBenPMJJBYSubmitPO extends GroupsBasePo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String beneficiaryName;
	private String relation;
	private String sharePercentage;
	private String beneficiaryDOB;
	private String gender;
	private String benAddress;
	private String city;
	private String pincode;
	private String beneficiaryPos;

	/*
	 * private NomineeBenPMJJBYSubmitVO nomineeBenPMJJBYSubmitVO;
	 * 
	 * public NomineeBenPMJJBYSubmitVO getNomineeBenPMJJBYSubmitVO() { return
	 * nomineeBenPMJJBYSubmitVO; } public void setNomineeBenPMJJBYSubmitVO(
	 * NomineeBenPMJJBYSubmitVO nomineeBenPMJJBYSubmitVO) {
	 * this.nomineeBenPMJJBYSubmitVO = nomineeBenPMJJBYSubmitVO; }
	 */

	public String getBeneficiaryPos() {
		return beneficiaryPos;
	}

	public void setBeneficiaryPos(String beneficiaryPos) {
		this.beneficiaryPos = beneficiaryPos;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getSharePercentage() {
		return sharePercentage;
	}

	public void setSharePercentage(String sharePercentage) {
		this.sharePercentage = sharePercentage;
	}

	public String getBeneficiaryDOB() {
		return beneficiaryDOB;
	}

	public void setBeneficiaryDOB(String beneficiaryDOB) {
		this.beneficiaryDOB = beneficiaryDOB;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBenAddress() {
		return benAddress;
	}

	public void setBenAddress(String benAddress) {
		this.benAddress = benAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "NomineeBenPMJJBYSubmitPO [beneficiaryName=" + beneficiaryName
				+ ", relation=" + relation + ", sharePercentage="
				+ sharePercentage + ", beneficiaryDOB=" + beneficiaryDOB
				+ ", gender=" + gender + ", benAddress=" + benAddress
				+ ", city=" + city + ", pincode=" + pincode
				+ ", nomineeBenPMJJBYSubmitVO=" + "]";
	}

}
