package com.ipru.groups.grpswitch.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.ipru.groups.po.GroupsBasePo;
import com.ipru.groups.vo.ProductSwitchAmountVO;

public class SwitchFundPO extends GroupsBasePo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long switchFundId;
	private String isAgreedCheck;
	private String switchType;
	private String totalFundValue;
	private ProductSwitchAmountVO productSwitchAmount;
	
	private SwitchDetailsPO[] switchDetails;
	//private Map<String,Object> switchDetails = new HashMap<String, Object>();
	
	

	public String getIsAgreedCheck() {
		return isAgreedCheck;
	}

	public void setIsAgreedCheck(String isAgreedCheck) {
		this.isAgreedCheck = isAgreedCheck;
	}

	public String getSwitchType() {
		return switchType;
	}

	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}

	public String getTotalFundValue() {
		return totalFundValue;
	}

	public void setTotalFundValue(String totalFundValue) {
		this.totalFundValue = totalFundValue;
	}

	public ProductSwitchAmountVO getProductSwitchAmount() {
		return productSwitchAmount;
	}

	public void setProductSwitchAmount(ProductSwitchAmountVO productSwitchAmount) {
		this.productSwitchAmount = productSwitchAmount;
	}



	
/*	private List switchDetails;
	
	

	public List getSwitchDetails() {
		return switchDetails;
	}

	public void setSwitchDetails(List switchDetails) {
		this.switchDetails = switchDetails;
	}*/
	
	

/*	public Map<String,Object> getSwitchDetails() {
		return switchDetails;
	}

	public void setSwitchDetails(Map<String,Object> switchDetails) {
		this.switchDetails = switchDetails;
	}*/

	public Long getSwitchFundId() {
		return switchFundId;
	}

	public void setSwitchFundId(Long switchFundId) {
		this.switchFundId = switchFundId;
	}

	public SwitchDetailsPO[] getSwitchDetails() {
		return switchDetails;
	}

	public void setSwitchDetails(SwitchDetailsPO[] switchDetails) {
		this.switchDetails = switchDetails;
	}

	
	
	
	

}

