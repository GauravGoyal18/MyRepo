package com.ipru.groups.vo;

import com.google.gson.annotations.SerializedName;
import com.tcs.vo.BaseVO;

public class MemberFundDataVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@SerializedName("funddesc")
	private String fundType;
	
	@SerializedName("units")
	private double units;
	
	@SerializedName("navValue")
	private double nav;
	
	@SerializedName("totalAmount")
	private double value;
	
	private String sfin;

	public MemberFundDataVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberFundDataVO(String fundType, double units, double nav, double value, String sfin) {
		super();
		this.fundType = fundType;
		this.units = units;
		this.nav = nav;
		this.value = value;
		this.sfin = sfin;
	}

	public String getFundType() {
		return fundType;
	}

	public void setFundType(String fundType) {
		this.fundType = fundType;
	}

	public double getUnits() {
		return units;
	}

	public void setUnits(double units) {
		this.units = units;
	}

	public double getNav() {
		return nav;
	}

	public void setNav(double nav) {
		this.nav = nav;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	

	public String getSfin() {
		return sfin;
	}

	public void setSfin(String sfin) {
		this.sfin = sfin;
	}
	
	@Override
	public String toString() {
		return "MemberFundDataVO [fundType=" + fundType + ", units=" + units
				+ ", nav=" + nav + ", value=" + value + ", sfin=" + sfin + "]";
	}
}
