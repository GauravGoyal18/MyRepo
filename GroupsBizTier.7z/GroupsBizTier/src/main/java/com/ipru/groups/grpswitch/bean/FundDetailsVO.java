package com.ipru.groups.grpswitch.bean;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;
import com.ipru.groups.vo.GroupsBaseVO;

public class FundDetailsVO extends GroupsBaseVO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	 @SerializedName("funddesc")
	private String fundDesc;
	 
	 @SerializedName("sfin") 
	private String sFin;
	 
	 @SerializedName("fundcode") 
	private String fundCode;
	 
	 @SerializedName("units")
	private String units;
	 
	 @SerializedName("navValue")
	private String navValue;
	
	 @SerializedName("totalAmount")
	private String totalAmount;
	
	 @SerializedName("firstYear")
	private String firstYearReturns;
	 
	 @SerializedName("thirdYear")
	private String thirdYearReturns;
	 
	 @SerializedName("fifthYear")
	private String fifthYearReturns;
	 
	 @SerializedName("inception")
	private String returnsSinceInception;
	
	

	private String fundName;
	
	 @SerializedName("benchmark")
	private String benchMark;
	 
	 @SerializedName("inceptionDate")
	private String inceptionDate;
	 
	 @SerializedName("benchmarkFirstYear")
	private String benchmarkFirstYear;
	 
	 @SerializedName("benchmarkThirdYear")
	private String benchmarkThirdYear;
	 
	 @SerializedName("benchmarkFifthYear")
	private String benchmarkFifthYear;
	 
	 @SerializedName("assetsInvested")
	private String assetsInvested;
	 
	 @SerializedName("fundObjective")
	private String fundObjective;
	 
	 @SerializedName("benchmarkInception")
	private String benchmarkInception;
	 
	 @SerializedName("aum_equity_category")
	private String aumEquityCategory;
	 
	 @SerializedName("aum_debt_category")
	private String aumDebtCategory;
	 
	 @SerializedName("aum_money_market_cash_category")
	private String aumMoneyMarketCashCategory;
	 
	 @SerializedName("portfolio_by_maturity_debt_avg")
	private String portfolioByMaturityDebtAvg;
	 
	 @SerializedName("portfolio_by_maturity_bal_avg")
	private String portfolioByMaturityBalAvg;

	public String getFundDesc() {
		return fundDesc;
	}

	public void setFundDesc(String fundDesc) {
		this.fundDesc = fundDesc;
	}

	public String getsFin() {
		return sFin;
	}

	public void setsFin(String sFin) {
		this.sFin = sFin;
	}

	public String getFundCode() {
		return fundCode;
	}

	public void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getNavValue() {
		return navValue;
	}

	public void setNavValue(String navValue) {
		this.navValue = navValue;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getFirstYearReturns() {
		return firstYearReturns;
	}

	public void setFirstYearReturns(String firstYearReturns) {
		this.firstYearReturns = firstYearReturns;
	}

	public String getThirdYearReturns() {
		return thirdYearReturns;
	}

	public void setThirdYearReturns(String thirdYearReturns) {
		this.thirdYearReturns = thirdYearReturns;
	}

	public String getFifthYearReturns() {
		return fifthYearReturns;
	}

	public void setFifthYearReturns(String fifthYearReturns) {
		this.fifthYearReturns = fifthYearReturns;
	}

	public String getReturnsSinceInception() {
		return returnsSinceInception;
	}

	public void setReturnsSinceInception(String returnsSinceInception) {
		this.returnsSinceInception = returnsSinceInception;
	}

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

	public String getBenchMark() {
		return benchMark;
	}

	public void setBenchMark(String benchMark) {
		this.benchMark = benchMark;
	}

	public String getInceptionDate() {
		return inceptionDate;
	}

	public void setInceptionDate(String inceptionDate) {
		this.inceptionDate = inceptionDate;
	}

	public String getBenchmarkFirstYear() {
		return benchmarkFirstYear;
	}

	public void setBenchmarkFirstYear(String benchmarkFirstYear) {
		this.benchmarkFirstYear = benchmarkFirstYear;
	}

	public String getBenchmarkThirdYear() {
		return benchmarkThirdYear;
	}

	public void setBenchmarkThirdYear(String benchmarkThirdYear) {
		this.benchmarkThirdYear = benchmarkThirdYear;
	}

	public String getBenchmarkFifthYear() {
		return benchmarkFifthYear;
	}

	public void setBenchmarkFifthYear(String benchmarkFifthYear) {
		this.benchmarkFifthYear = benchmarkFifthYear;
	}

	public String getAssetsInvested() {
		return assetsInvested;
	}

	public void setAssetsInvested(String assetsInvested) {
		this.assetsInvested = assetsInvested;
	}

	public String getFundObjective() {
		return fundObjective;
	}

	public void setFundObjective(String fundObjective) {
		this.fundObjective = fundObjective;
	}

	public String getBenchmarkInception() {
		return benchmarkInception;
	}

	public void setBenchmarkInception(String benchmarkInception) {
		this.benchmarkInception = benchmarkInception;
	}

	public String getAumEquityCategory() {
		return aumEquityCategory;
	}

	public void setAumEquityCategory(String aumEquityCategory) {
		this.aumEquityCategory = aumEquityCategory;
	}

	public String getAumDebtCategory() {
		return aumDebtCategory;
	}

	public void setAumDebtCategory(String aumDebtCategory) {
		this.aumDebtCategory = aumDebtCategory;
	}

	public String getAumMoneyMarketCashCategory() {
		return aumMoneyMarketCashCategory;
	}

	public void setAumMoneyMarketCashCategory(String aumMoneyMarketCashCategory) {
		this.aumMoneyMarketCashCategory = aumMoneyMarketCashCategory;
	}

	public String getPortfolioByMaturityDebtAvg() {
		return portfolioByMaturityDebtAvg;
	}

	public void setPortfolioByMaturityDebtAvg(String portfolioByMaturityDebtAvg) {
		this.portfolioByMaturityDebtAvg = portfolioByMaturityDebtAvg;
	}

	public String getPortfolioByMaturityBalAvg() {
		return portfolioByMaturityBalAvg;
	}

	public void setPortfolioByMaturityBalAvg(String portfolioByMaturityBalAvg) {
		this.portfolioByMaturityBalAvg = portfolioByMaturityBalAvg;
	}

	@Override
	public String toString() {
		return "FundDetailsVO [fundDesc=" + fundDesc + ", sFin=" + sFin
				+ ", fundCode=" + fundCode + ", units=" + units + ", navValue="
				+ navValue + ", totalAmount=" + totalAmount
				+ ", firstYearReturns=" + firstYearReturns
				+ ", thirdYearReturns=" + thirdYearReturns
				+ ", fifthYearReturns=" + fifthYearReturns
				+ ", returnsSinceInception=" + returnsSinceInception
				+ ", fundName=" + fundName + ", benchMark=" + benchMark
				+ ", inceptionDate=" + inceptionDate + ", benchmarkFirstYear="
				+ benchmarkFirstYear + ", benchmarkThirdYear="
				+ benchmarkThirdYear + ", benchmarkFifthYear="
				+ benchmarkFifthYear + ", assetsInvested=" + assetsInvested
				+ ", fundObjective=" + fundObjective + ", benchmarkInception="
				+ benchmarkInception + ", aumEquityCategory="
				+ aumEquityCategory + ", aumDebtCategory=" + aumDebtCategory
				+ ", aumMoneyMarketCashCategory=" + aumMoneyMarketCashCategory
				+ ", portfolioByMaturityDebtAvg=" + portfolioByMaturityDebtAvg
				+ ", portfolioByMaturityBalAvg=" + portfolioByMaturityBalAvg
				+ "]";
	}

		
}

