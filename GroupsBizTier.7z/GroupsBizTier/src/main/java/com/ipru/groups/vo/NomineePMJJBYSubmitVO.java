package com.ipru.groups.vo;

import java.util.Set;

import com.tcs.vo.BaseVO;

public class NomineePMJJBYSubmitVO extends GroupsBaseVO implements ISpaarcCallLog {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long requestId;
	
	//private String policyNo;
	private String schemeName;
	private String accountNumber;
	private String effectiveDate;
	
	private FunctionalityMasterVO functionality;
	
	private Set<NomineeBenPMJJBYSubmitVO> beneficiary;


	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public Set<NomineeBenPMJJBYSubmitVO> getBeneficiary() {
		return beneficiary;
	}
	public void setBeneficiary(Set<NomineeBenPMJJBYSubmitVO> beneficiary) {
		this.beneficiary = beneficiary;
	}
	/*public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}*/
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	@Override
	public String toString() {
		return "NomineePMJJBYSubmitVO [requestId=" + requestId + ", policyNo="
				 + ", schemeName=" + schemeName + ", accountNumber="
				+ accountNumber + ", effectiveDate=" + effectiveDate
				+ ", beneficiary=" + beneficiary + "]";
	}

	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}
	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}
	@Override
	public String getFunctionalityReqId() {
		// TODO Auto-generated method stub
		return String.valueOf(this.requestId);
	}

	 
}
