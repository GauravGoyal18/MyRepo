package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class TrackerRequestVO extends BaseVO {

	private String functionality;
	private String toDate;
	private String fromDate;
	private String clientId;
	private String policyNo;
	private String status;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFunctionality() {
		return functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	@Override
	public String toString() {
		return "TrackerRequestVO [functionality=" + functionality + ", toDate=" + toDate + ", fromDate=" + fromDate + ", clientId=" + clientId + ", policyNo=" + policyNo + ", status=" + status + "]";
	}

}
