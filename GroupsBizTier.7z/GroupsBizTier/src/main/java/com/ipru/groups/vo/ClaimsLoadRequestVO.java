package com.ipru.groups.vo;

import java.util.List;

import com.tcs.vo.BaseVO;

public class ClaimsLoadRequestVO extends BaseVO{




	private static final long serialVersionUID = 1L;
	private String policyNo;
	private String role;
	private String screenName;
	private List<RoleScreenAccessMappingVO> accessMappingList;
	private List<FieldAccessMappingVO> fieldAccessMappingList;



	public ClaimsLoadRequestVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ClaimsLoadRequestVO(String policyNo, String role, String screenName, List<RoleScreenAccessMappingVO> accessMappingList, List<FieldAccessMappingVO> fieldAccessMappingList) {
		super();
		this.policyNo = policyNo;
		this.role = role;
		this.screenName = screenName;
		this.accessMappingList = accessMappingList;
		this.fieldAccessMappingList = fieldAccessMappingList;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public List<RoleScreenAccessMappingVO> getAccessMappingList() {
		return accessMappingList;
	}

	public void setAccessMappingList(List<RoleScreenAccessMappingVO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}

	
	
	@Override
	public String toString() {
		return "ProfileUpdateLoadRequestVO [policyNo=" + policyNo + ", role=" + role + ", screenName=" + screenName + ", accessMappingList=" + accessMappingList + ", fieldAccessMappingList="
				+ fieldAccessMappingList + "]";
	}

	public List<FieldAccessMappingVO> getFieldAccessMappingList() {
		return fieldAccessMappingList;
	}

	public void setFieldAccessMappingList(
			List<FieldAccessMappingVO> fieldAccessMappingList) {
		this.fieldAccessMappingList = fieldAccessMappingList;
	}


}
