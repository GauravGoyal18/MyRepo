package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;

public class CoiDownloadVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNumber;
	private String memberId;
	private long coiID;
	private Date downloadDate;
	
	
	
	public Date getDownloadDate() {
		return downloadDate;
	}
	public void setDownloadDate(Date downloadDate) {
		this.downloadDate = downloadDate;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public long getCoiID() {
		return coiID;
	}
	public void setCoiID(long coiID) {
		this.coiID = coiID;
	}
	@Override
	public String toString() {
		return "CoiDownloadVO [policyNumber=" + policyNumber + ", memberId="
				+ memberId + ", coiID=" + coiID + ", downloadDate="
				+ downloadDate + "]";
	}
	
}
