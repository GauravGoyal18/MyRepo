package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;

import com.ipru.groups.grpswitch.bean.FundDetailsVO;

public class StofLoadDataVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<FundMasterVO> fundMasterList;
	private List<String> activeApplicableToFundList;
	private FundDetailsVO fundDetailsVO;
	private List<FundDetailsVO> fundDetailsVOList;
	private List<String> activeFromFundList;
	private String fundCodes;
	private String policyNumber;
	private ProductSwitchAmountVO productSwitchAmount;
	private boolean isRequestPerDayExist;
	private String productCode;
	private List<DropDownObjVO> freqOfTrans;

	public List<DropDownObjVO> getFreqOfTrans() {
		return freqOfTrans;
	}

	public void setFreqOfTrans(List<DropDownObjVO> freqOfTrans) {
		this.freqOfTrans = freqOfTrans;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public boolean isRequestPerDayExist() {
		return isRequestPerDayExist;
	}

	public void setRequestPerDayExist(boolean isRequestPerDayExist) {
		this.isRequestPerDayExist = isRequestPerDayExist;
	}

	public ProductSwitchAmountVO getProductSwitchAmount() {
		return productSwitchAmount;
	}

	public void setProductSwitchAmount(ProductSwitchAmountVO productSwitchAmount) {
		this.productSwitchAmount = productSwitchAmount;
	}

	public String getFundCodes() {
		return fundCodes;
	}

	public void setFundCodes(String fundCodes) {
		this.fundCodes = fundCodes;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public List<String> getActiveFromFundList() {
		return activeFromFundList;
	}

	public void setActiveFromFundList(List<String> activeFromFundList) {
		this.activeFromFundList = activeFromFundList;
	}

	public List<FundDetailsVO> getFundDetailsVOList() {
		return fundDetailsVOList;
	}

	public void setFundDetailsVOList(List<FundDetailsVO> fundDetailsVOList) {
		this.fundDetailsVOList = fundDetailsVOList;
	}

	public FundDetailsVO getFundDetailsVO() {
		return fundDetailsVO;
	}

	public void setFundDetailsVO(FundDetailsVO fundDetailsVO) {
		this.fundDetailsVO = fundDetailsVO;
	}

	public List<FundMasterVO> getFundMasterList() {
		return fundMasterList;
	}

	public void setFundMasterList(List<FundMasterVO> fundMasterList) {
		this.fundMasterList = fundMasterList;
	}

	public List<String> getActiveApplicableToFundList() {
		return activeApplicableToFundList;
	}

	public void setActiveApplicableToFundList(List<String> activeApplicableToFundList) {
		this.activeApplicableToFundList = activeApplicableToFundList;
	}

	@Override
	public String toString() {
		return "StofLoadDataVO [fundMasterList=" + fundMasterList + ", activeApplicableToFundList=" + activeApplicableToFundList + ", fundDetailsVO=" + fundDetailsVO + ", fundDetailsVOList="
				+ fundDetailsVOList + ", activeFromFundList=" + activeFromFundList + ", fundCodes=" + fundCodes + ", policyNumber=" + policyNumber + ", productSwitchAmount=" + productSwitchAmount
				+ ", isRequestPerDayExist=" + isRequestPerDayExist + ", productCode=" + productCode + ", freqOfTrans=" + freqOfTrans + "]";
	}

}
