package com.ipru.groups.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClaimAnnuitySubmitVO extends GroupsBaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private FunctionalityMasterVO functionality;
	private Long claimTxnId;
	private String salutation;
	private String empId;
	private String empName;
	private String dob;
	private double purchasedPrice;
	private Long annuityCal;
	private String annuityOption;
	private String frequency;
	private String paymentMode;
	private String pan;

	private String gender;
	private String address1;
	private String address2;
	private String address3;
	private String state;
	private String city;

	private String pinCode;
	private String landlineNo;
	private String mobNo;
	private String emailId;

	private String maritalStatus;
	private String bankName;
	private String bankAddress;
	private String accNo;

	private String ifscCode;
	private String micrCode;
	private Long tds;
	private Date requested;

	private Long claimId;
	ClaimReqIBMredirectVO claimReqIBMredirectVO;

	private Set<ClaimAnnuityBenSubmitVO> beneficiary = new HashSet<ClaimAnnuityBenSubmitVO>();

	ClaimAnnuitySpouseVO spouse = new ClaimAnnuitySpouseVO();
	private List<UploadFileVO> panUploadFileList = new ArrayList<UploadFileVO>(0);
	private List<UploadFileVO> dobUploadFileList = new ArrayList<UploadFileVO>(0);
	private List<UploadFileVO> benDobUploadFileList = new ArrayList<UploadFileVO>(0);
	private List<UploadFileVO> ageProofUploadFileList = new ArrayList<UploadFileVO>(0);

	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}

	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}

	public Long getClaimTxnId() {
		return claimTxnId;
	}

	public void setClaimTxnId(Long claimTxnId) {
		this.claimTxnId = claimTxnId;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public double getPurchasedPrice() {
		return purchasedPrice;
	}

	public void setPurchasedPrice(double purchasedPrice) {
		this.purchasedPrice = purchasedPrice;
	}

	public Long getAnnuityCal() {
		return annuityCal;
	}

	public void setAnnuityCal(Long annuityCal) {
		this.annuityCal = annuityCal;
	}

	public String getAnnuityOption() {
		return annuityOption;
	}

	public void setAnnuityOption(String annuityOption) {
		this.annuityOption = annuityOption;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getLandlineNo() {
		return landlineNo;
	}

	public void setLandlineNo(String landlineNo) {
		this.landlineNo = landlineNo;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAddress() {
		return bankAddress;
	}

	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public Long getTds() {
		return tds;
	}

	public void setTds(Long tds) {
		this.tds = tds;
	}

	public Date getRequested() {
		return requested;
	}

	public void setRequested(Date requested) {
		this.requested = requested;
	}

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public ClaimReqIBMredirectVO getClaimReqIBMredirectVO() {
		return claimReqIBMredirectVO;
	}

	public void setClaimReqIBMredirectVO(ClaimReqIBMredirectVO claimReqIBMredirectVO) {
		this.claimReqIBMredirectVO = claimReqIBMredirectVO;
	}

	public Set<ClaimAnnuityBenSubmitVO> getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(Set<ClaimAnnuityBenSubmitVO> beneficiary) {
		this.beneficiary = beneficiary;
	}

	public ClaimAnnuitySpouseVO getSpouse() {
		return spouse;
	}

	public void setSpouse(ClaimAnnuitySpouseVO spouse) {
		this.spouse = spouse;
	}

	public List<UploadFileVO> getPanUploadFileList() {
		return panUploadFileList;
	}

	public void setPanUploadFileList(List<UploadFileVO> panUploadFileList) {
		this.panUploadFileList = panUploadFileList;
	}

	public List<UploadFileVO> getDobUploadFileList() {
		return dobUploadFileList;
	}

	public void setDobUploadFileList(List<UploadFileVO> dobUploadFileList) {
		this.dobUploadFileList = dobUploadFileList;
	}

	public List<UploadFileVO> getBenDobUploadFileList() {
		return benDobUploadFileList;
	}

	public void setBenDobUploadFileList(List<UploadFileVO> benDobUploadFileList) {
		this.benDobUploadFileList = benDobUploadFileList;
	}

	public List<UploadFileVO> getAgeProofUploadFileList() {
		return ageProofUploadFileList;
	}

	public void setAgeProofUploadFileList(List<UploadFileVO> ageProofUploadFileList) {
		this.ageProofUploadFileList = ageProofUploadFileList;
	}

}
