package com.ipru.groups.po;

public class NomineeUpdateTransactionPo {
	private long customerTrxnId;

	public long getCustomerTrxnId() {
		return customerTrxnId;
	}

	public void setCustomerTrxnId(long customerTrxnId) {
		this.customerTrxnId = customerTrxnId;
	}

}
