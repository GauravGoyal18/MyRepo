package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;

public class UpdateFTWSVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private long seqId;
	private long requestId;
	private String contractId;
	private String fileName;
	private String status;
	private String documentId;
	private String transferFlag;
	private Date createdDate;
	
	
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public long getSeqId() {
		return seqId;
	}
	public void setSeqId(long seqId) {
		this.seqId = seqId;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTransferFlag() {
		return transferFlag;
	}
	public void setTransferFlag(String transferFlag) {
		this.transferFlag = transferFlag;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	@Override
	public String toString() {
		return "UpdateFTWSVO [requestId=" + requestId + ", contractId="
				+ contractId + ", fileName=" + fileName + ", status=" + status
				+ ", transferFlag=" + transferFlag + ", createdDate="
				+ createdDate + "]";
	}
	
}
