package com.ipru.groups.vo;

import java.util.List;
import java.util.Map;

import com.ipru.groups.po.RoleScreenAccessMappingPO;
import com.tcs.web.vo.BaseVO;

public class UnitStatementLoadResponseVO extends BaseVO {
	
	private static final long serialVersionUID = 1L;
	private List<RoleScreenAccessMappingPO> accessMappingList;
	private Map<String, FieldAccessMappingVO> fieldAccessMappingMap;
	



	public UnitStatementLoadResponseVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Map<String, FieldAccessMappingVO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}



	public void setFieldAccessMappingMap(
			Map<String, FieldAccessMappingVO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}



	public void setAccessMappingList(
			List<RoleScreenAccessMappingPO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}



	public List<RoleScreenAccessMappingPO> getAccessMappingList() {
		return accessMappingList;
	}



	@Override
	public String toString() {
		return "UnitStatementLoadResponseVO [accessMappingList="
				+ accessMappingList + ", fieldAccessMappingMap="
				+ fieldAccessMappingMap + "]";
	}



}
