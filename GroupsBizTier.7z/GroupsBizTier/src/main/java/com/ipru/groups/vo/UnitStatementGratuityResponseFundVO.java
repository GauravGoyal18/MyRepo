package com.ipru.groups.vo;

import java.util.ArrayList;
import java.util.List;

import com.tcs.vo.BaseVO;

public class UnitStatementGratuityResponseFundVO extends BaseVO
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String fundName;
	private List<UnitStatementGratuityFundDetailsVO> unitStatementGratuityFundDetailsVOList;
	
	
	
	public String getFundName() {
		return fundName;
	}
	public void setFundName(String fundName) {
		this.fundName = fundName;
	}
	public List<UnitStatementGratuityFundDetailsVO> getUnitStatementGratuityFundDetailsVOList() {
		return unitStatementGratuityFundDetailsVOList;
	}
	public void setUnitStatementGratuityFundDetailsVOList(
			List<UnitStatementGratuityFundDetailsVO> unitStatementGratuityFundDetailsVOList) {
		this.unitStatementGratuityFundDetailsVOList = unitStatementGratuityFundDetailsVOList;
	}
	@Override
	public String toString() {
		return "UnitStatementGratuityResponseFundVO [fundName=" + fundName
				+ ", unitStatementGratuityFundDetailsVOList="
				+ unitStatementGratuityFundDetailsVOList + "]";
	}
	
	
	
}
