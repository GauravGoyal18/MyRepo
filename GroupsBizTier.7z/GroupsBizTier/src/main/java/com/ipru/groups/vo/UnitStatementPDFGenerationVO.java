package com.ipru.groups.vo;

import java.io.Serializable;

public class UnitStatementPDFGenerationVO implements Serializable {
	
	
private static final long serialVersionUID = 1L;
	
	private String transactionDate;
	private String transactionDescription;
	private String description;
	private String entryType;
	
	String amount;
	String NAVValue;
	
	String units;
	String totalUnits ;
	String value;
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionDescription() {
		return transactionDescription;
	}
	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEntryType() {
		return entryType;
	}
	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getNAVValue() {
		return NAVValue;
	}
	public void setNAVValue(String nAVValue) {
		NAVValue = nAVValue;
	}
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	public String getTotalUnits() {
		return totalUnits;
	}
	public void setTotalUnits(String totalUnits) {
		this.totalUnits = totalUnits;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "UnitStatementPDFGenerationVO [transactionDate="
				+ transactionDate + ", transactionDescription="
				+ transactionDescription + ", description=" + description
				+ ", entryType=" + entryType + ", amount=" + amount
				+ ", NAVValue=" + NAVValue + ", units=" + units
				+ ", totalUnits=" + totalUnits + ", value=" + value + "]";
	}
	
	
	
	
	

}
