package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;

import com.tcs.vo.BaseVO;

public class ProfileUpdateDetailsVo implements Serializable {

	public String getUpdateReqId() {
		return updateReqId;
	}
	public void setUpdateReqId(String updateReqId) {
		this.updateReqId = updateReqId;
	}
	@Override
	public String toString() {
		return "ProfileUpdateDetailsVo [requestId=" + requestId + ", custId="
				+ custId + ", subfieldCode=" + subfieldCode + ", fieldName="
				+ fieldName + ", oldValue=" + oldValue + ", newValue="
				+ newValue + ", currentDate=" + currentDate + ", updateReqId="
				+ updateReqId + ", fieldCode=" + fieldCode
				+ ", fieldGroupCode=" + fieldGroupCode
				+ ", profileUpdateTranscationVO=" + profileUpdateTranscationVO
				+ "]";
	}
	private static final long serialVersionUID = 1L;
	private long requestId;
	private long custId;
	private String subfieldCode;
	private String fieldName;
	private String oldValue;
	private String newValue;
	private Date currentDate;
	private String updateReqId;
	private int fieldCode;
	private int fieldGroupCode;
	
	private ProfileUpdateTranscationVO profileUpdateTranscationVO;

	public ProfileUpdateTranscationVO getProfileUpdateTranscationVO() {
		return profileUpdateTranscationVO;
	}

	public void setProfileUpdateTranscationVO(ProfileUpdateTranscationVO profileUpdateTranscationVO) {
		this.profileUpdateTranscationVO = profileUpdateTranscationVO;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public long getCustId() {
		return custId;
	}
	public void setCustId(long custId) {
		this.custId = custId;
	}
	public String getSubfieldCode() {
		return subfieldCode;
	}
	public void setSubfieldCode(String subfieldCode) {
		this.subfieldCode = subfieldCode;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public int getFieldCode() {
		return fieldCode;
	}
	public void setFieldCode(int fieldCode) {
		this.fieldCode = fieldCode;
	}
	public int getFieldGroupCode() {
		return fieldGroupCode;
	}
	public void setFieldGroupCode(int fieldGroupCode) {
		this.fieldGroupCode = fieldGroupCode;
	}
	public String getOldValue() {
		return oldValue;
	}
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	public String getNewValue() {
		return newValue;
	}
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}
	public Date getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
	
	
	
	
	

}
