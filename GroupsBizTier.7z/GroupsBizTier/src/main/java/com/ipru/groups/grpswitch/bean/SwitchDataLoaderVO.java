package com.ipru.groups.grpswitch.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.GroupsBaseVO;
import com.ipru.groups.vo.ProductSwitchAmountVO;
import com.ipru.security.user.IPruUser;

public class SwitchDataLoaderVO extends GroupsBaseVO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private  ProductSwitchAmountVO productSwitchAmount;
	private List<String> activeApplicableToFundList;
	private List<String> activeApplicableFromFundList;
	private List<String> activeApplicableToFundCodeList;
	private List<String> activeApplicableFromFundCodeList;
	private Map<String,FundMasterVO> activeApplicableToFundMap;
	private List<FundMasterVO> fundMasterList;
	private List<NSEHolidaysVO> nseHolidaysList;
	private IPruUser userVO;
	
	public ProductSwitchAmountVO getProductSwitchAmount() {
		return productSwitchAmount;
	}

	public void setProductSwitchAmount(ProductSwitchAmountVO productSwitchAmount) {
		this.productSwitchAmount = productSwitchAmount;
	}

	public List<String> getActiveApplicableToFundList() {
		return activeApplicableToFundList;
	}

	public void setActiveApplicableToFundList(
			List<String> activeApplicableToFundList) {
		this.activeApplicableToFundList = activeApplicableToFundList;
	}

	public Map<String,FundMasterVO> getActiveApplicableToFundMap() {
		return activeApplicableToFundMap;
	}

	public void setActiveApplicableToFundMap(
			Map<String,FundMasterVO> activeApplicableToFundMap) {
		this.activeApplicableToFundMap = activeApplicableToFundMap;
	}

	public List<FundMasterVO> getFundMasterList() {
		return fundMasterList;
	}

	public void setFundMasterList(List<FundMasterVO> fundMasterList) {
		this.fundMasterList = fundMasterList;
	}

	public List<NSEHolidaysVO> getNseHolidaysList() {
		return nseHolidaysList;
	}

	public void setNseHolidaysList(List<NSEHolidaysVO> nseHolidaysList) {
		this.nseHolidaysList = nseHolidaysList;
	}

	public List<String> getActiveApplicableFromFundList() {
		return activeApplicableFromFundList;
	}

	public void setActiveApplicableFromFundList(
			List<String> activeApplicableFromFundList) {
		this.activeApplicableFromFundList = activeApplicableFromFundList;
	}

	public List<String> getActiveApplicableToFundCodeList() {
		return activeApplicableToFundCodeList;
	}

	public void setActiveApplicableToFundCodeList(
			List<String> activeApplicableToFundCodeList) {
		this.activeApplicableToFundCodeList = activeApplicableToFundCodeList;
	}

	public List<String> getActiveApplicableFromFundCodeList() {
		return activeApplicableFromFundCodeList;
	}

	public void setActiveApplicableFromFundCodeList(
			List<String> activeApplicableFromFundCodeList) {
		this.activeApplicableFromFundCodeList = activeApplicableFromFundCodeList;
	}

	public IPruUser getUserVO() {
		return userVO;
	}

	public void setUserVO(IPruUser userVO) {
		this.userVO = userVO;
	}



}

