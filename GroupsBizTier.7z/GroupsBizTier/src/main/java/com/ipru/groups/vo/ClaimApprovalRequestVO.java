package com.ipru.groups.vo;

import java.util.List;

public class ClaimApprovalRequestVO extends GroupsBaseVO {

	private String status;
	private List<ClaimsRequestTransactionVO> claimsRequestTransactionVOList;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<ClaimsRequestTransactionVO> getClaimsRequestTransactionVOList() {
		return claimsRequestTransactionVOList;
	}

	public void setClaimsRequestTransactionVOList(List<ClaimsRequestTransactionVO> claimsRequestTransactionVOList) {
		this.claimsRequestTransactionVOList = claimsRequestTransactionVOList;
	}

}
