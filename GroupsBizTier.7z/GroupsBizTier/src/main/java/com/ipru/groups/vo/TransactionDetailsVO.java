package com.ipru.groups.vo;

import java.math.BigDecimal;

import com.tcs.web.vo.BaseVO;

public class TransactionDetailsVO extends BaseVO {
	private static final long serialVersionUID = 1L;
	
	private String transactionDate;
	private String transactionDescription;
	private String description;
	private String entryType;
		
	//double  amount;
	BigDecimal amount;
	BigDecimal  NAVValue;
	
	BigDecimal units;
	BigDecimal totalUnits ;
	BigDecimal value;
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionDescription() {
		return transactionDescription;
	}
	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEntryType() {
		return entryType;
	}
	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getNAVValue() {
		return NAVValue;
	}
	public void setNAVValue(BigDecimal nAVValue) {
		NAVValue = nAVValue;
	}
	public BigDecimal getUnits() {
		return units;
	}
	public void setUnits(BigDecimal units) {
		this.units = units;
	}
	public BigDecimal getTotalUnits() {
		return totalUnits;
	}
	public void setTotalUnits(BigDecimal totalUnits) {
		this.totalUnits = totalUnits;
	}
	public BigDecimal getValue() {
		return value;
	}
	public void setValue(BigDecimal value) {
		this.value = value;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "TransactionDetailsVO [transactionDate=" + transactionDate
				+ ", transactionDescription=" + transactionDescription
				+ ", description=" + description + ", entryType=" + entryType
				+ ", amount=" + amount + ", NAVValue=" + NAVValue + ", units="
				+ units + ", totalUnits=" + totalUnits + ", value=" + value
				+ "]";
	}
	

}
