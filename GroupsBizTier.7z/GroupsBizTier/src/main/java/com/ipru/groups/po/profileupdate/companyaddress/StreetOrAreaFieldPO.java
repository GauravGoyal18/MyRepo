package com.ipru.groups.po.profileupdate.companyaddress;

import com.ipru.groups.po.profileupdate.FieldMeta;


public class StreetOrAreaFieldPO extends FieldMeta{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	private String fieldId;



	private String oldValue;
	private String newValue;
	private String index;
	//private String fieldCanonicalName;
	private int fieldGroupCode;
	private int fieldCode;


	public String getFieldId() {
		return fieldId;
	}
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}
	public String getOldValue() {
		return oldValue;
	}
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	public String getNewValue() {
		return newValue;
	}
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}

	public int getFieldGroupCode() {
		return fieldGroupCode;
	}
	public void setFieldGroupCode(int fieldGroupCode) {
		this.fieldGroupCode = fieldGroupCode;
	}
	public int getFieldCode() {
		return fieldCode;
	}
	public void setFieldCode(int fieldCode) {
		this.fieldCode = fieldCode;
	}
	
	

	@Override
	public String toString() {
		return "StreetOrAreaFieldPO [fieldId=" + fieldId + ", oldValue="
				+ oldValue + ", newValue=" + newValue + ", index=" + index
				+ ", fieldGroupCode=" + fieldGroupCode + ", fieldCode="
				+ fieldCode + "]";
	}
}
