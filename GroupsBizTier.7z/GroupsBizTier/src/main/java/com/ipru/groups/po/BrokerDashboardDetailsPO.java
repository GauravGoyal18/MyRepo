package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ipru.security.user.PolicyDetails;

public class BrokerDashboardDetailsPO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String branchCode;
	private String nationalCode;
	private String licenseValidityDate;
	private String licenseValidityStatus;
	private Map<String, FieldAccessMappingPO> fieldAccessMappingMap;
	private List<RoleScreenAccessMapPO> roleAccessMapList;
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getNationalCode() {
		return nationalCode;
	}
	public void setNationalCode(String nationalCode) {
		this.nationalCode = nationalCode;
	}
	
	
	
	public String getLicenseValidityDate() {
		return licenseValidityDate;
	}
	public void setLicenseValidityDate(String licenseValidityDate) {
		this.licenseValidityDate = licenseValidityDate;
	}
	public String getLicenseValidityStatus() {
		return licenseValidityStatus;
	}
	public void setLicenseValidityStatus(String licenseValidityStatus) {
		this.licenseValidityStatus = licenseValidityStatus;
	}
	public Map<String, FieldAccessMappingPO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}
	public void setFieldAccessMappingMap(Map<String, FieldAccessMappingPO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}
	public List<RoleScreenAccessMapPO> getRoleAccessMapList() {
		return roleAccessMapList;
	}
	public void setRoleAccessMapList(List<RoleScreenAccessMapPO> roleAccessMapList) {
		this.roleAccessMapList = roleAccessMapList;
	}
	

	



}
