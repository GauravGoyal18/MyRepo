package com.ipru.groups.grpswitch.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ipru.groups.client.FundNAVClient;
import com.ipru.groups.client.FundPerformanceClient;
import com.ipru.groups.client.NSEHolidayDetailsClient;
import com.ipru.groups.client.PreFundDetailsClient;
import com.ipru.groups.client.ProductDetailsClient;
import com.ipru.groups.grpswitch.bean.NSEHolidaysVO;
import com.ipru.groups.grpswitch.bean.SwitchPreFundDetailsVO;
import com.ipru.groups.grpswitch.bean.SwitchTransactionVO;
import com.ipru.groups.grpswitch.dao.SwitchDaoImpl;
import com.ipru.groups.service.WebserviceInvoke;
import com.ipru.groups.vo.ProductDetailsVO;
import com.ipru.groups.vo.ServiceWebpageCallVO;
import com.ipru.groups.widget.service.GroupsBaseService;
import com.tcs.exception.ServiceException;
import com.tcs.exception.WebServiceClientException;
import com.tcs.logger.FLogger;


public class SwitchServiceImpl  extends GroupsBaseService {
	
	private SwitchDaoImpl m_switchObjDao = null;
	private String m_StrModuleName = "group";
	
	public SwitchDaoImpl getSwitchDao() throws ServiceException {
		
		try{
			
			if (m_switchObjDao == null) {
				m_switchObjDao = new SwitchDaoImpl(m_StrModuleName);
			}
			
		}
		catch (Exception e) {
			
		}
		return m_switchObjDao ;
	}
	
	SwitchDaoImpl switchDaoImpl=new SwitchDaoImpl("group");
	private boolean status=false;
	
	public ProductDetailsVO fetchProductDetailsFromPolicy(String policyNo) throws NullPointerException,Exception{
		try{
			FLogger.info("SwitchLogger", "SwitchServiceImpl", "fetchProductFromPolicy","Method Start");
			ProductDetailsVO productDetails = null;
			//Call Webservice
	//		ProductDetailsVO productDetails  = ProductDetailsClient.fetchProductDetails(policyNo);
			//ProductDetailsVO productDetails  = WebserviceInvoke.getInstance().fetchProductDetails(policyNo);
			String output  = WebserviceInvoke.getInstance().fetchProductDetails(policyNo,"SwitchLogger");
			
			//json String to List of Object
			List<ProductDetailsVO> productDetailsVOList=getGsonSingleton().fromJson(output.toString(), new TypeToken<List<ProductDetailsVO>>(){}.getType());
			if(productDetailsVOList != null)
				productDetails = productDetailsVOList.get(0);
			
			FLogger.info("SwitchLogger", "SwitchServiceImpl", "fetchProductFromPolicy","Method End");
			return	productDetails;
		}
		catch(WebServiceClientException e)
		{
			FLogger.error("SwitchLogger", "SwitchServiceImpl", "fetchProductDetailsFromPolicy", "Exception Occurred :",e);
			throw new ServiceException("Error", "GRPF02", e.getMessage());
		}
	}
	
	
	public List<NSEHolidaysVO> fetchNSEHolidayDetails() throws NullPointerException,Exception{
		
		try{
			FLogger.info("SwitchLogger", "SwitchServiceImpl", "fetchNSEHolidayDetails","Method Start");
			List<NSEHolidaysVO> nseHolidaysList = new ArrayList<NSEHolidaysVO>();
			//Call Webservice
	//		List<NSEHolidaysVO> nseHolidaysList  = NSEHolidayDetailsClient.fetchNSEHoliday();
			String output  = WebserviceInvoke.getInstance().fetchNSEHoliday("SwitchLogger");
			
			
			Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
			nseHolidaysList = gson.fromJson(output.toString(), new TypeToken<List<NSEHolidaysVO>>() {}.getType());
			
			FLogger.info("SwitchLogger", "SwitchServiceImpl", "fetchNSEHolidayDetails","Method End");
			return	nseHolidaysList;
		}
		catch(WebServiceClientException e)
		{
			FLogger.error("SwitchLogger", "SwitchServiceImpl", "fetchProductDetailsFromPolicy", "Exception Occurred :",e);
			throw new ServiceException("Error", "GRPF02", e.getMessage());
		}

	}
	
	
	public String fetchFundNAVUnit(Map<String,String> map) throws NullPointerException,Exception{
		try{
			FLogger.info("SwitchLogger", "SwitchServiceImpl", "fetchFundNAVUnit","Method Start");
			String fundNAVString;
			//Call Webservice
		
			fundNAVString = WebserviceInvoke.getInstance().invokeFundNAVWS(map,"SwitchLogger");
		
			FLogger.info("SwitchLogger", "SwitchServiceImpl", "fetchFundNAVUnit","Method End");
			return	fundNAVString;
		}
		catch(WebServiceClientException e)
		{
			FLogger.error("SwitchLogger", "SwitchServiceImpl", "fetchProductDetailsFromPolicy", "Exception Occurred :",e);
			throw new ServiceException("Error", "GRPF02", e.getMessage());
		}
	}
	
	
	public String fetchReturnsInception(String fundCodes) throws NullPointerException,Exception{
		try{
			FLogger.info("SwitchLogger", "SwitchServiceImpl", "fetchReturnsInception","Method Start");
			
			//Call Webservice
	//		String fundPerformanceString = FundPerformanceClient.fetchFundDetails(fundCodes);
			String fundPerformanceString = WebserviceInvoke.getInstance().fetchFundDetails(fundCodes,"SwitchLogger");
			
			FLogger.info("SwitchLogger", "SwitchServiceImpl", "fetchReturnsInception","Method End");
			return	fundPerformanceString;
		}
		catch(WebServiceClientException e)
		{
			FLogger.error("SwitchLogger", "SwitchServiceImpl", "fetchProductDetailsFromPolicy", "Exception Occurred :",e);
			throw new ServiceException("Error", "GRPF02", e.getMessage());
		}
	}
	
	
	public boolean checkOneSwitchPerDay(String clientId) throws NullPointerException,Exception{
		FLogger.info("SwitchLogger", "SwitchServiceImpl", "checkOneSwitchPerDay","Method Start");
		
		boolean checkSwitchallowed = switchDaoImpl.checkOneSwitchPerDay(clientId);
		
		FLogger.info("SwitchLogger", "SwitchServiceImpl", "checkOneSwitchPerDay","Method End");
		return	checkSwitchallowed;
	}
	
	
	
	public List<SwitchPreFundDetailsVO> fetchPreFundAndFundDetailsService(Map<String,String> map) throws NullPointerException,Exception{
		try{
			FLogger.info("SwitchLogger", "SwitchServiceImpl", "checkOneSwitchPerDay","Method Start");
			
			//Call Webservice 
	//		List<SwitchPreFundDetailsVO> preFundDetails = PreFundDetailsClient.invokePreFundDetails(map);
			String output = WebserviceInvoke.getInstance().invokePreFundDetails(map,"SwitchLogger");
			
			Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
			
			List<SwitchPreFundDetailsVO> preFundDetails = gson.fromJson(output.toString(), new TypeToken<List<SwitchPreFundDetailsVO>>(){}.getType());
			
			FLogger.info("SwitchLogger", "SwitchServiceImpl", "checkOneSwitchPerDay","Method End");
			return	preFundDetails;
		}
		catch(WebServiceClientException e)
		{
			FLogger.error("SwitchLogger", "SwitchServiceImpl", "fetchProductDetailsFromPolicy", "Exception Occurred :",e);
			throw new ServiceException("Error", "GRPF02", e.getMessage());
		}
	}
	
	
	
	public SwitchTransactionVO saveSwitch(SwitchTransactionVO switchTransactionVO) throws NullPointerException,Exception{
		FLogger.info("SwitchLogger", "SwitchServiceImpl", "saveSwitch","Entered saveSwitch");
		status = false;
		if(switchTransactionVO!=null && switchDaoImpl != null)
		{
			/*ServiceWebpageCallVO serviceWebpageCallVO = new ServiceWebpageCallVO();
			serviceWebpageCallVO.setClientId(switchTransactionVO.getClientId());
			serviceWebpageCallVO.setPolicyNo(switchTransactionVO.getPolicyNo());
			serviceWebpageCallVO.setAppNo("NA");
			serviceWebpageCallVO.setCallDesc("Switch Request submited");//write ur own

			//ServiceWebPageMenuVO serviceWebPageMenuVO = serviceWebPageSubmitRequestVO.getSelectedMenu();

			serviceWebpageCallVO.setMenuId(1234);
			serviceWebpageCallVO.setCallCategory("call Cat");
			serviceWebpageCallVO.setMasterCallType("type");
			serviceWebpageCallVO.setCallType("type");
			serviceWebpageCallVO.setSubType("type");
			serviceWebpageCallVO.setAssigneeName("name");
			serviceWebpageCallVO.setAssigneeGroup("group");
			serviceWebpageCallVO.setAssigneeSubGroup("setMasterCallTypeub group");
			serviceWebpageCallVO.setWsResponse(null);
			serviceWebpageCallVO.setStatus("PENDING");
			serviceWebpageCallVO.setRequestedDateTime(new Date());
			serviceWebpageCallVO.setLastUpdateDateTime(new Date());
			serviceWebpageCallVO.setEmailSentflag("N");*/
			//serviceWebpageCallVO.setFunctionality("switch");//.htm
			switchDaoImpl.saveSwitch(switchTransactionVO);
		}
		
		
				
		FLogger.info("SwitchLogger", "SwitchServiceImpl", "saveSwitch","Exited saveSwitch");
		return	switchTransactionVO;
	}
	
	
	


	
}

