package com.ipru.groups.po;

import java.util.List;
import java.util.Map;

import com.ipru.groups.vo.FieldAccessMappingVO;
import com.tcs.web.po.BasePO;

public class NomineeUpdateLoadDataPo extends BasePO {
	private List<RoleScreenAccessMappingPO> accessMappingList;
	private Map<String, FieldAccessMappingVO> fieldAccessMappingMap;
	List<NomineeUpdatePo> nomineeUpdatePo;
	List<NomineeUpdateRelationPo> nomineeUpdateRelationPo;
	boolean requestPerDay;

	public boolean isRequestPerDay() {
		return requestPerDay;
	}

	public void setRequestPerDay(boolean requestPerDay) {
		this.requestPerDay = requestPerDay;
	}

	public List<NomineeUpdatePo> getNomineeUpdatePo() {
		return nomineeUpdatePo;
	}

	public void setNomineeUpdatePo(List<NomineeUpdatePo> nomineeUpdatePo) {
		this.nomineeUpdatePo = nomineeUpdatePo;
	}

	public List<NomineeUpdateRelationPo> getNomineeUpdateRelationPo() {
		return nomineeUpdateRelationPo;
	}

	public void setNomineeUpdateRelationPo(List<NomineeUpdateRelationPo> nomineeUpdateRelationPo) {
		this.nomineeUpdateRelationPo = nomineeUpdateRelationPo;
	}

	public List<RoleScreenAccessMappingPO> getAccessMappingList() {
		return accessMappingList;
	}

	public void setAccessMappingList(List<RoleScreenAccessMappingPO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}

	public Map<String, FieldAccessMappingVO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}

	public void setFieldAccessMappingMap(Map<String, FieldAccessMappingVO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}

	@Override
	public String toString() {
		return "NomineeUpdateLoadDataPo [accessMappingList=" + accessMappingList + ", fieldAccessMappingMap=" + fieldAccessMappingMap + ", nomineeUpdatePo=" + nomineeUpdatePo
				+ ", nomineeUpdateRelationPo=" + nomineeUpdateRelationPo + ", requestPerDay=" + requestPerDay + "]";
	}

}
