package com.ipru.groups.po.profileupdate.companyaddress;

import com.ipru.groups.po.profileupdate.FieldMeta;


public class AddressproofFieldPO extends FieldMeta{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*public AddressproofFieldPO()
	{
		super();
	}*/
	private String fieldId;
	private String oldValue;
	/*public AddressproofFieldPO(String fieldId, String oldValue,
			String newValue, String index, int fieldGroupCode, int fieldCode) {
		super();
		this.fieldId = fieldId;
		this.oldValue = oldValue;
		this.newValue = newValue;
		this.index = index;
		this.fieldGroupCode = fieldGroupCode;
		this.fieldCode = fieldCode;
	}*/
	private String newValue;
	private String index;

	private int fieldGroupCode;
	private int fieldCode;
	
	
	
	public String getFieldId() {
		return fieldId;
	}
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}
	public String getOldValue() {
		return oldValue;
	}
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	public String getNewValue() {
		return newValue;
	}
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}

	@Override
	public String toString() {
		return "AddressproofFieldPO [fieldId=" + fieldId + ", oldValue="
				+ oldValue + ", newValue=" + newValue + ", index=" + index
				+ ", fieldGroupCode=" + fieldGroupCode + ", fieldCode="
				+ fieldCode + "]";
	}
	public int getFieldGroupCode() {
		return fieldGroupCode;
	}
	public void setFieldGroupCode(int fieldGroupCode) {
		this.fieldGroupCode = fieldGroupCode;
	}
	public int getFieldCode() {
		return fieldCode;
	}
	public void setFieldCode(int fieldCode) {
		this.fieldCode = fieldCode;
	}
	
	

}
