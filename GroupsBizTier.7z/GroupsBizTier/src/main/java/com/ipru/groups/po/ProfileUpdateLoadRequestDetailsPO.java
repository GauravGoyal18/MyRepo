package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.ipru.groups.vo.AuthoritySignatoryChangeVO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.ProfileUpdateLoadRequestVO;

public class ProfileUpdateLoadRequestDetailsPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*private PolicyDetailsPO policyDetails;*/
	private List<RoleScreenAccessMappingPO> accessMappingList;
	private Map<String, FieldAccessMappingPO> fieldAccessMappingMap;
	private List<CompanyAddressChangePO> profileCompanyAddressVOList;
	private List<ContactPersonChangePO> profileContactPersonVOList;
	
	private List<AuthoritySignatoryChangePO> profileAuthoritySignatoryVOList;
	

	

	public ProfileUpdateLoadRequestDetailsPO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public List<RoleScreenAccessMappingPO> getAccessMappingList() {
		return accessMappingList;
	}


	public void setAccessMappingList(
			List<RoleScreenAccessMappingPO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}


	


	public List<CompanyAddressChangePO> getProfileCompanyAddressVOList() {
		return profileCompanyAddressVOList;
	}


	public void setProfileCompanyAddressVOList(
			List<CompanyAddressChangePO> profileCompanyAddressVOList) {
		this.profileCompanyAddressVOList = profileCompanyAddressVOList;
	}


	public List<ContactPersonChangePO> getProfileContactPersonVOList() {
		return profileContactPersonVOList;
	}


	public void setProfileContactPersonVOList(
			List<ContactPersonChangePO> profileContactPersonVOList) {
		this.profileContactPersonVOList = profileContactPersonVOList;
	}


	public List<AuthoritySignatoryChangePO> getProfileAuthoritySignatoryVOList() {
		return profileAuthoritySignatoryVOList;
	}


	public void setProfileAuthoritySignatoryVOList(
			List<AuthoritySignatoryChangePO> profileAuthoritySignatoryVOList) {
		this.profileAuthoritySignatoryVOList = profileAuthoritySignatoryVOList;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}




	public Map<String, FieldAccessMappingPO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}


	public void setFieldAccessMappingMap(
			Map<String, FieldAccessMappingPO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}


	@Override
	public String toString() {
		return "ProfileUpdateLoadRequestDetailsPO [accessMappingList="
				+ accessMappingList + ", fieldAccessMappingMap="
				+ fieldAccessMappingMap + ", profileCompanyAddressVOList="
				+ profileCompanyAddressVOList + ", profileContactPersonVOList="
				+ profileContactPersonVOList
				+ ", profileAuthoritySignatoryVOList="
				+ profileAuthoritySignatoryVOList + "]";
	}

}
