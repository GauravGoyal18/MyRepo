package com.ipru.groups.vo;

import java.io.Serializable;

import com.ipru.groups.po.ClaimGratuityWithDrawalUnitPO;
import com.tcs.vo.BaseVO;

public class ClaimGratuityWithDrawalUnitVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private long withDrawalId;
	private String planName;
	private int withdrawalPercent;
	
	private ClaimGratuityVO claimGratuityVO;
	
	public long getWithDrawalId() {
		return withDrawalId;
	}
	public void setWithDrawalId(long withDrawalId) {
		this.withDrawalId = withDrawalId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public int getWithdrawalPercent() {
		return withdrawalPercent;
	}
	public void setWithdrawalPercent(int withdrawalPercent) {
		this.withdrawalPercent = withdrawalPercent;
	}	
	public ClaimGratuityVO getClaimGratuityVO() {
		return claimGratuityVO;
	}
	public void setClaimGratuityVO(ClaimGratuityVO claimGratuityVO) {
		this.claimGratuityVO = claimGratuityVO;
	}
	@Override
	public String toString() {
		return "ClaimGratuityWithDrawalUnitVO [withDrawalId=" + withDrawalId + ", planName=" + planName + ", withdrawalPercent=" + withdrawalPercent + ", claimGratuityVO=" + claimGratuityVO + "]";
	}
	
	
	private static ClaimGratuityWithDrawalUnitVO instance;
	 private static final String CLASSNAME = ClaimGratuityWithDrawalUnitVO.class .getCanonicalName();
        
	/*private ClaimGratuityWithDrawalUnitVO() {
	
	}
	

	 public static ClaimGratuityWithDrawalUnitVO getInstance() {
     if (instance == null) {
                     synchronized (CLASSNAME) {
                                     instance = new ClaimGratuityWithDrawalUnitVO();
                     }
     }
     return instance;
	
	

	 }*/
	

}
