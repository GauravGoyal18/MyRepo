package com.ipru.groups.vo;

public class AnntyClaimVO {

	private double purchasePrice;

	public double getPurchasePrice() {
		return purchasePrice;
	}

	public void setPurchasePrice(double purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

}
