package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class ClaimsApprovalVO extends BaseVO {

	private long requestId;

	private Date requestedDate;
	private String employeeId;
	private String employeeName;
	private String status;
	private String approvedBy;
	private Date approvedDate;
	private String claimType;
	private String clientId;
	private String role;

	private ClaimsRequestTransactionVO claimsRequestTransaction;

	public ClaimsRequestTransactionVO getClaimsRequestTransaction() {
		return claimsRequestTransaction;
	}

	public void setClaimsRequestTransaction(ClaimsRequestTransactionVO claimsRequestTransaction) {
		this.claimsRequestTransaction = claimsRequestTransaction;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public Date getRequestedDate() {
		return requestedDate;
	}

	public void setRequestedDate(Date requestedDate) {
		this.requestedDate = requestedDate;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	/*@Override
	public String toString() {
		return "ClaimsApprovalVO [requestId=" + requestId + ", requestedDate=" + requestedDate + ", employeeId=" + employeeId + ", employeeName=" + employeeName + ", status=" + status
				+ ", approvedBy=" + approvedBy + ", approvedDate=" + approvedDate + ", claimType=" + claimType + ", clientId=" + clientId + ", role=" + role + ", claimsRequestTransaction="
				+ claimsRequestTransaction + "]";
	}*/

}
