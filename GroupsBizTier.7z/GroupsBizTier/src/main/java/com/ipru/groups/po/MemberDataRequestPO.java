package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

public class MemberDataRequestPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNo;
	private String role;
	private String unitCode;
	private String employeeId;
	private String memberType;
	private String max;
	private String offset;
	private String productType;

	public MemberDataRequestPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberDataRequestPO(String policyNo, String role, String unitCode,
			String employeeId, String memberType, String max, String offset,
			String productType) {
		super();
		this.policyNo = policyNo;
		this.role = role;
		this.unitCode = unitCode;
		this.employeeId = employeeId;
		this.memberType = memberType;
		this.max = max;
		this.offset = offset;
		this.productType = productType;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	@Override
	public String toString() {
		return "MemberDataRequestPO [policyNo=" + policyNo + ", role=" + role
				+ ", unitCode=" + unitCode + ", employeeId=" + employeeId
				+ ", memberType=" + memberType + ", max=" + max + ", offset="
				+ offset + "]";
	}

	public String getMax() {
		return max;
	}

	public void setMax(String max) {
		this.max = max;
	}

	public String getOffset() {
		return offset;
	}

	public void setOffset(String offset) {
		this.offset = offset;
	}

}
