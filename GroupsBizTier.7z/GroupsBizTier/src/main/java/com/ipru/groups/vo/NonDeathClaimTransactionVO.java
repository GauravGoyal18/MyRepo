package com.ipru.groups.vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class NonDeathClaimTransactionVO extends GroupsBaseVO {

	private static final long serialVersionUID = 1L;
	private long customerTrxnId;
	private Date requestedDate;
	private Set<ClaimsApprovalVO> claimsApprovalVoSet = new HashSet<ClaimsApprovalVO>(
			0);

	public long getCustomerTrxnId() {
		return customerTrxnId;
	}

	public void setCustomerTrxnId(long customerTrxnId) {
		this.customerTrxnId = customerTrxnId;
	}

	public Date getRequestedDate() {
		return requestedDate;
	}

	public void setRequestedDate(Date requestedDate) {
		this.requestedDate = requestedDate;
	}

	public Set<ClaimsApprovalVO> getClaimsApprovalVoSet() {
		return claimsApprovalVoSet;
	}

	public void setClaimsApprovalVoSet(Set<ClaimsApprovalVO> claimsApprovalVoSet) {
		this.claimsApprovalVoSet = claimsApprovalVoSet;
	}

	@Override
	public String toString() {
		return "NonDeathClaimTransactionVO [customerTrxnId=" + customerTrxnId
				+ ", requestedDate=" + requestedDate + ", claimsApprovalVoSet="
				+ claimsApprovalVoSet + "]";
	}

}
