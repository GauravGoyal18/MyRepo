package com.ipru.groups.po;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.ipru.groups.vo.ClaimsBenPMJJBYSubmitVO;
import com.ipru.groups.vo.UploadFileVO;

public class ClaimsPMJJBYSubmitPO extends GroupsBasePo {

	private String schemeName;
	private String accountNumber;
	private String polHolderName;
	private String claimDate;
	private String deathDate;
	private String deathReason;
	private Set<ClaimsBenPMJJBYSubmitPO> beneficiary;

	private List<UploadFilePO> claimForm = new ArrayList<UploadFilePO>();
	private List<UploadFilePO> deathCertificate = new ArrayList<UploadFilePO>(0);
	private List<UploadFilePO> cancelledCheque = new ArrayList<UploadFilePO>(0);

	public String getSchemeName() {
		return schemeName;
	}

	public Set<ClaimsBenPMJJBYSubmitPO> getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(Set<ClaimsBenPMJJBYSubmitPO> beneficiary) {
		this.beneficiary = beneficiary;
	}

	public List<UploadFilePO> getClaimForm() {
		return claimForm;
	}

	public void setClaimForm(List<UploadFilePO> claimForm) {
		this.claimForm = claimForm;
	}

	public List<UploadFilePO> getDeathCertificate() {
		return deathCertificate;
	}

	public void setDeathCertificate(List<UploadFilePO> deathCertificate) {
		this.deathCertificate = deathCertificate;
	}

	public List<UploadFilePO> getCancelledCheque() {
		return cancelledCheque;
	}

	public void setCancelledCheque(List<UploadFilePO> cancelledCheque) {
		this.cancelledCheque = cancelledCheque;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPolHolderName() {
		return polHolderName;
	}

	public void setPolHolderName(String polHolderName) {
		this.polHolderName = polHolderName;
	}

	public String getClaimDate() {
		return claimDate;
	}

	public void setClaimDate(String claimDate) {
		this.claimDate = claimDate;
	}

	public String getDeathDate() {
		return deathDate;
	}

	public void setDeathDate(String deathDate) {
		this.deathDate = deathDate;
	}

	public String getDeathReason() {
		return deathReason;
	}

	public void setDeathReason(String deathReason) {
		this.deathReason = deathReason;
	}

}
