package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;

import com.ipru.groups.po.ClaimGratuityLeavePO;
import com.tcs.vo.BaseVO;

public class ClaimGratuityLeaveVO implements Serializable{
	
private static final long serialVersionUID = 1L;
	
	private long leaveId;
	private String fromDate;
	private String toDate;
	private String reasonForLeave;
	private String illnessType;
	private ClaimGratuityVO claimGratuityVO;
	public long getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(long leaveId) {
		this.leaveId = leaveId;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getReasonForLeave() {
		return reasonForLeave;
	}
	public void setReasonForLeave(String reasonForLeave) {
		this.reasonForLeave = reasonForLeave;
	}
	public String getIllnessType() {
		return illnessType;
	}
	public void setIllnessType(String illnessType) {
		this.illnessType = illnessType;
	}
	public ClaimGratuityVO getClaimGratuityVO() {
		return claimGratuityVO;
	}
	public void setClaimGratuityVO(ClaimGratuityVO claimGratuityVO) {
		this.claimGratuityVO = claimGratuityVO;
	}
	@Override
	public String toString() {
		return "ClaimGratuityLeaveVO [leaveId=" + leaveId + ", fromDate=" + fromDate + ", toDate=" + toDate + ", reasonForLeave=" + reasonForLeave + ", illnessType=" + illnessType
				+ ", claimGratuityVO=" + claimGratuityVO + "]";
	}
	
		

	
	
	
	
	
	
	
	

}
