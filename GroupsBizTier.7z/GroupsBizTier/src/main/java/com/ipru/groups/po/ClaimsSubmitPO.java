package com.ipru.groups.po;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.tcs.web.po.BasePO;

public class ClaimsSubmitPO extends GroupsBasePo{
	
	private static final long serialVersionUID = 1L;

	private Long claimId;
	private String employeeId;
	private String employeeName;
	private String eventDate;
	private String intimationDate;
	private String cause;
	private String pan;
	
	private String mobileNumber;
	private String commutation;
	private String annuity;
	private String gratuityApplicable;
	private String employeeEmailId_1;
	private String employeeEmailId_2;
	
	private String status;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	private long transactionId;

	private List<UploadFilePO> uploadFileList;

	private List<BeneficiaryPO> beneficiary;
	//private Map<String,BeneficiaryPO> beneficiary = new HashMap<String, BeneficiaryPO>();

	private Set<BeneficiaryPO> beneficiarySet =new HashSet<BeneficiaryPO>(0);

	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public String getIntimationDate() {
		return intimationDate;
	}

	public void setIntimationDate(String intimationDate) {
		this.intimationDate = intimationDate;
	}



	public String getCause() {
		return cause;
	}

	public void setCause(String cause) {
		this.cause = cause;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCommutation() {
		return commutation;
	}

	public void setCommutation(String commutation) {
		this.commutation = commutation;
	}

	public String getAnnuity() {
		return annuity;
	}

	public void setAnnuity(String annuity) {
		this.annuity = annuity;
	}

	public String getGratuityApplicable() {
		return gratuityApplicable;
	}

	public void setGratuityApplicable(String gratuityApplicable) {
		this.gratuityApplicable = gratuityApplicable;
	}

	

	public String getEmployeeEmailId_1() {
		return employeeEmailId_1;
	}

	public void setEmployeeEmailId_1(String employeeEmailId_1) {
		this.employeeEmailId_1 = employeeEmailId_1;
	}

	public String getEmployeeEmailId_2() {
		return employeeEmailId_2;
	}

	public void setEmployeeEmailId_2(String employeeEmailId_2) {
		this.employeeEmailId_2 = employeeEmailId_2;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public List<UploadFilePO> getUploadFileList() {
		return uploadFileList;
	}

	public void setUploadFileList(List<UploadFilePO> uploadFileList) {
		this.uploadFileList = uploadFileList;
	}

	public List<BeneficiaryPO> getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(List<BeneficiaryPO> beneficiary) {
		this.beneficiary = beneficiary;
	}

	public Set<BeneficiaryPO> getBeneficiarySet() {
		return beneficiarySet;
	}

	public void setBeneficiarySet(Set<BeneficiaryPO> beneficiarySet) {
		this.beneficiarySet = beneficiarySet;
	}

	public static synchronized long getSerialversionuid() {
		return serialVersionUID;
	}
	


	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	@Override
	public String toString() {
		return "ClaimsSubmitPO [claimId=" + claimId + ", employeeId=" + employeeId + ", employeeName=" + employeeName + ", eventDate=" + eventDate + ", intimationDate=" + intimationDate + ", cause="
				+ cause + ", pan=" + pan + ", mobileNumber=" + mobileNumber + ", commutation=" + commutation + ", annuity=" + annuity + ", gratuityApplicable=" + gratuityApplicable
				+ ", employeeEmailId_1=" + employeeEmailId_1 + ", employeeEmailId_2=" + employeeEmailId_2 + ", status=" + status + ", createdBy=" + createdBy + ", createdDate=" + createdDate
				+ ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + ", transactionId=" + transactionId + ", uploadFileList=" + uploadFileList + ", beneficiary=" + beneficiary
				+ ", beneficiarySet=" + beneficiarySet + "]";
	}

		
}
