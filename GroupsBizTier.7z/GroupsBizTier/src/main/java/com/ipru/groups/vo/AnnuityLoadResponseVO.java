package com.ipru.groups.vo;

public class AnnuityLoadResponseVO extends GroupsBaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double purchasePrice;
	private boolean showFormLink;
	private long claimId;

	public double getPurchasePrice() {
		return purchasePrice;
	}

	public void setPurchasePrice(double purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

	public boolean isShowFormLink() {
		return showFormLink;
	}

	public void setShowFormLink(boolean showFormLink) {
		this.showFormLink = showFormLink;
	}

	public long getClaimId() {
		return claimId;
	}

	public void setClaimId(long claimId) {
		this.claimId = claimId;
	}

}
