package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

public class ServiceWebPageMenuListPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNo;
	private List<ServiceWebPageMenuPO> menuList;
	private long functionalityId;

	public ServiceWebPageMenuListPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceWebPageMenuListPO(List<ServiceWebPageMenuPO> menuList,
			String policyNo) {
		super();
		this.menuList = menuList;
		this.policyNo = policyNo;
	}

	public List<ServiceWebPageMenuPO> getMenuList() {
		return menuList;
	}

	public void setMenuList(List<ServiceWebPageMenuPO> menuList) {
		this.menuList = menuList;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public long getFunctionalityId() {
		return functionalityId;
	}

	public void setFunctionalityId(long functionalityId) {
		this.functionalityId = functionalityId;
	}
	
	

}
