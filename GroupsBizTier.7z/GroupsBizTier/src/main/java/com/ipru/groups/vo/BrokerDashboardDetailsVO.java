package com.ipru.groups.vo;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ipru.groups.po.FieldAccessMappingPO;
import com.ipru.groups.po.RoleScreenAccessMapPO;
import com.ipru.security.user.PolicyDetails;
import com.tcs.vo.BaseVO;

public class BrokerDashboardDetailsVO extends BaseVO {

	private static final long serialVersionUID = 1L;
	private String branchCode;
	private String nationalCode;
	private String licenseValidityDate;
	

	
	private Map<String, FieldAccessMappingVO> fieldAccessMappingMap;
	private List<RoleScreenAccessMapVO> roleAccessMapList;
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getNationalCode() {
		return nationalCode;
	}
	public void setNationalCode(String nationalCode) {
		this.nationalCode = nationalCode;
	}
	
	
	public String getLicenseValidityDate() {
		return licenseValidityDate;
	}
	public void setLicenseValidityDate(String licenseValidityDate) {
		this.licenseValidityDate = licenseValidityDate;
	}
	
	
	public Map<String, FieldAccessMappingVO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}
	public void setFieldAccessMappingMap(Map<String, FieldAccessMappingVO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}
	public List<RoleScreenAccessMapVO> getRoleAccessMapList() {
		return roleAccessMapList;
	}
	public void setRoleAccessMapList(List<RoleScreenAccessMapVO> roleAccessMapList) {
		this.roleAccessMapList = roleAccessMapList;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
