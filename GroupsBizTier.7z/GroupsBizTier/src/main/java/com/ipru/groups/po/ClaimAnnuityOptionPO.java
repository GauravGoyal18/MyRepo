package com.ipru.groups.po;

public class ClaimAnnuityOptionPO extends GroupsBasePo {

	private Long optionId;
	private String empId;
	private String optionName;
	private String isSpouseVisible;
	private String isBeneficiaryVisible;
	private String isPanFileVisible;
	private String isSpouseDobFileVisible;
	private String isBenDobFileVisible;
	private String isAgeProofVisible;
	private String downloadShow;

	public String getDownloadShow() {
		return downloadShow;
	}

	public void setDownloadShow(String downloadShow) {
		this.downloadShow = downloadShow;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getIsPanFileVisible() {
		return isPanFileVisible;
	}

	public void setIsPanFileVisible(String isPanFileVisible) {
		this.isPanFileVisible = isPanFileVisible;
	}

	public String getIsSpouseDobFileVisible() {
		return isSpouseDobFileVisible;
	}

	public void setIsSpouseDobFileVisible(String isSpouseDobFileVisible) {
		this.isSpouseDobFileVisible = isSpouseDobFileVisible;
	}

	public String getIsBenDobFileVisible() {
		return isBenDobFileVisible;
	}

	public void setIsBenDobFileVisible(String isBenDobFileVisible) {
		this.isBenDobFileVisible = isBenDobFileVisible;
	}

	public String getIsAgeProofVisible() {
		return isAgeProofVisible;
	}

	public void setIsAgeProofVisible(String isAgeProofVisible) {
		this.isAgeProofVisible = isAgeProofVisible;
	}

	public Long getOptionId() {
		return optionId;
	}

	public void setOptionId(Long optionId) {
		this.optionId = optionId;
	}

	public String getOptionName() {
		return optionName;
	}

	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}

	public String getIsSpouseVisible() {
		return isSpouseVisible;
	}

	public void setIsSpouseVisible(String isSpouseVisible) {
		this.isSpouseVisible = isSpouseVisible;
	}

	public String getIsBeneficiaryVisible() {
		return isBeneficiaryVisible;
	}

	public void setIsBeneficiaryVisible(String isBeneficiaryVisible) {
		this.isBeneficiaryVisible = isBeneficiaryVisible;
	}

}
