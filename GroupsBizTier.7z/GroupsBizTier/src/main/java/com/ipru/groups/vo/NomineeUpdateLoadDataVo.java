package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.ipru.groups.po.RoleScreenAccessMappingPO;

public class NomineeUpdateLoadDataVo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<RoleScreenAccessMappingPO> accessMappingList;
	private Map<String, FieldAccessMappingVO> fieldAccessMappingMap;
	List<NomineeUpdateVo> nomineeUpdateVo;
	List<NomineeUpdateRelationVo> nomineeUpdateRelationVo;
	boolean requestPerDay;

	public boolean isRequestPerDay() {
		return requestPerDay;
	}

	public void setRequestPerDay(boolean requestPerDay) {
		this.requestPerDay = requestPerDay;
	}

	public List<NomineeUpdateVo> getNomineeUpdateVo() {
		return nomineeUpdateVo;
	}

	public void setNomineeUpdateVo(List<NomineeUpdateVo> nomineeUpdateVo) {
		this.nomineeUpdateVo = nomineeUpdateVo;
	}

	public List<NomineeUpdateRelationVo> getNomineeUpdateRelationVo() {
		return nomineeUpdateRelationVo;
	}

	public void setNomineeUpdateRelationVo(List<NomineeUpdateRelationVo> nomineeUpdateRelationVo) {
		this.nomineeUpdateRelationVo = nomineeUpdateRelationVo;
	}

	public List<RoleScreenAccessMappingPO> getAccessMappingList() {
		return accessMappingList;
	}

	public void setAccessMappingList(List<RoleScreenAccessMappingPO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}

	public Map<String, FieldAccessMappingVO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}

	public void setFieldAccessMappingMap(Map<String, FieldAccessMappingVO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}

	@Override
	public String toString() {
		return "NomineeUpdateLoadDataVo [accessMappingList=" + accessMappingList + ", fieldAccessMappingMap=" + fieldAccessMappingMap + ", nomineeUpdateVo=" + nomineeUpdateVo
				+ ", nomineeUpdateRelationVo=" + nomineeUpdateRelationVo + ", requestPerDay=" + requestPerDay + "]";
	}

}
