package com.ipru.groups.security.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ipru.groups.interceptor.GroupBaseDao;
import com.ipru.groups.po.BusinessParametersList;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.PolicyProductFundMasterVO;
import com.ipru.groups.vo.PolicyValidMasterVO;
import com.ipru.groups.vo.ProductFundMasterVO;
import com.ipru.groups.vo.ProductMasterVO;
import com.ipru.groups.vo.ProductSwitchAmountVO;
import com.tcs.dao.hibernate.BaseDAOHibernateImpl;

public class BusinessParametersListDAOHibernateImpl extends GroupBaseDao<BusinessParametersList, Integer> {

	private String thisClass = this.getClass().getName();

	public BusinessParametersListDAOHibernateImpl(String p_StrModuleName) {
		super(p_StrModuleName);
	}

	public Object openSession() {
		return getSession();
	}

	public void closeSession(Object session) {
		if (null != session) {
			((Session) session).clear();
			((Session) session).close();

		}
	}

	// added for url retrieval
	public List<String> selectAllUrls() {
		Transaction tx = null;
		Session session = null;
		try {
			session = getSession();
			tx = session.beginTransaction();

			List<String> urls = new ArrayList<String>();
			urls = (List<String>) (session.getNamedQuery("RoleScreenAccessMappingVO.getDistinctScreenCodes").list());
			tx.commit();

			return urls;

		}
		catch (Exception e) {
			e.printStackTrace();
			if(tx != null) 
				tx.rollback();
			return null;
		}

		finally {
			if (session != null && session.isOpen()) {
				session.clear();
				session.close();
			}
		}

	}

	public List<FieldAccessMappingVO> getFieldAccessMappingList(String role) {

		Session session = null;
		List<FieldAccessMappingVO> fieldAccessMappingVoList = new ArrayList<FieldAccessMappingVO>();
		Transaction tx = null;
		try {
			session = getSession();
			tx=session.beginTransaction();
			List result = (List) (session.createSQLQuery("SELECT A.RD_ID,A.RD_ROLE,A.RD_COMPONENT,A.RD_FLOW,A.RD_PARENT_COMP_ID,A.RD_OP_ID,B.OP_SHOW_EDIT,B.OP_SHOW_DISABLED,B.OP_SHOW,B.OP_SHOW_SUBMIT,B.OP_MANDATORY, A.RD_COMPONENT_POS_ID FROM GRP_RULE_DEFINITION_MASTER A, GRP_OPERATION_MASTER B WHERE A.RD_OP_ID = B.OP_ID AND A.RD_ROLE=:role").setParameter("role", role).list());

			Iterator iterator = result.iterator();

			while (iterator.hasNext()) {
				Object[] row = (Object[]) iterator.next();
				if (row != null) {
					FieldAccessMappingVO fieldAccessMappingVO = new FieldAccessMappingVO();
					if (row[0] != null)
						fieldAccessMappingVO.setRdId(Long.valueOf(String.valueOf(row[0])));
					fieldAccessMappingVO.setRdRole(String.valueOf(row[1]));
					fieldAccessMappingVO.setRdComponent(String.valueOf(row[2]));
					fieldAccessMappingVO.setRdFlow(String.valueOf(row[3]));
					if (row[4] != null)
						fieldAccessMappingVO.setRdParentComponentId(Long.valueOf(String.valueOf(row[4])));
					if (row[5] != null)
						fieldAccessMappingVO.setRdOpId(Long.valueOf(String.valueOf(row[5])));
					fieldAccessMappingVO.setOpShowEdit(String.valueOf(row[6]));
					fieldAccessMappingVO.setOpShowDisabled(String.valueOf(row[7]));
					fieldAccessMappingVO.setOpShow(String.valueOf(row[8]));
					fieldAccessMappingVO.setOpShowSubmit(String.valueOf(row[9]));
					fieldAccessMappingVO.setOpMandatory(String.valueOf(row[10]));
					if (row[11] != null)
						fieldAccessMappingVO.setRdComponentPosId(Long.valueOf(String.valueOf(row[11])));
					fieldAccessMappingVoList.add(fieldAccessMappingVO);
				}
			}
			tx.commit();
		}
		catch (Exception e) {
			e.printStackTrace();
			if(tx!=null)
				tx.rollback();
			return null;
		}

		finally {
			if (session != null && session.isOpen()) {
				session.clear();
				session.close();
			}
		}
		return fieldAccessMappingVoList;
	}
	
	
	public List<ProductMasterVO> getProductMasterList() {
		Session session = null;
		Transaction tx=null;
		try {
			session = getSession();
			tx=session.beginTransaction();
			Query query= session.getNamedQuery("ProductMasterVO.getProductMaster");
			List<ProductMasterVO> productMasterList = (List<ProductMasterVO>)query.list();
			tx.commit();
			return productMasterList;

		}
		catch (Exception e) {
			e.printStackTrace();
			if(tx!= null)
				tx.rollback();
			return null;
		}

		finally {
			if (session != null && session.isOpen()) {
				session.clear();
				session.close();
			}
		}

	}
	
	public List<FundMasterVO> getFundMasterList() {
		Session session = null;
		Transaction tx=null;
		try {
			session = getSession();
			tx=session.beginTransaction();
			/*List<FundMasterVO> fundMasterList = new ArrayList<FundMasterVO>();
			fundMasterList = (List<FundMasterVO>) (session.createSQLQuery("FundMasterVO.getFundMaster").list());*/
			
			Query query= session.getNamedQuery("FundMasterVO.getFundMaster");
			List<FundMasterVO> fundMasterList = (List<FundMasterVO>)query.list();
			tx.commit();
			return fundMasterList;

		}
		catch (Exception e) {
			e.printStackTrace();
			if(tx!=null)
				tx.rollback();
			return null;
		}

		finally {
			if (session != null && session.isOpen()) {
				session.clear();
				session.close();
			}
		}

	}
	
	public List<ProductFundMasterVO> getProductFundMasterList() {
		Transaction tx=null;
		Session session = null;
		try {
			session = getSession();
			tx=session.beginTransaction();
			/*List<ProductFundMasterVO> productFundMasterList = new ArrayList<ProductFundMasterVO>();
			productFundMasterList = (List<ProductFundMasterVO>) (session.createSQLQuery("ProductFundMasterVO.getProductFundMaster").list());*/
			
			Query query= session.getNamedQuery("ProductFundMasterVO.getProductFundMaster");
			List<ProductFundMasterVO> productFundMasterList = (List<ProductFundMasterVO>)query.list();
			tx.commit();
			return productFundMasterList;

		}
		catch (Exception e) {
			e.printStackTrace();
			if(tx != null)
				tx.rollback();
			return null;
		}

		finally {
			if (session != null && session.isOpen()) {
				session.clear();
				session.close();
			}
		}

	}
	
	public List<ProductSwitchAmountVO> getProductProductSwitchAmountMasterList() {
		Transaction tx=null;

		Session session = null;
		try {
			session = getSession();
			tx=session.beginTransaction();

			/*List<ProductFundMasterVO> productFundMasterList = new ArrayList<ProductFundMasterVO>();
			productFundMasterList = (List<ProductFundMasterVO>) (session.createSQLQuery("ProductFundMasterVO.getProductFundMaster").list());*/
			
			Query query= session.getNamedQuery("ProductSwitchAmountVO.getProductSwitchAmountMaster");
			List<ProductSwitchAmountVO> productSwitchAmountMasterList = (List<ProductSwitchAmountVO>)query.list();
			tx.commit();
			return productSwitchAmountMasterList;

		}
		catch (Exception e) {
			e.printStackTrace();
			if(tx != null)
				tx.rollback();
			return null;
		}

		finally {
			if (session != null && session.isOpen()) {
				session.clear();
				session.close();
			}
		}

	}
	
	public List<PolicyValidMasterVO> getPolicyValidMasterList() {
		Transaction tx=null;
		Session session = null;
		try {
			session = getSession();
			tx=session.beginTransaction();

			/*List<ProductFundMasterVO> productFundMasterList = new ArrayList<ProductFundMasterVO>();
			productFundMasterList = (List<ProductFundMasterVO>) (session.createSQLQuery("ProductFundMasterVO.getProductFundMaster").list());*/
			
			Query query= session.getNamedQuery("PolicyValidMasterVO.getPolicyValidMaster");
			List<PolicyValidMasterVO> policyValidMasterList = (List<PolicyValidMasterVO>)query.list();
			tx.commit();

			return policyValidMasterList;

		}
		catch (Exception e) {
			e.printStackTrace();
			if(tx != null)
				tx.rollback();
			return null;
		}

		finally {
			if (session != null && session.isOpen()) {
				session.clear();
				session.close();
			}
		}

	}
	
	public List<FunctionalityMasterVO> getFunctionalityList() {
		Transaction tx=null;
		Session session = null;
		try {
			session = getSession();
			tx=session.beginTransaction();

			/*List<FundMasterVO> fundMasterList = new ArrayList<FundMasterVO>();
			fundMasterList = (List<FundMasterVO>) (session.createSQLQuery("FundMasterVO.getFundMaster").list());*/
			
			Query query= session.getNamedQuery("FunctionalityMasterVO.getFunctionalityList");
			List<FunctionalityMasterVO> functionalityList = (List<FunctionalityMasterVO>)query.list();
			tx.commit();

			return functionalityList;

		}
		catch (Exception e) {
			e.printStackTrace();
			if(tx != null)
				tx.rollback();
			return null;
		}

		finally {
			if (session != null && session.isOpen()) {
				session.clear();
				session.close();
			}
		}

	}

	public List<PolicyProductFundMasterVO> getPolicyProductFundList() {
		Transaction tx=null;
		Session session = null;
		try {
			session = getSession();
			tx=session.beginTransaction();

			/*List<ProductFundMasterVO> productFundMasterList = new ArrayList<ProductFundMasterVO>();
			productFundMasterList = (List<ProductFundMasterVO>) (session.createSQLQuery("ProductFundMasterVO.getProductFundMaster").list());*/
			
			Query query= session.getNamedQuery("PolicyProductFundMasterVO.getPolicyProductFundMaster");
			List<PolicyProductFundMasterVO> policyProductFundMasterList = (List<PolicyProductFundMasterVO>)query.list();
			tx.commit();

			return policyProductFundMasterList;

		}
		catch (Exception e) {
			e.printStackTrace();
			if(tx != null)
				tx.rollback();
			return null;
		}

		finally {
			if (session != null && session.isOpen()) {
				session.clear();
				session.close();
			}
		}
	}

}
