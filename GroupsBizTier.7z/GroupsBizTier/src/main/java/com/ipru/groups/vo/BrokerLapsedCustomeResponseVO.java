package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class BrokerLapsedCustomeResponseVO extends GroupsBaseVO {

	/**
	 * 
	 */
	private String policyNumber;
	private String policyStatus;
	private String productName;
	private String branchCode;
	private String clientName;
	private String premiumAmount;
	private String rcd;

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public String getRcd() {
		return rcd;
	}

	public void setRcd(String rcd) {
		this.rcd = rcd;
	}

	@Override
	public String toString() {
		return "BrokerLapsedCustomeResponseVO [policyNumber=" + policyNumber + ", policyStatus=" + policyStatus + ", productName=" + productName + ", branchCode=" + branchCode + ", clientName="
				+ clientName + ", premiumAmount=" + premiumAmount + ", rcd=" + rcd + "]";
	}

}
