package com.ipru.groups.po.profileupdate.companyaddress;

import com.ipru.groups.po.profileupdate.IFieldMeta;


public class FieldMeta implements IFieldMeta {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fieldId;
	private String oldValue;
	private String newValue;
	private String index;
	private int fieldGroupCode;
	private int fieldCode;
	
	
	public int getFieldGroupCode() {
		return fieldGroupCode;
	}
	public void setFieldGroupCode(int fieldGroupCode) {
		this.fieldGroupCode = fieldGroupCode;
	}
	public int getFieldCode() {
		return fieldCode;
	}
	public void setFieldCode(int fieldCode) {
		this.fieldCode = fieldCode;
	}
	public String getFieldId() {
		return fieldId;
	}
	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}
	public String getOldValue() {
		return oldValue;
	}
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	public String getNewValue() {
		return newValue;
	}
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	
	
	
	
	
	
	

}
