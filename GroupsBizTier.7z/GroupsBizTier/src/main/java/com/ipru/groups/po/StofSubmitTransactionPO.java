package com.ipru.groups.po;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.ipru.groups.grpswitch.bean.ProductSwitchAmountPO;
import com.ipru.groups.grpswitch.bean.SwitchFundDetailsPO;
import com.tcs.web.po.BasePO;

public class StofSubmitTransactionPO extends BasePO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long stofTransactionId;
	private String iAgreeTnC;
	private String switchType;
	private String totalStofAmount;
	private String totalFundAmount;
	private String reqExecutionDate;
	private String productCode;

	private Set<StofSubmitPo> stof = new HashSet<StofSubmitPo>(0);

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Long getStofTransactionId() {
		return stofTransactionId;
	}

	public void setStofTransactionId(Long stofTransactionId) {
		this.stofTransactionId = stofTransactionId;
	}

	public String getTotalFundAmount() {
		return totalFundAmount;
	}

	public void setTotalFundAmount(String totalFundAmount) {
		this.totalFundAmount = totalFundAmount;
	}

	public String getiAgreeTnC() {
		return iAgreeTnC;
	}

	public void setiAgreeTnC(String iAgreeTnC) {
		this.iAgreeTnC = iAgreeTnC;
	}

	public String getSwitchType() {
		return switchType;
	}

	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}

	public String getTotalStofAmount() {
		return totalStofAmount;
	}

	public void setTotalStofAmount(String totalStofAmount) {
		this.totalStofAmount = totalStofAmount;
	}

	public String getReqExecutionDate() {
		return reqExecutionDate;
	}

	public void setReqExecutionDate(String reqExecutionDate) {
		this.reqExecutionDate = reqExecutionDate;
	}

	public Set<StofSubmitPo> getStof() {
		return stof;
	}

	public void setStof(Set<StofSubmitPo> stof) {
		this.stof = stof;
	}

	@Override
	public String toString() {
		return "StofSubmitTransactionPO [stofTransactionId=" + stofTransactionId + ", iAgreeTnC=" + iAgreeTnC + ", switchType=" + switchType + ", totalStofAmount=" + totalStofAmount
				+ ", totalFundAmount=" + totalFundAmount + ", reqExecutionDate=" + reqExecutionDate + ", productCode=" + productCode + ", stof=" + stof + "]";
	}

}
