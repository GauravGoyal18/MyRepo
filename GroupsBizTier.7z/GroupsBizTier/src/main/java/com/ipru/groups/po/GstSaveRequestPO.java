package com.ipru.groups.po;

import java.io.Serializable;

public class GstSaveRequestPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private GstSubmitPO gstFormJson;
	private EmailMobileRequestPO emailMobileJson;

	public GstSubmitPO getGstFormJson() {
		return gstFormJson;
	}

	public void setGstFormJson(GstSubmitPO gstFormJson) {
		this.gstFormJson = gstFormJson;
	}

	public EmailMobileRequestPO getEmailMobileJson() {
		return emailMobileJson;
	}

	public void setEmailMobileJson(EmailMobileRequestPO emailMobileJson) {
		this.emailMobileJson = emailMobileJson;
	}

}
