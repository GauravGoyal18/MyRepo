package com.ipru.groups.utility;

import java.security.SecureRandom;
import java.util.Random;

import com.ipru.groups.widget.service.SignUpService;
import com.tcs.logger.FLogger;

public class UIDGenerator {
	
	private static final String CLASS_NAME = UIDGenerator.class.getCanonicalName();
	private static final String INFO_LOGGER_NAME = "SignUpLogger";
	
	private static final char charUpAlphabets[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
	
	public  String generateUid(String l_strFirstName, String l_strLastName, String l_strClientId, String oldData) {
		
		final String METHOD_NAME = "generateUid";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		StringBuffer l_strUid = new StringBuffer();
		StringBuffer l_sbFName = new StringBuffer();
		StringBuffer l_sbLName = new StringBuffer();
		StringBuffer upAlphabets = new StringBuffer();
		upAlphabets.append(charUpAlphabets);
		boolean l_blnFlag = true;

		for (int i = 0; i < l_strFirstName.length(); i++) {
			char c = l_strFirstName.charAt(i);
			if (c != ' ' && c != '.') {
				l_sbFName.append(c);
			}
		}
		for (int i = 0; i < l_strLastName.length(); i++) {
			char c = l_strLastName.charAt(i);
			if (c != ' ' && c != '.') {
				l_sbLName.append(c);
			}
		}
		int l_intFNameLn = l_sbFName.length();
		int l_intLNameLn = l_sbLName.length();
		if (l_intFNameLn != 0) {
			if (l_intFNameLn > 5) {
				for (int l_intFnCounter = 0; l_intFnCounter < 5; l_intFnCounter++) {
					l_strUid.append(l_sbFName.charAt(l_intFnCounter));
				}
			}
			else {
				for (int l_intFnCounter = 0; l_intFnCounter < l_intFNameLn; l_intFnCounter++) {
					l_strUid.append(l_sbFName.charAt(l_intFnCounter));
				}
			}
		}
		else {
			if (l_intLNameLn > 5) {
				for (int l_intLnCounter = 0; l_intLnCounter < 5; l_intLnCounter++) {
					l_strUid.append(l_sbLName.charAt(l_intLnCounter));
				}
			}
			else {
				for (int l_intLnCounter = 0; l_intLnCounter < l_intLNameLn; l_intLnCounter++) {
					l_strUid.append(l_sbLName.charAt(l_intLnCounter));
				}
			}
		}
		int intUidSize = l_strUid.length();
		if (intUidSize < 5 ) {
			int i = 0;
			int l_IntRanNo = 1;
			Random l_ranObj = new Random();
			while (i < 5 - intUidSize) {
				l_IntRanNo = l_ranObj.nextInt(26);
				l_strUid.append(upAlphabets.charAt(l_IntRanNo));
				i++;
			}
		}
		// system.out.println(l_strUid.toString());
		for (int l_intClientCounter = 5; l_intClientCounter < l_strClientId.trim().length(); l_intClientCounter++) {
			l_strUid.append(l_strClientId.charAt(l_intClientCounter));
		}
		
		if(oldData!=null && oldData.equalsIgnoreCase(l_strUid.toString())) {
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "User id already exist "+oldData);
			l_strUid.setLength(0);
			int i = 0;
			int l_IntRanNo = 1;
			Random l_ranObj = new SecureRandom();
			while (i < 8) {
				l_IntRanNo = l_ranObj.nextInt(26);
				l_strUid.append(upAlphabets.charAt(l_IntRanNo));
				i++;
			}
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Random user id generated "+l_strUid);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return l_strUid.toString();
	}



}
