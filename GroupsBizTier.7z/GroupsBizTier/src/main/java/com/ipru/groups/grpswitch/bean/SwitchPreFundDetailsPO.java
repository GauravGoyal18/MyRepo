package com.ipru.groups.grpswitch.bean;

import java.io.Serializable;
import java.util.Date;

import com.ipru.groups.po.GroupsBasePo;


public class SwitchPreFundDetailsPO extends GroupsBasePo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long switchPreFundDetailsId;
	private String fundCode;
	private String fundNAV;
	private Date fundNAVEffectiveDate;
	private String preFundUnit;
	private String preFundAmount;
	private SwitchTransactionPO switchTransactionPO;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	public Long getSwitchPreFundDetailsId() {
		return switchPreFundDetailsId;
	}
	public void setSwitchPreFundDetailsId(Long switchPreFundDetailsId) {
		this.switchPreFundDetailsId = switchPreFundDetailsId;
	}
	public String getFundCode() {
		return fundCode;
	}
	public void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}
	public String getFundNAV() {
		return fundNAV;
	}
	public void setFundNAV(String fundNAV) {
		this.fundNAV = fundNAV;
	}
	public Date getFundNAVEffectiveDate() {
		return fundNAVEffectiveDate;
	}
	public void setFundNAVEffectiveDate(Date fundNAVEffectiveDate) {
		this.fundNAVEffectiveDate = fundNAVEffectiveDate;
	}
	public String getPreFundUnit() {
		return preFundUnit;
	}
	public void setPreFundUnit(String preFundUnit) {
		this.preFundUnit = preFundUnit;
	}
	public String getPreFundAmount() {
		return preFundAmount;
	}
	public void setPreFundAmount(String preFundAmount) {
		this.preFundAmount = preFundAmount;
	}

	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public SwitchTransactionPO getSwitchTransactionPO() {
		return switchTransactionPO;
	}
	public void setSwitchTransactionPO(SwitchTransactionPO switchTransactionPO) {
		this.switchTransactionPO = switchTransactionPO;
	}

	



	
	



}

