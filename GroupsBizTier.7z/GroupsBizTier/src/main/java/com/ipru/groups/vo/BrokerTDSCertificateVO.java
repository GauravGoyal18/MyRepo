package com.ipru.groups.vo;

public class BrokerTDSCertificateVO extends GroupsBaseVO {

	
	private static final long serialVersionUID = 1L;
	private String natioanalcode;
	private String branchcode;
	private String brokerCode;
	private String startDate;
	private String endDate;
	
	
	
	public String getNatioanalcode() {
		return natioanalcode;
	}
	public void setNatioanalcode(String natioanalcode) {
		this.natioanalcode = natioanalcode;
	}
	public String getBranchcode() {
		return branchcode;
	}
	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}
	public String getBrokerCode() {
		return brokerCode;
	}
	public void setBrokerCode(String brokerCode) {
		this.brokerCode = brokerCode;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	@Override
	public String toString() {
		return "TDSCertificateVO [startDate=" + startDate + ", endDate="
				+ endDate + "]";
	}
}
