package com.ipru.groups.pdfgen;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.PDFTestBean;
import com.tcs.pdfgenerator.core.service.ITemplateCoreService;
import com.tcs.pdfgenerator.exception.PDFGeneratorException;
import com.tcs.pdfgenerator.service.FTL2PDFGenerator;
import com.tcs.pdfgenerator.util.PDFGeneratorUtils;

public class PdfGeneratorTestMain {
	private static Properties templateProperties;
	public static void main(String[] args) throws PDFGeneratorException {
		createFTLConfigInstance();
		ITemplateCoreService service= new TemplateCoreServiceImpl();
		PDFTestBean testBean = new PDFTestBean();
		testBean.setName("Amruta");
		FTL2PDFGenerator.getPDFGeneratorInstance.generatePDFTemplate(PDFGeneratorUtils.createTemplateBean("test.ftl", testBean, "D:/Sidana.pdf"), service);
		
		
}
	private static void createFTLConfigInstance() {
		List<String> filePaths = new ArrayList<String>(1);
		loadTemplateProperties();
		filePaths.add(GroupConstants.CONSTANT_C + templateProperties.getProperty("PDF_TMPL_PATH"));
		PDFGeneratorUtils.getFTLConfigInstance(filePaths);
		
	}
	
	private static Properties loadTemplateProperties(){
		templateProperties = MasterPropertiesFileLoader.CONSTANT_TEMPLATE_PROPERTIES;
		FileInputStream fis = null;
		
		
		if(templateProperties == null){
			templateProperties = new Properties();
			try {
				fis = new FileInputStream(GroupConstants.CONSTANT_TEMPLATE_PROP);
				templateProperties.load(fis);
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally {
				try {
					if(fis!=null)
						fis.close();
				}
				catch (Exception e) {
					
					e.printStackTrace();
				} finally {
					fis=null;
				}
			}
		}
		return templateProperties;
	}
}
