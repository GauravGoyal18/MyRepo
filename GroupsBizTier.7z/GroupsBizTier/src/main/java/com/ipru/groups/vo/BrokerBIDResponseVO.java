package com.ipru.groups.vo;

import java.math.BigDecimal;

public class BrokerBIDResponseVO extends GroupsBaseVO {
	private BigDecimal amountCr;
	private BigDecimal amountDr;
	private BigDecimal balance;
	private String date;
	private String particulars;
	private String modeOfPayment;

	/**
	 * @return the amountCr
	 */
	public BigDecimal getAmountCr() {
		return amountCr;
	}

	/**
	 * @param amountCr
	 *            the amountCr to set
	 */
	public void setAmountCr(BigDecimal amountCr) {
		this.amountCr = amountCr;
	}

	/**
	 * @return the amountDr
	 */
	public BigDecimal getAmountDr() {
		return amountDr;
	}

	/**
	 * @param amountDr
	 *            the amountDr to set
	 */
	public void setAmountDr(BigDecimal amountDr) {
		this.amountDr = amountDr;
	}

	/**
	 * @return the balance
	 */
	public BigDecimal getBalance() {
		return balance;
	}

	/**
	 * @param balance
	 *            the balance to set
	 */
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date
	 *            the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * @return the particulars
	 */
	public String getParticulars() {
		return particulars;
	}

	/**
	 * @param particulars
	 *            the particulars to set
	 */
	public void setParticulars(String particulars) {
		this.particulars = particulars;
	}

	/**
	 * @return the modeOfPayment
	 */
	public String getModeOfPayment() {
		return modeOfPayment;
	}

	/**
	 * @param modeOfPayment
	 *            the modeOfPayment to set
	 */
	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

}
