package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;

public class BeneficiaryVO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long beneficiaryId;
	public Long getBeneficiaryId() {
		return beneficiaryId;
	}
	public void setBeneficiaryId(Long beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	private String beneficiaryName;
	private String companyOrBuildingName;
	private String flatOrUnitNumber;
	private String streetOrArea;
	private String landmark;
	private String city;
	private String state;
	private String pincode;
	private String addressProofDocumentType;
	
	private String createdBy;
	private Date    createdDate;
	private String updatedBy;
	private Date   updatedDate;
	private String  appointyName;
	private String beneficiaryDOB;
	private String sharePercentage;
	private String relation;
	private String bankAccountNUMBER;
	private String bankName;
	private String ifscCode;
	private String micrCode;
	private ClaimsSubmitVO claimVO;
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public ClaimsSubmitVO getClaimVO() {
		return claimVO;
	}
	public void setClaimVO(ClaimsSubmitVO claimVO) {
		this.claimVO = claimVO;
	}
	
	
	
	public String getSharePercentage() {
		return sharePercentage;
	}
	public void setSharePercentage(String sharePercentage) {
		this.sharePercentage = sharePercentage;
	}
	public String getAppointyName() {
		return appointyName;
	}
	public void setAppointyName(String appointyName) {
		this.appointyName = appointyName;
	}
	public String getBeneficiaryDOB() {
		return beneficiaryDOB;
	}
	public void setBeneficiaryDOB(String beneficiaryDOB) {
		this.beneficiaryDOB = beneficiaryDOB;
	}
	
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getBankAccountNUMBER() {
		return bankAccountNUMBER;
	}
	public void setBankAccountNUMBER(String bankAccountNUMBER) {
		this.bankAccountNUMBER = bankAccountNUMBER;
	}
	
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getMicrCode() {
		return micrCode;
	}
	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}
	public String getCompanyOrBuildingName() {
		return companyOrBuildingName;
	}
	public void setCompanyOrBuildingName(String companyOrBuildingName) {
		this.companyOrBuildingName = companyOrBuildingName;
	}
	public String getFlatOrUnitNumber() {
		return flatOrUnitNumber;
	}
	public void setFlatOrUnitNumber(String flatOrUnitNumber) {
		this.flatOrUnitNumber = flatOrUnitNumber;
	}
	public String getStreetOrArea() {
		return streetOrArea;
	}
	public void setStreetOrArea(String streetOrArea) {
		this.streetOrArea = streetOrArea;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getAddressProofDocumentType() {
		return addressProofDocumentType;
	}
	public void setAddressProofDocumentType(String addressProofDocumentType) {
		this.addressProofDocumentType = addressProofDocumentType;
	}
	

}

