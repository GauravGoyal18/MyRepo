package com.ipru.groups.vo;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ipru.groups.po.FieldAccessMappingPO;
import com.tcs.vo.BaseVO;

public class PortfolioDataVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double contributionTillDate;
	private double bonusTillAllocation;
	private double payoutTillDate;
	private double lessAdjustments;
	private double addAdjustments;
	private double yearEndAnualBonus;
	private double actualContributionTillDate;
	private double totalFundValueToday;
	private Date navDate;
	private List<MemberFundDataVO> fundDetails;
	private Map<String, FieldAccessMappingVO> fieldAccessMappingMap;

	public double getContributionTillDate() {
		return contributionTillDate;
	}

	public void setContributionTillDate(double contributionTillDate) {
		this.contributionTillDate = contributionTillDate;
	}

	public double getBonusTillAllocation() {
		return bonusTillAllocation;
	}

	public void setBonusTillAllocation(double bonusTillAllocation) {
		this.bonusTillAllocation = bonusTillAllocation;
	}

	public double getPayoutTillDate() {
		return payoutTillDate;
	}

	public void setPayoutTillDate(double payoutTillDate) {
		this.payoutTillDate = payoutTillDate;
	}

	public double getLessAdjustments() {
		return lessAdjustments;
	}

	public void setLessAdjustments(double lessAdjustments) {
		this.lessAdjustments = lessAdjustments;
	}

	public double getAddAdjustments() {
		return addAdjustments;
	}

	public void setAddAdjustments(double addAdjustments) {
		this.addAdjustments = addAdjustments;
	}

	public double getYearEndAnualBonus() {
		return yearEndAnualBonus;
	}

	public void setYearEndAnualBonus(double yearEndAnualBonus) {
		this.yearEndAnualBonus = yearEndAnualBonus;
	}

	public double getActualContributionTillDate() {
		return actualContributionTillDate;
	}

	public void setActualContributionTillDate(double actualContributionTillDate) {
		this.actualContributionTillDate = actualContributionTillDate;
	}

	public double getTotalFundValueToday() {
		return totalFundValueToday;
	}

	public void setTotalFundValueToday(double totalFundValueToday) {
		this.totalFundValueToday = totalFundValueToday;
	}

	public Date getNavDate() {
		return navDate;
	}

	public void setNavDate(Date navDate) {
		this.navDate = navDate;
	}

	public List<MemberFundDataVO> getFundDetails() {
		return fundDetails;
	}

	public void setFundDetails(List<MemberFundDataVO> fundDetails) {
		this.fundDetails = fundDetails;
	}

	public Map<String, FieldAccessMappingVO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}

	public void setFieldAccessMappingMap(Map<String, FieldAccessMappingVO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}

	@Override
	public String toString() {
		return "PortfolioDataVO [contributionTillDate=" + contributionTillDate + ", bonusTillAllocation=" + bonusTillAllocation + ", payoutTillDate=" + payoutTillDate + ", lessAdjustments="
				+ lessAdjustments + ", addAdjustments=" + addAdjustments + ", yearEndAnualBonus=" + yearEndAnualBonus + ", actualContributionTillDate=" + actualContributionTillDate
				+ ", totalFundValueToday=" + totalFundValueToday + ", navDate=" + navDate + ", fundDetails=" + fundDetails + ", fieldAccessMappingMap=" + fieldAccessMappingMap + "]";
	}

}
