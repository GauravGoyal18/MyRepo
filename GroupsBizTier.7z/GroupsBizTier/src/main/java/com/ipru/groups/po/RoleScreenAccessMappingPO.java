package com.ipru.groups.po;

import java.io.Serializable;

/**
 * RoleScreenAccessMappingVO is a POJO class which is mapped to table
 * TBL_ROLESCREENACCESSMAPPING
 * 
 * @author Sudha Suman(736523)TCS
 */
public class RoleScreenAccessMappingPO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String accessGroup;
	private String screenCode;
	private Long rScMapId;
	private String hasCreate;
	private String hasRead;
	private String hasUpdate;
	private String hasDelete;
	private String roleLandingPage;
	private String policyNo;
	private String displayPriority;
	private String displayName;
	private String logo;
	private FunctionalityMasterPO functionalityMaster;


	public String getAccessGroup() {
		return accessGroup;
	}

	public void setAccessGroup(String accessGroup) {
		this.accessGroup = accessGroup;
	}

	public String getScreenCode() {
		return screenCode;
	}

	public void setScreenCode(String screenCode) {
		this.screenCode = screenCode;
	}

	public Long getrScMapId() {
		return rScMapId;
	}

	public void setrScMapId(Long rScMapId) {
		this.rScMapId = rScMapId;
	}

	public String getHasCreate() {
		return hasCreate;
	}

	public void setHasCreate(String hasCreate) {
		this.hasCreate = hasCreate;
	}

	public String getHasRead() {
		return hasRead;
	}

	public void setHasRead(String hasRead) {
		this.hasRead = hasRead;
	}

	public String getHasUpdate() {
		return hasUpdate;
	}

	public void setHasUpdate(String hasUpdate) {
		this.hasUpdate = hasUpdate;
	}

	public String getHasDelete() {
		return hasDelete;
	}

	public void setHasDelete(String hasDelete) {
		this.hasDelete = hasDelete;
	}

	public String getRoleLandingPage() {
		return roleLandingPage;
	}

	public void setRoleLandingPage(String roleLandingPage) {
		this.roleLandingPage = roleLandingPage;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/*
	 * public String getClientId() { return clientId; } public void
	 * setClientId(String clientId) { this.clientId = clientId; }
	 */
	public String getDisplayPriority() {
		return displayPriority;
	}

	public void setDisplayPriority(String displayPriority) {
		this.displayPriority = displayPriority;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public FunctionalityMasterPO getFunctionalityMaster() {
		return functionalityMaster;
	}

	public void setFunctionalityMaster(FunctionalityMasterPO functionalityMaster) {
		this.functionalityMaster = functionalityMaster;
	}

	@Override
	public String toString() {
		return "RoleScreenAccessMappingPO [accessGroup=" + accessGroup + ", screenCode=" + screenCode + ", rScMapId=" + rScMapId + ", hasCreate=" + hasCreate + ", hasRead=" + hasRead + ", hasUpdate="
				+ hasUpdate + ", hasDelete=" + hasDelete + ", roleLandingPage=" + roleLandingPage + ", policyNo=" + policyNo + ", displayPriority=" + displayPriority + ", displayName=" + displayName
				+ ", logo=" + logo + ", functionalityMaster=" + functionalityMaster + "]";
	}





	

}
