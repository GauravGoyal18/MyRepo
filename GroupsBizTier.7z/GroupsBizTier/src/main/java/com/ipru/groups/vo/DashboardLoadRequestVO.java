package com.ipru.groups.vo;

import java.util.List;

import com.ipru.groups.po.RoleScreenAccessMappingPO;
import com.ipru.security.user.IPruUser;
import com.tcs.vo.BaseVO;

public class DashboardLoadRequestVO extends BaseVO {

	private static final long serialVersionUID = 1L;
	private String screenName;
	private IPruUser userVO;

	public IPruUser getUserVO() {
		return userVO;
	}

	public void setUserVO(IPruUser userVO) {
		this.userVO = userVO;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

}
