package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.ipru.groups.vo.ClaimGratuityVO;
import com.tcs.web.po.BasePO;

public class ClaimGratuityLeavePO  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private long leaveId;
	private String fromDate;
	private String toDate;
	private String reasonForLeave;
	private String illnessType;
	private ClaimGratuityPO claimGratuityPO;
	public long getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(long leaveId) {
		this.leaveId = leaveId;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getReasonForLeave() {
		return reasonForLeave;
	}
	public void setReasonForLeave(String reasonForLeave) {
		this.reasonForLeave = reasonForLeave;
	}
	public String getIllnessType() {
		return illnessType;
	}
	public void setIllnessType(String illnessType) {
		this.illnessType = illnessType;
	}
	public ClaimGratuityPO getClaimGratuityPO() {
		return claimGratuityPO;
	}
	public void setClaimGratuityPO(ClaimGratuityPO claimGratuityPO) {
		this.claimGratuityPO = claimGratuityPO;
	}
	@Override
	public String toString() {
		return "ClaimGratuityLeavePO [leaveId=" + leaveId + ", fromDate=" + fromDate + ", toDate=" + toDate + ", reasonForLeave=" + reasonForLeave + ", illnessType=" + illnessType
				+ ", claimGratuityPO=" + claimGratuityPO + "]";
	}
	
	
	/*private static ClaimGratuityLeavePO instance;
	 private static final String CLASSNAME = ClaimGratuityLeavePO.class .getCanonicalName();
          
	private ClaimGratuityLeavePO() {
	
	}
	

	 public static ClaimGratuityLeavePO getInstance() {
       if (instance == null) {
                       synchronized (CLASSNAME) {
                                       instance = new ClaimGratuityLeavePO();
                       }
       }
       return instance;
	
	
	
}*/
}
