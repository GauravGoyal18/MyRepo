package com.ipru.groups.serviceexpress.service;



import java.util.List;

import com.ipru.IPruException;
import com.ipru.groups.vo.ServiceExpressVO;
import com.ipru.groups.serviceexpress.dao.ServiceExpressDaoImpl;
import com.ipru.groups.vo.ServiceWebPageSubmitRequestVO;
import com.ipru.groups.vo.ServiceWebpageCallVO;
import com.ipru.groups.vo.UploadFileVO;
import com.ipru.groups.widget.dao.ServiceWebPageDAOHibernateImpl;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.service.BaseService;

public class ServiceExpressServiceImpl extends BaseService {
	
	
	
	public ServiceExpressVO ServiceExpressSubmitData(ServiceExpressVO serviceExpressVO) throws Exception {
		FLogger.info("ServiceExpressLogger", "ServiceExpressServiceImpl", "ServiceExpressSubmitData", " Method start ");
		
		
		
		
		if (serviceExpressVO != null) {
			
			
			ServiceExpressDaoImpl dao = new ServiceExpressDaoImpl("group");
			serviceExpressVO =  dao.serviceExpressSubmit(serviceExpressVO);
		}
		else {
			FLogger.error("ServiceExpressError", "ServiceExpressServiceImpl", "ServiceExpressSubmitData", "result cannot be null");
			throw new IPruException("Error", "GRPT01", "serviceExpressVO cannot be null");
		}
		FLogger.info("ServiceExpressLogger", "ServiceExpressServiceImpl", "ServiceExpressSubmitData", "Method End");
		return serviceExpressVO;
		
	}
}
