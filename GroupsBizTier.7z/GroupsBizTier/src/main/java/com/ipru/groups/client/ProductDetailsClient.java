package com.ipru.groups.client;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ipru.groups.param.obj.ParamObj;
import com.ipru.groups.po.PrePopulateBean;
import com.ipru.groups.service.WebserviceInvoke;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.NomineeUpdateVo;
import com.ipru.groups.vo.ProductDetailsVO;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.tcs.logger.FLogger;

public class ProductDetailsClient {
	public static ProductDetailsVO fetchProductDetails(String policyNumber) throws Exception {
		FLogger.info("FundPerformanceLogger", "ProductDetailsClient", "fetchProductDetails", "Method Start");

		ProductDetailsVO product = new ProductDetailsVO();
		product = getProductDetails(policyNumber);
		FLogger.info("FundPerformanceLogger", "ProductDetailsClient", "fetchProductDetails", "Method End");
		return product;
	}

	public static ProductDetailsVO getProductDetails(String policyNumber) throws Exception {
		FLogger.info("FundPerformanceLogger", "ProductDetailsClient", "getProductDetails", "Method Start");
		List<ProductDetailsVO> productDetailsVOList = new ArrayList<ProductDetailsVO>();

		Client clientGet = Client.create();

		List<String> paramList = new ArrayList();

		paramList.add(policyNumber);

		Type listType = new TypeToken<ArrayList<ProductDetailsVO>>() {
		}.getType();
		String output = WebserviceInvoke.getInstance().invokePrePopulateDetailsForFundPerformance(paramList,"FundPerformanceLogger");

		if (StringUtils.isNoneBlank(output)) {
			productDetailsVOList = new Gson().fromJson(output, listType);
			return productDetailsVOList.get(0);

		}
		else {
			return null;
		}
		
	}

	/*public static void main(String[] args) throws Exception {

		ProductDetailsClient.fetchProductDetails("00000348");
	}*/
}
