package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class ClaimsExcelResponsePO implements Serializable {

	private String key;
	private List value;
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public List getValue() {
		return value;
	}
	public void setValue(List value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "ClaimsExcelResponsePO [key=" + key + ", value=" + value + "]";
	}
	
	
}
