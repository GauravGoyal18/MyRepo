package com.ipru.groups.vo;

import java.io.Serializable;

public class RetirementCalenderVO implements Serializable {
	
	
	private String employeeId;
	private String firstName;
	private String lastName;
	private String birthDate;
	private String policyNumber;
	private String retirementDate;
	
	
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getRetirementDate() {
		return retirementDate;
	}
	public void setRetirementDate(String retirementDate) {
		this.retirementDate = retirementDate;
	}
	
	
	@Override
	public String toString() {
		return "RetirementCalenderVO [employeeId=" + employeeId
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", birthDate=" + birthDate + ", policyNumber=" + policyNumber
				+ ", retirementDate=" + retirementDate + "]";
	}
	

}

