package com.ipru.groups.po;

import java.util.List;

import com.ipru.groups.vo.ClaimDropDownVO;
import com.tcs.web.po.BasePO;

public class ClaimsDropDownData extends BasePO {
	List<ClaimDropDownVO> state;
	List<ClaimDropDownVO> city;
	List<ClaimDropDownVO> cause;
	List<ClaimDropDownVO> relation;
	boolean requestPerDay;
	private String productType;

	String functionalityId;

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public synchronized boolean isRequestPerDay() {
		return requestPerDay;
	}

	public synchronized void setRequestPerDay(boolean requestPerDay) {
		this.requestPerDay = requestPerDay;
	}

	public String getFunctionalityId() {
		return functionalityId;
	}

	public void setFunctionalityId(String functionalityId) {
		this.functionalityId = functionalityId;
	}

	public List<ClaimDropDownVO> getRelation() {
		return relation;
	}

	public void setRelation(List<ClaimDropDownVO> relation) {
		this.relation = relation;
	}

	public List<ClaimDropDownVO> getState() {
		return state;
	}

	public void setState(List<ClaimDropDownVO> state) {
		this.state = state;
	}

	public List<ClaimDropDownVO> getCity() {
		return city;
	}

	public void setCity(List<ClaimDropDownVO> city) {
		this.city = city;
	}

	public List<ClaimDropDownVO> getCause() {
		return cause;
	}

	public void setCause(List<ClaimDropDownVO> cause) {
		this.cause = cause;
	}

	@Override
	public String toString() {
		return "ClaimsLoadData [state=" + state + ", city=" + city + ", cause=" + cause + ", relation=" + relation + ", requestPerDay=" + requestPerDay + ", functionalityId=" + functionalityId + "]";
	}

}
