package com.ipru.groups.po;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ipru.groups.param.obj.ParamObj;


@XmlRootElement

public class DropDownRequestPO {

	private String functionality;
	private String dropDownType;
	private ParamObj paramObj;
	
		@XmlElement
	public String getFunctionality() {
		return functionality;
	}
	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}
	@XmlElement
	public String getDropDownType() {
		return dropDownType;
	}
	public void setDropDownType(String dropDownType) {
		this.dropDownType = dropDownType;
	}
	@XmlElement
	public ParamObj getParamObj() {
		return paramObj;
	}
	public void setParamObj(ParamObj paramObj) {
		this.paramObj = paramObj;
	}
	@Override
	public String toString() {
		return "DropDownRequestPo [functionality=" + functionality
				+ ", dropDownType=" + dropDownType + ", paramObj=" + paramObj
				+ "]";
	}
	public DropDownRequestPO(String functionality, String dropDownType,
			ParamObj paramObj) {
		super();
		this.functionality = functionality;
		this.dropDownType = dropDownType;
		this.paramObj = paramObj;
	}
	public DropDownRequestPO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DropDownRequestPO(String functionality, String dropDownType) {
		super();
		this.functionality = functionality;
		this.dropDownType = dropDownType;
	}
	
	
}
