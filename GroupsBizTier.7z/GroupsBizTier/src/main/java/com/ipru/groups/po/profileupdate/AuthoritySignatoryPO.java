package com.ipru.groups.po.profileupdate;

import java.util.List;

import com.ipru.groups.po.GroupsBasePo;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.utilities.GroupCommonUtils;

public class AuthoritySignatoryPO extends GroupsBasePo {

	private static final long serialVersionUID = 1L;
	private FieldMeta title;
	private FieldMeta firstName;
	private FieldMeta middleName;
	private FieldMeta lastName;
	private FieldMeta emailId;
	private FieldMeta mobnumber;
	private FieldMeta active;
	private String prePopulateList;
	private String index;
	private long functionalityId;
	private List<UploadFilePO> uploadFiles;
	
	public long getFunctionalityId() {
		return functionalityId;
	}

	public void setFunctionalityId(long functionalityId) {
		this.functionalityId = functionalityId;
	}

	

	public FieldMeta getTitle() {
		return title;
	}

	public void setTitle(FieldMeta title) {
		
		if(title!=null){
			title.setNewValue(GroupCommonUtils.getGenderBasedOnTitle(title.getNewValue()));
			title.setOldValue(GroupCommonUtils.getGenderBasedOnTitle(title.getOldValue()));
		}
		this.title = title;

	}

	public FieldMeta getFirstName() {
		return firstName;
	}

	public void setFirstName(FieldMeta firstName) {
		this.firstName = firstName;
	}

	public FieldMeta getMiddleName() {
		return middleName;
	}

	public void setMiddleName(FieldMeta middleName) {
		this.middleName = middleName;
	}

	public FieldMeta getLastName() {
		return lastName;
	}

	public void setLastName(FieldMeta lastName) {
		this.lastName = lastName;
	}

	public FieldMeta getEmailId() {
		return emailId;
	}

	public void setEmailId(FieldMeta emailId) {
		this.emailId = emailId;
	}

	

	public FieldMeta getMobnumber() {
		return mobnumber;
	}

	public void setMobnumber(FieldMeta mobnumber) {
		this.mobnumber = mobnumber;
	}

	public FieldMeta getActive() {
		return active;
	}

	public void setActive(FieldMeta active) {

		if(active!=null){
			active.setNewValue(GroupCommonUtils.getActiveFromWebService(active.getNewValue()));
			active.setOldValue(GroupCommonUtils.getActiveFromWebService(active.getOldValue()));
		}
		this.active = active;
	}

	public String getPrePopulateList() {
		return prePopulateList;
	}

	public void setPrePopulateList(String prePopulateList) {
		this.prePopulateList = prePopulateList;
	}

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	@Override
	public String toString() {
		return "AuthoritySignatoryPO [title=" + title + ", firstName="
				+ firstName + ", middleName=" + middleName + ", lastName="
				+ lastName + ", emailId=" + emailId + ", mobnumber="
				+ mobnumber + ", active=" + active + ", prePopulateList="
				+ prePopulateList + ", index=" + index + ", functionalityId="
				+ functionalityId + ", uploadFiles=" + uploadFiles + "]";
	}

	public List<UploadFilePO> getUploadFiles() {
		return uploadFiles;
	}

	public void setUploadFiles(List<UploadFilePO> uploadFiles) {
		this.uploadFiles = uploadFiles;
	}

	
	
	
}
