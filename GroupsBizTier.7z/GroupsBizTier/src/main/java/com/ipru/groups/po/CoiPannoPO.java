package com.ipru.groups.po;

import java.io.Serializable;

public class CoiPannoPO  implements Serializable{

	private String policynumber;
	private String birthdate;
	private String pannumber;
	private String employeeid;
	private String masterpolicy;
	private String Action;
	private String docFlag;
	private String sumassured;

	
	
	public String getPolicynumber() {
		return policynumber;
	}
	public void setPolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public String getPannumber() {
		return pannumber;
	}
	public void setPannumber(String pannumber) {
		this.pannumber = pannumber;
	}
	
	
	public String getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}
	public String getAction() {
		return Action;
	}
	public void setAction(String action) {
		Action = action;
	}
	public String getMasterpolicy() {
		return masterpolicy;
	}
	public void setMasterpolicy(String masterpolicy) {
		this.masterpolicy = masterpolicy;
	}
	public String getDocFlag() {
		return docFlag;
	}
	public void setDocFlag(String docFlag) {
		this.docFlag = docFlag;
	}
	public String getSumassured() {
		return sumassured;
	}
	public void setSumassured(String sumassured) {
		this.sumassured = sumassured;
	}
	
	

}
