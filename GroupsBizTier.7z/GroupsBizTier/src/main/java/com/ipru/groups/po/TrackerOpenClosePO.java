package com.ipru.groups.po;

import java.util.List;

public class TrackerOpenClosePO extends GroupsBasePo {

	private List<ServiceTrackerTransformerPO> openList;
	private List<ServiceTrackerTransformerPO> closeList;
	private List<ServiceTrackerTransformerPO> openCloseList;

	public List<ServiceTrackerTransformerPO> getOpenCloseList() {
		return openCloseList;
	}

	public void setOpenCloseList(List<ServiceTrackerTransformerPO> openCloseList) {
		this.openCloseList = openCloseList;
	}

	public List<ServiceTrackerTransformerPO> getOpenList() {
		return openList;
	}

	public void setOpenList(List<ServiceTrackerTransformerPO> openList) {
		this.openList = openList;
	}

	public List<ServiceTrackerTransformerPO> getCloseList() {
		return closeList;
	}

	public void setCloseList(List<ServiceTrackerTransformerPO> closeList) {
		this.closeList = closeList;
	}

}
