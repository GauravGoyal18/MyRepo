package com.ipru.groups.serviceexpress.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.groups.vo.ServiceExpressVO;
import com.tcs.dao.hibernate.BaseDAOHibernateImpl;
import com.tcs.logger.FLogger;

public class ServiceExpressDaoImpl extends BaseDAOHibernateImpl<RoleScreenAccessMappingVO, Integer>{
	
	private Session session = null;

	public ServiceExpressDaoImpl(String moduleName) {
		super(moduleName);
	
	}

	public ServiceExpressVO serviceExpressSubmit(ServiceExpressVO serviceExpresssubmitVO) throws Exception {
		FLogger.info("ServiceExpressLogger", "ServiceExpressDaoImpl", "serviceExpressSubmit", "Method start");
        Transaction tx = null;
    
        try{
            session=getSession();
            
            if (session != null) {
            
            tx = session.beginTransaction();
            session.save(serviceExpresssubmitVO);
               
            tx.commit();
            }
            } catch(Exception e) {
            
            	FLogger.error("ServiceExpressError", "ServiceExpressDaoImpl", "serviceExpressSubmit", "Exception came ", e);
    			e.printStackTrace();
    			tx.rollback();
    		
    			FLogger.error("ServiceExpressError", "ServiceExpressDaoImpl", "serviceExpressSubmit", "Transaction Rolledback Successfully.");
    			throw new Exception(e);
            }
        finally {
            if(session!=null && session.isOpen()){
                session.flush();
                session.close();
                session = null;
            }
            }
        FLogger.info("ServiceExpressLogger", "ServiceExpressDaoImpl", "serviceExpressSubmit", "Method End");
		return serviceExpresssubmitVO;
		
	}
}
