package com.ipru.groups.vo;

import java.math.BigDecimal;

public class BidStatementResponseVO extends GroupsBaseVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigDecimal amountCr;
	private BigDecimal amountDr;
	private BigDecimal balance;
	private String date;
	private String particulars;
	private String modeOfPayment;
	
	
	
	public String getModeOfPayment() {
		return modeOfPayment;
	}
	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}
	
	public BigDecimal getAmountCr() {
		return amountCr;
	}
	public void setAmountCr(BigDecimal amountCr) {
		this.amountCr = amountCr;
	}
	public BigDecimal getAmountDr() {
		return amountDr;
	}
	public void setAmountDr(BigDecimal amountDr) {
		this.amountDr = amountDr;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getParticulars() {
		return particulars;
	}
	public void setParticulars(String particulars) {
		this.particulars = particulars;
	}
	@Override
	public String toString() {
		return "BidStatementResponseVO [amountCr=" + amountCr + ", amountDr="
				+ amountDr + ", balance=" + balance + ", date=" + date
				+ ", particulars=" + particulars + ", modeOfPayment="
				+ modeOfPayment + "]";
	}
	
	
}
