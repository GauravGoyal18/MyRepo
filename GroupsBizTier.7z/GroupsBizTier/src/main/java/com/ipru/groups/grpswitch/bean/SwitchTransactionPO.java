package com.ipru.groups.grpswitch.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ipru.groups.po.GroupsBasePo;

public class SwitchTransactionPO extends GroupsBasePo implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long switchFundId;
	private String isAgreedCheck;
	private String switchType;
	private String totalFundSwitchValue;
	private String totalFundValue;
//	private String role;
//	private String policyNo;
	private String productCode;
	//private String clientId;
	private String requestType;
	private Date reqExecutionDate;
	private String memberType;

	// private SwitchPreFundDetailsPO switchPreFundDetailsPO;
	private ProductSwitchAmountPO productSwitchAmount;
	private SwitchFundDetailsPO[] switchFundDetails;
	private SwitchPreFundDetailsPO[] switchPreFundDetailsPO;
	// private Set<SwitchFundDetailsPO> switchFundDetailsSet =new
	// HashSet<SwitchFundDetailsPO>(0);
	private Set<SwitchFundDetailsPO> switchFundDetailsSet;
	private List<SwitchPreFundDetailsPO> switchPreFundDetailsPOList;
	private Set<SwitchPreFundDetailsPO> switchPreFundDetailsSet = new HashSet<SwitchPreFundDetailsPO>(0);

	private Long customerTrxnId;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;

	public String getIsAgreedCheck() {
		return isAgreedCheck;
	}

	public void setIsAgreedCheck(String isAgreedCheck) {
		this.isAgreedCheck = isAgreedCheck;
	}

	public String getSwitchType() {
		return switchType;
	}

	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}

	public String getTotalFundValue() {
		return totalFundValue;
	}

	public void setTotalFundValue(String totalFundValue) {
		this.totalFundValue = totalFundValue;
	}

	/*
	 * private List switchDetails; public List getSwitchDetails() { return
	 * switchDetails; } public void setSwitchDetails(List switchDetails) {
	 * this.switchDetails = switchDetails; }
	 */

	/*
	 * public Map<String,Object> getSwitchDetails() { return switchDetails; }
	 * public void setSwitchDetails(Map<String,Object> switchDetails) {
	 * this.switchDetails = switchDetails; }
	 */

	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	public ProductSwitchAmountPO getProductSwitchAmount() {
		return productSwitchAmount;
	}

	public void setProductSwitchAmount(ProductSwitchAmountPO productSwitchAmount) {
		this.productSwitchAmount = productSwitchAmount;
	}

	public Long getSwitchFundId() {
		return switchFundId;
	}

	public void setSwitchFundId(Long switchFundId) {
		this.switchFundId = switchFundId;
	}

	public SwitchFundDetailsPO[] getSwitchFundDetails() {
		return switchFundDetails;
	}

	public void setSwitchFundDetails(SwitchFundDetailsPO[] switchFundDetails) {
		this.switchFundDetails = switchFundDetails;
	}

	/*public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}*/

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

/*	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}*/

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Set<SwitchFundDetailsPO> getSwitchFundDetailsSet() {
		return switchFundDetailsSet;
	}

	public void setSwitchFundDetailsSet(Set<SwitchFundDetailsPO> switchFundDetailsSet) {
		this.switchFundDetailsSet = switchFundDetailsSet;
	}

	public Date getReqExecutionDate() {
		return reqExecutionDate;
	}

	public void setReqExecutionDate(Date reqExecutionDate) {
		this.reqExecutionDate = reqExecutionDate;
	}

	public String getTotalFundSwitchValue() {
		return totalFundSwitchValue;
	}

	public void setTotalFundSwitchValue(String totalFundSwitchValue) {
		this.totalFundSwitchValue = totalFundSwitchValue;
	}

	public SwitchPreFundDetailsPO[] getSwitchPreFundDetailsPO() {
		return switchPreFundDetailsPO;
	}

	public void setSwitchPreFundDetailsPO(SwitchPreFundDetailsPO[] switchPreFundDetailsPO) {
		this.switchPreFundDetailsPO = switchPreFundDetailsPO;
	}

	public List<SwitchPreFundDetailsPO> getSwitchPreFundDetailsPOList() {
		return switchPreFundDetailsPOList;
	}

	public void setSwitchPreFundDetailsPOList(List<SwitchPreFundDetailsPO> switchPreFundDetailsPOList) {
		this.switchPreFundDetailsPOList = switchPreFundDetailsPOList;
	}

	public Set<SwitchPreFundDetailsPO> getSwitchPreFundDetailsSet() {
		return switchPreFundDetailsSet;
	}

	public void setSwitchPreFundDetailsSet(Set<SwitchPreFundDetailsPO> switchPreFundDetailsSet) {
		this.switchPreFundDetailsSet = switchPreFundDetailsSet;
	}

	public Long getCustomerTrxnId() {
		return customerTrxnId;
	}

	public void setCustomerTrxnId(Long customerTrxnId) {
		this.customerTrxnId = customerTrxnId;
	}

}
