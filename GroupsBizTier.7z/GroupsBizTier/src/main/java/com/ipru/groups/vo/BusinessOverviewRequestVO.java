package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class BusinessOverviewRequestVO extends GroupsBaseVO {

	/**
	 * 
	 */

	private String nationalCode;
	private String branchCode;
	private String loginType;
	private String brokerType;

	

	public String getBrokerType() {
		return brokerType;
	}

	public void setBrokerType(String brokerType) {
		this.brokerType = brokerType;
	}

	public BusinessOverviewRequestVO() {
		// TODO Auto-generated constructor stub
	}

	public String getNationalCode() {
		return nationalCode;
	}

	public void setNationalCode(String nationalCode) {
		this.nationalCode = nationalCode;

	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getLoginType() {
		return loginType;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	@Override
	public String toString() {
		return "BusinessOverviewRequestVO [nationalCode=" + nationalCode + ", branchCode=" + branchCode + ", loginType=" + loginType + ", brokerType=" + brokerType + "]";
	}

	
}
