package com.ipru.groups.vo;

import java.util.Date;

import com.ipru.groups.grpswitch.bean.SwitchFundDetailsPO;
import com.tcs.vo.BaseVO;

public class SwitchTrackerVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String role;
	private String policyNo;
	private String status;
	private String clientId;
	
	private String totalFundSwitchValue;
	private String totalFundValue;
	
	private String reqExecutionDate;
	private long customerTransactionId;
	private String fromNAV;
	private String fromAmount;
	private String toAmount;
	private String fromFundCode;
	private String toFundCode;
	private String switchType;
	private String fromUnit;
	private String toUnit;
	private long switchTransactionId;
	private SwitchFundDetailsPO switchFundDetails;
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getTotalFundSwitchValue() {
		return totalFundSwitchValue;
	}
	public void setTotalFundSwitchValue(String totalFundSwitchValue) {
		this.totalFundSwitchValue = totalFundSwitchValue;
	}
	public String getTotalFundValue() {
		return totalFundValue;
	}
	public void setTotalFundValue(String totalFundValue) {
		this.totalFundValue = totalFundValue;
	}
	public String getReqExecutionDate() {
		return reqExecutionDate;
	}
	public void setReqExecutionDate(String string) {
		this.reqExecutionDate = string;
	}
	public long getCustomerTransactionId() {
		return customerTransactionId;
	}
	public void setCustomerTransactionId(long customerTransactionId) {
		this.customerTransactionId = customerTransactionId;
	}
	
	public String getFromNAV() {
		return fromNAV;
	}
	public void setFromNAV(String fromNAV) {
		this.fromNAV = fromNAV;
	}
	public String getFromAmount() {
		return fromAmount;
	}
	public void setFromAmount(String fromAmount) {
		this.fromAmount = fromAmount;
	}
	public String getToAmount() {
		return toAmount;
	}
	public void setToAmount(String toAmount) {
		this.toAmount = toAmount;
	}
	public String getFromFundCode() {
		return fromFundCode;
	}
	public void setFromFundCode(String fromFundCode) {
		this.fromFundCode = fromFundCode;
	}
	public String getToFundCode() {
		return toFundCode;
	}
	public void setToFundCode(String toFundCode) {
		this.toFundCode = toFundCode;
	}
	
	public String getSwitchType() {
		return switchType;
	}
	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}
	public String getFromUnit() {
		return fromUnit;
	}
	public void setFromUnit(String fromUnit) {
		this.fromUnit = fromUnit;
	}
	public String getToUnit() {
		return toUnit;
	}
	public void setToUnit(String toUnit) {
		this.toUnit = toUnit;
	}
	
	public SwitchFundDetailsPO getSwitchFundDetails() {
		return switchFundDetails;
	}
	public void setSwitchFundDetails(SwitchFundDetailsPO switchFundDetails) {
		this.switchFundDetails = switchFundDetails;
	}
	
	public long getSwitchTransactionId() {
		return switchTransactionId;
	}
	public void setSwitchTransactionId(long switchTransactionId) {
		this.switchTransactionId = switchTransactionId;
	}
	@Override
	public String toString() {
		return "SwitchTrackerVO [role=" + role + ", policyNo=" + policyNo + ", status=" + status + ", clientId=" + clientId + ", totalFundSwitchValue=" + totalFundSwitchValue + ", totalFundValue="
				+ totalFundValue + ", reqExecutionDate=" + reqExecutionDate + ", customerTransactionId=" + customerTransactionId + ", fromNAV=" + fromNAV + ", fromAmount=" + fromAmount
				+ ", toAmount=" + toAmount + ", fromFundCode=" + fromFundCode + ", toFundCode=" + toFundCode + ", switchType=" + switchType + ", fromUnit=" + fromUnit + ", toUnit=" + toUnit
				+ ", switchTransactionId=" + switchTransactionId + ", switchFundDetails=" + switchFundDetails + "]";
	}
	
	
	
	
	
	
	
	
}
