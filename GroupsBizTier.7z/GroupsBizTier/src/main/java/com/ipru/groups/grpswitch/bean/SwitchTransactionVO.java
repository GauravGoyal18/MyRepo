package com.ipru.groups.grpswitch.bean;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.GroupsBaseVO;

public class SwitchTransactionVO extends GroupsBaseVO {

	private static final long serialVersionUID = 1L;

	private Long switchTransactionId;
	private String productCode;
	private String requestType;
	private String isAgreedCheck;
	private String switchType;
	private String totalFundSwitchValue;
	private String totalFundValue;
	private Date reqExecutionDate;
	private SwitchPreFundDetailsVO switchPreFundDetailsVO;
	private SwitchFundDetailsVO switchFundDetailsVO;
	private long customerTransactionId;

	private ProductSwitchAmountPO productSwitchAmount;
	private SwitchFundDetailsVO[] switchFundDetails;
	private Set<SwitchFundDetailsVO> switchFundDetailsSet = new HashSet<SwitchFundDetailsVO>(0);// req
	private Set<SwitchPreFundDetailsVO> switchPreFundDetailsSet = new HashSet<SwitchPreFundDetailsVO>(0);// req

	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	private FunctionalityMasterVO functionality;

	public String getIsAgreedCheck() {
		return isAgreedCheck;
	}

	public void setIsAgreedCheck(String isAgreedCheck) {
		this.isAgreedCheck = isAgreedCheck;
	}

	public String getSwitchType() {
		return switchType;
	}

	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}

	public String getTotalFundValue() {
		return totalFundValue;
	}

	public void setTotalFundValue(String totalFundValue) {
		this.totalFundValue = totalFundValue;
	}

	public ProductSwitchAmountPO getProductSwitchAmount() {
		return productSwitchAmount;
	}

	public void setProductSwitchAmount(ProductSwitchAmountPO productSwitchAmount) {
		this.productSwitchAmount = productSwitchAmount;
	}

	/*
	 * private List switchDetails; public List getSwitchDetails() { return
	 * switchDetails; } public void setSwitchDetails(List switchDetails) {
	 * this.switchDetails = switchDetails; }
	 */

	/*
	 * public Map<String,Object> getSwitchDetails() { return switchDetails; }
	 * public void setSwitchDetails(Map<String,Object> switchDetails) {
	 * this.switchDetails = switchDetails; }
	 */

	public SwitchFundDetailsVO[] getSwitchFundDetails() {
		return switchFundDetails;
	}

	public void setSwitchFundDetails(SwitchFundDetailsVO[] switchFundDetails) {
		this.switchFundDetails = switchFundDetails;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Long getSwitchTransactionId() {
		return switchTransactionId;
	}

	public void setSwitchTransactionId(Long switchTransactionId) {
		this.switchTransactionId = switchTransactionId;
	}

	public SwitchFundDetailsVO getSwitchFundDetailsVO() {
		return switchFundDetailsVO;
	}

	public void setSwitchFundDetailsVO(SwitchFundDetailsVO switchFundDetailsVO) {
		this.switchFundDetailsVO = switchFundDetailsVO;
	}

	public Set<SwitchFundDetailsVO> getSwitchFundDetailsSet() {
		return switchFundDetailsSet;
	}

	public void setSwitchFundDetailsSet(Set<SwitchFundDetailsVO> switchFundDetailsSet) {
		this.switchFundDetailsSet = switchFundDetailsSet;
	}

	public Date getReqExecutionDate() {
		return reqExecutionDate;
	}

	public void setReqExecutionDate(Date reqExecutionDate) {
		this.reqExecutionDate = reqExecutionDate;
	}

	public long getCustomerTransactionId() {
		return customerTransactionId;
	}

	public void setCustomerTransactionId(long customerTransactionId) {
		this.customerTransactionId = customerTransactionId;
	}

	public String getTotalFundSwitchValue() {
		return totalFundSwitchValue;
	}

	public void setTotalFundSwitchValue(String totalFundSwitchValue) {
		this.totalFundSwitchValue = totalFundSwitchValue;
	}

	public SwitchPreFundDetailsVO getSwitchPreFundDetailsVO() {
		return switchPreFundDetailsVO;
	}

	public void setSwitchPreFundDetailsVO(SwitchPreFundDetailsVO switchPreFundDetailsVO) {
		this.switchPreFundDetailsVO = switchPreFundDetailsVO;
	}

	public Set<SwitchPreFundDetailsVO> getSwitchPreFundDetailsSet() {
		return switchPreFundDetailsSet;
	}

	public void setSwitchPreFundDetailsSet(Set<SwitchPreFundDetailsVO> switchPreFundDetailsSet) {
		this.switchPreFundDetailsSet = switchPreFundDetailsSet;
	}

/*	@Override
	public String getFunctionalityReqId() {
		return String.valueOf(getSwitchTransactionId());
	}*/

	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}

	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}

}
