package com.ipru.groups.vo;

import java.io.Serializable;

public class CompanyAddressChangeVO implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int requestId;
	
	private String addressType;
	private String companyOrBuildingName;
	private String flatOrUnitNumber;
	private String streetOrArea;
	private String landmark;
	private String pincode;
	private String city;
	private String state;
	//private String addressproof;
	
	
	public int getRequestId() {
		return requestId;
	}
	
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	public String getCompanyOrBuildingName() {
		return companyOrBuildingName;
	}
	public void setCompanyOrBuildingName(String companyOrBuildingName) {
		this.companyOrBuildingName = companyOrBuildingName;
	}
	public String getFlatOrUnitNumber() {
		return flatOrUnitNumber;
	}
	public void setFlatOrUnitNumber(String flatOrUnitNumber) {
		this.flatOrUnitNumber = flatOrUnitNumber;
	}
	public String getStreetOrArea() {
		return streetOrArea;
	}
	public void setStreetOrArea(String streetOrArea) {
		this.streetOrArea = streetOrArea;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	/*public String getAddressproof() {
		return addressproof;
	}
	public void setAddressproof(String addressproof) {
		this.addressproof = addressproof;
	}*/
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	@Override
	public String toString() {
		return "CompanyAddressChangeVO [requestId=" + requestId
				+ ", addressType=" + addressType + ", companyOrBuildingName="
				+ companyOrBuildingName + ", flatOrUnitNumber="
				+ flatOrUnitNumber + ", streetOrArea=" + streetOrArea
				+ ", landmark=" + landmark + ", pincode=" + pincode + ", city="
				+ city + ", state=" + state + "]";
	}

		
		
	
		
		

}
