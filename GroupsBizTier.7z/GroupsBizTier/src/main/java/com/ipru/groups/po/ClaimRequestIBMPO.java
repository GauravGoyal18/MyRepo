package com.ipru.groups.po;

import com.tcs.web.po.BasePO;

public class ClaimRequestIBMPO extends BasePO{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNo;
	private String employeeId;
	private String typeOfClaim;
	private String gratuityApplicable;
	private String commutationPer;
	private String annuityPer;
	private String empName;
	private String beneficiary;
	private String beneficiaryPayMode;
	private String ifscCode;
	private String micrCode;
	private String bankName;
	private String bankAccountNo;
	private String address;
	private String functionalityId;
	
	public String getFunctionalityId() {
		return functionalityId;
	}
	public void setFunctionalityId(String functionalityId) {
		this.functionalityId = functionalityId;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getTypeOfClaim() {
		return typeOfClaim;
	}
	public void setTypeOfClaim(String typeOfClaim) {
		this.typeOfClaim = typeOfClaim;
	}
	public String getGratuityApplicable() {
		return gratuityApplicable;
	}
	public void setGratuityApplicable(String gratuityApplicable) {
		this.gratuityApplicable = gratuityApplicable;
	}
	public String getCommutationPer() {
		return commutationPer;
	}
	public void setCommutationPer(String commutationPer) {
		this.commutationPer = commutationPer;
	}
	public String getAnnuityPer() {
		return annuityPer;
	}
	public void setAnnuityPer(String annuityPer) {
		this.annuityPer = annuityPer;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getBeneficiary() {
		return beneficiary;
	}
	public void setBeneficiary(String beneficiary) {
		this.beneficiary = beneficiary;
	}
	public String getBeneficiaryPayMode() {
		return beneficiaryPayMode;
	}
	public void setBeneficiaryPayMode(String beneficiaryPayMode) {
		this.beneficiaryPayMode = beneficiaryPayMode;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getMicrCode() {
		return micrCode;
	}
	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankAccountNo() {
		return bankAccountNo;
	}
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "ClaimRequestIBMPO [policyNo=" + policyNo + ", employeeId="
				+ employeeId + ", typeOfClaim=" + typeOfClaim
				+ ", gratuityApplicable=" + gratuityApplicable
				+ ", commutationPer=" + commutationPer + ", annuityPer="
				+ annuityPer + ", empName=" + empName + ", beneficiary="
				+ beneficiary + ", beneficiaryPayMode=" + beneficiaryPayMode
				+ ", ifscCode=" + ifscCode + ", micrCode=" + micrCode
				+ ", bankName=" + bankName + ", bankAccountNo=" + bankAccountNo
				+ ", address=" + address + ", functionalityId="
				+ functionalityId + "]";
	}
	
	
	
	
	
	

}
