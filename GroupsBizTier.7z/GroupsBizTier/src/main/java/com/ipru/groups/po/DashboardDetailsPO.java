package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.ipru.security.user.PolicyDetails;

public class DashboardDetailsPO implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<PolicyDetailsPO> policyDetailList;
	private PolicyDetails selectedPolicy;

	public DashboardDetailsPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PolicyDetails getSelectedPolicy() {
		return selectedPolicy;
	}

	public void setSelectedPolicy(PolicyDetails selectedPolicy) {
		this.selectedPolicy = selectedPolicy;
	}

	public List<PolicyDetailsPO> getPolicyDetailList() {
		return policyDetailList;
	}

	public void setPolicyDetailList(List<PolicyDetailsPO> policyDetailList) {
		this.policyDetailList = policyDetailList;
	}

}
