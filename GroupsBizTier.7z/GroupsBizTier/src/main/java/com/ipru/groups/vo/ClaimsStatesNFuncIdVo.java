package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;



public class ClaimsStatesNFuncIdVo  implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<DropDownObjVO> dropDownStates;
	private String functionalityID;
	public List<DropDownObjVO> getDropDownStates() {
		return dropDownStates;
	}
	public void setDropDownStates(List<DropDownObjVO> dropDownStates) {
		this.dropDownStates = dropDownStates;
	}
	public String getFunctionalityID() {
		return functionalityID;
	}
	public void setFunctionalityID(String functionalityID) {
		this.functionalityID = functionalityID;
	}
	
	
}
