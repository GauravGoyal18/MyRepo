package com.ipru.groups.enums;

public enum ClaimsEnum {
	
	employeeId,
	employeeName,
	claimEventDate,
	commutationPercentage,
	annuityPercentage,
	panName,
	employeeEmailId_1,
	employeeEmailId_2,
	gratuityApplicable,
	claimCause,
	mobileNumber,
	
	beneficiaryDOB,
	bankAccountNumber,
	areaOrStreet,
	companyOrBuildingName,
	bankName,
	relation,
	appointeeName,
	landMark,
	flatOrUnitNumber,
	IFSCcode,
	pinCord,
	share,
	city,
	states,
	beneficiaryName;
	
	
}
