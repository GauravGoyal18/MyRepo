package com.ipru.groups.security.po;

public class LDAPUserDetail {
	private boolean isValidUser;
	private String validationMechanism;
	private String errorCode;
	private String firstLoginStatus;
	private Boolean accountLocked;
	private Boolean accountExpired;
	//Added By Rajvinder for Company, department
	private String companyName; 
	private String department;
	//added by Rajvinder for PREM Ack - LOGGEDIN USER NAME
	private String givenName;
	private String displayName;

	public String getValidationMechanism() {
		return validationMechanism;
	}

	public void setValidationMechanism(String validationMechanism) {
		this.validationMechanism = validationMechanism;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getFirstLoginStatus() {
		return firstLoginStatus;
	}

	public void setFirstLoginStatus(String firstLoginStatus) {
		this.firstLoginStatus = firstLoginStatus;
	}

	public Boolean getAccountLocked() {
		return accountLocked;
	}

	public void setAccountLocked(Boolean accountLocked) {
		this.accountLocked = accountLocked;
	}

	public Boolean getAccountExpired() {
		return accountExpired;
	}

	public void setAccountExpired(Boolean accountExpired) {
		this.accountExpired = accountExpired;
	}

	public boolean isValidUser() {
		return isValidUser;
	}

	public void setValidUser(boolean isValidUser) {
		this.isValidUser = isValidUser;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
}
