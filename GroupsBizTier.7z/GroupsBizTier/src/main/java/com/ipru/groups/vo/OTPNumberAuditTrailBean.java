package com.ipru.groups.vo;

import java.io.Serializable;
import java.sql.Timestamp;


public class OTPNumberAuditTrailBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long transactionId = 0;
	private String sourceFunctionality = "";
	private String otpNumber = "";
	private String otpNumberEntered = "";
	private Timestamp otpEnteredDate = null;

	public String getSourceFunctionality() {
		return sourceFunctionality;
	}

	public void setSourceFunctionality(String sourceFunctionality) {
		this.sourceFunctionality = sourceFunctionality;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public String getOtpNumber() {
		return otpNumber;
	}

	public void setOtpNumber(String otpNumber) {
		this.otpNumber = otpNumber;
	}

	public String getOtpNumberEntered() {
		return otpNumberEntered;
	}

	public void setOtpNumberEntered(String otpNumberEntered) {
		this.otpNumberEntered = otpNumberEntered;
	}

	public Timestamp getOtpEnteredDate() {
		return otpEnteredDate;
	}

	public void setOtpEnteredDate(Timestamp otpEnteredDate) {
		this.otpEnteredDate = otpEnteredDate;
	}

}
