package com.ipru.groups.enums;

public enum NomineeUpdateMandateEnum {

	nomineeUpdateMandateEnum1("beneficaryName"),
	nomineeUpdateMandateEnum2("dob"),
	nomineeUpdateMandateEnum3("relation"),
	nomineeUpdateMandateEnum4("gender"),
	nomineeUpdateMandateEnum5("share"),
	nomineeUpdateMandateEnum6("beneficaryLastName");
	
	private final String name;       

    private NomineeUpdateMandateEnum(String s) {
        name = s;
    }

    public boolean equalsName(String otherName) {
        // (otherName == null) check is not needed because name.equals(null) returns false 
        return name.equals(otherName);
    }

    public String toString() {
       return this.name;
    }
}
