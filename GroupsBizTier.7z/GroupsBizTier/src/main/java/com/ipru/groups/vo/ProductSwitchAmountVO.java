package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class ProductSwitchAmountVO extends GroupsBaseVO {

	private static final long serialVersionUID = 1L;
	private Long id;
	private String productCode;
	private String minSwitchAmount;
	private String maxSwitchAmount;
	

	public ProductSwitchAmountVO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getProductCode() {
		return productCode;
	}


	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}


	public String getMinSwitchAmount() {
		return minSwitchAmount;
	}


	public void setMinSwitchAmount(String minSwitchAmount) {
		this.minSwitchAmount = minSwitchAmount;
	}


	public String getMaxSwitchAmount() {
		return maxSwitchAmount;
	}


	public void setMaxSwitchAmount(String maxSwitchAmount) {
		this.maxSwitchAmount = maxSwitchAmount;
	}



	
}
