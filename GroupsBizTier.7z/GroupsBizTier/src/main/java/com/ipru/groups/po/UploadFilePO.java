package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;

public class UploadFilePO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long docId;
	private String documentName;
	private String policyNo;
	private String clientId;
	private String role;
	private String moduleType;
	private String docName;
	private long docSize;
	private String contentType;
	private String errorMsg;
	private String docPath;
	private String docFileType;
	private Date docUploadDate;
	private Date docClosureDate;
	private Date docPurgeDate;
	private String uploadType;
	private String uploadSource;
	private String uploadStatus;
	private long readFlagCounter;
	private Date lastUpdateDate;
	private long requestId;
	private String functionality;

	public UploadFilePO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public UploadFilePO(long docId, String policyNo, String clientId, String role, String moduleType, String docName, long docSize, String contentType, String errorMsg, String docPath, String docFileType, Date docUploadDate, Date docClosureDate, Date docPurgeDate, String uploadType, String uploadSource, String uploadStatus, long readFlagCounter, Date lastUpdateDate, long requestId, String functionality) {
		super();
		this.docId = docId;
		this.policyNo = policyNo;
		this.clientId = clientId;
		this.role = role;
		this.moduleType = moduleType;
		this.docName = docName;
		this.docSize = docSize;
		this.contentType = contentType;
		this.errorMsg = errorMsg;
		this.docPath = docPath;
		this.docFileType = docFileType;
		this.docUploadDate = docUploadDate;
		this.docClosureDate = docClosureDate;
		this.docPurgeDate = docPurgeDate;
		this.uploadType = uploadType;
		this.uploadSource = uploadSource;
		this.uploadStatus = uploadStatus;
		this.readFlagCounter = readFlagCounter;
		this.lastUpdateDate = lastUpdateDate;
		this.requestId = requestId;
		this.functionality = functionality;
	}

	public long getDocId() {
		return docId;
	}

	public void setDocId(long docId) {
		this.docId = docId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getModuleType() {
		return moduleType;
	}

	public void setModuleType(String moduleType) {
		this.moduleType = moduleType;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getDocPath() {
		return docPath;
	}

	public void setDocPath(String docPath) {
		this.docPath = docPath;
	}

	public String getDocFileType() {
		return docFileType;
	}

	public void setDocFileType(String docFileType) {
		this.docFileType = docFileType;
	}

	public Date getDocUploadDate() {
		return docUploadDate;
	}

	public void setDocUploadDate(Date docUploadDate) {
		this.docUploadDate = docUploadDate;
	}

	public Date getDocClosureDate() {
		return docClosureDate;
	}

	public void setDocClosureDate(Date docClosureDate) {
		this.docClosureDate = docClosureDate;
	}

	public Date getDocPurgeDate() {
		return docPurgeDate;
	}

	public void setDocPurgeDate(Date docPurgeDate) {
		this.docPurgeDate = docPurgeDate;
	}

	public String getUploadType() {
		return uploadType;
	}

	public void setUploadType(String uploadType) {
		this.uploadType = uploadType;
	}

	public String getUploadSource() {
		return uploadSource;
	}

	public void setUploadSource(String uploadSource) {
		this.uploadSource = uploadSource;
	}

	public String getUploadStatus() {
		return uploadStatus;
	}

	public void setUploadStatus(String uploadStatus) {
		this.uploadStatus = uploadStatus;
	}

	public long getReadFlagCounter() {
		return readFlagCounter;
	}

	public void setReadFlagCounter(long readFlagCounter) {
		this.readFlagCounter = readFlagCounter;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public long getDocSize() {
		return docSize;
	}

	public void setDocSize(long docSize) {
		this.docSize = docSize;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getFunctionality() {
		return functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}

	@Override
	public String toString() {
		return "UploadFilePO [docId=" + docId + ", documentName="
				+ documentName + ", policyNo=" + policyNo + ", clientId="
				+ clientId + ", role=" + role + ", moduleType=" + moduleType
				+ ", docName=" + docName + ", docSize=" + docSize
				+ ", contentType=" + contentType + ", errorMsg=" + errorMsg
				+ ", docPath=" + docPath + ", docFileType=" + docFileType
				+ ", docUploadDate=" + docUploadDate + ", docClosureDate="
				+ docClosureDate + ", docPurgeDate=" + docPurgeDate
				+ ", uploadType=" + uploadType + ", uploadSource="
				+ uploadSource + ", uploadStatus=" + uploadStatus
				+ ", readFlagCounter=" + readFlagCounter + ", lastUpdateDate="
				+ lastUpdateDate + ", requestId=" + requestId
				+ ", functionality=" + functionality + "]";
	}

}
