package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

public class ServiceWebPageSubmitRequestPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNumber;
	private ServiceWebPageMenuPO selectedMenu;
	private String detailOfRequest;
	private String clientId;
	private List<UploadFilePO> uploadFileList;
	private String screenName;

	public ServiceWebPageSubmitRequestPO() {
		super();
	}

	public ServiceWebPageSubmitRequestPO(String policyNumber, ServiceWebPageMenuPO selectedMenu, String detailOfRequest, String clientId, List<UploadFilePO> uploadFileList, String screenName) {
		super();
		this.policyNumber = policyNumber;
		this.selectedMenu = selectedMenu;
		this.detailOfRequest = detailOfRequest;
		this.clientId = clientId;
		this.uploadFileList = uploadFileList;
		this.screenName = screenName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public ServiceWebPageMenuPO getSelectedMenu() {
		return selectedMenu;
	}

	public void setSelectedMenu(ServiceWebPageMenuPO selectedMenu) {
		this.selectedMenu = selectedMenu;
	}

	public String getDetailOfRequest() {
		return detailOfRequest;
	}

	public void setDetailOfRequest(String detailOfRequest) {
		this.detailOfRequest = detailOfRequest;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public List<UploadFilePO> getUploadFileList() {
		return uploadFileList;
	}

	public void setUploadFileList(List<UploadFilePO> uploadFileList) {
		this.uploadFileList = uploadFileList;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	@Override
	public String toString() {
		return "ServiceWebPageSubmitRequestPO [policyNumber=" + policyNumber + ", selectedMenu=" + selectedMenu + ", detailOfRequest=" + detailOfRequest + ", clientId=" + clientId
				+ ", uploadFileList=" + uploadFileList + ", screenName=" + screenName + "]";
	}

}
