package com.ipru.groups.po;

import java.io.Serializable;

public class AnnuityRequestPO extends GroupsBasePo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	
}
