package com.ipru.groups.vo;

import java.io.Serializable;

public class CoiSumAssuredVO implements Serializable{
	private String output;
	private String totalSumAssured;
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	public String getTotalSumAssured() {
		return totalSumAssured;
	}
	public void setTotalSumAssured(String totalSumAssured) {
		this.totalSumAssured = totalSumAssured;
	}
	@Override
	public String toString() {
		return "CoiSumAssuredVO [output=" + output + ", totalSumAssured=" + totalSumAssured + "]";
	}
	

}
