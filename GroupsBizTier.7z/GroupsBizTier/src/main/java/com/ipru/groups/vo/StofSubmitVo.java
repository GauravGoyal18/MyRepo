package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;

public class StofSubmitVo implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long switchFundDetailsId;
	private String fromFundCode;
	private String toFundCode;
	private String switchType;
	private String frequency;
	private String numberOfTransfer;
	private String fundFromName;
	private String fundToName;
	private String nav;
	private String unit;
	private String ammount;
	private String toUnit;
	private String toAmount;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;

	/* private String totalValue; */
	/*
	 * private String fromNAV; private String fromUnit; private String
	 * fromAmount;
	 */
	// private String toNAV;

	/*
	 * private String remainingFromUnit; private String remainingFromAmount;
	 * private String remainingToUnit; private String remainingToAmount;
	 */

	StofSubmitTransactionVO stofSubmitTransactionVO;

	public String getSwitchType() {
		return switchType;
	}

	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}

	public String getFundFromName() {
		return fundFromName;
	}

	public void setFundFromName(String fundFromName) {
		this.fundFromName = fundFromName;
	}

	public String getFundToName() {
		return fundToName;
	}

	public void setFundToName(String fundToName) {
		this.fundToName = fundToName;
	}

	public StofSubmitTransactionVO getStofSubmitTransactionVO() {
		return stofSubmitTransactionVO;
	}

	public void setStofSubmitTransactionVO(StofSubmitTransactionVO stofSubmitTransactionVO) {
		this.stofSubmitTransactionVO = stofSubmitTransactionVO;
	}

	public Long getSwitchFundDetailsId() {
		return switchFundDetailsId;
	}

	public void setSwitchFundDetailsId(Long switchFundDetailsId) {
		this.switchFundDetailsId = switchFundDetailsId;
	}

	public String getFromFundCode() {
		return fromFundCode;
	}

	public void setFromFundCode(String fromFundCode) {
		this.fromFundCode = fromFundCode;
	}

	public String getToFundCode() {
		return toFundCode;
	}

	public void setToFundCode(String toFundCode) {
		this.toFundCode = toFundCode;
	}

	public String getNav() {
		return nav;
	}

	public void setNav(String nav) {
		this.nav = nav;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getAmmount() {
		return ammount;
	}

	public void setAmmount(String ammount) {
		this.ammount = ammount;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getNumberOfTransfer() {
		return numberOfTransfer;
	}

	public void setNumberOfTransfer(String numberOfTransfer) {
		this.numberOfTransfer = numberOfTransfer;
	}

	public String getToUnit() {
		return toUnit;
	}

	public void setToUnit(String toUnit) {
		this.toUnit = toUnit;
	}

	public String getToAmount() {
		return toAmount;
	}

	public void setToAmount(String toAmount) {
		this.toAmount = toAmount;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

}