package com.ipru.groups.vo;

import java.util.Date;

public class ClaimRequestIBMVO extends GroupsBaseVO {

	private static final long serialVersionUID = 1L;
	
	private long requestId;
	private Long claimId;
	private String employeeId;
	private String typeOfClaim;
	private String gratuityApplicable;
	private String commutationPer;
	private String annuityPer;
	private String empName;
	private String beneficiary;
	private String beneficiaryPayMode;
	private String ifscCode;
	private String micrCode;
	private String bankName;
	private String bankAccountNo;
	private String address;
	private Date requestedTime;


	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public Long getClaimId() {
		return claimId;
	}

	public void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getTypeOfClaim() {
		return typeOfClaim;
	}

	public void setTypeOfClaim(String typeOfClaim) {
		this.typeOfClaim = typeOfClaim;
	}

	public String getGratuityApplicable() {
		return gratuityApplicable;
	}

	public void setGratuityApplicable(String gratuityApplicable) {
		this.gratuityApplicable = gratuityApplicable;
	}

	public String getCommutationPer() {
		return commutationPer;
	}

	public void setCommutationPer(String commutationPer) {
		this.commutationPer = commutationPer;
	}

	public String getAnnuityPer() {
		return annuityPer;
	}

	public void setAnnuityPer(String annuityPer) {
		this.annuityPer = annuityPer;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(String beneficiary) {
		this.beneficiary = beneficiary;
	}

	public String getBeneficiaryPayMode() {
		return beneficiaryPayMode;
	}

	public void setBeneficiaryPayMode(String beneficiaryPayMode) {
		this.beneficiaryPayMode = beneficiaryPayMode;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getRequestedTime() {
		return requestedTime;
	}

	public void setRequestedTime(Date requestedTime) {
		this.requestedTime = requestedTime;
	}

	@Override
	public String toString() {
		return "ClaimRequestIBMVO [requestId=" + requestId + ", claimId="
				+ claimId + ", employeeId=" + employeeId + ", typeOfClaim="
				+ typeOfClaim + ", gratuityApplicable=" + gratuityApplicable
				+ ", commutationPer=" + commutationPer + ", annuityPer="
				+ annuityPer + ", empName=" + empName + ", beneficiary="
				+ beneficiary + ", beneficiaryPayMode=" + beneficiaryPayMode
				+ ", ifscCode=" + ifscCode + ", micrCode=" + micrCode
				+ ", bankName=" + bankName + ", bankAccountNo=" + bankAccountNo
				+ ", address=" + address + ", requestedTime=" + requestedTime
				+ "]";
	}
	
	

}
