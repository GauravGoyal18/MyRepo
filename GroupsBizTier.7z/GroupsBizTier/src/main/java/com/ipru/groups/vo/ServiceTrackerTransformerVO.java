package com.ipru.groups.vo;

import java.util.Date;

public class ServiceTrackerTransformerVO extends GroupsBaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long requestId;
	private String functionalityName;
	private Date requestTime;
	private String status;
	private Date updtTime;
	
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	public String getFunctionalityName() {
		return functionalityName;
	}
	public void setFunctionalityName(String functionalityName) {
		this.functionalityName = functionalityName;
	}
	public Date getRequestTime() {
		return requestTime;
	}
	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getUpdtTime() {
		return updtTime;
	}
	public void setUpdtTime(Date updtTime) {
		this.updtTime = updtTime;
	}
	
	
	
	

}
