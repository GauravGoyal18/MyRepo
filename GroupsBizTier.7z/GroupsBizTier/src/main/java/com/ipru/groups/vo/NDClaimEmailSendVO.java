package com.ipru.groups.vo;

public class NDClaimEmailSendVO {
	
	private String emailID;
	private String CLAIMEXCLID;
	private String trycountsch;
	private String policyNo;
	private String empyoleeName;
	private String currntDate;


	
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getCLAIMEXCLID() {
		return CLAIMEXCLID;
	}
	public void setCLAIMEXCLID(String cLAIMEXCLID) {
		CLAIMEXCLID = cLAIMEXCLID;
	}
	
	
	public String getTrycountsch() {
		return trycountsch;
	}
	public void setTrycountsch(String trycountsch) {
		this.trycountsch = trycountsch;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getEmpyoleeName() {
		return empyoleeName;
	}
	public void setEmpyoleeName(String empyoleeName) {
		this.empyoleeName = empyoleeName;
	}
	public String getCurrntDate() {
		return currntDate;
	}
	public void setCurrntDate(String currntDate) {
		this.currntDate = currntDate;
	}
	@Override
	public String toString() {
		return "NDClaimEmailSendVO [emailID=" + emailID + ", CLAIMEXCLID="
				+ CLAIMEXCLID + ", trycountsch=" + trycountsch + ", policyNo="
				+ policyNo + ", empyoleeName=" + empyoleeName + ", currntDate="
				+ currntDate + "]";
	}
	

}
