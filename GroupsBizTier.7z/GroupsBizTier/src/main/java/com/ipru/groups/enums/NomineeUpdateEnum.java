package com.ipru.groups.enums;

public enum NomineeUpdateEnum {

	beneficaryName, dob, relation, gender, beneficaryLastName, share;

}
