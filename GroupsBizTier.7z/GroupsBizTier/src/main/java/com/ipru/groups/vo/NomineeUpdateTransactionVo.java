package com.ipru.groups.vo;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NomineeUpdateTransactionVo extends GroupsBaseVO implements ISpaarcCallLog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long customerTrxnId;
	private Set<NomineeUpdateSubmitVo> nomineeUpdateSubmitVoSet = new HashSet<NomineeUpdateSubmitVo>(0);
	//private List<NomineeUpdateSubmitVo> nomineeUpdateSubmitVoList;
	private Date currentDate;
	private FunctionalityMasterVO functionality;

/*	public List<NomineeUpdateSubmitVo> getNomineeUpdateSubmitVoList() {
		return nomineeUpdateSubmitVoList;
	}

	public void setNomineeUpdateSubmitVoList(List<NomineeUpdateSubmitVo> nomineeUpdateSubmitVoList) {
		this.nomineeUpdateSubmitVoList = nomineeUpdateSubmitVoList;
	}
*/
	public Set<NomineeUpdateSubmitVo> getNomineeUpdateSubmitVoSet() {
		return nomineeUpdateSubmitVoSet;
	}

	public void setNomineeUpdateSubmitVoSet(Set<NomineeUpdateSubmitVo> nomineeUpdateSubmitVoSet) {
		this.nomineeUpdateSubmitVoSet = nomineeUpdateSubmitVoSet;
	}

	public long getCustomerTrxnId() {
		return customerTrxnId;
	}

	public void setCustomerTrxnId(long customerTrxnId) {
		this.customerTrxnId = customerTrxnId;
	}

	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	@Override
	public String getFunctionalityReqId() {
		return String.valueOf(getCustomerTrxnId());
	}

	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}

	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}

	@Override
	public String toString() {
		return "NomineeUpdateTransactionVo [customerTrxnId=" + customerTrxnId + ", nomineeUpdateSubmitVoSet=" + nomineeUpdateSubmitVoSet + ", currentDate=" + currentDate + ", functionality="
				+ functionality + "]";
	}

}
