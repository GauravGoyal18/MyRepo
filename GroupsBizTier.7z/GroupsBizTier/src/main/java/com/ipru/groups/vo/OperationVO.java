package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class OperationVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long opId;
	private String opShowEdit;
	private String opShowDisabled;
	private String opShow;
	private String opShowSubmit;
	private String opMandatory;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;

	public OperationVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OperationVO(long opId, String opShowEdit, String opShowDisabled, String opShow, String opShowSubmit, String opMandatory, String createdBy, Date createdDate, String updatedBy, Date updatedDate) {
		super();
		this.opId = opId;
		this.opShowEdit = opShowEdit;
		this.opShowDisabled = opShowDisabled;
		this.opShow = opShow;
		this.opShowSubmit = opShowSubmit;
		this.opMandatory = opMandatory;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.updatedBy = updatedBy;
		this.updatedDate = updatedDate;
	}

	public long getOpId() {
		return opId;
	}

	public void setOpId(long opId) {
		this.opId = opId;
	}

	public String getOpShowEdit() {
		return opShowEdit;
	}

	public void setOpShowEdit(String opShowEdit) {
		this.opShowEdit = opShowEdit;
	}

	public String getOpShowDisabled() {
		return opShowDisabled;
	}

	public void setOpShowDisabled(String opShowDisabled) {
		this.opShowDisabled = opShowDisabled;
	}

	public String getOpShow() {
		return opShow;
	}

	public void setOpShow(String opShow) {
		this.opShow = opShow;
	}

	public String getOpShowSubmit() {
		return opShowSubmit;
	}

	public void setOpShowSubmit(String opShowSubmit) {
		this.opShowSubmit = opShowSubmit;
	}

	public String getOpMandatory() {
		return opMandatory;
	}

	public void setOpMandatory(String opMandatory) {
		this.opMandatory = opMandatory;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "OperationVO [opId=" + opId + ", opShowEdit=" + opShowEdit + ", opShowDisabled=" + opShowDisabled + ", opShow=" + opShow + ", opShowSubmit=" + opShowSubmit + ", opMandatory="
				+ opMandatory + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + "]";
	}

}
