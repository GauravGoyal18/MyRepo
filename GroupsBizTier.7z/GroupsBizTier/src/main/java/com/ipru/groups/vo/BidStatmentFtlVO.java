package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class BidStatmentFtlVO implements Serializable {

	private String policyNo;
	private String clientName;
	List<BidStatementResponseVO> bidResponseList;
	List<BrokerBIDResponseVO> brokerbidResponseList;
	private String renewalNo;
	private String location;
	private String statementDate;
	private Date currentDate;

	public Date getCurrentDate() {
		return currentDate;
	}

	public List<BrokerBIDResponseVO> getBrokerbidResponseList() {
		return brokerbidResponseList;
	}

	public void setBrokerbidResponseList(List<BrokerBIDResponseVO> brokerbidResponseList) {
		this.brokerbidResponseList = brokerbidResponseList;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	public String getStatementDate() {
		return statementDate;
	}

	public void setStatementDate(String statementDate) {
		this.statementDate = statementDate;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public String getRenewalNo() {
		return renewalNo;
	}

	public void setRenewalNo(String renewalNo) {
		this.renewalNo = renewalNo;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public List<BidStatementResponseVO> getBidResponseList() {
		return bidResponseList;
	}

	public void setBidResponseList(List<BidStatementResponseVO> bidResponseList) {
		this.bidResponseList = bidResponseList;
	}

	@Override
	public String toString() {
		return "BidStatmentFtlVO [policyNo=" + policyNo + ", clientName=" + clientName + ", bidResponseList=" + bidResponseList + ", renewalNo=" + renewalNo + ", location=" + location
				+ ", statementDate=" + statementDate + ", currentDate=" + currentDate + "]";
	}

}
