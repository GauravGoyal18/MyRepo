package com.ipru.groups.fundPerformance.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.codec.binary.Base64;

import com.ipru.IPruException;
import com.ipru.groups.client.ProductDetailsClient;
import com.ipru.groups.service.WebserviceInvoke;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.ProductDetailsVO;
import com.ipru.groups.widget.service.GroupsBaseService;
import com.tcs.logger.FLogger;
import com.tcs.service.BaseService;
import com.tcs.wsconfig.wsclient.WebServiceClient;
import com.tcs.wsconfig.wsclient.WebserviceClientConfigurator;

public class FundPerformanceServiceImpl extends GroupsBaseService {

	private static final String CLASS_NAME = FundPerformanceServiceImpl.class.getName();

	public ProductDetailsVO fetchProductDetailsFromPolicy(String policyNo) throws NullPointerException, Exception {
		FLogger.info("FundPerformanceLogger", "FundPerformanceServiceImpl", "fetchProductFromPolicy", "Method Start");

		// Call Webservice
		ProductDetailsVO productDetails = ProductDetailsClient.fetchProductDetails(policyNo);

		FLogger.info("FundPerformanceLogger", "FundPerformanceServiceImpl", "fetchProductFromPolicy", "Method End");
		return productDetails;
	}

	@SuppressWarnings("static-access")
	public String getFundsDetailJsonOld(List<String> fundCode) throws Exception {
		FLogger.info("FundPerformanceLogger", "FundPerformance ", "getFundsDetailJson", "getFundsDetailJson method start ");
		String response;

		// Will be changed
//		Properties properties = MasterPropertiesFileLoader.CONSTANT_DIGITAL_WEB_SERVICE;
		//String fundPerformannceURL = properties.getProperty("DIGITAL_FUND_PERFORMANCE");
		String fundPerformannceURL = "http://10.16.13.113:7727/digi_digital/Fund-Performance/groups-fund-performance.htm?fundCode=";
		StringBuffer urlHit = new StringBuffer(fundPerformannceURL);

		StringBuffer fundListEncoded = new StringBuffer();
		StringBuffer dateParamAppend = new StringBuffer();

		Iterator it = fundCode.iterator();
		while (it.hasNext()) {
			// urlHit.append(it.next().toString());

			fundListEncoded.append(it.next().toString());

			if (it.hasNext()) {
				fundListEncoded.append(",");
			}
		}
		byte[] encoded = Base64.encodeBase64(fundListEncoded.toString().getBytes());
		dateParamAppend.append(new String(encoded));
		dateParamAppend.append("&startDate=");
		Date endDate = new Date();
		Calendar cal = new GregorianCalendar();
		cal.setTime(endDate);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		endDate = cal.getTime();
		cal.add(Calendar.DAY_OF_MONTH, -6);
		Date startDate = cal.getTime();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		dateParamAppend.append(new String(Base64.encodeBase64(dateFormat.format(startDate).toString().toUpperCase().getBytes())));
		// fundListEncoded.append(dateFormat.format(endDate).toString().toUpperCase());
		dateParamAppend.append("&endDate=");
		dateParamAppend.append(new String(Base64.encodeBase64(dateFormat.format(endDate).toString().toUpperCase().getBytes())));
		// fundListEncoded.append(dateFormat.format(currentDate).toString().toUpperCase());
		urlHit.append(dateParamAppend.toString());
		URL url = new URL(urlHit.toString());
		// URL url = new URL(urlHit.toString());
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Accept", "application/json");

		if (conn.getResponseCode() != 200) {
			throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
		}

		BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

		
		while ((response = br.readLine()) != null) {
			
			break;
		}
		conn.disconnect();
		FLogger.info("FundPerformanceLogger", "FundPerformance ", "getFundsDetailJson", "getFundsDetailJson method end ");
		return response;
		
	}
	
	@SuppressWarnings("static-access")
	public String getFundsDetailJson(List<String> fundCode) throws Exception {

		FLogger.info("FundPerformanceLogger", "FundPerformance ", "getFundsDetailJson", "getFundsDetailJson method sart ");
		
		FLogger.debug("FundPerformanceLogger", "FundPerformanceServiceImpl", "getFundsDetaitChart", "fundCode : "+fundCode);
		
		String response = null;
		
		Map<String, String> map = new HashMap<String, String>();

		StringBuffer fundListEncoded = new StringBuffer();

		Iterator it = fundCode.iterator();
		while (it.hasNext()) {

			fundListEncoded.append(it.next().toString());

			if (it.hasNext()) {
				fundListEncoded.append(",");
			}
		}
		byte[] encoded = Base64.encodeBase64(fundListEncoded.toString().getBytes());
		map.put("fundCode", new String(encoded));
		
		Date endDate = new Date();
		Calendar cal = new GregorianCalendar();
		cal.setTime(endDate);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		endDate = cal.getTime();
		cal.add(Calendar.DAY_OF_MONTH, -6);
		Date startDate = cal.getTime();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		
		map.put("startDate", (new String(Base64.encodeBase64(dateFormat.format(startDate).toString().toUpperCase().getBytes()))));
		
		map.put("endDate", (new String(Base64.encodeBase64(dateFormat.format(endDate).toString().toUpperCase().getBytes()))));
		
		//Call Webservice
		response = WebserviceInvoke.getInstance().fetchFundsDetailJson(map,"FundPerformanceLogger");
		
		FLogger.info("FundPerformanceLogger", "FundPerformance ", "getFundsDetailJson", "getFundsDetailJson method end ");
		return	response;
	
	}

	public String getFundsDetaitChartOld(String fundCode) throws Exception {
		
		try{
			FLogger.info("FundPerformanceLogger", "FundPerformance ", "getFundsDetailJson", "getFundsDetailJson method sart ");
			
			FLogger.debug("FundPerformanceLogger", "FundPerformanceServiceImpl", "getFundsDetaitChart", "fundCode : "+fundCode);
			String response;
	
			// Will be changed
			//Properties properties = MasterPropertiesFileLoader.CONSTANT_DIGITAL_WEB_SERVICE;
			//String fundPerformannceURL = properties.getProperty("DIGITAL_FUND_PERFORMANCE_CHART");
			
			String fundPerformannceURL = "https://onlinelifeinsurance.iciciprulife.com/digital/Fund-Performance/funds-product-performance.htm?fundCode=";
			
			FLogger.debug("FundPerformanceLogger", "FundPerformanceServiceImpl", "getFundsDetaitChart", "fundPerformannceURL : "+fundPerformannceURL);
			StringBuffer urlHit = new StringBuffer(fundPerformannceURL);
			/*
			 * StringBuffer urlHit = new StringBuffer(
			 * "https://onlinelifeinsurance.iciciprulife.com/digital/Fund-Performance/funds-product-performance.htm?fundCode="
			 * );
			 */
	
			String fundListEncoded = fundCode;
			StringBuffer dateParamAppend = new StringBuffer();
	
			// byte[] encoded = Base64.encodeBase64(fundListEncoded.getBytes());
	
			dateParamAppend.append(fundListEncoded);
			dateParamAppend.append("&startDate=");
			Date currentDate = new Date();
			Calendar cal = new GregorianCalendar();
			cal.setTime(currentDate);
			cal.add(Calendar.DAY_OF_MONTH, -1);
			currentDate = cal.getTime();
			cal.add(Calendar.DAY_OF_MONTH, -6);
			Date endDate = cal.getTime();
	
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
			// dateParamAppend.append(new
			// String(Base64.encodeBase64(dateFormat.format(endDate).toString().toUpperCase().getBytes())));
			dateParamAppend.append((dateFormat.format(endDate).toString().toUpperCase()));
			// fundListEncoded.append(dateFormat.format(endDate).toString().toUpperCase());
			dateParamAppend.append("&endDate=");
			// dateParamAppend.append(new
			// String(Base64.encodeBase64(dateFormat.format(currentDate).toString().toUpperCase().getBytes())));
			// fundListEncoded.append(dateFormat.format(currentDate).toString().toUpperCase());
			dateParamAppend.append(dateFormat.format(currentDate).toString().toUpperCase());
			
			
			FLogger.debug("FundPerformanceLogger", "FundPerformanceServiceImpl", "getFundsDetaitChart", "dateParamAppend : "+dateParamAppend.toString());
			urlHit.append(dateParamAppend.toString());
			
			FLogger.debug("FundPerformanceLogger", "FundPerformanceServiceImpl", "getFundsDetaitChart", "urlHit : "+urlHit.toString());
			URL url = new URL(urlHit.toString());
			// URL url = new URL(urlHit.toString());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			
			if (conn.getResponseCode() != 200) {
				FLogger.info("FundPerformanceLogger", "FundPerformanceServiceImpl", "getFundsDetaitChart", "conn.getResponseCode() != 200 : "+conn.getResponseCode());
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}
	
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
	
			
			while ((response = br.readLine()) != null) {
				
				break;
			}
			conn.disconnect();
			FLogger.info("FundPerformanceLogger", "FundPerformance ", "getFundsDetailJson", "getFundsDetailJson method end ");
			return response;
		}
		catch(RuntimeException e){
			FLogger.error("FundPerformanceLogger", "FundPerformanceServiceImpl", "getFundsDetaitChart", "RuntimeException Occurred ", e);
			throw new IPruException("Error", "GRPFP03", "Run Time Exception");
		}
		catch(Exception e){
			FLogger.error("FundPerformanceLogger", "FundPerformanceServiceImpl", "getFundsDetaitChart", "Exception Occurred ", e);
			throw new IPruException("Error", "GRPFP03", "Exception");
		}
	}
	
	public String getFundsDetaitChart(String fundCode) throws Exception {
		FLogger.info("FundPerformanceLogger", "FundPerformance ", "getFundsDetailJson", "getFundsDetailJson method sart ");
		
		FLogger.debug("FundPerformanceLogger", "FundPerformanceServiceImpl", "getFundsDetaitChart", "fundCode : "+fundCode);
		
		String response = null;
		
		Date currentDate = new Date();
		Calendar cal = new GregorianCalendar();
		cal.setTime(currentDate);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		currentDate = cal.getTime();
		cal.add(Calendar.DAY_OF_MONTH, -6);
		Date endDate = cal.getTime();
		
		//Call Webservice
		response = WebserviceInvoke.getInstance().fetchFundsDetailChart(fundCode,currentDate,endDate,"FundPerformanceLogger");
		
		FLogger.info("FundPerformanceLogger", "FundPerformance ", "getFundsDetailJson", "getFundsDetailJson method end ");
		return	response;
	}
	
/*	public static void main(String[] args) throws Exception{
		
		new WebserviceClientConfigurator().reloadWsConfig();
		List<String> list = new ArrayList<String>();
		list.add("MMAF");
		
		//System.out.println(new FundPerformanceServiceImpl().getFundsDetailJson(list));
		
//		//System.out.println(new FundPerformanceServiceImpl().getFundsDetaitChartOld("MMAF"));
	}*/

}
