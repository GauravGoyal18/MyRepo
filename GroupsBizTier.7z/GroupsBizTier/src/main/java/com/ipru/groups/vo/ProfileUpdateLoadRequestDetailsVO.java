package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.ipru.groups.po.RoleScreenAccessMappingPO;

public class ProfileUpdateLoadRequestDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*private PolicyDetailsPO policyDetails;*/
	private List<RoleScreenAccessMappingPO> accessMappingList;
	private Map<String, FieldAccessMappingVO> fieldAccessMappingMap;
	
	private List<CompanyAddressChangeVO> profileCompanyAddressVOList;
	
	private List<ContactPersonChangeVO> profileContactPersonVOList;
	
	private List<AuthoritySignatoryChangeVO> profileAuthoritySignatoryVOList;




	public List<AuthoritySignatoryChangeVO> getProfileAuthoritySignatoryVOList() {
		return profileAuthoritySignatoryVOList;
	}



	public void setProfileAuthoritySignatoryVOList(
			List<AuthoritySignatoryChangeVO> profileAuthoritySignatoryVOList) {
		this.profileAuthoritySignatoryVOList = profileAuthoritySignatoryVOList;
	}



	public ProfileUpdateLoadRequestDetailsVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Map<String, FieldAccessMappingVO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}



	public void setFieldAccessMappingMap(
			Map<String, FieldAccessMappingVO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}



	public void setAccessMappingList(
			List<RoleScreenAccessMappingPO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}



	public List<RoleScreenAccessMappingPO> getAccessMappingList() {
		return accessMappingList;
	}





	public List<CompanyAddressChangeVO> getProfileCompanyAddressVOList() {
		return profileCompanyAddressVOList;
	}



	public void setProfileCompanyAddressVOList(
			List<CompanyAddressChangeVO> profileCompanyAddressVOList) {
		this.profileCompanyAddressVOList = profileCompanyAddressVOList;
	}



	public List<ContactPersonChangeVO> getProfileContactPersonVOList() {
		return profileContactPersonVOList;
	}



	public void setProfileContactPersonVOList(
			List<ContactPersonChangeVO> profileContactPersonVOList) {
		this.profileContactPersonVOList = profileContactPersonVOList;
	}



	@Override
	public String toString() {
		return "ProfileUpdateLoadRequestDetailsVO [accessMappingList="
				+ accessMappingList + ", fieldAccessMappingMap="
				+ fieldAccessMappingMap + ", profileCompanyAddressVOList="
				+ profileCompanyAddressVOList + ", profileContactPersonVOList="
				+ profileContactPersonVOList
				+ ", profileAuthoritySignatoryVOList="
				+ profileAuthoritySignatoryVOList + "]";
	}





}
