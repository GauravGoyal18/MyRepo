package com.ipru.groups.po;

import java.util.Collection;

public class ClaimsApprovalShowPO extends GroupsBasePo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long transactionId;
	private Collection<ClaimsApprovalPO> claimApprovals;
	public Long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}
	public Collection<ClaimsApprovalPO> getClaimApprovals() {
		return claimApprovals;
	}
	public void setClaimApprovals(Collection<ClaimsApprovalPO> claimApprovals) {
		this.claimApprovals = claimApprovals;
	}
	
	
	
}
