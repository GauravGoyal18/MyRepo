package com.ipru.groups.po;

import java.util.List;

import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.tcs.web.po.BasePO;

public class NomineeUpdateLoadRequestPO extends BasePO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String clientId;
	private String policyNo;
	private String role;
	private String screenName;
	private List<RoleScreenAccessMappingVO> accessMappingList;
	private List<FieldAccessMappingVO> fieldAccessMappingList;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public List<RoleScreenAccessMappingVO> getAccessMappingList() {
		return accessMappingList;
	}

	public void setAccessMappingList(List<RoleScreenAccessMappingVO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}

	public List<FieldAccessMappingVO> getFieldAccessMappingList() {
		return fieldAccessMappingList;
	}

	public void setFieldAccessMappingList(List<FieldAccessMappingVO> fieldAccessMappingList) {
		this.fieldAccessMappingList = fieldAccessMappingList;
	}

	@Override
	public String toString() {
		return "NomineeUpdateLoadRequestPO [clientId=" + clientId + ", policyNo=" + policyNo + ", role=" + role + ", screenName=" + screenName + ", accessMappingList=" + accessMappingList
				+ ", fieldAccessMappingList=" + fieldAccessMappingList + "]";
	}

}
