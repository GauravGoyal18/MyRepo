package com.ipru.groups.po;


public class ClaimExcelDataPO  extends GroupsBasePo{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long claimExclId;
	private String type_of_claim;
	private String employee_id;
	private String employee_name;
	private String pan_Number;
	private String claim_event_date;
	private String member_Mob_number;
	private String member_Email_id1;
	private String member_Email_id2;
	private String net_Taxable_salary;
	private String equitable_tranfer;
	private String equitable_tranfer_to_whom;
	private String gratuity_Applicable;
	private String email_sch_flag;
	private String trycountEmailsch;
	private long customer_Trxn_Id;
	private String sysDate;
	private String functionalityId;
	
	public String getFunctionalityId() {
		return functionalityId;
	}
	public void setFunctionalityId(String functionalityId) {
		this.functionalityId = functionalityId;
	}
	public long getClaimExclId() {
		return claimExclId;
	}
	public void setClaimExclId(long claimExclId) {
		this.claimExclId = claimExclId;
	}
	public String getType_of_claim() {
		return type_of_claim;
	}
	public void setType_of_claim(String type_of_claim) {
		this.type_of_claim = type_of_claim;
	}
	public String getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getPan_Number() {
		return pan_Number;
	}
	public void setPan_Number(String pan_Number) {
		this.pan_Number = pan_Number;
	}
	public String getClaim_event_date() {
		return claim_event_date;
	}
	public void setClaim_event_date(String claim_event_date) {
		this.claim_event_date = claim_event_date;
	}
	public String getMember_Mob_number() {
		return member_Mob_number;
	}
	public void setMember_Mob_number(String member_Mob_number) {
		this.member_Mob_number = member_Mob_number;
	}
	public String getMember_Email_id1() {
		return member_Email_id1;
	}
	public void setMember_Email_id1(String member_Email_id1) {
		this.member_Email_id1 = member_Email_id1;
	}
	public String getMember_Email_id2() {
		return member_Email_id2;
	}
	public void setMember_Email_id2(String member_Email_id2) {
		this.member_Email_id2 = member_Email_id2;
	}
	public String getNet_Taxable_salary() {
		return net_Taxable_salary;
	}
	public void setNet_Taxable_salary(String net_Taxable_salary) {
		this.net_Taxable_salary = net_Taxable_salary;
	}
	public String getEquitable_tranfer() {
		return equitable_tranfer;
	}
	public void setEquitable_tranfer(String equitable_tranfer) {
		this.equitable_tranfer = equitable_tranfer;
	}
	public String getEquitable_tranfer_to_whom() {
		return equitable_tranfer_to_whom;
	}
	public void setEquitable_tranfer_to_whom(String equitable_tranfer_to_whom) {
		this.equitable_tranfer_to_whom = equitable_tranfer_to_whom;
	}
	public String getGratuity_Applicable() {
		return gratuity_Applicable;
	}
	public void setGratuity_Applicable(String gratuity_Applicable) {
		this.gratuity_Applicable = gratuity_Applicable;
	}
	public String getEmail_sch_flag() {
		return email_sch_flag;
	}
	public void setEmail_sch_flag(String email_sch_flag) {
		this.email_sch_flag = email_sch_flag;
	}
	public String getTrycountEmailsch() {
		return trycountEmailsch;
	}
	public void setTrycountEmailsch(String trycountEmailsch) {
		this.trycountEmailsch = trycountEmailsch;
	}
	public long getCustomer_Trxn_Id() {
		return customer_Trxn_Id;
	}
	public void setCustomer_Trxn_Id(long customer_Trxn_Id) {
		this.customer_Trxn_Id = customer_Trxn_Id;
	}
	public String getSysDate() {
		return sysDate;
	}
	public void setSysDate(String sysDate) {
		this.sysDate = sysDate;
	}
	@Override
	public String toString() {
		return "ClaimExcelDataPO [claimExclId=" + claimExclId
				+ ", type_of_claim=" + type_of_claim + ", employee_id="
				+ employee_id + ", employee_name=" + employee_name
				+ ", pan_Number=" + pan_Number + ", claim_event_date="
				+ claim_event_date + ", member_Mob_number=" + member_Mob_number
				+ ", member_Email_id1=" + member_Email_id1
				+ ", member_Email_id2=" + member_Email_id2
				+ ", net_Taxable_salary=" + net_Taxable_salary
				+ ", equitable_tranfer=" + equitable_tranfer
				+ ", equitable_tranfer_to_whom=" + equitable_tranfer_to_whom
				+ ", gratuity_Applicable=" + gratuity_Applicable
				+ ", email_sch_flag=" + email_sch_flag + ", trycountEmailsch="
				+ trycountEmailsch + ", customer_Trxn_Id=" + customer_Trxn_Id
				+ ", sysDate=" + sysDate + ", functionalityId="
				+ functionalityId + "]";
	}
	
	
	
	
	

}
