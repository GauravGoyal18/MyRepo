package com.ipru.groups.vo;

import java.io.Serializable;

import com.tcs.vo.BaseVO;

public class TrackerResponseVO extends BaseVO {
	private Long requestId;
	private String requestedDate;
	private Long spaarcId;
	private String status;
	private String functionality;
	private String toDate;
	private String fromDate;
	private String clientId;
	private String policyNo;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public String getRequestedDate() {
		return requestedDate;
	}

	public void setRequestedDate(String requestedDate) {
		this.requestedDate = requestedDate;
	}

	public Long getSpaarcId() {
		return spaarcId;
	}

	public void setSpaarcId(Long spaarcId) {
		this.spaarcId = spaarcId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFunctionality() {
		return functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	@Override
	public String toString() {
		return "TrackerResponseVO [requestId=" + requestId + ", requestedDate=" + requestedDate + ", spaarcId=" + spaarcId + ", status=" + status + ", functionality=" + functionality + ", toDate="
				+ toDate + ", fromDate=" + fromDate + ", clientId=" + clientId + ", policyNo=" + policyNo + "]";
	}

}
