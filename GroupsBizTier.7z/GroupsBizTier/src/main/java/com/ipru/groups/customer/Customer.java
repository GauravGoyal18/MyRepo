package com.ipru.groups.customer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;

	private String addressProof;
	private String age;
	private String agentCode;
	private String ageProof;
	private String appntDate;
	private String appntNumber;
	private String avgInvestment;
	private String avgSumAssured;
	private String gapInvestment;


	//added by viresh
	private String experience="";
	
	private String dependentName="";

	private String organisationName;
	private String organisationType;
	private String organisationTypeToDispay;
	private String industryDesc;
	private String industryType;
	private String pasaFlag;
	private String callDate;
	private String callType;
	private String clientDebt;
	private String clientEquity;
	private String complaintType;
	// private String id;
	/* Summary details */
	private String custId;
	private String date;
	private Date dateOfBirth;
	private String dob;
	private String dueDate;
	private String email;
	private String emailIdOrgnl;
	private String familyDetailsString;

	/* private String femaleslt; */
	private String filterDate;
	private String productCode;
	/* Top premium dashboard */
	private String foreClosedAmount;

	private String gender;
	private String idealDebt;
	private String idealEquity;

	private String idProof;
	private String impDates;
	private String investedPrmum;
	private String issuedDate;
	private String landlineNo;
	private String lapsed;
	private String lastName;
	private String leadOrigin;
	private String leadType;
	private String location;
	/*
	 * private String maleslt; private String micrcode;
	 */
	private String middleName;
	private String mobileNo;
	private String mobileNoOrgnl;
	private String mobileOrEmail;
	private String name;

	private String noOfPolicies;

	private String outstanding;

	private String maritalStatus; // By Danesh
	private String resStatus; // By Danesh
	private String nationality; // By Danesh
	private String nationalityCode; // By Danesh
	private String PEP; // By Danesh
	private String iciciAccNo; // By Danesh
	private String aadharNo; // By Danesh
	private String idirectAccNo; // By Danesh
	private String lombardAccNo; // By Danesh

	/* added for showing on profile page -- merger -- start -- Kushal */
	private String maritalStatus_show;
	private String residentialStatus_show;
	private String nationality_show;
	private String panNo;
	/* private String panno; */

	private int personInfoId;
	/* Not Clear */
	private String phoneNum = "lalala";

	private String picurl;
	private String policyName;
	private String policyNo;
	private String policyStatus;
	private String premiumAmt;
	private String premiumAmtUF;

	private String premiumDue;
	private String premiumDueUF;
	private String productName;
	private String profession;
	private String education;
	private String educationToDisplay;
	/* Demand Generation Up/Sell Products */
	private String propToBuy;
	private String recProductCode1;
	private String recProductCode2;
	private String recProductName1;
	private String recProductName2;
	private String recSumAssured;
	private String requestDate;
	private String signUrl;
	private String source;
	private String srNumber;
	// private Integer amount;
	private String sumAssured;
	private String sumAssuredUF;
	private String surrenderValue;
	private String title;
	/* Top premium dashboard */
	private String totalfundValue;
	/* temp Params */
	private String totalfundValueUF;
	private String touchPoint;

	/*
	 * If any changes are made in the fields: address, flat_bldg, road_sector,
	 * area, landmark, pinCode, city, state, country Please kindly keep a check
	 * on the impact of it on Profile Module. These fields have been added in
	 * properties file for profile, so that may lead to lapse in the execution.
	 */
	
	private String flat_bldg;
	private String flatBldg; // for digidrive profileupdate
	private String road_sector;
	private String roadSector; // for digidrive profileupdate
	private String area;
	private String landmark;
	private String pinCode;
	private String city;
	private String state;
	private String country;
	private String addrProof;
	
	
	/* added for showing on profile page Sushma */
	private String maritalStatusShow;
	private String residentialStatusShow;
	private String nationalityShow;
	private String landLineNumber;
	public String getMaritalStatusShow() {
		return maritalStatusShow;
	}

	public void setMaritalStatusShow(String maritalStatusShow) {
		this.maritalStatusShow = maritalStatusShow;
	}

	public String getResidentialStatusShow() {
		return residentialStatusShow;
	}

	public void setResidentialStatusShow(String residentialStatusShow) {
		this.residentialStatusShow = residentialStatusShow;
	}

	public String getNationalityShow() {
		return nationalityShow;
	}

	public void setNationalityShow(String nationalityShow) {
		this.nationalityShow = nationalityShow;
	}



	
	
	public String getAddrProof() {
		return addrProof;
	}

	public void setAddrProof(String addrProof) {
		this.addrProof = addrProof;
	}



	private String std1;
	private String landline1;
	private String std2;
	private String landline2;
	private String officialEmail;
	private String personalEmail;
	private String addressProofShortDes;
	private String ageProofShortDes;
	private String idProofShortDes;
	private String incomeProof;
	private String incomeProofShortDes;

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getDependentName() {
		return dependentName;
	}

	public void setDependentName(String dependentName) {
		this.dependentName = dependentName;
	}

	public String getPasaFlag() {
		return pasaFlag;
	}

	public void setPasaFlag(String pasaFlag) {
		this.pasaFlag = pasaFlag;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMaritalStatus_show() {
		return maritalStatus_show;
	}

	public void setMaritalStatus_show(String maritalStatus_show) {
		this.maritalStatus_show = maritalStatus_show;
	}

	public String getResidentialStatus_show() {
		return residentialStatus_show;
	}

	public void setResidentialStatus_show(String residentialStatus_show) {
		this.residentialStatus_show = residentialStatus_show;
	}

	public String getNationality_show() {
		return nationality_show;
	}

	public void setNationality_show(String nationality_show) {
		this.nationality_show = nationality_show;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* added for showing on profile page -- merger -- end -- Kushal */

	public String getPEP() {
		return PEP;
	}

	public void setPEP(String pEP) {
		PEP = pEP;
	}

	public String getNationalityCode() {
		return nationalityCode;
	}

	public void setNationalityCode(String nationalityCode) {
		this.nationalityCode = nationalityCode;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getResStatus() {
		return resStatus;
	}

	public void setResStatus(String resStatus) {
		this.resStatus = resStatus;
	}

	public String getStd1() {
		return std1;
	}

	public void setStd1(String std1) {
		this.std1 = std1;
	}

	public String getLandline1() {
		return landline1;
	}

	public void setLandline1(String landline1) {
		this.landline1 = landline1;
	}

	public String getStd2() {
		return std2;
	}

	public void setStd2(String std2) {
		this.std2 = std2;
	}

	public String getLandline2() {
		return landline2;
	}

	public void setLandline2(String landline2) {
		this.landline2 = landline2;
	}

	public String getOfficialEmail() {
		return officialEmail;
	}

	public void setOfficialEmail(String officialEmail) {
		this.officialEmail = officialEmail;
	}

	public String getPersonalEmail() {
		return personalEmail;
	}

	public void setPersonalEmail(String personalEmail) {
		this.personalEmail = personalEmail;
	}



	/*
	 * If any changes are made in the fields: address, flat_bldg, road_sector,
	 * area, landmark, pinCode, city, state, country Please kindly keep a check
	 * on the impact of it on Profile Module. These fields have been added in
	 * properties file for profile, so that may lead to lapse in the execution.
	 */
	private String firstName;

	// for digidrive profileupdate
	public String getFlatBldg() {
		return flatBldg;
	}

	public void setFlatBldg(String flatBldg) {
		this.flatBldg = flatBldg;
	}

	public String getRoadSector() {
		return roadSector;
	}

	public void setRoadSector(String roadSector) {
		this.roadSector = roadSector;
	}
	// for digidrive profileupdate
	
	
	
	
	
	public String getFlat_bldg() {
		return flat_bldg;
	}

	public void setFlat_bldg(String flat_bldg) {
		this.flat_bldg = flat_bldg;
		setFlatBldg(flat_bldg);
	}

	public String getRoad_sector() {
		return road_sector;
		
	}

	public void setRoad_sector(String road_sector) {
		this.road_sector = road_sector;
		setRoadSector(road_sector);
	}


	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getIncomeProof() {
		return incomeProof;
	}

	public void setIncomeProof(String incomeProof) {
		this.incomeProof = incomeProof;
	}

	public String getIncomeProofShortDes() {
		return incomeProofShortDes;
	}

	public void setIncomeProofShortDes(String incomeProofShortDes) {
		this.incomeProofShortDes = incomeProofShortDes;
	}

	public String getAddressProofShortDes() {
		return addressProofShortDes;
	}

	public void setAddressProofShortDes(String addressProofShortDes) {
		this.addressProofShortDes = addressProofShortDes;
	}

	public String getAgeProofShortDes() {
		return ageProofShortDes;
	}

	public void setAgeProofShortDes(String ageProofShortDes) {
		this.ageProofShortDes = ageProofShortDes;
	}

	public String getIdProofShortDes() {
		return idProofShortDes;
	}

	public void setIdProofShortDes(String idProofShortDes) {
		this.idProofShortDes = idProofShortDes;
	}

	public String getAddressProof() {
		return addressProof;
	}

	public String getAge() {
		return age;
	}

	public String getAgentCode() {
		return agentCode;
	}

	public String getAgeProof() {
		return ageProof;
	}

	public String getAppntDate() {
		return appntDate;
	}

	public String getAppntNumber() {
		return appntNumber;
	}

	public String getCallDate() {
		return callDate;
	}

	public String getCallType() {
		return callType;
	}

	public String getClientDebt() {
		return clientDebt;
	}

	public String getClientEquity() {
		return clientEquity;
	}

	public String getComplaintType() {
		return complaintType;
	}

	public String getCustId() {
		return custId;
	}

	public String getDate() {
		return date;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public String getDob() {
		return dob;
	}

	public String getDueDate() {
		return dueDate;
	}

	public String getEmail() {

		if (StringUtils.isBlank(email)) {
			if (this.personalEmail != null && !personalEmail.equals("")
					&& personalEmail.indexOf("@") != -1
					&& officialEmail != null && !officialEmail.equals("")
					&& officialEmail.indexOf("@") != -1)
				email = officialEmail + "," + personalEmail;
			else if (this.personalEmail != null
					&& !personalEmail.equals("")
					&& personalEmail.indexOf("@") != -1
					&& (officialEmail == null || officialEmail.equals("") || officialEmail
							.indexOf("@") == -1))
				email = personalEmail;
			else if (this.officialEmail != null
					&& !officialEmail.equals("")
					&& officialEmail.indexOf("@") != -1
					&& (personalEmail == null || personalEmail.equals("") || personalEmail
							.indexOf("@") == -1))
				email = officialEmail;
		}

		return email;
	}

	public String getEmailIdOrgnl() {
		return emailIdOrgnl;
	}


	public String getFamilyDetailsString() {
		return familyDetailsString;
	}

	public String getFilterDate() {
		return filterDate;
	}

	public String getForeClosedAmount() {
		return foreClosedAmount;
	}

	public String getGender() {
		return gender;
	}

	public String getIdealDebt() {
		return idealDebt;
	}

	public String getIdealEquity() {
		return idealEquity;
	}

	public String getIdProof() {
		return idProof;
	}

	public String getImpDates() {
		return impDates;
	}

	public String getInvestedPrmum() {
		return investedPrmum;
	}

	public String getIssuedDate() {
		return issuedDate;
	}

	public String getLandlineNo() {
		if (StringUtils.isEmpty(landlineNo)) {
			if (this.std1 != null && !std1.equals("") && landline1 != null
					&& !landline1.equals("") && std2 != null
					&& !std2.equals("") && landline2 != null
					&& !landline2.equals(""))
				landlineNo = std1 + "-" + landline1 + "," + std2 + "-"
						+ landline2;
			else if (this.std1 != null
					&& !std1.equals("")
					&& landline1 != null
					&& !landline1.equals("")
					&& (std2 == null || std2.equals("") || landline2 == null || landline2
							.equals("")))
				landlineNo = std1 + "-" + landline1;
			else if (this.std2 != null
					&& !std2.equals("")
					&& landline2 != null
					&& !landline2.equals("")
					&& (std1 == null || std1.equals("") || landline1 == null || landline1
							.equals("")))
				landlineNo = std2 + "-" + landline2;
		}

		return landlineNo;
	}

	public String getLapsed() {
		return lapsed;
	}

	public String getLastName() {
		return lastName;
	}

	public String getLeadOrigin() {
		return leadOrigin;
	}

	public String getLeadType() {
		return leadType;
	}

	public String getLocation() {
		return location;
	}

	public String getMiddleName() {
		return middleName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public String getMobileNoOrgnl() {
		return mobileNoOrgnl;
	}

	public String getMobileOrEmail() {
		return mobileOrEmail;
	}

	public String getName() {
		return name;
	}

	public String getNoOfPolicies() {
		return noOfPolicies;
	}

	public String getOutstanding() {
		return outstanding;
	}

	public String getPanNo() {
		return panNo;
	}

	

	public int getPersonInfoId() {
		return personInfoId;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public String getPicurl() {
		return picurl;
	}

	public String getPolicyName() {
		return policyName;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public String getPremiumAmt() {
		return premiumAmt;
	}

	public String getPremiumAmtUF() {
		return premiumAmtUF;
	}

	public String getPremiumDue() {
		return premiumDue;
	}

	public String getPremiumDueUF() {
		return premiumDueUF;
	}

	public String getProductName() {
		return productName;
	}

	public String getProfession() {
		return profession;
	}

	public String getPropToBuy() {
		return propToBuy;
	}

	public String getRecProductCode1() {
		return recProductCode1;
	}

	public String getRecProductCode2() {
		return recProductCode2;
	}

	public String getRecProductName1() {
		return recProductName1;
	}

	public String getRecProductName2() {
		return recProductName2;
	}

	public String getRecSumAssured() {
		return recSumAssured;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public String getSignUrl() {
		return signUrl;
	}

	public String getSource() {
		return source;
	}

	public String getSrNumber() {
		return srNumber;
	}

	public String getSumAssured() {
		return sumAssured;
	}

	public String getSumAssuredUF() {
		return sumAssuredUF;
	}

	public String getSurrenderValue() {
		return surrenderValue;
	}

	public String getTitle() {
		return title;
	}

	public String getTotalfundValue() {
		return totalfundValue;
	}

	public String getTotalfundValueUF() {
		return totalfundValueUF;
	}

	public String getTouchPoint() {
		return touchPoint;
	}

	public void setAddressProof(String addressProof) {
		this.addressProof = addressProof;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public void setAgeProof(String ageProof) {
		this.ageProof = ageProof;
	}

	public void setAppntDate(String appntDate) {
		this.appntDate = appntDate;
	}

	public void setAppntNumber(String appntNumber) {
		this.appntNumber = appntNumber;
	}

	public void setCallDate(String callDate) {
		this.callDate = callDate;
	}

	public void setCallType(String callType) {
		this.callType = callType;
	}

	public void setClientDebt(String clientDebt) {
		this.clientDebt = clientDebt;
	}

	public void setClientEquity(String clientEquity) {
		this.clientEquity = clientEquity;
	}

	public void setComplaintType(String complaintType) {
		this.complaintType = complaintType;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setEmailIdOrgnl(String emailIdOrgnl) {
		this.emailIdOrgnl = emailIdOrgnl;
	}

	public void setFamilyDetailsString(String familyDetailsString) {
		this.familyDetailsString = familyDetailsString;
	}

	public void setFilterDate(String filterDate) {
		this.filterDate = filterDate;
	}

	public void setForeClosedAmount(String foreClosedAmount) {
		this.foreClosedAmount = foreClosedAmount;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setIdealDebt(String idealDebt) {
		this.idealDebt = idealDebt;
	}

	public void setIdealEquity(String idealEquity) {
		this.idealEquity = idealEquity;
	}

	public void setIdProof(String idProof) {
		this.idProof = idProof;
	}

	public void setImpDates(String impDates) {
		this.impDates = impDates;
	}

	public void setInvestedPrmum(String investedPrmum) {
		this.investedPrmum = investedPrmum;
	}

	public void setIssuedDate(String issuedDate) {
		this.issuedDate = issuedDate;
	}

	public void setLandlineNo(String landlineNo) {
		this.landlineNo = landlineNo;
	}

	public void setLapsed(String lapsed) {
		this.lapsed = lapsed;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setLeadOrigin(String leadOrigin) {
		this.leadOrigin = leadOrigin;
	}

	public void setLeadType(String leadType) {
		this.leadType = leadType;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public void setMobileNoOrgnl(String mobileNoOrgnl) {
		this.mobileNoOrgnl = mobileNoOrgnl;
	}

	public void setMobileOrEmail(String mobileOrEmail) {
		this.mobileOrEmail = mobileOrEmail;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setNoOfPolicies(String noOfPolicies) {
		this.noOfPolicies = noOfPolicies;
	}

	public void setOutstanding(String outstanding) {
		this.outstanding = outstanding;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}


	public void setPersonInfoId(int personInfoId) {
		this.personInfoId = personInfoId;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public void setPicurl(String picurl) {
		this.picurl = picurl;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public void setPremiumAmt(String premiumAmt) {
		this.premiumAmt = premiumAmt;
	}

	public void setPremiumAmtUF(String premiumAmtUF) {
		this.premiumAmtUF = premiumAmtUF;
	}

	public void setPremiumDue(String premiumDue) {
		this.premiumDue = premiumDue;
	}

	public void setPremiumDueUF(String premiumDueUF) {
		this.premiumDueUF = premiumDueUF;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}

	public void setPropToBuy(String propToBuy) {
		this.propToBuy = propToBuy;
	}

	public void setRecProductCode1(String recProductCode1) {
		this.recProductCode1 = recProductCode1;
	}

	public void setRecProductCode2(String recProductCode2) {
		this.recProductCode2 = recProductCode2;
	}

	public void setRecProductName1(String recProductName1) {
		this.recProductName1 = recProductName1;
	}

	public void setRecProductName2(String recProductName2) {
		this.recProductName2 = recProductName2;
	}

	public void setRecSumAssured(String recSumAssured) {
		this.recSumAssured = recSumAssured;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public void setSignUrl(String signUrl) {
		this.signUrl = signUrl;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setSrNumber(String srNumber) {
		this.srNumber = srNumber;
	}

	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}

	public void setSumAssuredUF(String sumAssuredUF) {
		this.sumAssuredUF = sumAssuredUF;
	}

	public void setSurrenderValue(String surrenderValue) {
		this.surrenderValue = surrenderValue;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setTotalfundValue(String totalfundValue) {
		this.totalfundValue = totalfundValue;
	}

	public void setTotalfundValueUF(String totalfundValueUF) {
		this.totalfundValueUF = totalfundValueUF;
	}

	public void setTouchPoint(String touchPoint) {
		this.touchPoint = touchPoint;
	}

	public String getIciciAccNo() {
		return iciciAccNo;
	}

	public void setIciciAccNo(String iciciAccNo) {
		this.iciciAccNo = iciciAccNo;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getIdirectAccNo() {
		return idirectAccNo;
	}

	public void setIdirectAccNo(String idirectAccNo) {
		this.idirectAccNo = idirectAccNo;
	}

	public String getLombardAccNo() {
		return lombardAccNo;
	}

	public void setLombardAccNo(String lombardAccNo) {
		this.lombardAccNo = lombardAccNo;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getAvgInvestment() {
		return avgInvestment;
	}

	public void setAvgInvestment(String avgInvestment) {
		this.avgInvestment = avgInvestment;
	}

	public String getAvgSumAssured() {
		return avgSumAssured;
	}

	public void setAvgSumAssured(String avgSumAssured) {
		this.avgSumAssured = avgSumAssured;
	}

	public String getGapInvestment() {
		return gapInvestment;
	}

	public void setGapInvestment(String gapInvestment) {
		this.gapInvestment = gapInvestment;
	}

	public String getEducationToDisplay() {
		return educationToDisplay;
	}

	public void setEducationToDisplay(String educationToDisplay) {
		this.educationToDisplay = educationToDisplay;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getOrganisationType() {
		return organisationType;
	}

	public void setOrganisationType(String organisationType) {
		this.organisationType = organisationType;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getOrganisationTypeToDispay() {
		return organisationTypeToDispay;
	}

	public void setOrganisationTypeToDispay(String organisationTypeToDispay) {
		this.organisationTypeToDispay = organisationTypeToDispay;
	}

	public String getIndustryDesc() {
		return industryDesc;
	}

	public void setIndustryDesc(String industryDesc) {
		this.industryDesc = industryDesc;
	}

	public String getIndustryType() {
		return industryType;
	}

	public void setIndustryType(String industryType) {
		this.industryType = industryType;
	}

	private String designation;

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	private String annualIncome;

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getLandLineNumber() {
		return landLineNumber;
	}

	public void setLandLineNumber(String landLineNumber) {
		this.landLineNumber = landLineNumber;
	}
	
}
