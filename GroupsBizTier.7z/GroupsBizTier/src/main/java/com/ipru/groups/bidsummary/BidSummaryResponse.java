package com.ipru.groups.bidsummary;


import java.io.Serializable;
import java.math.BigDecimal;

import com.ipru.estatement.bid.generated.ArrayOfAuthorisedSignatory;
import com.ipru.estatement.bid.generated.ArrayOfBID;

public class BidSummaryResponse implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigDecimal balance;
    private String unitName;
    
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	
   /* private ArrayOfAuthorisedSignatory authorisedSignatory;
    private ArrayOfBID bidAsOnDate;
    private String billedToDt;
    private String companyAddress;
    private String companyName;
    private Integer inforceMemberUnderPolicy;
    private String mstPolicyNo;
    private String paidToDt;
    private String policyCommencementDt;
    private String policyInceptionDt;
    private String policyRenewalDt;
    private String policyType;
    private String premiumMode;
	public ArrayOfAuthorisedSignatory getAuthorisedSignatory() {
		return authorisedSignatory;
	}
	public void setAuthorisedSignatory(
			ArrayOfAuthorisedSignatory authorisedSignatory) {
		this.authorisedSignatory = authorisedSignatory;
	}
	public ArrayOfBID getBidAsOnDate() {
		return bidAsOnDate;
	}
	public void setBidAsOnDate(ArrayOfBID bidAsOnDate) {
		this.bidAsOnDate = bidAsOnDate;
	}
	public String getBilledToDt() {
		return billedToDt;
	}
	public void setBilledToDt(String billedToDt) {
		this.billedToDt = billedToDt;
	}
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Integer getInforceMemberUnderPolicy() {
		return inforceMemberUnderPolicy;
	}
	public void setInforceMemberUnderPolicy(Integer inforceMemberUnderPolicy) {
		this.inforceMemberUnderPolicy = inforceMemberUnderPolicy;
	}
	public String getMstPolicyNo() {
		return mstPolicyNo;
	}
	public void setMstPolicyNo(String mstPolicyNo) {
		this.mstPolicyNo = mstPolicyNo;
	}
	public String getPaidToDt() {
		return paidToDt;
	}
	public void setPaidToDt(String paidToDt) {
		this.paidToDt = paidToDt;
	}
	public String getPolicyCommencementDt() {
		return policyCommencementDt;
	}
	public void setPolicyCommencementDt(String policyCommencementDt) {
		this.policyCommencementDt = policyCommencementDt;
	}
	public String getPolicyInceptionDt() {
		return policyInceptionDt;
	}
	public void setPolicyInceptionDt(String policyInceptionDt) {
		this.policyInceptionDt = policyInceptionDt;
	}
	public String getPolicyRenewalDt() {
		return policyRenewalDt;
	}
	public void setPolicyRenewalDt(String policyRenewalDt) {
		this.policyRenewalDt = policyRenewalDt;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getPremiumMode() {
		return premiumMode;
	}
	public void setPremiumMode(String premiumMode) {
		this.premiumMode = premiumMode;
	}*/
    
    

}
