package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class EmailMobileRequestVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String emailId;
	private long mobileNo;
	private String webClientId;
	private String policyNo;
	private String clientId;
	private String role;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getWebClientId() {
		return webClientId;
	}

	public void setWebClientId(String webClientId) {
		this.webClientId = webClientId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "EmailMobileRequestVO [emailId=" + emailId + ", mobileNo=" + mobileNo + ", webClientId=" + webClientId + ", policyNo=" + policyNo + ", clientId=" + clientId + ", role=" + role + "]";
	}

}
