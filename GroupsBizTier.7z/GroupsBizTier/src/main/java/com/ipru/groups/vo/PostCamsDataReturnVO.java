package com.ipru.groups.vo;

public class PostCamsDataReturnVO {
private String result;
private String Response;
public String getResult() {
	return result;
}
public void setResult(String result) {
	this.result = result;
}
public String getResponse() {
	return Response;
}
public void setResponse(String response) {
	Response = response;
}
@Override
public String toString() {
	return "PostCamsDataReturnVO [result=" + result + ", Response=" + Response
			+ "]";
}

}
