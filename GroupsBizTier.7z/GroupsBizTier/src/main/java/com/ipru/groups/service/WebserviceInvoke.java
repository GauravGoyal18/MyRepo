package com.ipru.groups.service;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ipru.IPruException;
import com.ipru.broker.EncryptPassword;
import com.ipru.broker.EncryptPasswordResponse;
import com.ipru.cams.client.PostCamsData;
import com.ipru.cams.client.PostCamsDataResponse;
import com.ipru.digitallifeverification.wsdl.IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement;
import com.ipru.digitallifeverification.wsdl.IAXISDIGILIFEVERIFICATIONRequestType;
import com.ipru.digitallifeverification.wsdl.IAXISDIGILIFEVERIFICATIONResponseType;
import com.ipru.digitallifeverification.wsdl.IAXISDIGILIFEVERIFICATIONResponseType.IAXISDIGILIFEVERIFICATIONResponseElement;
import com.ipru.ecamptransaction.bean.EcampAuthBean;
import com.ipru.ecamptransaction.bean.EcampJsonBean;
import com.ipru.ecamptransaction.bean.EcampResponseBean;
import com.ipru.estatement.bid.generated.ObjectFactory;
import com.ipru.estatement.bid.generated.PortalBIDUnitwise;
import com.ipru.estatement.bid.generated.PortalBIDUnitwiseResponse;
import com.ipru.estatement.bid.generated.PortalPolicySnapshot;
import com.ipru.estatement.bid.generated.PortalPolicySnapshotResponse;
import com.ipru.groups.po.DropDownRequestPO;
import com.ipru.groups.spaarc.helper.SpaarcCallLogHelper;
import com.ipru.groups.vo.AnntyClaimVO;
import com.ipru.groups.vo.AnnuityAuthenticationVO;
import com.ipru.groups.vo.AnnuityCalculatorVO;
import com.ipru.groups.vo.BidStatementVO;
import com.ipru.groups.vo.BrokerBIDVO;
import com.ipru.groups.vo.DigitalLifeVerificationVO;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.groups.vo.GroupEmailSmsVO;
import com.ipru.groups.vo.NomineeUpdateVo;
import com.ipru.groups.vo.ProductDetailsVO;
import com.ipru.groups.vo.ServiceWebpageCallVO;
import com.ipru.groups.vo.SignUpPolicyDetailsVO;
import com.ipru.groups.vo.StofPreFundDetailsVO;
import com.ipru.groups.vo.UploadFileVO;
import com.ipru.groups.widget.service.ClickPssResponse;
import com.ipru.groups.widget.service.GroupsBaseService;
import com.ipru.spaarc.generated.AutoCallLog;
import com.ipru.spaarc.generated.AutoCallLogResponse;
import com.sun.jersey.api.client.Client;
import com.tcs.beans.ParamObj;
import com.tcs.beans.PrePopulateBean;
import com.tcs.beans.SwitchToRequest;
import com.tcs.beans.WebServiceNameEnum;
import com.tcs.exception.WebServiceClientException;
import com.tcs.logger.FLogger;
import com.tcs.wsconfig.wsclient.CacheConfigurator;
import com.tcs.wsconfig.wsclient.WebServiceClient;
import com.tcs.wsconfig.wsclient.WebserviceClientConfigurator;
import com.tcs.wsconfig.wsclient.WebserviceSource;

public final class WebserviceInvoke extends GroupsBaseService {

	private static WebserviceInvoke webserviceInvoke = null;
	private static final String CLASS_NAME = "WebserviceInvoke";
	private static final String WEBSERVICELOGGER = "WebServiceLogger"; // Use
																		// Capital
																		// letters
																		// for
																		// constants.

	private WebserviceInvoke() {
	}

	/* Singleton WebserviceInvoke instance */
	public static WebserviceInvoke getInstance() {
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getInstance", "Method start");
		if (webserviceInvoke == null) {
			synchronized (CLASS_NAME) {
				webserviceInvoke = new WebserviceInvoke();
			}
		}
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getInstance", "Method End");
		return webserviceInvoke;
	}

	public String createSpaarcAutoCallLog(ServiceWebpageCallVO serviceWebpageCallVO, List<UploadFileVO> uploadFileList, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();

		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "createSpaarcAutoCallLog", "Method Start time" + startTime);
		String wsResponse = null;

		@SuppressWarnings("unchecked")
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.SpaarcAutoCallLog.getWebServiceName());

		SpaarcCallLogHelper spaarcCallLogHelper = SpaarcCallLogHelper.getInstance();
		AutoCallLog autoCallLog = spaarcCallLogHelper.createCallLog(serviceWebpageCallVO, uploadFileList);

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {

					// ////System.out.println("webserviceSource : " +
					// ToStringBuilder.reflectionToString(webserviceSource) +
					// "\n");

					AutoCallLogResponse output = (AutoCallLogResponse) WebServiceClient.getInstance().invokeWsUsingHttpClient(autoCallLog, webserviceSource);
					if (output != null) {
						wsResponse = output.getAutoCallLogResult();
						// ////System.out.println("wsResponse  :" + wsResponse);
					}
					else {
						// ////System.out.println("Null Response");
					}
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "createSpaarcAutoCallLog", "Method end time" + endTime);

		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "createSpaarcAutoCallLog", methodExcutionTimeCalculate(startTime, endTime));
		return wsResponse;
	}

	public PortalBIDUnitwiseResponse getBidStatementData(BidStatementVO bidRequest, String INFO_LOGGER_NAME) throws Exception {

		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		long startTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBidStatementData", "Method Start time" + startTime);

		ObjectFactory factory = new ObjectFactory();
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.BidStatement.getWebServiceName());

		PortalBIDUnitwise bid = factory.createPortalBIDUnitwise();
		PortalBIDUnitwiseResponse output = null;

		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy");
		SimpleDateFormat format2 = new SimpleDateFormat("dd-MM-yy");
		String frmDate = bidRequest.getFromDate();
		Date fromdate1 = (Date) format1.parse(frmDate);
		String fromDateString = format2.format(fromdate1);
		String toDate = bidRequest.getToDate();
		Date toDate1 = (Date) format1.parse(toDate);
		String toDateString = format2.format(toDate1);

		GregorianCalendar c = new GregorianCalendar();
		c.setTime(format2.parse(fromDateString));

		GregorianCalendar c1 = new GregorianCalendar();
		c1.setTime(format2.parse(toDateString));

		XMLGregorianCalendar endDt = DatatypeFactory.newInstance().newXMLGregorianCalendar(c1);
		XMLGregorianCalendar startDt = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		bid.setEndDt(endDt);
		bid.setStartDt(startDt);
		bid.setPolicyKey(new BigDecimal(bidRequest.getPolicyKey()));
		bid.setRequestId(factory.createPortalBIDUnitwiseRequestId(bidRequest.getRequestId()));
		bid.setUnitCode(factory.createPortalBIDUnitwiseUnitCode(bidRequest.getUnitCode()));
		bid.setUserID(factory.createPortalBIDUnitwiseUserID(bidRequest.getUserID()));
		// bid.setEndDt(endDt);

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					// //System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
					output = (PortalBIDUnitwiseResponse) WebServiceClient.getInstance().invokeWsUsingHttpClient(bid, webserviceSource);
					// ////System.out.println("\nResponse  :"+output);

				}
			}
		}

		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBidStatementData", "Output:::" + output.toString());
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBidStatementData", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBidStatementData", methodExcutionTimeCalculate(startTime, endTime));
		return output;
	}

	public String getAnnuityData(AnnuityCalculatorVO annuityCalculatorVO, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getAnnuityData", "Method Start" + startTime);

		String wsResponse = null;
		String incomeOption = null;
		Gson gson = new Gson();
		String jsonString = gson.toJson(annuityCalculatorVO);

		@SuppressWarnings("unchecked")
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.AnnuityCalculator.getWebServiceName());

		// ////System.out.println("jsonSTring111111111111 *************************"+jsonString);

		/*
		 * String jsonString = "\n{\n" + "  \"policyType\" : \"G\", \n" +
		 * "  \"annuitantAge\" : \"25\", \n" + "  \"spouseAge\" : \"23\", \n" +
		 * "  \"channelType\" : \"Tied\", \n" + "  \"inputAmt\" : \"45000\", \n"
		 * + "  \"calculatorMode\" : \"A\", \n" +
		 * "  \"incomeOption\" : \"JLLS\", \n" +
		 * "  \"prevAnnuityAmt\" : \"\", \n" +
		 * "  \"annuitantGender\" : \"F\",\n" + "  \"ageDiff\" : \"2\"\n}" ;
		 */

		if (annuityCalculatorVO.getIncomeOption().equalsIgnoreCase("ALL")) {
			incomeOption = "";
		}
		else {
			incomeOption = annuityCalculatorVO.getIncomeOption();
		}
		String jsonString1 = "\n{\n" + "  \"policyType\" : \"G\", \n" + "  \"annuitantAge\" : \"" + annuityCalculatorVO.getAnnuitantAge() + "\", \n" + "  \"spouseAge\" : \""
				+ annuityCalculatorVO.getSpouseAge() + "\", \n" + "  \"channelType\" : \"" + annuityCalculatorVO.getChannelType() + "\", \n" + "  \"inputAmt\" : \""
				+ annuityCalculatorVO.getInputAmt() + "\", \n" + "  \"calculatorMode\" : \"" + annuityCalculatorVO.getCalculatorMode() + "\", \n" + "  \"incomeOption\" : \"" + incomeOption + "\", \n"
				+ "  \"prevAnnuityAmt\" : \"\", \n" + "  \"annuitantGender\" : \"" + annuityCalculatorVO.getAnnuitantGender() + "\",\n" + "  \"ageDiff\" : \"" + annuityCalculatorVO.getAgeDiff()
				+ "\"\n}";

		// ////System.out.println("jsonSTring *************************"+jsonString);
		// String auth = "{\"authKey\":\"CAMS1454AUTH7204\"}";
		PostCamsData postCamsData = new PostCamsData();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getAnnuityData", "jsonString1" + jsonString1);

		postCamsData.setJsonString(jsonString1);
		AnnuityAuthenticationVO authentication = new AnnuityAuthenticationVO();
		authentication.setAuthKey("CAMS1454AUTH7204");
		String auth = gson.toJson(authentication);
		postCamsData.setAuth(auth);

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					// ////System.out.println("webserviceSource is not null");
					PostCamsDataResponse output = (PostCamsDataResponse) WebServiceClient.getInstance().invokeWsUsingHttpClient(postCamsData, webserviceSource);
					if (output != null) {
						wsResponse = output.getPostCamsDataReturn();
						// ////System.out.println("wsResponse  :" +
						// ToStringBuilder.reflectionToString(output));
					}
					else {
						FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getAnnuityData", "Null reponse from webservice");

					}
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getAnnuityData", "method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getAnnuityData", methodExcutionTimeCalculate(startTime, endTime));

		return wsResponse;
	}

	public String getBrokerData(EncryptPassword encrypted, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		String wsResponse = null;
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		try {
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBrokerData", "Method Start" + startTime);
			ObjectFactory factory = new ObjectFactory();
			List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.BROKER.getWebServiceName());
			if (CollectionUtils.isNotEmpty(list)) {
				for (WebserviceSource webserviceSource : list) {
					if (webserviceSource != null) {
						JAXBElement output = (JAXBElement) WebServiceClient.getInstance().invokeWsUsingHttpClient(encrypted, webserviceSource);

						wsResponse = ((EncryptPasswordResponse) output.getValue()).getReturn() == null ? null : ((EncryptPasswordResponse) output.getValue()).getReturn();
					}
				}
			}
		}
		catch (Exception e) {
			wsResponse = null;
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBrokerData", "method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBrokerData", methodExcutionTimeCalculate(startTime, endTime));

		return wsResponse;
	}

	public String invokeFundNAVWS(Map<String, String> map, String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeFundNAVWS", "Method Start" + startTime);
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.GroupsServices.getWebServiceName());
		List<String> paramList = new ArrayList<String>();

		if (map != null) {
			if (map.get("policy") != null && map.get("policy") instanceof String) {
				paramList.add((String) map.get("policy"));
			}

			if (map.get("clientId") != null && map.get("clientId") instanceof String) {
				paramList.add((String) map.get("clientId"));
			}

			if (map.get("employeeId") != null && map.get("employeeId") instanceof String) {
				paramList.add((String) map.get("employeeId"));
			}

		}

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		SwitchToRequest switchToRequest = new SwitchToRequest();
		switchToRequest.setParamObj(paramObj);

		String switchToRequestString = getGsonSingleton().toJson(switchToRequest);
		Object output = null;

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(switchToRequestString, webserviceSource);
				}
			}
		}
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeFundNAVWS", "Output:::" + output.toString());
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeFundNAVWS", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeFundNAVWS", methodExcutionTimeCalculate(startTime, endTime));
		return output.toString();

	}

	public String fetchFundDetails(String fundCodes, String INFO_LOGGER_NAME) throws WebServiceClientException, NullPointerException, Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundDetails", "Method start" + startTime);
		Object output = null;
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.FUNDPERFORMANCE.getWebServiceName());
		Map<String, String> map = new HashMap<String, String>();
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					map.put("fundCodes", fundCodes);

					webserviceSource.setGetParameters(map);

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(null, webserviceSource);

				}
			}
		}

		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundDetails", "Output:::" + output.toString());
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundDetails", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundDetails", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String fetchProductDetails(String policyNumber, String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchProductDetails", "Method Start" + startTime);
		Object output = null;
		ProductDetailsVO productDetailsVO = null;

		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.NSEAndProductDetails.getWebServiceName());
		List<String> paramList = new ArrayList<String>();

		paramList.add(policyNumber);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("switchProductCode");
		prePopulateBean.setParamObj(paramObj);

		String prePopulateBeanString = getGsonSingleton().toJson(prePopulateBean);

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(prePopulateBeanString, webserviceSource);
				}
			}
		}
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchProductDetails", "Output:::" + output.toString());
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchProductDetails", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchProductDetails", methodExcutionTimeCalculate(startTime, endTime));
		return output.toString();
		// return productDetailsVO;

	}

	public String fetchNSEHoliday(String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {
		// public List<NSEHolidaysVO> fetchNSEHoliday() throws Exception{
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchNSEHoliday", "Method Start" + startTime);

		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.NSEAndProductDetails.getWebServiceName());
		Object output = null;
		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("nscHolidays");

		String prePopulateBeanString = getGsonSingleton().toJson(prePopulateBean);

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(prePopulateBeanString, webserviceSource);
				}
			}
		}
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchNSEHoliday", "Output:::" + output.toString());
		/*
		 * Gson gson1 = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		 * nseHolidaysVOList = gson1.fromJson(output.toString(), new
		 * TypeToken<List<NSEHolidaysVO>>() {}.getType());
		 */
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchNSEHoliday", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchNSEHoliday", methodExcutionTimeCalculate(startTime, endTime));
		return output.toString();
	}

	public String invokePreFundDetails(Map<String, String> map, String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetails", "Method Start" + startTime);
		Object output = null;
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PreFundDetails.getWebServiceName());

		List<String> paramList = new ArrayList<String>();
		Set<String> fundCodes = new HashSet<String>();

		if (map != null) {
			if (map.get("fromToFundCode") != null && map.get("fromToFundCode") instanceof String) {
				fundCodes = new HashSet<String>(Arrays.asList(map.get("fromToFundCode").split(",")));
			}

			if (map.get("policy") != null && map.get("policy") instanceof String) {
				paramList.add((String) map.get("policy"));
			}

			if (map.get("clientId") != null && map.get("clientId") instanceof String) {
				paramList.add((String) map.get("clientId"));
			}

			if (map.get("employeeId") != null && map.get("employeeId") instanceof String) {
				paramList.add((String) map.get("employeeId"));
			}
		}

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		SwitchToRequest switchToRequest = new SwitchToRequest();
		switchToRequest.setParamObj(paramObj);
		switchToRequest.setFundCodes(fundCodes);

		String switchToRequestString = getGsonSingleton().toJson(switchToRequest);

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(switchToRequestString, webserviceSource);
				}
			}
		}

		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetails", "Output:::" + output.toString());
		/*
		 * Gson gson1 = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		 * switchPreFundDetailsVOList = gson1.fromJson(output.toString(), new
		 * TypeToken<List<SwitchPreFundDetailsVO>>(){}.getType());
		 */
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetails", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetails", methodExcutionTimeCalculate(startTime, endTime));
		return output.toString();
	}

	public String invokePreFundDetailsForStof(Set<String> fundCodes, Map<String, String> map, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetailsForStof", "Method Start" + startTime);
		List<StofPreFundDetailsVO> list = new ArrayList<StofPreFundDetailsVO>();
		Object output = null;
		List<String> paramList = new ArrayList();
		if (map != null) {
			if (map.get("policy") != null && map.get("policy") instanceof String) {
				// paramList.add("00000348");//policynumber
				paramList.add((String) map.get("policy"));// policynumber
			}

			if (map.get("clientId") != null && map.get("clientId") instanceof String) {
				// paramList.add("ME11443");
				paramList.add((String) map.get("clientId"));
			}

		}

		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PreFundDetails.getWebServiceName());

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);
		SwitchToRequest switchToRequest = new SwitchToRequest();
		switchToRequest.setParamObj(paramObj);
		switchToRequest.setFundCodes(fundCodes);
		String switchToRequestString = getGsonSingleton().toJson(switchToRequest);

		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(switchToRequestString, webserviceSource);
				}
			}
		}
		/*
		 * Gson gson=new Gson(); if(output.toString()!=null &&
		 * !output.toString().equalsIgnoreCase("")) { list =
		 * gson.fromJson(output.toString(), new
		 * TypeToken<List<StofPreFundDetailsVO>>(){}.getType()); }
		 */
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetailsForStof", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetailsForStof", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeFreqOfTransDropDownDetailsForStof(String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeFreqOfTransDropDownDetailsForStof", "Method Start" + startTime);
		DropDownRequestPO dropDownRequest = new DropDownRequestPO("stof", "frequency");

		String requestString = getGsonSingleton().toJson(dropDownRequest);
		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.DropDownDetails.getWebServiceName());

		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeFreqOfTransDropDownDetailsForStof", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeFreqOfTransDropDownDetailsForStof", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeRelationDropDownDetailsForNominee(String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeRelationDropDownDetailsForNominee", "Method Start" + startTime);
		DropDownRequestPO dropDownRequest = new DropDownRequestPO("nominee", "relation", null);

		String requestString = getGsonSingleton().toJson(dropDownRequest);
		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.DropDownDetails.getWebServiceName());

		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetailsForStof", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetailsForStof", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForNominee(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNominee", "Method Start" + startTime);

		List<NomineeUpdateVo> nomineeUpdateVoList = new ArrayList<NomineeUpdateVo>();
		Client clientGet = Client.create();

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("nominee");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNominee", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNominee", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForCoi2(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoi2", "Method Start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("coi2");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoi2", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoi2", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForcoiSingleDownload(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {
		// TODO Auto-generated method stub
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForcoiSingleDownload", "Method Start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("coiSingleDownload");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForcoiSingleDownload", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForcoiSingleDownload", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForCoiProductCode(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiProductCode", "Method Start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("coiProductCode");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiProductCode", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiProductCode", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForCoiPolicyNumber(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiPolicyNumber", "Method Start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("coiPolicyNumber");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		@SuppressWarnings("unchecked")
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiPolicyNumber", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiPolicyNumber", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForCoiPanNumber(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {
		// TODO Auto-generated method stub
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiPanNumber", "Method Start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("coiPanNumber");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiPanNumber", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiPanNumber", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForDownloadFile(List<String> paramList) throws Exception {
		long startTime = System.nanoTime();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForDownloadFile", "Method Start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("fileDownload");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForDownloadFile", "Method end");
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForDownloadFile", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeRelationDropDownDetailsForCityDetails(String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeRelationDropDownDetailsForCityDetails", "Method Start" + startTime);
		DropDownRequestPO dropDownRequest = new DropDownRequestPO("profile", "getCityDetails", null);

		String requestString = getGsonSingleton().toJson(dropDownRequest);
		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.DropDownDetails.getWebServiceName());

		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);

				}
			}
		}

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeRelationDropDownDetailsForCityDetails", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeRelationDropDownDetailsForCityDetails", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeRelationDropDownDetailsForAddressType(String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeRelationDropDownDetailsForAddressType", "Method Start" + startTime);
		DropDownRequestPO dropDownRequest = new DropDownRequestPO("profile", "addressType", null);

		String requestString = getGsonSingleton().toJson(dropDownRequest);
		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.DropDownDetails.getWebServiceName());

		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeRelationDropDownDetailsForAddressType", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeRelationDropDownDetailsForAddressType", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeRelationDropDownDetailsForStateDetails(String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeRelationDropDownDetailsForStateDetails", "Method Start" + startTime);
		DropDownRequestPO dropDownRequest = new DropDownRequestPO("profile", "getStateDetails", null);

		String requestString = getGsonSingleton().toJson(dropDownRequest);
		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.DropDownDetails.getWebServiceName());

		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeRelationDropDownDetailsForStateDetails", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeRelationDropDownDetailsForStateDetails", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForCompanyAddressChange(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNominee", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("loadCompanyAddressChange");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNominee", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNominee", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForContactPersonChange(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForContactPersonChange", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("loadContactPersonChange");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForContactPersonChange", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForContactPersonChange", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForAuthorizedSignatoryChange(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForAuthorizedSignatoryChange", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("loadAuthorityPersonChange");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForAuthorizedSignatoryChange", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForAuthorizedSignatoryChange", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}
	          
	public String invokePrePopulateDetailsForMemberData(List<String> paramList, String max, String functionality, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForMemberData", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setMax(max);

		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForMemberData", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForMemberData", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForFundPerformance(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForFundPerformance", "Method Start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("switchProductCode");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForFundPerformance", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForFundPerformance", methodExcutionTimeCalculate(startTime, endTime));

		if (output != null)
			return output.toString();
		else
			return null;
	}

	public String invokePrePopulateDetailsForMemberDataCount(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForMemberDataCount", "Method start" + startTime);
		// ////System.out.println("invokePrePopulateDetailsForMemberDataCount callledddd");

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);

		prePopulateBean.setParamObj(paramObj);
		// ////System.out.println(" Prepop bean :"+prePopulateBean.toString());

		String requestString = getGsonSingleton().toJson(prePopulateBean);
		// ////System.out.println("requestString requestString requestString requestString requestString :"+requestString);
		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.prePopulateCount.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {
					// ////System.out.println("webserviceSource is not null ");
					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					// ////System.out.println(" OUTPUT IS :"+output);
				}
			}
		}
		long endTime = System.nanoTime();

		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForMemberData", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForMemberData", methodExcutionTimeCalculate(startTime, endTime));
		if (output != null)
			return output.toString();
		else
			return null;

	}

	public String invokePrePopulateDetailsForRetirementCalenderData(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForRetirementCalenderData", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("retirementDataQuery");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForRetirementCalenderData", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForRetirementCalenderData", methodExcutionTimeCalculate(startTime, endTime));

		if (output != null)
			return output.toString();
		else
			return null;
	}

	public String invokeDropDownDetailsClaims(String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "nvokePreFundDetailsForStof", "Method Start" + startTime);
		DropDownRequestPO dropDownRequest = new DropDownRequestPO("claims", "cause", null);

		String requestString = getGsonSingleton().toJson(dropDownRequest);
		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.DropDownDetails.getWebServiceName());

		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetailsForStof", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePreFundDetailsForStof", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeEmailCampaignWebService(String campaignName, GroupEmailSmsVO emailSms_obj, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeEmailCampaignWebService", "Method start" + startTime);
		String wsResponse = null;

		@SuppressWarnings("unchecked")
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.EmailCampaign.getWebServiceName());

		/*
		 * SpaarcCallLogHelper spaarcCallLogHelper =
		 * SpaarcCallLogHelper.getInstance(); AutoCallLog autoCallLog =
		 * spaarcCallLogHelper.createCallLog(serviceWebpageCallVO,
		 * uploadFileList);
		 */

		EcampAuthBean authBean = new EcampAuthBean();
		authBean.setUser("ecamp");
		authBean.setPassword("group@ipru");
		authBean.setAppName("Group");

		String authJsonString = getGsonSingleton().toJson(authBean);

		EcampJsonBean bean = new EcampJsonBean();
		bean.setCampaign(campaignName);

		List<String> dynParam = new ArrayList<String>(1);
		/*
		 * dynParam.add("Rohit");// Customer Name dynParam.add("Contact");//
		 * Functionality dynParam.add("00002285");// Identifier code
		 * dynParam.add("252524");// OTP dynParam.add("00002285");// Identifier
		 * code dynParam.add("rohit.sidana@ext.iciciprulife.com");
		 */
		if (emailSms_obj != null) {
			dynParam.add(emailSms_obj.getParam1());// Customer Name
			dynParam.add(emailSms_obj.getParam2());// Functionality
			dynParam.add(emailSms_obj.getParam3());// Identifier code
			dynParam.add(emailSms_obj.getParam4());// OTP
			dynParam.add(emailSms_obj.getParam5());// Identifier code
			dynParam.add(emailSms_obj.getParam6());// Email id
		}

		bean.setDynParam(dynParam);

		String requestJsonString = getGsonSingleton().toJson(bean);

		Map<String, String> form = new HashMap<String, String>(1);

		form.put("auth", authJsonString);
		form.put("jsonString", requestJsonString);

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeEmailCampaignWebService", "webserviceSource is not null");
					// ////System.out.println("webserviceSource : " +
					// ToStringBuilder.reflectionToString(webserviceSource) +
					// "\n");
					webserviceSource.setGetParameters(form);
					Object output = WebServiceClient.getInstance().invokeWsUsingHttpClient(null, webserviceSource);
					FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeEmailCampaignWebService", "output : " + output);

					if (output != null) {
						// ////System.out.println("output  :" + output);
						EcampResponseBean ecampResponseBean = getGsonSingleton().fromJson(output.toString(), EcampResponseBean.class);
						wsResponse = ecampResponseBean.getResult();
						FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeEmailCampaignWebService", "wsResponse  :" + wsResponse);
					}
					else {
						FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeEmailCampaignWebService", "Null Response");
					}
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeEmailCampaignWebService", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeEmailCampaignWebService", methodExcutionTimeCalculate(startTime, endTime));
		return wsResponse;
	}

	public PortalPolicySnapshotResponse fetchBIDSummary(String policyKey, String unitCode, String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBIDSummary", "Method Start" + startTime);
		// ////System.out.println("Entering WebService fetchBIDSummary1");
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.BIDSummary.getWebServiceName());

		PortalPolicySnapshotResponse output = null;

		/*
		 * String[] format = new String[]{"dd/MM/yyyy"}; Calendar fromCal =
		 * Calendar.getInstance();
		 * fromCal.setTime(DateUtils.parseDate("01/04/2016", format)); Calendar
		 * toCal = Calendar.getInstance();
		 * toCal.setTime(DateUtils.parseDate("31/03/2017", format));
		 * GregorianCalendar fromGregCal = new
		 * GregorianCalendar(fromCal.get(Calendar.YEAR),
		 * fromCal.get(Calendar.MONTH), fromCal.get(Calendar.DAY_OF_MONTH));
		 * XMLGregorianCalendar fromGregXmlCal =
		 * DatatypeFactory.newInstance().newXMLGregorianCalendar(fromGregCal);
		 * GregorianCalendar toGregCal = new
		 * GregorianCalendar(toCal.get(Calendar.YEAR),
		 * toCal.get(Calendar.MONTH), toCal.get(Calendar.DAY_OF_MONTH));
		 * XMLGregorianCalendar toGregXmlCal =
		 * DatatypeFactory.newInstance().newXMLGregorianCalendar(toGregCal);
		 */

		SecureRandom sr = new SecureRandom();
		String i = String.valueOf(Math.abs(sr.nextInt() / 10000));
		// //System.out.println(i);
		ObjectFactory factory = new ObjectFactory();

		PortalPolicySnapshot policySnapshot = factory.createPortalPolicySnapshot();

		// BigDecimal bigDecimal = new BigDecimal("5329");
		// bigDecimal = bigDecimal.setScale(0);
		// //System.out.println(bigDecimal);
		policySnapshot.setPolicyKey(factory.createPortalPolicySnapshotPolicyKey(new BigDecimal(policyKey)));
		policySnapshot.setRequestId(factory.createPortalPolicySnapshotRequestId(i));
		policySnapshot.setUnitCode(factory.createPortalPolicySnapshotUnitCode(unitCode));
		policySnapshot.setUserId(factory.createPortalPolicySnapshotUserId("test"));

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					// //System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
					output = (PortalPolicySnapshotResponse) WebServiceClient.getInstance().invokeWsUsingHttpClient(policySnapshot, webserviceSource);
					// ////System.out.println("\nResponse  :"+output);
					/*
					 * List<BID> bidList =
					 * output.getPortalPolicySnapshotResult()
					 * .getValue().getBidAsOnDate().getValue().getBID(); for(BID
					 * bid : bidList){
					 * //System.out.println(bid.getBalance().getName() + ":" +
					 * bid.getBalance().getValue());
					 * //System.out.println(bid.getUnitName().getName() + ":" +
					 * bid.getUnitName().getValue()); }
					 */
				}
			}
		}
		// ////System.out.println("done");
		// ////System.out.println("Leaving fetchBIDSummary");
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBIDSummary", "Output:::" + output.toString());
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBIDSummary", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBIDSummary", methodExcutionTimeCalculate(startTime, endTime));
		return output;

	}

	public String invokePrePopulateDetailsForContributionHistoryData(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForContributionHistoryData", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForContributionHistoryData", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForContributionHistoryData", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	private String methodExcutionTimeCalculate(long startTime, long endTime) {
		long difference = endTime - startTime;

		String totalTime = String.format("Total execution time: %d min, %d sec", TimeUnit.NANOSECONDS.toHours(difference), TimeUnit.NANOSECONDS.toSeconds(difference)
				- TimeUnit.MINUTES.toSeconds(TimeUnit.NANOSECONDS.toMinutes(difference)));
		return totalTime;

	}

	public String fetchPortfolioDetails(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchPortfolioDetails", "Method Start" + startTime);

		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.NSEAndProductDetails.getWebServiceName());
		Object output = null;

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String prePopulateBeanString = getGsonSingleton().toJson(prePopulateBean);

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(prePopulateBeanString, webserviceSource);
				}
			}
		}
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchPortfolioDetails", "Output:::" + output.toString());

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchPortfolioDetails", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchPortfolioDetails", methodExcutionTimeCalculate(startTime, endTime));
		return output.toString();
	}

	public String fetchFundsDetailChart(String fundCodes, Date currentDate, Date endDate, String INFO_LOGGER_NAME) throws WebServiceClientException, NullPointerException, Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundsDetailChart", "Method start" + startTime);
		Object output = null;
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.DigitalFundPerformanceChart.getWebServiceName());
		Map<String, String> map = new HashMap<String, String>();
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {

					SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");

					map.put("fundCode", fundCodes);
					map.put("startDate", (dateFormat.format(endDate).toString().toUpperCase()));
					map.put("endDate", dateFormat.format(currentDate).toString().toUpperCase());

					webserviceSource.setGetParameters(map);

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(null, webserviceSource);

				}
			}
		}

		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundsDetailChart", "Output:::" + output.toString());
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundsDetailChart", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundsDetailChart", methodExcutionTimeCalculate(startTime, endTime));
		return output.toString();
	}

	public String fetchFundsDetailJson(Map<String, String> map, String INFO_LOGGER_NAME) throws WebServiceClientException, NullPointerException, Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundsDetailJson", "Method start" + startTime);
		Object output = null;
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.DigitalFundPerformance.getWebServiceName());
		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {

					webserviceSource.setGetParameters(map);

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(null, webserviceSource);
				}
			}
		}

		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundsDetailJson", "Output:::" + output.toString());
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundsDetailJson", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchFundsDetailJson", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForUnitStatementCustomerDetails(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForUnitStatementCustomerDetails", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;

		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}

		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForUnitStatementCustomerDetails", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForUnitStatementCustomerDetails", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForFundTransactionDetailsData(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForFundTransactionDetailsData", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForFundTransactionDetailsData", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForFundTransactionDetailsData", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForFundTransactionDescriptionDetails(List<String> paramList, String functionality) throws Exception {

		long startTime = System.nanoTime();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForFundTransactionDescriptionDetails", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForFundTransactionDescriptionDetails", "Method end" + endTime);
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForFundTransactionDescriptionDetails", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForGetTotalUnits(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {
		Object output = null;
		try {
			long startTime = System.nanoTime();
			INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForGetTotalUnits", "Method start" + startTime);

			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForGetTotalUnits", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForGetTotalUnits", methodExcutionTimeCalculate(startTime, endTime));
		}
		catch (Exception e) {
			output = "";
			return output.toString();

		}
		return output.toString();
	}

	public String invokePrePopulateDetailsForFundName(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForFundName", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForFundName", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForFundName", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForNavValue(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNavValue", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNavValue", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNavValue", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePrePopulateDetailsForNavDate(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNavDate", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNavDate", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForNavDate", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokePmjjbyData(List<String> paramList, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePmjjbyData", "Method Start" + startTime);

		List<NomineeUpdateVo> nomineeUpdateVoList = new ArrayList<NomineeUpdateVo>();
		Client clientGet = Client.create();

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("pmjjby");
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePmjjbyData", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePmjjbyData", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeUnitStatementGratuityFundDetails(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeUnitStatementGratuityFundDetails", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeUnitStatementGratuityFundDetails", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeUnitStatementGratuityFundDetails", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeGetSingleSFIN(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {
		Object output = null;
		String output1 = "";
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetSingleSFIN", "Method start" + startTime);

		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetSingleSFIN", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetSingleSFIN", methodExcutionTimeCalculate(startTime, endTime));

		}
		catch (Exception e) {
			return output1;
		}

		return output.toString();
	}

	public String invokeGetOpeningBal(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetOpeningBal", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetOpeningBal", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetOpeningBal", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeGetUnitStmtDate(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetUnitStmtDate", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		// paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		// prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetUnitStmtDate", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetUnitStmtDate", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeGetOpeningBalNAV(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetOpeningBalNAV", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetOpeningBalNAV", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetOpeningBalNAV", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeGetClosingBal(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetClosingBal", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetClosingBal", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetClosingBal", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeGetUnitStatementGratuity(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetUnitStatementGratuity", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetUnitStatementGratuity", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetUnitStatementGratuity", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeGetClosingBalNAV(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetClosingBalNAV", "Method start" + startTime);

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetClosingBalNAV", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeGetClosingBalNAV", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String invokeClaimsPmjjbyData(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {
		Object output = null;
		try {
			long startTime = System.nanoTime();
			INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePmjjbyData", "Method Start" + startTime);

			List<NomineeUpdateVo> nomineeUpdateVoList = new ArrayList<NomineeUpdateVo>();
			Client clientGet = Client.create();

			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePmjjbyData", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePmjjbyData", methodExcutionTimeCalculate(startTime, endTime));

		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return output.toString();
	}

	public String invokePurchasePriceForIBMClaim(List<String> paramList, String functionality) throws Exception {
		Object output = null;
		try {
			long startTime = System.nanoTime();
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePurchasePriceForIBMClaim", "Method Start" + startTime);

			Client clientGet = Client.create();

			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePurchasePriceForIBMClaim", "Method end" + endTime);
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePurchasePriceForIBMClaim", methodExcutionTimeCalculate(startTime, endTime));

		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return output.toString();
	}

	public String getBusinessOverviewDetails(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBusinessOverviewDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForBusinessOverviewDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForBusinessOverviewDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "BrokerLapsedCustomerService", "LapsedCustomerDetails", "Error Occured in this method LapsedCustomerDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String brokerLapsedCustomerDetails(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "LapsedCustomerDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForLapsedCustomerDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForLapsedCustomerDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "BrokerLapsedCustomerService", "LapsedCustomerDetails", "Error Occured in this method LapsedCustomerDetails", e);

			throw new IPruException("Error", "GRPLC", "Some error occured or web service down");
		}
	}

	public static void main(String[] args) throws Exception {
		WebserviceClientConfigurator.reloadWsConfig();
		try {
			System.out.println("hi");

			List<String> paramList = new ArrayList<>();
			paramList.add("470326");

			String result = WebserviceInvoke.getInstance().invokePurchasePriceForIBMClaim(paramList, "purchasePriceIBM");

			List<AnntyClaimVO> anntyClaimVO = new Gson().fromJson(result.toString(), new TypeToken<List<AnntyClaimVO>>() {
			}.getType());

			System.out.println("Purchase price : " + anntyClaimVO.get(0).getPurchasePrice());

			/*
			 * String encryptedPath=
			 * "REU2cEdJcDE5TmtOV2o2M0tBVkRBd1BjelBpeVNGQm0vRXNGRkkwL3MrN0JWUXNqZzF0VVV3cjYrT1NGYlVaL3VsbXhZZVhhTVRjWA0Kdklmdm12dGpyc2x3eFNRVVo1dU5BWUVQNGtVcDJnTFhxNW15NG96TE0vbzFGQ1hFYkZVaVVjWVd2NFF4SnB4cEJhMkpWbjRxaXZSRg0Kby8vUjFnaGE0RFE5bTZyc1lTZTc1cnQ2b0w0RE1HTzFxaGlkVGVQZnRzY2tuTVdzTUJDeXZTTTQrUTBiTlE9PQ0K"
			 * ; String path = EncryptionPBEMD5DES.decrypt(
			 * EncodingUtility.decodeBase64(encryptedPath),
			 * EncodingUtility.CONSTANT_DOCUMENT_PATH_ENCRYPTION_KEY, 1);
			 * System.out.println(path); SecureRandom sr = new SecureRandom();
			 * String i = String.valueOf(Math.abs(sr.nextInt()/10000));
			 * BidStatementVO bidRequest=new BidStatementVO(); SimpleDateFormat
			 * format1 = new SimpleDateFormat("dd MMMM, yyyy");
			 * bidRequest.setFromDate("1 May, 2017");
			 * bidRequest.setToDate("2 May, 2017");
			 * bidRequest.setPolicyKey("9783"); bidRequest.setRequestId(i);
			 * bidRequest.setUserID("test"); PortalBIDUnitwiseResponse reposnse=
			 * WebserviceInvoke.getInstance().getBidStatementData(bidRequest);
			 * //PortalPolicySnapshotResponse reposnse=
			 * invoke.fetchBIDSummary();
			 * System.out.println(reposnse.toString()); List<BIDLine>
			 * bids=reposnse
			 * .getPortalBIDUnitwiseResult().getValue().getBIDLine();
			 * for(BIDLine bid:bids) {
			 * System.out.println(bid.getAmountCr().getValue());
			 * System.out.println(bid.getAmountDr().getValue());
			 * System.out.println(bid.getBalance().getValue());
			 * System.out.println(bid.getDate().getValue());
			 * System.out.println(bid.getModeOfPayment().getValue());
			 * System.out.println(bid.getParticulars().getValue()); }
			 */

			/*
			 * com.ipru.bulksms.beans.netCoreSmsRequest.ObjectFactory factory =
			 * new com.ipru.bulksms.beans.netCoreSmsRequest.ObjectFactory();
			 * com.ipru.bulksms.beans.netCoreSmsRequest.REQ request =
			 * factory.createREQ();
			 * com.ipru.bulksms.beans.netCoreSmsRequest.REQ.USER user =
			 * factory.createREQUSER(); user.setUSERNAME(8888800000l);
			 * user.setPASSWORD("jtgwp");
			 * com.ipru.bulksms.beans.netCoreSmsRequest.REQ.ACCOUNT account =
			 * factory.createREQACCOUNT(); account.setID(344353);
			 * List<com.ipru.bulksms.beans.netCoreSmsRequest.REQ.MESSAGE>
			 * messageList = request.getMESSAGE();
			 * com.ipru.bulksms.beans.netCoreSmsRequest.REQ.MESSAGE message =
			 * factory.createREQMESSAGE();
			 * com.ipru.bulksms.beans.netCoreSmsRequest.REQ.MESSAGE.SMS sms =
			 * factory.createREQMESSAGESMS(); sms.setFROM("ICICIPRU_MCON_HIGH");
			 * sms.setTO(919003290336l); message.setSMS(sms);
			 * message.setTEXT("Test"); messageList.add(message);
			 * request.setUSER(user); request.setACCOUNT(account);
			 * com.ipru.bulksms.beans.netCoreSmsResponse.RESULT response =
			 * WebserviceInvoke.getInstance().invokeNetCoreSmsService(request);
			 * System.out.println("Response : " + response);
			 */

			/*
			 * com.ipru.bulksms.beans.mGageSmsRequest.ObjectFactory factory =
			 * new com.ipru.bulksms.beans.mGageSmsRequest.ObjectFactory();
			 * com.ipru.bulksms.beans.mGageSmsRequest.A2Wml mGageReqObj =
			 * factory.createA2Wml();
			 * com.ipru.bulksms.beans.mGageSmsRequest.A2Wml.Request
			 * mGageSubReqObj= factory.createA2WmlRequest();
			 * com.ipru.bulksms.beans.mGageSmsRequest.A2Wml.Request.Message
			 * message = factory.createA2WmlRequestMessage();
			 * com.ipru.bulksms.beans
			 * .mGageSmsRequest.A2Wml.Request.RecipientList recList =
			 * factory.createA2WmlRequestRecipientList();
			 * List<com.ipru.bulksms.beans
			 * .mGageSmsRequest.A2Wml.Request.RecipientList.Recipient> recpList
			 * = recList.getRecipient();
			 * com.ipru.bulksms.beans.mGageSmsRequest.A2Wml
			 * .Request.RecipientList.Recipient rec =
			 * factory.createA2WmlRequestRecipientListRecipient();
			 * mGageSubReqObj.setAccId("640608");
			 * mGageSubReqObj.setPin("d@D2q!Z9");
			 * mGageSubReqObj.setFromAddress("IPRULI");
			 * message.setMessageTxt("Test");
			 * //CommonUtils.checkMobileNumbers(mobileNo);
			 * rec.setDestAddress("919003290336"); recpList.add(rec);
			 * mGageSubReqObj.setMessage(message);
			 * mGageSubReqObj.setRecipientList(recList);
			 * mGageReqObj.setRequest(mGageSubReqObj);
			 * com.ipru.bulksms.beans.mGageSmsResponse.A2Wml result =
			 * WebserviceInvoke
			 * .getInstance().invokeMgageSmsService(mGageReqObj);
			 * com.ipru.bulksms.beans.mGageSmsResponse.A2Wml.Response response =
			 * result.getResponse(); System.out.println("Response : "+response);
			 */

		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String invokePmjjbySchData(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePmjjbyData", "Method Start" + startTime);

		List<NomineeUpdateVo> nomineeUpdateVoList = new ArrayList<NomineeUpdateVo>();
		Client clientGet = Client.create();

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePmjjbyData", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePmjjbyData", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	/*
	 * public com.ipru.bulksms.beans.netCoreSmsResponse.RESULT
	 * invokeNetCoreSmsService(com.ipru.bulksms.beans.netCoreSmsRequest.REQ
	 * smsRequest) throws Exception { long startTime = System.nanoTime();
	 * FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeNetCoreSmsService", "Method start" + startTime);
	 * com.ipru.bulksms.beans.netCoreSmsResponse.RESULT wsResponse = null;
	 * @SuppressWarnings("unchecked") List<WebserviceSource> list =
	 * (ArrayList<WebserviceSource>)
	 * CacheConfigurator.getCacheElementValue(WebServiceNameEnum
	 * .NetCoreSmsProd.getWebServiceName()); Map<String, String> form = new
	 * HashMap<String, String>(1); form.put("feedId", "344353");
	 * form.put("username", "8888800000"); form.put("password", "jtgwp");
	 * form.put("senderid", "ICICIPRU_MCON_HIGH"); form.put("to", mobileNo);
	 * form.put("text", message); if (CollectionUtils.isNotEmpty(list)) { for
	 * (WebserviceSource webserviceSource : list) { if (webserviceSource !=
	 * null) { FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeNetCoreSmsService", "webserviceSource is not null"); //
	 * webserviceSource.setGetParameters(form); Object output =
	 * WebServiceClient.getInstance().invokeWsUsingHttpClient(smsRequest,
	 * webserviceSource); FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeNetCoreSmsService", "output : " + output); if (output != null) {
	 * wsResponse = (com.ipru.bulksms.beans.netCoreSmsResponse.RESULT) output;
	 * FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeNetCoreSmsService", "wsResponse  :" + wsResponse); } else {
	 * FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeNetCoreSmsService", "Null Response"); } } } } long endTime =
	 * System.nanoTime(); FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeNetCoreSmsService", "Method end" + endTime);
	 * FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeNetCoreSmsService", methodExcutionTimeCalculate(startTime,
	 * endTime)); return wsResponse; } public
	 * com.ipru.bulksms.beans.mGageSmsResponse.A2Wml
	 * invokeMgageSmsService(com.ipru.bulksms.beans.mGageSmsRequest.A2Wml
	 * smsRequest) throws Exception { long startTime = System.nanoTime();
	 * FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeMgageSmsService", "Method start" + startTime);
	 * com.ipru.bulksms.beans.mGageSmsResponse.A2Wml wsResponse = null;
	 * @SuppressWarnings("unchecked") List<WebserviceSource> list =
	 * (ArrayList<WebserviceSource>)
	 * CacheConfigurator.getCacheElementValue(WebServiceNameEnum
	 * .MGageSmsProd.getWebServiceName()); if (CollectionUtils.isNotEmpty(list))
	 * { for (WebserviceSource webserviceSource : list) { if (webserviceSource
	 * != null) { FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeMgageSmsService", "webserviceSource is not null"); Object output =
	 * WebServiceClient.getInstance().invokeWsUsingHttpClient(smsRequest,
	 * webserviceSource); FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeMgageSmsService", "output : " + output); if (output != null) {
	 * wsResponse = (com.ipru.bulksms.beans.mGageSmsResponse.A2Wml) output;
	 * FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeMgageSmsService", "wsResponse  :" + wsResponse); } else {
	 * FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeMgageSmsService", "Null Response"); } } } } long endTime =
	 * System.nanoTime(); FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeMgageSmsService", "Method end" + endTime);
	 * FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "invokeMgageSmsService", methodExcutionTimeCalculate(startTime,
	 * endTime)); return wsResponse; }
	 */

	public String getPaidCommissionPolicyEncrypt(EncryptPassword encrypted, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		String wsResponse = null;
		try {
			INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getPaidCommissionPolicyEncrypt", "Method Start" + startTime);
			ObjectFactory factory = new ObjectFactory();
			List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.BROKER.getWebServiceName());
			if (CollectionUtils.isNotEmpty(list)) {
				for (WebserviceSource webserviceSource : list) {
					if (webserviceSource != null) {
						JAXBElement output = (JAXBElement) WebServiceClient.getInstance().invokeWsUsingHttpClient(encrypted, webserviceSource);

						wsResponse = ((EncryptPasswordResponse) output.getValue()).getReturn() == null ? null : ((EncryptPasswordResponse) output.getValue()).getReturn();
					}
				}
			}
		}
		catch (Exception e) {
			wsResponse = null;
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getPaidCommissionPolicyEncrypt", "method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getPaidCommissionPolicyEncrypt", methodExcutionTimeCalculate(startTime, endTime));

		return wsResponse;
	}

	public String getTDSCertificatePolicyEncrypt(EncryptPassword encrypted, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		String wsResponse = null;
		try {
			INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getTDSCertificatePolicyEncrypt", "Method Start" + startTime);
			ObjectFactory factory = new ObjectFactory();
			List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.BROKER.getWebServiceName());
			if (CollectionUtils.isNotEmpty(list)) {
				for (WebserviceSource webserviceSource : list) {
					if (webserviceSource != null) {
						JAXBElement output = (JAXBElement) WebServiceClient.getInstance().invokeWsUsingHttpClient(encrypted, webserviceSource);

						wsResponse = ((EncryptPasswordResponse) output.getValue()).getReturn() == null ? null : ((EncryptPasswordResponse) output.getValue()).getReturn();
					}
				}
			}
		}
		catch (Exception e) {
			wsResponse = null;
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getTDSCertificatePolicyEncrypt", "method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getTDSCertificatePolicyEncryptRd", methodExcutionTimeCalculate(startTime, endTime));

		return wsResponse;
	}

	public String fetchBrokerTopCustomerDetails(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {
		Object output = null;
		String output1 = "";
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerTopCustomerDetails", "Method Start" + startTime);

		try {
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			/* Object output = null; */

			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerTopCustomerDetails", "Output:::" + output.toString());

			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerTopCustomerDetails", "Method End" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerTopCustomerDetails", methodExcutionTimeCalculate(startTime, endTime));
		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerTopCustomerDetails", "fetchBrokerTopCustomerDetails Some error occured or web service down ", e);
			throw new IPruException("Error", "GRPBTC", "Some error occured or web service down");
			// return output1;
		}

		return output.toString();
	}

	public String fetchBrokerRenewalDueDetails(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {
		Object output = null;
		String output1 = "";
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerRenewalDueDetails", "Method Start" + startTime);

		try {
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			/* Object output = null; */

			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerRenewalDueDetails", "Output:::" + output.toString());

			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerRenewalDueDetails", "Method End" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerRenewalDueDetails", methodExcutionTimeCalculate(startTime, endTime));
		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerRenewalDueDetails", "fetchBrokerTopCustomerDetails Some error occured or web service down ", e);
			throw new IPruException("Error", "GRPBRD", "Some error occured or web service down");
			// return output1;
		}

		return output.toString();
	}

	public String fetchBrokerAccruedDetails(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {
		Object output = null;
		String output1 = "";
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerRenewalDueDetails", "Method Start" + startTime);

		try {
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			/* Object output = null; */

			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerRenewalDueDetails", "Output:::" + output.toString());

			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerRenewalDueDetails", "Method End" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerRenewalDueDetails", methodExcutionTimeCalculate(startTime, endTime));
		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, "WebserviceInvoke", "fetchBrokerRenewalDueDetails", "fetchBrokerTopCustomerDetails Some error occured or web service down ", e);
			throw new IPruException("Error", "GRPBAC", "Some error occured or web service down");
			// return output1;
		}

		return output.toString();
	}

	public String getUserAuthInfoDetails(String functionality, List<String> paramList) throws Exception {

		long startTime = System.nanoTime();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getUserAuthInfoDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForgetUserAuthInfoDetails", "Method end" + endTime);
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForgetUserAuthInfoDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("WebServiceLogger", "IPruUserDetailDAOHibernateImpl", "getUserAuthInfoDetails", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String getUserAuthInfoDetails1(String functionality, List<String> paramList) throws Exception {

		long startTime = System.nanoTime();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getUserAuthInfoDetails1", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForgetUserAuthInfoDetails1", "Method end" + endTime);
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForgetUserAuthInfoDetails1", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("WebServiceLogger", "IPruUserDetailDAOHibernateImpl", "getUserAuthInfoDetails1", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String getMemberDetails(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getMemberDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetMemberDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetMemberDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "IPruUserDetailDAOHibernateImpl", "getMemberDetails", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String getTrustDetails(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getTrustDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetTrustDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetTrustDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "IPruUserDetailDAOHibernateImpl", "getTrustDetails", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String getTermDetails(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getTermDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetTermDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetTermDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "IPruUserDetailDAOHibernateImpl", "getTermDetails", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String getGTRUSTDetails(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getGTRUSTDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetGTRUSTDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetGTRUSTDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "IPruUserDetailDAOHibernateImpl", "getGTRUSTDetails", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String getLoginProductTypeDetails(String functionality, List<String> paramList1, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getLoginProductTypeDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList1);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetLoginProductTypeDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetLoginProductTypeDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "IPruUserDetailDAOHibernateImpl", "getLoginProductTypeDetails", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String invokeCoiDetails(List<String> paramList, String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeCoiDetails", "Method Start" + startTime);

		List<NomineeUpdateVo> nomineeUpdateVoList = new ArrayList<NomineeUpdateVo>();
		Client clientGet = Client.create();

		ParamObj paramObj = new ParamObj();
		paramObj.setParam(paramList);

		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality(functionality);
		prePopulateBean.setParamObj(paramObj);

		String requestString = getGsonSingleton().toJson(prePopulateBean);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeCoiDetails", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokeCoiDetails", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public PortalBIDUnitwiseResponse getBrokerBidData(BrokerBIDVO brokerBIDVO, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBidStatementData", "Method Start time" + startTime);

		ObjectFactory factory = new ObjectFactory();
		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.BidStatement.getWebServiceName());

		PortalBIDUnitwise bid = factory.createPortalBIDUnitwise();
		PortalBIDUnitwiseResponse output = null;

		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy");
		SimpleDateFormat format2 = new SimpleDateFormat("dd-MM-yy");
		String frmDate = brokerBIDVO.getFromDate();
		Date fromdate1 = (Date) format1.parse(frmDate);
		String fromDateString = format2.format(fromdate1);
		String toDate = brokerBIDVO.getToDate();
		Date toDate1 = (Date) format1.parse(toDate);
		String toDateString = format2.format(toDate1);

		GregorianCalendar c = new GregorianCalendar();
		c.setTime(format2.parse(fromDateString));

		GregorianCalendar c1 = new GregorianCalendar();
		c1.setTime(format2.parse(toDateString));

		XMLGregorianCalendar endDt = DatatypeFactory.newInstance().newXMLGregorianCalendar(c1);
		XMLGregorianCalendar startDt = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		bid.setEndDt(endDt);
		bid.setStartDt(startDt);
		bid.setPolicyKey(new BigDecimal(brokerBIDVO.getPolicyKey()));
		bid.setRequestId(factory.createPortalBIDUnitwiseRequestId(brokerBIDVO.getRequestId()));
		bid.setUnitCode(factory.createPortalBIDUnitwiseUnitCode(brokerBIDVO.getUnitCode()));
		bid.setUserID(factory.createPortalBIDUnitwiseUserID(brokerBIDVO.getUserID()));
		// bid.setEndDt(endDt);

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {
					// //System.out.println(ToStringBuilder.reflectionToString(webserviceSource));
					output = (PortalBIDUnitwiseResponse) WebServiceClient.getInstance().invokeWsUsingHttpClient(bid, webserviceSource);
					// ////System.out.println("\nResponse  :"+output);

				}
			}
		}

		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBidStatementData", "Output:::" + output.toString());
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBidStatementData", "Method End" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBidStatementData", methodExcutionTimeCalculate(startTime, endTime));
		return output;
	}

	/*
	 * public String sendEmailAttacment(InsertFileToDb insertFile) { // TODO
	 * Auto-generated method stub long startTime = System.nanoTime(); String
	 * wsResponse=null; try{ FLogger.info("WebServiceLogger",
	 * "WebserviceInvoke", "sendEmailAttacment", "Method Start" + startTime);
	 * ObjectFactory factory = new ObjectFactory(); List<WebserviceSource> list
	 * = (ArrayList<WebserviceSource>)
	 * CacheConfigurator.getCacheElementValue(WebServiceNameEnum
	 * .EmailAttachment.getWebServiceName()); if
	 * (CollectionUtils.isNotEmpty(list)) { for (WebserviceSource
	 * webserviceSource : list) { if (webserviceSource != null) { //JAXBElement
	 * output = (JAXBElement)
	 * WebServiceClient.getInstance().invokeWsUsingHttpClient(insertFile,
	 * webserviceSource);
	 * //wsResponse=((InsertFileToDbResponse)output.getValue()
	 * ).getInsertFileToDbReturn
	 * ()==null?null:((InsertFileToDbResponse)output.getValue
	 * ()).getInsertFileToDbReturn(); } } } } catch(Exception e) {
	 * wsResponse=null; } long endTime = System.nanoTime();
	 * FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "sendEmailAttacment", "method end" + endTime);
	 * FLogger.info("WebServiceLogger", "WebserviceInvoke",
	 * "sendEmailAttacment", methodExcutionTimeCalculate(startTime, endTime));
	 * return wsResponse; }
	 */
	public String fetchBrokerBranchAndNational(String functionality, List paramList, String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getUserAuthInfoDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetUserAuthInfoDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetUserAuthInfoDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "IPruUserDetailDAOHibernateImpl", "getUserAuthInfoDetails", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String fetchBrokerBranch(String functionality, List paramList, String INFO_LOGGER_NAME) throws WebServiceClientException, Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getUserAuthInfoDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetUserAuthInfoDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetUserAuthInfoDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "IPruUserDetailDAOHibernateImpl", "getUserAuthInfoDetails", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}

	}

	public String getUserDataList(String functionality, Map<String, Object> params, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getUserDataList", "Method start" + startTime);
		try {
			/*
			 * List<String> paramList=new ArrayList<String>(1);
			 * paramList.addAll(params);
			 */

			ParamObj paramObj = new ParamObj();
			paramObj.setParamMap(params);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsFor getUserDataList", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetUserDataList", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "BusinessOverviewService", "getBusinessOverviewDetails", "Error Occured in this method getBusinessOverviewDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String getLoginProductType(String functionality, List<String> paramList1, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getLoginProductTypeDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList1);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetLoginProductTypeDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForgetLoginProductTypeDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "IPruUserDetailDAOHibernateImpl", "getLoginProductTypeDetails", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String invokePrePopulateDetailsForFscDetailsFind(FscDetailsVO fscdetails2, String INFO_LOGGER_NAME) throws Exception {
		// TODO Auto-generated method stub
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiPanNumber", "Method Start" + startTime);

		// ParamObj paramObj = new ParamObj();
		// paramObj.setParam(fscdetails2);

		/*
		 * PrePopulateBean prePopulateBean = new PrePopulateBean();
		 * prePopulateBean.setFunctionality("getFscDetailsQuerry");
		 * prePopulateBean.setParamObj(paramObj);
		 */
		// FscDetailsVO fscdetails=new FscDetailsVO();
		// fscdetails.setFsc_client_id(fscdetails2);

		String requestString = getGsonSingleton().toJson(fscdetails2);

		Object output = null;
		List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.FscDetails.getWebServiceName());
		if (CollectionUtils.isNotEmpty(webList)) {
			for (WebserviceSource webserviceSource : webList) {
				if (webserviceSource != null) {

					output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
				}
			}
		}
		long endTime = System.nanoTime();
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiPanNumber", "Method end" + endTime);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForCoiPanNumber", methodExcutionTimeCalculate(startTime, endTime));

		return output.toString();
	}

	public String getClickPssEncryptedData(String jsonString, String env) throws Exception {
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getClickPssEncryptedData", "method start");
		Object responseType = null;
		ClickPssResponse clikPssResp = null;
		String clickPSSUrl = null;
		long startTime = System.currentTimeMillis();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getClickPssEncryptedData", "webservice start time in miliseconds..." + startTime);

		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getClickPssEncryptedData", "web service request sent for ClickPSS::" + jsonString);

		List<WebserviceSource> webList = null;

		webList = env.equals("UAT") ? (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("GETTOKENWITHENCRYPTEDDATA_UAT") : (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue("GETTOKENWITHENCRYPTEDDATA_PROD");

		responseType = (Object) WebServiceClient.invokeWsUsingHttpClient1(webList, jsonString);
		// System.out.println("responseType"+responseType);
		if (responseType != null) {
			clikPssResp = getGsonSingletonStatic().fromJson(responseType.toString(), ClickPssResponse.class);
			if (clikPssResp != null)
				clickPSSUrl = clikPssResp.getUrl();
		}

		long endTime = System.currentTimeMillis();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getClickPssEncryptedData", "webservice end time in miliseconds..." + endTime);
		return clickPSSUrl;
	}

	public String getLoggerName(String INFO_LOGGER_NAME, String WebServiceLogger) {
		return StringUtils.isEmpty(INFO_LOGGER_NAME) ? "WebServiceLogger" : INFO_LOGGER_NAME;

	}

	public String fetchBrokerBranchPolicyList(String functionality, List paramList) throws Exception {
		// TODO Auto-generated method stub

		long startTime = System.nanoTime();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getUserAuthInfoDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForgetUserAuthInfoDetails", "Method end" + endTime);
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForgetUserAuthInfoDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("WebServiceLogger", "IPruUserDetailDAOHibernateImpl", "getUserAuthInfoDetails", "Error Occured in this method getUserAuthInfoDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String brokerBidDetail(String functionality, List<String> paramList) throws Exception {

		long startTime = System.nanoTime();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "brokerBidDetail", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {
						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForLapsedCustomerDetails", "Method end" + endTime);
			FLogger.info("WebServiceLogger", "WebserviceInvoke", "invokePrePopulateDetailsForLapsedCustomerDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("BrokerBIDLogger", "BrokerBIDServiceImpl", "brokerBidDetail", "Error Occured in this method LapsedCustomerDetails", e);

			throw new IPruException("Error", "GRPLC", "Some error occured or web service down");
		}
	}

	public String fetchSignUpMasterSheetDetails(SignUpPolicyDetailsVO signUpPolicyDetailsVO, String LOGGER_NAME) throws Exception {
		final String METHOD_NAME = "fetchMasterSheetDetails";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		Object output = null;
		try {
			List paramList = null;
			if (signUpPolicyDetailsVO != null) {
				paramList = new ArrayList();
				paramList.add(signUpPolicyDetailsVO.getPolicyNo());
				paramList.add(signUpPolicyDetailsVO.getEmpId());
				paramList.add(signUpPolicyDetailsVO.getDob());
			}
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality("SignUpMasterSheetDetails");
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end" + endTime);
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came : ", e);
			output = "";
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return output.toString();
	}

	/* Broker Bid Summary method Start */

	public PortalPolicySnapshotResponse fetchBrokerBidSummary(String policyKey, String unitCode, String LOGGERNAME) throws WebServiceClientException, Exception {

		long startTime = System.nanoTime();
		FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchBrokerBidSummary", "Method Start" + startTime);

		List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.BIDSummary.getWebServiceName());

		PortalPolicySnapshotResponse output = null;

		SecureRandom sr = new SecureRandom();
		String i = String.valueOf(Math.abs(sr.nextInt() / 10000));

		ObjectFactory factory = new ObjectFactory();

		PortalPolicySnapshot policySnapshot = factory.createPortalPolicySnapshot();

		policySnapshot.setPolicyKey(factory.createPortalPolicySnapshotPolicyKey(new BigDecimal(policyKey)));
		policySnapshot.setRequestId(factory.createPortalPolicySnapshotRequestId(i));
		policySnapshot.setUnitCode(factory.createPortalPolicySnapshotUnitCode(unitCode));
		policySnapshot.setUserId(factory.createPortalPolicySnapshotUserId("test"));

		if (CollectionUtils.isNotEmpty(list)) {
			for (WebserviceSource webserviceSource : list) {
				if (webserviceSource != null) {

					output = (PortalPolicySnapshotResponse) WebServiceClient.getInstance().invokeWsUsingHttpClient(policySnapshot, webserviceSource);

				}
			}
		}

		FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchBrokerBidSummary", "Output:::" + output.toString());
		long endTime = System.nanoTime();
		FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchBrokerBidSummary", "Method End" + endTime);
		FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchBrokerBidSummary", methodExcutionTimeCalculate(startTime, endTime));
		return output;

	}

	/* Broker Bid Summary method end */

	public String fetchDashboardDetails(String functionality, List<String> paramList, String LOGGERNAME) throws WebServiceClientException, Exception {
		Object output = null;
		String output1 = "";
		long startTime = System.nanoTime();
		this.getLoggerName(LOGGERNAME, WEBSERVICELOGGER);
		FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchDashboardDetails", "Method Start" + startTime);

		try {
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			/* Object output = null; */

			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchDashboardDetails", "Output:::" + output.toString());

			long endTime = System.nanoTime();
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchDashboardDetails", "Method End" + endTime);
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchDashboardDetails", methodExcutionTimeCalculate(startTime, endTime));
		}
		catch (Exception e) {
			FLogger.error("WebServiceLogger", "WebserviceInvoke", "fetchDashboardDetails", "fetchDashboardDetails Some error occured or web service down ", e);
			throw new IPruException("Error", "GRPBAC", "Some error occured or web service down");
			// return output1;
		}

		return output.toString();
	}

	public String fetchDashboardTrustDetails(String functionality, List<String> paramList, String LOGGERNAME) throws WebServiceClientException, Exception {
		Object output = null;
		String output1 = "";
		long startTime = System.nanoTime();
		this.getLoggerName(LOGGERNAME, WEBSERVICELOGGER);
		FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchDashboardDetails", "Method Start" + startTime);

		try {
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			/* Object output = null; */

			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchDashboardDetails", "Output:::" + output.toString());

			long endTime = System.nanoTime();
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchDashboardDetails", "Method End" + endTime);
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "fetchDashboardDetails", methodExcutionTimeCalculate(startTime, endTime));
		}
		catch (Exception e) {
			FLogger.error(LOGGERNAME, "WebserviceInvoke", "fetchDashboardDetails", "fetchDashboardDetails Some error occured or web service down ", e);
			throw new IPruException("Error", "GRPBAC", "Some error occured or web service down");
			// return output1;
		}

		return output.toString();
	}

	public String getClickPssEncryptedDataForCOI(String jsonString, String env) throws Exception {
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getClickPssEncryptedData", "method start");
		Object responseType = null;
		ClickPssResponse clikPssResp = null;
		String clickPSSUrl = null;
		long startTime = System.currentTimeMillis();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getClickPssEncryptedData", "webservice start time in miliseconds..." + startTime);

		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getClickPssEncryptedData", "web service request sent for ClickPSS::" + jsonString);

		List<WebserviceSource> webList = null;

		// webList = env.equals("UAT") ? (ArrayList<WebserviceSource>)
		// CacheConfigurator.getCacheElementValue("GETTOKENWITHENCRYPTEDDATA_UAT1")
		// : (ArrayList<WebserviceSource>)
		// CacheConfigurator.getCacheElementValue("GETTOKENWITHENCRYPTEDDATA_PROD1");
		webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.GETTOKENWITHENCRYPTEDDATA.getWebServiceName());

		responseType = (Object) WebServiceClient.invokeWsUsingHttpClient1(webList, jsonString);
		// System.out.println("responseType"+responseType);
		if (responseType != null) {
			clikPssResp = getGsonSingletonStatic().fromJson(responseType.toString(), ClickPssResponse.class);
			if (clikPssResp != null)
				clickPSSUrl = clikPssResp.getUrl();
		}

		long endTime = System.currentTimeMillis();
		FLogger.info("WebServiceLogger", "WebserviceInvoke", "getClickPssEncryptedData", "webservice end time in miliseconds..." + endTime);
		return clickPSSUrl;
	}

	public String getCountryDetails(String functionality, String INFO_LOGGER_NAME) throws Exception {

		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getCountryDetails", "Method start" + startTime);
		try {

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getCountryDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getCountryDetails", methodExcutionTimeCalculate(startTime, endTime));

			return output.toString();
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "BrokerLapsedCustomerService", "LapsedCustomerDetails", "Error Occured in this method LapsedCustomerDetails", e);

			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}

	public String getIsValidUserForSwitch(String functionality, List<String> paramList, String LOGGERNAME) throws WebServiceClientException, Exception {
		Object output = null;
		String output1 = "";
		long startTime = System.nanoTime();
		this.getLoggerName(LOGGERNAME, WEBSERVICELOGGER);
		FLogger.info(LOGGERNAME, "WebserviceInvoke", "getIsValidUserForSwitch", "Method Start" + startTime);

		try {
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			/* Object output = null; */

			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);

					}
				}
			}
			// FLogger.info(LOGGERNAME, "WebserviceInvoke",
			// "getIsValidUserForSwitch", "Output:::" + output.toString());

			long endTime = System.nanoTime();
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "getIsValidUserForSwitch", "Method End" + endTime);
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "getIsValidUserForSwitch", methodExcutionTimeCalculate(startTime, endTime));
		}
		catch (Exception e) {
			if (e.getMessage().equals("Webservice is down")) {
				return null;
			}
			else {
				FLogger.error(LOGGERNAME, "WebserviceInvoke", "getIsValidUserForSwitch", "getIsValidUserForSwitch Some error occured or web service down ", e);
				throw new IPruException("Error", "GRPBAC", "Some error occured or web service down");
			}
			// return output1;
		}

		return output != null ? output.toString() : null;
	}

	public String getCountOfDataWithSamePolicyNo(String functionality1, List<String> paramList1, String LOGGERNAME) throws WebServiceClientException, Exception {
		Object output = null;
		String output1 = "";
		long startTime = System.nanoTime();
		this.getLoggerName(LOGGERNAME, WEBSERVICELOGGER);
		FLogger.info(LOGGERNAME, "WebserviceInvoke", "getCountOfDataWithSamePolicyNo", "Method Start" + startTime);

		try {
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			/* Object output = null; */

			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList1);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality1);
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "getCountOfDataWithSamePolicyNo", "Output:::" + output.toString());

			long endTime = System.nanoTime();
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "getCountOfDataWithSamePolicyNo", "Method End" + endTime);
			FLogger.info(LOGGERNAME, "WebserviceInvoke", "getCountOfDataWithSamePolicyNo", methodExcutionTimeCalculate(startTime, endTime));
		}
		catch (Exception e) {
			FLogger.error(LOGGERNAME, "WebserviceInvoke", "getCountOfDataWithSamePolicyNo", "getCountOfDataWithSamePolicyNo Some error occured or web service down ", e);
			throw new IPruException("Error", "GRPBAC", "Some error occured or web service down");
			// return output1;
		}

		return output.toString();
	}
	
	
	
	//Akmal Added Broker Bid PolicyKey Method
	public String fetchBrokerPolicyKey(String functionality, List<String> paramList, String INFO_LOGGER_NAME) throws Exception {
		long startTime = System.nanoTime();
		INFO_LOGGER_NAME = this.getLoggerName(INFO_LOGGER_NAME, WEBSERVICELOGGER);
		FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "getBusinessOverviewDetails", "Method start" + startTime);
		try {
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);
			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality(functionality);
			prePopulateBean.setParamObj(paramObj);
			String requestString = getGsonSingleton().toJson(prePopulateBean);
			Object output = null;
			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {
						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForBusinessOverviewDetails", "Method end" + endTime);
			FLogger.info(INFO_LOGGER_NAME, "WebserviceInvoke", "invokePrePopulateDetailsForBusinessOverviewDetails", methodExcutionTimeCalculate(startTime, endTime));
			return output.toString();
		}

		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, "BrokerLapsedCustomerService", "LapsedCustomerDetails", "Error Occured in this method LapsedCustomerDetails", e);
			throw new IPruException("Error", "GRPBO", "Some error occured or web service down");
		}
	}
	
	//Nagaraj Added for SignUp functionality to check Data in policy_delink table
	public String checkDataInDeLink(SignUpPolicyDetailsVO signUpPolicyDetailsVO, String LOGGER_NAME) throws Exception {
		final String METHOD_NAME = "checkDataInDeLink";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		Object output = null;
		try {
			List paramList = null;
			if (signUpPolicyDetailsVO != null) {
				paramList = new ArrayList();
				paramList.add(signUpPolicyDetailsVO.getPolicyNo());
				paramList.add(signUpPolicyDetailsVO.getEmpId());
				
			}
			ParamObj paramObj = new ParamObj();
			paramObj.setParam(paramList);

			PrePopulateBean prePopulateBean = new PrePopulateBean();
			prePopulateBean.setFunctionality("SignUpCheckInDeLink");
			prePopulateBean.setParamObj(paramObj);

			String requestString = getGsonSingleton().toJson(prePopulateBean);

			List<WebserviceSource> webList = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.PrePopulateDetails.getWebServiceName());
			if (CollectionUtils.isNotEmpty(webList)) {
				for (WebserviceSource webserviceSource : webList) {
					if (webserviceSource != null) {

						output = (Object) WebServiceClient.getInstance().invokeWsUsingHttpClient(requestString, webserviceSource);
					}
				}
			}
			long endTime = System.nanoTime();
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end" + endTime);
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came : ", e);
			output = "";
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return output.toString();
	}
	
	// Digital Life Verification Code to fetch annuitants/pensioners details from SOAP webservice(informatica) 
	public String fetchDigiLifeVerifiDetails(DigitalLifeVerificationVO digitalLifeVerificationVO,String LOGGER_NAME)
	{
		Gson gson = new Gson();
		String jsonString=null;
		final String METHOD_NAME = "fetchDigiLifeVerifiDetails";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		IAXISDIGILIFEVERIFICATIONResponseElement iaxisdigilifeverificationResponse = null;
		IAXISDIGILIFEVERIFICATIONRequestType iaxisdigilifeverificationRequestType = new IAXISDIGILIFEVERIFICATIONRequestType();
		IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement iaxisdigilifeverificationRequest = new IAXISDIGILIFEVERIFICATIONRequestType.IAXISDIGILIFEVERIFICATIONRequestElement();
		 
		try
		{
			iaxisdigilifeverificationRequest.setCONTRACTID(digitalLifeVerificationVO.getContractid());
			iaxisdigilifeverificationRequestType.setIAXISDIGILIFEVERIFICATIONRequestElement(iaxisdigilifeverificationRequest);
			List<WebserviceSource> list = (ArrayList<WebserviceSource>) CacheConfigurator.getCacheElementValue(WebServiceNameEnum.DIGILIFE_VERIFICATION.getWebServiceName());
			Map<String, String> map = new HashMap<String, String>();
			if (CollectionUtils.isNotEmpty(list)) {
				for (WebserviceSource webserviceSource : list) {
					if (webserviceSource != null) {
						
						
						JAXBElement<IAXISDIGILIFEVERIFICATIONResponseType> response = (JAXBElement<IAXISDIGILIFEVERIFICATIONResponseType>) WebServiceClient.getInstance().invokeWsUsingHttpClient(iaxisdigilifeverificationRequestType, webserviceSource);
						iaxisdigilifeverificationResponse =  response.getValue().getIAXISDIGILIFEVERIFICATIONResponseElement().get(0);	
					}
				}
			}
			
			 jsonString = gson.toJson(iaxisdigilifeverificationResponse);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came : ", e);
		}
		
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return jsonString;
	}
	
	
}
