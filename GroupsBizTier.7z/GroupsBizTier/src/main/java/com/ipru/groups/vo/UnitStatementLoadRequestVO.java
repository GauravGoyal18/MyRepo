package com.ipru.groups.vo;

import java.util.List;

import com.tcs.web.vo.BaseVO;

public class UnitStatementLoadRequestVO extends BaseVO{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String policyNo;
	private String role;
	private String clientId;
	private String screenName;
	

	private List<RoleScreenAccessMappingVO> accessMappingList;
	private List<FieldAccessMappingVO> fieldAccessMappingList;

	public UnitStatementLoadRequestVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public void setRole(String role) {
		this.role = role;
	}


	



	public List<RoleScreenAccessMappingVO> getAccessMappingList() {
		return accessMappingList;
	}

	public void setAccessMappingList(List<RoleScreenAccessMappingVO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}

	
	public List<FieldAccessMappingVO> getFieldAccessMappingList() {
		return fieldAccessMappingList;
	}

	public void setFieldAccessMappingList(
			List<FieldAccessMappingVO> fieldAccessMappingList) {
		this.fieldAccessMappingList = fieldAccessMappingList;
	}



	public String getScreenName() {
		return screenName;
	}



	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}



	@Override
	public String toString() {
		return "UnitStatementLoadRequestVO [policyNo=" + policyNo + ", role="
				+ role + ", clientId=" + clientId + ", screenName="
				+ screenName + ", accessMappingList=" + accessMappingList
				+ ", fieldAccessMappingList=" + fieldAccessMappingList + "]";
	}
	
	
	public UnitStatementLoadRequestVO(String policyNo, String role,
			String screenName, String clientId,
			List<RoleScreenAccessMappingVO> accessMappingList,
			List<FieldAccessMappingVO> fieldAccessMappingList) {
		super();
		this.policyNo = policyNo;
		this.role = role;
		this.screenName=screenName;
		this.clientId = clientId;
		this.accessMappingList = accessMappingList;
		this.fieldAccessMappingList = fieldAccessMappingList;
	}

	
	
}
