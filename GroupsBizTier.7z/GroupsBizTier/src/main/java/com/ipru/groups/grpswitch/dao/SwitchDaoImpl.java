package com.ipru.groups.grpswitch.dao;

import java.math.BigDecimal;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ipru.groups.grpswitch.bean.SwitchTransactionVO;
import com.ipru.groups.interceptor.GroupBaseDao;
import com.tcs.logger.FLogger;
import com.tcs.vo.BaseVO;

public class SwitchDaoImpl extends GroupBaseDao<BaseVO, Integer>  {
	
	private Session session=null;
	private boolean status=false;
	
	public SwitchDaoImpl(String moduleName) {
		super(moduleName);
	}
	
	public boolean checkOneSwitchPerDay(String clientId)throws NullPointerException,Exception{
		FLogger.info("SwitchLogger", "SwitchDaoImpl", "checkOneSwitchPerDay","Entered saveSwitch");
		session=getSession();
		
		String query = session.getNamedQuery("SwitchTransaction.countNoOfSwitchPerDay").getQueryString();
		BigDecimal counterList = (BigDecimal)session.createSQLQuery(query)
				.setParameter("clientId", clientId)
				//.setParameter("reqExecutionDate", switchDate)
				.uniqueResult();
		if (counterList != null && counterList.intValue() > 0)
			return Boolean.TRUE;
		
		FLogger.info("SwitchLogger", "SwitchDaoImpl", "checkOneSwitchPerDay","Exited saveSwitch");
		return status;
	}
	
	
	

	public SwitchTransactionVO saveSwitch(SwitchTransactionVO switchTransactionVO) throws Exception {
		
		FLogger.info("SwitchLogger", "SwitchDaoImpl", "saveSwitch","Entered saveSwitch");
		Transaction tx = null;
		session = getSession();
		try{
			
			tx = session.beginTransaction();
	
			session.save(switchTransactionVO);
			
			tx.commit();
			
			FLogger.info("SwitchLogger", "SwitchDaoImpl", "saveSwitch","Exited saveSwitch");
			return switchTransactionVO;
						
		}
		catch (Exception e) {
			tx.rollback();
			FLogger.error("SwitchLogger", "SwitchDaoImpl", "saveSwitch","Exception Occurred");

			throw e;
		}
		finally {
			if (session != null && session.isOpen()) {
				session.flush();
				session.close();
				session = null;
			}

		}

	}
	
	

}
