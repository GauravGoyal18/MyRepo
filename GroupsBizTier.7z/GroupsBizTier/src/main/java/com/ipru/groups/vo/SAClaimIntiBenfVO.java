package com.ipru.groups.vo;

import java.io.Serializable;


public class SAClaimIntiBenfVO implements Serializable {

	private static final long serialVersionUID = 1L;

	
	private Long benefId;
	private String salutation;
	private String firstName;
	private String lastName;
	private String bankName;
	private String branch;
	private String accountNumber;
	private String dateOfBirth;
	private String gender;
	private String ageProof;
	private String relationShipWithMember;
	private String category;
	private String compBuildName;
	private String flatUnitNo;
	private String streetArea;
	private String state;
	private String city;
	private String pincode;
	private String mobileNumber;
	private String emailId;
	private String appointeeFName;
	private String appointeeLName;
	private String appointeeRelation;
	private String annuitantDateofBirth;
	private String annuSalutation;
	private String annuFirstName;
	private String annuLastName;
	private String annuDOB;
	
	
	
	public String getAnnuDOB() {
		return annuDOB;
	}

	public void setAnnuDOB(String annuDOB) {
		this.annuDOB = annuDOB;
	}

	public String getAnnuitantDateofBirth() {
		return annuitantDateofBirth;
	}

	public void setAnnuitantDateofBirth(String annuitantDateofBirth) {
		this.annuitantDateofBirth = annuitantDateofBirth;
	}

	public String getAnnuSalutation() {
		return annuSalutation;
	}

	public void setAnnuSalutation(String annuSalutation) {
		this.annuSalutation = annuSalutation;
	}

	public String getAnnuFirstName() {
		return annuFirstName;
	}

	public void setAnnuFirstName(String annuFirstName) {
		this.annuFirstName = annuFirstName;
	}

	public String getAnnuLastName() {
		return annuLastName;
	}

	public void setAnnuLastName(String annuLastName) {
		this.annuLastName = annuLastName;
	}

	private transient SAClaimIntimationVO sAClaimIntimationVO;
	
	public String getAppointeeFName() {
		return appointeeFName;
	}

	public void setAppointeeFName(String appointeeFName) {
		this.appointeeFName = appointeeFName;
	}

	public String getAppointeeLName() {
		return appointeeLName;
	}

	public void setAppointeeLName(String appointeeLName) {
		this.appointeeLName = appointeeLName;
	}

	public String getAppointeeRelation() {
		return appointeeRelation;
	}

	public void setAppointeeRelation(String appointeeRelation) {
		this.appointeeRelation = appointeeRelation;
	}

	

	public Long getBenefId() {
		return benefId;
	}

	public void setBenefId(Long benefId) {
		this.benefId = benefId;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAgeProof() {
		return ageProof;
	}

	public void setAgeProof(String ageProof) {
		this.ageProof = ageProof;
	}

	public String getRelationShipWithMember() {
		return relationShipWithMember;
	}

	public void setRelationShipWithMember(String relationShipWithMember) {
		this.relationShipWithMember = relationShipWithMember;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCompBuildName() {
		return compBuildName;
	}

	public void setCompBuildName(String compBuildName) {
		this.compBuildName = compBuildName;
	}

	public String getFlatUnitNo() {
		return flatUnitNo;
	}

	public void setFlatUnitNo(String flatUnitNo) {
		this.flatUnitNo = flatUnitNo;
	}

	public String getStreetArea() {
		return streetArea;
	}

	public void setStreetArea(String streetArea) {
		this.streetArea = streetArea;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public SAClaimIntimationVO getsAClaimIntimationVO() {
		return sAClaimIntimationVO;
	}

	public void setsAClaimIntimationVO(SAClaimIntimationVO sAClaimIntimationVO) {
		this.sAClaimIntimationVO = sAClaimIntimationVO;
	}

	@Override
	public String toString() {
		return "SAClaimIntiBenfVO [benefId=" + benefId + ", salutation="
				+ salutation + ", firstName=" + firstName + ", lastName="
				+ lastName + ", bankName=" + bankName + ", branch=" + branch
				+ ", accountNumber=" + accountNumber + ", dateOfBirth="
				+ dateOfBirth + ", gender=" + gender + ", ageProof=" + ageProof
				+ ", relationShipWithMember=" + relationShipWithMember
				+ ", category=" + category + ", compBuildName=" + compBuildName
				+ ", flatUnitNo=" + flatUnitNo + ", streetArea=" + streetArea
				+ ", state=" + state + ", city=" + city + ", pincode="
				+ pincode + ", mobileNumber=" + mobileNumber + ", emailId="
				+ emailId + ", appointeeFName=" + appointeeFName
				+ ", appointeeLName=" + appointeeLName + ", appointeeRelation="
				+ appointeeRelation + ", annuitantDateofBirth="
				+ annuitantDateofBirth + ", annuSalutation=" + annuSalutation
				+ ", annuFirstName=" + annuFirstName + ", annuLastName="
				+ annuLastName + ", annuDOB=" + annuDOB + "]";
	}

	
}
