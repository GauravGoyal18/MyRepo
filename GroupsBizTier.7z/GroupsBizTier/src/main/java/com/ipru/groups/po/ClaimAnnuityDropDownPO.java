package com.ipru.groups.po;

import java.util.List;

public class ClaimAnnuityDropDownPO extends GroupsBasePo {

	private List maritalStatusList;
	private List paymentModeList;
	private List penPayList;
	private List salutationList;
	private List genderList;

	public List getGenderList() {
		return genderList;
	}

	public void setGenderList(List genderList) {
		this.genderList = genderList;
	}

	public List getMaritalStatusList() {
		return maritalStatusList;
	}

	public void setMaritalStatusList(List maritalStatusList) {
		this.maritalStatusList = maritalStatusList;
	}

	public List getPaymentModeList() {
		return paymentModeList;
	}

	public void setPaymentModeList(List paymentModeList) {
		this.paymentModeList = paymentModeList;
	}

	public List getPenPayList() {
		return penPayList;
	}

	public void setPenPayList(List penPayList) {
		this.penPayList = penPayList;
	}

	public List getSalutationList() {
		return salutationList;
	}

	public void setSalutationList(List salutationList) {
		this.salutationList = salutationList;
	}

}
