package com.ipru.groups.po;

import java.util.Date;

public class ClaimsBenPMJJBYSubmitPO extends GroupsBasePo {

	private String beneficiaryName;
	private String relation;
	private String sharePercentage;
	private String beneficiaryDOB;
	private String gender;
	private String mobileNumber;
	private String benAddress;
	private String city;
	private String pincode;
	private String typeOfPayment;
	private String micrCode;
	private String ifscCode;
	private String bankName;
	private String bankAcc;
	private String bankAddress;
	private String beneficiaryPos;

	public String getBeneficiaryPos() {
		return beneficiaryPos;
	}

	public void setBeneficiaryPos(String beneficiaryPos) {
		this.beneficiaryPos = beneficiaryPos;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getSharePercentage() {
		return sharePercentage;
	}

	public void setSharePercentage(String sharePercentage) {
		this.sharePercentage = sharePercentage;
	}

	public String getBeneficiaryDOB() {
		return beneficiaryDOB;
	}

	public void setBeneficiaryDOB(String beneficiaryDOB) {
		this.beneficiaryDOB = beneficiaryDOB;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getBenAddress() {
		return benAddress;
	}

	public void setBenAddress(String benAddress) {
		this.benAddress = benAddress;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getTypeOfPayment() {
		return typeOfPayment;
	}

	public void setTypeOfPayment(String typeOfPayment) {
		this.typeOfPayment = typeOfPayment;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAcc() {
		return bankAcc;
	}

	public void setBankAcc(String bankAcc) {
		this.bankAcc = bankAcc;
	}

	public String getBankAddress() {
		return bankAddress;
	}

	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress;
	}

}
