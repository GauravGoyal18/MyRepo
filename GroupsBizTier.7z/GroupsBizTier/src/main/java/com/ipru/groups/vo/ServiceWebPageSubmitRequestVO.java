package com.ipru.groups.vo;

import java.util.List;

import com.ipru.groups.po.UploadFilePO;
import com.tcs.vo.BaseVO;

public class ServiceWebPageSubmitRequestVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNumber;
	private ServiceWebPageMenuVO selectedMenu;
	private String detailOfRequest;
	private String clientId;
	private List<UploadFileVO> uploadFileList;
	private String screenName;
	private long functionalityId;

	public ServiceWebPageSubmitRequestVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceWebPageSubmitRequestVO(String policyNumber, ServiceWebPageMenuVO selectedMenu, String detailOfRequest, String clientId, List<UploadFileVO> uploadFileList, String screenName, long functionalityId) {
		super();
		this.policyNumber = policyNumber;
		this.selectedMenu = selectedMenu;
		this.detailOfRequest = detailOfRequest;
		this.clientId = clientId;
		this.uploadFileList = uploadFileList;
		this.screenName = screenName;
		this.functionalityId = functionalityId;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public ServiceWebPageMenuVO getSelectedMenu() {
		return selectedMenu;
	}

	public void setSelectedMenu(ServiceWebPageMenuVO selectedMenu) {
		this.selectedMenu = selectedMenu;
	}

	public String getDetailOfRequest() {
		return detailOfRequest;
	}

	public void setDetailOfRequest(String detailOfRequest) {
		this.detailOfRequest = detailOfRequest;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public List<UploadFileVO> getUploadFileList() {
		return uploadFileList;
	}

	public void setUploadFileList(List<UploadFileVO> uploadFileList) {
		this.uploadFileList = uploadFileList;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public long getFunctionalityId() {
		return functionalityId;
	}

	public void setFunctionalityId(long functionalityId) {
		this.functionalityId = functionalityId;
	}

	@Override
	public String toString() {
		return "ServiceWebPageSubmitRequestVO [policyNumber=" + policyNumber + ", selectedMenu=" + selectedMenu + ", detailOfRequest=" + detailOfRequest + ", clientId=" + clientId
				+ ", uploadFileList=" + uploadFileList + ", screenName=" + screenName + ", functionalityId=" + functionalityId + "]";
	}

}
