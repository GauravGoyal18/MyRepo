package com.ipru.groups.po;

import java.util.Set;

import com.ipru.groups.vo.NomineeBenPMJJBYSubmitVO;
import com.tcs.web.po.BasePO;

public class NomineePMJJBYPO extends BasePO {
	
	private String policyNo;
	String schemeName;
	String accountNumber;
	private Set<NomineeBenPMJJBYSubmitPO> beneficiary;
	
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Set<NomineeBenPMJJBYSubmitPO> getBeneficiary() {
		return beneficiary;
	}
	public void setBeneficiary(Set<NomineeBenPMJJBYSubmitPO> beneficiary) {
		this.beneficiary = beneficiary;
	}
	

}
