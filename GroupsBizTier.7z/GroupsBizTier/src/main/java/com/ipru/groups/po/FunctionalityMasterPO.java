package com.ipru.groups.po;

import java.io.Serializable;

public class FunctionalityMasterPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long functionalityId;
	private String functionalityName;
	private String screenCode;

	public FunctionalityMasterPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FunctionalityMasterPO(long functionalityId, String functionalityName, String screenCode) {
		super();
		this.functionalityId = functionalityId;
		this.functionalityName = functionalityName;
		this.screenCode = screenCode;
	}

	public long getFunctionalityId() {
		return functionalityId;
	}

	public void setFunctionalityId(long functionalityId) {
		this.functionalityId = functionalityId;
	}

	public String getFunctionalityName() {
		return functionalityName;
	}

	public void setFunctionalityName(String functionalityName) {
		this.functionalityName = functionalityName;
	}

	public String getScreenCode() {
		return screenCode;
	}

	public void setScreenCode(String screenCode) {
		this.screenCode = screenCode;
	}

	@Override
	public String toString() {
		return "FunctionalityMasterPO [functionalityId=" + functionalityId + ", functionalityName=" + functionalityName + ", screenCode=" + screenCode + "]";
	}

}
