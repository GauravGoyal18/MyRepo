package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;

import com.ipru.groups.po.TransactionDetailsPdfGenerationPO;
import com.ipru.groups.po.UnitStatementPDFGeneratorVO;
import com.tcs.vo.BaseVO;

public class UnitStatementDataVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private String fundName;
	List<TransactionDetailsVO> transactionList;	
	List<UnitStatementPDFGenerationVO> unitStatementPDFGenerationVOList;
	

	public List<UnitStatementPDFGenerationVO> getUnitStatementPDFGenerationVOList() {
		return unitStatementPDFGenerationVOList;
	}

	public void setUnitStatementPDFGenerationVOList(
			List<UnitStatementPDFGenerationVO> unitStatementPDFGenerationVOList) {
		this.unitStatementPDFGenerationVOList = unitStatementPDFGenerationVOList;
	}

	public String getFundName() {
		return fundName;
	}

	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

	public List<TransactionDetailsVO> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(List<TransactionDetailsVO> transactionList) {
		this.transactionList = transactionList;
	}

	@Override
	public String toString() {
		return "UnitStatementDataVO [fundName=" + fundName
				+ ", transactionList=" + transactionList
				+ ", unitStatementPDFGenerationVOList="
				+ unitStatementPDFGenerationVOList + "]";
	}

	

}
