package com.ipru.groups.vo;

public class ClaimAnnuityOptionVO extends GroupsBaseVO {

	private String empId;
	private Long optionId;
	private String optionName;
	private String isSpouseVisible;
	private String isBeneficiaryVisible;
	private String isPanFileVisible;
	private String isSpouseDobFileVisible;
	private String isBenDobFileVisible;
	private String isAgeProofVisible;
	private String downloadShow;

	ClaimReqIBMredirectVO claimReqIBMredirectVO;
	private String claimId;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getClaimId() {
		return claimId;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

	public ClaimReqIBMredirectVO getClaimReqIBMredirectVO() {
		return claimReqIBMredirectVO;
	}

	public void setClaimReqIBMredirectVO(ClaimReqIBMredirectVO claimReqIBMredirectVO) {
		this.claimReqIBMredirectVO = claimReqIBMredirectVO;
	}

	public String getDownloadShow() {
		return downloadShow;
	}

	public void setDownloadShow(String downloadShow) {
		this.downloadShow = downloadShow;
	}

	public String getIsPanFileVisible() {
		return isPanFileVisible;
	}

	public void setIsPanFileVisible(String isPanFileVisible) {
		this.isPanFileVisible = isPanFileVisible;
	}

	public String getIsSpouseDobFileVisible() {
		return isSpouseDobFileVisible;
	}

	public void setIsSpouseDobFileVisible(String isSpouseDobFileVisible) {
		this.isSpouseDobFileVisible = isSpouseDobFileVisible;
	}

	public String getIsBenDobFileVisible() {
		return isBenDobFileVisible;
	}

	public void setIsBenDobFileVisible(String isBenDobFileVisible) {
		this.isBenDobFileVisible = isBenDobFileVisible;
	}

	public String getIsAgeProofVisible() {
		return isAgeProofVisible;
	}

	public void setIsAgeProofVisible(String isAgeProofVisible) {
		this.isAgeProofVisible = isAgeProofVisible;
	}

	public Long getOptionId() {
		return optionId;
	}

	public void setOptionId(Long optionId) {
		this.optionId = optionId;
	}

	public String getOptionName() {
		return optionName;
	}

	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}

	public String getIsSpouseVisible() {
		return isSpouseVisible;
	}

	public void setIsSpouseVisible(String isSpouseVisible) {
		this.isSpouseVisible = isSpouseVisible;
	}

	public String getIsBeneficiaryVisible() {
		return isBeneficiaryVisible;
	}

	public void setIsBeneficiaryVisible(String isBeneficiaryVisible) {
		this.isBeneficiaryVisible = isBeneficiaryVisible;
	}

}
