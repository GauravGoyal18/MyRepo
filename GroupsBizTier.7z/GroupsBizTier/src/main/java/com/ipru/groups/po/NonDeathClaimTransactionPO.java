package com.ipru.groups.po;

import java.io.Serializable;

public class NonDeathClaimTransactionPO implements Serializable {

	private static final long serialVersionUID = 1L;
	private long customerTrxnId;

	public long getCustomerTrxnId() {
		return customerTrxnId;
	}

	public void setCustomerTrxnId(long customerTrxnId) {
		this.customerTrxnId = customerTrxnId;
	}

	@Override
	public String toString() {
		return "NonDeathClaimTransactionPO [customerTrxnId=" + customerTrxnId
				+ "]";
	}

}
