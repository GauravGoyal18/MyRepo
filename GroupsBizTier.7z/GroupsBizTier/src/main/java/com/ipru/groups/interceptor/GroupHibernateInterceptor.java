package com.ipru.groups.interceptor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.CallbackException;
import org.hibernate.EmptyInterceptor;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.type.Type;

import com.google.gson.Gson;
import com.ipru.groups.spaarc.helper.SpaarcCallLogHelper;
import com.ipru.groups.utilities.GroupCommonUtils;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.vo.ClaimsRequestTransactionVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.ISpaarcCallLog;
import com.ipru.groups.vo.ServiceWebPageMenuVO;
import com.ipru.groups.vo.ServiceWebpageCallVO;
import com.tcs.logger.FLogger;

/**
 * @author Rohit Sidana
 *
 */
public class GroupHibernateInterceptor extends EmptyInterceptor {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = GroupHibernateInterceptor.class.getCanonicalName();
	private static final String INFO_LOGGER_NAME = "GROUPLogger";
	/**
	 * https://forum.hibernate.org/viewtopic.php?t=940410
	 * We listen to onFlushDirty calls and perform additional operations like
	 * audit and validation based on previouse and current state. We work in ATO
	 * flush mode (default). The problem is when AUTO flush is called before
	 * query execution, Interceptor.onFlushDirty() is called, but hibernate
	 * doesn't flsuh anything to DB. Then again if another query is executed,
	 * onFlushDirty is called again with the SAME previous state as before, and
	 * so on. I saw a bug was reported for this - see below, but was closed with
	 * 'as designed' explanation: https://hibernate.onjira.com/browse/HB-1480
	 *  
	 */
	private Boolean isOnFlushDirtyCalledForClaims;

	public Boolean isOnFlushDirtyCalledForClaims() {
		return isOnFlushDirtyCalledForClaims;
	}

	public void setOnFlushDirtyCalledForClaims(Boolean isOnFlushDirtyCalledForClaims) {
		this.isOnFlushDirtyCalledForClaims = isOnFlushDirtyCalledForClaims;
	}

	private Session session;

	public Session getSession() {
		
		return session;
	}

	public void setSession(Session session) {
		setOnFlushDirtyCalledForClaims(Boolean.FALSE);
		this.session = session;
	}
	
	/*@Override
	public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState, String[] propertyNames, Type[] types) throws CallbackException {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "onFlushDirty", "Entered Method");

		if (entity != null) {
			if ((entity instanceof ISpaarcCallLog) && (entity instanceof ClaimsRequestTransactionVO) && isOnFlushDirtyCalledForClaims() == Boolean.FALSE) {
				setOnFlushDirtyCalledForClaims(Boolean.TRUE);
				String aproovedStatus = ((ClaimsRequestTransactionVO) entity).getApprovalStatus();
				ClaimsRequestTransactionVO entityObj =((ClaimsRequestTransactionVO) entity);
				for (ClaimsApprovalVO claimsApprovalVO : entityObj.getClaimsApprovalVoSet()) {
					claimsApprovalVO.setClaimsRequestTransaction(null);
				}
				for (ClaimsBeneficiaryVO claimsBenVO : entityObj.getClaimsBeneficiaryVOSet()) {
					claimsBenVO.setClaimsRequestTransactionVO(null);
				}
				for (ClaimsRequestVO claimsReqVO : entityObj.getClaimsRequestVOSet()) {
					claimsReqVO.setClaimsRequestTransactionVO(null);
				}
				try {
					if (aproovedStatus != null && aproovedStatus.equalsIgnoreCase("APPROVED")) {
						spaarcCallLogRequestSubmit(entityObj);
					}
				}
				catch (Exception e) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "onSave", "Exception Came : " ,e);
					throw new CallbackException(e);
				}
			}
			else {
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "onFlushDirty", "Entity Object is not instance of ISpaarcCallLog or is not instance of ClaimsRequestTransactionVO.");
			}
		}
		else {
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "onFlushDirty", "Entity Object is null.");
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "onFlushDirty", "Exited Method");
		return super.onFlushDirty(entity, id, currentState, previousState, propertyNames, types);
	}*/

	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) throws CallbackException {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "onSave", "Entered Method");

		if (entity != null) {
			if ((entity instanceof ISpaarcCallLog) && !(entity instanceof ClaimsRequestTransactionVO)) {
				try {
					SpaarcCallLogHelper spaarcCallLogHelper = SpaarcCallLogHelper.getInstance();
					spaarcCallLogHelper.spaarcCallLogRequestSubmit(entity,session);
				}
				catch (Exception e) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "onSave", "Exception Came : " ,e);
					throw new CallbackException(e);
				}
			}
			else {
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "onSave", "Entity Object is not instance of ISpaarcCallLog or is instance of ClaimsRequestTransactionVO.");
			}
		}
		else {
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "onSave", "Entity Object is null.");
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "onSave", "Exited Method");
		return super.onSave(entity, id, state, propertyNames, types);
	}

	/*private void spaarcCallLogRequestSubmit(Object entity) throws Exception {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "Entered Method");

		FileOutputStream fout = null;
		ObjectOutputStream oos = null;
		String storedFileName = null;
		String storedFileNameWithPath = null;
		Query namedQuery = null;
		List<ServiceWebPageMenuVO> menuList = null;
		String functionalityName = null;
		long functionalityId = 0;

		try {
			if (entity != null) {

				FunctionalityMasterVO functionality = ((ISpaarcCallLog) entity).getFunctionality();
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "Fn::" + functionality);

				String functionalityReqId = ((ISpaarcCallLog) entity).getFunctionalityReqId();
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "functionalityReqId::" + functionalityReqId);

				String clientId = ((ISpaarcCallLog) entity).getClientId();
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "ClientId::" + clientId);

				String policyNo = ((ISpaarcCallLog) entity).getPolicyNo();
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "PolicyNo::" + policyNo);

				String role = ((ISpaarcCallLog) entity).getRole();
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "role::" + role);

				String productCategory = ((ISpaarcCallLog) entity).getProductType();
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "productCategory::" + productCategory);

				String memberType = ((ISpaarcCallLog) entity).getMemberType();
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "memberType::" + memberType);

				storedFileNameWithPath = getCallDesc(entity);

				if (functionality != null && functionalityReqId != null && clientId != null && policyNo != null && role != null && productCategory != null && memberType != null) {
					functionalityName = functionality.getFunctionalityName();
					functionalityId = functionality.getFunctionalityId();
					productCategory = productCategory.toUpperCase();

					if (session != null) {
						
						List result = (List) (session.createSQLQuery("SELECT REQUEST_MENU_ID,REQUEST_MENU_NAME,PRODUCTCATEGORY,MEMBERTYPE,CALLCATEGORY,MASTERCALLTYPE,CALLTYPE,SUBTYPE,ASSIGNEENAME,ASSIGNEEEMPID,ASSIGNEEGROUP,ASSIGNEESUBGROUP,FORMATLINK,FUNCTIONALITY_ID FROM GRP_SERVICE_WEBPAGE_MENU where PRODUCTCATEGORY=:productCategory and MEMBERTYPE=:memberType and FUNCTIONALITY_ID=:functionalityId order by REQUEST_MENU_NAME").setParameter("productCategory", productCategory).setParameter("memberType", memberType).setParameter("functionalityId", functionalityId).list());
						
						if(result != null){
							menuList = new ArrayList<ServiceWebPageMenuVO>();
							Iterator iterator = result.iterator();

							while (iterator.hasNext()) {
								Object[] row = (Object[]) iterator.next();
								if (row != null) {
									ServiceWebPageMenuVO menu = new ServiceWebPageMenuVO();
									
									if (row[0] != null)
										menu.setRequestMenuID(Long.valueOf(String.valueOf(row[0])));
									menu.setRequestMenuName(String.valueOf(row[1]));
									menu.setProductCategory(String.valueOf(row[2]));
									menu.setMemberType(String.valueOf(row[3]));
									menu.setCallCategory(String.valueOf(row[4]));
									menu.setMasterCallType(String.valueOf(row[5]));
									menu.setCallType(String.valueOf(row[6]));
									menu.setSubType(String.valueOf(row[7]));
									menu.setAssigneeName(String.valueOf(row[8]));
									menu.setAssigneeEmpId(String.valueOf(row[9]));
									menu.setAssigneeGroup(String.valueOf(row[10]));
									menu.setAssigneeSubGroup(String.valueOf(row[11]));
									menu.setFormatLink(String.valueOf(row[12]));
									if (row[13] != null)
										menu.setFunctionalityId(Long.valueOf(String.valueOf(row[13])));
									
									menuList.add(menu);
								}
							}
						}
						
						namedQuery = session.getNamedQuery("ServiceWebPageMenuVO.getMenuDetails");
						namedQuery.setParameter("productCategory", productCategory);
						namedQuery.setParameter("memberType", memberType);
						namedQuery.setParameter("functionalityId", functionalityId);
						menuList = namedQuery.list();

						if (menuList != null && menuList.size() > 0) {

							for (ServiceWebPageMenuVO serviceWebPageMenuVO : menuList) {
								if (serviceWebPageMenuVO != null) {
									ServiceWebpageCallVO serviceWebpageCallVO = new ServiceWebpageCallVO();
									serviceWebpageCallVO.setClientId(clientId);
									serviceWebpageCallVO.setPolicyNo(policyNo);
									serviceWebpageCallVO.setAppNo("NA");

									serviceWebpageCallVO.setMenuId(serviceWebPageMenuVO.getRequestMenuID());
									serviceWebpageCallVO.setCallCategory(serviceWebPageMenuVO.getCallCategory());
									serviceWebpageCallVO.setMasterCallType(serviceWebPageMenuVO.getMasterCallType());
									serviceWebpageCallVO.setCallType(serviceWebPageMenuVO.getCallType());
									serviceWebpageCallVO.setSubType(serviceWebPageMenuVO.getSubType());
									serviceWebpageCallVO.setAssigneeName(serviceWebPageMenuVO.getAssigneeName());
									serviceWebpageCallVO.setAssigneeGroup(serviceWebPageMenuVO.getAssigneeGroup());
									serviceWebpageCallVO.setAssigneeSubGroup(serviceWebPageMenuVO.getAssigneeSubGroup());

									serviceWebpageCallVO.setFunctionality(functionality);
									serviceWebpageCallVO.setFunctionalityReqId(functionalityReqId);

									serviceWebpageCallVO.setWsResponse(null);
									serviceWebpageCallVO.setStatus("PENDING");
									serviceWebpageCallVO.setRequestedDateTime(GroupCommonUtils.getCurrentDate());
									serviceWebpageCallVO.setLastUpdateDateTime(GroupCommonUtils.getCurrentDate());
									serviceWebpageCallVO.setEmailSentflag("N");
									serviceWebpageCallVO.setSchTryCount(0);

									serviceWebpageCallVO.setCallDesc(storedFileNameWithPath);

									session.save(serviceWebpageCallVO);
								}
							}
						}
						else {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "MCT,CT,ST are not available.");
						}
					}
					else {
						FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "Hibernate Session is null.");
					}
				}
				else {
					FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "Mandatory fields are null.");
				}
			}
			else {
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "Entity Object is null.");
			}
		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "Exception Came : " ,e);
//			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				if (fout != null) {
					fout.close();
				}
				if (oos != null) {
					oos.close();
				}
			}
			catch (IOException e) {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "Exception Came while closing i/o streams : " + e.getMessage());
			}
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "spaarcCallLogRequestSubmit", "Exited Method");
	}

	private String getCallDesc(Object entity) throws Exception {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getCallDesc", "Entered Method");
		String functionalityName = null;
		FileOutputStream fout = null;
		ObjectOutputStream oos = null;
		File upLoadedfile = null;
		// FileWriter fs = null;
		String storedFileNameWithPath = null;

		try {
			if (entity != null) {
				FunctionalityMasterVO functionality = ((ISpaarcCallLog) entity).getFunctionality();

				if (functionality != null) {
					functionalityName = functionality.getFunctionalityName();
				}

				String functionalityReqId = ((ISpaarcCallLog) entity).getFunctionalityReqId();

				String clientId = ((ISpaarcCallLog) entity).getClientId();

				String policyNo = ((ISpaarcCallLog) entity).getPolicyNo();

				Gson gson = new Gson();

				String entityJson = gson.toJson(entity);

				String destination = GroupCommonUtils.createDirWithTodaysDate(GroupConstants.CONSTANT_SPAARC_OBJECT_DOCS_PATH);

				if (StringUtils.isNotEmpty(destination)) {

					File file = new File(destination + "/" + functionalityName);
					if (!file.isDirectory()) {
						file.mkdirs();
					}
					String todaysDate = new SimpleDateFormat("ddMMyyyyHHmmssSSS").format(Calendar.getInstance().getTime());

					String storedFileName = policyNo + "_" + clientId + "_" + functionalityReqId + "_" + todaysDate + ".ser";

					String uploadFolder = file.getAbsolutePath().replace("\\", "/") + "/";
					storedFileNameWithPath = uploadFolder + storedFileName;

					upLoadedfile = new File(storedFileNameWithPath);
					upLoadedfile.createNewFile();

					// fs = new FileWriter(upLoadedfile);

					fout = new FileOutputStream(upLoadedfile);
					oos = new ObjectOutputStream(fout);
					oos.writeObject(entityJson);
				}
				else {
					FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getCallDesc", "destination is null.");
				}
			}
			else {
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getCallDesc", "Entity is null.");
			}
		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getCallDesc", "Exception Came : ", e);
//			e.printStackTrace();
			throw e;
		}
		finally {
			try {
				if (fout != null) {
					fout.close();
				}
				if (oos != null) {
					oos.close();
				}
			}
			catch (IOException e) {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getCallDesc", "Exception came while closing the output streams." ,e);
				throw e;
			}
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getCallDesc", "Exited Method");
		return storedFileNameWithPath;
	}*/

	@Override
	public void afterTransactionCompletion(Transaction tx) {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "afterTransactionCompletion", "Entered Method");
		boolean txWasCommittedRolledBack = false;
		if (tx.wasCommitted()) {
			session.flush();
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "afterTransactionCompletion", "Session flushed");
			txWasCommittedRolledBack = true;
		}
		else if (tx.wasRolledBack()) {
			session.clear();
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "afterTransactionCompletion", "Session Cleared");
			txWasCommittedRolledBack = true;
		}
		if (txWasCommittedRolledBack && session.isOpen()) {
			setOnFlushDirtyCalledForClaims(null);
			session.close();
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "afterTransactionCompletion", "Session closed");
			session = null;
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "afterTransactionCompletion", "Session made to null");
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "afterTransactionCompletion", "Exited Method");
	}
	
	/*public void postFlush(Iterator entities) {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "postFlush", "Entered Method");
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "postFlush", "Exited Method");
	}
	public void preFlush(Iterator entities) {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "preFlush", "Entered Method");
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "preFlush", "Exited Method");
	}*/

}
