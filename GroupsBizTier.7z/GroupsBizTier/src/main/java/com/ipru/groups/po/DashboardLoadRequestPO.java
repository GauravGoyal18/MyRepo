package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.security.user.IPruUser;

public class DashboardLoadRequestPO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String screenName;
	private IPruUser userVO;

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public IPruUser getUserVO() {
		return userVO;
	}

	public void setUserVO(IPruUser userVO) {
		this.userVO = userVO;
	}

}
