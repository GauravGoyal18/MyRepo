package com.ipru.groups.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.tcs.vo.BaseVO;

public class UnitStatementResponseVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String startDate;
	private String endDate;
	private String trustName;
	private String policyNumber;
	private String memberName;
	private String closingBalance;
	private String policyType;
	private List<UnitStatementDataVO> unitStatementDataVOList;
	
	@Override
	public String toString() {
		return "unitStatementDataVOList [startDate=" + startDate + ", endDate="
				+ endDate + ", trustName=" + trustName + ", policyNumber="
				+ policyNumber + ", memberName=" + memberName
				+ ", closingBalance=" + closingBalance + ", policyType="
				+ policyType + ", unitStatementDataVOList="
				+ unitStatementDataVOList + "]";
	}
	
	
	

	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getTrustName() {
		return trustName;
	}
	public void setTrustName(String trustName) {
		this.trustName = trustName;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getClosingBalance() {
		return closingBalance;
	}
	public void setClosingBalance(String closingBalance) {
		this.closingBalance = closingBalance;
	}
	public List<UnitStatementDataVO> getUnitStatementDataVOList() {
		return unitStatementDataVOList;
	}
	public void setUnitStatementDataVOList(
			List<UnitStatementDataVO> unitStatementDataVOList) {
		this.unitStatementDataVOList = unitStatementDataVOList;
	}
	
	
}
