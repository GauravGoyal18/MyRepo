package com.ipru.groups.vo;

public class NomineeBenPMJJBYSubmitVO extends GroupsBaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long requestId;
	private String beneficiaryName;
	private String relation;
	private String sharePercentage;
	private String beneficiaryDOB;
	private String gender;
	private String benAddress;
	private String city;
	private String pincode;
	private String beneficiaryPos;

	private NomineePMJJBYSubmitVO nomineePMJJBYSubmitVO;

	public String getBeneficiaryPos() {
		return beneficiaryPos;
	}

	public void setBeneficiaryPos(String beneficiaryPos) {
		this.beneficiaryPos = beneficiaryPos;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public NomineePMJJBYSubmitVO getNomineePMJJBYSubmitVO() {
		return nomineePMJJBYSubmitVO;
	}

	public void setNomineePMJJBYSubmitVO(
			NomineePMJJBYSubmitVO nomineePMJJBYSubmitVO) {
		this.nomineePMJJBYSubmitVO = nomineePMJJBYSubmitVO;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getSharePercentage() {
		return sharePercentage;
	}

	public void setSharePercentage(String sharePercentage) {
		this.sharePercentage = sharePercentage;
	}

	public String getBeneficiaryDOB() {
		return beneficiaryDOB;
	}

	public void setBeneficiaryDOB(String beneficiaryDOB) {
		this.beneficiaryDOB = beneficiaryDOB;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBenAddress() {
		return benAddress;
	}

	public void setBenAddress(String benAddress) {
		this.benAddress = benAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "NomineeBenPMJJBYSubmitVO [beneficiaryName=" + beneficiaryName
				+ ", relation=" + relation + ", sharePercentage="
				+ sharePercentage + ", beneficiaryDOB=" + beneficiaryDOB
				+ ", gender=" + gender + ", benAddress=" + benAddress
				+ ", city=" + city + ", pincode=" + pincode
				+ ", nomineePMJJBYSubmitVO=" + "]";
	}

}
