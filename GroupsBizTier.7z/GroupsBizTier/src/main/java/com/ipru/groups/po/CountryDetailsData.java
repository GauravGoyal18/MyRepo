package com.ipru.groups.po;

import com.tcs.web.po.BasePO;

public class CountryDetailsData extends BasePO {
	private String countryName;
	private String countryCode;
	String functionalityId;
	
	
	

	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getFunctionalityId() {
		return functionalityId;
	}
	public void setFunctionalityId(String functionalityId) {
		this.functionalityId = functionalityId;
	}
	@Override
	public String toString() {
		return "CountryDetailsData [countryName=" + countryName + ", countryCode=" + countryCode + ", functionalityId=" + functionalityId + "]";
	}

	
	


}
