package com.ipru.groups.po;

import java.io.Serializable;

public class TrackerRequestPO implements Serializable {

	private String functionality;
	
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFunctionality() {
		return functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}



	@Override
	public String toString() {
		return "TrackerRequestPO [functionality=" + functionality + ", status=" + status + "]";
	}
}
