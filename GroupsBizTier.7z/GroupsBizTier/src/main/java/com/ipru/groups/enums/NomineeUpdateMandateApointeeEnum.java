package com.ipru.groups.enums;

public enum NomineeUpdateMandateApointeeEnum {

	nomineeUpdateMandateApointeeEnum1("apointeeDob"), nomineeUpdateMandateApointeeEnum2("apointeeRelation"), nomineeUpdateMandateApointeeEnum3("apointeeGender"), nomineeUpdateMandateApointeeEnum4("apointeeFirstappointeeName"), nomineeUpdateMandateApointeeEnum5("apointeeLasttappointeeName"), nomineeUpdateMandateApointeeEnum6("beneficaryName"), nomineeUpdateMandateApointeeEnum7("dob"), nomineeUpdateMandateApointeeEnum8("relation"), nomineeUpdateMandateApointeeEnum9("gender"), nomineeUpdateMandateApointeeEnum10("share"), nomineeUpdateMandateApointeeEnum11("beneficaryLastName");

	private final String name;

	private NomineeUpdateMandateApointeeEnum(String s) {
		name = s;
	}

	public boolean equalsName(String otherName) {
		// (otherName == null) check is not needed because name.equals(null)
		// returns false
		return name.equals(otherName);
	}

	public String toString() {
		return this.name;
	}
}
