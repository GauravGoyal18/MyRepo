package com.ipru.groups.po;

import java.util.List;
import java.util.Set;

import com.ipru.groups.vo.FunctionalityMasterVO;
import com.tcs.vo.BaseVO;
import com.tcs.web.po.BasePO;

public class ClaimRequestIBMSubmitPO extends BasePO {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ClaimRequestIBMPO claimRequestIBMPO;
	private List<UploadFilePO> uploadFileList4;
	private List<UploadFilePO> uploadFileList3;
	private List<UploadFilePO> uploadFileList2;
	private List<UploadFilePO> uploadFileList1;
	private List<List<UploadFilePO>> claimRequestIBMPOUploadList;
	private FunctionalityMasterVO functionality;
	
	
	

	@Override
	public String toString() {
		return "ClaimRequestIBMSubmitPO [claimRequestIBMPO="
				+ claimRequestIBMPO + ", uploadFileList4=" + uploadFileList4
				+ ", uploadFileList3=" + uploadFileList3 + ", uploadFileList2="
				+ uploadFileList2 + ", uploadFileList1=" + uploadFileList1
				+ ", claimRequestIBMPOUploadList="
				+ claimRequestIBMPOUploadList + ", functionality="
				+ functionality + "]";
	}



	public List<List<UploadFilePO>> getClaimRequestIBMPOUploadList() {
		return claimRequestIBMPOUploadList;
	}



	public void setClaimRequestIBMPOUploadList(
			List<List<UploadFilePO>> claimRequestIBMPOUploadList) {
		this.claimRequestIBMPOUploadList = claimRequestIBMPOUploadList;
	}



	public List<UploadFilePO> getUploadFileList4() {
		return uploadFileList4;
	}

	public void setUploadFileList4(List<UploadFilePO> uploadFileList4) {
		this.uploadFileList4 = uploadFileList4;
	}

	public List<UploadFilePO> getUploadFileList3() {
		return uploadFileList3;
	}

	public void setUploadFileList3(List<UploadFilePO> uploadFileList3) {
		this.uploadFileList3 = uploadFileList3;
	}

	public List<UploadFilePO> getUploadFileList2() {
		return uploadFileList2;
	}

	public void setUploadFileList2(List<UploadFilePO> uploadFileList2) {
		this.uploadFileList2 = uploadFileList2;
	}

	public List<UploadFilePO> getUploadFileList1() {
		return uploadFileList1;
	}

	public void setUploadFileList1(List<UploadFilePO> uploadFileList1) {
		this.uploadFileList1 = uploadFileList1;
	}

	public ClaimRequestIBMPO getClaimRequestIBMPO() {
		return claimRequestIBMPO;
	}

	public void setClaimRequestIBMPO(ClaimRequestIBMPO claimRequestIBMPO) {
		this.claimRequestIBMPO = claimRequestIBMPO;
	}



	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}



	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}
	
	
	
}
