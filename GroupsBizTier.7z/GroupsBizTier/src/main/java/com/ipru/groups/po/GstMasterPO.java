package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;

public class GstMasterPO implements Serializable {

	private static final long serialVersionUID = 1L;
	private long requestId;
	private String policyNo;
	private String formLink;
	private Date linkValidDate;
	private String linkValidStatus;
	private String emailId;
	private String mobileNo;
	private String formId;
	private Date lastUpdateDate;

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getFormLink() {
		return formLink;
	}

	public void setFormLink(String formLink) {
		this.formLink = formLink;
	}

	public Date getLinkValidDate() {
		return linkValidDate;
	}

	public void setLinkValidDate(Date linkValidDate) {
		this.linkValidDate = linkValidDate;
	}

	public String getLinkValidStatus() {
		return linkValidStatus;
	}

	public void setLinkValidStatus(String linkValidStatus) {
		this.linkValidStatus = linkValidStatus;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

}
