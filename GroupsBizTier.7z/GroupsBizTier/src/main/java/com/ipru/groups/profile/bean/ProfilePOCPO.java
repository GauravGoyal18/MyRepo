package com.ipru.groups.profile.bean;

import java.io.Serializable;

public class ProfilePOCPO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
/*	private String id;
	private boolean isDisabled;
	private boolean isEditable;
	private boolean isShow;
	private int fieldGroupCode;
	private int fieldCode;
	private int subFieldCode;*/
	
	private long rdId;
	private String rdRole;
	private String rdComponent;
	private String rdFlow;
	private long rdParentComponentId;
	private long rdOpId;
	private String opShowEdit;
	private String opShowDisabled;
	private String opShow;
	private String opShowSubmit;
	private String opMandatory;
	private long rdComponentPosId;
	
	
	
	public long getRdId() {
		return rdId;
	}
	public void setRdId(long rdId) {
		this.rdId = rdId;
	}
	public String getRdRole() {
		return rdRole;
	}
	public void setRdRole(String rdRole) {
		this.rdRole = rdRole;
	}
	public String getRdComponent() {
		return rdComponent;
	}
	public void setRdComponent(String rdComponent) {
		this.rdComponent = rdComponent;
	}
	public String getRdFlow() {
		return rdFlow;
	}
	public void setRdFlow(String rdFlow) {
		this.rdFlow = rdFlow;
	}
	public long getRdParentComponentId() {
		return rdParentComponentId;
	}
	public void setRdParentComponentId(long rdParentComponentId) {
		this.rdParentComponentId = rdParentComponentId;
	}
	public long getRdOpId() {
		return rdOpId;
	}
	public void setRdOpId(long rdOpId) {
		this.rdOpId = rdOpId;
	}
	public String getOpShowEdit() {
		return opShowEdit;
	}
	public void setOpShowEdit(String opShowEdit) {
		this.opShowEdit = opShowEdit;
	}
	public String getOpShowDisabled() {
		return opShowDisabled;
	}
	public void setOpShowDisabled(String opShowDisabled) {
		this.opShowDisabled = opShowDisabled;
	}
	public String getOpShow() {
		return opShow;
	}
	public void setOpShow(String opShow) {
		this.opShow = opShow;
	}
	public String getOpShowSubmit() {
		return opShowSubmit;
	}
	public void setOpShowSubmit(String opShowSubmit) {
		this.opShowSubmit = opShowSubmit;
	}
	public String getOpMandatory() {
		return opMandatory;
	}
	public void setOpMandatory(String opMandatory) {
		this.opMandatory = opMandatory;
	}
	public long getRdComponentPosId() {
		return rdComponentPosId;
	}
	public void setRdComponentPosId(long rdComponentPosId) {
		this.rdComponentPosId = rdComponentPosId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	
	
	/*public int getSubFieldCode() {
		return subFieldCode;
	}
	public void setSubFieldCode(int subFieldCode) {
		this.subFieldCode = subFieldCode;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public boolean isDisabled() {
		return isDisabled;
	}
	public void setDisabled(boolean isDisabled) {
		this.isDisabled = isDisabled;
	}
	public boolean isEditable() {
		return isEditable;
	}
	public void setEditable(boolean isEditable) {
		this.isEditable = isEditable;
	}
	public boolean isShow() {
		return isShow;
	}
	public void setShow(boolean isShow) {
		this.isShow = isShow;
	}
	public int getFieldCode() {
		return fieldCode;
	}
	public void setFieldCode(int fieldCode) {
		this.fieldCode = fieldCode;
	}
	public int getFieldGroupCode() {
		return fieldGroupCode;
	}
	public void setFieldGroupCode(int fieldGroupCode) {
		this.fieldGroupCode = fieldGroupCode;
	}
	*/
	

}
