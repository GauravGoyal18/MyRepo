package com.ipru.groups.vo;

import com.tcs.web.vo.BaseVO;

public class ContributionHistoryRequestVO extends BaseVO {
	
	private String policyNumber;
	private String clientId;
	private String memberEmpId;
	private String role;
	
	
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getMemberEmpId() {
		return memberEmpId;
	}
	public void setMemberEmpId(String memberEmpId) {
		this.memberEmpId = memberEmpId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "ContributionHistoryRequestVO [policyNumber=" + policyNumber
				+ ", clientId=" + clientId + ", memberEmpId=" + memberEmpId
				+ ", role=" + role + "]";
	}

	
	
	

}
