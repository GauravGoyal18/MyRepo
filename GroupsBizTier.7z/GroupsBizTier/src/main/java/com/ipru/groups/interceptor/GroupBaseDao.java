package com.ipru.groups.interceptor;

import java.io.Serializable;

import org.hibernate.Session;

import com.tcs.dao.hibernate.BaseDAOHibernateImpl;
import com.tcs.hibernate.HibernateConfigReader;

public class GroupBaseDao<T, ID> extends BaseDAOHibernateImpl<T, Serializable> {

	private GroupHibernateInterceptor groupHibernateInterceptor;
	private String strModuleName;

	public String getStrModuleName() {
		return strModuleName;
	}

	public void setStrModuleName(String strModuleName) {
		this.strModuleName = strModuleName;
	}

	public GroupHibernateInterceptor getSpaarcLogInterceptor() {
		return groupHibernateInterceptor;
	}

	public void setSpaarcLogInterceptor(GroupHibernateInterceptor groupHibernateInterceptor) {
		this.groupHibernateInterceptor = groupHibernateInterceptor;
	}

	public GroupBaseDao(String p_StrModuleName) {
		super(p_StrModuleName);
		setStrModuleName(p_StrModuleName);
		setSpaarcLogInterceptor(new GroupHibernateInterceptor());

	}

	@Override
	public Session getSession() {
		Session session = HibernateConfigReader.INSTANCE.getSessionFactoryMap().get(getStrModuleName()).openSession(getSpaarcLogInterceptor());
		getSpaarcLogInterceptor().setSession(session);
		return session;

	}

}
