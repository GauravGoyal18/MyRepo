package com.ipru.groups.po;

import java.io.Serializable;


public class SAClaimIntiSpousePO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long spouseId;
	private String salutation;
	private String firstName;
	private String lastName;
	private String dateOfBirth;
	private String ageProof;

	public Long getSpouseId() {
		return spouseId;
	}

	public void setSpouseId(Long spouseId) {
		this.spouseId = spouseId;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getAgeProof() {
		return ageProof;
	}

	public void setAgeProof(String ageProof) {
		this.ageProof = ageProof;
	}


	@Override
	public String toString() {
		return "SAClaimIntiSpousePO [spouseId=" + spouseId + ", salutation="
				+ salutation + ", firstName=" + firstName + ", lastName="
				+ lastName + ", dateOfBirth=" + dateOfBirth + ", ageProof="
				+ ageProof + "]";
	}
	
	
}
