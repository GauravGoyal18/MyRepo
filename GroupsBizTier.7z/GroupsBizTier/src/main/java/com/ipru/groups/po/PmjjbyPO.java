package com.ipru.groups.po;

public class PmjjbyPO extends GroupsBasePo {
	
	private static final long serialVersionUID = 1L;

	private String bankAccNo;
	private String dobOfAssured;
	private String nominee;
	
	
	
	public String getBankAccNo() {
		return bankAccNo;
	}
	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}
	public String getDobOfAssured() {
		return dobOfAssured;
	}
	public void setDobOfAssured(String dobOfAssured) {
		this.dobOfAssured = dobOfAssured;
	}
	public String getNominee() {
		return nominee;
	}
	public void setNominee(String nominee) {
		this.nominee = nominee;
	}

	
	
	
}
