package com.ipru.groups.vo;

import java.util.List;

import com.tcs.vo.BaseVO;

public class ClaimAnnuityIBMSubmitVO extends BaseVO {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private ClaimRequestIBMVO claimRequestIBMVO;
	private List<UploadFileVO> uploadFileList4;
	private List<UploadFileVO> uploadFileList3;
	private List<UploadFileVO> uploadFileList2;
	private List<UploadFileVO> uploadFileList1;
	private List<List<UploadFileVO>> claimRequestIBMVOUploadList;
	private FunctionalityMasterVO functionality;
	



	

	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}


	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}


	public ClaimRequestIBMVO getClaimRequestIBMVO() {
		return claimRequestIBMVO;
	}


	public void setClaimRequestIBMVO(ClaimRequestIBMVO claimRequestIBMVO) {
		this.claimRequestIBMVO = claimRequestIBMVO;
	}


	public List<UploadFileVO> getUploadFileList4() {
		return uploadFileList4;
	}


	public void setUploadFileList4(List<UploadFileVO> uploadFileList4) {
		this.uploadFileList4 = uploadFileList4;
	}


	public List<UploadFileVO> getUploadFileList3() {
		return uploadFileList3;
	}


	public void setUploadFileList3(List<UploadFileVO> uploadFileList3) {
		this.uploadFileList3 = uploadFileList3;
	}


	public List<UploadFileVO> getUploadFileList2() {
		return uploadFileList2;
	}


	public void setUploadFileList2(List<UploadFileVO> uploadFileList2) {
		this.uploadFileList2 = uploadFileList2;
	}


	public List<UploadFileVO> getUploadFileList1() {
		return uploadFileList1;
	}


	public void setUploadFileList1(List<UploadFileVO> uploadFileList1) {
		this.uploadFileList1 = uploadFileList1;
	}


	public List<List<UploadFileVO>> getClaimRequestIBMVOUploadList() {
		return claimRequestIBMVOUploadList;
	}


	public void setClaimRequestIBMVOUploadList(
			List<List<UploadFileVO>> claimRequestIBMVOUploadList) {
		this.claimRequestIBMVOUploadList = claimRequestIBMVOUploadList;
	}


	@Override
	public String toString() {
		return "ClaimAnnuitySubmitIBMVO [claimRequestIBMVO="
				+ claimRequestIBMVO + ", uploadFileList4=" + uploadFileList4
				+ ", uploadFileList3=" + uploadFileList3 + ", uploadFileList2="
				+ uploadFileList2 + ", uploadFileList1=" + uploadFileList1
				+ ", claimRequestIBMVOUploadList="
				+ claimRequestIBMVOUploadList + ", functionality="
				+ functionality + "]";
	}


	
	

	
}
