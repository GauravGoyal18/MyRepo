package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;

public class ServiceWebPageTransPO implements Serializable {

	private static final long serialVersionUID = 1L;
	private long requestId;

	public ServiceWebPageTransPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	@Override
	public String toString() {
		return "ServiceWebPageTransPO [requestId=" + requestId + "]";
	}

}
