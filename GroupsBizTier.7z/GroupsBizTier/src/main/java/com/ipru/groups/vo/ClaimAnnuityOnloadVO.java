package com.ipru.groups.vo;

import java.util.List;

public class ClaimAnnuityOnloadVO extends GroupsBaseVO {

	private List<ClaimAnnuityWegaVO> claimAnnuityWegaList;
	private List<ClaimAnnuityOptionVO> claimAnnuityOptionList;

	public List<ClaimAnnuityWegaVO> getClaimAnnuityWegaList() {
		return claimAnnuityWegaList;
	}

	public void setClaimAnnuityWegaList(List<ClaimAnnuityWegaVO> claimAnnuityWegaList) {
		this.claimAnnuityWegaList = claimAnnuityWegaList;
	}

	public List<ClaimAnnuityOptionVO> getClaimAnnuityOptionList() {
		return claimAnnuityOptionList;
	}

	public void setClaimAnnuityOptionList(List<ClaimAnnuityOptionVO> claimAnnuityOptionList) {
		this.claimAnnuityOptionList = claimAnnuityOptionList;
	}

}
