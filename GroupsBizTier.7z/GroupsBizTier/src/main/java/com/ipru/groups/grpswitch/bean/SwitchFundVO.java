package com.ipru.groups.grpswitch.bean;

import java.io.Serializable;

import com.ipru.groups.vo.GroupsBaseVO;


public class SwitchFundVO extends GroupsBaseVO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	
	
	

}

