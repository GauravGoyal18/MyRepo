package com.ipru.groups.po;

import java.io.Serializable;

import com.tcs.web.po.BasePO;

public class DropDownObjPO extends BasePO{

	private static final long serialVersionUID = 1L;
	private String key;
	private String value;
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "DropDownObjVO [key=" + key + ", value=" + value + "]";
	}
	
}
