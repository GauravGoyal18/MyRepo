package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class ServiceWebpageCallVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long requestId;
	private String clientId;
	private String policyNo;
	private String appNo;
	private String callDesc;
	private long menuId;
	private String callCategory;
	private String masterCallType;
	private String callType;
	private String subType;
	private String assigneeName;
	private String assigneeGroup;
	private String assigneeSubGroup;
	private String wsResponse;
	private String status;
	private Date requestedDateTime;
	private Date lastUpdateDateTime;
	private String emailSentflag;
	private FunctionalityMasterVO functionality;
	private String functionalityReqId;
	private int schTryCount;

	public ServiceWebpageCallVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceWebpageCallVO(long requestId, String clientId, String policyNo, String appNo, String callDesc, long menuId, String callCategory, String masterCallType, String callType, String subType, String assigneeName, String assigneeGroup, String assigneeSubGroup, String wsResponse, String status, Date requestedDateTime, Date lastUpdateDateTime, String emailSentflag, FunctionalityMasterVO functionality, String functionalityReqId, int schTryCount) {
		super();
		this.requestId = requestId;
		this.clientId = clientId;
		this.policyNo = policyNo;
		this.appNo = appNo;
		this.callDesc = callDesc;
		this.menuId = menuId;
		this.callCategory = callCategory;
		this.masterCallType = masterCallType;
		this.callType = callType;
		this.subType = subType;
		this.assigneeName = assigneeName;
		this.assigneeGroup = assigneeGroup;
		this.assigneeSubGroup = assigneeSubGroup;
		this.wsResponse = wsResponse;
		this.status = status;
		this.requestedDateTime = requestedDateTime;
		this.lastUpdateDateTime = lastUpdateDateTime;
		this.emailSentflag = emailSentflag;
		this.functionality = functionality;
		this.functionalityReqId = functionalityReqId;
		this.schTryCount = schTryCount;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getAppNo() {
		return appNo;
	}

	public void setAppNo(String appNo) {
		this.appNo = appNo;
	}

	public String getCallDesc() {
		return callDesc;
	}

	public void setCallDesc(String callDesc) {
		this.callDesc = callDesc;
	}

	public long getMenuId() {
		return menuId;
	}

	public void setMenuId(long menuId) {
		this.menuId = menuId;
	}

	public String getWsResponse() {
		return wsResponse;
	}

	public void setWsResponse(String wsResponse) {
		this.wsResponse = wsResponse;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getRequestedDateTime() {
		return requestedDateTime;
	}

	public void setRequestedDateTime(Date requestedDateTime) {
		this.requestedDateTime = requestedDateTime;
	}

	public Date getLastUpdateDateTime() {
		return lastUpdateDateTime;
	}

	public void setLastUpdateDateTime(Date lastUpdateDateTime) {
		this.lastUpdateDateTime = lastUpdateDateTime;
	}

	public String getEmailSentflag() {
		return emailSentflag;
	}

	public void setEmailSentflag(String emailSentflag) {
		this.emailSentflag = emailSentflag;
	}

	public String getCallCategory() {
		return callCategory;
	}

	public void setCallCategory(String callCategory) {
		this.callCategory = callCategory;
	}

	public String getMasterCallType() {
		return masterCallType;
	}

	public void setMasterCallType(String masterCallType) {
		this.masterCallType = masterCallType;
	}

	public String getCallType() {
		return callType;
	}

	public void setCallType(String callType) {
		this.callType = callType;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getAssigneeName() {
		return assigneeName;
	}

	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	public String getAssigneeGroup() {
		return assigneeGroup;
	}

	public void setAssigneeGroup(String assigneeGroup) {
		this.assigneeGroup = assigneeGroup;
	}

	public String getAssigneeSubGroup() {
		return assigneeSubGroup;
	}

	public void setAssigneeSubGroup(String assigneeSubGroup) {
		this.assigneeSubGroup = assigneeSubGroup;
	}

	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}

	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}

	public String getFunctionalityReqId() {
		return functionalityReqId;
	}

	public void setFunctionalityReqId(String functionalityReqId) {
		this.functionalityReqId = functionalityReqId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getSchTryCount() {
		return schTryCount;
	}

	public void setSchTryCount(int schTryCount) {
		this.schTryCount = schTryCount;
	}

	@Override
	public String toString() {
		return "ServiceWebpageCallVO [requestId=" + requestId + ", clientId=" + clientId + ", policyNo=" + policyNo + ", appNo=" + appNo + ", callDesc=" + callDesc + ", menuId=" + menuId
				+ ", callCategory=" + callCategory + ", masterCallType=" + masterCallType + ", callType=" + callType + ", subType=" + subType + ", assigneeName=" + assigneeName + ", assigneeGroup="
				+ assigneeGroup + ", assigneeSubGroup=" + assigneeSubGroup + ", wsResponse=" + wsResponse + ", status=" + status + ", requestedDateTime=" + requestedDateTime + ", lastUpdateDateTime="
				+ lastUpdateDateTime + ", emailSentflag=" + emailSentflag + ", functionality=" + functionality + ", functionalityReqId=" + functionalityReqId + ", schTryCount=" + schTryCount + "]";
	}

}
