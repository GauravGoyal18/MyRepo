package com.ipru.groups.po;

import com.tcs.web.po.BasePO;

public class StofSubmitPo extends BasePO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fundFromName;
	private String fundToName;
	private String nav;
	private String unit;
	private String ammount;
	private String frequency;
	private String numberOfTransfer;
	private String unitOrAmount;
	private String totalValue;

	private String fromUnit;
	private String fromAmount;
	private String toNAV;
	private String toUnit;
	private String toAmount;

	public synchronized String getTotalValue() {
		return totalValue;
	}

	public synchronized void setTotalValue(String totalValue) {
		this.totalValue = totalValue;
	}

	public synchronized String getUnit() {
		return unit;
	}

	public synchronized void setUnit(String unit) {
		this.unit = unit;
	}

	public synchronized String getAmmount() {
		return ammount;
	}

	public synchronized void setAmmount(String ammount) {
		this.ammount = ammount;
	}

	public synchronized String getFundFromName() {
		return fundFromName;
	}

	public synchronized void setFundFromName(String fundFromName) {
		this.fundFromName = fundFromName;
	}

	public synchronized String getFundToName() {
		return fundToName;
	}

	public synchronized void setFundToName(String fundToName) {
		this.fundToName = fundToName;
	}

	public synchronized String getNav() {
		return nav;
	}

	public synchronized void setNav(String nav) {
		this.nav = nav;
	}

	public synchronized String getFrequency() {
		return frequency;
	}

	public synchronized void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public synchronized String getNumberOfTransfer() {
		return numberOfTransfer;
	}

	public synchronized void setNumberOfTransfer(String numberOfTransfer) {
		this.numberOfTransfer = numberOfTransfer;
	}

	public synchronized String getUnitOrAmount() {
		return unitOrAmount;
	}

	public synchronized void setUnitOrAmount(String unitOrAmount) {
		this.unitOrAmount = unitOrAmount;
	}

	public synchronized String getFromUnit() {
		return fromUnit;
	}

	public synchronized void setFromUnit(String fromUnit) {
		this.fromUnit = fromUnit;
	}

	public synchronized String getFromAmount() {
		return fromAmount;
	}

	public synchronized void setFromAmount(String fromAmount) {
		this.fromAmount = fromAmount;
	}

	public synchronized String getToNAV() {
		return toNAV;
	}

	public synchronized void setToNAV(String toNAV) {
		this.toNAV = toNAV;
	}

	public synchronized String getToUnit() {
		return toUnit;
	}

	public synchronized void setToUnit(String toUnit) {
		this.toUnit = toUnit;
	}

	public synchronized String getToAmount() {
		return toAmount;
	}

	public synchronized void setToAmount(String toAmount) {
		this.toAmount = toAmount;
	}

	@Override
	public String toString() {
		return "StofSubmitPo [fundFromName=" + fundFromName + ", fundToName=" + fundToName + ", nav=" + nav + ", unit=" + unit + ", ammount=" + ammount + ", frequency=" + frequency
				+ ", numberOfTransfer=" + numberOfTransfer + ", unitOrAmount=" + unitOrAmount + ", totalValue=" + totalValue + ", fromUnit=" + fromUnit + ", fromAmount=" + fromAmount + ", toNAV="
				+ toNAV + ", toUnit=" + toUnit + ", toAmount=" + toAmount + "]";
	}

}
