package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Date;

public class TrackerResponsePO implements Serializable {

	private Long requestId;
	private String requestedDate;
	private Long spaarcId;
	private String status;
	private String functionality;

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public String getRequestedDate() {
		return requestedDate;
	}

	public void setRequestedDate(String requestedDate) {
		this.requestedDate = requestedDate;
	}

	public Long getSpaarcId() {
		return spaarcId;
	}

	public void setSpaarcId(Long spaarcId) {
		this.spaarcId = spaarcId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFunctionality() {
		return functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}

	@Override
	public String toString() {
		return "TrackerResponsePO [requestId=" + requestId + ", requestedDate=" + requestedDate + ", spaarcId=" + spaarcId + ", status=" + status + ", functionality=" + functionality + "]";
	}

}
