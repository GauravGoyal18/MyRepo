package com.ipru.groups.po;

import java.lang.reflect.Field;

public class UnitStatementPO {
	
	private String startDate;
	private String endDate;
	
	
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
	@Override
	public String toString() {
		return "UnitStatementPO [startDate=" + startDate + ", endDate="
				+ endDate + "]";
	}
	
	
	 public String getFieldName(String fieldName) throws NoSuchFieldException, SecurityException, ClassNotFoundException{
		Field field =UnitStatementPO.class.getDeclaredField(fieldName);
		/*field.setAccessible(true);*/
		return field.getName();
		
		/*Field field = UnitStatementPO.getClass().getDeclaredField(fieldName);
		null;*/
	}

}
