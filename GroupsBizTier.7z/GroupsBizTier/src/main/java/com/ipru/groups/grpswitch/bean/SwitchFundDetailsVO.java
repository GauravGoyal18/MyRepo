package com.ipru.groups.grpswitch.bean;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.ipru.groups.vo.GroupsBaseVO;
import com.ipru.groups.vo.ProductSwitchAmountVO;

public class SwitchFundDetailsVO extends GroupsBaseVO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long switchFundDetailsId;
	private String fromFundCode;
	private String toFundCode;
	private String fromFundName;
	private String toFundName;
	private String switchType;
	private String fromNAV;   
	private String fromUnit;  
	private String fromAmount;
	private String toUnit;  
	private String toAmount;
	
	private String unitsOrAmount;
	private SwitchTransactionVO switchTransactionVO;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	private String status;
	
	public String getStatus() {
	return (this.status == null || (this.status != null && this.status.equals(""))) ? "1" : status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getSwitchFundDetailsId() {
		return switchFundDetailsId;
	}
	public void setSwitchFundDetailsId(Long switchFundDetailsId) {
		this.switchFundDetailsId = switchFundDetailsId;
	}
	public String getFromFundCode() {
		return fromFundCode;
	}
	public void setFromFundCode(String fromFundCode) {
		this.fromFundCode = fromFundCode;
	}
	public String getToFundCode() {
		return toFundCode;
	}
	public void setToFundCode(String toFundCode) {
		this.toFundCode = toFundCode;
	}
	public String getSwitchType() {
		return switchType;
	}
	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}
	public String getFromNAV() {
		return fromNAV;
	}
	public void setFromNAV(String fromNAV) {
		this.fromNAV = fromNAV;
	}
	public String getFromUnit() {
		return fromUnit;
	}
	public void setFromUnit(String fromUnit) {
		this.fromUnit = fromUnit;
	}
	public String getFromAmount() {
		return fromAmount;
	}
	public void setFromAmount(String fromAmount) {
		this.fromAmount = fromAmount;
	}
	public String getToUnit() {
		return toUnit;
	}
	public void setToUnit(String toUnit) {
		this.toUnit = toUnit;
	}
	public String getToAmount() {
		return toAmount;
	}
	public void setToAmount(String toAmount) {
		this.toAmount = toAmount;
	}
	public SwitchTransactionVO getSwitchTransactionVO() {
		return switchTransactionVO;
	}
	public void setSwitchTransactionVO(SwitchTransactionVO switchTransactionVO) {
		this.switchTransactionVO = switchTransactionVO;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUnitsOrAmount() {
		return unitsOrAmount;
	}
	public void setUnitsOrAmount(String unitsOrAmount) {
		this.unitsOrAmount = unitsOrAmount;
	}
	public String getFromFundName() {
		return fromFundName;
	}
	public void setFromFundName(String fromFundName) {
		this.fromFundName = fromFundName;
	}
	public String getToFundName() {
		return toFundName;
	}
	public void setToFundName(String toFundName) {
		this.toFundName = toFundName;
	}
	
	
}

