package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Map;

public class YYEmployeeFormPO implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String employeeId;
	private String employeeName;
	private String employeeGender;
	private String employeeSalary;
	private String medical;
	private String employeeDOBString;
	private String employeeProfession;
	private YYAddress address;
	private String employeeColours;
	private Map<String, Object> coloursMap;
	private String successFailure;

	public String getEmployeeId() {
		return employeeId;
	}
	public YYAddress getAddress() {
		return address;
	}
	public void setAddress(YYAddress address) {
		this.address = address;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(String employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	public String getEmployeeDOBString() {
		return employeeDOBString;
	}
	public void setEmployeeDOBString(String employeeDOBString) {
		this.employeeDOBString = employeeDOBString;
	}
	public String getMedical() {
		return medical;
	}
	public void setMedical(String medical) {
		this.medical = medical;
	}
	public String getEmployeeGender() {
		return employeeGender;
	}
	public void setEmployeeGender(String employeeGender) {
		this.employeeGender = employeeGender;
	}
	public String getEmployeeProfession() {
		return employeeProfession;
	}
	public void setEmployeeProfession(String employeeProfession) {
		this.employeeProfession = employeeProfession;
	}
	public String getEmployeeColours() {
		return employeeColours;
	}
	public void setEmployeeColours(String employeeColours) {
		this.employeeColours = employeeColours;
	}
	
	public Map<String, Object> getColoursMap() {
		return coloursMap;
	}
	public void setColoursMap(Map<String, Object> coloursMap) {
		this.coloursMap = coloursMap;
	}

	public String getSuccessFailure() {
		return successFailure;
	}
	public void setSuccessFailure(String successFailure) {
		this.successFailure = successFailure;
	}
	
}

