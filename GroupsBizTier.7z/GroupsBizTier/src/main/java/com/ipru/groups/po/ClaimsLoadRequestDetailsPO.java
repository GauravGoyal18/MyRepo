package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ClaimsLoadRequestDetailsPO implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*private PolicyDetailsPO policyDetails;*/
	private List<RoleScreenAccessMappingPO> accessMappingList;
	private Map<String, FieldAccessMappingPO> fieldAccessMappingMap;
	
	

	

	public ClaimsLoadRequestDetailsPO() {
		super();
		// TODO Auto-generated constructor stub
	}



	public List<RoleScreenAccessMappingPO> getAccessMappingList() {
		return accessMappingList;
	}


	public void setAccessMappingList(
			List<RoleScreenAccessMappingPO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}


	




	public static long getSerialversionuid() {
		return serialVersionUID;
	}




	public Map<String, FieldAccessMappingPO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}


	public void setFieldAccessMappingMap(
			Map<String, FieldAccessMappingPO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}


	@Override
	public String toString() {
		return "ClaimsLoadRequestDetailsPO [accessMappingList=" + accessMappingList + ", fieldAccessMappingMap=" + fieldAccessMappingMap + "]";
	}



}
