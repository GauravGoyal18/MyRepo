package com.ipru.groups.po;

import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.tcs.logger.FLogger;

public class DownloadExcelUtil {

	public String createExcel(List result, String memberType, String productType) throws Exception {
		FLogger.info("MemberDataLogger", "createExcel",
				"getBizResponseForLoadMemberData", "createExcel Starts");
		String filePath = "D://MemberData.xlsx";
		FileOutputStream out = new FileOutputStream(filePath);
		if (result != null) {
			// for trust
			if (memberType.equals("TRUST")) {
				if(productType.equalsIgnoreCase("GRATUITY")){
					XSSFWorkbook workbook = new XSSFWorkbook();
					
					CellStyle style = workbook.createCellStyle();
					Font font = workbook.createFont();
					font.setBold(true);
					style.setFont(font);
					
					XSSFSheet spreadsheet = workbook.createSheet("employe db");
					XSSFRow row = spreadsheet.createRow(0);
					XSSFCell cell;
					XSSFCell headerCell;
					
					
					headerCell = row.createCell(0);
					headerCell.setCellStyle(style);
					headerCell.setCellValue("MemberID");
					
					headerCell = row.createCell(1);
					headerCell.setCellStyle(style);
					headerCell.setCellValue("MemberName");
					
					headerCell = row.createCell(2);
					headerCell.setCellStyle(style);
					headerCell.setCellValue("DateOfBirth");
					
					headerCell = row.createCell(3);
					headerCell.setCellStyle(style);
					headerCell.setCellValue("DateofJoining");

					int i = 1;
					Iterator iterator = result.iterator();
					try {
						while (iterator.hasNext()) {
							MemberDataTrustPO memberdatatrustvo1 = (MemberDataTrustPO) iterator
									.next();

							row = spreadsheet.createRow(i);
							cell = row.createCell(0);
							cell.setCellValue(memberdatatrustvo1.getMemberId());
							cell = row.createCell(1);
							cell.setCellValue(memberdatatrustvo1.getMemberName());
							cell = row.createCell(2);
							cell.setCellValue(memberdatatrustvo1.getDateOfBirth());
							cell = row.createCell(3);
							cell.setCellValue(memberdatatrustvo1.getDateOfJoining());

							i++;

						}

						workbook.write(out);
						out.flush();
						out.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				} else {
					XSSFWorkbook workbook = new XSSFWorkbook();
					
					CellStyle style = workbook.createCellStyle();
					Font font = workbook.createFont();
					font.setBold(true);
					style.setFont(font);
					
					XSSFSheet spreadsheet = workbook.createSheet("employe db");
					XSSFRow row = spreadsheet.createRow(0);
					XSSFCell cell;
					XSSFCell headerCell;
					
					headerCell = row.createCell(0);
					headerCell.setCellStyle(style);
					headerCell.setCellValue("MemberID");
					headerCell = row.createCell(1);
					headerCell.setCellStyle(style);
					headerCell.setCellValue("MemberName");
					headerCell = row.createCell(2);
					headerCell.setCellStyle(style);
					headerCell.setCellValue("TotalUnits");
					headerCell = row.createCell(3);
					headerCell.setCellStyle(style);
					headerCell.setCellValue("DateofJoining");

					int i = 1;
					Iterator iterator = result.iterator();
					try {
						while (iterator.hasNext()) {
							MemberDataTrustPO memberdatatrustvo1 = (MemberDataTrustPO) iterator
									.next();

							row = spreadsheet.createRow(i);
							cell = row.createCell(0);
							cell.setCellValue(memberdatatrustvo1.getMemberId());
							cell = row.createCell(1);
							cell.setCellValue(memberdatatrustvo1.getMemberName());
							cell = row.createCell(2);
							cell.setCellValue(memberdatatrustvo1.getUnits());
							cell = row.createCell(3);
							cell.setCellValue(memberdatatrustvo1.getDateOfJoining());

							i++;

						}

						workbook.write(out);
						out.flush();
						out.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

			// for term
			if (memberType.equals("TERM") || memberType.equals("GTRUST")) {
				XSSFWorkbook workbook = new XSSFWorkbook();
				
				CellStyle style = workbook.createCellStyle();
				Font font = workbook.createFont();
				font.setBold(true);
				style.setFont(font);
				
				XSSFSheet spreadsheet = workbook.createSheet("employe db");
				XSSFRow row = spreadsheet.createRow(0);
				XSSFCell cell;
				XSSFCell headerCell;
				
				headerCell = row.createCell(0);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("PolicyNo");
				headerCell = row.createCell(1);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("MemberID");
				headerCell = row.createCell(2);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("MemberName");
				headerCell = row.createCell(3);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("BirthDate");
				headerCell = row.createCell(4);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("Gender");
				headerCell = row.createCell(5);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("DateOfJoiningCompany");
				headerCell = row.createCell(6);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("UnitCode");
				headerCell = row.createCell(7);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("Designation");
				headerCell = row.createCell(8);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("coverProvided");
				headerCell = row.createCell(9);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("coverRequested");
				headerCell = row.createCell(10);
				headerCell.setCellStyle(style);
				headerCell.setCellValue("medicalRequired");

				int i = 1;
				Iterator iterator = result.iterator();
				try {
					while (iterator.hasNext()) {
						MemberDataTermPO MemberDataTermpo = (MemberDataTermPO) iterator
								.next();

						row = spreadsheet.createRow(i);
						cell = row.createCell(0);
						cell.setCellValue(MemberDataTermpo.getPolicyNo());
						cell = row.createCell(1);
						cell.setCellValue(MemberDataTermpo.getMemberId());
						cell = row.createCell(2);
						cell.setCellValue(MemberDataTermpo.getMemberName());
						cell = row.createCell(3);
						cell.setCellValue(MemberDataTermpo.getDateOfBirth());
						cell = row.createCell(4);
						cell.setCellValue(MemberDataTermpo.getGender());
						cell = row.createCell(5);
						cell.setCellValue(MemberDataTermpo.getDateOfJoining());
						cell = row.createCell(6);
						cell.setCellValue(MemberDataTermpo.getUnitCode());
						cell = row.createCell(7);
						cell.setCellValue(MemberDataTermpo.getDesignation());
						cell = row.createCell(8);
						cell.setCellValue(MemberDataTermpo.getCoverProvided());
						cell = row.createCell(9);
						cell.setCellValue(MemberDataTermpo.getCoverRequested());
						cell = row.createCell(10);
						cell.setCellValue(MemberDataTermpo.getMedicalRequired());

						i++;

					}

					workbook.write(out);
					out.flush();
					out.close();
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
			return filePath;

		}
		return filePath;
	}
}
