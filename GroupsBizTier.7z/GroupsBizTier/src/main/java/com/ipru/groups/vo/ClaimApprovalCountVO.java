package com.ipru.groups.vo;

public class ClaimApprovalCountVO extends GroupsBaseVO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private long approvalCount;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getApprovalCount() {
		return approvalCount;
	}

	public void setApprovalCount(long approvalCount) {
		this.approvalCount = approvalCount;
	}

}
