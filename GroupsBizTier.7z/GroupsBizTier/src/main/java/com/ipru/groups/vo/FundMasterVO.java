package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class FundMasterVO extends GroupsBaseVO  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fundCode;
	private String fundName;
	private String isActive;
	private String isCapital;
	private String isReturnGuarantee;
	private String isAssetType;
	
	public FundMasterVO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getFundCode() {
		return fundCode;
	}


	public void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}


	public String getFundName() {
		return fundName;
	}


	public void setFundName(String fundName) {
		this.fundName = fundName;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}


	public String getIsCapital() {
		return isCapital;
	}


	public void setIsCapital(String isCapital) {
		this.isCapital = isCapital;
	}


	public String getIsReturnGuarantee() {
		return isReturnGuarantee;
	}


	public void setIsReturnGuarantee(String isReturnGuarantee) {
		this.isReturnGuarantee = isReturnGuarantee;
	}


	public String getIsAssetType() {
		return isAssetType;
	}


	public void setIsAssetType(String isAssetType) {
		this.isAssetType = isAssetType;
	}

}
