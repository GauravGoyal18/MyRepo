package com.ipru.groups.client;

import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ipru.groups.grpswitch.bean.FundDetailsVO;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.logger.FLogger;

public class FundPerformanceClient {

	/**
	 * @param args
	 */
	
	public static String fetchFundDetails(String fundCodes) throws NullPointerException,Exception{
		FLogger.info("SwitchLogger", "FundPerformanceClient", "fetchFundDetails","Method Start");
	

		String responseStr = "";
		
		if (StringUtils.isEmpty(fundCodes)) {
			return responseStr;
		}
		
		String requestParameters = "fundCodes=" + fundCodes;
		HttpClientBuilder clientBuilder = HttpClientBuilder.create();
		
		Properties properties = MasterPropertiesFileLoader.CONSTANT_FUND_PERFORMANCE_WS;
		String proxyHost = properties.getProperty("proxyHost");
		String proxyPort = properties.getProperty("proxyPort");
		String targetUri = properties.getProperty("fundperformanceWS");
		final int WS_CONNECTION_TIMEOUT_MS = Integer.parseInt(properties.getProperty("WS_CONNECTION_TIMEOUT_MS"));
		final int WS_SOCKET_TIMEOUT_MS = Integer.parseInt(properties.getProperty("WS_SOCKET_TIMEOUT_MS"));
		
		/*String proxyHost = "10.50.37.138";
		String proxyPort = "9443";
		String targetUri = "http://10.50.37.138:9443/digital/FundPerformaceWS?";
		final int WS_CONNECTION_TIMEOUT_MS = 10000;
		final int WS_SOCKET_TIMEOUT_MS = 10000;*/
		
		RequestConfig params = RequestConfig.custom().setConnectTimeout(WS_CONNECTION_TIMEOUT_MS).setSocketTimeout(WS_SOCKET_TIMEOUT_MS).build();
		
		String url = targetUri + requestParameters;
		
		HttpHost proxy = new HttpHost(proxyHost, Integer.parseInt(proxyPort));
		HttpHost target = new HttpHost(url);
		clientBuilder.useSystemProperties();
		clientBuilder.setProxy(proxy);
		HttpPost postRequest = new HttpPost(url);
		postRequest.setConfig(params);
		CloseableHttpClient client = clientBuilder.build();
		CloseableHttpResponse response = null;
		
		FLogger.info("SwitchLogger", "FundPerformanceClient", "fetchFundDetails","Start Time ::: "+Calendar.getInstance().getTime());
		////System.out.println("Start Time ::: "+Calendar.getInstance().getTime());
		////System.out.println(Calendar.getInstance().getTime());
		response = client.execute(target,postRequest);
		//////System.out.println("vfdf  "+response);
		responseStr = EntityUtils.toString(response.getEntity());
		FLogger.info("SwitchLogger", "FundPerformanceClient", "fetchFundDetails","End Time ::: "+Calendar.getInstance().getTime());
		////System.out.println("End Time ::: "+Calendar.getInstance().getTime());
		//////System.out.println("vfdf  "+responseStr);
		////System.out.println(Calendar.getInstance().getTime());
		
		FLogger.info("SwitchLogger", "FundPerformanceClient", "fetchFundDetails","Method Start");
				
		
		return responseStr;
		
	}
	
	
	public static void main(String[] args) throws NullPointerException, Exception {
		

		Gson gsonJSON = new Gson();
		
		String fundPerformanceString = FundPerformanceClient.fetchFundDetails("DBT,GTH");
		//System.out.println(fundPerformanceString);
		
		
		String fundNAVString ="[{\"funddesc\":\"Group Debt Fund\",\"sfin\":\"ULGF 002 03/04/03 GDebt 105\",\"fundcode\":\"DBT\",\"units\":\"37226.039\",\"navValue\":\"30.4453\",\"totalAmount\":1133357.9251666998},{\"funddesc\":\"Group Growth Fund\",\"sfin\":\"ULGF 004 30/10/03 GGrowth 105\",\"fundcode\":\"GTH\",\"units\":\"21262.845\",\"navValue\":\"60.1372\",\"totalAmount\":1278687.962334}]";
		List<FundDetailsVO> fundNAVList = gsonJSON.fromJson(fundNAVString, new TypeToken<List<FundDetailsVO>>(){}.getType());
		
		
		Map<String,FundDetailsVO> returnInceptionVOMap = gsonJSON .fromJson(fundPerformanceString, new TypeToken<Map<String,FundDetailsVO>>(){}.getType());
		
		FundDetailsVO returnInception;
		
		for(FundDetailsVO fundNAV : fundNAVList){
			for (Map.Entry<String, FundDetailsVO> entry : returnInceptionVOMap.entrySet()) {
				
				////System.out.println("Key : " + entry.getKey() + " Value : " + entry.getValue());
				
				String key = entry.getKey();
				 returnInception = entry.getValue();
				
				if(StringUtils.equalsIgnoreCase(returnInception.getFundName(), fundNAV.getFundDesc()))
				{
					fundNAV.setAssetsInvested(returnInception.getAssetsInvested());
					fundNAV.setAumDebtCategory(returnInception.getAumDebtCategory());
					fundNAV.setAumEquityCategory(returnInception.getAumEquityCategory());
					fundNAV.setAumMoneyMarketCashCategory(returnInception.getAumMoneyMarketCashCategory());
					fundNAV.setBenchMark(returnInception.getBenchMark());
					fundNAV.setBenchmarkFifthYear(returnInception.getBenchmarkFifthYear());
					fundNAV.setBenchmarkFirstYear(returnInception.getBenchmarkFirstYear());
					fundNAV.setBenchmarkInception(returnInception.getBenchmarkInception());
					fundNAV.setBenchmarkThirdYear(returnInception.getBenchmarkThirdYear());
					fundNAV.setFifthYearReturns(returnInception.getFifthYearReturns());
					fundNAV.setFirstYearReturns(returnInception.getFirstYearReturns());
					//fundNAV.setFundCode(returnInception.getFundCode());
					//fundNAV.setFundDesc(returnInception.getFundDesc());
					fundNAV.setFundName(returnInception.getFundName());
					fundNAV.setFundObjective(returnInception.getFundObjective());
					fundNAV.setReturnsSinceInception(returnInception.getReturnsSinceInception());
					fundNAV.setInceptionDate(returnInception.getInceptionDate());
					//fundNAV.setNavValue(returnInception.getNavValue());
					fundNAV.setPortfolioByMaturityBalAvg(returnInception.getPortfolioByMaturityBalAvg());
					fundNAV.setPortfolioByMaturityDebtAvg(returnInception.getPortfolioByMaturityDebtAvg());
					//fundNAV.setsFin(returnInception.getsFin());
					fundNAV.setThirdYearReturns(returnInception.getThirdYearReturns());
					//fundNAV.setTotalAmount(returnInception.getTotalAmount());
					//fundNAV.setUnits(returnInception.getUnits());
					
					//System.out.println(fundNAV.getNavValue());
					//System.out.println(fundNAV.getFundName());
					//System.out.println(fundNAV.getReturnsSinceInception());
					//System.out.println(fundNAV.getFirstYearReturns());
					
					break;
				}
			}
			
			//System.out.println(fundNAV.toString());
		}
		
		
		
		
	}
	
}
