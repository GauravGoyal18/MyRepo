package com.ipru.groups.po;

import java.util.List;
import java.util.Map;

import com.ipru.groups.po.RoleScreenAccessMappingPO;
import com.tcs.web.vo.BaseVO;

public class UnitStmtLoadResGratuityAcceeMappingPO extends BaseVO {
	
	private static final long serialVersionUID = 1L;
	private List<RoleScreenAccessMappingPO> accessMappingList;
	private Map<String, FieldAccessMappingPO> fieldAccessMappingMap;
	



	public UnitStmtLoadResGratuityAcceeMappingPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Map<String, FieldAccessMappingPO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}



	public void setFieldAccessMappingMap(
			Map<String, FieldAccessMappingPO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}



	public void setAccessMappingList(
			List<RoleScreenAccessMappingPO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}



	public List<RoleScreenAccessMappingPO> getAccessMappingList() {
		return accessMappingList;
	}



	@Override
	public String toString() {
		return "UnitStmtLoadResGratuityAcceeMappingPO [accessMappingList="
				+ accessMappingList + ", fieldAccessMappingMap="
				+ fieldAccessMappingMap + "]";
	}



}
