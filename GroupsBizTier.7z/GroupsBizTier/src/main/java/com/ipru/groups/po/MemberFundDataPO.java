package com.ipru.groups.po;

import java.io.Serializable;

public class MemberFundDataPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fundType;
	private double units;
	private double nav;
	private double value;
	private String sfin;

	public MemberFundDataPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberFundDataPO(String fundType, double units, double nav, double value, String sfin) {
		super();
		this.fundType = fundType;
		this.units = units;
		this.nav = nav;
		this.value = value;
		this.sfin = sfin;
	}

	public String getFundType() {
		return fundType;
	}

	public void setFundType(String fundType) {
		this.fundType = fundType;
	}

	public double getUnits() {
		return units;
	}

	public void setUnits(double units) {
		this.units = units;
	}

	public double getNav() {
		return nav;
	}

	public void setNav(double nav) {
		this.nav = nav;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}
	
	public String getSfin() {
		return sfin;
	}

	public void setSfin(String sfin) {
		this.sfin = sfin;
	}

	@Override
	public String toString() {
		return "MemberFundDataPO [fundType=" + fundType + ", units=" + units
				+ ", nav=" + nav + ", value=" + value + ", sfin=" + sfin + "]";
	}
}
