package com.ipru.groups.vo;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProfileUpdateTranscationVO extends GroupsBaseVO implements ISpaarcCallLog {

	@Override
	public String toString() {
		return "ProfileUpdateTranscationVO [requestId=" + requestId + ", unitId=" + unitId + ", memberId=" + memberId + ", currentDate=" + currentDate + ", category=" + category + ", trusteeName="
				+ trusteeName + ", updateReqId=" + ", functionality=" + functionality + ", profileUpdateDetailsVOSet=" + profileUpdateDetailsVOSet + ", profileUpdateDetailsVOList="
				+ profileUpdateDetailsVOList + "]";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long requestId;
	private String unitId;
	private String memberId;
	private Date currentDate;
	private String category;
	private String trusteeName;

	private FunctionalityMasterVO functionality;
	private List<UploadFileVO> getUploadFileVOList;

	public List<UploadFileVO> getGetUploadFileVOList() {
		return getUploadFileVOList;
	}

	public void setGetUploadFileVOList(List<UploadFileVO> getUploadFileVOList) {
		this.getUploadFileVOList = getUploadFileVOList;
	}

	private Set<ProfileUpdateDetailsVo> profileUpdateDetailsVOSet = new HashSet<ProfileUpdateDetailsVo>(0);
	private List<ProfileUpdateDetailsVo> profileUpdateDetailsVOList;

	public Set<ProfileUpdateDetailsVo> getProfileUpdateDetailsVOSet() {
		return profileUpdateDetailsVOSet;
	}

	public void setProfileUpdateDetailsVOSet(Set<ProfileUpdateDetailsVo> profileUpdateDetailsVOSet) {
		this.profileUpdateDetailsVOSet = profileUpdateDetailsVOSet;
	}

	public List<ProfileUpdateDetailsVo> getProfileUpdateDetailsVOList() {
		return profileUpdateDetailsVOList;
	}

	public void setProfileUpdateDetailsVOList(List<ProfileUpdateDetailsVo> profileUpdateDetailsVOList) {
		this.profileUpdateDetailsVOList = profileUpdateDetailsVOList;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getTrusteeName() {
		return trusteeName;
	}

	public void setTrusteeName(String trusteeName) {
		this.trusteeName = trusteeName;
	}

	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}

	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}

	@Override
	public String getFunctionalityReqId() {
		return String.valueOf(getRequestId());
	}

}
