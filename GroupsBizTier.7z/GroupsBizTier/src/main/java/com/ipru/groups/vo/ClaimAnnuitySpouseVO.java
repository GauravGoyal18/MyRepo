package com.ipru.groups.vo;

import java.util.Date;

public class ClaimAnnuitySpouseVO extends GroupsBaseVO {

	private Long spouseId;

	private String name;
	private String dateofBirth;
	private String gender;
	private String address1;
	private String address2;
	private String address3;
	private String state;
	private String city;
	private String pinCode;
	private String landlineNo;
	private String mobileNo;
	private Long claimTxnId;
	private ClaimAnnuitySubmitVO claimAnnuitySubmitVO;

	
	public ClaimAnnuitySubmitVO getClaimAnnuitySubmitVO() {
		return claimAnnuitySubmitVO;
	}

	public void setClaimAnnuitySubmitVO(ClaimAnnuitySubmitVO claimAnnuitySubmitVO) {
		this.claimAnnuitySubmitVO = claimAnnuitySubmitVO;
	}

	public Long getSpouseId() {
		return spouseId;
	}

	public void setSpouseId(Long spouseId) {
		this.spouseId = spouseId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(String dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getLandlineNo() {
		return landlineNo;
	}

	public void setLandlineNo(String landlineNo) {
		this.landlineNo = landlineNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Long getClaimTxnId() {
		return claimTxnId;
	}

	public void setClaimTxnId(Long claimTxnId) {
		this.claimTxnId = claimTxnId;
	}

}
