package com.ipru.groups.po;

import java.util.ArrayList;
import java.util.Arrays;

public class NomineeUpdateParameters {

	private String value;
	private int nomineeCount;
	ArrayList<String> relations;
	ArrayList<String> genders;

	boolean appointeeDetailsFlag[];

	public boolean[] getAppointeeDetailsFlag() {
		return appointeeDetailsFlag;
	}

	public void setAppointeeDetailsFlag(boolean[] appointeeDetailsFlag) {
		this.appointeeDetailsFlag = appointeeDetailsFlag;
	}

	public ArrayList<String> getGenders() {
		return genders;
	}

	public void setGenders(ArrayList<String> genders) {
		this.genders = genders;
	}

	public ArrayList<String> getRelations() {
		return relations;
	}

	public void setRelations(ArrayList<String> relations) {
		this.relations = relations;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getNomineeCount() {
		return nomineeCount;
	}

	public void setNomineeCount(int nomineeCount) {
		this.nomineeCount = nomineeCount;
	}

	@Override
	public String toString() {
		return "NomineeUpdateParameters [value=" + value + ", nomineeCount=" + nomineeCount + ", relations=" + relations + ", genders=" + genders + ", appointeeDetailsFlag="
				+ Arrays.toString(appointeeDetailsFlag) + "]";
	}

}
