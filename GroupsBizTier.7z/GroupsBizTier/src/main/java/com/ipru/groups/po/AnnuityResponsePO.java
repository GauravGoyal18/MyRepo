package com.ipru.groups.po;

import com.tcs.web.po.BasePO;

public class AnnuityResponsePO extends BasePO{
	private String incomeOption;
	private Double yearlyAmount;
	private Double halfYearlyAmount;
	private Double quaterlyAmount;
	private Double monthlyAmount;
	public String getIncomeOption() {
		return incomeOption;
	}
	public void setIncomeOption(String incomeOption) {
		this.incomeOption = incomeOption;
	}
	public Double getYearlyAmount() {
		return yearlyAmount;
	}
	public void setYearlyAmount(Double yearlyAmount) {
		this.yearlyAmount = yearlyAmount;
	}
	public Double getHalfYearlyAmount() {
		return halfYearlyAmount;
	}
	public void setHalfYearlyAmount(Double halfYearlyAmount) {
		this.halfYearlyAmount = halfYearlyAmount;
	}
	public Double getQuaterlyAmount() {
		return quaterlyAmount;
	}
	public void setQuaterlyAmount(Double quaterlyAmount) {
		this.quaterlyAmount = quaterlyAmount;
	}
	public Double getMonthlyAmount() {
		return monthlyAmount;
	}
	public void setMonthlyAmount(Double monthlyAmount) {
		this.monthlyAmount = monthlyAmount;
	}
	@Override
	public String toString() {
		return "AnnuityResponse [incomeOption=" + incomeOption
				+ ", yearlyAmount=" + yearlyAmount + ", halfYearlyAmount="
				+ halfYearlyAmount + ", quaterlyAmount=" + quaterlyAmount
				+ ", monthlyAmount=" + monthlyAmount + "]";
	}

	
	
}
