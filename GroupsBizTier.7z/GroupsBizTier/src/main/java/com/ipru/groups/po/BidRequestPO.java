package com.ipru.groups.po;

import java.util.Calendar;
import java.util.Date;

public class BidRequestPO {
private String policyKey;
private String startDt;
private String endDt;
private String unitCode;
private String requestId;
private String userID;
@Override
public String toString() {
	return "BidRequestPO [policyKey=" + policyKey + ", startDt=" + startDt
			+ ", endDt=" + endDt + ", unitCode=" + unitCode + ", requestId="
			+ requestId + ", userID=" + userID + "]";
}
public String getPolicyKey() {
	return policyKey;
}
public void setPolicyKey(String policyKey) {
	this.policyKey = policyKey;
}
public String getStartDt() {
	return startDt;
}
public void setStartDt(String startDt) {
	this.startDt = startDt;
}
public String getEndDt() {
	return endDt;
}
public void setEndDt(String endDt) {
	this.endDt = endDt;
}
public String getUnitCode() {
	return unitCode;
}
public void setUnitCode(String unitCode) {
	this.unitCode = unitCode;
}
public String getRequestId() {
	return requestId;
}
public void setRequestId(String requestId) {
	this.requestId = requestId;
}
public String getUserID() {
	return userID;
}
public void setUserID(String userID) {
	this.userID = userID;
}


}
