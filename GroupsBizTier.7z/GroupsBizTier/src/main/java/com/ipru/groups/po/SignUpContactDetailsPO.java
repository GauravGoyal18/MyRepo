package com.ipru.groups.po;

public class SignUpContactDetailsPO extends GroupsBasePo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String emailId;
	private long mobileNo;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

}
