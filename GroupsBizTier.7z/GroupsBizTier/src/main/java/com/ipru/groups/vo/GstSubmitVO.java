package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class GstSubmitVO extends BaseVO {

	private static final long serialVersionUID = 1L;

	private long requestId;
	private String customerName;
	private String policyNumber;
	private String cob;
	private String otherCOB;
	private String panNumber;
	private String customerType;
	private String otherCustomerType;
	private String gstExemptionNo;
	private String totalNoGst;
	private String registrationStatus;
	private String registrationDate;
	private String gstinOrUin;
	private String address;
	private String pinCode;
	private String state;
	private String stateCode;
	private String declarationName;
	private String declarationDesignation;
	private String declarationDate;
	private String isRegisteredUser;
	private String isdNo;

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getCob() {
		return cob;
	}

	public void setCob(String cob) {
		this.cob = cob;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getTotalNoGst() {
		return totalNoGst;
	}

	public void setTotalNoGst(String totalNoGst) {
		this.totalNoGst = totalNoGst;
	}

	public String getRegistrationStatus() {
		return registrationStatus;
	}

	public void setRegistrationStatus(String registrationStatus) {
		this.registrationStatus = registrationStatus;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getGstinOrUin() {
		return gstinOrUin;
	}

	public void setGstinOrUin(String gstinOrUin) {
		this.gstinOrUin = gstinOrUin;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getDeclarationName() {
		return declarationName;
	}

	public void setDeclarationName(String declarationName) {
		this.declarationName = declarationName;
	}

	public String getDeclarationDesignation() {
		return declarationDesignation;
	}

	public void setDeclarationDesignation(String declarationDesignation) {
		this.declarationDesignation = declarationDesignation;
	}

	public String getDeclarationDate() {
		return declarationDate;
	}

	public void setDeclarationDate(String declarationDate) {
		this.declarationDate = declarationDate;
	}

	public String getGstExemptionNo() {
		return gstExemptionNo;
	}

	public void setGstExemptionNo(String gstExemptionNo) {
		this.gstExemptionNo = gstExemptionNo;
	}

	public String getOtherCOB() {
		return otherCOB;
	}

	public void setOtherCOB(String otherCOB) {
		this.otherCOB = otherCOB;
	}

	public String getOtherCustomerType() {
		return otherCustomerType;
	}

	public void setOtherCustomerType(String otherCustomerType) {
		this.otherCustomerType = otherCustomerType;
	}

	public String getIsRegisteredUser() {
		return isRegisteredUser;
	}

	public void setIsRegisteredUser(String isRegisteredUser) {
		this.isRegisteredUser = isRegisteredUser;
	}

	public String getIsdNo() {
		return isdNo;
	}

	public void setIsdNo(String isdNo) {
		this.isdNo = isdNo;
	}

}
