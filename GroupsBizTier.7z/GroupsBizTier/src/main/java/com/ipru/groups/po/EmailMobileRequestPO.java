package com.ipru.groups.po;

import java.io.Serializable;

public class EmailMobileRequestPO implements Serializable {

	private String emailId;
	private long mobileNo;
	private String webClientId;
	private String policyNo;
	private String clientId;
	private String role;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "EmailMobileRequestPO [emailId=" + emailId + ", mobileNo=" + mobileNo + ", webClientId=" + webClientId + ", policyNo=" + policyNo + ", clientId=" + clientId + ", role=" + role + "]";
	}

}
