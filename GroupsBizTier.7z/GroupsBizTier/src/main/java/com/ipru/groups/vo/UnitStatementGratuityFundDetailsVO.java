package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class UnitStatementGratuityFundDetailsVO extends BaseVO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String transDate;
	private String description;
	private String transDescription;
	private String amount;
	private String navValue;
	private String units;
	private String totalUnits;
	private String value;
	public String getDescription() {
		return description;
	}
	public String getTransDate() {
		return transDate;
	}
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	public String fundData() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTransDescription() {
		return transDescription;
	}
	public void setTransDescription(String transDescription) {
		this.transDescription = transDescription;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getNavValue() {
		return navValue;
	}
	public void setNavValue(String navValue) {
		this.navValue = navValue;
	}
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	public String getTotalUnits() {
		return totalUnits;
	}
	public void setTotalUnits(String totalUnits) {
		this.totalUnits = totalUnits;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
	
	@Override
	public String toString() {
		return "UnitStatementGratuityFundDetails [transDate=" + transDate
				+ ", description=" + description + ", transDescription="
				+ transDescription + ", amount=" + amount + ", navValue="
				+ navValue + ", units=" + units + ", totalUnits=" + totalUnits
				+ ", value=" + value + "]";
	}
	
	
	

}
