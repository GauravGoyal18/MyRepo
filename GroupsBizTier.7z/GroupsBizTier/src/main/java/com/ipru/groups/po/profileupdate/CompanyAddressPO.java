package com.ipru.groups.po.profileupdate;

import java.util.List;

import com.ipru.groups.po.GroupsBasePo;
import com.ipru.groups.po.UploadFilePO;

public class CompanyAddressPO extends GroupsBasePo {
	


	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;
	
	private FieldMeta addressType;
	private FieldMeta companyOrBuildingName;
	private FieldMeta flatOrUnitNumber;
	private FieldMeta streetOrArea;
	private FieldMeta landmark;
	private FieldMeta pincode;
	private FieldMeta city;
	private FieldMeta state;
	//private FieldMeta addressproof;
	private List<UploadFilePO> uploadFiles;
	private String prePopulateList;
	private String index;
	private long functionalityId;

	
	

	public long getFunctionalityId() {
		return functionalityId;
	}
	public void setFunctionalityId(long functionalityId) {
		this.functionalityId = functionalityId;
	}
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public String getPrePopulateList() {
		return prePopulateList;
	}
	public void setPrePopulateList(String prePopulateList) {
		this.prePopulateList = prePopulateList;
	}


	public List<UploadFilePO> getUploadFiles() {
		return uploadFiles;
	}
	public void setUploadFiles(List<UploadFilePO> uploadFiles) {
		this.uploadFiles = uploadFiles;
	}
	public FieldMeta getAddressType() {
		return addressType;
	}
	public void setAddressType(FieldMeta addressType) {
		this.addressType = addressType;
	}
	public FieldMeta getCompanyOrBuildingName() {
		return companyOrBuildingName;
	}
	public void setCompanyOrBuildingName(FieldMeta companyOrBuildingName) {
		this.companyOrBuildingName = companyOrBuildingName;
	}
	public FieldMeta getFlatOrUnitNumber() {
		return flatOrUnitNumber;
	}
	public void setFlatOrUnitNumber(FieldMeta flatOrUnitNumber) {
		this.flatOrUnitNumber = flatOrUnitNumber;
	}
	public FieldMeta getStreetOrArea() {
		return streetOrArea;
	}
	public void setStreetOrArea(FieldMeta streetOrArea) {
		this.streetOrArea = streetOrArea;
	}
	public FieldMeta getLandmark() {
		return landmark;
	}
	public void setLandmark(FieldMeta landmark) {
		this.landmark = landmark;
	}
	public FieldMeta getPincode() {
		return pincode;
	}
	public void setPincode(FieldMeta pincode) {
		this.pincode = pincode;
	}
	public FieldMeta getCity() {
		return city;
	}
	public void setCity(FieldMeta city) {
		this.city = city;
	}
	public FieldMeta getState() {
		return state;
	}
	public void setState(FieldMeta state) {
		this.state = state;
	}
	/*public FieldMeta getAddressproof() {
		return addressproof;
	}
	public void setAddressproof(FieldMeta addressproof) {
		this.addressproof = addressproof;
	}*/
	@Override
	public String toString() {
		return "CompanyAddressPO [addressType=" + addressType
				+ ", companyOrBuildingName=" + companyOrBuildingName
				+ ", flatOrUnitNumber=" + flatOrUnitNumber + ", streetOrArea="
				+ streetOrArea + ", landmark=" + landmark + ", pincode="
				+ pincode + ", city=" + city + ", state=" + state
				+ ", uploadFiles=" + uploadFiles + ", prePopulateList="
				+ prePopulateList + ", index=" + index + ", functionalityId="
				+ functionalityId + "]";
	}
	
	
	
	

}
