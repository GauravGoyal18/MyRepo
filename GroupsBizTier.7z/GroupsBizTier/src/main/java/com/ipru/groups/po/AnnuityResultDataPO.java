package com.ipru.groups.po;

import java.util.List;

import com.ipru.groups.vo.AnnuityResponseVO;

public class AnnuityResultDataPO {
	private  List<AnnuityResponseVO> list;
	private  List<AnnuityResponseVO> list1;
	public List<AnnuityResponseVO> getList() {
		return list;
	}
	public void setList(List<AnnuityResponseVO> list) {
		this.list = list;
	}
	public List<AnnuityResponseVO> getList1() {
		return list1;
	}
	public void setList1(List<AnnuityResponseVO> list1) {
		this.list1 = list1;
	}
	@Override
	public String toString() {
		return "AnnuityResultDataPO [list=" + list + ", list1=" + list1 + "]";
	}
	
	
}
