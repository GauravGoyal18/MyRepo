package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;

public class ClaimsRequestPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String fieldName;
	private String newValue;

	

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	@Override
	public String toString() {
		return "ClaimsRequestPO [fieldName=" + fieldName + ", newValue=" + newValue + "]";
	}

}
