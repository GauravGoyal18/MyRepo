package com.ipru.groups.vo;

public class AnnuityAuthenticationVO {
private String authKey;

public String getAuthKey() {
	return authKey;
}

public void setAuthKey(String authKey) {
	this.authKey = authKey;
}

@Override
public String toString() {
	return "AnnuityAuthenticationVO [authKey=" + authKey + "]";
}

}
