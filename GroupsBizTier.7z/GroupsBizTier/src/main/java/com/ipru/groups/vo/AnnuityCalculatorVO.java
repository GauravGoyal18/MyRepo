package com.ipru.groups.vo;

import java.io.Serializable;

public class AnnuityCalculatorVO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyType;
	private String annuitantGender;
	private int annuitantAge;
	private int spouseAge;
	private String channelType;
	private String incomeOption;
	private String calculatorMode;
	private String prevAnnuityAmt;
	private double inputAmt;
	private int ageDiff;
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getAnnuitantGender() {
		return annuitantGender;
	}
	public void setAnnuitantGender(String annuitantGender) {
		this.annuitantGender = annuitantGender;
	}
	public int getAnnuitantAge() {
		return annuitantAge;
	}
	public void setAnnuitantAge(int annuitantAge) {
		this.annuitantAge = annuitantAge;
	}
	public int getSpouseAge() {
		return spouseAge;
	}
	public void setSpouseAge(int spouseAge) {
		this.spouseAge = spouseAge;
	}
	public String getChannelType() {
		return channelType;
	}
	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}
	
	public String getIncomeOption() {
		return incomeOption;
	}
	public void setIncomeOption(String incomeOption) {
		this.incomeOption = incomeOption;
	}
	
	public String getCalculatorMode() {
		return calculatorMode;
	}
	public void setCalculatorMode(String calculatorMode) {
		this.calculatorMode = calculatorMode;
	}
	public String getPrevAnnuityAmt() {
		return prevAnnuityAmt;
	}
	public void setPrevAnnuityAmt(String prevAnnuityAmt) {
		this.prevAnnuityAmt = prevAnnuityAmt;
	}
	public double getInputAmt() {
		return inputAmt;
	}
	public void setInputAmt(double inputAmt) {
		this.inputAmt = inputAmt;
	}
	public int getAgeDiff() {
		return ageDiff;
	}
	public void setAgeDiff(int ageDiff) {
		this.ageDiff = ageDiff;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "AnnuityCalculatorVO [policyType=" + policyType
				+ ", annuitantGender=" + annuitantGender + ", annuitantAge="
				+ annuitantAge + ", spouseAge=" + spouseAge + ", channelType="
				+ channelType + ", incomeOption=" + incomeOption
				+ ", calculatorMode=" + calculatorMode + ", prevAnnuityAmt="
				+ prevAnnuityAmt + ", inputAmt=" + inputAmt + ", ageDiff="
				+ ageDiff + "]";
	}
	
	
}
