package com.ipru.groups.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import com.google.gson.Gson;
import com.ipru.groups.param.obj.ParamObj;
import com.ipru.groups.po.SwitchToRequest;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.tcs.logger.FLogger;

public class FundNAVClient {

	/**
	 * @param args
	 */
	
	public static String invokeFundNAVWS(Map<String,String> map){
		
		FLogger.info("FundNAVClient", "FundNAVClient", "invokeFundNAVWS","Method Start");
		//////System.out.println("FundNAVClient entering");
        Client clientGet = Client.create();

        List<String> paramList=new ArrayList<String>();

        //Load Property File
        Properties properties = MasterPropertiesFileLoader.CONSTANT_REST;
    	String restPath = properties.getProperty("REST_PATH");
    	String auth = properties.getProperty("AUTH");
        
        //paramList.add("00000364");
        //paramList.add("ME11443");// clientid
        
    	//Web service Time Out
        clientGet.setConnectTimeout(Integer.parseInt(properties.getProperty("CONNECT_TIMEOUT")));
        clientGet.setReadTimeout(Integer.parseInt(properties.getProperty("READ_TIMEOUT")));
        
        
        if(map != null){
			if(map.get("policy") != null && map.get("policy") instanceof String)
			{
				//paramList.add("00000348");//policynumber
				paramList.add((String)map.get("policy"));//policynumber
			}
			
			if(map.get("clientId") != null && map.get("clientId") instanceof String){
				 //paramList.add("ME11443");
				 paramList.add((String)map.get("clientId"));
			}
				
		}


        
        //for trust pass only policyNumber
        //for member pass both policynumber,clientid
        ParamObj paramObj=new ParamObj();
        paramObj.setParam(paramList);
       
        // create SwitchToRequest class as follow
        SwitchToRequest switchToRequest=new SwitchToRequest();
        switchToRequest.setParamObj(paramObj);

      //  pass SwitchToRequest pojo class object in post as a parameter as given bellow
    
		
        WebResource webResource = clientGet.resource(restPath+"groups/switch.rest");
        ClientResponse responseGet = webResource.type("application/json")
        			.header("Authorization",auth)
        			.post(ClientResponse.class,switchToRequest);

        FLogger.info("FundNAVClient", "Response status"+ responseGet.getStatus());
        ////System.out.println("Response status : "+responseGet.getStatus());
        String output = responseGet.getEntity(String.class);
        //System.out.println(output);
        FLogger.info("FundNAVClient", "Output of Fund NAV Webservice"+ output);
        
        // you will get response in list of SwitchTo bean which is given below
     //   ArrayList<SwitchTo> list=gson.fromJson(output, ArrayList.class);
       // ////System.out.println("Data"+list.toString());

        Gson gson=new Gson();
        String switchToRequestJson=gson.toJson(switchToRequest);
       // ////System.out.println("json"+switchToRequestJson);

//        ////System.out.println("FundNAVClient Leaving");
        FLogger.info("FundNAVClient", "FundNAVClient", "invokeFundNAVWS","Method End");
        return output;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<String,String> map = new HashMap<String,String>();
		map.put("policy","00000348");
		map.put("clientId","ME11443");
		String s = FundNAVClient.invokeFundNAVWS(map);
		//System.out.println(s);

	}

}
