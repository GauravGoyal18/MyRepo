package com.ipru.groups.po;

import java.io.Serializable;

public class ClaimsPMJJBYOnloadPO extends GroupsBasePo {

	private String schemeName;
	private String accountNumber;
	private String polHolderName;
	private String functionalityId;

	public String getSchemeName() {
		return schemeName;
	}

	public String getFunctionalityId() {
		return functionalityId;
	}

	public void setFunctionalityId(String functionalityId) {
		this.functionalityId = functionalityId;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getPolHolderName() {
		return polHolderName;
	}

	public void setPolHolderName(String polHolderName) {
		this.polHolderName = polHolderName;
	}

}
