package com.ipru.groups.po;

import java.util.List;

import com.ipru.groups.vo.ClaimAnnuityOptionVO;
import com.ipru.groups.vo.ClaimAnnuityWegaVO;

public class ClaimAnnuityOnloadPO extends GroupsBasePo {
	private List<ClaimAnnuityWegaPO> claimAnnuityWegaList;
	private List<ClaimAnnuityOptionPO> claimAnnuityOptionList;

	public List<ClaimAnnuityWegaPO> getClaimAnnuityWegaList() {
		return claimAnnuityWegaList;
	}

	public void setClaimAnnuityWegaList(List<ClaimAnnuityWegaPO> claimAnnuityWegaList) {
		this.claimAnnuityWegaList = claimAnnuityWegaList;
	}

	public List<ClaimAnnuityOptionPO> getClaimAnnuityOptionList() {
		return claimAnnuityOptionList;
	}

	public void setClaimAnnuityOptionList(List<ClaimAnnuityOptionPO> claimAnnuityOptionList) {
		this.claimAnnuityOptionList = claimAnnuityOptionList;
	}

}
