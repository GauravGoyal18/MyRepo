package com.ipru.groups.po;

import java.util.Date;

public class BeneficiaryPO extends GroupsBasePo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long beneficiaryId;
	

	private String beneficiaryName;
	private String companyOrBuildingName;
	private String flatOrUnitNumber;
	private String streetOrArea;
	private String landmark;
	private String city;
	private String state;
	private String pincode;
	private String addressProofDocumentType;
	
	
	private String createdBy;
	private Date    createdDate;
	private String updatedBy;
	private Date   updatedDate;
	private String  appointeeName;
	private String beneficiaryDOB;
	private String sharePercentage;
	private String relation;
	private String bankAccountNUMBER;
	private String bankName;
	private String ifscCode;
	private String micrCode;
	private String benPos;
	
	
	
	
	



	public Long getBeneficiaryId() {
		return beneficiaryId;
	}
	public void setBeneficiaryId(Long beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getCompanyOrBuildingName() {
		return companyOrBuildingName;
	}
	public void setCompanyOrBuildingName(String companyOrBuildingName) {
		this.companyOrBuildingName = companyOrBuildingName;
	}
	public String getFlatOrUnitNumber() {
		return flatOrUnitNumber;
	}
	public void setFlatOrUnitNumber(String flatOrUnitNumber) {
		this.flatOrUnitNumber = flatOrUnitNumber;
	}
	public String getStreetOrArea() {
		return streetOrArea;
	}
	public void setStreetOrArea(String streetOrArea) {
		this.streetOrArea = streetOrArea;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getAddressProofDocumentType() {
		return addressProofDocumentType;
	}
	public void setAddressProofDocumentType(String addressProofDocumentType) {
		this.addressProofDocumentType = addressProofDocumentType;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public synchronized String getAppointeeName() {
		return appointeeName;
	}
	public synchronized void setAppointeeName(String appointeeName) {
		this.appointeeName = appointeeName;
	}
	public static synchronized long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getBeneficiaryDOB() {
		return beneficiaryDOB;
	}
	public void setBeneficiaryDOB(String beneficiaryDOB) {
		this.beneficiaryDOB = beneficiaryDOB;
	}
	public String getSharePercentage() {
		return sharePercentage;
	}
	public void setSharePercentage(String sharePercentage) {
		this.sharePercentage = sharePercentage;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getBankAccountNUMBER() {
		return bankAccountNUMBER;
	}
	public void setBankAccountNUMBER(String bankAccountNUMBER) {
		this.bankAccountNUMBER = bankAccountNUMBER;
	}
	
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getMicrCode() {
		return micrCode;
	}
	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}
	
	
	public String getBenPos() {
		return benPos;
	}
	public void setBenPos(String benPos) {
		this.benPos = benPos;
	}
	@Override
	public String toString() {
		return "BeneficiaryPO [beneficiaryId=" + beneficiaryId + ", beneficiaryName=" + beneficiaryName + ", companyOrBuildingName=" + companyOrBuildingName + ", flatOrUnitNumber=" + flatOrUnitNumber
				+ ", streetOrArea=" + streetOrArea + ", landmark=" + landmark + ", city=" + city + ", state=" + state + ", pincode=" + pincode + ", addressProofDocumentType="
				+ addressProofDocumentType + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + ", appointeeName="
				+ appointeeName + ", beneficiaryDOB=" + beneficiaryDOB + ", sharePercentage=" + sharePercentage + ", relation=" + relation + ", bankAccountNUMBER=" + bankAccountNUMBER + ", bankName="
				+ bankName + ", ifscCode=" + ifscCode + ", micrCode=" + micrCode + ", benPos=" + benPos + "]";
	}
	
	

}
