package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;

public class AnnuityResultDataVO implements Serializable{
private  List<AnnuityResponseVO> list;
private  List<AnnuityResponseVO> list1;
public List<AnnuityResponseVO> getList() {
	return list;
}

public void setList(List<AnnuityResponseVO> list) {
	this.list = list;
}

public List<AnnuityResponseVO> getList1() {
	return list1;
}

public void setList1(List<AnnuityResponseVO> list1) {
	this.list1 = list1;
}

@Override
public String toString() {
	return "AnnuityResultDataVO [list=" + list + ", list1=" + list1 + "]";
}



}
