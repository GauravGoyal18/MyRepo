package com.ipru.groups.po;

public class MemberFundDataRequestPO {

	private String policyNo;
	private String role;
	private MemberDataTrustPO selectedMember;

	public MemberFundDataRequestPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberFundDataRequestPO(String policyNo, String role, MemberDataTrustPO selectedMember) {
		super();
		this.policyNo = policyNo;
		this.role = role;
		this.selectedMember = selectedMember;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public MemberDataTrustPO getSelectedMember() {
		return selectedMember;
	}

	public void setSelectedMember(MemberDataTrustPO selectedMember) {
		this.selectedMember = selectedMember;
	}

	@Override
	public String toString() {
		return "MemberFundDataRequestPO [policyNo=" + policyNo + ", role=" + role + ", selectedMember=" + selectedMember + "]";
	}

}
