package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;

public class FscDetailsVO implements Serializable {

	
private static final long serialVersionUID = 1L;
	
	private String referral_code;
    private String nationalCode; //UM Code in Retail
	private String branchCode; //Referal Code in Retail
	private long timestampMs;
	private String websiteSource;
	private String fscChannel;
	private String fsc_client_id; //FSC_ClientId
	private String fsc_Name;
	
	private String login_type;
	private String policyno;

	
	public String getPolicyno() {
		return policyno;
	}
	public void setPolicyno(String policyno) {
		this.policyno = policyno;
	}
	List<String> policyNoList;
	
	public String getLogin_type() {
		return login_type;
	}
	public void setLogin_type(String login_type) {
		this.login_type = login_type;
	}
	public String getNationalCode() {
		return nationalCode;
	}
	public void setNationalCode(String nationalCode) {
		this.nationalCode = nationalCode;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public long getTimestampMs() {
		return timestampMs;
	}
	public void setTimestampMs(long timestampMs) {
		this.timestampMs = timestampMs;
	}
	public String getWebsiteSource() {
		return websiteSource;
	}
	public void setWebsiteSource(String websiteSource) {
		this.websiteSource = websiteSource;
	}
	public String getFscChannel() {
		return fscChannel;
	}
	public void setFscChannel(String fscChannel) {
		this.fscChannel = fscChannel;
	}
	
	public String getFsc_Name() {
		return fsc_Name;
	}
	public void setFsc_Name(String fsc_Name) {
		this.fsc_Name = fsc_Name;
	}
	public String getReferral_code() {
		return referral_code;
	}
	public void setReferral_code(String referral_code) {
		this.referral_code = referral_code;
	}
	
	public String getFsc_client_id() {
		return fsc_client_id;
	}
	public void setFsc_client_id(String fsc_client_id) {
		this.fsc_client_id = fsc_client_id;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<String> getPolicyNoList() {
		return policyNoList;
	}
	public void setPolicyNoList(List<String> policyNoList) {
		this.policyNoList = policyNoList;
	}
	
	
	
}
