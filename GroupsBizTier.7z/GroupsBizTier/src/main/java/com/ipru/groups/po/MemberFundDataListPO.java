package com.ipru.groups.po;

import java.util.List;

public class MemberFundDataListPO {

	private List<MemberFundDataPO> memberFundDataPOList;
	private String policyNo;
	private String role;

	public MemberFundDataListPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberFundDataListPO(List<MemberFundDataPO> memberFundDataPOList, String policyNo, String role) {
		super();
		this.memberFundDataPOList = memberFundDataPOList;
		this.policyNo = policyNo;
		this.role = role;
	}

	public List<MemberFundDataPO> getMemberFundDataPOList() {
		return memberFundDataPOList;
	}

	public void setMemberFundDataPOList(List<MemberFundDataPO> memberFundDataPOList) {
		this.memberFundDataPOList = memberFundDataPOList;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "MemberFundDataListPO [memberFundDataPOList=" + memberFundDataPOList + ", policyNo=" + policyNo + ", role=" + role + "]";
	}

}
