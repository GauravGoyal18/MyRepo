package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class RuleDefinitionVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long rdId;
	private String rdRole;
	private String rdComponent;
	private String rdFlow;
	private long rdParentComponentId;
	private long rdOpId;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	private long componentPosId;
	private long componentGroupCode;

	public RuleDefinitionVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RuleDefinitionVO(long rdId, String rdRole, String rdComponent, String rdFlow, long rdParentComponentId, long rdOpId, String createdBy, Date createdDate, String updatedBy, Date updatedDate, long componentPosId, long componentGroupCode) {
		super();
		this.rdId = rdId;
		this.rdRole = rdRole;
		this.rdComponent = rdComponent;
		this.rdFlow = rdFlow;
		this.rdParentComponentId = rdParentComponentId;
		this.rdOpId = rdOpId;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.updatedBy = updatedBy;
		this.updatedDate = updatedDate;
		this.componentPosId = componentPosId;
		this.componentGroupCode = componentGroupCode;
	}

	public long getRdId() {
		return rdId;
	}

	public void setRdId(long rdId) {
		this.rdId = rdId;
	}

	public String getRdRole() {
		return rdRole;
	}

	public void setRdRole(String rdRole) {
		this.rdRole = rdRole;
	}

	public String getRdComponent() {
		return rdComponent;
	}

	public void setRdComponent(String rdComponent) {
		this.rdComponent = rdComponent;
	}

	public String getRdFlow() {
		return rdFlow;
	}

	public void setRdFlow(String rdFlow) {
		this.rdFlow = rdFlow;
	}

	public long getRdParentComponentId() {
		return rdParentComponentId;
	}

	public void setRdParentComponentId(long rdParentComponentId) {
		this.rdParentComponentId = rdParentComponentId;
	}

	public long getRdOpId() {
		return rdOpId;
	}

	public void setRdOpId(long rdOpId) {
		this.rdOpId = rdOpId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public long getComponentPosId() {
		return componentPosId;
	}

	public void setComponentPosId(long componentPosId) {
		this.componentPosId = componentPosId;
	}

	public long getComponentGroupCode() {
		return componentGroupCode;
	}

	public void setComponentGroupCode(long componentGroupCode) {
		this.componentGroupCode = componentGroupCode;
	}

	@Override
	public String toString() {
		return "RuleDefinitionVO [rdId=" + rdId + ", rdRole=" + rdRole + ", rdComponent=" + rdComponent + ", rdFlow=" + rdFlow + ", rdParentComponentId=" + rdParentComponentId + ", rdOpId=" + rdOpId
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + ", componentPosId=" + componentPosId
				+ ", componentGroupCode=" + componentGroupCode + "]";
	}

}
