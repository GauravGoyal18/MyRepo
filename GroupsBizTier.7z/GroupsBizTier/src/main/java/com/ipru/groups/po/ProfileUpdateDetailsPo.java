package com.ipru.groups.po;

import java.io.Serializable;

import com.tcs.web.po.BasePO;

public class ProfileUpdateDetailsPo extends  BasePO {




	



	@Override
	public String toString() {
		return "ProfileUpdateDetailsPo [fieldName=" + fieldName + ", newValue="
				+ newValue + ", oldValue=" + oldValue + ", index=" + index
				+ ", updateReqId=" + updateReqId + "]";
	}

	public String getIndex() {
		return index;
	}

	public String getUpdateReqId() {
		return updateReqId;
	}

	public void setUpdateReqId(String updateReqId) {
		this.updateReqId = updateReqId;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	private String fieldName;

	private String newValue;
	private String oldValue;
	private String index;
	private String updateReqId;
	
/*	private String trusteeName;
	*/
	

	//getter and setter
	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}


	
}
