package com.ipru.groups.po;

public class MemberAddTraditionalPO extends GroupsBasePo {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String dob;
	private String emailID;
	private String doj;
	private String mobileNo;
	
	@Override
	public String toString() {
		return "MemberAddTraditionalPO [dob=" + dob + ", emailID=" + emailID + ", doj=" + doj + ", mobileNo=" + mobileNo + "]";
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	
	
}
