package com.ipru.groups.vo;

import java.util.Date;

public class PMJJBYSchVO extends GroupsBaseVO {

	private static final long serialVersionUID = 1L;
	
	private String memberId;	
	private long schTryCount;
	private String status;
	private String errorMsg;
	private Date docUploadTime;
	private Date lastUpdateTime;
	
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public long getSchTryCount() {
		return schTryCount;
	}
	public void setSchTryCount(long schTryCount) {
		this.schTryCount = schTryCount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public Date getDocUploadTime() {
		return docUploadTime;
	}
	public void setDocUploadTime(Date docUploadTime) {
		this.docUploadTime = docUploadTime;
	}
	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}
	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
	
}
