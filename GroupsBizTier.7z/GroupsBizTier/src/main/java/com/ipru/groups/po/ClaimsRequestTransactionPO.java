package com.ipru.groups.po;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class ClaimsRequestTransactionPO extends GroupsBasePo {

	private long customerTrxnId;
	private Date currentDate;
	private Date approvalDate;
	private String approvalStatus;
	
	private String spaarcSentFlag;


	private String claimType;
	private Set<ClaimsRequestPO> claimsRequestVOSet = new HashSet<ClaimsRequestPO>(0);
	private Set<ClaimBeneficiaryPO> claimsBeneficiaryVOSet = new HashSet<ClaimBeneficiaryPO>(0);
	private Set<ClaimsApprovalPO> claimsApprovalVoSet = new HashSet<ClaimsApprovalPO>(0);


	
	
	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	public Date getApprovalDate() {
		return approvalDate;
	}

	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public Set<ClaimsRequestPO> getClaimsRequestVOSet() {
		return claimsRequestVOSet;
	}

	public void setClaimsRequestVOSet(Set<ClaimsRequestPO> claimsRequestVOSet) {
		this.claimsRequestVOSet = claimsRequestVOSet;
	}

	public Set<ClaimBeneficiaryPO> getClaimsBeneficiaryVOSet() {
		return claimsBeneficiaryVOSet;
	}

	public void setClaimsBeneficiaryVOSet(Set<ClaimBeneficiaryPO> claimsBeneficiaryVOSet) {
		this.claimsBeneficiaryVOSet = claimsBeneficiaryVOSet;
	}

	public Set<ClaimsApprovalPO> getClaimsApprovalVoSet() {
		return claimsApprovalVoSet;
	}

	public void setClaimsApprovalVoSet(Set<ClaimsApprovalPO> claimsApprovalVoSet) {
		this.claimsApprovalVoSet = claimsApprovalVoSet;
	}

	public long getCustomerTrxnId() {
		return customerTrxnId;
	}

	public void setCustomerTrxnId(long customerTrxnId) {
		this.customerTrxnId = customerTrxnId;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getSpaarcSentFlag() {
		return spaarcSentFlag;
	}

	public void setSpaarcSentFlag(String spaarcSentFlag) {
		this.spaarcSentFlag = spaarcSentFlag;
	}

	
	
	/*@Override
	public String toString() {
		return "ClaimsRequestTransactionPO [customerTrxnId=" + customerTrxnId + ", claimsRequestVOSet=" + claimsRequestVOSet + ", claimsBeneficiaryVOSet=" + claimsBeneficiaryVOSet
				+ ", claimsApprovalVoSet=" + claimsApprovalVoSet + "]";
	}*/

}
