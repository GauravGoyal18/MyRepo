package com.ipru.groups.po;

import java.io.Serializable;

public class NomineeUpdateSubmitPo implements Serializable {

	private String fieldId;
	private String fieldCode;
	private String value;

	public String getFieldId() {
		return fieldId;
	}

	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}

	public String getFieldCode() {
		return fieldCode;
	}

	public void setFieldCode(String fieldCode) {
		this.fieldCode = fieldCode;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "NomineeUpdateSubmitPo [fieldId=" + fieldId + ", fieldCode=" + fieldCode + ", value=" + value + "]";
	}

}
