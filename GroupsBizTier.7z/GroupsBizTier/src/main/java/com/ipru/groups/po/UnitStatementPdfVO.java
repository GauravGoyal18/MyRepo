package com.ipru.groups.po;

public class UnitStatementPdfVO {

	
	private String trustName;
	private String policyNumber;
	private String policyType;
	private String startEndDate;
	
	
	
}
