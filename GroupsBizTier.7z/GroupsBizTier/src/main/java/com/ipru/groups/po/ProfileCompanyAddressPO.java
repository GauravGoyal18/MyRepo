package com.ipru.groups.po;

import java.io.Serializable;

public class ProfileCompanyAddressPO implements Serializable {
	private String companyAddress_addressType_new;
	private String  companyAddress_Company_new;
	private String companyAddress_Flat_new;
	private String companyAddress_Street_new;
	private String companyAddress_Landmark_new;
	private String companyAddress_Pincode_new;
	private String companyAddress_City_new;
	private String companyAddress_State_new;
	private String companyAddress_addressproof_new;
	
	
	
	public String getCompanyAddress_Company_new() {
		return companyAddress_Company_new;
	}
	public void setCompanyAddress_Company_new(String companyAddress_Company_new) {
		this.companyAddress_Company_new = companyAddress_Company_new;
	}
	public String getCompanyAddress_Flat_new() {
		return companyAddress_Flat_new;
	}
	public void setCompanyAddress_Flat_new(String companyAddress_Flat_new) {
		this.companyAddress_Flat_new = companyAddress_Flat_new;
	}
	public String getCompanyAddress_Street_new() {
		return companyAddress_Street_new;
	}
	public void setCompanyAddress_Street_new(String companyAddress_Street_new) {
		this.companyAddress_Street_new = companyAddress_Street_new;
	}
	public String getCompanyAddress_Landmark_new() {
		return companyAddress_Landmark_new;
	}
	public void setCompanyAddress_Landmark_new(String companyAddress_Landmark_new) {
		this.companyAddress_Landmark_new = companyAddress_Landmark_new;
	}
	public String getCompanyAddress_Pincode_new() {
		return companyAddress_Pincode_new;
	}
	public void setCompanyAddress_Pincode_new(String companyAddress_Pincode_new) {
		this.companyAddress_Pincode_new = companyAddress_Pincode_new;
	}
	public String getCompanyAddress_City_new() {
		return companyAddress_City_new;
	}
	public void setCompanyAddress_City_new(String companyAddress_City_new) {
		this.companyAddress_City_new = companyAddress_City_new;
	}
	public String getCompanyAddress_State_new() {
		return companyAddress_State_new;
	}
	public void setCompanyAddress_State_new(String companyAddress_State_new) {
		this.companyAddress_State_new = companyAddress_State_new;
	}
	public String getCompanyAddress_addressproof_new() {
		return companyAddress_addressproof_new;
	}
	public void setCompanyAddress_addressproof_new(
			String companyAddress_addressproof_new) {
		this.companyAddress_addressproof_new = companyAddress_addressproof_new;
	}
	public String getCompanyAddress_addressType_new() {
		return companyAddress_addressType_new;
	}
	public void setCompanyAddress_addressType_new(
			String companyAddress_addressType_new) {
		this.companyAddress_addressType_new = companyAddress_addressType_new;
	}
	@Override
	public String toString() {
		return "ProfileCompanyAddressPO [companyAddress_addressType_new="
				+ companyAddress_addressType_new
				+ ", companyAddress_Company_new=" + companyAddress_Company_new
				+ ", companyAddress_Flat_new=" + companyAddress_Flat_new
				+ ", companyAddress_Street_new=" + companyAddress_Street_new
				+ ", companyAddress_Landmark_new="
				+ companyAddress_Landmark_new + ", companyAddress_Pincode_new="
				+ companyAddress_Pincode_new + ", companyAddress_City_new="
				+ companyAddress_City_new + ", companyAddress_State_new="
				+ companyAddress_State_new
				+ ", companyAddress_addressproof_new="
				+ companyAddress_addressproof_new + "]";
	}
	
	
	
	
	
	
	


}
