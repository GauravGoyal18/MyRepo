package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;

public class NomineeUpdateSubmitVo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long requestId;
	private String memberId;
	private String modelName;
	private String fieldId;
	private String fieldCode;
	private String fieldGroupCode;
	private String value;
	private Date currentDate;
	private String category;
	private NomineeUpdateTransactionVo nomineeUpdateTransactionVo;

	public long getRequestId() {
		return requestId;
	}

	public NomineeUpdateTransactionVo getNomineeUpdateTransactionVo() {
		return nomineeUpdateTransactionVo;
	}

	public void setNomineeUpdateTransactionVo(NomineeUpdateTransactionVo nomineeUpdateTransactionVo) {
		this.nomineeUpdateTransactionVo = nomineeUpdateTransactionVo;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getFieldId() {
		return fieldId;
	}

	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}

	public String getFieldCode() {
		return fieldCode;
	}

	public void setFieldCode(String fieldCode) {
		this.fieldCode = fieldCode;
	}

	public String getFieldGroupCode() {
		return fieldGroupCode;
	}

	public void setFieldGroupCode(String fieldGroupCode) {
		this.fieldGroupCode = fieldGroupCode;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "NomineeUpdateSubmitVo [requestId=" + requestId + ", memberId=" + memberId + ", modelName=" + modelName + ", fieldId=" + fieldId + ", fieldCode=" + fieldCode + ", fieldGroupCode="
				+ fieldGroupCode + ", value=" + value + ", currentDate=" + currentDate + ", category=" + category + ", nomineeUpdateTransactionVo=" + nomineeUpdateTransactionVo + "]";
	}

}
