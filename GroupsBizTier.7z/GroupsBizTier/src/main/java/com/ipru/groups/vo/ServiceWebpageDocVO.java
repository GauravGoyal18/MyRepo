package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class ServiceWebpageDocVO extends BaseVO {

	private long docId;
	private String docName;
	private long requestId;
	private Date requestedDate;
	private String clientId;
	private String flag;
	
	
}
