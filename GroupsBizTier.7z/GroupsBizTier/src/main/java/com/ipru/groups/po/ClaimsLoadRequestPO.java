package com.ipru.groups.po;

import java.util.List;

import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.tcs.web.po.BasePO;

public class ClaimsLoadRequestPO extends BasePO {




	private static final long serialVersionUID = 1L;
	private String policyNo;
	private String role;
	private String screenName;
	private List<RoleScreenAccessMappingVO> accessMappingList;
	private List<FieldAccessMappingVO> fieldAccessMappingList;

	
	public ClaimsLoadRequestPO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public ClaimsLoadRequestPO(String policyNo, String role, String screenName, List<RoleScreenAccessMappingVO> accessMappingList, List<FieldAccessMappingVO> fieldAccessMappingList) {
		super();
		this.policyNo = policyNo;
		this.role = role;
		this.screenName = screenName;
		this.accessMappingList = accessMappingList;
		this.fieldAccessMappingList = fieldAccessMappingList;
	}

	
	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public List<RoleScreenAccessMappingVO> getAccessMappingList() {
		return accessMappingList;
	}

	public void setAccessMappingList(List<RoleScreenAccessMappingVO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}

	
	
	@Override
	public String toString() {
		return "ProfileUpdateLoadRequestPO [policyNo=" + policyNo + ", role=" + role + ", screenName=" + screenName + ", accessMappingList=" + accessMappingList + ", fieldAccessMappingList="
				+ fieldAccessMappingList + "]";
	}


}
