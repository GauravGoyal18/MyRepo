package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

public class MemberDataTermListPO implements Serializable {

	private List<MemberDataTermPO> memberPOList;
	private String policyNo;
	private String role;

	public MemberDataTermListPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberDataTermListPO(List<MemberDataTermPO> memberPOList, String policyNo, String role) {
		super();
		this.memberPOList = memberPOList;
		this.policyNo = policyNo;
		this.role = role;
	}

	public List<MemberDataTermPO> getMemberPOList() {
		return memberPOList;
	}

	public void setMemberPOList(List<MemberDataTermPO> memberPOList) {
		this.memberPOList = memberPOList;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "MemberDataTermListPO [memberPOList=" + memberPOList + ", policyNo=" + policyNo + ", role=" + role + "]";
	}

}
