package com.ipru.groups.po;

import java.util.List;

import com.ipru.groups.grpswitch.bean.FundDetailsPO;
import com.ipru.groups.grpswitch.bean.ProductSwitchAmountPO;
import com.tcs.web.po.BasePO;

public class StofLoadDataPO extends BasePO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<FundMasterPO> fundMasterList;
	private List<String> activeApplicableToFundList;
	private FundDetailsPO fundDetailsVO;
	private List<FundDetailsPO> fundDetailsVOList;
	private List<String> activeFromFundList;
	private String fundCodes;
	private String policyNumber;
	private ProductSwitchAmountPO productSwitchAmount;
	private boolean isRequestPerDayExist;
	private String productCode;
	private List<DropDownObjPO> freqOfTrans;

	public List<DropDownObjPO> getFreqOfTrans() {
		return freqOfTrans;
	}

	public void setFreqOfTrans(List<DropDownObjPO> freqOfTrans) {
		this.freqOfTrans = freqOfTrans;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public synchronized boolean isRequestPerDayExist() {
		return isRequestPerDayExist;
	}

	public synchronized void setRequestPerDayExist(boolean isRequestPerDayExist) {
		this.isRequestPerDayExist = isRequestPerDayExist;
	}

	public synchronized ProductSwitchAmountPO getProductSwitchAmount() {
		return productSwitchAmount;
	}

	public synchronized void setProductSwitchAmount(ProductSwitchAmountPO productSwitchAmount) {
		this.productSwitchAmount = productSwitchAmount;
	}

	public synchronized List<FundMasterPO> getFundMasterList() {
		return fundMasterList;
	}

	public synchronized void setFundMasterList(List<FundMasterPO> fundMasterList) {
		this.fundMasterList = fundMasterList;
	}

	public synchronized List<String> getActiveApplicableToFundList() {
		return activeApplicableToFundList;
	}

	public synchronized void setActiveApplicableToFundList(List<String> activeApplicableToFundList) {
		this.activeApplicableToFundList = activeApplicableToFundList;
	}

	public synchronized FundDetailsPO getFundDetailsVO() {
		return fundDetailsVO;
	}

	public synchronized void setFundDetailsVO(FundDetailsPO fundDetailsVO) {
		this.fundDetailsVO = fundDetailsVO;
	}

	public synchronized List<FundDetailsPO> getFundDetailsVOList() {
		return fundDetailsVOList;
	}

	public synchronized void setFundDetailsVOList(List<FundDetailsPO> fundDetailsVOList) {
		this.fundDetailsVOList = fundDetailsVOList;
	}

	public synchronized List<String> getActiveFromFundList() {
		return activeFromFundList;
	}

	public synchronized void setActiveFromFundList(List<String> activeFromFundList) {
		this.activeFromFundList = activeFromFundList;
	}

	public synchronized String getFundCodes() {
		return fundCodes;
	}

	public synchronized void setFundCodes(String fundCodes) {
		this.fundCodes = fundCodes;
	}

	public synchronized String getPolicyNumber() {
		return policyNumber;
	}

	public synchronized void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	@Override
	public String toString() {
		return "StofLoadDataPO [fundMasterList=" + fundMasterList + ", activeApplicableToFundList=" + activeApplicableToFundList + ", fundDetailsVO=" + fundDetailsVO + ", fundDetailsVOList="
				+ fundDetailsVOList + ", activeFromFundList=" + activeFromFundList + ", fundCodes=" + fundCodes + ", policyNumber=" + policyNumber + ", productSwitchAmount=" + productSwitchAmount
				+ ", isRequestPerDayExist=" + isRequestPerDayExist + ", productCode=" + productCode + ", freqOfTrans=" + freqOfTrans + "]";
	}

}
