package com.ipru.groups.po;

import com.tcs.web.po.BasePO;

public class ServiceDeskPO extends BasePO {
	
	private static final long serialVersionUID = 1L;
	private long requestId;
	private String policyNo;
	private String address;
	private String email;
	private String telephoneno;
	private String faxno;
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelephoneno() {
		return telephoneno;
	}
	public void setTelephoneno(String telephoneno) {
		this.telephoneno = telephoneno;
	}
	public String getFaxno() {
		return faxno;
	}
	public void setFaxno(String faxno) {
		this.faxno = faxno;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "ServiceDeskPO [requestId=" + requestId + ", policyNo="
				+ policyNo + ", address=" + address + ", email=" + email
				+ ", telephoneno=" + telephoneno + ", faxno=" + faxno + "]";
	}
	
	
	
	

}
