package com.ipru.groups.profile.bean;

import java.io.Serializable;

public class ProfilePOCVO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private boolean isDisabled;
	private boolean isEditable;
	private boolean isShow;
	private int fieldGroupCode;
	private int fieldCode;
	private int subFieldCode;
	

	
	
	public int getSubFieldCode() {
		return subFieldCode;
	}
	public void setSubFieldCode(int subFieldCode) {
		this.subFieldCode = subFieldCode;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public boolean isDisabled() {
		return isDisabled;
	}
	public void setDisabled(boolean isDisabled) {
		this.isDisabled = isDisabled;
	}
	public boolean isEditable() {
		return isEditable;
	}
	public void setEditable(boolean isEditable) {
		this.isEditable = isEditable;
	}
	public boolean isShow() {
		return isShow;
	}
	public void setShow(boolean isShow) {
		this.isShow = isShow;
	}
	public int getFieldCode() {
		return fieldCode;
	}
	public void setFieldCode(int fieldCode) {
		this.fieldCode = fieldCode;
	}
	public int getFieldGroupCode() {
		return fieldGroupCode;
	}
	public void setFieldGroupCode(int fieldGroupCode) {
		this.fieldGroupCode = fieldGroupCode;
	}
	
	

}
