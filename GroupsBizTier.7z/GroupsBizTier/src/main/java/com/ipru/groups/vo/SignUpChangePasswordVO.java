package com.ipru.groups.vo;

import com.ipru.security.user.GroupsUserAuthInfoNew;

public class SignUpChangePasswordVO extends GroupsBaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private SignUpPolicyDetailsVO signUpPolicyDetailsVO;
	private SignUpMasterSheetDetailsVO masterSheetDetails;
	private GroupsUserAuthInfoNew groupsUserAuthInfoNew;

	public SignUpPolicyDetailsVO getSignUpPolicyDetailsVO() {
		return signUpPolicyDetailsVO;
	}

	public void setSignUpPolicyDetailsVO(SignUpPolicyDetailsVO signUpPolicyDetailsVO) {
		this.signUpPolicyDetailsVO = signUpPolicyDetailsVO;
	}

	public SignUpMasterSheetDetailsVO getMasterSheetDetails() {
		return masterSheetDetails;
	}

	public void setMasterSheetDetails(SignUpMasterSheetDetailsVO masterSheetDetails) {
		this.masterSheetDetails = masterSheetDetails;
	}

	public GroupsUserAuthInfoNew getGroupsUserAuthInfoNew() {
		return groupsUserAuthInfoNew;
	}

	public void setGroupsUserAuthInfoNew(GroupsUserAuthInfoNew groupsUserAuthInfoNew) {
		this.groupsUserAuthInfoNew = groupsUserAuthInfoNew;
	}

}
