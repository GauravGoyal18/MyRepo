package com.ipru.groups.po;

public class DocumentRequestPo {

	private long documentId;
	private String docName;
	private String contentType;
	

	
	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public long getDocumentId() {
		return documentId;
	}

	public void setDocumentId(long documentId) {
		this.documentId = documentId;
	}

	@Override
	public String toString() {
		return "DocumentRequestPo [documentId=" + documentId + ", docName="
				+ docName + ", contentType=" + contentType + "]";
	}
	
}
