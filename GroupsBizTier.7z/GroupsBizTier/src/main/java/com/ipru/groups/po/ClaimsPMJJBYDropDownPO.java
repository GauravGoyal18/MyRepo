package com.ipru.groups.po;

import java.util.List;

public class ClaimsPMJJBYDropDownPO {

	private List genderList;
	private List typeOfPaymentList;
	private List reason;

	public List getGenderList() {
		return genderList;
	}

	public void setGenderList(List genderList) {
		this.genderList = genderList;
	}

	public List getTypeOfPaymentList() {
		return typeOfPaymentList;
	}

	public void setTypeOfPaymentList(List typeOfPaymentList) {
		this.typeOfPaymentList = typeOfPaymentList;
	}

	public List getReason() {
		return reason;
	}

	public void setReason(List reason) {
		this.reason = reason;
	}

}
