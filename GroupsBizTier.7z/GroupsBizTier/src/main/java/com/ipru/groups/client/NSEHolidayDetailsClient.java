package com.ipru.groups.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ipru.groups.grpswitch.bean.NSEHolidaysVO;
import com.ipru.groups.param.obj.ParamObj;
import com.ipru.groups.po.PrePopulateBean;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.tcs.logger.FLogger;

public class NSEHolidayDetailsClient {

	/**
	 * @param args
	 */
	
	public static List<NSEHolidaysVO> fetchNSEHoliday()  throws Exception{
		FLogger.info("NSEHolidayDetailsClient", "NSEHolidayDetailsClient", "fetchNSEHoliday","Method Start");
		
		List<NSEHolidaysVO> nseHolidaysList = new ArrayList<NSEHolidaysVO>();
		nseHolidaysList = mockNSEHolidays();
        FLogger.info("NSEHolidayDetailsClient", "NSEHolidayDetailsClient", "fetchNSEHoliday","Method End");
        return nseHolidaysList;
	}
	
	private static List<NSEHolidaysVO> mockNSEHolidays() throws Exception{

		List<NSEHolidaysVO> list = new ArrayList<NSEHolidaysVO>();

		Client clientGet = Client.create();
		ParamObj paramObj = new ParamObj();

		// create SwitchToRequest class as follow
		PrePopulateBean prePopulateBean = new PrePopulateBean();
		prePopulateBean.setFunctionality("nscHolidays");
		prePopulateBean.setParamObj(paramObj);
		Properties properties = MasterPropertiesFileLoader.CONSTANT_REST;
		String restPath = properties.getProperty("REST_PATH");
		String auth = properties.getProperty("AUTH");

		clientGet.setConnectTimeout(Integer.parseInt(properties.getProperty("CONNECT_TIMEOUT")));
        clientGet.setReadTimeout(Integer.parseInt(properties.getProperty("READ_TIMEOUT")));

		WebResource webResource = clientGet.resource(restPath
				+ "groups/prePopulate.rest");
		ClientResponse responseGet = webResource.type("application/json")
				.header("Authorization", auth)
				.post(ClientResponse.class, prePopulateBean);

		FLogger.info("NSEHolidayDetailsClient","Response status" + responseGet.getStatus());
		////System.out.println("Response status : " + responseGet.getStatus());
		String output = responseGet.getEntity(String.class);
		////System.out.println("Holidayyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy" + output);
		FLogger.info("NSEHolidayDetailsClient", "Output of Fund NAV Webservice"
				+ output);
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		list = gson.fromJson(output, new TypeToken<List<NSEHolidaysVO>>() {
		}.getType());
		
		// you will get response in list of SwitchTo bean which is given below
		// ArrayList<SwitchTo> list=gson.fromJson(output, ArrayList.class);
		// ////System.out.println("Data"+list.toString());

		FLogger.info("NSEHolidayDetailsClient", "NSEHolidayDetailsClient","mockNSEHolidays", "Method End");
		return list;

	}
	
	public static void main(String[] args) {
		
	}

}
