package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

public class GroupRetailLoginInfoPO implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String emailId;
    public String mobileNo;
    public String webClientId;
	private long milliseconds;
	private String ssoWebsiteSource;
	
	public long getMilliseconds() {
		return milliseconds;
	}
	public String getSsoWebsiteSource() {
		return ssoWebsiteSource;
	}
	public void setSsoWebsiteSource(String ssoWebsiteSource) {
		this.ssoWebsiteSource = ssoWebsiteSource;
	}
	public void setMilliseconds(long milliseconds) {
		this.milliseconds = milliseconds;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getWebClientId() {
		return webClientId;
	}
	public void setWebClientId(String webClientId) {
		this.webClientId = webClientId;
	}
    
    
   // public List<GroupPolicyDetail> policyDetailList;

}
