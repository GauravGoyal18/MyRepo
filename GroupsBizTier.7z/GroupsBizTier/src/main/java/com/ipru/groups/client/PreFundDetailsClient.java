package com.ipru.groups.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ipru.groups.grpswitch.bean.SwitchPreFundDetailsVO;
import com.ipru.groups.param.obj.ParamObj;
import com.ipru.groups.po.SwitchToRequest;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.StofPreFundDetailsVO;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.tcs.logger.FLogger;

public class PreFundDetailsClient {

	/**
	 * @param args
	 */
/*	
	public static List<SwitchPreFundDetailsVO> invokePreFundDetails(Set<String> fundCodes){
		FLogger.info("SwitchLogger", "PreFundDetailsClient", "invokePreFundDetails","Method Start");
		
		List<SwitchPreFundDetailsVO> fetchPreFundDetails = new ArrayList<SwitchPreFundDetailsVO>();
		fetchPreFundDetails = fetchPreFundDetails(fundCodes);
		
        FLogger.info("SwitchLogger", "PreFundDetailsClient", "invokePreFundDetails","Method End");
        return fetchPreFundDetails;
	}
	
	private static List<SwitchPreFundDetailsVO> fetchPreFundDetails(Set<String> fundCodes) {

		List<SwitchPreFundDetailsVO> list= new ArrayList<SwitchPreFundDetailsVO>();
		SwitchPreFundDetailsVO switchPreFundDetailsVO;
		
		
	
		for(String fundCode : fundCodes)
		{
			switchPreFundDetailsVO = new SwitchPreFundDetailsVO();
			//switchPreFundDetailsVO.setSwitchPreFundDetailsId((long) 2);
			switchPreFundDetailsVO.setFundCode(fundCode);
			switchPreFundDetailsVO.setFundNAV(fundCode+" NAV");
			switchPreFundDetailsVO.setFundCode(fundCode+" NAV");
			switchPreFundDetailsVO.setFundNAVEffectiveDate(java.sql.Date.valueOf("2017-01-26"));
			switchPreFundDetailsVO.setPreFundUnit(fundCode+" preFundUnit");
			switchPreFundDetailsVO.setPreFundAmount(fundCode+" preFundAmount");
			list.add(switchPreFundDetailsVO);
		}
		
		
		

		return list;

	}*/
	
	public static List<SwitchPreFundDetailsVO> invokePreFundDetails(Map<String,String> map){
		FLogger.info("SwitchLogger", "PreFundDetailsClient", "invokePreFundDetails","Method Start");
		List<SwitchPreFundDetailsVO> fetchPreFundDetails = new ArrayList<SwitchPreFundDetailsVO>();
			
		fetchPreFundDetails = fetchPreFundDetails(map);
			 
	
		FLogger.info("SwitchLogger", "PreFundDetailsClient", "invokePreFundDetails","Method End");
		return fetchPreFundDetails;
	}
	
	private static List<SwitchPreFundDetailsVO> fetchPreFundDetails(Map<String,String> map) {
		FLogger.info("SwitchLogger", "PreFundDetailsClient", "fetchPreFundDetails","Method Start");

		List<SwitchPreFundDetailsVO> list= new ArrayList<SwitchPreFundDetailsVO>();
		List<String> paramList=new ArrayList<String>();
		Set<String> fundCodes = null;
		if(map != null){
			if(map.get("fromToFundCode") != null && map.get("fromToFundCode") instanceof String)
			{
				fundCodes = new HashSet<String>(Arrays.asList(map.get("fromToFundCode").split(",")));
			}
		
			if(map.get("policy") != null && map.get("policy") instanceof String)
			{
				//paramList.add("00000348");//policynumber
				paramList.add((String)map.get("policy"));//policynumber
			}
			
			if(map.get("clientId") != null && map.get("clientId") instanceof String){
				 //paramList.add("ME11443");
				 paramList.add((String)map.get("clientId"));
			}
		}
		
		
		Client clientGet = Client.create(); 
		Properties properties = MasterPropertiesFileLoader.CONSTANT_REST;
		String restPath = properties.getProperty("REST_PATH");
		String auth = properties.getProperty("AUTH");
		
		//Web service Time Out
		clientGet.setConnectTimeout(Integer.parseInt(properties.getProperty("CONNECT_TIMEOUT")));
		clientGet.setReadTimeout(Integer.parseInt(properties.getProperty("READ_TIMEOUT")));
//		String restPath = "http://localhost:9080/GroupsREST/";
//		String auth = "Basic YWRtaW46YWRtaW4=";
	
//    	clientGet.setConnectTimeout(10000);
//    	clientGet.setReadTimeout(100000);
    	
    	
		ParamObj paramObj=new ParamObj();
		paramObj.setParam(paramList);
		SwitchToRequest switchToRequest=new SwitchToRequest();
		switchToRequest.setParamObj(paramObj);
		
		switchToRequest.setFundCodes(fundCodes);
		WebResource webResource = clientGet.resource(restPath+"groups/fundDetails.rest");
		ClientResponse responseGet = webResource.type("application/json")   
													 .header("Authorization", auth)     
		        											 .post(ClientResponse.class,switchToRequest);
		////System.out.println("Response status : "+responseGet.getStatus());
		String output = responseGet.getEntity(String.class);
		FLogger.info("SwitchLogger", "PreFundDetailsClient", "fetchPreFundDetails","output"+output.toString());
		
		Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
		if(output!=null && !output.equalsIgnoreCase(""))
		{	
			list = gson.fromJson(output, new TypeToken<List<SwitchPreFundDetailsVO>>(){}.getType());
		}
		
		FLogger.info("SwitchLogger", "PreFundDetailsClient", "fetchPreFundDetails","listlistlistlist"+list.toString());
		
		FLogger.info("SwitchLogger", "PreFundDetailsClient", "fetchPreFundDetails","Method end");
		
		////System.out.println("List*********"+list.toString());
				return list;

	}
	
	
	
	public static List<StofPreFundDetailsVO> invokePreFundDetailsForStof(Set<String> fundCodes,Map<String,String> map){
		FLogger.info("StofLogger", "PreFundDetailsClient", "invokePreFundDetailsForStof","Method Start");
		try
		{
		List<StofPreFundDetailsVO> fetchPreFundDetails = new ArrayList<StofPreFundDetailsVO>();
		fetchPreFundDetails = fetchPreFundDetailsForStof(fundCodes,map);
		 return fetchPreFundDetails;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			////System.out.println("inside catch");
			 return null;
		}
        //FLogger.info("PreFundDetailsClient", "PreFundDetailsClient", "invokePreFundDetailsForStof","Method End");
      //  return fetchPreFundDetails;
	}
	
	private static List<StofPreFundDetailsVO> fetchPreFundDetailsForStof(Set<String> fundCodes,Map<String,String> map) {
		FLogger.info("StofLogger", "PreFundDetailsClient", "fetchPreFundDetailsForStof","Method Start");

		List<StofPreFundDetailsVO> list= new ArrayList<StofPreFundDetailsVO>();
		StofPreFundDetailsVO stofPreFundDetailsVO;
		/*SwitchPreFundDetailsVO switchPreFundDetailsVO2 = new SwitchPreFundDetailsVO();
		SwitchPreFundDetailsVO switchPreFundDetailsVO3 = new SwitchPreFundDetailsVO();
		SwitchPreFundDetailsVO switchPreFundDetailsVO4 = new SwitchPreFundDetailsVO();*/
		
	
		/*for(String fundCode : fundCodes)
		{
			stofPreFundDetailsVO = new StofPreFundDetailsVO();
			//switchPreFundDetailsVO.setSwitchPreFundDetailsId((long) 2);
			stofPreFundDetailsVO.setFundCode(fundCode);
			stofPreFundDetailsVO.setFundNAV(fundCode+" NAV");
			stofPreFundDetailsVO.setFundCode(fundCode+" NAV");
			stofPreFundDetailsVO.setFundNAVEffectiveDate(java.sql.Date.valueOf("2017-01-26"));
			stofPreFundDetailsVO.setPreFundUnit(fundCode+" preFundUnit");
			stofPreFundDetailsVO.setPreFundAmount(fundCode+" preFundAmount");
			list.add(stofPreFundDetailsVO);
		}*/
		   List<String> paramList=new ArrayList(); 
		if(map != null){
			if(map.get("policy") != null && map.get("policy") instanceof String)
			{
				//paramList.add("00000348");//policynumber
				paramList.add((String)map.get("policy"));//policynumber
			}
			
			if(map.get("clientId") != null && map.get("clientId") instanceof String){
				 //paramList.add("ME11443");
				 paramList.add((String)map.get("clientId"));
			}
				
		}
		
		
	        Client clientGet = Client.create(); 
	        Properties properties = MasterPropertiesFileLoader.CONSTANT_REST;
	    	String restPath = properties.getProperty("REST_PATH");
	    	String auth = properties.getProperty("AUTH");
	    	//Web service Time Out
	        clientGet.setConnectTimeout(Integer.parseInt(properties.getProperty("CONNECT_TIMEOUT")));
	        clientGet.setReadTimeout(Integer.parseInt(properties.getProperty("READ_TIMEOUT")));
//	        String restPath = "http://localhost:9080/GroupsREST/";
//			String auth = "Basic YWRtaW46YWRtaW4=";
			
//	    	clientGet.setConnectTimeout(10000);
//	    	clientGet.setReadTimeout(100000);
	    	
	        
	        
	        
	        
	        
	        ParamObj paramObj=new ParamObj();
	        paramObj.setParam(paramList);
	        SwitchToRequest switchToRequest=new SwitchToRequest();
	        switchToRequest.setParamObj(paramObj);
	        switchToRequest.setFundCodes(fundCodes);
	       WebResource webResource = clientGet.resource(restPath+"groups/fundDetails.rest");
	        ClientResponse responseGet = webResource.type("application/json")   
	        											 .header("Authorization", auth)     
	        											 .post(ClientResponse.class,switchToRequest);
	 
	        String output = responseGet.getEntity(String.class);
			FLogger.info("StofLogger", "PreFundDetailsClient", "fetchPreFundDetailsForStof","output"+output.toString());

	        Gson gson=new Gson();
	        if(output!=null && !output.equalsIgnoreCase(""))
			{	
	        	list = gson.fromJson(output, new TypeToken<List<StofPreFundDetailsVO>>(){}.getType());
			}
	        
			FLogger.info("StofLogger", "PreFundDetailsClient", "fetchPreFundDetailsForStof","listlistlistlist"+list.toString());
		
			FLogger.info("StofLogger", "PreFundDetailsClient", "fetchPreFundDetailsForStof","Method end");

			////System.out.println("List*********"+list.toString());
		return list;

	}
	public static void main(String[] args) {
		

		
		Map<String,String> map = new HashMap<String,String>();
		map.put("clientId","ME11443");
		map.put("policy","00000348");
		map.put("fromToFundCode","GTH,BLN,DBT");
		//Set<String> fundCodes =new HashSet();
		//fundCodes.add("DBT");
		//fundCodes.add("GGSEC");
		//fundCodes.add("BLN");
		//fundCodes.add("GTH");
		
		new PreFundDetailsClient().invokePreFundDetails(map);
//		new PreFundDetailsClient().invokePreFundDetailsForStof(fundCodes, map);
	
	}

}
