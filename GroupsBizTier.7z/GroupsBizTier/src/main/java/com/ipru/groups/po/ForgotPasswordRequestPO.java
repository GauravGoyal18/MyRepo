package com.ipru.groups.po;

import java.io.Serializable;

public class ForgotPasswordRequestPO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String emailId;
	private String mobileNo;
	private String newPassword;
	private String confirmPassword;
	private String countryName;



	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	@Override
	public String toString() {
		return "ForgotPasswordRequestPO [emailId=" + emailId + ", mobileNo=" + mobileNo + ", newPassword=" + newPassword + ", confirmPassword=" + confirmPassword + ", countryName=" + countryName
				+ "]";
	}

	
}
