package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;

public class UnitStatementGratuityFtlVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<UnitStatementGratuityResponseFundVO> unitStatementGratuityFtlVOList;
	private String policyNumber;
	private String startDate;
	private String endDate;
	private String closingBalance;
	private String clientName;
	
	
	
	

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClosingBalance() {
		return closingBalance;
	}

	public void setClosingBalance(String closingBalance) {
		this.closingBalance = closingBalance;
	}
	
	public List<UnitStatementGratuityResponseFundVO> getUnitStatementGratuityFtlVOList() {
		return unitStatementGratuityFtlVOList;
	}

	public void setUnitStatementGratuityFtlVOList(
			List<UnitStatementGratuityResponseFundVO> unitStatementGratuityFtlVOList) {
		this.unitStatementGratuityFtlVOList = unitStatementGratuityFtlVOList;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "UnitStatementGratuityFtlVO [unitStatementGratuityFtlVOList="
				+ unitStatementGratuityFtlVOList + ", policyNumber="
				+ policyNumber + ", startDate=" + startDate + ", endDate="
				+ endDate + ", closingBalance=" + closingBalance
				+ ", clientName=" + clientName + "]";
	}
	

}
