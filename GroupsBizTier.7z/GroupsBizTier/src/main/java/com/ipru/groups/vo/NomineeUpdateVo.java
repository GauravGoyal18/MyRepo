package com.ipru.groups.vo;

import java.io.Serializable;

public class NomineeUpdateVo implements Serializable {

	private String beneficaryName;
	private String dob;
	private String relation;
	private int sharePer;
	private String gender;

	public String getBeneficaryName() {
		return beneficaryName;
	}

	public void setBeneficaryName(String beneficaryName) {
		this.beneficaryName = beneficaryName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public int getSharePer() {
		return sharePer;
	}

	public void setSharePer(int sharePer) {
		this.sharePer = sharePer;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "NomineeUpdateVo [beneficaryName=" + beneficaryName + ", dob=" + dob + ", relation=" + relation + ", share=" + sharePer + ", gender=" + gender + "]";
	}

}
