package com.ipru.groups.vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class StofSubmitTransactionVO extends GroupsBaseVO implements ISpaarcCallLog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long stofTransactionId;
	private String iAgreeTnC;
	private String switchType;
	private String totalStofAmount;
	private String totalFundAmount;
	private Date reqExecutionDate;

	private String productCode;
	private String requestType;

	private Set<StofSubmitVo> stof = new HashSet<StofSubmitVo>(0);
	private Set<StofPreFundDetailsVO> stofPreFundDetailsSet = new HashSet<StofPreFundDetailsVO>(0);
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	private FunctionalityMasterVO functionality;

	public String getTotalFundAmount() {
		return totalFundAmount;
	}

	public void setTotalFundAmount(String totalFundAmount) {
		this.totalFundAmount = totalFundAmount;
	}

	public Set<StofPreFundDetailsVO> getStofPreFundDetailsSet() {
		return stofPreFundDetailsSet;
	}

	public void setStofPreFundDetailsSet(Set<StofPreFundDetailsVO> stofPreFundDetailsSet) {
		this.stofPreFundDetailsSet = stofPreFundDetailsSet;
	}

	public Long getStofTransactionId() {
		return stofTransactionId;
	}

	public void setStofTransactionId(Long stofTransactionId) {
		this.stofTransactionId = stofTransactionId;
	}

	public String getiAgreeTnC() {
		return iAgreeTnC;
	}

	public void setiAgreeTnC(String iAgreeTnC) {
		this.iAgreeTnC = iAgreeTnC;
	}

	public String getSwitchType() {
		return switchType;
	}

	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}

	public String getTotalStofAmount() {
		return totalStofAmount;
	}

	public void setTotalStofAmount(String totalStofAmount) {
		this.totalStofAmount = totalStofAmount;
	}

	public Date getReqExecutionDate() {
		return reqExecutionDate;
	}

	public void setReqExecutionDate(Date reqExecutionDate) {
		this.reqExecutionDate = reqExecutionDate;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public Set<StofSubmitVo> getStof() {
		return stof;
	}

	public void setStof(Set<StofSubmitVo> stof) {
		this.stof = stof;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String getFunctionalityReqId() {
		return String.valueOf(getStofTransactionId());
	}

	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}

	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}

}
