package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class ServiceWebPageMenuVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long requestMenuID;
	private String requestMenuName;
	private String productCategory;
	private String memberType;
	private String callCategory;
	private String masterCallType;
	private String callType;
	private String subType;
	private String assigneeName;
	private String assigneeEmpId;
	private String assigneeGroup;
	private String assigneeSubGroup;
	private String formatLink;
	private long functionalityId;

	public ServiceWebPageMenuVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceWebPageMenuVO(Long requestMenuID, String requestMenuName, String productCategory, String memberType, String callCategory, String masterCallType, String callType, String subType, String assigneeName, String assigneeEmpId, String assigneeGroup, String assigneeSubGroup, String formatLink, long functionalityId) {
		super();
		this.requestMenuID = requestMenuID;
		this.requestMenuName = requestMenuName;
		this.productCategory = productCategory;
		this.memberType = memberType;
		this.callCategory = callCategory;
		this.masterCallType = masterCallType;
		this.callType = callType;
		this.subType = subType;
		this.assigneeName = assigneeName;
		this.assigneeEmpId = assigneeEmpId;
		this.assigneeGroup = assigneeGroup;
		this.assigneeSubGroup = assigneeSubGroup;
		this.formatLink = formatLink;
		this.functionalityId = functionalityId;
	}

	public Long getRequestMenuID() {
		return requestMenuID;
	}

	public void setRequestMenuID(Long requestMenuID) {
		this.requestMenuID = requestMenuID;
	}

	public String getRequestMenuName() {
		return requestMenuName;
	}

	public void setRequestMenuName(String requestMenuName) {
		this.requestMenuName = requestMenuName;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	public String getCallCategory() {
		return callCategory;
	}

	public void setCallCategory(String callCategory) {
		this.callCategory = callCategory;
	}

	public String getMasterCallType() {
		return masterCallType;
	}

	public void setMasterCallType(String masterCallType) {
		this.masterCallType = masterCallType;
	}

	public String getCallType() {
		return callType;
	}

	public void setCallType(String callType) {
		this.callType = callType;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getAssigneeName() {
		return assigneeName;
	}

	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	public String getAssigneeEmpId() {
		return assigneeEmpId;
	}

	public void setAssigneeEmpId(String assigneeEmpId) {
		this.assigneeEmpId = assigneeEmpId;
	}

	public String getAssigneeGroup() {
		return assigneeGroup;
	}

	public void setAssigneeGroup(String assigneeGroup) {
		this.assigneeGroup = assigneeGroup;
	}

	public String getAssigneeSubGroup() {
		return assigneeSubGroup;
	}

	public void setAssigneeSubGroup(String assigneeSubGroup) {
		this.assigneeSubGroup = assigneeSubGroup;
	}

	public String getFormatLink() {
		return formatLink;
	}

	public void setFormatLink(String formatLink) {
		this.formatLink = formatLink;
	}

	public long getFunctionalityId() {
		return functionalityId;
	}

	public void setFunctionalityId(long functionalityId) {
		this.functionalityId = functionalityId;
	}

	@Override
	public String toString() {
		return "ServiceWebPageMenuVO [requestMenuID=" + requestMenuID + ", requestMenuName=" + requestMenuName + ", productCategory=" + productCategory + ", memberType=" + memberType
				+ ", callCategory=" + callCategory + ", masterCallType=" + masterCallType + ", callType=" + callType + ", subType=" + subType + ", assigneeName=" + assigneeName + ", assigneeEmpId="
				+ assigneeEmpId + ", assigneeGroup=" + assigneeGroup + ", assigneeSubGroup=" + assigneeSubGroup + ", formatLink=" + formatLink + ", functionalityId=" + functionalityId + "]";
	}

}
