package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;
import java.util.Hashtable;

public class ServiceExpressPO implements Serializable {

	private String requestID;
	private String location;
	private String empCount;
	private String SPOCname;
	private String mobilenumber;
	private String landlinenumber;
	private String description;
	private String userID;
	private String user_role;
	private String policy_number;
	private Date created_date;
	private String client_ID;
		
	

	public String getRequestID() {
		return requestID;
	}



	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}



	public String getLocation() {
		return location;
	}



	public void setLocation(String location) {
		this.location = location;
	}



	public String getEmpCount() {
		return empCount;
	}



	public void setEmpCount(String empCount) {
		this.empCount = empCount;
	}



	public String getSPOCname() {
		return SPOCname;
	}



	public void setSPOCname(String sPOCname) {
		SPOCname = sPOCname;
	}



	public String getMobilenumber() {
		return mobilenumber;
	}



	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}



	public String getLandlinenumber() {
		return landlinenumber;
	}



	public void setLandlinenumber(String landlinenumber) {
		this.landlinenumber = landlinenumber;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}

	

	public String getUserID() {
		return userID;
	}



	public void setUserID(String userID) {
		this.userID = userID;
	}



	public String getUser_role() {
		return user_role;
	}



	public void setUser_role(String user_role) {
		this.user_role = user_role;
	}



	public String getPolicy_number() {
		return policy_number;
	}



	public void setPolicy_number(String policy_number) {
		this.policy_number = policy_number;
	}



	public Date getCreated_date() {
		return created_date;
	}



	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}



	public String getClient_ID() {
		return client_ID;
	}



	public void setClient_ID(String client_ID) {
		this.client_ID = client_ID;
	}



	@Override
	public String toString() {
		return "ServiceExpressPO [requestID=" + requestID + ", location="
				+ location + ", empCount=" + empCount + ", SPOCname="
				+ SPOCname + ", mobilenumber=" + mobilenumber
				+ ", landlinenumber=" + landlinenumber + ", description="
				+ description + ", userID=" + userID + ", user_role="
				+ user_role + ", policy_number=" + policy_number
				+ ", created_date=" + created_date + ", client_ID=" + client_ID
				+ "]";
	}
	
}
