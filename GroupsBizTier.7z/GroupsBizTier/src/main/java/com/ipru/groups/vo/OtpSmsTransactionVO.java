package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class OtpSmsTransactionVO extends BaseVO {

	private static final long serialVersionUID = 1L;

	private Long ostId; // primary key OST_ID
	private Long otpTransactionId;  // ForeignKey from OTP_NO
	// private OTPNumberBean oTPNumberBean;
	private String sentOTP;
	private Date requestSubmitDate;
	private String smsTransactionId; // May be required for future delivery
										// reports
	private String responseErrorCode;
	private String responseErrorDesc;
	private String requestErrorCode;
	private String requestErrorDesc;
	private String ostMessageId;
	private String smsRequestId; // May be required for future delivery reports
	private String sentMobileNumber;

	public Long getOstId() {
		return ostId;
	}

	public void setOstId(Long ostId) {
		this.ostId = ostId;
	}

	public Long getOtpTransactionId() {
		return otpTransactionId;
	}

	public void setOtpTransactionId(Long otpTransactionId) {
		this.otpTransactionId = otpTransactionId;
	}

	public String getSentOTP() {
		return sentOTP;
	}

	public void setSentOTP(String sentOTP) {
		this.sentOTP = sentOTP;
	}

	public Date getRequestSubmitDate() {
		return requestSubmitDate;
	}

	public void setRequestSubmitDate(Date requestSubmitDate) {
		this.requestSubmitDate = requestSubmitDate;
	}

	public String getSmsTransactionId() {
		return smsTransactionId;
	}

	public void setSmsTransactionId(String smsTransactionId) {
		this.smsTransactionId = smsTransactionId;
	}

	public String getResponseErrorCode() {
		return responseErrorCode;
	}

	public void setResponseErrorCode(String responseErrorCode) {
		this.responseErrorCode = responseErrorCode;
	}

	public String getResponseErrorDesc() {
		return responseErrorDesc;
	}

	public void setResponseErrorDesc(String responseErrorDesc) {
		this.responseErrorDesc = responseErrorDesc;
	}

	public String getRequestErrorCode() {
		return requestErrorCode;
	}

	public void setRequestErrorCode(String requestErrorCode) {
		this.requestErrorCode = requestErrorCode;
	}

	public String getRequestErrorDesc() {
		return requestErrorDesc;
	}

	public void setRequestErrorDesc(String requestErrorDesc) {
		this.requestErrorDesc = requestErrorDesc;
	}

	public String getOstMessageId() {
		return ostMessageId;
	}

	public void setOstMessageId(String ostMessageId) {
		this.ostMessageId = ostMessageId;
	}

	public String getSmsRequestId() {
		return smsRequestId;
	}

	public void setSmsRequestId(String smsRequestId) {
		this.smsRequestId = smsRequestId;
	}

	public String getSentMobileNumber() {
		return sentMobileNumber;
	}

	public void setSentMobileNumber(String sentMobileNumber) {
		this.sentMobileNumber = sentMobileNumber;
	}

}
