package com.ipru.groups.po.profileupdate.companyaddress;

public class CompanyAddressUploadPO {

}
