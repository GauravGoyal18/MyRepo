package com.ipru.groups.vo;

import java.util.Date;

import com.ipru.groups.grpswitch.bean.SwitchFundDetailsPO;
import com.tcs.vo.BaseVO;

public class BrokerAccruedRequestVO extends GroupsBaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String role;
	private String policyNo;
	private String status;
	private String clientName;
	private String nationalCode;
	private String BranchCode;
	private String loginType;
	private String brokerType;
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getNationalCode() {
		return nationalCode;
	}
	public void setNationalCode(String nationalCode) {
		this.nationalCode = nationalCode;
	}
	public String getBranchCode() {
		return BranchCode;
	}
	public void setBranchCode(String branchCode) {
		BranchCode = branchCode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
	public String getBrokerType() {
		return brokerType;
	}
	public void setBrokerType(String brokerType) {
		this.brokerType = brokerType;
	}
	@Override
	public String toString() {
		return "BrokerAccruedRequestVO [role=" + role + ", policyNo=" + policyNo + ", status=" + status + ", clientName=" + clientName + ", nationalCode=" + nationalCode + ", BranchCode="
				+ BranchCode + ", loginType=" + loginType + ", brokerType=" + brokerType + "]";
	}
	
	
	
	
	
}
