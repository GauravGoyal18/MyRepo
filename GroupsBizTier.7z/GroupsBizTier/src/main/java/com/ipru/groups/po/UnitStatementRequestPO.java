package com.ipru.groups.po;

public class UnitStatementRequestPO {
	
	private UnitStatementPO unitStatementPO;

	public UnitStatementPO getUnitStatementPO() {
		return unitStatementPO;
	}

	public void setUnitStatementPO(UnitStatementPO unitStatementPO) {
		this.unitStatementPO = unitStatementPO;
	}

	@Override
	public String toString() {
		return "UnitStatementRequestPO [unitStatementPO=" + unitStatementPO
				+ "]";
	}

}
