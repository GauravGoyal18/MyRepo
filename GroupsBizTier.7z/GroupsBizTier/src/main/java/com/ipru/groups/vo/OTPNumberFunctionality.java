package com.ipru.groups.vo;

import java.io.Serializable;
import java.sql.Timestamp;

public class OTPNumberFunctionality implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long transactionId = 0;
	private Long otpTransactionId = 0L;
	private String otpNumber = "";
	private String otpStatus = "";
	private String identifierCode = "";
	private String identifierType = "";
	private String functionality = "";
	private int attempts = 0;
	private String mailSentFlag = null;
	private String smsSentFlag = null;
	private Timestamp otpCreatedDate = null;
	private Timestamp otpUpdatedDate = null;
	
	private String policyNo;

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public Long getOtpTransactionId() {
		return otpTransactionId;
	}

	public void setOtpTransactionId(Long otpTransactionId) {
		this.otpTransactionId = otpTransactionId;
	}

	public String getOtpNumber() {
		return otpNumber;
	}

	public void setOtpNumber(String otpNumber) {
		this.otpNumber = otpNumber;
	}

	public String getOtpStatus() {
		return otpStatus;
	}

	public void setOtpStatus(String otpStatus) {
		this.otpStatus = otpStatus;
	}

	public String getIdentifierCode() {
		return identifierCode;
	}

	public void setIdentifierCode(String identifierCode) {
		this.identifierCode = identifierCode;
	}

	public String getIdentifierType() {
		return identifierType;
	}

	public void setIdentifierType(String identifierType) {
		this.identifierType = identifierType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getFunctionality() {
		return functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}

	public int getAttempts() {
		return attempts;
	}

	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}

	public String getMailSentFlag() {
		return mailSentFlag;
	}

	public void setMailSentFlag(String mailSentFlag) {
		this.mailSentFlag = mailSentFlag;
	}

	public String getSmsSentFlag() {
		return smsSentFlag;
	}

	public void setSmsSentFlag(String smsSentFlag) {
		this.smsSentFlag = smsSentFlag;
	}

	public Timestamp getOtpCreatedDate() {
		return otpCreatedDate;
	}

	public void setOtpCreatedDate(Timestamp otpCreatedDate) {
		this.otpCreatedDate = otpCreatedDate;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	

	public Timestamp getOtpUpdatedDate() {
		return otpUpdatedDate;
	}

	public void setOtpUpdatedDate(Timestamp otpUpdatedDate) {
		this.otpUpdatedDate = otpUpdatedDate;
	}

	@Override
	public String toString() {
		return "OTPNumberFunctionality [transactionId=" + transactionId
				+ ", otpTransactionId=" + otpTransactionId + ", otpNumber="
				+ otpNumber + ", otpStatus=" + otpStatus + ", identifierCode="
				+ identifierCode + ", identifierType=" + identifierType
				+ ", functionality=" + functionality + ", attempts=" + attempts
				+ ", mailSentFlag=" + mailSentFlag + ", smsSentFlag="
				+ smsSentFlag + ", otpCreatedDate=" + otpCreatedDate
				+ ", otpUpdatedDate=" + otpUpdatedDate + ", policyNo="
				+ policyNo + "]";
	}

	

}
