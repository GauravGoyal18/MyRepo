package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class GstSaveRequestVO extends BaseVO {

	private static final long serialVersionUID = 1L;
	private GstSubmitVO gstFormJson;
	private EmailMobileRequestVO emailMobileJson;

	public GstSubmitVO getGstFormJson() {
		return gstFormJson;
	}

	public void setGstFormJson(GstSubmitVO gstFormJson) {
		this.gstFormJson = gstFormJson;
	}

	public EmailMobileRequestVO getEmailMobileJson() {
		return emailMobileJson;
	}

	public void setEmailMobileJson(EmailMobileRequestVO emailMobileJson) {
		this.emailMobileJson = emailMobileJson;
	}

}
