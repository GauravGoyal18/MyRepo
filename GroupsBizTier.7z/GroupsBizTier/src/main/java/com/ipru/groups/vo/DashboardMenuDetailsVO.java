package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class DashboardMenuDetailsVO extends BaseVO {

	private Long id;
	private String policyNo;
	private String role;
	private String menu;
	private String logo;
	

	//getter setter
	public String getLogo()
	{
		return logo;
	}
	public void setLogo(String logo)
	{
		this.logo=logo;
	}
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}
	@Override
	public String toString() {
		return "DashboardMenuDetailsVO [id=" + id + ", policyNo=" + policyNo
				+ ", role=" + role + ", menu=" + menu + ", logo=" + logo + "]";
	}
	
	
	
	
}
