package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

import com.ipru.groups.vo.RoleScreenAccessMappingVO;

public class RoleScreenAccessMapPO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String groupId;
	private String groupName;
	private String display;
	private int displayOrder;
	private List<RoleScreenAccessMappingVO> accessMappingList;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public List<RoleScreenAccessMappingVO> getAccessMappingList() {
		return accessMappingList;
	}

	public void setAccessMappingList(List<RoleScreenAccessMappingVO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getDisplay() {
		return display;
	}

	public void setDisplay(String display) {
		this.display = display;
	}

	public int getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}

	@Override
	public String toString() {
		return "RoleScreenAccessMapPO [groupId=" + groupId + ", groupName=" + groupName + ", display=" + display + ", displayOrder=" + displayOrder + ", accessMappingList=" + accessMappingList + "]";
	}

}
