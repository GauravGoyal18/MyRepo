package com.ipru.groups.vo;

import java.util.List;

import com.ipru.groups.po.ClaimsSubmitPO;
import com.ipru.groups.po.UploadFilePO;

public class ClaimsListVO extends GroupsBaseVO {

	private List<ClaimsSubmitVO> addClaims;

	public List<ClaimsSubmitVO> getAddClaims() {
		return addClaims;
	}

	public void setAddClaims(List<ClaimsSubmitVO> addClaims) {
		this.addClaims = addClaims;
	}

}
