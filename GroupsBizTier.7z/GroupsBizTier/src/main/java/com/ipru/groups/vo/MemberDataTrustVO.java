package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class MemberDataTrustVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String memberId;
	private String memberName;
	private String dateOfJoining;
	private String dateOfBirth;
	private double units;

	public MemberDataTrustVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberDataTrustVO(String memberId, String memberName,
			String dateOfJoining, String dateOfBirth, double units) {
		super();
		this.memberId = memberId;
		this.memberName = memberName;
		this.dateOfJoining = dateOfJoining;
		this.dateOfBirth = dateOfBirth;
		this.units = units;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public double getUnits() {
		return units;
	}

	public void setUnits(double units) {
		this.units = units;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {
		return "MemberDataTrustVO [memberId=" + memberId + ", memberName="
				+ memberName + ", dateOfJoining=" + dateOfJoining
				+ ", dateOfBirth=" + dateOfBirth + ", units=" + units + "]";
	}

}
