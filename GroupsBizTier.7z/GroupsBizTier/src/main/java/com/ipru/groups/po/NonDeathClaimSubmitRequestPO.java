package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

public class NonDeathClaimSubmitRequestPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<UploadFilePO> uploadFileList;

	public List<UploadFilePO> getUploadFileList() {
		return uploadFileList;
	}

	public void setUploadFileList(List<UploadFilePO> uploadFileList) {
		this.uploadFileList = uploadFileList;
	}

	@Override
	public String toString() {
		return "NonDeathClaimSubmitRequestPO [uploadFileList=" + uploadFileList
				+ "]";
	}

}
