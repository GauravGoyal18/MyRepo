package com.ipru.groups.vo;

import java.util.List;

public class DashboardIWantToJson {
	
	List<DashboardMenuDetailsVO> menuList;

	public List<DashboardMenuDetailsVO> getMenuList() {
		return menuList;
	}

	public void setMenuList(List<DashboardMenuDetailsVO> menuList) {
		this.menuList = menuList;
	}

	@Override
	public String toString() {
		return "DashboardIWantToJson [menuList=" + menuList + "]";
	}
	
}
