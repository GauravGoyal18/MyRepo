package com.ipru.groups.po;

import java.io.Serializable;

public class GroupsBrokerPO  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String nationalCode; //UM Code in Retail
	private String branchCode; //Referal Code in Retail
	private long timestampMs;
	private String websiteSource;
	private String fscChannel;
	private String fscClientId; //FSC_ClientId
	
	public String getNationalCode() {
		return nationalCode;
	}
	public void setNationalCode(String nationalCode) {
		this.nationalCode = nationalCode;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public long getTimestampMs() {
		return timestampMs;
	}
	public void setTimestampMs(long timestampMs) {
		this.timestampMs = timestampMs;
	}
	public String getWebsiteSource() {
		return websiteSource;
	}
	public void setWebsiteSource(String websiteSource) {
		this.websiteSource = websiteSource;
	}
	public String getFscChannel() {
		return fscChannel;
	}
	public void setFscChannel(String fscChannel) {
		this.fscChannel = fscChannel;
	}
	public String getFscClientId() {
		return fscClientId;
	}
	public void setFscClientId(String fscClientId) {
		this.fscClientId = fscClientId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
		
		
}
