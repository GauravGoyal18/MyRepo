package com.ipru.groups.enums;

public enum RequestTypeEnum {
			
			SWITCHFUND("SWCH"),STOF("STOF");
			
			private final String requestType;

			RequestTypeEnum(String requestType) {
				this.requestType = requestType;
			}

			public String getRequestType() {
				return requestType;
			}
			
}
