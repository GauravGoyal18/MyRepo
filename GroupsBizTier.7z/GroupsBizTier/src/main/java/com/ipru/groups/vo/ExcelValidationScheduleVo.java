package com.ipru.groups.vo;

public class ExcelValidationScheduleVo {

	
	private long REQUEST_ID;
	
	private String trycountsch;
	private String docPath;
	public long getREQUEST_ID() {
		return REQUEST_ID;
	}
	public void setREQUEST_ID(long rEQUEST_ID) {
		REQUEST_ID = rEQUEST_ID;
	}
	
	public String getTrycountsch() {
		return trycountsch;
	}
	public void setTrycountsch(String trycountsch) {
		this.trycountsch = trycountsch;
	}
	public String getDocPath() {
		return docPath;
	}
	public void setDocPath(String docPath) {
		this.docPath = docPath;
	}
	@Override
	public String toString() {
		return "ExcelValidationScheduleVo [REQUEST_ID=" + REQUEST_ID
				+ ", trycountsch=" + trycountsch + ", docPath=" + docPath + "]";
	}
	
	
}
