package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class ServiceWebPageRequestVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNo;
	private String productCategory;
	private String role;
	private String selectedOption;
	private String memberType;

	public ServiceWebPageRequestVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceWebPageRequestVO(String policyNo, String productCategory, String role, String selectedOption, String memberType) {
		super();
		this.policyNo = policyNo;
		this.productCategory = productCategory;
		this.role = role;
		this.selectedOption = selectedOption;
		this.memberType = memberType;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getSelectedOption() {
		return selectedOption;
	}

	public void setSelectedOption(String selectedOption) {
		this.selectedOption = selectedOption;
	}

	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	@Override
	public String toString() {
		return "ServiceWebPageRequestVO [policyNo=" + policyNo + ", productCategory=" + productCategory + ", role=" + role + ", selectedOption=" + selectedOption + ", memberType=" + memberType + "]";
	}

}
