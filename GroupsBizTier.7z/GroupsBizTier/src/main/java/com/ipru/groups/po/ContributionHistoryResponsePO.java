package com.ipru.groups.po;

import com.tcs.web.po.BasePO;

public class ContributionHistoryResponsePO extends BasePO {
	
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private String fundCode;
		private String fundType;
		private String transactionDate;
		private String nav;
		private String units;
		private String amount;
		private String transactionType;
	
		
		

	public String getFundCode() {
		return fundCode;
	}
	public void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}
	public String getFundType() {
		return fundType;
	}
	public void setFundType(String fundType) {
		this.fundType = fundType;
	}
	
	public String getNav() {
		return nav;
	}
	public void setNav(String nav) {
		this.nav = nav;
	}
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	@Override
	public String toString() {
		return "ContributionHistoryResponsePO [fundCode=" + fundCode
				+ ", fundType=" + fundType + ", transactionDate="
				+ transactionDate + ", nav=" + nav + ", units=" + units
				+ ", amount=" + amount + ", transactionType=" + transactionType
				+ "]";
	}
	
	
	
		
		}
