package com.ipru.groups.vo;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClaimsExcelValidationVO extends GroupsBaseVO {

	private static final long serialVersionUID = 1L;
	private FunctionalityMasterVO functionality;
	private long customerTrxnId;
	private long requestId;
	private Date currentDate;
	
	private String approvalStatus;
	private String errormessage;
	
	
	private Set<UploadFileVO> uploadFileVOSet = new HashSet<UploadFileVO>(0);
	private Set<ClaimsRequestVO> claimsRequestVOSet = new HashSet<ClaimsRequestVO>(0);
	private Set<ClaimsBeneficiaryVO> claimsBeneficiaryVOSet = new HashSet<ClaimsBeneficiaryVO>(0);
	private Set<ClaimsApprovalVO> claimsApprovalVoSet = new HashSet<ClaimsApprovalVO>(0);
	
	public FunctionalityMasterVO getFunctionality() {
		return functionality;
	}
	public void setFunctionality(FunctionalityMasterVO functionality) {
		this.functionality = functionality;
	}
	public long getCustomerTrxnId() {
		return customerTrxnId;
	}
	public void setCustomerTrxnId(long customerTrxnId) {
		this.customerTrxnId = customerTrxnId;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public Date getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
	
	public String getApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public String getErrormessage() {
		return errormessage;
	}
	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}
	public Set<UploadFileVO> getUploadFileVOSet() {
		return uploadFileVOSet;
	}
	public void setUploadFileVOSet(Set<UploadFileVO> uploadFileVOSet) {
		this.uploadFileVOSet = uploadFileVOSet;
	}
	public Set<ClaimsRequestVO> getClaimsRequestVOSet() {
		return claimsRequestVOSet;
	}
	public void setClaimsRequestVOSet(Set<ClaimsRequestVO> claimsRequestVOSet) {
		this.claimsRequestVOSet = claimsRequestVOSet;
	}
	public Set<ClaimsBeneficiaryVO> getClaimsBeneficiaryVOSet() {
		return claimsBeneficiaryVOSet;
	}
	public void setClaimsBeneficiaryVOSet(Set<ClaimsBeneficiaryVO> claimsBeneficiaryVOSet) {
		this.claimsBeneficiaryVOSet = claimsBeneficiaryVOSet;
	}
	public Set<ClaimsApprovalVO> getClaimsApprovalVoSet() {
		return claimsApprovalVoSet;
	}
	public void setClaimsApprovalVoSet(Set<ClaimsApprovalVO> claimsApprovalVoSet) {
		this.claimsApprovalVoSet = claimsApprovalVoSet;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

	}
