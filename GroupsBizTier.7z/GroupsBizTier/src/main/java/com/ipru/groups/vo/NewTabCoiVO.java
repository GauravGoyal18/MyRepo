package com.ipru.groups.vo;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NewTabCoiVO extends GroupsBaseVO {

	private static final long serialVersionUID = 1L;
	private String policynumber;
	private String customerId;
	private String templateId;
	private String loanAcNO;
	public String getpolicynumber() {
		return policynumber;
	}
	public void setpolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public String getLoanAcNO() {
		return loanAcNO;
	}
	public void setLoanAcNO(String loanAcNO) {
		this.loanAcNO = loanAcNO;
	}
	

	}
