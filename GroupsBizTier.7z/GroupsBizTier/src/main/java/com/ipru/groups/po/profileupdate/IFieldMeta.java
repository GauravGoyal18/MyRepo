package com.ipru.groups.po.profileupdate;

import java.io.Serializable;

public interface IFieldMeta extends Serializable {
	
	public String getFieldId();
	public void setFieldId(String fieldId);
	public String getOldValue();
	public void setOldValue(String oldValue);
	public String getNewValue();
	public void setNewValue(String newValue);
	public String getIndex();
	public void setIndex(String index);
/*	new added*/
	
	public int getFieldGroupCode();
	public void setFieldGroupCode(int fieldGroupCode);
	public int getFieldCode();
	public void setFieldCode(int fieldCode);
	
	
	
	
	/*public String getShowDisabled();
	public void setShowDisabled(String showDisabled);
	public String getShowEdit();
	public void setShowEdit(String showEdit);
	public String getShow();
	public void setShow(String Show);
	
	
	public String getFieldCanonicalName();
	public void setFieldCanonicalName(String fieldCanonicalName);*/
	
	
	
	
	
	

}
