package com.ipru.groups.po;

import com.tcs.web.po.BasePO;

public class CoiPO extends BasePO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNumber;
	private String dob;
	private String memLoanAcc;
	private String panNo;
	private String companyName;
	private String emailId;
	private long mobileNo;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getMemLoanAcc() {
		return memLoanAcc;
	}

	public void setMemLoanAcc(String memLoanAcc) {
		this.memLoanAcc = memLoanAcc;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		return "CoiPO [policyNumber=" + policyNumber + ", dob=" + dob + ", memLoanAcc=" + memLoanAcc + ", panNo=" + panNo + ", companyName=" + companyName + ", emailId=" + emailId + ", mobileNo="
				+ mobileNo + "]";
	}

}
