package com.ipru.groups.vo;

import java.util.List;

import com.tcs.web.po.BasePO;

public class ProductFundMasterDataVO extends BasePO{
	List<ProductMasterVO> productMasterList;
	List<FundMasterVO> fundMasterList;
	List<ProductFundMasterVO> productFundMasterList;
	List<ProductSwitchAmountVO> productSwitchAmountMasterList;
	private String policyNumber;
	private String clientId;
	private String role;
	private String roleType;
	
	public String getRoleType() {
		return roleType;
	}
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
	public synchronized String getPolicyNumber() {
		return policyNumber;
	}
	public synchronized void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public synchronized String getClientId() {
		return clientId;
	}
	public synchronized void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public synchronized String getRole() {
		return role;
	}
	public synchronized void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "ProductFundMasterDataVO [productMasterList="
				+ productMasterList + ", fundMasterList=" + fundMasterList
				+ ", productFundMasterList=" + productFundMasterList
				+ ", productSwitchAmountMasterList="
				+ productSwitchAmountMasterList + ", policyNumber="
				+ policyNumber + ", clientId=" + clientId + ", role=" + role
				+ ", roleType=" + roleType + "]";
	}
	public synchronized List<ProductMasterVO> getProductMasterList() {
		return productMasterList;
	}
	public synchronized void setProductMasterList(
			List<ProductMasterVO> productMasterList) {
		this.productMasterList = productMasterList;
	}
	public synchronized List<FundMasterVO> getFundMasterList() {
		return fundMasterList;
	}
	public synchronized void setFundMasterList(List<FundMasterVO> fundMasterList) {
		this.fundMasterList = fundMasterList;
	}
	public synchronized List<ProductFundMasterVO> getProductFundMasterList() {
		return productFundMasterList;
	}
	public synchronized void setProductFundMasterList(
			List<ProductFundMasterVO> productFundMasterList) {
		this.productFundMasterList = productFundMasterList;
	}
	public synchronized List<ProductSwitchAmountVO> getProductSwitchAmountMasterList() {
		return productSwitchAmountMasterList;
	}
	public synchronized void setProductSwitchAmountMasterList(
			List<ProductSwitchAmountVO> productSwitchAmountMasterList) {
		this.productSwitchAmountMasterList = productSwitchAmountMasterList;
	}
	
}
