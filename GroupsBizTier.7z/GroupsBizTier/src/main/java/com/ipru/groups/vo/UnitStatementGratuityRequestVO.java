package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class UnitStatementGratuityRequestVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private UnitStatementGratuityFundVO unitStatementGratuityVO;

	@Override
	public String toString() {
		return "UnitStatementGratuityRequestVO [unitStatementGratuityVO="
				+ unitStatementGratuityVO + "]";
	}

	public UnitStatementGratuityFundVO getUnitStatementGratuityVO() {
		return unitStatementGratuityVO;
	}

	public void setUnitStatementGratuityVO(
			UnitStatementGratuityFundVO unitStatementGratuityVO) {
		this.unitStatementGratuityVO = unitStatementGratuityVO;
	}

}
