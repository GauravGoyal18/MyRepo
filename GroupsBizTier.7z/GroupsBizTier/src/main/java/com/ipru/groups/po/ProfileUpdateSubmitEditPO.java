/*package com.ipru.groups.po;

import java.util.List;
import java.util.Map;

public class ProfileUpdateSubmitEditPO {
	
	private List<UploadFilePO> uploadFileList;
	private <ProfileUpdateDetailsEditPo> profileUpdateEdit;

}
*/