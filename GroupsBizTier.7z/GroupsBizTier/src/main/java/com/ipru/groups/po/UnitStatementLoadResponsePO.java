package com.ipru.groups.po;

import java.util.List;
import java.util.Map;

import com.ipru.groups.vo.FieldAccessMappingVO;
import com.tcs.web.vo.BaseVO;

public class UnitStatementLoadResponsePO extends BaseVO {

	private static final long serialVersionUID = 1L;
	private List<RoleScreenAccessMappingPO> accessMappingList;
	private Map<String, FieldAccessMappingVO> fieldAccessMappingMap;

	public UnitStatementLoadResponsePO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setAccessMappingList(
			List<RoleScreenAccessMappingPO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}

	public List<RoleScreenAccessMappingPO> getAccessMappingList() {
		return accessMappingList;
	}

	public Map<String, FieldAccessMappingVO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}

	public void setFieldAccessMappingMap(
			Map<String, FieldAccessMappingVO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}

	@Override
	public String toString() {
		return "UnitStatementLoadResponsePO [accessMappingList="
				+ accessMappingList + ", fieldAccessMappingMap="
				+ fieldAccessMappingMap + "]";
	}

}
