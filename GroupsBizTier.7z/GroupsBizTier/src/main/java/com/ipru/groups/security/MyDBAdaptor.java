package com.ipru.groups.security;

import java.util.HashMap;
import java.util.List;

import javax.naming.NamingException;
import javax.naming.directory.DirContext;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.ipru.enums.Role;
import com.ipru.security.dao.IPruUserDetailDAOHibernateImpl;
import com.ipru.security.user.GroupsUserAuthInfo;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;
import com.tcs.security.auth.AbstractAuthStoreDBAdapter;
import com.tcs.security.user.Autherization;
import com.tcs.security.user.IUser;
import com.tcs.security.user.UserVO;

public class MyDBAdaptor extends AbstractAuthStoreDBAdapter// GenericDBHibernateAdapter
{

	String message = "";

	public String getMessage() {
		return message;
	}

	public void myMethod() {

	}

	@Override
	public void deleteUser(String p_StrUserName) throws NamingException {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isValidUser(String p_StrUserName, String p_StrPassword) throws Exception {
		FLogger.info("securityLogger", "MyDBAdaptor", "isValidUser", "is valid use called");
		IPruUserDetailDAOHibernateImpl ipruUserDao = new IPruUserDetailDAOHibernateImpl("GroupSecurity");
		boolean b = ipruUserDao.IsValidUser(p_StrUserName, p_StrPassword);
		message = ipruUserDao.getMessage();
		FLogger.info("securityLogger", "MyDBAdaptor", "isValidUser", "exixting is valid user");
		return b;

	}

	@Override
	public IUser getUser(String p_StrUserName, String p_StrPassword) throws NamingException {
		FLogger.info("securityLogger", "MyDBAdaptor", "getUser", "get User called in MyDBAdaptor");
		IPruUser user = null;
		Session session = null;
		Transaction tx = null;
		try {
			IPruUserDetailDAOHibernateImpl ipruUserDao = new IPruUserDetailDAOHibernateImpl("GroupSecurity");
			FLogger.info("securityLogger", "MyDBAdaptor", "getUser(String p_StrUserName, String p_StrPassword)", "getting sesion");
			session = ipruUserDao.getSession();
			tx = session.beginTransaction();
			GroupsUserAuthInfo u = ipruUserDao.getUser(p_StrUserName, p_StrPassword, session);
			if (u != null) {
				user = new IPruUser();
				Autherization a = new Autherization();
				a.setRole(u.getRole());
				user.setAutherization(a);
				if (u.getFname() != null) {
					user.setUsername(u.getFname());
					user.setUserId(u.getFname());
				}
				user.setPassword(u.getPsswrd());
				user.setUserIdInt(u.getUserid());
				user.setFirstLoginStatus(u.getFirstLogin());
				user.setLastPasswordUpdateDate(u.getLastPasswordUpdateDate());
				user.setRoles(u.getRole());
				user.setPolicyNo(u.getPolicyNo());
				if (u.getRole().contains(Role.TRUST.name()) || u.getRole().contains(Role.GTRUST.name()))
					user.setClientId(u.getPolicyNo());
				else
					user.setClientId(u.getClientId());
				user.setWebClientId(u.getWebClientId());

				user.setDbValidation(false);
				if (u != null && u.getIsuserlocked().equalsIgnoreCase("true"))
					user.setAccountLocked(true);
				else
					user.setAccountLocked(false);
				if (u != null && u.getIsvaliduser().equalsIgnoreCase("true"))
					user.setAccountExpired(false);
				else if (u != null && u.getIsvaliduser().equalsIgnoreCase("false"))
					user.setAccountExpired(true);
				user.setFirstName(u.getFirstName());
				user.setLastName(u.getLastName());	
			}
			tx.commit();
			return user;
		}
		catch (Exception e) {
			FLogger.error("securityLoggerError", "MyDBAdaptor", "getUser(String p_StrUserName, String p_StrPassword)", "Exception found in getting user in getUser :" + e.getMessage());
			e.printStackTrace();
			tx.rollback();

		}
		finally {
			if (session != null && session.isOpen()) {
				session.clear();
				FLogger.info("securityLogger", "MyDBAdaptor", "getUser(String p_StrUserName, String p_StrPassword)", "closing sesion");
				session.close();
			}
		}
		return null;
	}

	@Override
	public boolean authenticateUser(String p_StrUserId, String p_StrPwd) {
		return false;
	}

	@Override
	public void deleteGroup(String p_StrName) throws NamingException {

	}

	@Override
	public void deletePermission(String p_StrName) throws NamingException {

	}

	@Override
	public void assignUser(String p_StrUserName, String p_StrGroupName) throws NamingException {

	}

	@Override
	public void removeUser(String p_StrUserName, String p_StrGroupName) throws NamingException {

	}

	@Override
	public boolean userInGroup(String p_StrUserName, String p_StrGroupName) throws NamingException {
		return false;
	}

	@Override
	public List<?> getMembers(String p_StrGroupName) throws NamingException {
		return null;
	}

	@Override
	public List<?> getGroups(String p_StrUserName) throws NamingException {
		return null;
	}

	@Override
	public List<?> getPermissions(String p_StrGroupName) throws NamingException {
		return null;
	}

	@Override
	public void addUser(String p_StrUserName, String p_StrFirstName, String p_StrLastName, String p_StrPassword, String p_StrEmail, int p_IAccActivation) throws NamingException {

	}

	@Override
	public boolean validateAccount(String p_StrActivationCode, String p_StrAccessCode, String p_StrPassword) {
		return false;
	}

	@Override
	public boolean validateAccount(String p_StrActivationCode, String p_StrAccessCode, String p_StrPassword, String p_StrUserid) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void addGroup(String p_StrName, String p_StrDescription) throws NamingException {
		// TODO Auto-generated method stub

	}

	@Override
	public void addPermission(String p_StrName, String p_StrDescription) throws NamingException {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean updateUserPassword(String p_StrUserName, String p_StrNewPassword) throws NamingException {
		// TODO Auto-generated method stub
		// LoginProcessDAOImplementation dao = new
		// LoginProcessDAOImplementation(
		// "security");
		// return dao.changePassword(p_StrUserName, p_StrNewPassword);
		return false;

	}

	@Override
	public boolean updateUnblockFlag(String p_StrUserName) throws NamingException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateEntityId(String p_StrUserName, String p_StrEntityId) throws NamingException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isUserLocked(String p_StrUserName) throws Exception {
		// LoginProcessDAOImplementation dao = new
		// LoginProcessDAOImplementation(
		// "security");
		// return dao.isUserLocked(p_StrUserName);
		FLogger.info("securityLogger", "MyDBAdaptor", "isValidUser", "isUserLocked is called");
		IPruUserDetailDAOHibernateImpl ipruUserDao = new IPruUserDetailDAOHibernateImpl("GroupSecurity");
		boolean userLockedStatus = ipruUserDao.IsUserLocked(p_StrUserName);
		return userLockedStatus;

	}

	@Override
	public boolean updateTryCount(String p_StrUserName, int p_IInTryCount) throws NamingException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public HashMap<?, ?> getUserDetails(String p_StrUserName, String p_StrUserPwd) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAttribute(String p_StrUserName, String p_StrAttribute) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateParamsDuringLogin(String p_StrUserName, String p_StrFirstTimeLogin) throws NamingException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public DirContext getAdapterContext() throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateParamsSpeedxAccLock(String p_StrUserName) throws NamingException {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * @Override public IUser getUser(String p_StrUserName) throws
	 * NamingException { IPruUser user = new IPruUser(); Autherization a = new
	 * Autherization(); a.setRole("ROLE_AGENT"); user.setAutherization(a);
	 * user.setUsername(p_StrUserName); user.setRoles("BANCA_EMP"); // To Write
	 * Logic for taking additional user details // Added By 380982 20-11-2012
	 *//**
	 * Stored Procedure Call
	 */
	/*
	 * IPruUserDetailDAOHibernateImpl ipruUserDao = new
	 * IPruUserDetailDAOHibernateImpl("security"); //Session session = null; try
	 * { Properties prop=new Properties(); try {
	 * prop=MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
	 * String roleDerived="UNKNOWN"; FLogger.info("securityLogger",
	 * "MyDBAdaptor", "getUser(String p_StrUserName)", "getting session");
	 * //session = new IPruUserDetailDAOHibernateImpl("security").getSession();
	 * GroupsUserAuthInfo u=ipruUserDao.getUser(p_StrUserName,null); String
	 * userRole = prop.getProperty("unknownRole"); String roleTypeD =
	 * prop.getProperty("roleTypeD"); String roleTypeA =
	 * prop.getProperty("roleTypeA"); //derive role prc call::380982 if(u!=null
	 * && u.getRoleType().equalsIgnoreCase(roleTypeD)) { roleDerived=new
	 * IPruUserDetailDAOHibernateImpl
	 * ("security").storedprocforDeriveRole(p_StrUserName);
	 * if(roleDerived!=null) { user.setRoles(roleDerived);
	 * user.setFirstLDAPLogin(false); user.setAgentId(p_StrUserName); } else {
	 * user.setRoles(userRole); user.setFirstLDAPLogin(true);
	 * user.setAgentId(p_StrUserName); } } else { if(u!=null &&
	 * u.getRoleType().equalsIgnoreCase(roleTypeA)) {
	 * user.setRoles(u.getWebSiteRoleCode()); user.setFirstLDAPLogin(false);
	 * user.setAgentId(p_StrUserName); } else { roleDerived=new
	 * IPruUserDetailDAOHibernateImpl
	 * ("security").storedprocforDeriveRole(p_StrUserName);
	 * user.setRoles(roleDerived); user.setFirstLDAPLogin(true);
	 * user.setAgentId(p_StrUserName); } } if(u!=null &&
	 * u.getValidationMechanism().equalsIgnoreCase("DB")) {
	 * user.setDbValidation(false); } else user.setDbValidation(true);
	 * if(u!=null && u.getIsuserlocked().equalsIgnoreCase("true")) {
	 * user.setAccountLocked(true); } else { user.setAccountLocked(false); }
	 * if(u!=null && u.getValidationMechanism() != null)
	 * user.setValidationMechanism(u.getValidationMechanism());
	 * FLogger.info("securityLogger",
	 * "MyDBAdaptor","getUser(String p_StrUserName)","Role Derived for user "+
	 * user.getUserName() +" from Db  : "+user.getRoles()); } catch(Exception e)
	 * { e.printStackTrace(); } return user; } catch(Exception e) {
	 * e.printStackTrace(); } finally { if(session!=null && session.isOpen()) {
	 * session.flush(); session.clear(); FLogger.info("securityLogger",
	 * "MyDBAdaptor", "getUser(String p_StrUserName)", "closing session");
	 * session.close(); } } return user; }
	 */

	@Override
	public void LastLogin(String p_StrUserName) throws NamingException {
		// TODO Auto-generated method stub

		/*
		 * Authentication auth = new Authentication(); Session sess =
		 * getSession(false); auth =
		 * (Authentication)sess.get(Authentication.class, p_StrUserName);
		 * //auth.setLstLgnAttmpt(new Date()); sess.save(auth); sess.flush();
		 */
	}

	@Override
	public void updateLastPasswordChangeDate(String p_StrUserName) throws NamingException {
		// // TODO Auto-generated method stub
		// LoginProcessDAOImplementation dao = new
		// LoginProcessDAOImplementation(
		// "security");
		// // dao.updateLastChangePasswordDate(p_StrUserName );
	}

	@Override
	public boolean isUserActive(String p_paramUserName, String p_paramUserPwd) throws Exception {

		/*
		 * LoginProcessDAOImplementation dao = new
		 * LoginProcessDAOImplementation( "security");
		 */
		FLogger.info("securityLogger", "MyDBAdaptor", "getUser(String p_StrUserName)", "isUserActive has been called");
		IPruUserDetailDAOHibernateImpl ipruUserDao = new IPruUserDetailDAOHibernateImpl("GroupSecurity");
		GroupsUserAuthInfo user = ipruUserDao.getUser(p_paramUserName, p_paramUserPwd);
		if (user != null) {
			return true;
		}
		else
			return false;
	}

	@Override
	public String getSecretQuestion(String p_StrUserName) throws Exception {

		// LoginProcessDAOImplementation dao = new
		// LoginProcessDAOImplementation(
		// "security");
		// return dao.getSecretQuestion(p_StrUserName);
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSecretAnswer(String p_StrUserName) throws Exception {
		// LoginProcessDAOImplementation dao = new
		// LoginProcessDAOImplementation(
		// "security");
		// return dao.getSecretAnswer(p_StrUserName);
		return null;
		// TODO Auto-generated method stub

	}

	@Override
	public String getDefaultPassword(String p_StrUserName) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void ActivateUser(String p_StrUserName, String p_StrActivationKey) throws Exception {

		// LoginProcessDAOImplementation dao = new
		// LoginProcessDAOImplementation(
		// "security");
		// dao.activateUser(p_StrUserName, p_StrActivationKey) ;//
		// addAuthenticationUserInfo(p_StrUserName,
		// p_StrActivationKey);//activateUser(p_StrUserName,p_StrActivationKey);//isValidAuthentication(p_StrUserName,
		// p_StrActivationKey);
	}

	@Override
	public void insertActivateUserData(String p_StrUserName, String p_StrActivationKey) throws NamingException {

		// LoginProcessDAOImplementation dao = new
		// LoginProcessDAOImplementation(
		// "security");
		// dao.addAuthenticationUserInfo(p_StrUserName,
		// p_StrActivationKey);//activateUser(p_StrUserName,p_StrActivationKey);//isValidAuthentication(p_StrUserName,
		// p_StrActivationKey);
		// TODO Auto-generated method stub
	}

	@Override
	public boolean checkSecretAnswer(String p_StrUserName) throws NamingException, Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void addUser(UserVO user) throws NamingException {
		// TODO Auto-generated method stub

	}

	/*
	 * public IUser getRequiredInfo(CsrPolicyDetailsVO obj) { return null; }
	 */

	@Override
	public IUser getUser(String arg0) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}
}
