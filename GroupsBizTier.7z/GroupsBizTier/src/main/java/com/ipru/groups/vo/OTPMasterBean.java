package com.ipru.groups.vo;

import java.io.Serializable;
/**
 * Master class which has other beans in it.
 * @author VivekGrewal554674(TCS)
 *
 */
public class OTPMasterBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private OTPNumberBean otpBean=null;
	private OTPNumberAuditTrailBean auditBean=null;
	private OTPNumberFunctionality otpFunc=null;
	private String otpEntered="";
	public String getOtpEntered() {
		return otpEntered;
	}
	public void setOtpEntered(String otpEntered) {
		this.otpEntered = otpEntered;
	}
	public OTPNumberBean getOtpBean() {
		return otpBean;
	}
	public void setOtpBean(OTPNumberBean otpBean) {
		this.otpBean = otpBean;
	}
	public OTPNumberAuditTrailBean getAuditBean() {
		return auditBean;
	}
	public void setAuditBean(OTPNumberAuditTrailBean auditBean) {
		this.auditBean = auditBean;
	}
	public OTPNumberFunctionality getOtpFunc() {
		return otpFunc;
	}
	public void setOtpFunc(OTPNumberFunctionality otpFunc) {
		this.otpFunc = otpFunc;
	}
}
