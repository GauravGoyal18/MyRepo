package com.ipru.groups.po;

import java.io.Serializable;

public class ContactabilityRequestPO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String emailId;
	private String mobileNo;
	private String property;
	private String countryName;


	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	
}
