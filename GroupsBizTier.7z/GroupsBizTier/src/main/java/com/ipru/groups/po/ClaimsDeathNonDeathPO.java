package com.ipru.groups.po;

import java.util.List;

public class ClaimsDeathNonDeathPO extends GroupsBasePo {

	private List<ClaimsRequestTransactionPO> deathList;
	private List<ClaimsRequestTransactionPO> nonDeathList;
	private String productType;

	public List<ClaimsRequestTransactionPO> getDeathList() {
		return deathList;
	}

	public void setDeathList(List<ClaimsRequestTransactionPO> deathList) {
		this.deathList = deathList;
	}

	public List<ClaimsRequestTransactionPO> getNonDeathList() {
		return nonDeathList;
	}

	public void setNonDeathList(List<ClaimsRequestTransactionPO> nonDeathList) {
		this.nonDeathList = nonDeathList;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

}
