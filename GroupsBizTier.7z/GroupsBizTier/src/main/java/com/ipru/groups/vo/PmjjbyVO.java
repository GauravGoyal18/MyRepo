package com.ipru.groups.vo;

public class PmjjbyVO extends GroupsBaseVO {

	private static final long serialVersionUID = 1L;

	private String renewalNo;
	private String masterPolicyNo;
	private String subPolicyNo;
	private String proposer;
	private String nameOfAssured;
	private String ageOfAssured;
	private String dobOfAssured;
	private String ageOfLifeAssured;
	private String memberIdNo;
	private String dateOfCOC;
	private String sumAssured;
	private String premium;
	private String uinNo;
	private String signedOnDate;
	private String productCode;
	private String policyIsSuredDate;
	private String schemeName;
	private String address;
	private String terminateDate;
	private String annualrenDate;
	private String premiumMode;
	private String applicationDT;
	private String folioNo;
	private String panNo;
	private String emailId;
	private String pmjjbyUId;
	private String nominee;
	private String mumbaiOnDt;
	private String bankAccNo;
	private String trantype;

	private long schTryCount;
	private String nomineeAge;
	private String nomineeRelation;
	
	private String appointeeName;

	public long getSchTryCount() {
		return schTryCount;
	}

	public void setSchTryCount(long schTryCount) {
		this.schTryCount = schTryCount;
	}

	public String getRenewalNo() {
		return renewalNo;
	}

	public void setRenewalNo(String renewalNo) {
		this.renewalNo = renewalNo;
	}

	public String getMasterPolicyNo() {
		return masterPolicyNo;
	}

	public void setMasterPolicyNo(String masterPolicyNo) {
		this.masterPolicyNo = masterPolicyNo;
	}

	public String getSubPolicyNo() {
		return subPolicyNo;
	}

	public void setSubPolicyNo(String subPolicyNo) {
		this.subPolicyNo = subPolicyNo;
	}

	public String getProposer() {
		return proposer;
	}

	public void setProposer(String proposer) {
		this.proposer = proposer;
	}

	public String getNameOfAssured() {
		return nameOfAssured;
	}

	public void setNameOfAssured(String nameOfAssured) {
		this.nameOfAssured = nameOfAssured;
	}

	public String getAgeOfAssured() {
		return ageOfAssured;
	}

	public void setAgeOfAssured(String ageOfAssured) {
		this.ageOfAssured = ageOfAssured;
	}

	public String getDobOfAssured() {
		return dobOfAssured;
	}

	public void setDobOfAssured(String dobOfAssured) {
		this.dobOfAssured = dobOfAssured;
	}

	public String getAgeOfLifeAssured() {
		return ageOfLifeAssured;
	}

	public void setAgeOfLifeAssured(String ageOfLifeAssured) {
		this.ageOfLifeAssured = ageOfLifeAssured;
	}

	public String getMemberIdNo() {
		return memberIdNo;
	}

	public void setMemberIdNo(String memberIdNo) {
		this.memberIdNo = memberIdNo;
	}

	public String getDateOfCOC() {
		return dateOfCOC;
	}

	public void setDateOfCOC(String dateOfCOC) {
		this.dateOfCOC = dateOfCOC;
	}

	public String getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}

	public String getPremium() {
		return premium;
	}

	public void setPremium(String premium) {
		this.premium = premium;
	}

	public String getUinNo() {
		return uinNo;
	}

	public void setUinNo(String uinNo) {
		this.uinNo = uinNo;
	}

	public String getSignedOnDate() {
		return signedOnDate;
	}

	public void setSignedOnDate(String signedOnDate) {
		this.signedOnDate = signedOnDate;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getPolicyIsSuredDate() {
		return policyIsSuredDate;
	}

	public void setPolicyIsSuredDate(String policyIsSuredDate) {
		this.policyIsSuredDate = policyIsSuredDate;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTerminateDate() {
		return terminateDate;
	}

	public void setTerminateDate(String terminateDate) {
		this.terminateDate = terminateDate;
	}

	public String getAnnualrenDate() {
		return annualrenDate;
	}

	public void setAnnualrenDate(String annualrenDate) {
		this.annualrenDate = annualrenDate;
	}

	public String getPremiumMode() {
		return premiumMode;
	}

	public void setPremiumMode(String premiumMode) {
		this.premiumMode = premiumMode;
	}

	public String getApplicationDT() {
		return applicationDT;
	}

	public void setApplicationDT(String applicationDT) {
		this.applicationDT = applicationDT;
	}

	public String getFolioNo() {
		return folioNo;
	}

	public void setFolioNo(String folioNo) {
		this.folioNo = folioNo;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPmjjbyUId() {
		return pmjjbyUId;
	}

	public void setPmjjbyUId(String pmjjbyUId) {
		this.pmjjbyUId = pmjjbyUId;
	}

	public String getNominee() {
		return nominee;
	}

	public void setNominee(String nominee) {
		this.nominee = nominee;
	}

	public String getMumbaiOnDt() {
		return mumbaiOnDt;
	}

	public void setMumbaiOnDt(String mumbaiOnDt) {
		this.mumbaiOnDt = mumbaiOnDt;
	}

	public String getBankAccNo() {
		return bankAccNo;
	}

	public void setBankAccNo(String bankAccNo) {
		this.bankAccNo = bankAccNo;
	}

	public String getTrantype() {
		return trantype;
	}

	public void setTrantype(String trantype) {
		this.trantype = trantype;
	}

	public String getNomineeAge() {
		return nomineeAge;
	}

	public void setNomineeAge(String nomineeAge) {
		this.nomineeAge = nomineeAge;
	}

	public String getNomineeRelation() {
		return nomineeRelation;
	}

	public void setNomineeRelation(String nomineeRelation) {
		this.nomineeRelation = nomineeRelation;
	}

	public String getAppointeeName() {
		return appointeeName;
	}

	public void setAppointeeName(String appointeeName) {
		this.appointeeName = appointeeName;
	}
	

}
