package com.ipru.groups.vo;

import java.util.List;

public class DashboardAlertJson {

	private List<AlertsAndNotificationVO> alertList;

	public List<AlertsAndNotificationVO> getAlertList() {
		return alertList;
	}

	public void setAlertList(List<AlertsAndNotificationVO> alertList) {
		this.alertList = alertList;
	}

	@Override
	public String toString() {
		return "DashboardAlertJson [alertList=" + alertList + "]";
	}
	
}
