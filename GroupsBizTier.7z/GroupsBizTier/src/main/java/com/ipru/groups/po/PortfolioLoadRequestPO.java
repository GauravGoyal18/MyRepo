package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

import com.ipru.groups.vo.FieldAccessMappingVO;

public class PortfolioLoadRequestPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNo;
	private String clientId;
	private String role;
	private String webClientId;
	private String screenName;
	private String empId;
	private String productType;

	private List<FieldAccessMappingPO> fieldAccessMappingList;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getWebClientId() {
		return webClientId;
	}

	public void setWebClientId(String webClientId) {
		this.webClientId = webClientId;
	}

	public List<FieldAccessMappingPO> getFieldAccessMappingList() {
		return fieldAccessMappingList;
	}

	public void setFieldAccessMappingList(
			List<FieldAccessMappingPO> fieldAccessMappingList) {
		this.fieldAccessMappingList = fieldAccessMappingList;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	@Override
	public String toString() {
		return "PortfolioLoadRequestPO [policyNo=" + policyNo + ", clientId="
				+ clientId + ", role=" + role + ", webClientId=" + webClientId
				+ ", screenName=" + screenName + ", empId=" + empId
				+ ", productType=" + productType + ", fieldAccessMappingList="
				+ fieldAccessMappingList + "]";
	}

}
