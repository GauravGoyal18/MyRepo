package com.ipru.groups.po;


public class ClaimReqIBMredirectPO extends GroupsBasePo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long isClaimReq;
	private long isClaimAnnuityReq;

	public long getIsClaimReq() {
		return isClaimReq;
	}

	public void setIsClaimReq(long isClaimReq) {
		this.isClaimReq = isClaimReq;
	}

	public long getIsClaimAnnuityReq() {
		return isClaimAnnuityReq;
	}

	public void setIsClaimAnnuityReq(long isClaimAnnuityReq) {
		this.isClaimAnnuityReq = isClaimAnnuityReq;
	}

	@Override
	public String toString() {
		return "ClaimReqIBMredirectPO [isClaimReq=" + isClaimReq + ", isClaimAnnuityReq=" + isClaimAnnuityReq + "]";
	}

}
