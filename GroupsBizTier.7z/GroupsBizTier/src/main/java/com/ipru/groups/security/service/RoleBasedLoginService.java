package com.ipru.groups.security.service;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.ipru.groups.security.dao.BusinessParametersListDAOHibernateImpl;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.utilities.SessionKeyConstants;
import com.ipru.groups.vo.BrokerDashboardDetailsVO;
import com.ipru.groups.vo.BrokerDashboardLoadRequestVO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.groups.widget.service.BrokerDashboardService;
import com.ipru.security.dao.RoleBasedLoginDAO;
import com.ipru.security.user.IPruUser;
import com.ipru.security.user.PolicyDetails;
import com.tcs.logger.FLogger;
import com.tcs.service.BaseService;

public class RoleBasedLoginService extends BaseService {
	
	@SuppressWarnings("static-access")
	public IPruUser getRoleScreenMapping(IPruUser userVO) throws Throwable {
		FLogger.info("securityLogger", "RoleBasedLoginService", "getRoleScreenMapping(IPruUser userVO)", "getRoleScreenMapping calleddd");
		String roles = userVO.getRoles();
		String policyNo = userVO.getPolicyNo();
		HashMap<String, String> accessMatrix = null;
		String landingPage = "";
		String screensDisplayed = null;
		List<String> screenAccessDeniedList = null;
		List<RoleScreenAccessMappingVO> lstRoleScreenAccess = null;
		List<FieldAccessMappingVO> fieldAccessMappingVoList =  null;

		try {
			
		  

			if (roles != null) {
				RoleBasedLoginDAO roleDAO = new RoleBasedLoginDAO("GroupSecurity");
				roleDAO.saveLoginHistoryDetails(userVO, true);  
				Properties prop = new Properties();
				try {

					if (MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES != null) {
						prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
					}
					else {
						FileInputStream fis = null;
						try {
							fis = new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
							prop.load(fis);
						}
						catch (Exception e) {
							FLogger.error("securityLoggerError", "RoleBasedLoginService", "getRoleScreenMapping(IPruUser userVO)", "Exception occured while loading prop " + e.getMessage());
						}
						finally {
							if (fis != null)
								fis.close();
							fis = null;
						}

					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				String loginWithEmailMobile = userVO.getLoginThroughUserIdEmailMobile();
				
				if (loginWithEmailMobile!=null && loginWithEmailMobile.equals(prop.getProperty("GRP_BROKERSOURCE"))) {  
					try {
						lstRoleScreenAccess = new AuthorizationService().getAccessMatrixForAccessGroupSSO(roles);
						userVO.setLstRoleScreenAccessMapping(lstRoleScreenAccess);
						accessMatrix = (HashMap<String, String>) prepareAccessMatrix(lstRoleScreenAccess);
						userVO.setAccessMatrix(accessMatrix);
						screenAccessDeniedList = new ArrayList<String>();

						for (Entry<String, String> pairs : accessMatrix.entrySet()) {
							if (pairs.getValue().toString().contains("R")) {
								if (screensDisplayed != null)
									screensDisplayed = screensDisplayed + "~" + pairs.getKey();
								else
									screensDisplayed = pairs.getKey();

							}
							else {
								   screenAccessDeniedList.add(pairs.getKey());
							   }
								if (pairs.getValue().toString().contains("L")) {
									landingPage = pairs.getKey();
								}

						}
					}
					catch (Throwable e) {
						e.printStackTrace();
						userVO.setErrorCode("1003");
						FLogger.info("securityLogger", "RoleBasedLoginService", "getStoredProcDetails(String p_StrUserName, String p_StrPassword)", "Exception occured in getScreenMatrix" + roles
								+ "-" + userVO.getErrorCode());
					}
					userVO.setScreenDisplayed(screensDisplayed);
					userVO.setLandingPage(landingPage);
					userVO.setScreenAccessDeniedList(screenAccessDeniedList);
					
					fieldAccessMappingVoList = this.getFieldAccessMappingList(userVO);
					
					userVO.setFieldAccessMappingVoList(fieldAccessMappingVoList);
					
				} else if (loginWithEmailMobile!=null && loginWithEmailMobile.equals(prop.getProperty("LOGIN_USERID"))) {
					try {
						lstRoleScreenAccess = new AuthorizationService().getAccessMatrixForAccessGroup(roles, policyNo);
						//lstRoleScreenAccess = new AuthorizationService().getAccessMatrixForAccessGroupSSO(roles);
						userVO.setLstRoleScreenAccessMapping(lstRoleScreenAccess);
						accessMatrix = (HashMap<String, String>) prepareAccessMatrix(lstRoleScreenAccess);
						userVO.setAccessMatrix(accessMatrix);
						screenAccessDeniedList = new ArrayList<String>();

						for (Entry<String, String> pairs : accessMatrix.entrySet()) {
							if (pairs.getValue().toString().contains("R")) {
								if (screensDisplayed != null)
									screensDisplayed = screensDisplayed + "~" + pairs.getKey();
								else
									screensDisplayed = pairs.getKey();

							}
							else {
								screenAccessDeniedList.add(pairs.getKey());
							}
							if (pairs.getValue().toString().contains("L")) {
								landingPage = pairs.getKey();
							}

						}
					}
					catch (Throwable e) {
						e.printStackTrace();
						userVO.setErrorCode("1003");
						FLogger.info("securityLogger", "RoleBasedLoginService", "getStoredProcDetails(String p_StrUserName, String p_StrPassword)", "Exception occured in getScreenMatrix" + roles
								+ "-" + userVO.getErrorCode());
					}
					userVO.setScreenDisplayed(screensDisplayed);
					userVO.setLandingPage(landingPage);
					userVO.setScreenAccessDeniedList(screenAccessDeniedList);
					
					fieldAccessMappingVoList = this.getFieldAccessMappingList(userVO);
					
					userVO.setFieldAccessMappingVoList(fieldAccessMappingVoList);
					
				} else if(loginWithEmailMobile!=null && loginWithEmailMobile.equals(prop.getProperty("LOGIN_EMAIL_MOBILE"))) {
					BusinessParametersListDAOHibernateImpl daoHibernateImpl = new BusinessParametersListDAOHibernateImpl("GroupSecurity");
					
					userVO = new AuthorizationService().getAccessMatrixForAccessGroup(userVO);
					Map<String, PolicyDetails> policyDetailMap = userVO.getPolicyDetailMap();
					Iterator it = policyDetailMap.entrySet().iterator();
					while (it.hasNext()) {
						Map.Entry pair = (Map.Entry)it.next();
				        PolicyDetails policyDetails = (PolicyDetails) pair.getValue();
				        
				        fieldAccessMappingVoList = daoHibernateImpl.getFieldAccessMappingList(policyDetails.getRole());
				        policyDetails.setFieldAccessMappingVoList(fieldAccessMappingVoList);
				        
				        pair.setValue(policyDetails);
					}
					
					userVO.setPolicyDetailMap(policyDetailMap);
					
				}
			}
		}
		   
		
		catch (Exception e) {
			e.printStackTrace();
			FLogger.info("securityLogger", "RoleBasedLoginService", "getStoredProcDetails(String p_StrUserName, String p_StrPassword)", "Exception occured in getStoredProcDetails where role is::"
					+ roles);
		}
		finally {

		}
		return userVO;
	}

	public static List<FieldAccessMappingVO> getFieldAccessMappingList(IPruUser userVO) {
		FLogger.info("securityLogger", "RoleBasedLoginService", "getFieldAccessMappingList", "Method start for returning access mapping list from back end");

		String roles = userVO.getRoles();
		// ArrayList<List> finalList = new ArrayList<List>();
		List<FieldAccessMappingVO> fieldAccessMappingVoList = null;
		BusinessParametersListDAOHibernateImpl daoHibernateImpl = new BusinessParametersListDAOHibernateImpl("GroupSecurity");

		fieldAccessMappingVoList = daoHibernateImpl.getFieldAccessMappingList(roles);

		FLogger.info("securityLogger", "RoleBasedLoginService", "getFieldAccessMappingList", "Method end for returning access mapping list from back end");

		return fieldAccessMappingVoList;
	}

	public Map<String, String> prepareAccessMatrix(List<RoleScreenAccessMappingVO> lstRoleScreenAccess) {

		HashMap<String, String> accessMap = new HashMap<String, String>();
		for (RoleScreenAccessMappingVO roleScreenAccessMappingVO : lstRoleScreenAccess) {
			StringBuilder crudStr = new StringBuilder();
			if (StringUtils.equalsIgnoreCase(roleScreenAccessMappingVO.getHasCreate(), "yes")) {
				crudStr.append("C");
			}
			else {
				crudStr.append("*");
			}
			if (StringUtils.equalsIgnoreCase(roleScreenAccessMappingVO.getHasRead(), "yes")) {
				crudStr.append("R");
			}
			else {
				crudStr.append("*");
			}
			if (StringUtils.equalsIgnoreCase(roleScreenAccessMappingVO.getHasUpdate(), "yes")) {
				crudStr.append("U");
			}
			else {
				crudStr.append("*");
			}
			if (StringUtils.equalsIgnoreCase(roleScreenAccessMappingVO.getHasDelete(), "yes")) {
				crudStr.append("D");
			}
			else {
				crudStr.append("*");
			}
			if (StringUtils.equalsIgnoreCase(roleScreenAccessMappingVO.getRoleLandingPage(), "yes")) {
				crudStr.append("L");
			}
			else {
				crudStr.append("*");
			}
			accessMap.put(roleScreenAccessMappingVO.getScreenCode(), crudStr.toString());
			crudStr.setLength(0);
		}
		return accessMap;
	}
    }
