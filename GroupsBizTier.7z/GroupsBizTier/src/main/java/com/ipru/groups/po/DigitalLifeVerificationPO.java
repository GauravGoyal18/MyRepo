package com.ipru.groups.po;

import java.io.Serializable;
import java.util.List;

import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.UploadFileVO;

public class DigitalLifeVerificationPO implements Serializable{

	
	private static final long serialVersionUID = 1L;
	
	private long requestId;
	private String contractid;
	private String firstname;
	private String policyid;
	private String masterPolNo;
	private String trustname;
	private String dateofbirth;
	private String panno;
	private long phonemobile;
	private String createdDate;
	private FunctionalityMasterPO functionality;
	private List<UploadFilePO> uploadFileList;
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getContractid() {
		return contractid;
	}
	public void setContractid(String contractid) {
		this.contractid = contractid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getPolicyid() {
		return policyid;
	}
	public void setPolicyid(String policyid) {
		this.policyid = policyid;
	}
	public String getMasterPolNo() {
		return masterPolNo;
	}
	public void setMasterPolNo(String masterPolNo) {
		this.masterPolNo = masterPolNo;
	}
	public String getTrustname() {
		return trustname;
	}
	public void setTrustname(String trustname) {
		this.trustname = trustname;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getPanno() {
		return panno;
	}
	public void setPanno(String panno) {
		this.panno = panno;
	}
	public long getPhonemobile() {
		return phonemobile;
	}
	public void setPhonemobile(long phonemobile) {
		this.phonemobile = phonemobile;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
	public FunctionalityMasterPO getFunctionality() {
		return functionality;
	}
	public void setFunctionality(FunctionalityMasterPO functionality) {
		this.functionality = functionality;
	}
	public List<UploadFilePO> getUploadFileList() {
		return uploadFileList;
	}
	public void setUploadFileList(List<UploadFilePO> uploadFileList) {
		this.uploadFileList = uploadFileList;
	}
	@Override
	public String toString() {
		return "DigitalLifeVerificationPO [requestId=" + requestId
				+ ", contractid=" + contractid + ", firstname=" + firstname
				+ ", policyid=" + policyid + ", masterPolNo=" + masterPolNo
				+ ", trustname=" + trustname + ", dateofbirth=" + dateofbirth
				+ ", panno=" + panno + ", phonemobile=" + phonemobile
				+ ", createdDate=" + createdDate + ", functionality="
				+ functionality + ", uploadFileList=" + uploadFileList + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((contractid == null) ? 0 : contractid.hashCode());
		result = prime * result
				+ ((createdDate == null) ? 0 : createdDate.hashCode());
		result = prime * result
				+ ((dateofbirth == null) ? 0 : dateofbirth.hashCode());
		result = prime * result
				+ ((firstname == null) ? 0 : firstname.hashCode());
		result = prime * result
				+ ((functionality == null) ? 0 : functionality.hashCode());
		result = prime * result
				+ ((masterPolNo == null) ? 0 : masterPolNo.hashCode());
		result = prime * result + ((panno == null) ? 0 : panno.hashCode());
		result = prime * result + (int) (phonemobile ^ (phonemobile >>> 32));
		result = prime * result
				+ ((policyid == null) ? 0 : policyid.hashCode());
		result = prime * result + (int) (requestId ^ (requestId >>> 32));
		result = prime * result
				+ ((trustname == null) ? 0 : trustname.hashCode());
		result = prime * result
				+ ((uploadFileList == null) ? 0 : uploadFileList.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DigitalLifeVerificationPO other = (DigitalLifeVerificationPO) obj;
		if (contractid == null) {
			if (other.contractid != null)
				return false;
		} else if (!contractid.equals(other.contractid))
			return false;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		if (dateofbirth == null) {
			if (other.dateofbirth != null)
				return false;
		} else if (!dateofbirth.equals(other.dateofbirth))
			return false;
		if (firstname == null) {
			if (other.firstname != null)
				return false;
		} else if (!firstname.equals(other.firstname))
			return false;
		if (functionality == null) {
			if (other.functionality != null)
				return false;
		} else if (!functionality.equals(other.functionality))
			return false;
		if (masterPolNo == null) {
			if (other.masterPolNo != null)
				return false;
		} else if (!masterPolNo.equals(other.masterPolNo))
			return false;
		if (panno == null) {
			if (other.panno != null)
				return false;
		} else if (!panno.equals(other.panno))
			return false;
		if (phonemobile != other.phonemobile)
			return false;
		if (policyid == null) {
			if (other.policyid != null)
				return false;
		} else if (!policyid.equals(other.policyid))
			return false;
		if (requestId != other.requestId)
			return false;
		if (trustname == null) {
			if (other.trustname != null)
				return false;
		} else if (!trustname.equals(other.trustname))
			return false;
		if (uploadFileList == null) {
			if (other.uploadFileList != null)
				return false;
		} else if (!uploadFileList.equals(other.uploadFileList))
			return false;
		return true;
	}
	
	
	
	
}
