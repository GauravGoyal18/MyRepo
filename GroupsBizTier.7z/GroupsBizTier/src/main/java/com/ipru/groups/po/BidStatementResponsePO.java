package com.ipru.groups.po;


public class BidStatementResponsePO extends GroupsBasePo{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private String amountCr;
	private String amountDr;
	private String balance;
	private String date;
	private String particulars;
	public String getAmountCr() {
		return amountCr;
	}
	public void setAmountCr(String amountCr) {
		this.amountCr = amountCr;
	}
	public String getAmountDr() {
		return amountDr;
	}
	public void setAmountDr(String amountDr) {
		this.amountDr = amountDr;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getParticulars() {
		return particulars;
	}
	public void setParticulars(String particulars) {
		this.particulars = particulars;
	}
	@Override
	public String toString() {
		return "BidStatementResponsePO [amountCr=" + amountCr + ", amountDr="
				+ amountDr + ", balance=" + balance + ", date=" + date
				+ ", particulars=" + particulars + "]";
	}
	
	
	
}
