package com.ipru.groups.vo;

import java.util.List;

import com.tcs.vo.BaseVO;

public class GstDropDownVO extends BaseVO {

	private List<String> policyList;
	private String policyNo;

	public List<String> getPolicyList() {
		return policyList;
	}

	public void setPolicyList(List<String> policyList) {
		this.policyList = policyList;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

}
