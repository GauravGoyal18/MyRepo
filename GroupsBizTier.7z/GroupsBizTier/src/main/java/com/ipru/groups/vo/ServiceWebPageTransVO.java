package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class ServiceWebPageTransVO extends BaseVO {

	private static final long serialVersionUID = 1L;
	private long requestId;
	private String clientId;
	private String policyNo;
	private String appNo;
	private String callDesc;
	private long menuId;
	private String callCategory;
	private String masterCallType;
	private String callType;
	private String subType;
	private String assigneeName;
	private String assigneeGroup;
	private String assigneeSubGroup;
	private Date requestedDateTime;

	public ServiceWebPageTransVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceWebPageTransVO(long requestId, String clientId, String policyNo, String appNo, String callDesc, long menuId, String callCategory, String masterCallType, String callType, String subType, String assigneeName, String assigneeGroup, String assigneeSubGroup, Date requestedDateTime) {
		super();
		this.requestId = requestId;
		this.clientId = clientId;
		this.policyNo = policyNo;
		this.appNo = appNo;
		this.callDesc = callDesc;
		this.menuId = menuId;
		this.callCategory = callCategory;
		this.masterCallType = masterCallType;
		this.callType = callType;
		this.subType = subType;
		this.assigneeName = assigneeName;
		this.assigneeGroup = assigneeGroup;
		this.assigneeSubGroup = assigneeSubGroup;
		this.requestedDateTime = requestedDateTime;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getAppNo() {
		return appNo;
	}

	public void setAppNo(String appNo) {
		this.appNo = appNo;
	}

	public String getCallDesc() {
		return callDesc;
	}

	public void setCallDesc(String callDesc) {
		this.callDesc = callDesc;
	}

	public long getMenuId() {
		return menuId;
	}

	public void setMenuId(long menuId) {
		this.menuId = menuId;
	}

	public String getCallCategory() {
		return callCategory;
	}

	public void setCallCategory(String callCategory) {
		this.callCategory = callCategory;
	}

	public String getMasterCallType() {
		return masterCallType;
	}

	public void setMasterCallType(String masterCallType) {
		this.masterCallType = masterCallType;
	}

	public String getCallType() {
		return callType;
	}

	public void setCallType(String callType) {
		this.callType = callType;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getAssigneeName() {
		return assigneeName;
	}

	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	public String getAssigneeGroup() {
		return assigneeGroup;
	}

	public void setAssigneeGroup(String assigneeGroup) {
		this.assigneeGroup = assigneeGroup;
	}

	public String getAssigneeSubGroup() {
		return assigneeSubGroup;
	}

	public void setAssigneeSubGroup(String assigneeSubGroup) {
		this.assigneeSubGroup = assigneeSubGroup;
	}

	public Date getRequestedDateTime() {
		return requestedDateTime;
	}

	public void setRequestedDateTime(Date requestedDateTime) {
		this.requestedDateTime = requestedDateTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "ServiceWebPageTransVO [requestId=" + requestId + ", clientId=" + clientId + ", policyNo=" + policyNo + ", appNo=" + appNo + ", callDesc=" + callDesc + ", menuId=" + menuId
				+ ", callCategory=" + callCategory + ", masterCallType=" + masterCallType + ", callType=" + callType + ", subType=" + subType + ", assigneeName=" + assigneeName + ", assigneeGroup="
				+ assigneeGroup + ", assigneeSubGroup=" + assigneeSubGroup + ", requestedDateTime=" + requestedDateTime + "]";
	}

}
