package com.ipru.groups.pdfgen;

import java.io.Serializable;
import java.util.Map;

import com.ipru.groups.utilities.GroupsJsonUtils;
import com.ipru.groups.widget.service.GroupsBaseService;
import com.tcs.pdfgenerator.core.service.ITemplateCoreService;

public class TemplateCoreServiceImpl extends GroupsBaseService implements ITemplateCoreService {

	@Override
	public Map<String, Object> getTemplateDataModel(
			Serializable paramSerializable) throws Exception {
		String json = getGsonSingleton().toJson(paramSerializable);
		return GroupsJsonUtils.getInstance().jsonToMap(GroupsJsonUtils.getInstance().getJsonObject(json));
	}

}
