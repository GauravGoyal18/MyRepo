package com.ipru.groups.vo;

import java.util.Date;

import com.tcs.vo.BaseVO;

public class ClaimsBeneficiaryVO extends BaseVO {

	private static final long serialVersionUID = 1L;
	private long requestId;
	private String clientId;
	private String modelName;
	private String fieldName;
	private String newValue;
	private Date currentDate;
	private String category;
	private String fieldCode;
	private String fieldGroupCode;
	private long tranctionId;
	private String beneficiaryPos;
	private ClaimsRequestTransactionVO claimsRequestTransactionVO;

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	public Date getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getFieldCode() {
		return fieldCode;
	}

	public void setFieldCode(String fieldCode) {
		this.fieldCode = fieldCode;
	}

	public String getFieldGroupCode() {
		return fieldGroupCode;
	}

	public void setFieldGroupCode(String fieldGroupCode) {
		this.fieldGroupCode = fieldGroupCode;
	}

	public long getTranctionId() {
		return tranctionId;
	}

	public void setTranctionId(long tranctionId) {
		this.tranctionId = tranctionId;
	}

	public String getBeneficiaryPos() {
		return beneficiaryPos;
	}

	public void setBeneficiaryPos(String beneficiaryPos) {
		this.beneficiaryPos = beneficiaryPos;
	}

	public ClaimsRequestTransactionVO getClaimsRequestTransactionVO() {
		return claimsRequestTransactionVO;
	}

	public void setClaimsRequestTransactionVO(ClaimsRequestTransactionVO claimsRequestTransactionVO) {
		this.claimsRequestTransactionVO = claimsRequestTransactionVO;
	}

	@Override
	public String toString() {
		return "ClaimsBeneficiaryVO [requestId=" + requestId + ", clientId=" + clientId + ", modelName=" + modelName + ", fieldName=" + fieldName + ", newValue=" + newValue + ", currentDate="
				+ currentDate + ", category=" + category + ", fieldCode=" + fieldCode + ", fieldGroupCode=" + fieldGroupCode + ", tranctionId=" + tranctionId + ", beneficiaryPos=" + beneficiaryPos
				+ ", claimsRequestTransactionVO=" + claimsRequestTransactionVO + "]";
	}

}
