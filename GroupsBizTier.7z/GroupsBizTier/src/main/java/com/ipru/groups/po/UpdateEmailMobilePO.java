package com.ipru.groups.po;

import java.io.Serializable;

public class UpdateEmailMobilePO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String emailId;
	private String mobileNo;
	private String firstName;
	private String lastName;
	private String countryName;
	private String webClientId;

	

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getWebClientId() {
		return webClientId;
	}

	public void setWebClientId(String webClientId) {
		this.webClientId = webClientId;
	}

	@Override
	public String toString() {
		return "UpdateEmailMobilePO [emailId=" + emailId + ", mobileNo=" + mobileNo + ", firstName=" + firstName + ", lastName=" + lastName + ", countryName=" + countryName + ", webClientId="
				+ webClientId + "]";
	}

	

	
	
	
}
