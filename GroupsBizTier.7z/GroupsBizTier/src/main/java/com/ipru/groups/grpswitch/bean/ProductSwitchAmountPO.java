package com.ipru.groups.grpswitch.bean;

import com.ipru.groups.po.GroupsBasePo;
import com.tcs.vo.BaseVO;

public class ProductSwitchAmountPO extends GroupsBasePo  {

	private static final long serialVersionUID = 1L;
	private Long id;
	private String productCode;
	private String minSwitchAmount;
	private String maxSwitchAmount;
	

	public ProductSwitchAmountPO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getProductCode() {
		return productCode;
	}


	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}


	public String getMinSwitchAmount() {
		return minSwitchAmount;
	}


	public void setMinSwitchAmount(String minSwitchAmount) {
		this.minSwitchAmount = minSwitchAmount;
	}


	public String getMaxSwitchAmount() {
		return maxSwitchAmount;
	}


	public void setMaxSwitchAmount(String maxSwitchAmount) {
		this.maxSwitchAmount = maxSwitchAmount;
	}



	
}
