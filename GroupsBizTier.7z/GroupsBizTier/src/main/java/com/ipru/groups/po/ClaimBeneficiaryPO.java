package com.ipru.groups.po;

import java.io.Serializable;

public class ClaimBeneficiaryPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String beneficiaryPos;
	private String fieldName;
	private String newValue;

	public String getBeneficiaryPos() {
		return beneficiaryPos;
	}

	public void setBeneficiaryPos(String beneficiaryPos) {
		this.beneficiaryPos = beneficiaryPos;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	@Override
	public String toString() {
		return "ClaimBeneficiaryPO [beneficiaryPos=" + beneficiaryPos + ", fieldName=" + fieldName + ", newValue=" + newValue + "]";
	}

}
