package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class MemberFundDataRequestVO extends BaseVO {
	private String policyNo;
	private String role;
	private MemberDataTrustVO selectedMember;

	public MemberFundDataRequestVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberFundDataRequestVO(String policyNo, String role, MemberDataTrustVO selectedMember) {
		super();
		this.policyNo = policyNo;
		this.role = role;
		this.selectedMember = selectedMember;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public MemberDataTrustVO getSelectedMember() {
		return selectedMember;
	}

	public void setSelectedMember(MemberDataTrustVO selectedMember) {
		this.selectedMember = selectedMember;
	}

	@Override
	public String toString() {
		return "MemberFundDataRequestVO [policyNo=" + policyNo + ", role=" + role + ", selectedMember=" + selectedMember + "]";
	}

}
