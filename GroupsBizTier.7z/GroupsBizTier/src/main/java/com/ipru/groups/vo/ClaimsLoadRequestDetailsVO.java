package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.ipru.groups.po.RoleScreenAccessMappingPO;

public class ClaimsLoadRequestDetailsVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*private PolicyDetailsPO policyDetails;*/
	private List<RoleScreenAccessMappingPO> accessMappingList;
	private Map<String, FieldAccessMappingVO> fieldAccessMappingMap;
	
	private List<ClaimsSubmitVO> claimsVOList;
	
	private List<BeneficiaryVO> beneficiaryVOList;


	public ClaimsLoadRequestDetailsVO() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Map<String, FieldAccessMappingVO> getFieldAccessMappingMap() {
		return fieldAccessMappingMap;
	}



	public void setFieldAccessMappingMap(
			Map<String, FieldAccessMappingVO> fieldAccessMappingMap) {
		this.fieldAccessMappingMap = fieldAccessMappingMap;
	}



	public void setAccessMappingList(
			List<RoleScreenAccessMappingPO> accessMappingList) {
		this.accessMappingList = accessMappingList;
	}



	public List<RoleScreenAccessMappingPO> getAccessMappingList() {
		return accessMappingList;
	}


	public List<ClaimsSubmitVO> getClaimsVOList() {
		return claimsVOList;
	}



	public void setClaimsVOList(List<ClaimsSubmitVO> claimsVOList) {
		this.claimsVOList = claimsVOList;
	}



	public List<BeneficiaryVO> getBeneficiaryVOList() {
		return beneficiaryVOList;
	}



	public void setBeneficiaryVOList(List<BeneficiaryVO> beneficiaryVOList) {
		this.beneficiaryVOList = beneficiaryVOList;
	}



	@Override
	public String toString() {
		return "ClaimsLoadRequestDetailsVO [accessMappingList=" + accessMappingList + ", fieldAccessMappingMap=" + fieldAccessMappingMap + ", claimsVOList=" + claimsVOList + ", beneficiaryVOList="
				+ beneficiaryVOList + "]";
	}





}
