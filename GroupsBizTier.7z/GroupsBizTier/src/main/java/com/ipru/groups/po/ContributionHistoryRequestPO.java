package com.ipru.groups.po;

import com.tcs.web.po.BasePO;

public class ContributionHistoryRequestPO extends BasePO {
	
	
	private String policyNumber;
	private String clientId;
	private String memberEmpId;
	private String role;
	
	
	
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	public String getMemberEmpId() {
		return memberEmpId;
	}
	
	public void setMemberEmpId(String memberEmpId) {
		this.memberEmpId = memberEmpId;
	}
	@Override
	public String toString() {
		return "ContributionHistoryRequestPO [policyNumber=" + policyNumber
				+ ", clientId=" + clientId + ", memberEmpId=" + memberEmpId
				+ ", role=" + role + "]";
	}
	
	
	

}
