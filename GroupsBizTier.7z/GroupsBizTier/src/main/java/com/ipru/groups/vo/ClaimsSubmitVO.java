package com.ipru.groups.vo;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ipru.groups.po.BeneficiaryPO;
import com.ipru.groups.po.UploadFilePO;
import com.tcs.web.po.BasePO;

public class ClaimsSubmitVO extends BasePO{

	
	private static final long serialVersionUID = 1L;

	private Long claimId;
	private String employeeId;
	private String employeeName;
	private String eventDate;
	private String intimationDate;
	private String cause;
	private String pan;
	
	private String mobileNumber;
	private String commutation;
	private String annuity;
	private String gratuityApplicable;
	private String employeeEmailId_1;
	private String employeeEmailId_2;
	
	private String status;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;


	private List<UploadFilePO> uploadFileList;

	private List<BeneficiaryPO> beneficiary;
	//private Map<String,BeneficiaryPO> beneficiary = new HashMap<String, BeneficiaryPO>();

	private Set<BeneficiaryPO> beneficiarySet =new HashSet<BeneficiaryPO>(0);

	public synchronized Long getClaimId() {
		return claimId;
	}

	public synchronized void setClaimId(Long claimId) {
		this.claimId = claimId;
	}

	public synchronized String getEmployeeId() {
		return employeeId;
	}

	public synchronized void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public synchronized String getEmployeeName() {
		return employeeName;
	}

	public synchronized void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public synchronized String getEventDate() {
		return eventDate;
	}

	public synchronized void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public synchronized String getIntimationDate() {
		return intimationDate;
	}

	public synchronized void setIntimationDate(String intimationDate) {
		this.intimationDate = intimationDate;
	}

	public synchronized String getCause() {
		return cause;
	}

	public synchronized void setCause(String cause) {
		this.cause = cause;
	}

	public synchronized String getPan() {
		return pan;
	}

	public synchronized void setPan(String pan) {
		this.pan = pan;
	}

	public synchronized String getMobileNumber() {
		return mobileNumber;
	}

	public synchronized void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public synchronized String getCommutation() {
		return commutation;
	}

	public synchronized void setCommutation(String commutation) {
		this.commutation = commutation;
	}

	public synchronized String getAnnuity() {
		return annuity;
	}

	public synchronized void setAnnuity(String annuity) {
		this.annuity = annuity;
	}

	public synchronized String getGratuityApplicable() {
		return gratuityApplicable;
	}

	public synchronized void setGratuityApplicable(String gratuityApplicable) {
		this.gratuityApplicable = gratuityApplicable;
	}



	public String getEmployeeEmailId_1() {
		return employeeEmailId_1;
	}

	public void setEmployeeEmailId_1(String employeeEmailId_1) {
		this.employeeEmailId_1 = employeeEmailId_1;
	}

	public String getEmployeeEmailId_2() {
		return employeeEmailId_2;
	}

	public void setEmployeeEmailId_2(String employeeEmailId_2) {
		this.employeeEmailId_2 = employeeEmailId_2;
	}

	public synchronized String getStatus() {
		return status;
	}

	public synchronized void setStatus(String status) {
		this.status = status;
	}

	public synchronized String getCreatedBy() {
		return createdBy;
	}

	public synchronized void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public synchronized Date getCreatedDate() {
		return createdDate;
	}

	public synchronized void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public synchronized String getUpdatedBy() {
		return updatedBy;
	}

	public synchronized void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public synchronized Date getUpdatedDate() {
		return updatedDate;
	}

	public synchronized void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public synchronized List<UploadFilePO> getUploadFileList() {
		return uploadFileList;
	}

	public synchronized void setUploadFileList(List<UploadFilePO> uploadFileList) {
		this.uploadFileList = uploadFileList;
	}

	public synchronized List<BeneficiaryPO> getBeneficiary() {
		return beneficiary;
	}

	public synchronized void setBeneficiary(List<BeneficiaryPO> beneficiary) {
		this.beneficiary = beneficiary;
	}

	public synchronized Set<BeneficiaryPO> getBeneficiarySet() {
		return beneficiarySet;
	}

	public synchronized void setBeneficiarySet(Set<BeneficiaryPO> beneficiarySet) {
		this.beneficiarySet = beneficiarySet;
	}

	public static synchronized long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "ClaimsSubmitVO [claimId=" + claimId + ", employeeId=" + employeeId + ", employeeName=" + employeeName + ", eventDate=" + eventDate + ", intimationDate=" + intimationDate + ", cause="
				+ cause + ", pan=" + pan + ", mobileNumber=" + mobileNumber + ", commutation=" + commutation + ", annuity=" + annuity + ", gratuityApplicable=" + gratuityApplicable
				+ ", employeeEmailId_1=" + employeeEmailId_1 + ", employeeEmailId_2=" + employeeEmailId_2 + ", status=" + status + ", createdBy=" + createdBy + ", createdDate=" + createdDate
				+ ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + ", uploadFileList=" + uploadFileList + ", beneficiary=" + beneficiary + ", beneficiarySet=" + beneficiarySet + "]";
	}

	
		
}
