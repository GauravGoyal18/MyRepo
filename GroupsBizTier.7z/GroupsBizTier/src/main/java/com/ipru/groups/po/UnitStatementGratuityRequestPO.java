package com.ipru.groups.po;

public class UnitStatementGratuityRequestPO {
	
	private UnitStatementGratuityPO unitStatementGratuityPO;

	@Override
	public String toString() {
		return "UnitStatementGratuityRequestPO [unitStatementGratuityPO="
				+ unitStatementGratuityPO + "]";
	}

	public UnitStatementGratuityPO getUnitStatementGratuityPO() {
		return unitStatementGratuityPO;
	}

	public void setUnitStatementGratuityPO(
			UnitStatementGratuityPO unitStatementGratuityPO) {
		this.unitStatementGratuityPO = unitStatementGratuityPO;
	}
	

}
