package com.ipru.groups.po;

import java.math.BigDecimal;
import java.util.List;

import com.ipru.groups.vo.UnitStatementDataVO;
import com.tcs.web.po.BasePO;

public class UnitStatementPDFGeneratorVO extends BasePO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String trustName;
	private String memberName;
	private String policyNumber;
	private String policyType;
	private String startDate;
	private String endDate;
	private String closingBalance;
	private List<UnitStatementDataVO> unitStatementDataVOList;
	
	






	public String getStartDate() {
		return startDate;
	}


	public String getClosingBalance() {
		return closingBalance;
	}


	public void setClosingBalance(String closingBalance) {
		this.closingBalance = closingBalance;
	}


	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}


	public String getEndDate() {
		return endDate;
	}


	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getTrustName() {
		return trustName;
	}


	public void setTrustName(String trustName) {
		this.trustName = trustName;
	}


	public String getPolicyNumber() {
		return policyNumber;
	}


	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}


	public String getPolicyType() {
		return policyType;
	}


	public String getMemberName() {
		return memberName;
	}


	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}


	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}



	public List<UnitStatementDataVO> getUnitStatementDataVOList() {
		return unitStatementDataVOList;
	}


	public void setUnitStatementDataVOList(
			List<UnitStatementDataVO> unitStatementDataVOList) {
		this.unitStatementDataVOList = unitStatementDataVOList;
	}


	@Override
	public String toString() {
		return "UnitStatementPDFGeneratorPO [trustName=" + trustName
				+ ", memberName=" + memberName + ", policyNumber="
				+ policyNumber + ", policyType=" + policyType + ", startDate="
				+ startDate + ", endDate=" + endDate + ", closingBalance="
				+ closingBalance + ", unitStatementDataVOList="
				+ unitStatementDataVOList + "]";
	}
	
	

}
