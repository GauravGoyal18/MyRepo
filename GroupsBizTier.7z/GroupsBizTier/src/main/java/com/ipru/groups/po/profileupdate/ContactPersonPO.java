package com.ipru.groups.po.profileupdate;

import com.ipru.groups.po.GroupsBasePo;
import com.ipru.groups.utilities.GroupCommonUtils;

public class ContactPersonPO extends GroupsBasePo {
	
	
	private static final long serialVersionUID = 1L;
	
	private FieldMeta title;
	private FieldMeta firstName;
	private FieldMeta middleName;
	private FieldMeta lastName;
	private FieldMeta mobnumber;
	private FieldMeta emailId;
	private String prePopulateList;
	private String index;

	
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	
	public String getPrePopulateList() {
		return prePopulateList;
	}
	@Override
	public String toString() {
		return "ContactPersonPO [title=" + title + ", firstName=" + firstName
				+ ", middleName=" + middleName + ", lastName=" + lastName
				+ ", mobnumber=" + mobnumber + ", emailId=" + emailId
				+ ", prePopulateList=" + prePopulateList + ", index=" + index
				+ "]";
	}
	public void setPrePopulateList(String prePopulateList) {
		this.prePopulateList = prePopulateList;
	}
	public FieldMeta getTitle() {
		return title;
	}
	public void setTitle(FieldMeta title) {
		if(title!=null){
			title.setNewValue(GroupCommonUtils.getGenderBasedOnTitle(title.getNewValue()));
			title.setOldValue(GroupCommonUtils.getGenderBasedOnTitle(title.getOldValue()));
		}
		this.title = title;
	}
	public FieldMeta getFirstName() {
		return firstName;
	}
	public void setFirstName(FieldMeta firstName) {
		this.firstName = firstName;
	}
	public FieldMeta getMiddleName() {
		return middleName;
	}
	public void setMiddleName(FieldMeta middleName) {
		this.middleName = middleName;
	}
	public FieldMeta getLastName() {
		return lastName;
	}
	public void setLastName(FieldMeta lastName) {
		this.lastName = lastName;
	}
	public FieldMeta getMobnumber() {
		return mobnumber;
	}
	public void setMobnumber(FieldMeta mobnumber) {
		this.mobnumber = mobnumber;
	}
	public FieldMeta getEmailId() {
		return emailId;
	}
	public void setEmailId(FieldMeta emailId) {
		this.emailId = emailId;
	}
	
	
	

}
