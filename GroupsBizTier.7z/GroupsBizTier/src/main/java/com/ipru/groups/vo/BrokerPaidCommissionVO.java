package com.ipru.groups.vo;

public class BrokerPaidCommissionVO extends GroupsBaseVO{
	
	
	private static final long serialVersionUID = 1L;
	private String brokerCode;
	private String startDate;
	private String endDate;
	private String branchCode;
	private String nationalCode;
	
	
	
	public String getBrokerCode() {
		return brokerCode;
	}
	public void setBrokerCode(String brokerCode) {
		this.brokerCode = brokerCode;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getNationalCode() {
		return nationalCode;
	}
	public void setNationalCode(String nationalCode) {
		this.nationalCode = nationalCode;
	}
	@Override
	public String toString() {
		return "BrokerPaidCommissionVO [brokerCode=" + brokerCode + ", startDate=" + startDate + ", endDate=" + endDate + ", branchCode=" + branchCode + ", nationalCode=" + nationalCode + "]";
	}
	

}
