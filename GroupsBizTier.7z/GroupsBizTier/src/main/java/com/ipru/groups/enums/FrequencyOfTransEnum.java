package com.ipru.groups.enums;

public enum FrequencyOfTransEnum {

	Fortnightly,
	Monthly,
	Quarterly;
}
