package com.ipru.groups.vo;

import com.tcs.vo.BaseVO;

public class FunctionalityGroupMasterVO extends BaseVO {

	private static final long serialVersionUID = 1L;
	private long groupId;
	private String groupName;
	private String display;
	private int displayOrder;

	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getDisplay() {
		return display;
	}

	public void setDisplay(String display) {
		this.display = display;
	}

	public int getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}

	@Override
	public String toString() {
		return "FunctionalityGroupMasterVO [groupId=" + groupId + ", groupName=" + groupName + ", display=" + display + ", displayOrder=" + displayOrder + "]";
	}

}
