package com.ipru.groups.grpswitch.bean;

import java.io.Serializable;
import java.sql.Date;

import com.ipru.groups.vo.GroupsBaseVO;


public class NSEHolidaysVO extends GroupsBaseVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private long srNo;
	private Date holidayDate;
	private String holiday;
	private String holidayDesc;
	private String activeFlag;
	public long getSrNo() {
		return srNo;
	}
	public void setSrNo(long srNo) {
		this.srNo = srNo;
	}
	public Date getHolidayDate() {
		return holidayDate;
	}
	public void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}
	public String getHoliday() {
		return holiday;
	}
	public void setHoliday(String holiday) {
		this.holiday = holiday;
	}
	public String getHolidayDesc() {
		return holidayDesc;
	}
	public void setHolidayDesc(String holidayDesc) {
		this.holidayDesc = holidayDesc;
	}
	public String getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}

}
