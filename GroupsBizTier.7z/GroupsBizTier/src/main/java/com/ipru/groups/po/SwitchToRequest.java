package com.ipru.groups.po;

import java.util.Set;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ipru.groups.param.obj.ParamObj;

@XmlRootElement
public class SwitchToRequest {
	private ParamObj paramObj;
	private Set<String> fundCodes;

	@XmlElement
	public ParamObj getParamObj() {
		return paramObj;
	}

	public void setParamObj(ParamObj paramObj) {
		this.paramObj = paramObj;
	}

	public synchronized Set<String> getFundCodes() {
		return fundCodes;
	}

	public synchronized void setFundCodes(Set<String> fundCodes) {
		this.fundCodes = fundCodes;
	}

	@Override
	public String toString() {
		return "SwitchToRequest [paramObj=" + paramObj + ", fundCodes=" + fundCodes + "]";
	}

}
