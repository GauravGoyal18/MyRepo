package com.ipru.groups.po;

import java.io.Serializable;
import java.util.Date;

public class ServiceWebpageCallPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long requestId;

	public ServiceWebpageCallPO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceWebpageCallPO(long requestId) {
		super();
		this.requestId = requestId;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	@Override
	public String toString() {
		return "ServiceWebpageCallPO [requestId=" + requestId + "]";
	}

}
