package com.ipru.groups.enums;

public enum SwitchTypeEnum {
	
	Units,
	amount;
}
