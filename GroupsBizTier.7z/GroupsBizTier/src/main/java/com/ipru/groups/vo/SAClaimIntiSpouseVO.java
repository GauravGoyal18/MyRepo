package com.ipru.groups.vo;

import java.io.Serializable;

public class SAClaimIntiSpouseVO implements Serializable  {

	private static final long serialVersionUID = 1L;

	
	private Long spouseId;
	private String salutation;
	private String firstName;
	private String lastName;
	private String dateOfBirth;
	private String ageProof;
	
	private transient SAClaimIntimationVO sAClaimIntimationVO;
	
	public String getSalutation() {
		return salutation;
	}
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getAgeProof() {
		return ageProof;
	}
	public void setAgeProof(String ageProof) {
		this.ageProof = ageProof;
	}
	public Long getSpouseId() {
		return spouseId;
	}
	public void setSpouseId(Long spouseId) {
		this.spouseId = spouseId;
	}
	public SAClaimIntimationVO getsAClaimIntimationVO() {
		return sAClaimIntimationVO;
	}
	public void setsAClaimIntimationVO(SAClaimIntimationVO sAClaimIntimationVO) {
		this.sAClaimIntimationVO = sAClaimIntimationVO;
	}
	
	public static boolean isNotEmpty(SAClaimIntiSpouseVO spouse)
	{
		if(spouse.getSpouseId()==null&&spouse.getSalutation()==null&&spouse.getFirstName()==null&&spouse.getLastName()==null&&spouse.getDateOfBirth()==null&&spouse.getAgeProof()==null)
		return false;
		else
		return true;
		
	}
	
	
	
	@Override
	public String toString() {
		return "SAClaimIntiSpouseVO [spouseId=" + spouseId + ", salutation="
				+ salutation + ", firstName=" + firstName + ", lastName="
				+ lastName + ", dateOfBirth=" + dateOfBirth + ", ageProof="
				+ ageProof + ", sAClaimIntimationVO=" + sAClaimIntimationVO
				+ "]";
	}
	
}
