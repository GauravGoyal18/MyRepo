package com.ipru;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.ipru.groups.security.dao.BusinessParametersListDAOHibernateImpl;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.PolicyProductFundMasterVO;
import com.ipru.groups.vo.PolicyValidMasterVO;
import com.ipru.groups.vo.ProductFundMasterVO;
import com.ipru.groups.vo.ProductMasterVO;
import com.ipru.groups.vo.ProductSwitchAmountVO;
import com.ipru.groups.widget.dao.GstDaoHibernateImpl;
import com.ipru.groups.widget.service.GroupsBaseService;
import com.tcs.logger.FLogger;

public class MasterDataService extends GroupsBaseService {
	Properties pdfPropsProductCode = MasterPropertiesFileLoader.CONSTANT_CACHE_MODE_CSEBI_PRODUCTCODE_PROPERTIES;

	

	/**
	 * Gets the all urls.
	 * 
	 * @return the all urls
	 */
	public static List getAllUrls() {
		FLogger.debug("PurchaseFlow.EBILogger", "RightProductHandler", "getAllUrls", "Method for returning URLs list from back end");

		// ArrayList<List> finalList = new ArrayList<List>();
		List list = new ArrayList();
		BusinessParametersListDAOHibernateImpl daoHibernateImpl = new BusinessParametersListDAOHibernateImpl("GroupSecurity");
		
		list = (List) daoHibernateImpl.selectAllUrls();
		
		return list;
	}

	public static List<FunctionalityMasterVO> getFunctionalityList() {
		List<FunctionalityMasterVO> functionalityList = null;
		BusinessParametersListDAOHibernateImpl daoHibernateImpl = new BusinessParametersListDAOHibernateImpl("GroupSecurity");

		functionalityList = daoHibernateImpl.getFunctionalityList();

		return functionalityList;
	}
	
	public static List<ProductMasterVO> getProductMasterList() {

		List<ProductMasterVO> productMasterVOList = null;
		BusinessParametersListDAOHibernateImpl daoHibernateImpl = new BusinessParametersListDAOHibernateImpl("group");

		productMasterVOList = daoHibernateImpl.getProductMasterList();

		return productMasterVOList;
	}

	public static List<FundMasterVO> getFundMasterList() {

		List<FundMasterVO> fundMasterVOList = null;
		BusinessParametersListDAOHibernateImpl daoHibernateImpl = new BusinessParametersListDAOHibernateImpl("group");

		fundMasterVOList = daoHibernateImpl.getFundMasterList();

		return fundMasterVOList;
	}
	
	
	public static List<ProductFundMasterVO> getProductFundMasterList() {

		List<ProductFundMasterVO> productFundMasterVOList = null;
		BusinessParametersListDAOHibernateImpl daoHibernateImpl = new BusinessParametersListDAOHibernateImpl("group");

		productFundMasterVOList = daoHibernateImpl.getProductFundMasterList();

		return productFundMasterVOList;
	}
	
	public static List<ProductSwitchAmountVO> getProductProductSwitchAmountMasterList() {

		List<ProductSwitchAmountVO> productSwitchAmountMasterVOList = null;
		BusinessParametersListDAOHibernateImpl daoHibernateImpl = new BusinessParametersListDAOHibernateImpl("group");

		productSwitchAmountMasterVOList = daoHibernateImpl.getProductProductSwitchAmountMasterList();

		return productSwitchAmountMasterVOList;
	}
	
	public static List<PolicyValidMasterVO> getPolicyValidMasterList() {

		List<PolicyValidMasterVO> PolicyValidMasterVOList = null;
		BusinessParametersListDAOHibernateImpl daoHibernateImpl = new BusinessParametersListDAOHibernateImpl("group");

		PolicyValidMasterVOList = daoHibernateImpl.getPolicyValidMasterList();

		return PolicyValidMasterVOList;
	}
	
	public static List<String> getGstPolicyList() {

		List<String> gstPolicyList = null;
		GstDaoHibernateImpl daoHibernateImpl = new GstDaoHibernateImpl("group");

		gstPolicyList = daoHibernateImpl.getPolicyList();

		return gstPolicyList;
	}

	public static List<PolicyProductFundMasterVO> getPolicyProductFundList() {
		
		List<PolicyProductFundMasterVO> policyProductFundMasterList = null;
		
		BusinessParametersListDAOHibernateImpl daoHibernateImpl = new BusinessParametersListDAOHibernateImpl("group");
		
		policyProductFundMasterList = daoHibernateImpl.getPolicyProductFundList();
		
		return policyProductFundMasterList;
	}
}
