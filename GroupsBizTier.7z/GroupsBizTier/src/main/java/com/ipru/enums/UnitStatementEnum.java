package com.ipru.enums;

public enum UnitStatementEnum {
	/*UnitStatement*/
	startDate,
	endDate,
	TRUST,
	MEMBER,
	trustUnitStatCustormerDetails,
	memberUnitStatCustormerDetails,
	getFundTransactionListTrust,
	getFunTransactionListMember,
	Contribution,
	Claim,
	getFundName,
	getNavValue,
	getNavDate,
	getFundNameListTrust,
	getFundNameListMember,
	trustTotalUnit,
	memberTotalUnit,
	getSingleSFINUnitStatement,
	getUnitStmtSixMonthPreDate,
	
	
	/*UnitStatement Gratuity*/
	
	getGratuityFundList,
	getSingleSFIN,
	getOpeningBal,
	getUnitStmtDate1,
	getUnitStmtDate2,
	getOpeningBalNAV,
	getUnitStatementGratuity,
	getClosingBal,
	getClosingBalNAV
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
