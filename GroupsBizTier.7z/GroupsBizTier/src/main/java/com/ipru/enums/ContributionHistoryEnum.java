package com.ipru.enums;

public enum ContributionHistoryEnum {
	  
	TRUST,
	MEMBER
	
}
