package com.ipru.enums;

public enum ProfileUpdateEditEnum {
		fieldName,
		newValue,
		oldValue,
		index
}
