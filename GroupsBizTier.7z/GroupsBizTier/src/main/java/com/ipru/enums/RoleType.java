package com.ipru.enums;

public enum RoleType {
	TRUST,
	MEMBER,
	TERM,
	GTRUST,
	UPLOADER
}
