package com.ipru.enums;

public enum Role {
	G1,
	G2,
	saml,
	TERM,
	GTRUST,
	TRUST,
	Member
}
