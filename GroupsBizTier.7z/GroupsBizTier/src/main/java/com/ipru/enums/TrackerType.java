package com.ipru.enums;



public enum TrackerType {		 
	ClaimWebPage,
	ServiceWebPage,
	Service
}

