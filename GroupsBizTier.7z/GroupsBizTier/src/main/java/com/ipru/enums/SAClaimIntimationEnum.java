package com.ipru.enums;

import java.util.ArrayList;

public class SAClaimIntimationEnum {



	public enum TypeOfClaim
	{
		
		NORMAL_RETIREMENT("Normal Retirement"),
		RESIGNATION("Resignation"),
		EARLY_RETIREMENT("Early Retirement");
		
		private String claimType;
		   
		public String getTypeOfClaim() {
	       return this.claimType;
	   }
		
	   TypeOfClaim(String claimType) {
	           this.claimType = claimType;
	   }
	}
	public enum PurchaseOption
	{
		Option1("Open Market Option"),
		Option2("Transfer to new fund");
		
		private String option;
		   
		public String getPurchaseOption() {
	       return this.option;
	   }
		
		PurchaseOption(String option) {
	           this.option = option;
	   }
	}
	public enum ModeOfPayment
	{
		//MODE1("Regular Cheque"),
		//MODE2("PDC"),
		MODE3("Electronic Credit");
		//MODE4("Annuity Card");
		private String mode;
		   
		public String getModeOfPayment() {
	    return this.mode;
	   }
		
		ModeOfPayment(String mode) {
	    this.mode = mode;
	   }
		
	}
	public enum Salutation
	{
		SALUTATION1("Capt."),
		SALUTATION2("Mr."),
		SALUTATION3("Ms."),
		SALUTATION4("Dr."),
		SALUTATION5("Mrs.");
	
		private String salutation;
		   
		public String getSalutation() {
	       return this.salutation;
	   }
		
		Salutation(String salutation) {
	    this.salutation = salutation;
	   }
	}
	public enum Relation
	{
		FATHER("Father"),
		MOTHER("Mother"),
		DAUGHTER("Daughter"),
		SON("Son");
		
		private String relation;
		   
		public String getRelation() {
	       return this.relation;
	   }
		
		Relation(String relation) {
	           this.relation = relation;
	   }
		
	}
	
	public enum PaymentFrequency
	{
		MONTHLY("Monthly"),
		QUATERLY("Quaterly"),
		HALF_YEARLY("Half Yearly"),
		YEARLY("Yearly");
		private String paymentFrequency;
		   
		public String getPaymentFrequency() {
	       return this.paymentFrequency;
	   }
		
		PaymentFrequency(String paymentFrequency) {
	           this.paymentFrequency = paymentFrequency;
	   }
	}
	
	public enum Gender
	{
		MALE("Male"),
		FEMALE("Female");
		
		private String gender;
		   
		public String getGender() {
	       return this.gender;
	   }
		
	   Gender(String gender) {
	           this.gender = gender;
	   }
	}
	
	public enum Category
	{
		MAJOR("Male"),
		MINOR("Female");
		
		private String category;
		   
		public String getCategory() {
	       return this.category;
	   }
		
		Category(String category) {
	           this.category = category;
	   }
	}
	
	public enum AnnuityOptions
	{
		annuityOptions1("Life annuity"),
		annuityOptions2("Life annuity with return of premium"),
		annuityOptions3("Joint life last survivor (JLSS) (This option is applicable only when annuitant has spouse at time of commencement of pension.)"),
		annuityOptions4("Joint life last survivor with return of Purchase price (JLSS) (This option is applicable only when annuitant has spouse at time of commencement of pension.)"),
		annuityOptions5("Life annuity guaranteed for 5 years and life thereafter"),
		annuityOptions6("Life annuity guaranteed for 10 years and life thereafter"),
		annuityOptions7("Life annuity guaranteed for 15 years and life thereafter"),
		annuityOptions8("Life Annuity with Return of 50% Purchase Price"),
		annuityOptions9("Life Annuity with Return of 75% Purchase Price"),
		annuityOptions10("Life Annuity with Return of Balance Purchase price"),
		annuityOptions11("Life Annuity Guaranteed for 5/10/15 years and payable for life thereafter"),
		annuityOptions12("Life Annuity with Return of Purchase Price on Critical illness (CI) or Permanent Disability due to accident (PD) or Death"),
		annuityOptions13("Life Annuity with annual increase of 5%"),
		annuityOptions14("Joint Life, Last Survivor with Return of Purchase Price in parts");
		
		private String annuOptions;
		   
		public String getAnnuityOptions() {
	       return this.annuOptions;
	   }
		
		AnnuityOptions(String annuOptions) {
	           this.annuOptions = annuOptions;
	   }
	}
		
	
		public static ArrayList<String> getTypeOfClaimEnumList()
		{
			TypeOfClaim[] typeOfClaims = TypeOfClaim.values();
			ArrayList<String> claims = new ArrayList<String>();
			for (TypeOfClaim typeOfClaim : typeOfClaims) {
	    	   claims.add(typeOfClaim.getTypeOfClaim().toString());
			}
	       return claims;
	   }
		
		public static  ArrayList<String> getPurchaseOptionEnumList()
		{
			PurchaseOption[] opts = PurchaseOption.values();
			ArrayList<String> purOpt = new ArrayList<String>();
			for (PurchaseOption opt : opts) {
				purOpt.add(opt.getPurchaseOption().toString());
			}
	       return purOpt;
	   }
		
		public static ArrayList<String> getModeOfPaymentEnumList()
		{
			ModeOfPayment[] mop = ModeOfPayment.values();
			ArrayList<String> moPayList = new ArrayList<String>();
			for (ModeOfPayment mo : mop) {
				moPayList.add(mo.getModeOfPayment().toString());
			}
	       return moPayList;
	   }
		
		public static ArrayList<String> getSalutationEnumList()
		{
			Salutation[] sals = Salutation.values();
			ArrayList<String> salList = new ArrayList<String>();
			for (Salutation sal : sals) {
				salList.add(sal.getSalutation().toString());
			}
	       return salList;
	   }
		
		public static ArrayList<String> getRelationEnumList()
		{
			Relation[] rela = Relation.values();
			ArrayList<String> relaList = new ArrayList<String>();
			for (Relation rel : rela) {
				relaList.add(rel.getRelation().toString());
			}
	       return relaList;
	   }
		
		public static ArrayList<String> getPaymentFrequencyEnumList()
		{
			PaymentFrequency[] payFreq = PaymentFrequency.values();
			ArrayList<String> payFreqList = new ArrayList<String>();
			for (PaymentFrequency payFr : payFreq) {
				payFreqList.add(payFr.getPaymentFrequency().toString());
			}
	       return payFreqList;
	   }
		
		public static ArrayList<String> getGenderEnumList()
		{
			Gender[] gndr = Gender.values();
			ArrayList<String> genList = new ArrayList<String>();
			for (Gender gen : gndr) {
				genList.add(gen.getGender().toString());
			}
	       return genList;
	   }
		
		public static ArrayList<String> getAnnuityOptionsEnumList()
		{
			AnnuityOptions[] annuOptions = AnnuityOptions.values();
			ArrayList<String> annuOptList = new ArrayList<String>();
			for (AnnuityOptions annuOp : annuOptions) {
				annuOptList.add(annuOp.getAnnuityOptions().toString());
			}
	       return annuOptList;
	   }

}
