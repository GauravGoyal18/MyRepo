package com.ipru.bulksms;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import com.tcs.logger.FLogger;
public final class SmsXmlUtil {

    /**
     * Utility method to marshal request object to webservice request
     * @param requestData
     * @param classType
     * @return
     * @throws JAXBException
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws TransformerException
     */
    public static String marshal(Object requestData, Class<?> classType) throws JAXBException, SAXException, IOException, ParserConfigurationException  {
		FLogger.info("BulkSMS","SmsXmlUtil" ,"marshal" , "Entered method");
	final String DOCTYPE="<!DOCTYPE REQ SYSTEM 'http://bulkpush.mytoday.com/BulkSms/BulkSmsV1.00.dtd'>\n";
    JAXBContext context = null;
	context = JAXBContext.newInstance(classType);
	StringWriter writer = new StringWriter();
	writer.write(DOCTYPE);
	Marshaller marshaller = null;
	marshaller = context.createMarshaller();
	marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
	marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
	marshaller.marshal(requestData, writer);
	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	dbf.setNamespaceAware(true);
	Document doc = dbf.newDocumentBuilder().parse(new InputSource(new StringReader(writer.toString())));
	if(doc!=null){
		return writer.toString();
	}
		FLogger.info("BulkSMS","SmsXmlUtil" ,"marshal" , "Exited method");
	return null;
//	return getDocumentXML(doc);
	
}

    /**
     * Utility method to unmarshal
     * @param replyData
     * @param classType
     * @return
     * @throws JAXBException
     */
    public static Object unmarshal(String replyData, Class<?> classType) throws JAXBException {
		FLogger.info("BulkSMS","SmsXmlUtil" ,"unmarshal" , "Entered method");

		/*String proxyHost = "10.50.52.221"; 
	int proxyPort = 80;
	System.setProperty("http.proxyHost",proxyHost);  
	System.setProperty("http.proxyPort",String.valueOf(proxyPort)) ;*/

	JAXBContext context = null;
	context = JAXBContext.newInstance(classType);
	Unmarshaller unmarshal = context.createUnmarshaller();
	InputSource inStream = new InputSource();
	inStream.setCharacterStream(new StringReader(replyData));
	Object replyObj = unmarshal.unmarshal(inStream);
		FLogger.info("BulkSMS","SmsXmlUtil" ,"unmarshal" , "Exited method");
		return replyObj;
	}

	/**
	 * Utility method to unmarshal ignoring dtds
	 * @param replyData
	 * @param classType
	 * @return
	 * @throws JAXBException
	 */
	public static Object unmarshalIgnoringDTDs(String replyData, Class<?> classType) throws JAXBException {
		FLogger.info("BulkSMS","SmsXmlUtil" ,"unmarshalIgnoringDTDs" , "Entered method");
		FLogger.info("BulkSMS","SmsXmlUtil" ,"unmarshalIgnoringDTDs" , "replyData::"+replyData);
		Object replyObj = null;
		SAXParserFactory parserFactory = SAXParserFactory.newInstance();
		try {
			SAXParser saxParser = parserFactory.newSAXParser();
			XMLReader xmlReader = saxParser.getXMLReader();
			EntityResolver entityResolver = new EntityResolver() {
				@Override
				public InputSource resolveEntity(String arg0, String arg1)
						throws SAXException, IOException {
					return new InputSource(new StringReader(""));
				}
			};
			xmlReader.setEntityResolver(entityResolver);
			FLogger.info("BulkSMS","SmsXmlUtil" ,"unmarshalIgnoringDTDs" ,"Before Manipulating : "+replyData);
			final String docTypeDeclarationRegex = "<!DOCTYPE[^>]*>";
			final String xmlDeclaration = "<?xml version=\"1.0\" encoding= \"UTF-8\" ?>";
			replyData = replyData.replaceAll(docTypeDeclarationRegex, xmlDeclaration);
			replyData = replyData.replaceAll(">\\s*<", "><");
			FLogger.info("BulkSMS","SmsXmlUtil" ,"unmarshalIgnoringDTDs" ,"After Manipulating : "+replyData);
			SAXSource saxSource = new SAXSource(xmlReader, new InputSource(new StringReader(replyData)));
			Unmarshaller unmarshaller = JAXBContext.newInstance(classType).createUnmarshaller();
			replyObj = unmarshaller.unmarshal(saxSource);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		}
		FLogger.info("BulkSMS","SmsXmlUtil" ,"unmarshalIgnoringDTDs" , "Exited method");
	return replyObj;
    }
    
    public static String getDocumentXML(Document doc) throws TransformerException{
    	DOMSource domSource = new DOMSource(doc);
    	StringWriter writer = new StringWriter();
    	StreamResult result = new StreamResult(writer);
    	TransformerFactory tf = TransformerFactory.newInstance();
    	Transformer transformer = tf.newTransformer();
    	transformer.transform(domSource, result);
    	return  writer.toString();
    }
}




