package com.ipru.bulksms.beans.smsresponse;

import java.io.Serializable;
import java.util.List;

/**
 * Bean which capture BulkSMS response for usage across application
 * @author IPRU23846
 *
 */
public class SmsResponseBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private String reqErrorCode;
	private String reqErrorDesc;
	private List<ResponseMessageBO> messages;
	private String requestId;

	public String getReqErrorCode() {
		return reqErrorCode;
	}

	public void setReqErrorCode(String reqErrorCode) {
		this.reqErrorCode = reqErrorCode;
	}

	public String getReqErrorDesc() {
		return reqErrorDesc;
	}

	public void setReqErrorDesc(String reqErrorDesc) {
		this.reqErrorDesc = reqErrorDesc;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public List<ResponseMessageBO> getMessages() {
		return messages;
	}

	public void setMessages(List<ResponseMessageBO> messages) {
		this.messages = messages;
	}
	

}
