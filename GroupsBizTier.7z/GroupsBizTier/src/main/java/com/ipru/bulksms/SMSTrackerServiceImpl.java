package com.ipru.bulksms;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.ws.rs.core.UriBuilder;
import javax.xml.bind.JAXBException;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.ProxyAuthenticationStrategy;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.ipru.bulksms.beans.smsrequest.ObjectFactory;
import com.ipru.bulksms.beans.smsrequest.REQ;
import com.ipru.bulksms.beans.smsrequest.SmsRequestBO;
import com.ipru.bulksms.beans.smsresponse.ERROR;
import com.ipru.bulksms.beans.smsresponse.MID;
import com.ipru.bulksms.beans.smsresponse.RESULT;
import com.ipru.bulksms.beans.smsresponse.ResponseMessageBO;
import com.ipru.bulksms.beans.smsresponse.SmsResponseBO;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.GroupsJsonUtils;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.widget.service.GroupsBaseService;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.representation.Form;
import com.tcs.logger.FLogger;

/**
 * Concrete implementation for Consumption of BulkSMS WebService
 * @author IPRU23846
 * @author IPRU25270
 */

public class SMSTrackerServiceImpl extends GroupsBaseService implements SMSTrackerService {
	private ObjectFactory smsObjFactory = new ObjectFactory();
	private static final String CLASS_NAME = SMSTrackerServiceImpl.class.getCanonicalName();
	private Properties smsProperties = null;


	@Override
	public SmsResponseBO sendSmsBySingleMsgApi(String messageText, List<String> toMobileNumbers) throws SmsServiceException{
		FLogger.info("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Entered method");
		 RESULT result =null;
		 ClientResponse response = null;
		try {
		buildProperties();
		

		ClientConfig config = new DefaultClientConfig();
		String proxyHost = getSmsProperties().getProperty("http.proxyHost");
		String proxyPort = getSmsProperties().getProperty("http.proxyPort");
		if(StringUtils.isNotBlank(proxyHost)&&StringUtils.isNotBlank(proxyPort)){
			System.setProperty("http.proxyHost",proxyHost);  
	        System.setProperty("http.proxyPort",proxyPort) ;
		}
		FLogger.debug("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Creating REST client Default configuration");
		Client client = Client.create(config);
        FLogger.debug("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Generating webResource");
        WebResource webResource = client.resource(UriBuilder.fromUri(getSmsProperties().getProperty("WebserviceUri")).build());
        Form formData = new Form();
        FLogger.debug("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Generating requestMap");
        Map<String,Object>reqObject = generateRequestMap(messageText,toMobileNumbers);
        if(MapUtils.isNotEmpty(reqObject)){
        for (Map.Entry<String, Object> entry : reqObject.entrySet())
        {
        	if(!StringUtils.equalsIgnoreCase(entry.getKey(),"class")){
        	formData.add(entry.getKey(),entry.getValue());
        	}
        }
        }
        response = webResource.post(ClientResponse.class, formData);
        FLogger.debug("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Posted FormData::"+response);
       
		
			result = getResponseResult(response.getEntity(String.class));
		} catch (ClientHandlerException e) {
			handleServiceException(e);
		} catch (UniformInterfaceException e) {
			handleServiceException(e);
		} catch (Exception e) {
			handleServiceException(e);
		}
		FLogger.debug("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Posted FormData::"+response);
		FLogger.info("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Exited method");
        return generateResponseObj(result);
	}
	
	

	@Override
	public SmsResponseBO sendSmsBySingleMsgApi(String messageText,
			String toMobileNumber) throws SmsServiceException {
		FLogger.info("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Entered method");
		ClientResponse response = null;
		 RESULT result =null;
		try {
		buildProperties();
		ClientConfig config = new DefaultClientConfig();
		String proxyHost = getSmsProperties().getProperty("http.proxyHost");
		String proxyPort = getSmsProperties().getProperty("http.proxyPort");
		if(StringUtils.isNotBlank(proxyHost)&&StringUtils.isNotBlank(proxyPort)){
			System.setProperty("http.proxyHost",proxyHost);  
	        System.setProperty("http.proxyPort",proxyPort) ;
		}
		FLogger.debug("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Creating REST client Default configuration");
		Client client = Client.create(config);
        FLogger.debug("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Generating webResource");
        WebResource webResource = client.resource(UriBuilder.fromUri(getSmsProperties().getProperty("WebserviceUri")).build());
        Form formData = new Form();
        FLogger.debug("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Generating requestMap");
        Map<String,Object>reqObject = generateRequestMap(messageText,toMobileNumber);
        if(MapUtils.isNotEmpty(reqObject)){
        for (Map.Entry<String, Object> entry : reqObject.entrySet())
        {
        	if(!StringUtils.equalsIgnoreCase(entry.getKey(),"class")){
        	formData.add(entry.getKey(),entry.getValue());
        	}
        }
        }
        response= webResource.post(ClientResponse.class, formData);
        FLogger.debug("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Posted FormData::"+response);
       
		
			result = getResponseResult(response.getEntity(String.class));
		} catch (ClientHandlerException e) {
			handleServiceException(e);
		} catch (UniformInterfaceException e) {
			handleServiceException(e);
		} catch (Exception e) {
			handleServiceException(e);
		}
		FLogger.debug("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Posted FormData::"+response);
		FLogger.info("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApi" , "Exited method");
        return generateResponseObj(result);
	}
	
	

	
	
	/**
	 * Used to generate request string for usage of SingleMsgApi module of the REST webservice
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	private Map<String,Object> generateRequestMap(String messageText, List<String> toMobileNumbers) throws Exception{
		FLogger.info("BulkSMS",CLASS_NAME ,"generateRequestMap" , "Entered method");
		if(CollectionUtils.isEmpty(toMobileNumbers)||StringUtils.isBlank(messageText)) {
			throw new SmsServiceException("ToMobileNumbers or message Text is empty");
		}
		
		StringBuilder tocsvNumbers=new StringBuilder();
		tocsvNumbers.setLength(0);
		if(CollectionUtils.isNotEmpty(toMobileNumbers)){
			for (String eachMobileNum : toMobileNumbers) {
				checkMobileNumbers(eachMobileNum);
				if(StringUtils.isNotBlank(tocsvNumbers.toString())){
					tocsvNumbers.append(",");
				}
				tocsvNumbers.append(eachMobileNum);
			}
		}
		SmsRequestBO requestObj = new SmsRequestBO();
		requestObj.setFeedid(getSmsProperties().getProperty("feedId"));
		requestObj.setUsername(getSmsProperties().getProperty("authno"));
		requestObj.setPassword(getSmsProperties().getProperty("authprop"));
		requestObj.setTo(tocsvNumbers.toString());
		requestObj.setText(messageText);
		requestObj.setSenderid(getSmsProperties().getProperty("senderId"));
		FLogger.info("BulkSMS",CLASS_NAME ,"generateRequestMap" , "Exited method");
//		return new BeanMap(requestObj);
		return GroupsJsonUtils.getInstance().jsonToMap(GroupsJsonUtils.getInstance().getJsonObject(getGsonSingleton().toJson(requestObj)));
	}
	
	
	@SuppressWarnings("unchecked")
	private Map<String,Object> generateRequestMap(String messageText, String toMobileNumber) throws SmsServiceException, Exception{
		FLogger.info("BulkSMS",CLASS_NAME ,"generateRequestMap" , "Entered method");
		if(StringUtils.isBlank(toMobileNumber)||StringUtils.isBlank(messageText)) {
			throw new SmsServiceException("ToMobileNumber or message Text is empty");
		}
		checkMobileNumbers(toMobileNumber);
		SmsRequestBO requestObj = new SmsRequestBO();
		requestObj.setFeedid(getSmsProperties().getProperty("feedId"));
		requestObj.setUsername(getSmsProperties().getProperty("authno"));
		requestObj.setPassword(getSmsProperties().getProperty("authprop"));
		requestObj.setTo(toMobileNumber);
		requestObj.setText(messageText);
		requestObj.setSenderid(getSmsProperties().getProperty("senderId"));
		FLogger.info("BulkSMS",CLASS_NAME ,"generateRequestMap" , "Exited method");
		return GroupsJsonUtils.getInstance().jsonToMap(GroupsJsonUtils.getInstance().getJsonObject(getGsonSingleton().toJson(requestObj)));
	}
	/**
	 * Unmarshals the response from the Webservice into RESULT object
	 * @param webResponse
	 * @return
	 * @throws SmsServiceException
	 */
	private RESULT getResponseResult(String webResponse) throws SmsServiceException{
		FLogger.info("BulkSMS",CLASS_NAME ,"getResponseResult" , "Entered method");
        RESULT resultObj = null;
		try {
			resultObj = (RESULT)SmsXmlUtil.unmarshal(webResponse, RESULT.class);
		} catch (JAXBException e) {
			handleServiceException(e);
		}
		FLogger.info("BulkSMS",CLASS_NAME ,"getResponseResult" , "Exited method");
		return resultObj;
	}
	
	/**
	 * Unmarshals the response from the Webservice into RESULT object ignoring DTDs
	 * @param webResponse
	 * @return
	 * @throws SmsServiceException
	 */
	private RESULT getResponseResultIgnoringDTDs(String webResponse) throws SmsServiceException{
		FLogger.info("BulkSMS",CLASS_NAME ,"getResponseResultIgnoringDTDs" , "Entered method");
		RESULT resultObj = null;
		try {
			resultObj = (RESULT)SmsXmlUtil.unmarshalIgnoringDTDs(webResponse, RESULT.class);
		} catch (JAXBException e) {
			handleServiceException(e);
		}
		FLogger.info("BulkSMS",CLASS_NAME ,"getResponseResultIgnoringDTDs" , "Exited method");
		return resultObj;
	}


	
	
	/**
	 * Generates Response BO that can be used by application throughout.
	 * @param result
	 * @return
	 */
	private SmsResponseBO generateResponseObj(RESULT result){
		FLogger.info("BulkSMS",CLASS_NAME ,"generateResponseObj" , "Entered method");
		SmsResponseBO responseObj = null;
		if(result!=null){
			responseObj = new SmsResponseBO();
			if(result.getREQUESTERROR()!=null){
				responseObj.setReqErrorCode(result.getREQUESTERROR().getERROR().getCODE());
				responseObj.setReqErrorDesc(result.getREQUESTERROR().getERROR().getDESC());
			}
			if(CollectionUtils.isNotEmpty(result.getMID())){
				List<ResponseMessageBO> messages = new ArrayList<ResponseMessageBO>(1);
				for (MID resultMsg : result.getMID()) {
					ResponseMessageBO message= new ResponseMessageBO();
					if(CollectionUtils.isNotEmpty(resultMsg.getERROR())){
						for (ERROR error : resultMsg.getERROR()) {
							if(error!=null){
								message.setErrorCode(error.getCODE());
								message.setErrorDesc(error.getDESC());
								break;
							}
						}
					}
					message.setMsgId(resultMsg.getID());
					message.setSubmitDate(resultMsg.getSUBMITDATE());
					message.setTransactionId(resultMsg.getTID());
					message.setTag(resultMsg.getTAG());
					messages.add(message);
				}
				responseObj.setMessages(messages);
			}
			
			responseObj.setRequestId(result.getREQID());
			
		}else {
			responseObj = new SmsResponseBO();
			responseObj.setReqErrorCode("-999");
			responseObj.setReqErrorDesc("Undefined Error from SingleMsgApi");
		}
		FLogger.info("BulkSMS",CLASS_NAME ,"generateResponseObj" , "Exited method");
		return responseObj;
	}
	
	/**
	 * Generic Exception Handler method. Wrapping into customised Exception object
	 * @param e
	 * @throws SmsServiceException
	 */
	private void handleServiceException(Exception e) throws SmsServiceException {
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		FLogger.error("BulkSMS",CLASS_NAME ,"handleServiceException" , errors.toString());
		throw new SmsServiceException(e);
	}
	
	
	/**
	 * Builds the properties object
	 * 
	 * @throws SmsServiceException
	 */
	private void buildProperties() throws SmsServiceException{
		FileInputStream fis = null;
		if(MasterPropertiesFileLoader.CONSTANT_BULKSMS_WSCLIENT_PROPERTIES!=null)
		{
			smsProperties=MasterPropertiesFileLoader.CONSTANT_BULKSMS_WSCLIENT_PROPERTIES;
		}
		else
		{
			try {
				fis = new FileInputStream(GroupConstants.CONSTANT_BULKSMS_WSCLIENT_PROPERTIES);
				smsProperties.load(fis);
			} catch (FileNotFoundException e) {
				handleServiceException(e);
			} catch (IOException e) {
				handleServiceException(e);
			}
			finally {
				try {
					if(fis!=null)
						fis.close();
				}
				catch (Exception e) {
					FLogger.error("BulkSMS", CLASS_NAME, "buildProperties",
							"Exception Ocurred in finally of buildProperties: "+e.getMessage());
					e.printStackTrace();
				} finally {
					fis=null;
				}
			}
		}
	}
	
	public Properties getSmsProperties() {
		return smsProperties;
	}

	public void setSmsProperties(Properties smsProperties) {
		this.smsProperties = smsProperties;
	}
	/**
	 * Can be used to generate Request Object in case SendSMS module of the REST webservice is used. 
	 * @return
	 */
	@SuppressWarnings("unused")
	private REQ generateSmsReq(String messageText,Long mobileNo, String index){
			//Prerquisite is buildProperties;
			REQ smsRequestObj = smsObjFactory.createREQ();
		    smsRequestObj.setUSER(smsObjFactory.createREQUSER());
		    smsRequestObj.setACCOUNT(smsObjFactory.createREQACCOUNT());
		    smsRequestObj.setVER(1.0f);
		    smsRequestObj.getUSER().setUSERNAME(Long.valueOf(getSmsProperties().getProperty("authno")));
		    smsRequestObj.getUSER().setPASSWORD(getSmsProperties().getProperty("authprop"));
		    smsRequestObj.getACCOUNT().setID(Integer.valueOf(getSmsProperties().getProperty("feedId")));
		    
		    REQ.MESSAGE message = smsObjFactory.createREQMESSAGE();
		    message.setTEXT(messageText);
		    REQ.MESSAGE.SMS smsMessage = smsObjFactory.createREQMESSAGESMS();
		    smsMessage.setFROM("");
		    smsMessage.setTO(mobileNo);
		    smsMessage.setINDEX(Byte.valueOf(index));
		    message.setSMS(smsMessage);
		    smsRequestObj.getMESSAGE().add(message);
		    return smsRequestObj;
	}
	
	private String checkMobileNumbers(String mobileNo){
		if(StringUtils.isNotBlank(mobileNo)&&StringUtils.isNumeric(mobileNo)){
			if("10".equals(String.valueOf(mobileNo.length()))){
				mobileNo = "91"+mobileNo;
			}
		}
		return mobileNo;
	}

	/** This method is used to send OTP message using HttpClient API
	 * @param messageText
	 * @param toMobileNumber
	 * @return SmsResponseBO
	 * @throws SmsServiceException
	 */
	//Added by Deep for implementing HttpClient START
	public SmsResponseBO sendSmsBySingleMsgApiUsingHttpClient(String messageText, String toMobileNumber) throws SmsServiceException{
		FLogger.info("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApiUsingHttpClient" , "Entered method");
		buildProperties();
		System.getProperties().remove("http.proxyHost");
		System.getProperties().remove("http.proxyPort");
		//Added by ASN for setting Connection TO and Socket TO - Start
		final int WS_CONNECTION_TIMEOUT_MS = Integer.valueOf(getSmsProperties().getProperty("WS_CONNECTION_TIMEOUT_MS"));
		final int WS_SOCKET_TIMEOUT_MS = Integer.valueOf(getSmsProperties().getProperty("WS_SOCKET_TIMEOUT_MS"));
		RequestConfig params = RequestConfig.custom().setConnectTimeout(WS_CONNECTION_TIMEOUT_MS).setSocketTimeout(WS_SOCKET_TIMEOUT_MS).build();
		//Added by ASN for setting Connection TO and Socket TO - End
		HttpClientBuilder clientBuilder = HttpClientBuilder.create();
		RESULT result = null;

		String proxyHost = getSmsProperties().getProperty("http.proxyHost");
		String proxyPort = getSmsProperties().getProperty("http.proxyPort");
		String targetUri = getSmsProperties().getProperty("WebserviceUri");

		if(StringUtils.isNotBlank(proxyHost) && StringUtils.isNotBlank(proxyPort) && StringUtils.isNotBlank(targetUri)){
			HttpHost proxy = new HttpHost(proxyHost, Integer.parseInt(proxyPort));
			HttpHost target = new HttpHost(targetUri);
			
			clientBuilder.useSystemProperties();
			clientBuilder.setProxy(proxy);
			clientBuilder.setProxyAuthenticationStrategy(new ProxyAuthenticationStrategy());

			//NTLM authentication when running the application no you local
			String otp_env_check = getSmsProperties().getProperty("OTP_ENV_CHECK_FOR_NTLM");
			if(StringUtils.isNotBlank(otp_env_check) && StringUtils.equalsIgnoreCase(otp_env_check, "WIN")){
				String win_username = getSmsProperties().getProperty("win_username");
				String win_password = getSmsProperties().getProperty("win_password");
				String win_full_computer_name = getSmsProperties().getProperty("win_full_computer_name");
				String win_domain = getSmsProperties().getProperty("win_domain");

				Credentials cred = new NTCredentials(win_username, win_password, win_full_computer_name, win_domain);
				CredentialsProvider credsProvider = new BasicCredentialsProvider();
				credsProvider.setCredentials(new AuthScope(proxyHost, Integer.parseInt(proxyPort)),	cred);
				clientBuilder.setDefaultCredentialsProvider(credsProvider);
			}

			HttpPost postRequest = new HttpPost(targetUri);
			postRequest.setConfig(params);
			ArrayList<NameValuePair> requestBodies = generateRequestHttpEntity(messageText,toMobileNumber);
			try {
				postRequest.setEntity(new UrlEncodedFormEntity(requestBodies));
			} catch (UnsupportedEncodingException e1) {
				//e1.printStackTrace();
				handleServiceException(e1);
			}

			CloseableHttpClient client = clientBuilder.build();
			CloseableHttpResponse response = null;
			try {
				response = client.execute(target,postRequest);
				int status = response.getStatusLine().getStatusCode();
				String responseStr = EntityUtils.toString(response.getEntity());
				result = getResponseResultIgnoringDTDs(responseStr);
			} catch (ClientProtocolException e) {
				handleServiceException(e);
			} catch (IOException e) {
				handleServiceException(e);
			} catch (Exception e) {
				if(response!=null)
				{
					FLogger.info("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApiUsingHttpClient::response::", response.toString());
				}
				handleServiceException(e);
			}
			finally{
				try {
					if(response!=null)
						response.close();
					if(client!=null)
						client.close();
				} catch (IOException e) {
					handleServiceException(e);
				}
			}
			FLogger.info("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApiUsingHttpClient" ,"Exited method with result response");
			return generateResponseObj(result);
		}else{
			FLogger.info("BulkSMS",CLASS_NAME ,"sendSmsBySingleMsgApiUsingHttpClient" ,"Exited method with null response");
			return null;
		}


	}

	/**
	 * @param messageText
	 * @param toMobileNumber
	 * @return ArrayList<NameValuePair>
	 * @throws SmsServiceException
	 */
	@SuppressWarnings("unchecked")
	private ArrayList<NameValuePair> generateRequestHttpEntity(String messageText, String toMobileNumber) throws SmsServiceException{
		if(StringUtils.isBlank(toMobileNumber)||StringUtils.isBlank(messageText)) {
			throw new SmsServiceException("ToMobileNumber or message Text is empty");
		}

		checkMobileNumbers(toMobileNumber);
		ArrayList<NameValuePair> requestBodies = new ArrayList<NameValuePair>();

		requestBodies.add(new BasicNameValuePair("feedId",getSmsProperties().getProperty("feedId")));
		requestBodies.add(new BasicNameValuePair("username",getSmsProperties().getProperty("authno")));
		requestBodies.add(new BasicNameValuePair("password",getSmsProperties().getProperty("authprop")));
		requestBodies.add(new BasicNameValuePair("senderid",getSmsProperties().getProperty("senderId")));
		requestBodies.add(new BasicNameValuePair("to",toMobileNumber));
		requestBodies.add(new BasicNameValuePair("text",messageText));
		return requestBodies;
	}
	//Added by Deep for implementing HttpClient END
	
	/*	public static void main(String[] args) throws JAXBException, ParserConfigurationException, SAXException, IOException, TransformerException {
	SMSTrackerService service = new SMSTrackerService();
	//System.out.println(ToStringBuilder.reflectionToString(service.sendSmsAPI()));
}*/
	
	
}
