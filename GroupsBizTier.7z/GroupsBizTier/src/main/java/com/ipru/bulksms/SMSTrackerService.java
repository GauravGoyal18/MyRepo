package com.ipru.bulksms;

import java.util.List;

import com.ipru.bulksms.beans.smsresponse.SmsResponseBO;

/**
 * Interface for BULKSMS Webservice client 
 * @author IPRU23846
 *
 */
public interface SMSTrackerService {
	/**
	 * Client Web service method to integrate Netcore's IBANK's webservice to instantly send sms.
	 * @param messageText
	 * @param toMobileNumbers
	 * @return
	 * @throws SmsServiceException
	 */
	public SmsResponseBO sendSmsBySingleMsgApi(String messageText, List<String> toMobileNumbers) throws SmsServiceException;
	
	public SmsResponseBO sendSmsBySingleMsgApi(String messageText, String toMobileNumber) throws SmsServiceException;
	
	public SmsResponseBO sendSmsBySingleMsgApiUsingHttpClient(String messageText, String toMobileNumber) throws SmsServiceException;
}
