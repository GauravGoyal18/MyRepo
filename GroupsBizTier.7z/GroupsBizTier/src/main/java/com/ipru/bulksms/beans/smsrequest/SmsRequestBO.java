package com.ipru.bulksms.beans.smsrequest;

import java.io.Serializable;

public class SmsRequestBO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String feedid; //mandatory
	private String senderid; //optional
	private String username; //mandatory
	private String password; //mandatory
	private String time; //Future publish time optional
	private String To; //comma separated mobile nos. mandatory
	private String Text; //message in sms
	public String getFeedid() {
		return feedid;
	}
	public String getText() {
		return Text;
	}
	public void setText(String text) {
		Text = text;
	}
	public void setFeedid(String feedid) {
		this.feedid = feedid;
	}
	public String getSenderid() {
		return senderid;
	}
	public void setSenderid(String senderid) {
		this.senderid = senderid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTo() {
		return To;
	}
	public void setTo(String to) {
		To = to;
	}

}
