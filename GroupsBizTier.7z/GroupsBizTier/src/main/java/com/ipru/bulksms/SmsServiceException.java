package com.ipru.bulksms;

/**
 * Customised exception for BULKSMS Webservice Client
 * @author IPRU23846
 *
 */
public class SmsServiceException extends Exception {

	private static final long serialVersionUID = 1L;
	private String message;

	public SmsServiceException() {
		super();
	}

	public SmsServiceException(String strErrorMessage) {
		super(strErrorMessage);
		setMessage(strErrorMessage);
	}

	public SmsServiceException(Throwable cause) {
		super(cause.getMessage(), cause);
		setMessage(cause.getMessage());
	}

	public SmsServiceException(String msg, Throwable cause) {
		super(msg, cause);
		setMessage(msg);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
