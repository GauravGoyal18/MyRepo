package com.ipru.ThirdPartyAutoLogin;

import java.io.Serializable;

import com.google.gson.Gson;
import com.ipru.groups.utilities.EncryptionPBEMD5DES;

public class PremiumAckCABean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String websiteSource; //PREMACK
	private String custId; //Client Id of CA or BR
	private String agentId; //Agent Id of CA or BR
	private String websiteRole;//CANAT / CARREG
	private String returnURL;
	
	public String getWebsiteSource() {
		return websiteSource;
	}
	public void setWebsiteSource(String websiteSource) {
		this.websiteSource = websiteSource;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getWebsiteRole() {
		return websiteRole;
	}
	public void setWebsiteRole(String websiteRole) {
		this.websiteRole = websiteRole;
	}
	
	public static void main(String[] args) throws Exception {
		PremiumAckCABean premAckBean = new PremiumAckCABean();
		premAckBean.setAgentId("00002459");
		premAckBean.setCustId("00019749");
		premAckBean.setWebsiteRole("CANAT");
		premAckBean.setWebsiteSource("PREMACK");
		
		Gson gson = new Gson();
		String jsonPACK = gson.toJson(premAckBean);
		
		////System.out.println(CsrSecurityUtil.encodeBase64(EncryptionPBEMD5DES.encrypt(jsonPACK, "WEBSITE123", 1)));
		
	}
	/**
	 * @return the returnURL
	 */
	public String getReturnURL() {
		return returnURL;
	}
	/**
	 * @param returnURL the returnURL to set
	 */
	public void setReturnURL(String returnURL) {
		this.returnURL = returnURL;
	}
	
	

}
