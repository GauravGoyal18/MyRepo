package com.ipru.ThirdPartyAutoLogin;

import java.io.Serializable;

public class PreLoginThirdPartyInfoPO implements Serializable
{
			private static final long serialVersionUID = 1L;
			private String userId;
			private String role;
			private String websiteSource;
			private String reqFunc;
			private String password;
			private String policyNo;
			private String clientId;
			private long milliseconds;
			public String getReqFunc() {
				return reqFunc;
			}

			public void setReqFunc(String reqFunc) {
				this.reqFunc = reqFunc;
			}

			public String getWebsiteSource() {
				return websiteSource;
			}

			public void setWebsiteSource(String websiteSource) {
				this.websiteSource = websiteSource;
			}

			public String getRole() {
				return role;
			}

			public void setRole(String role) {
				this.role = role;
			}

			public String getUserId() {
				return userId;
			}

			public void setUserId(String userId) {
				this.userId = userId;
			}

			public String getPassword() {
				return password;
			}

			public void setPassword(String password) {
				this.password = password;
			}

			public String getPolicyNo() {
				return policyNo;
			}

			public void setPolicyNo(String policyNo) {
				this.policyNo = policyNo;
			}

			public String getClientId() {
				return clientId;
			}

			public void setClientId(String clientId) {
				this.clientId = clientId;
			}

			public long getMilliseconds() {
				return milliseconds;
			}

			public void setMilliseconds(long milliseconds) {
				this.milliseconds = milliseconds;
			}

			@Override
			public String toString() {
				return "PreLoginThirdPartyInfoPO [userId=" + userId + ", role=" + role + ", websiteSource=" + websiteSource + ", reqFunc=" + reqFunc + ", password=" + password + ", policyNo="
						+ policyNo + ", clientId=" + clientId + "]";
			}
}
