package com.tcs.excelValidation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Sheet;

import com.tcs.logger.FLogger;



public class Excel 
{
	private ExcelReader excelReader;
	private ExcelValidator excelValidator;
	private ExcelHelper excelHelper;
	static String  path="";
	static Sheet sheet;
	static String property="";
	public Excel() throws Exception
	{
		
		//path = "D:/AmrutaEclipse/Excel/src/ExcelUploads/uploadedFile.xls";
		
		
	}
	public Excel(String fileName, String path) throws Exception
	{
		FLogger.info("ClaimExcelValidationScheduler", "Excel","Excel", "fileName and Path  :"+fileName +path);
		excelReader = new ExcelReader();
		excelValidator = new ExcelValidator();
		excelHelper = new ExcelHelper();
		
		setFileName(fileName);//xml FileName
		setpath(path);
		
		FLogger.info("ClaimExcelValidationScheduler", "Excel","Excel", "set fileName and Path   method ended:");
		//TreeMap<String, ArrayList> tp=readExcel(sheet, property);
	}
	public TreeMap<String, ArrayList> getExcelValidation(int noOfRows,HashMap<String,String> expression) throws Exception
	{
		ExcelHelper helper=new ExcelHelper();
		TreeMap<String, ArrayList> resultRow=checkandValidateExcel(path, property,noOfRows,expression);
		/*if(resultRow.containsKey("Error"))
		{
			return resultRow;	
		
		}
		else
		{
			TreeMap<String, ArrayList> result=helper.readExcel(sheet, property,expression);
			return result;
		}*/
		
		return resultRow;
	}
	
	public void setFileName(String fileName)
	{
		System.out.println("FileName"+fileName);
		property=fileName;
		System.out.println("Inside setFileName");
	}
	public void setpath(String path1) throws Exception
	{
		System.out.println("path1"+path1);
		path=path1;
		System.out.println("Inside SetPath");
		sheet = excelReader.getExcelSheet(path);
		System.out.println("Inside SetPath");
		
		
	}
	public TreeMap checkandValidateExcel(String path, String property,int noOfRows,HashMap<String,String> expression)
			throws Exception {
		System.out
				.println("******************  Going to start validating the Excel file.********************");
		TreeMap data = new TreeMap();
		ArrayList<String> Error = new ArrayList<String>();
		String error = "";

		Sheet sheet = excelReader.getExcelSheet(path);
		if (sheet != null) {
			int noofrow = excelHelper.getNoOfRows(sheet);
			System.out.println("No of rows in Excel : " + noofrow);
			if (noofrow == 0) {
				error = "Error#Excel sheet is empty.";
				Error.add(error);
				data.put("Error", Error);
			} else if (noofrow > 0 && noofrow < noOfRows) {
				System.out.println("No of rows in Excel : " + noofrow);
				data = excelHelper.readExcel(sheet, property,expression);
				System.out.println("Data : " + data);
			} else {
				error = "Error#No of records can not be more than "+noOfRows+".";
				Error.add(error);
				data.put("Error", Error);
			}
		} else {
			error = "Error#Excel sheet is null.";
			System.out.println(error);
			Error.add(error);
			data.put("Error", Error);
		}

		return data;
	}

	/*public static void main(String args[]) 
	{
		System.out.println("Inside Excel");
		
		//System.out.println("Result*********"+tp.get(0));
		
	}*/
}
