package com.tcs.excelValidation;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import com.tcs.excelValidation.HeaderBean;


public class HeaderUtil {
	private HeaderXMLHandler handler;
	private String fileName;

	public HeaderUtil(String property) {
		fileName = property;
		//filePath = "D:/AmrutaEclipse/Excel/src/format/";
		try {
			SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();

			SAXParser saxParser = saxParserFactory.newSAXParser();

			handler = new HeaderXMLHandler();

			File file = new File(fileName);
			System.out.println("File object created. : "
					+ file.getAbsolutePath());

			saxParser.parse(file, handler);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("File is parsed.");
	}

	public  List<HeaderBean> getHeaderList() throws Exception {
		List<HeaderBean> headerList = null;

		// Get Employees list
		headerList = handler.getHeaderList();
		// print employee information
		for (HeaderBean headerBean : headerList)
			System.out.println(headerBean.toString());

		return headerList;
	}

	public List<String> getHeaderNameList() throws Exception {

		List<String> headerNameList = null;

		headerNameList = handler.getHeaderNameList();

		System.out.println("headerNameList : " + headerNameList);

		return headerNameList;
	}
}
