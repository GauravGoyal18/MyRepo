package com.tcs.excelValidation;
public class HeaderBean {

	private String headerName;
	private String headerType;
	private int headerSize;
	private String headerMandatary;
	private String headerDefaultValue;
//	private String headerPattern;
	
	/*public String getHeaderPattern() {
		return headerPattern;
	}

	public void setHeaderPattern(String headerPattern) {
		this.headerPattern = headerPattern;
	}*/

	public String getHeaderName() {
		return headerName;
	}

	public void setHeaderName(String headerName) {
		this.headerName = headerName;
	}

	public String getHeaderType() {
		return headerType;
	}

	public void setHeaderType(String headerType) {
		this.headerType = headerType;
	}

	public int getHeaderSize() {
		return headerSize;
	}

	public void setHeaderSize(int headerSize) {
		this.headerSize = headerSize;
	}

	public String getHeaderMandatary() {
		return headerMandatary;
	}

	public void setHeaderMandatary(String headerMandatary) {
		this.headerMandatary = headerMandatary;
	}

	public String getHeaderDefaultValue() {
		return headerDefaultValue;
	}

	public void setHeaderDefaultValue(String headerDefaultValue) {
		this.headerDefaultValue = headerDefaultValue;
	}

	@Override
	public String toString() {
		return "HeaderBean [headerDefaultValue=" + headerDefaultValue
				+ ", headerMandatary=" + headerMandatary + ", headerName="
				+ headerName + ", headerSize=" + headerSize + ", headerType="
				+ headerType + "]";
	}
}
