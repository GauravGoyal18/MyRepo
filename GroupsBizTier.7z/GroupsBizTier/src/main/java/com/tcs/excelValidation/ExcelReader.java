package com.tcs.excelValidation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.tcs.logger.FLogger;

public class ExcelReader {

	private ExcelValidator excelValidator;

	public ExcelReader() {
		excelValidator = new ExcelValidator();
	}

	public Sheet getExcelSheet(String path) throws Exception {

		FileInputStream file = null;

		FLogger.info("ClaimExcelValidationScheduler", "ExcelReader", "getExcelSheet", "Beforeeeeeeeeeeeeeeeeeee :");

		System.out.println("Beforeeeeeeeeeeeeeeeeeee" + path);

		Sheet sheet=null;

		try {
			
			file = new FileInputStream(new File(path).getAbsoluteFile());
			FLogger.info("ClaimExcelValidationScheduler", "ExcelReader", "getExcelSheet", "Afterrrrrrrrrrrrrrrrrrrrrrrrrrr :");
			String fileExtn = GetFileExtension(path);
			//sheet = null;
			if (fileExtn.equalsIgnoreCase("xlsx")) {
				XSSFWorkbook workbook = new XSSFWorkbook(file);
				sheet = workbook.getSheetAt(0);
				sheet = deleteExtraEmptyRows(sheet);
			}
			if (fileExtn.equalsIgnoreCase("xls")) {
				POIFSFileSystem fs = new POIFSFileSystem(file);
				HSSFWorkbook workbook = new HSSFWorkbook(fs);
				// OPCPackage pkg = OPCPackage.open(file);
				// XSSFWorkbook workbook = new XSSFWorkbook(pkg);
				// System.out.println("POIFSFileSystem object created");
				// System.out.println("HSSFWorkbook object created");
				sheet = workbook.getSheetAt(0);
				// System.out.println("sheet object created");
				sheet = deleteExtraEmptyRows(sheet);
			}
		}
		catch (FileNotFoundException e) {
			
			FLogger.error("GROUPLogger", "MasterPropertiesFileLoader", "getProperties(Properties prop,String path)",e.getMessage());
			
		}
		catch (IOException e) {
			
			FLogger.error("GROUPLogger", "MasterPropertiesFileLoader", "getProperties(Properties prop,String path)","",e);
		}
		finally {
		try {
			if(file!=null)
				file.close();
		}
		catch (Exception e) {
			FLogger.error("GROUPLoggerError", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
					"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
			e.printStackTrace();
		} finally {
			file=null;
		}
		}
		FLogger.info("ClaimExcelValidationScheduler", "ExcelReader", "getExcelSheet", "Method ended:");

		return sheet;
	}

	public String GetFileExtension(String path) {
		String fileName = path;
		String fname = "";
		String ext = "";
		int mid = fileName.lastIndexOf(".");
		fname = fileName.substring(0, mid);
		ext = fileName.substring(mid + 1, fileName.length());
		return ext;
	}

	public Sheet deleteExtraEmptyRows(Sheet sheet) {

		int NoOfRows = sheet.getLastRowNum();
		System.out.println("No of rows in Excel Sheet" + NoOfRows);

		int actualNoOfRows = 0;
		int emptyRows = 0;
		int flag = 0;
		ArrayList<Integer> emptyRowList = new ArrayList<Integer>();

		for (int i = 0; i <= NoOfRows; i++) {
			Row row = sheet.getRow(i);
			if (excelValidator.checkEmptyRow(row)) {
				emptyRowList.add(i);
				if (flag == 0) {
					emptyRows++;
					flag = 1;
				}
				else if (flag == 1) {
					emptyRows++;
				}

			}
			else {
				if (flag == 0) {
					actualNoOfRows++;
				}
				else if (flag == 1) {
					actualNoOfRows = actualNoOfRows + emptyRows + 1;
					emptyRows = 0;
					flag = 0;
					emptyRowList.clear();
				}
			}
		}

		System.out.println("Actual No of rows : " + actualNoOfRows);
		System.out.println("Empty row List : " + emptyRowList);

		for (int j = emptyRowList.size(); j > 0; j--) {
			int rowNo = emptyRowList.get(j - 1);
			int lastRowNo = sheet.getLastRowNum();
			if (rowNo <= lastRowNo) {
				Row row = sheet.getRow(rowNo);
				sheet.removeRow(row);
			}
		}

		System.out.println("Now new no of rows after deleting empty rows : " + sheet.getLastRowNum());

		return sheet;
	}
}
