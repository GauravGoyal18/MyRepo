package com.tcs.excelValidation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.tcs.excelValidation.HeaderBean;


public class HeaderXMLHandler extends DefaultHandler {

	private List<HeaderBean> headerList = null;
	private List<String> headerNameList = null;
	private HeaderBean headerBean = null;
	private String value=null;
	private StringBuffer tempValue = new StringBuffer();
	//private StringBuffer buffer = new StringBuffer();
	
	public List<HeaderBean> getHeaderList() {
		System.out.println("headerList : "+headerList);
		return headerList;
	}

	public List<String> getHeaderNameList() {
		System.out.println("headerNameList : "+headerNameList);
		return headerNameList;
	}


	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		tempValue.setLength(0); //clear buffer
		if (qName.equalsIgnoreCase("Header")) {
			if (headerList == null)
				headerList = new ArrayList<HeaderBean>();

			headerBean = new HeaderBean();

		} 
		/*else if (qName.equalsIgnoreCase("Header_Pattern")) {
			System.out.println("Header_Pattern start");
			bHeaderPattern = true;
		}*/
		
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		 
		if (qName.equalsIgnoreCase("Header")) {
			headerList.add(headerBean);
			System.out.println("headerList : " + headerList);
			// text = null;
		}
		else if (qName.equalsIgnoreCase("Header_Name")) {
			System.out.println("new Jar********************************************************Header_Name start");
			if (headerNameList == null) {
				headerNameList = new ArrayList<String>();
				headerBean.setHeaderName((value));
				headerNameList.add((value));
			} else {
				headerBean.setHeaderName((value));
				headerNameList.add((value));
			}
		} else if (qName.equalsIgnoreCase("Header_Type")) {
			System.out.println("Header_Type start");
			headerBean.setHeaderType(value);
		} else if (qName.equalsIgnoreCase("Header_Size")) {
			System.out.println("Header_Size start");
			headerBean.setHeaderSize(Integer.parseInt(value));
		} else if (qName.equalsIgnoreCase("Header_Mandatary")) {
			System.out.println("Header_Mandatary start");
			headerBean.setHeaderMandatary(value);
		} else if (qName.equalsIgnoreCase("Header_Default_Value")) {
			headerBean.setHeaderDefaultValue(value);
			
		}
		
	}

	@Override
	public void characters(char ch[], int start, int length)
			throws SAXException {


		tempValue.append(ch, start, length); // append to buffer
	
		
		value=tempValue.toString();
		
		
		System.out.println("chhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"+ch.length);
		
		System.out.println(value+"---------------start------------------------------"+start+"length-----------------"+length);
		
		 
	}
	
	
	 private void readList() {
         System.out.println("No of  the accounts in bank '" + headerList.size()  + "'.");
         Iterator<HeaderBean> it = headerList.iterator();
         while (it.hasNext()) {
                System.out.println(it.next().toString());
         }
  }
}