package com.tcs.excelValidation;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import java.util.HashMap;


import org.apache.poi.ss.usermodel.Sheet;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import com.tcs.logger.FLogger;



public class ExcelValidator {

	public ExcelValidator() {
		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","ExcelValidator", "Start method :");
	}

	public ArrayList<String> checkEmptyRows(Sheet sheet, ArrayList<String> Error) {
		
		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","checkEmptyRows", "Sheet start method :"+sheet);

		if (sheet != null) {
			for (int i = 0; i < sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				if (row == null) {
					String error = "Row number " + (i + 1)
							+ "#Row cannot be empty.";
					System.out.println(error);
					Error.add(error);
				} else {
					if (checkEmptyRow(row)) {
						String error = "Row number " + (i + 1)
								+ "#Row cannot be empty.";
						System.out.println(error);
						Error.add(error);
					}
				}
			}
		}

		return Error;
	}

	public boolean checkEmptyRow(Row row) {
		
		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","checkEmptyRow", "Row start method :"+row);

		if (row != null) {
			int lastcol = row.getLastCellNum();
			String cellstring = null;

			for (int colno = 0; colno < lastcol; colno++) {
				Cell cell = row.getCell(colno);

				if (cell == null) {
					// System.out.println("Cell is empty.");
				} else {
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_NUMERIC:
						cellstring = String.valueOf(cell.getNumericCellValue());
						break;
					case Cell.CELL_TYPE_STRING:
						cellstring = cell.getStringCellValue();

						break;
					case Cell.CELL_TYPE_FORMULA:

						break;
					case Cell.CELL_TYPE_BLANK:

						break;
					case Cell.CELL_TYPE_BOOLEAN:

						break;
					case Cell.CELL_TYPE_ERROR:

						break;
					}
					if (cellstring != null) {
						if (!(cellstring.equalsIgnoreCase("")))
							return false;
					}
				}
			}
		}
		return true;
	}

	public ArrayList<String> validateMandateField(String mandatary, int rowno,
			ArrayList<String> Error, String headername) {

		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateMandateField", "mandatary filed start method :"+mandatary);
		
		String error = null;

		if (mandatary.equalsIgnoreCase("M")) {
			error = "Row number " + (rowno + 1) + "#" + headername
					+ " is Mandatory. It cannot be empty.";
			System.out.println(error);
			FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateMandateField", "Error :"+error);

			Error.add(error);

		} else {
			FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateMandateField", "Optional blank :");
			System.out.println(headername + " : Optional blank");
		}
		return Error;
	}

	public ArrayList<String> validateLength(String cellvalue, int colSize,
			int rowno, ArrayList<String> Error, String headername) {
		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateLength", "validateLength :");
		
		if (cellvalue.length() <= colSize) {
			
			FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateLength", " length is ok :");
			System.out.println(headername + " length is ok.");
		} else {
			String error = "Row number " + (rowno + 1) + "#" + headername
					+ " is more than required size.";
			System.out.println(error);
			FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateLength", " Error :"+error);
			Error.add(error);
		}

		return Error;
	}
	
	public ArrayList<String> validateDefaultValue(String cellvalue,
			int rowno, ArrayList<String> Error, String headername, String defaultValue) {
		
		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateDefaultValue", " Start method :");
		if(defaultValue == null){
			return Error;
		}else {
			if(defaultValue.equals(""))
				return Error;
		}
		if (cellvalue.equals(defaultValue)) {
			FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateDefaultValue", "default value is ok.");

			System.out.println(headername + " default value is ok.");
		} else {
			String error = "Row number " + (rowno + 1) + "#" + headername
					+ " value should be ."+defaultValue+".";
			System.out.println(error);
			
			FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateDefaultValue", "Error" +error);

			Error.add(error);
		}

		return Error;
	}
	
	public ArrayList<String> validateSpecialCharacters(String cellString,
			int rowNo, ArrayList<String> Error, String headername,HashMap<String,String> expression) {
		
		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateSpecialCharacters", " Start method headerPatten : "+expression.keySet());
       
		System.out.println("headerPatten**********************"+expression.keySet());
		String error = null;
		String pattern = null;
		String SPECIAL_PATTERN = "^[a-zA-Z0-9\\s$+,:-;=?@#|<>.^*%!]*$";
		//String DATE_PATTERN = "^[A-Za-z0-9\\s:]*$";
		
		
		String DATE_PATTERN="\\d{2}-\\d{2}-\\d{4}";
		String NAME_PATTERN = "^[A-Za-z\\s]*$";
		
		String str = headername.toLowerCase();
		boolean isDate = str.contains("date");
		boolean isName = str.contains("name");

		if (cellString != null) {
			if (cellString.equalsIgnoreCase("")) {
				
				FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateSpecialCharacters", " Cell is blank. : ");

				System.out.println("Cell is blank.");
			} else {
				if(expression!=null && expression.containsKey(headername)){
					pattern=expression.get(headername);
					System.out.println("HeaderPattern**********"+pattern);
				}
				else if(isDate){
					pattern = DATE_PATTERN;
				} else if(isName){
					pattern = NAME_PATTERN;
				} 
				else{
					pattern = SPECIAL_PATTERN;
				}
				if (cellString.matches(pattern)) {
					
					FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateSpecialCharacters", " Special Database characters validation is done for. : "+headername);

					System.out
							.println("Special Database characters validation is done for "+headername);
				} else {
					error = "Row number " + (rowNo + 1) + "#" + headername
							+ " is not valid.";
					
					FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateSpecialCharacters", " error : "+error);

					System.out.println(error);
					Error.add(error);
				}
			}
		}
		return Error;
	}

	public ArrayList<String> validateString(Cell cell, int rowNo,
			ArrayList<String> Error, String headername, String mandatary,
			int colSize, HashMap<String,String> expression, String headerDefaultValue) {
		
		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateString", " validateString : ");

		String error = null;
		if (cell != null) {
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_NUMERIC:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " cannot be numeric. It should be text.";
				System.out.println(error);
				Error.add(error);
				break;
			case Cell.CELL_TYPE_STRING:
				String cellString = cell.getStringCellValue();
				if (cellString == null) {
					Error = validateMandateField(mandatary, rowNo, Error,
							headername);
				} else {
					if (cellString.equalsIgnoreCase("")) {
						Error = validateMandateField(mandatary, rowNo, Error,
								headername);
					} else {
						Error = validateDefaultValue(cellString, rowNo, Error, headername, headerDefaultValue);
						Error = validateLength(cellString, colSize, rowNo,
								Error, headername);
						Error = validateSpecialCharacters(cellString, rowNo, Error, headername,expression);
					}
				}
				break;
			case Cell.CELL_TYPE_FORMULA:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " cannot have formula. It should be text.";
				System.out.println(error);
				Error.add(error);
				break;
			case Cell.CELL_TYPE_BLANK:
				Error = validateMandateField(mandatary, rowNo, Error,
						headername);
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " cannot be true/false. It should be text.";
				System.out.println(error);
				Error.add(error);
				break;
			case Cell.CELL_TYPE_ERROR:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " have error. It should be text.";
				System.out.println(error);
				Error.add(error);
				break;
			}
		} else {
			Error = validateMandateField(mandatary, rowNo, Error, headername);
		}

		return Error;
	}

	public ArrayList<String> validateInteger(Cell cell, int rowNo,
			ArrayList<String> Error, String headername, String mandatary,
			int colSize, HashMap<String,String> expression, String headerDefaultValue) {

		String error = null;
		if (cell != null) {
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_NUMERIC:
				String cellString = String.valueOf(cell.getNumericCellValue());
				double cellInt ;
				if (cellString == null) {
					Error = validateMandateField(mandatary, rowNo, Error,
							headername);
				} else {
					if (cellString.equalsIgnoreCase("")) {
						Error = validateMandateField(mandatary, rowNo, Error,
								headername);
					} else if (cellString.contains("E")
							|| cellString.contains("e")) {
						cellString = BigDecimal
							.valueOf(cell.getNumericCellValue())
								.toPlainString();
						//cellString = new BigDecimal(cell.getNumericCellValue())+"";
						
					} else {
						cellString = cellString.substring(0,
								(cellString.length() - 2));
					}
				}
				if (cellString == null) {
					Error = validateMandateField(mandatary, rowNo, Error,
							headername);
				} else {
					if (cellString.equalsIgnoreCase("")) {
						Error = validateMandateField(mandatary, rowNo, Error,
								headername);
					} else {
						Error = validateDefaultValue(cellString, rowNo, Error, headername, headerDefaultValue);
						Error = validateLength(cellString, colSize, rowNo, Error,
								headername);
						Error = validateSpecialCharacters(cellString, rowNo, Error, headername,expression);
					}
				}
				break;
			case Cell.CELL_TYPE_STRING:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " cannot be text. It should be numeric.";
				System.out.println(error);
				Error.add(error);
				break;
			case Cell.CELL_TYPE_FORMULA:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " cannot have formula. It should be numeric.";
				System.out.println(error);
				Error.add(error);
				break;
			case Cell.CELL_TYPE_BLANK:
				Error = validateMandateField(mandatary, rowNo, Error,
						headername);
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " cannot be true/false. It should be numeric.";
				System.out.println(error);
				Error.add(error);
				break;
			case Cell.CELL_TYPE_ERROR:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " have error. It should be numeric.";
				System.out.println(error);
				Error.add(error);
				break;
			}
		} else {
			Error = validateMandateField(mandatary, rowNo, Error, headername);
		}

		return Error;
	}

	public ArrayList<String> validateAlpha(Cell cell, int rowNo,
			ArrayList<String> Error, String headername, String mandatary,
			int colSize, HashMap<String,String> expression, String headerDefaultValue) {
		
		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateAlpha", " validateAlpha method Start : ");

		String error = null;
		if (cell != null) {
			String cellString = null;
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_NUMERIC:
				cellString = String.valueOf(cell.getNumericCellValue());
				String cellInt = null;
				if (cellString == null) {
					Error = validateMandateField(mandatary, rowNo, Error,
							headername);
				} else {
					if (cellString.equalsIgnoreCase("")) {
						Error = validateMandateField(mandatary, rowNo, Error,
								headername);
					} else if (cellString.contains("E")
							|| cellString.contains("e")) {
						cellString = BigDecimal
								.valueOf(cell.getNumericCellValue())
								.toPlainString();
					} else {
						cellString = cellString.substring(0,
								(cellString.length() - 2));
					}
				}
				if (cellString == null) {
					Error = validateMandateField(mandatary, rowNo, Error,
							headername);
				} else {
					if (cellString.equalsIgnoreCase("")) {
						Error = validateMandateField(mandatary, rowNo, Error,
								headername);
					} else {
						Error = validateDefaultValue(cellString, rowNo, Error, headername, headerDefaultValue);
						Error = validateLength(cellString, colSize, rowNo, Error,
								headername);
						Error = validateSpecialCharacters(cellString, rowNo, Error, headername,expression);
					}
				}
				break;
			case Cell.CELL_TYPE_STRING:
				cellString = cell.getStringCellValue();
				if (cellString == null) {
					Error = validateMandateField(mandatary, rowNo, Error,
							headername);
				} else {
					if (cellString.equalsIgnoreCase("")) {
						Error = validateMandateField(mandatary, rowNo, Error,
								headername);
					} else {
						Error = validateDefaultValue(cellString, rowNo, Error, headername, headerDefaultValue);
						Error = validateLength(cellString, colSize, rowNo,
								Error, headername);
						Error = validateSpecialCharacters(cellString, rowNo, Error, headername,expression);
					}
				}
				break;
			case Cell.CELL_TYPE_FORMULA:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " cannot have formula. It should be numeric.";
				System.out.println(error);
				Error.add(error);
				break;
			case Cell.CELL_TYPE_BLANK:
				Error = validateMandateField(mandatary, rowNo, Error,
						headername);
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " cannot be true/false. It should be numeric.";
				System.out.println(error);
				Error.add(error);
				break;
			case Cell.CELL_TYPE_ERROR:
				error = "Row number " + (rowNo + 1) + "#" + headername
						+ " have error. It should be numeric.";
				System.out.println(error);
				Error.add(error);
				break;
			}
		} else {
			Error = validateMandateField(mandatary, rowNo, Error, headername);
		}

		return Error;
	}

	public ArrayList<String> validateDate(Cell cell, int rowNo,
			ArrayList<String> Error, String headername, String mandatary,
			int colSize,HashMap<String,String> expression, String headerDefaultValue) {
		
		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateDate", " Inside validate date : ");

		System.out.println("Inside validate date");
		
		String error = null;
		if (cell != null) {
				switch (cell.getCellType()) {
				case Cell.CELL_TYPE_NUMERIC:
					//Date cellDate=convertDateFormat(cell.getDateCellValue());
					Date cellDate = cell.getDateCellValue();
					System.out.println("*****************************Date in excel :"+cellDate);
					FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateDate", " Date in excel : "+cellDate);

					if (cellDate == null) {

						Error = validateMandateField(mandatary, rowNo, Error,
								headername);
					} else {
						String dateString = cellDate.toString();
						if (dateString.equalsIgnoreCase("")) {

							Error = validateMandateField(mandatary, rowNo,
									Error, headername);
						} else {
							SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");//dd-MMM-yy
							dateString = sdf.format(cell.getDateCellValue());
							
							Error = validateDefaultValue(dateString, rowNo, Error, headername, headerDefaultValue);
							Error = validateSpecialCharacters(dateString, rowNo, Error, headername,expression);
						}
					}
					break;
				case Cell.CELL_TYPE_STRING:
					error = "Row number " + (rowNo + 1) + "#" + headername
							+ " cannot be text. It should be date with dd-mm-yy format.";
					System.out.println(error);
					Error.add(error);
					break;
				case Cell.CELL_TYPE_FORMULA:
					error = "Row number " + (rowNo + 1) + "#" + headername
							+ " cannot have formula. It should be date with dd-mmm-yy format.";
					System.out.println(error);
					Error.add(error);
					break;
				case Cell.CELL_TYPE_BLANK:
					Error = validateMandateField(mandatary, rowNo, Error,
							headername);
					break;
				case Cell.CELL_TYPE_BOOLEAN:
					error = "Row number " + (rowNo + 1) + "#" + headername
							+ " cannot be true/false. It should be date with dd-mmm-yy format.";
					System.out.println(error);
					Error.add(error);
					break;
				case Cell.CELL_TYPE_ERROR:
					error = "Row number " + (rowNo + 1) + "#" + headername
							+ " have error. It should be date with dd-mmm-yy format.";
					System.out.println(error);
					Error.add(error);
					break;
				}
		} else {
			Error = validateMandateField(mandatary, rowNo, Error, headername);
		}
		FLogger.info("ClaimExcelValidationScheduler", "ExcelValidator","validateDate", " Error : "+Error);

		return Error;
	}
	
	
	
}
