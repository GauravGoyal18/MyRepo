package com.tcs.excelValidation;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.TreeMap;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

public class ExcelHelper {
	private ExcelReader excelReader;
	private ExcelValidator excelValidator;

	public ExcelHelper() throws Exception {
		excelReader = new ExcelReader();
		excelValidator = new ExcelValidator();
		// path = "D:/AmrutaEclipse/Excel/src/ExcelUploads/uploadedFile.xls";

	}

	public static String cellToString(Cell cell) {
		int type;
		String result = "";
		if (cell != null) {
			type = cell.getCellType();

			switch (type) {

			case Cell.CELL_TYPE_NUMERIC: // numeric value in Excel
				if (cell != null) {
					if (HSSFDateUtil.isCellDateFormatted(cell)) {
						Date cellDate = cell.getDateCellValue();
						result = cellDate.toString();
					} else {
						if(cell.getNumericCellValue()%1==0)
						{
						long r = (long) cell.getNumericCellValue();
						result = String.valueOf(r);
						}
						else
						{
							double r = cell.getNumericCellValue();
							result = String.valueOf(r);
						}
						
					}
				} else {
					result = "";
				}
				break;
			case Cell.CELL_TYPE_STRING: // String Value in Excel
				result = cell.getStringCellValue();
				break;
			case Cell.CELL_TYPE_FORMULA:
				result = cell.getCellFormula();
				break;
			case Cell.CELL_TYPE_BLANK:
				result = "";
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				boolean flag = cell.getBooleanCellValue();
				result = ((Boolean) flag).toString();
				break;
			case Cell.CELL_TYPE_ERROR:
				byte error = cell.getErrorCellValue();
				result = ((Byte) error).toString();
				break;

			default:
				// throw new
				// RuntimeException("There is no support for this type of cell");
				result = null;
			}
		}
		return result.toString();
	}

	public TreeMap<String, ArrayList> readExcel(Sheet sheet, String property,
			HashMap<String, String> expression) {

		TreeMap<String, ArrayList> data = new TreeMap<String, ArrayList>();
		ArrayList<ArrayList> sheetData = new ArrayList<ArrayList>();
		ArrayList<String> Error = new ArrayList<String>();
		String error = null;

		if (sheet == null) {
			error = "Error#Excel Sheet is null.";
			Error.add(error);
			System.out.println(error);
			data.put("Error", Error);
			return data;
		}

		// ****************** Going to read XML file for header details
		// ****************
		ArrayList<HeaderBean> headerList = new ArrayList<HeaderBean>();
		ArrayList<String> headerNameList = new ArrayList<String>();
		ArrayList<String> sheetHeaderNameList = new ArrayList<String>();
		HeaderUtil headerUtil;
		int rowNo, colNo, lastRow, lastCol;

		try {
			headerUtil = new HeaderUtil(property);
			if (headerUtil == null) {
				System.out.println("headerUtil is null");
			} else {
				headerList = (ArrayList<HeaderBean>) headerUtil.getHeaderList();
				headerNameList = (ArrayList<String>) headerUtil
						.getHeaderNameList();
				System.out.println("headerList : " + headerList);
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception came while reading data from XML.");
			error = "Error#Some Error occured. Please try again Later.";
			Error.add(error);
			System.out.println(error);
			data.put("Error", Error);
			return data;
		}

		sheetHeaderNameList = getSheetHeaders(sheet);
		System.out.println("sheetHeaderNameList : " + sheetHeaderNameList);

		if (matchHeaders(sheetHeaderNameList, headerNameList)) {
			System.out.println("Headers are matched.");
			Error = excelValidator.checkEmptyRows(sheet, Error);
			if (Error.isEmpty()) {
				System.out.println("Empty rows validation is fine.");
				lastRow = getNoOfRows(sheet);
				System.out.println("lastRow : " + lastRow);
				lastCol = sheet.getRow(0).getLastCellNum();
				System.out.println("lastCol : " + lastCol);
				for (rowNo = 1; rowNo <= lastRow; rowNo++) {

					Row row = sheet.getRow(rowNo);
					if (row != null) {
						ArrayList rowData = new ArrayList();
						for (colNo = 0; colNo < lastCol; colNo++) {
							HeaderBean headerBean = headerList.get(colNo);
							String headerName = null;
							String headerType = null;
							String headerDefaultValue = null;
							int headerSize = 0;
							String headerMandatory = null;
							// String headerPatten= null;
							if (headerBean != null) {
								headerName = headerBean.getHeaderName();
								headerType = headerBean.getHeaderType();
								headerSize = headerBean.getHeaderSize();
								headerMandatory = headerBean
										.getHeaderMandatary();
								headerDefaultValue = headerBean
										.getHeaderDefaultValue();
								// headerPatten=headerBean.getHeaderPattern();
								System.out
										.println("Header headerMandatory*************"
												+ headerMandatory);
								// System.out.println("Header pattern buffer*************"+headerPatten);
							}

							Cell cell = row.getCell(colNo);

							if (headerType.equalsIgnoreCase("String")) {
								Error = excelValidator.validateString(cell,
										rowNo, Error, headerName,
										headerMandatory, headerSize,
										expression, headerDefaultValue);
								if (Error.isEmpty()) {
									if (cell == null) {
										rowData.add("");
									} else {
										rowData.add(cell.getStringCellValue());
									}

								}
							} else if (headerType.equalsIgnoreCase("int")) {
								Error = excelValidator.validateInteger(cell,
										rowNo, Error, headerName,
										headerMandatory, headerSize,
										expression, headerDefaultValue);
								if (Error.isEmpty()) {
									if (cell == null) {
										rowData.add(0);
									} else {
										double cellDoubleValue = cell.getNumericCellValue();
										//String cellString222 = new BigDecimal(cell.getNumericCellValue())+"";
										int cellIntValue = (int) cellDoubleValue;
										rowData.add(cellIntValue);
									}
								}
							} else if (headerType.equalsIgnoreCase("long")) {
								Error = excelValidator.validateInteger(cell,
										rowNo, Error, headerName,
										headerMandatory, headerSize,
										expression, headerDefaultValue);
								if (Error.isEmpty()) {
									if (cell == null) {
										rowData.add(0);
									} else {
										double cellDoubleValue = cell
												.getNumericCellValue();
										
									//	String cellString = new BigDecimal(cell.getNumericCellValue())+"";
										
										long cellLongValue = (long) (cellDoubleValue);
										
										rowData.add(cellLongValue);
									}
								}
							} else if (headerType.equalsIgnoreCase("double")) {
								Error = excelValidator.validateInteger(cell,
										rowNo, Error, headerName,
										headerMandatory, headerSize,
										expression, headerDefaultValue);
								if (Error.isEmpty()) {
									if (cell == null) {
										rowData.add(0.0);
									} else {
										double cellDoubleValue = cell
												.getNumericCellValue();
										rowData.add(cellDoubleValue);
									}
								}
							} else if (headerType.equalsIgnoreCase("date")) {
								String dateString = null;
								Error = excelValidator.validateDate(cell,
										rowNo, Error, headerName,
										headerMandatory, headerSize,
										expression, headerDefaultValue);
								if (Error.isEmpty()) {
									if (cell == null) {
										dateString = "01-JAN-01";
									} else {
										Date dateValue = cell
												.getDateCellValue();
										if (dateValue == null) {
											dateString = "01-JAN-01";
										} else {
											SimpleDateFormat sdf = new SimpleDateFormat(
													"dd-MMM-yyyy");
											dateString = sdf.format(dateValue);
										}
									}
									rowData.add(dateString);
								}
							} else if (headerType.equalsIgnoreCase("alpha")) {
								Error = excelValidator.validateAlpha(cell,
										rowNo, Error, headerName,
										headerMandatory, headerSize,
										expression, headerDefaultValue);
								if (Error.isEmpty()) {
									if (cell == null) {
										rowData.add("");
									} else {
										switch (cell.getCellType()) {
										case Cell.CELL_TYPE_NUMERIC:
											rowData.add((int) cell.getNumericCellValue());
											break;
										case Cell.CELL_TYPE_STRING:
											rowData.add(cell.getStringCellValue());
											break;
										}
									}
								}
							} else if (headerType.equalsIgnoreCase("percent")) {
								Error = excelValidator.validateInteger(cell,
										rowNo, Error, headerName,
										headerMandatory, headerSize,
										expression, headerDefaultValue);
								if (Error.isEmpty()) {
									if (cell == null) {
										rowData.add(0.0);
									} else {
										rowData.add(cell.getNumericCellValue());
									}
								}
							}

							else if (headerType.equalsIgnoreCase("all")) {

								rowData.add(ExcelHelper.cellToString(cell));

							}

						} // End of For Loop for colNo.
						if (Error.isEmpty()) {
							sheetData.add(rowData);
						}
					}
				} // End of For Loop for rowNo.

				if (Error.isEmpty()) {
					data.put("Success", sheetData);
				} else {
					data.put("Error", Error);
				}
			} else {
				data.put("Error", Error);
			}
		} else {
			error = "Error#Headers in excel are not matching with required format.";
			Error.add(error);
			System.out.println(error);
			data.put("Error", Error);
		}

		return data;
	}

	public ArrayList<String> getSheetHeaders(Sheet sheet) {
		ArrayList<String> sheetHeaders = new ArrayList<String>();
		int lastrow = sheet.getLastRowNum() + 1;
		int lastcol = sheet.getRow(0).getLastCellNum();
		int rowno, colno = 0;
		int i;
		String cellstringvalue = null;

		Row rowHeader = sheet.getRow(0);
		for (i = 0; i < lastcol; i++) {
			Cell cell = rowHeader.getCell(i);
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_NUMERIC:
				int cellintvalue = (int) cell.getNumericCellValue();
				cellstringvalue = ((Integer) cellintvalue).toString();
				sheetHeaders.add(cellstringvalue);
				break;
			case Cell.CELL_TYPE_STRING:
				cellstringvalue = cell.getStringCellValue();
				sheetHeaders.add(cellstringvalue);
				break;
			case Cell.CELL_TYPE_FORMULA:
				sheetHeaders.add("null");
				break;
			case Cell.CELL_TYPE_BLANK:
				sheetHeaders.add("null");
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				sheetHeaders.add("null");
				break;
			case Cell.CELL_TYPE_ERROR:
				sheetHeaders.add("null");
				break;
			}
		}
		return sheetHeaders;
	}

	public boolean matchHeaders(ArrayList<String> sheetHeaders,
			ArrayList<String> headerNameList) {

		if (headerNameList != null) {
			if (sheetHeaders != null) {
				if (sheetHeaders.size() == headerNameList.size()) {
					for (int i = 0; i < sheetHeaders.size(); i++) {
						String sheetHeaderString = sheetHeaders.get(i);
						String headerNameString = headerNameList.get(i);

						if (headerNameString != null) {
							if (sheetHeaderString != null) {
								if (!(headerNameString
										.equalsIgnoreCase(sheetHeaderString)))
									return false;
							} else
								return false;
						}
					}
				} else
					return false;
			} else
				return false;
		}

		return true;
	}

	public int getNoOfRows(Sheet sheet) {
		int NoOfRows = 0;

		if (sheet != null) {
			NoOfRows = sheet.getLastRowNum();
		}

		// System.out.println("No of Rows : " + NoOfRows);

		return NoOfRows;
	}
}
