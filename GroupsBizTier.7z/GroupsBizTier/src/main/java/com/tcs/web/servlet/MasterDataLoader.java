package com.tcs.web.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ipru.MasterDataService;
import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.PolicyProductFundMasterVO;
import com.ipru.groups.vo.PolicyValidMasterVO;
import com.ipru.groups.vo.ProductFundMasterVO;
import com.ipru.groups.vo.ProductMasterVO;
import com.ipru.groups.vo.ProductSwitchAmountVO;
import com.tcs.PropertyLoader.PropertyLoader;
import com.tcs.caching.CacheProvider;
import com.tcs.exception.WebServiceClientException;
import com.tcs.logger.FLogger;
import com.tcs.pdfgenerator.util.PDFGeneratorUtils;
import com.tcs.wsconfig.wsclient.WebserviceClientConfigurator;

/**
 * Servlet implementation class MasterDataLoader
 */
public class MasterDataLoader extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	//loading static terracotta cache variables
	public static CacheProvider s_ObjCacheProvider = null;
	// loading static properties files
	//public static Properties CONSTANT_IPRUCONFIG_WEBSERVICEURI_PROPERTIES =propertyFileLoader(GroupCommonConstants.CONSTANT_IPRUCONFIG_WEBSERVICEURI);
	
//	public static String SUBENV = null;
	
    /**
     * @throws Exception 
     * @see HttpServlet#HttpServlet()
     */
    public MasterDataLoader() throws Exception {
    	
    	
        super();
       
        MasterPropertiesFileLoader.loadMasterPropertiesFile();
        // TODO Auto-generated constructor stub
    }
    
	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);

		

		// loading ehcache::::::::::
		
		try {
			WebserviceClientConfigurator.reloadWsConfig();
			createFTLConfigInstance();

			Properties prop=new Properties();
			prop=MasterPropertiesFileLoader.CONSTANT_CACHE_MODE_TERACOTTA_PROPERTIES;
			
			
			//String CachingModeTeracotta=prop.getProperty("CachingModeTeracotta");
			ArrayList<String> finalBigListUrls =null;
			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;
			List<ProductMasterVO> productMasterVoList = null;
			List<FundMasterVO> fundMasterVoList = null;
			List<ProductFundMasterVO> productFundMasterVoList = null;
			List<ProductSwitchAmountVO> productSwitchAmountVoList = null;
			List<PolicyValidMasterVO> policyValidMasterVoList = null;
			List<FunctionalityMasterVO> functionalityList = null;
			List<String> gstPolicyList = null;
			List<PolicyProductFundMasterVO> policyProductFundMasterList = null;
//			SUBENV = (String)config.getServletContext().getInitParameter("SUBENV"); 
			final String SUBENV = PropertyLoader.getInstance().getSubEnv();
			FLogger.error("GROUPLogger", "MasterDataLoader", "init", "**********SUBENV******::"+SUBENV);
			
			if(!"SCH".equalsIgnoreCase(SUBENV)){
				////System.out.println(" ==  in  if SUBENV==="+SUBENV);
			finalBigListUrls=(ArrayList<String>) MasterDataService.getAllUrls();		
			config.getServletContext().setAttribute(ContextKeyConstants.URL_BUSINESSPARAM, finalBigListUrls);
			//////System.out.println(" in prorp file data"+finalBigListUrls);

//			fieldAccessMappingVoList = MasterDataService.getFieldAccessMappingList();		
//			config.getServletContext().setAttribute(ContextKeyConstants.FIELDACCESSMAPPING_LIST, fieldAccessMappingVoList);
			}
			productMasterVoList = MasterDataService.getProductMasterList();		
			config.getServletContext().setAttribute(ContextKeyConstants.PRODUCT_MASTER_LIST, productMasterVoList);
			
			
			fundMasterVoList = MasterDataService.getFundMasterList();		
			config.getServletContext().setAttribute(ContextKeyConstants.FUND_MASTER_LIST, fundMasterVoList);
			
			productFundMasterVoList = MasterDataService.getProductFundMasterList();		
			config.getServletContext().setAttribute(ContextKeyConstants.PRODUCT_FUND_MASTER_LIST, productFundMasterVoList);
			
			productSwitchAmountVoList = MasterDataService.getProductProductSwitchAmountMasterList();		
			config.getServletContext().setAttribute(ContextKeyConstants.PRODUCT_SWITCH_AMOUNT_MASTER_LIST, productSwitchAmountVoList);
			
			policyValidMasterVoList = MasterDataService.getPolicyValidMasterList();		
			config.getServletContext().setAttribute(ContextKeyConstants.POLICY_VALID_MASTER_LIST, policyValidMasterVoList);
			
			config.getServletContext().setAttribute(ContextKeyConstants.CONCURRENT_SESSION_MAP_CONTEXT, new ConcurrentHashMap<String, Object>(1));
			
			functionalityList = MasterDataService.getFunctionalityList();
			config.getServletContext().setAttribute(ContextKeyConstants.FUNCTIONALITY_LIST, functionalityList);
			
			//gstPolicyList = MasterDataService.getGstPolicyList();
			//config.getServletContext().setAttribute(ContextKeyConstants.GST_POLICY_LIST, gstPolicyList);
			
			policyProductFundMasterList = MasterDataService.getPolicyProductFundList();
			config.getServletContext().setAttribute(ContextKeyConstants.POLICY_PRODUCT_FUND_MASTER_LIST, policyProductFundMasterList);
		}
		catch (WebServiceClientException e) {
			FLogger.error("GROUPLogger", "MasterDataLoader", "init", "Error while loading webservice client config", e);
			throw new ServletException();
		}
		catch (Exception e) {
			FLogger.error("GROUPLogger", "MasterDataLoader", "init", "Error while start up", e);
			throw new ServletException();
		}
}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	
	private static void createFTLConfigInstance() {
		List<String> filePaths = new ArrayList<String>(1);
		filePaths.add(GroupConstants.CONSTANT_C+MasterPropertiesFileLoader.CONSTANT_TEMPLATE_PROPERTIES.getProperty("SPAARC_TMPL_PATH"));
		filePaths.add(GroupConstants.CONSTANT_C+MasterPropertiesFileLoader.CONSTANT_TEMPLATE_PROPERTIES.getProperty("PDF_TMPL_PATH"));

		
		PDFGeneratorUtils.getFTLConfigInstance(filePaths);
	}
}
