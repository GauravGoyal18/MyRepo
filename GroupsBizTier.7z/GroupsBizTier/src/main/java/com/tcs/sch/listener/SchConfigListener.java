package com.tcs.sch.listener;

import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.tcs.PropertyLoader.PropertyLoader;
import com.tcs.config.ConfigManager;
import com.tcs.logger.FLogger;

public class SchConfigListener implements ServletContextListener {
	public void contextDestroyed(ServletContextEvent arg0) {
	}

	public void contextInitialized(ServletContextEvent event) {
		FLogger.info("INeoLog", "INEOSystemOut", "SystemOut", "Context name:::");

		String configdirectory = PropertyLoader.configdirectory;
		FLogger.info("INeoLog", "INEOSystemOut", "SystemOut",
				"contextInitialized called");
		FLogger.info(
				"INeoLog",
				"INEOSystemOut",
				"SystemOut",
				"Config Directory of this application:::::::::::::::::::::::::::::::------------>>>>>>>>>>"
						+ configdirectory);
		String loggerInitFile = configdirectory.concat(PropertyLoader
				.getInstance().getProperty("sch_logger_file"));

		FLogger.info("INeoLog", "INEOSystemOut", "SystemOut",
				"LoogerFilePath :::::::::::::::::::::::::::::::------------>>>>>>>>>>"
						+ loggerInitFile);
		FLogger.info("INeoLog", "INEOSystemOut", "SystemOut",
				"loggerInitFile -> " + loggerInitFile);
		if (loggerInitFile == null) {
			throw new Error("Servlet Init parameter LOGGER_INIT_FILE not set");
		}

		try {
			FLogger.initialize(loggerInitFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String SUBENV = event.getServletContext().getInitParameter("SUBENV");
		if (SUBENV == null) {
			FLogger.error("INeoLog", "INEOSystemOut", "SystemOut",
					"Servlet Init parameter SUBENV not set -> ");

			throw new Error(
					"Servlet Init parameter SUBENV not set. The valid values for the same are APP and SCH");
		}
		PropertyLoader.getInstance().setSubEnv(SUBENV);

		String configInitFile = configdirectory.concat(PropertyLoader
				.getInstance().getProperty("config_file"));
		FLogger.info("INeoLog", "INEOSystemOut", "SystemOut",
				"ConfigFilePath :::::::::::::::::::::::::::::::------------>>>>>>>>>>"
						+ configInitFile);
		if (configInitFile == null) {
			throw new Error("Servlet Init parameter CONFIG_INIT_FILE not set");
		}
		ConfigManager.INSTANCE.initialize(configInitFile);
	}
}
