/**
 * 
 */
package com.tcs.ipru.security;

import javax.servlet.ServletException;

import com.tcs.logger.FLogger;

/**
 * @author IPRU25568
 *
 */
public class SecurityFilterException extends ServletException {



	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String exceptionMsg="";
	private Throwable ex;

	public SecurityFilterException(String exceptionMessage) 
	{
		this.exceptionMsg=exceptionMessage;
		FLogger.error("securityLoggerError","SecurityFilterException","SecurityFilterException(Throwable ex)","Security Exception:::"+this.exceptionMsg,this.ex);

	}

	public SecurityFilterException(Throwable ex) 
	{
		this.ex = ex;
		this.exceptionMsg=ex.getMessage();
		FLogger.error("securityLoggerError","SecurityFilterException","SecurityFilterException(Throwable ex)","Security Exception:::"+this.exceptionMsg,this.ex);

	}

	public SecurityFilterException(String exceptionMessage,Throwable ex) 
	{
		this.ex = ex;
		this.exceptionMsg=exceptionMessage;
		FLogger.error("securityLoggerError","SecurityFilterException","SecurityFilterException(Throwable ex)","Security Exception:::"+exceptionMessage,this.ex);
	}

	public void setMessage(String msg) {
		exceptionMsg=msg;
	}

	public String getMessage(){
		return exceptionMsg;
	}

	@Override
	public String toString() {
		return "SecurityFilterException [exceptionMsg=" + exceptionMsg + ", ex=" + ex
				+ "]";
	}





}
