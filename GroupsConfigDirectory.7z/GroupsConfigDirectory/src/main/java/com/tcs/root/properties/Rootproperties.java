package com.tcs.root.properties;

public class Rootproperties {

}
