package org.springframework.security.concurrent;

import java.io.Serializable;

import org.springframework.security.core.session.SessionIdentifierAware;


public class SessionIdentifier implements SessionIdentifierAware, Serializable
{
	String sessionid = "";

	@Override
	public String getSessionId() {
		// TODO Auto-generated method stub
		return sessionid;
	}
	
	
	
	public void setSessionId(String sessionid ){
		this.sessionid= sessionid;
		
		
	}
	

}
