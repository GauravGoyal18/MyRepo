package com.thetransactioncompany.cors;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.logger.FLogger;

public class CORSFilter
  implements Filter
{
  private CORSConfiguration config;
  private CORSRequestHandler handler;

  public CORSFilter()
  {
  }

  public CORSFilter(CORSConfiguration config)
  {
    setConfiguration(config);
  }

  public void setConfiguration(CORSConfiguration config)
  {
    this.config = config;
    this.handler = new CORSRequestHandler(config);
  }

  public CORSConfiguration getConfiguration()
  {
    return this.config;
  }

   /** Rupangi :: variabe created for logging purpose **/ 
	HashSet<String> setList =  new HashSet<String>();

  public void init(FilterConfig filterConfig)
    throws ServletException
  {
    CORSConfigurationLoader configLoader = new CORSConfigurationLoader(filterConfig);
    try
    {
      setConfiguration(configLoader.load());
    }
    catch (CORSConfigurationException e)
    {
      throw new ServletException(e.getMessage(), e);
    }
  }

  private void printMessage(CORSException corsException, HttpServletResponse response)
    throws IOException, ServletException
  {
	  ////System.out.println("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
    response.setStatus(corsException.getHTTPStatusCode());
    response.resetBuffer();
    response.setContentType("text/plain");
    PrintWriter out = response.getWriter();
    out.println("Cross-Origin Resource Sharing (CORS) Filter: " + corsException.getMessage());
	FLogger.info("securityLogger","CORSFilter", "doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)", "Error :: " + corsException.getMessage() + corsException.getLocalizedMessage() + ";Cause :: " +corsException.getCause());
  }

  private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
	CORSRequestType type = CORSRequestType.detect(request);
	if (request.getHeader("Origin") != null) {
	Boolean addElement = setList.add(request.getHeader("Origin"));
		for (String a  : setList) {
			if(addElement && a.equals(request.getHeader("Origin")) && !(this.config.allowedOrigins.contains(request.getHeader("Origin")))) {
				FLogger.info("securityLogger","CORSFilter", "doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)", type + "::" + "RequestOrigin :: "+request.getHeader("Origin")+ "::" + "RequestHeader :: "+request.getHeader("Access-Control-Request-Headers"));
		}
		}
	}
	
    if (this.config.tagRequests)
      RequestTagger.tag(request, type);
    try
    {
      if (type.equals(CORSRequestType.ACTUAL))
      {
        this.handler.handleActualRequest(request, response);

        CORSResponseWrapper responseWrapper = new CORSResponseWrapper(response);

        chain.doFilter(request, responseWrapper);
      }
      else if (type.equals(CORSRequestType.PREFLIGHT))
      {
        this.handler.handlePreflightRequest(request, response);
      }
      else if (this.config.allowGenericHttpRequests)
      {
        chain.doFilter(request, response);
      }
      else
      {
        printMessage(CORSException.GENERIC_HTTP_NOT_ALLOWED, response);
      }
    }
    catch (CORSException e) {
      printMessage(e, response);
    }
  }

  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException
  {
    if (((request instanceof HttpServletRequest)) && ((response instanceof HttpServletResponse)))
    {
      doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
    }
    else
    {
      throw new ServletException("Cannot filter non-HTTP requests/responses");
    }
  }

  public void destroy()
  {
  }
}