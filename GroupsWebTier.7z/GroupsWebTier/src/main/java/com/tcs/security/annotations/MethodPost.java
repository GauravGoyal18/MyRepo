/**
 * 
 */
package com.tcs.security.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * @author Susanta Ghosh
 */
@Documented
@Target(java.lang.annotation.ElementType.METHOD)
@Retention(value = java.lang.annotation.RetentionPolicy.RUNTIME)
public @interface MethodPost {

}
