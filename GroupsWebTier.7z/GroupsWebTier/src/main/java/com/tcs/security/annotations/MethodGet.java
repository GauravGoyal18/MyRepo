/**
 * 
 */
package com.tcs.security.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * @author Hiren Sonawala
 * @Reviewed by Ameya Nerurkar
 * This annotation should be used for handler methods which are used in GET as well as POST requests. 
 * The methods should not contain any changes regarding system state change. The methods are used only for Frontend and Backend Validations.
 */
@Documented
@Target(java.lang.annotation.ElementType.METHOD)
@Retention(value = java.lang.annotation.RetentionPolicy.RUNTIME)
public @interface MethodGet {

}
