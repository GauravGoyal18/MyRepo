/**
 * 
 */
package com.tcs.security.encryption.filter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.lang3.StringUtils;

import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.security.user.IPruUser;
import com.tcs.security.encryption.util.JCryptionUtil;


/**
 * @author Susanta Ghosh
 *
 */
public class WrapRequestFilter implements Filter {

	  private static final String PARAM = "jc_param";
	  private Properties ipAddressObtained = new Properties();
	  private IPruUser userVO;
	/* (non-Javadoc)
	 * @see javax.servlet.Filter#destroy()
	 */
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}
	//Added by Hiren Sonawala
	private  Properties loadProperties(){
		
		//if(ipAddressObtained==null){
		try {
			if (MasterPropertiesFileLoader.CONSTANT_JCRYPTION_URL != null) {
				ipAddressObtained = MasterPropertiesFileLoader.CONSTANT_JCRYPTION_URL;
			}
			else {
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(GroupConstants.CONSTANT_JCRYPTION_URL_MAPPING);
					ipAddressObtained.load(fis);
				}
				catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally {
					if (fis != null) {
						fis.close();
						fis = null;
					}
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		//}
		
		return ipAddressObtained;
	}
	//Ended by Hiren Sonawala
	

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest requ = (HttpServletRequest) req; 
		HttpServletRequestWrapper wrappedRequest = null; 
//		Properties prop = loadProperties();
		     if(requ.getMethod().equalsIgnoreCase("POST"))
		     {
		    	 //Added by Hiren Sonawala
		    	 final String BLACKLIST_PAGES=ipAddressObtained.getProperty("JCRYPTION_LIST_URL");
					List<String> blackListedUrls = Arrays.asList(BLACKLIST_PAGES.split(","));
					StringBuffer reqBuf = requ.getRequestURL();
					String reqPage = reqBuf.substring(reqBuf.lastIndexOf("/")+1,reqBuf.length());
					userVO =(IPruUser)requ.getSession().getAttribute("userVO");
					final String EVENT_ID_PAGES = ipAddressObtained.getProperty("JCRYPTION_EVENT_ID");
					List<String> eventId_properties_list = Arrays.asList(EVENT_ID_PAGES.split(","));
					final String ONE_CASE_BLACKLIST_PAGES=ipAddressObtained.getProperty("JCRYPTION_EXCEPTIONAL_LISTS_URL");
					List<String> one_case_blackListedUrls = Arrays.asList(ONE_CASE_BLACKLIST_PAGES.split(","));
			    	final String ROLE_FOR_PRELOGIN_PAGES=ipAddressObtained.getProperty("JCRYPTION_ROLE_FOR_LOGIN");
			    	List<String> role_for_prelogin_preoperties = Arrays.asList(ROLE_FOR_PRELOGIN_PAGES.split(","));
			    	
			    	List<String> non_role_specific_eventIDs = Arrays.asList(ipAddressObtained.getProperty("JCRYPTION_NON_ROLE_EVENT_ID").split(","));
			    	
					/*if(org.apache.commons.lang3.StringUtils.isNotBlank(reqPage)&&blackListedUrls.contains(reqPage)
					//Added by Hiren Sonawala: Implemented for Jcryption where is not required in parent-flow but required in sub-flow.
					||(eventId_properties_list.contains(requ.getParameter("_eventId")) && one_case_blackListedUrls.contains(reqPage) && role_for_prelogin_preoperties.contains(userVO.getRoles()))
					//Added by Madhav for checking subflow events without checking userrole and parent flow
					|| (requ.getSession().getAttribute(SessionKeyConstants.SLBL_PAYMENT_SECURED_POST_FLAG) != null && requ.getSession().getAttribute(SessionKeyConstants.SLBL_PAYMENT_SECURED_POST_FLAG).equals("true") && non_role_specific_eventIDs.contains(requ.getParameter("_eventId")))
					){
						if(requ.getSession().getAttribute(SessionKeyConstants.CSR_PAYMENT_SECURED_POST_FLAG).equals("true"))
						{
							String requestedValue = requ.getParameter("jc_param");
							
							if(StringUtils.isEmpty(requestedValue) || StringUtils.isBlank(requestedValue))
							{
								throw new ServletException("Tempared Request");
							}
							
						//Ended by Hiren Sonawala
				 			
				 			String urlDecodedencryptedValue=URLDecoder.decode(requestedValue, "UTF-8");
				 			wrappedRequest = new DecryptedParameterRequest(requ,urlDecodedencryptedValue);
				 			// chain.doFilter(wrappedRequest, res);
			 //	}
						}
		    	 }*/
				 
		     }
		
		chain.doFilter(wrappedRequest != null ? wrappedRequest : req,res);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		loadProperties();

	}
	class DecryptedParameterRequest extends HttpServletRequestWrapper {

		private Map<String, String[]> parameters = new LinkedHashMap<String, String[]>(
				16);

		public DecryptedParameterRequest(HttpServletRequest request,String encryptedValue) {
			super(request);
			//Assert.notNull(keys, "Keys must not be null");
			com.tcs.security.encryption.servlet.EncryptoServlet cs=new com.tcs.security.encryption.servlet.EncryptoServlet();
			String decrypted =cs.decriptPassword(request,encryptedValue); //request.getParameter(PARAM));
			StringBuffer queryString=new StringBuffer();
		//	String restQueryParmameters=;
			queryString.append(request.getQueryString());
			queryString.append("&"+decrypted);
			parameters = JCryptionUtil.parse(queryString.toString(), "utf-8", PARAM);
			
		}

		@Override
		public String getParameter(String name) {
			if(StringUtils.isNotBlank(name)) {
			String[] arr = this.parameters.get(name);
			return (arr != null && arr.length > 0 ? arr[0] : null);
			}
			return null;
		}

		@Override
		public Map getParameterMap() {
			return Collections.unmodifiableMap(this.parameters);
		}

		@Override
		public Enumeration getParameterNames() {
			return Collections.enumeration(this.parameters.keySet());
		}

		@Override
		public String[] getParameterValues(String name) {
			if(StringUtils.isNotBlank(name)) {
			return this.parameters.get(name);
			}
			return null;
		}
	}

}
