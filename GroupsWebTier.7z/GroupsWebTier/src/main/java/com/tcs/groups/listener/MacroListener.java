package com.tcs.groups.listener;


import org.apache.poi.poifs.eventfilesystem.POIFSReaderEvent;
import org.apache.poi.poifs.eventfilesystem.POIFSReaderListener;

public class MacroListener implements POIFSReaderListener{

	  boolean macroDetected;

	  public boolean isMacroDetected() {
	    return macroDetected;
	  }

	  public void processPOIFSReaderEvent(POIFSReaderEvent event) {
	    if(event.getPath().toString().startsWith("\\Macros")
	          || event.getPath().toString().startsWith("\\_VBA")) {
	      macroDetected = true;
	    }

	  }

}
