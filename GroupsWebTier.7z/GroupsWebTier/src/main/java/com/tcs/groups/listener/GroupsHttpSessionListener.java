package com.tcs.groups.listener;

import java.util.Calendar;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.security.user.IPruUser;
import com.ipru.security.user.SessReqCounterVO;
import com.tcs.logger.FLogger;

public class GroupsHttpSessionListener implements HttpSessionListener {

	
	@Override
	public void sessionCreated(HttpSessionEvent arg0) {

		SessReqCounterVO sessReqCounterVO =new SessReqCounterVO();
		// TODO Auto-generated method stub
		HttpSession session = arg0.getSession();
		//////System.out.println("Session is getting created : "+session.getId());
		
		ConcurrentHashMap<String,Object> concurrentSessionMap = (ConcurrentHashMap<String,Object>)arg0.getSession().getServletContext().getAttribute(ContextKeyConstants.CONCURRENT_SESSION_MAP_CONTEXT);
		AtomicInteger atomicinteger=new AtomicInteger();
		atomicinteger.set(Integer.parseInt(arg0.getSession().getServletContext().getInitParameter("inactiveHits")));
		sessReqCounterVO.setRequestCounter(atomicinteger);
		//////System.out.println("sessReqCounterVO.setRequestCounter"+sessReqCounterVO.getRequestCounter());
		//if(concurrentSessionMap != null)
		concurrentSessionMap.put(session.getId(),sessReqCounterVO );
		FLogger.info("securityerror", "GroupsHttpSessionListener", "sessionsessionCreated(HttpSessionEvent sessionCloseEvenet)", "sessionCreated : "+session.getId());
	

	}

	@Override
	public void sessionDestroyed(HttpSessionEvent sessionCloseEvenet) {
		// TODO Auto-generated method stub
		Calendar cal=Calendar.getInstance();
		long time=cal.getTimeInMillis();
		FLogger.info("securityerror", "GroupsHttpSessionListener", "sessionDestroyed(HttpSessionEvent sessionCloseEvenet)",
				"inside session destroyed at startTime="+time);
		 StackTraceElement[] traceArray = Thread.currentThread().getStackTrace();
			for(StackTraceElement stackTraceElement:traceArray)
			{
				FLogger.info("securityerror", "GroupsHttpSessionListener", "sessionDestroyed(HttpSessionEvent sessionCloseEvenet)",
						stackTraceElement.getFileName()+""+stackTraceElement.getClassName()+""+stackTraceElement.getMethodName()+""+stackTraceElement.getLineNumber());
			}
		HttpSession session = sessionCloseEvenet.getSession();
		//////System.out.println("Session is getting destroy : "+session.getId());

		IPruUser ipruUser = (IPruUser)session.getAttribute("userVO");
		if(ipruUser!=null && ipruUser.getUsername()!=null)
		{
			session.removeAttribute("userVO");
		}
		ConcurrentHashMap<String,String> concurrentSessionMap = (ConcurrentHashMap<String,String>)sessionCloseEvenet.getSession().getServletContext().getAttribute(ContextKeyConstants.CONCURRENT_SESSION_MAP_CONTEXT);
		concurrentSessionMap.put("", "");
		concurrentSessionMap.remove(session.getId());

		FLogger.info("securityerror", "GroupsHttpSessionListener", "sessionDestroyed(HttpSessionEvent sessionCloseEvenet)", "exiting session destroyed session id : "+session.getId());

		FLogger.info("securityerror", "GroupsHttpSessionListener", "sessionDestroyed(HttpSessionEvent sessionCloseEvenet)",
				"exiting session destroyed for startTime="+time);

	}

}
