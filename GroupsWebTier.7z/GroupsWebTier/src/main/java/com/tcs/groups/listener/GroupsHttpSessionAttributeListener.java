package com.tcs.groups.listener;

import java.util.Calendar;
import java.util.Properties;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.logger.FLogger;

public class GroupsHttpSessionAttributeListener implements HttpSessionAttributeListener{
	

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpSessionAttributeListener#attributeAdded(javax.servlet.http.HttpSessionBindingEvent)
	 */
	@Override
	public void attributeAdded(HttpSessionBindingEvent event) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpSessionAttributeListener#attributeRemoved(javax.servlet.http.HttpSessionBindingEvent)
	 */
	@Override
	public void attributeRemoved(HttpSessionBindingEvent event) {
		// TODO Auto-generated method stub
		Calendar cal=Calendar.getInstance();
		long time=cal.getTimeInMillis();
		FLogger.info("securityLogger", "GroupsHttpSessionAttributeListener", "attributeRemoved(HttpSessionBindingEvent event)",
				"inside atrribute removed at startTime="+time);
		String name = event.getName();
	//	ApplicationForm applicationFormPO =null;
		HttpSession session = event.getSession();
		
		
		/*if(name!=null && name.equalsIgnoreCase("applicationFormPO")){
			// Added for Drop Link by Gaurav - Start
			try{
				
				Properties prop = null;
				String mail = "";
				String agentEmail = "";
				String mobileNo="";
				String agentMobNo = "";
				boolean agentFlag=false;
				boolean mailStatus=false;
				boolean smsStatus=false;
				
				prop=MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_APPLICATION_PROPERTIES_PROPERTIES;
				
				applicationFormPO = (ApplicationForm)event.getValue();
				if(applicationFormPO != null){
					String appNo = applicationFormPO.getAppNo();
					FLogger.info("BusinessTier", "SellOnlineHttpSessionAttributeListener", "attributeRemoved(HttpSessionBindingEvent event)",
							"In attributeREmoved for AppNo="+appNo+" and startTime="+time);
					String overAllStatus = applicationFormPO.getOverallStatus();
					
					if(applicationFormPO.isSOLFlag())
					{
						agentEmail = applicationFormPO.getAgentDropEmail();
						agentMobNo = applicationFormPO.getAgentDropMobile();
					}
					
					
					if(applicationFormPO.isBOLFlag() || applicationFormPO.isSOLFlag())
					{
						if(applicationFormPO.getPrimaryLifeAssure().getSelect().equalsIgnoreCase("Self"))
						{
							mail = applicationFormPO.getPrimaryLifeAssure().getEmail();
							mobileNo = applicationFormPO.getPrimaryLifeAssure().getMobile();
						}
						else
						{
							mail = applicationFormPO.getProposer().getEmail();
							mobileNo = applicationFormPO.getProposer().getMobile();
						}
					}
					
					try{
						applicationFormPO.setUrlWithContextPath((String)session.getAttribute("urlWithContextPath"));
					}catch (IllegalStateException e) {
						e.printStackTrace();
						FLogger.info("BusinessTier", "SellOnlineHttpSessionAttributeListener", "attributeRemoved(HttpSessionBindingEvent event)",
								"IllegalStateException for AppNo="+appNo+" and startTime="+time);
					}
					
					
					if((applicationFormPO.isBOLFlag() || applicationFormPO.isSOLFlag()) && overAllStatus!=null && (overAllStatus.equalsIgnoreCase(prop.getProperty("ContinuePurchaseProcess")) || overAllStatus.equalsIgnoreCase(prop.getProperty("PaymentPending"))) 
								&& applicationFormPO.getUrlWithContextPath()!=null)
					{

						EmailInvoke sendMailService = new EmailInvoke();
						
						//Drop Email for Customer
						if(mail!=null && !mail.trim().equalsIgnoreCase(""))
						{
							agentFlag=false;
							applicationFormPO.setCampaignName(prop.getProperty("APPL_INCOMPLETE_CAMPAIGN_NAME"));
							mailStatus = sendMailService.sendDropMail(applicationFormPO,agentFlag);
						}
						
						FLogger.info("BusinessTier", "SellOnlineHttpSessionAttributeListener", "attributeRemoved(HttpSessionBindingEvent event)",
								"applicationStatus. Sendmail Response for customer mail:" + mailStatus+"for appNo="+appNo+" and startTime="+time);
						
						//Drop SMS for Customer
						if(mobileNo!=null && mobileNo!="")
						{
							agentFlag=false;
							applicationFormPO.setCampaignName(prop.getProperty("APP_INCOMPLETE_SMS_CAMPAIGN"));
							smsStatus = sendMailService.sendDropSMS(applicationFormPO,agentFlag);
						}
						
						FLogger.info("BusinessTier", "SellOnlineHttpSessionAttributeListener", "attributeRemoved(HttpSessionBindingEvent event)",
								"applicationStatus. Sendmail Response for customer sms:" + smsStatus+"for appNo="+appNo+" and startTime="+time);
						
						//Drop Email for Agent
						if(applicationFormPO.isSOLFlag() && agentEmail!=null && !agentEmail.trim().equalsIgnoreCase(""))
						{
							agentFlag=true;
							applicationFormPO.setCampaignName(prop.getProperty("APPL_INCOMPLETE_CAMPAIGN_NAME"));
							mailStatus = sendMailService.sendDropMail(applicationFormPO,agentFlag);
						}
						
						FLogger.info("BusinessTier", "SellOnlineHttpSessionAttributeListener", "attributeRemoved(HttpSessionBindingEvent event)",
								"applicationStatus. Sendmail Response for agent mail:" + mailStatus+"for appNo="+appNo+" and startTime="+time);
						
						//Drop SMS for Agent
						if(applicationFormPO.isSOLFlag() && agentMobNo!=null && agentMobNo!="")
						{
							agentFlag=true;
							applicationFormPO.setCampaignName(prop.getProperty("APP_INCOMPLETE_SMS_CAMPAIGN"));
							smsStatus = sendMailService.sendDropSMS(applicationFormPO,agentFlag);
						}						
						
						FLogger.info("BusinessTier", "SellOnlineHttpSessionAttributeListener", "attributeRemoved(HttpSessionBindingEvent event)",
								"applicationStatus. Sendmail Response for agent sms:" + smsStatus+"for appNo="+appNo+" and startTime="+time);
						
					}					
					
				}
			}	
				catch (Exception e) {
				e.printStackTrace();
				FLogger.info("BusinessTier", "SellOnlineHttpSessionAttributeListener", "attributeRemoved(HttpSessionBindingEvent event)",
						"Exception in attribute removed for startTime="+time);
			
			}
			FLogger.info("BusinessTier", "SellOnlineHttpSessionAttributeListener", "attributeRemoved(HttpSessionBindingEvent event)",
					"End of attribute removed for startTime="+time);
		}*/
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpSessionAttributeListener#attributeReplaced(javax.servlet.http.HttpSessionBindingEvent)
	 */
	@Override
	public void attributeReplaced(HttpSessionBindingEvent event) {
		// TODO Auto-generated method stub
	}
}
