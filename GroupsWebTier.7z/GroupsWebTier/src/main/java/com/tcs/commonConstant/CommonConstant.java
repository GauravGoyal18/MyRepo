package com.tcs.commonConstant;

public class CommonConstant {
	public static final String FILENAME="fileName";
	public static final String NUMBEROFCOLS="numberOfColumns";
	
}
