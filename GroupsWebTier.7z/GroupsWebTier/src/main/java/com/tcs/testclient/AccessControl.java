package com.tcs.testclient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public class AccessControl implements Filter {

	String str_className = "AccessControl";
	String str_MethodName = "";
	FilterConfig config;

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// ////System.out.println("Access Control gets calleddddddddddddddddddddddddddd");
		this.str_MethodName = "doFilter";

		HttpServletRequest requ = (HttpServletRequest) req;
		String requestIPAddress = requ.getRemoteAddr();
		HttpSession session = ((HttpServletRequest) req).getSession();

		// Changes done by Harshini on 11/01/2016 **** For Thank You Page to be
		// shown Once **Start
		HttpServletResponse response = (HttpServletResponse) res;
		String pageURL = requ.getServletPath();
		String urlChangeFlag = (String) session.getAttribute("urlChangeFlag");
		String thankYouURL = (String) session.getAttribute("ThankyouPage");
		String queryString = requ.getQueryString();
		int key = 0;
		if (queryString != null && queryString.contains("execution")) {
			// ////System.out.println("queryString "+queryString);

			int indexOfExecutionKey = -1;
			indexOfExecutionKey = queryString.lastIndexOf("e");
			int indexOfExecution = queryString.indexOf("s");
			int positionOfExecutionKey = indexOfExecution - 1 - indexOfExecutionKey;
			if (positionOfExecutionKey == 1) {
				String stringKey = "" + queryString.charAt(indexOfExecutionKey + 1);
				key = Integer.parseInt(stringKey);
				// ////System.out.println("key1::"+key);
				FLogger.info("securityLogger", "AccessControl", "doFilter(ServletRequest req,ServletResponse res,FilterChain chain)", "key1::" + key);
			}
			else if (positionOfExecutionKey == 2) {
				String stringKey1 = "" + queryString.charAt(indexOfExecutionKey + 1);
				String stringKey2 = "" + queryString.charAt(indexOfExecutionKey + 2);
				String conString = stringKey1 + stringKey2;
				key = Integer.parseInt(conString);
				// ////System.out.println("key2::"+key);
				FLogger.info("securityLogger", "AccessControl", "doFilter(ServletRequest req,ServletResponse res,FilterChain chain)", "key2::" + key);

			}
			else if (positionOfExecutionKey == 3) {
				String stringKey1 = "" + queryString.charAt(indexOfExecutionKey + 1);
				String stringKey2 = "" + queryString.charAt(indexOfExecutionKey + 2);
				String stringKey3 = "" + queryString.charAt(indexOfExecutionKey + 3);
				String conString = stringKey1 + stringKey2 + stringKey3;
				key = Integer.parseInt(conString);
				// ////System.out.println("key3::"+key);
				FLogger.info("securityLogger", "AccessControl", "doFilter(ServletRequest req,ServletResponse res,FilterChain chain)", "key3::" + key);
			}
		}
		if (urlChangeFlag != null && urlChangeFlag.equalsIgnoreCase("true")) {
			// ////System.out.println("if(urlChangeFlag!=null && urlChangeFlag.equalsIgnoreCase");
			String thankuKey = (String) session.getAttribute("ThankyouKey");
			if ((key + "").equalsIgnoreCase(thankuKey)) {
				session.invalidate();
				response.sendRedirect("error.htm");
				return;
			}

		}
		else {
			if (pageURL.equalsIgnoreCase("/thankyou.htm")) {
				// ////System.out.println("/thankyou.htm");

				String thankYouKey = (String) session.getAttribute("ThankyouKey");

				if (thankYouKey == null) {
					if (key != 0)
						session.setAttribute("ThankyouKey", key + "");
				}

				else if (key != 0 && !thankYouKey.equalsIgnoreCase(key + "")) {
					session.invalidate();
					response.sendRedirect("error.htm");
					return;
				}

				if (thankYouURL == null) {
					session.setAttribute("ThankyouPage", pageURL);
				}
			}
			else {
				if (thankYouURL != null && thankYouURL.equalsIgnoreCase("/thankyou.htm") && urlChangeFlag == null) {
					session.setAttribute("urlChangeFlag", "true");
				}
			}
		}
		
		IPruUser userVo = (IPruUser) session.getAttribute("userVO");
		// //System.out.println(userVo+" User Vo in access control is " );
		String url = requ.getRequestURI();
		// ////System.out.println("url   " +requ.getRequestURI());
		String array[] = url.split("/");
		String temp = array[2].toString();
		// String array1[]=temp.split(".");
		int length = temp.length();
		String pageName = temp.substring(0, length - 4);
		if (null != userVo) {
			// ////System.out.println(" User vo is not null");
			// //System.out.println(userVo.getRoles());
			/*
			 * if(userVo.getNonLoggedInUid()!=null &&
			 * userVo.isNonLoggedinFlag()==true) { } else {
			 */
			ArrayList<String> finalBigUrlList = new ArrayList<String>();
			// ////System.out.println(":::::::::::" + config.getServletContext());
			ServletContext context = config.getServletContext();
			boolean flag = false;

			finalBigUrlList = (ArrayList<String>) context.getAttribute("url_businessParam");
			// //System.out.println(finalBigUrlList+" finalBigUrlList   ");

			String role = null;
			IPruUser user = (IPruUser) session.getAttribute("userVO");
			HashMap<String, String> accessMatrix = null;
			// ////System.out.println("Before for");
			for (int i = 0; i < finalBigUrlList.size(); i++) {
				String url1 = (String) finalBigUrlList.get(i);
				// ////System.out.println("url 1 "+url1);
				// ////System.out.println("page name "+pageName);
				if (url1.equalsIgnoreCase(pageName)) {
					if (user != null) {
						accessMatrix = user.getAccessMatrix();
						/*if (accessMatrix != null && accessMatrix.size() > 0 && accessMatrix.containsKey("otpEmailMobile")) {
							boolean emailMobileUpdated = user.isEmailMobileUpdated();
							if (emailMobileUpdated) {
								for (Entry<String, String> pairs : accessMatrix.entrySet()) {
									if (pairs.getValue().toString().contains("R")) {
										if (pairs.getKey().equalsIgnoreCase(pageName)) {
											flag = true;
										}
									}						
								}
							}
							else {
								for (Entry<String, String> pairs : accessMatrix.entrySet()) {
									if (pairs.getKey().equalsIgnoreCase(user.getLandingPage()) && pairs.getValue().toString().contains("R")) {
										if (pairs.getKey().equalsIgnoreCase(pageName)) {
											flag = true;
										}
									}
								}
							}
						}*/
						if (accessMatrix != null && accessMatrix.size() > 0) {
							for (Entry<String, String> pairs : accessMatrix.entrySet()) {
								if (pairs.getValue().toString().contains("R")) {
									if (pairs.getKey().equalsIgnoreCase(pageName)) {
										flag = true;
									}
								}
							}
						}
						if (flag == false) {
							ServletException e = new ServletException("Failed validation");							
							FLogger.info("securityLogger", "AccessControl", "Access Control Filter", "Attemp of priviledge escallation");
							throw e;
						}

					}
					else {
						ServletException e = new ServletException("Failed validation");						
						FLogger.info("securityLogger", "AccessControl", "Access Control Filter", "Session is null");
						throw e;
					}
				}
			}
			// }
		}

		chain.doFilter(req, res);

	}

	public void setFilterConfig(FilterConfig config) {
		this.config = config;
	}

	public FilterConfig getFilterConfig() {
		return config;
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		setFilterConfig(arg0);
	}

}
