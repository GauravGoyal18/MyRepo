package com.tcs.testclient;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.groups.utilities.EncryptionUtil;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.GroupsJsonUtils;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.security.user.IPruUser;
import com.ipru.security.user.SessReqCounterVO;
import com.tcs.ipru.security.EncoderUtility;
import com.tcs.ipru.security.SecurityFilterException;
import com.tcs.logger.FLogger;

public class JavaEncoding implements Filter {

	String str_className = "Java Encoding";
	String str_MethodName = "";
	String uidId = "";
	String header = "";
    String header_IFRAME = "";

	String URL = "";
	private final static String accessMatrixPrefix = "am_";
	private final static String addtnlUserDtlsPrefix = "aud_";

	private Properties whitelisturl;
	private Properties contentsecurityconfi;
	private String whitelistUrl;
	private String contentSecurityConfi;
	private static String contentSecurityConfi_IFRAME;
	private String[] whiteListURLArray;

	public void destroy() {
		// TODO Auto-generated method stub

	}

	public static boolean matches(String regex, CharSequence input) {
		if (Pattern.matches(regex, input)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean regexPatternMatching(String input) {
		if (StringUtils.isNotEmpty(input)) {
			Pattern pattern = Pattern.compile("[<>%!\\\\\\*]");
			Matcher matcher = pattern.matcher(input);
			if (matcher.find()) {
				return false;
			}
		}
		return true;
	}

	public static boolean isJSONValid(String JSON_STRING) {
		boolean isJsonValid = false;
		try {
			isJsonValid = GroupsJsonUtils.getInstance()
					.isJsonValid(JSON_STRING);
		} catch (Throwable t) {
			isJsonValid = false;
		}

		return isJsonValid;

	}

	public static String encodeHTML(String param) {
		// return ESAPI.encoder().encodeForHTML(param);
		return EncoderUtility.forHTML(param);
		// 234%22%3Balert(1)%2F%2F123
	}

	private void setIpruThreadName(ServletRequest req) {
		IPruUser userVo = (IPruUser) (((((HttpServletRequest) req).getSession())
				.getAttribute("userVO")));
		String userId = userVo == null ? "" : userVo.getUserId() == null ? ""
				: userVo.getUserId();

		// last 15 digits
		Thread.currentThread().setName(
				(EncryptionUtil.encryptSHA256(((HttpServletRequest) req)
						.getSession().getId())).substring(49)
						+ " USERID: "
						+ userId);
		// Thread.currentThread().setName(EncryptionUtil.encryptSHA256(((HttpServletRequest)
		// req).getSession().getId())+" USERID: "+userId);
	}

	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		this.str_MethodName = "doFilter";
		String path = ((HttpServletRequest) req).getServletPath();
		HttpServletRequest requ = (HttpServletRequest) req;
		// ** security-related HTTP headers **Start
		HttpServletResponse resp = (HttpServletResponse) res;
		resp.addHeader("X-XSS-Protection", "1; mode=block");
		resp.addHeader("X-Content-Type-Options", "nosniff");
		resp.addHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
		// ** security-related HTTP headers **End

		// Set thread name
		setIpruThreadName(req);

		try {
			if (!(contentSecurityConfi.contains("report-uri"))) {
				URL = requ.getScheme() + "://" + requ.getServerName() + ":"
						+ requ.getServerPort() + requ.getContextPath()
						+ "/csp-report";
				contentSecurityConfi = contentSecurityConfi + " report-uri "
						+ URL;
			}

			if (header.equals("Yes"))
				resp.addHeader("Content-Security-Policy-Report-Only",
						contentSecurityConfi);
			if(header_IFRAME.equals("Yes")) {
				resp.addHeader("Content-Security-Policy", contentSecurityConfi_IFRAME);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Map<String, String> map = new HashMap<String, String>();
		String akamaiHeader = "True-Client-IP";

		HttpSession session = ((HttpServletRequest) req).getSession();
		ConcurrentHashMap<String, Object> concurrentSessionMap = (ConcurrentHashMap<String, Object>) requ
				.getSession()
				.getServletContext()
				.getAttribute(
						ContextKeyConstants.CONCURRENT_SESSION_MAP_CONTEXT);
		if (concurrentSessionMap != null) {
			SessReqCounterVO sessCounterVo = (SessReqCounterVO) concurrentSessionMap
					.get(session.getId());
			if (sessCounterVo != null) {
				String reqURL = requ.getServletPath();
				// FLogger.debug("securityLoggerDebug", "JavaEncoding",
				// "doFilter(ServletRequest req,ServletResponse res,FilterChain chain)",
				// "reqURL : "+reqURL+" session id :"+session.getId());

				if (reqURL != null && !reqURL.contains(".css")
						&& !reqURL.contains(".js") && !reqURL.contains(".png")
						&& !reqURL.contains(".gif") && !reqURL.contains(".jpg")
						&& !reqURL.contains(".jpeg")) {

					AtomicInteger count = sessCounterVo.getRequestCounter();

					if (count != null && reqURL != null
							&& (reqURL).contains("SecReqCounterServlet")) {
						// FLogger.debug("securityLoggerDebug", "JavaEncoding",
						// "doFilter(ServletRequest req,ServletResponse res,FilterChain chain)",
						// " SecReqCounterServlet hit ---countbefore"+count+" session id :"+session.getId());

						// String sessionInvalidate="sessionInvalidate";
						if ((count != null) && (count.get() < 1)) {
							if (session != null) {

								session.invalidate();
								// ////System.out.println("less than 1");
								return;
							}

						}
						// FLogger.debug("securityLoggerDebug", "JavaEncoding",
						// "doFilter(ServletRequest req,ServletResponse res,FilterChain chain)",
						// "countbefore"+count+" session id :"+session.getId());
						count.getAndDecrement();
						// FLogger.debug("securityLoggerDebug", "JavaEncoding",
						// "doFilter(ServletRequest req,ServletResponse res,FilterChain chain)",
						// "count"+count+" session id :"+session.getId());
						sessCounterVo.setRequestCounter(count);
						concurrentSessionMap.replace(session.getId(),
								sessCounterVo);

					} else {

						AtomicInteger atomicinteger = new AtomicInteger();
						atomicinteger.set(Integer.parseInt(session
								.getServletContext().getInitParameter(
										"inactiveHits")));
						sessCounterVo.setRequestCounter(atomicinteger);
						// FLogger.debug("securityLoggerDebug", "JavaEncoding",
						// "doFilter(ServletRequest req,ServletResponse res,FilterChain chain)",
						// " atomicinteger is reset ---- atomicinteger : "+atomicinteger+" session id :"+session.getId());
						concurrentSessionMap.replace(session.getId(),
								sessCounterVo);
					}
				}
			}
		}
		boolean akamaiFlag = false;
		Enumeration headerNames = requ.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String key = (String) headerNames.nextElement();
			String value = requ.getHeader(key);
			map.put(key, value);
			if (map.containsKey(akamaiHeader)
					|| map.containsValue(akamaiHeader)) {
				akamaiFlag = true;
				// ////System.out.println("key value matched::::::");
			}
		}

		String requestIPAddress = requ.getRemoteAddr();
		// HttpSession session = ((HttpServletRequest) req).getSession();
		String currentIPAddress = (String) session
				.getAttribute("currentIPAddress");
		String trueClientIp = requ.getHeader("True-Client-IP");
		String clientIpSession = (String) session.getAttribute("trueClientIp");
		// String captchaLogin = (String) session.getAttribute("captchaLogin");

		// FLogger.info("IssueAnalysis", "JavaEncoding","doFilter",
		// "captcha in javaEncoding filter : "+captchaLogin+" Session Id : "+session.getId());

		// FLogger.debug("securityLoggerDebug", "JavaEncoding","doFilter",
		// "remte add in  session :"+currentIPAddress+" remote add request : "+requestIPAddress
		// +"client ip session :"+clientIpSession+" client ip request : "+trueClientIp
		// +"flag true or false : " +
		// akamaiFlag+" session id :"+session.getId());
		if (!akamaiFlag) {
			// FLogger.debug("securityLoggerDebug", "JavaEncoding","doFilter",
			// "remte add in  session :"+currentIPAddress+" remote add request : "+requestIPAddress
			// +"flag true or false: " +
			// akamaiFlag+" session id :"+session.getId());
			String check = "false";
			Properties prop = new Properties();
			FileInputStream fileIs = null;
			try {
				fileIs = new FileInputStream(GroupConstants.CONSTANT_C
						+ "/temp.properties");
				prop.load(fileIs);
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				if (fileIs != null) {
					fileIs.close();
					fileIs = null;
				}
			}
			check = prop.getProperty("checkTrueClientIPOnTEST", "false");
			if (StringUtils.equalsIgnoreCase(check, "true")) {
				if (currentIPAddress != null) {
					if (!requestIPAddress.equals(currentIPAddress)) {
						// ////System.out.println("currentIPAddress does not match request ip address");
						// FLogger.debug("securityLoggerDebug", "JavaEncoding",
						// "doFilter(ServletRequest req,ServletResponse res,FilterChain chain)",
						// "current and requested ip address matching for security purpose"+" session id :"+session.getId());
						// ServletException e1 =new
						// ServletException("Failed validation");
						SecurityFilterException e1 = new SecurityFilterException(
								"Failed Validation");
						FLogger.error("securityLoggerError", "JavaEncoding",
								"doFilter",
								"Current IP address does not match with requested IP address session id :"
										+ session.getId(), e1);
						FLogger.error("securityLoggerError", "JavaEncoding",
								"doFilter",
								"Current IP address does not match with requested IP address session id :"
										+ session.getId(), e1);
						throw e1;
					}
				}
			}
		}

		else if (akamaiFlag) {

			String check = "false";
			Properties prop = new Properties();
			FileInputStream fileIs = null;
			try {
				fileIs = new FileInputStream(GroupConstants.CONSTANT_C
						+ "/temp.properties");
				prop.load(fileIs);
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				if (fileIs != null) {
					fileIs.close();
					fileIs = null;
				}
			}
			check = prop.getProperty("checkTrueClientIP", "false");

			if (StringUtils.equalsIgnoreCase(check, "true")) {
				// FLogger.debug("securityLoggerDebug", "JavaEncoding",
				// "doFilter",
				// "client ip session :" + clientIpSession
				// + " client ip request : " + trueClientIp
				// + "flag true or false : " + akamaiFlag);
				if (StringUtils.isNotBlank(clientIpSession)) {
					if (!clientIpSession.equals(trueClientIp)) {
						System.out
								.println("client ip does not match request ip address");
						/*
						 * FLogger.debug( "securityLoggerDebug", "JavaEncoding",
						 * "doFilter(ServletRequest req,ServletResponse res,FilterChain chain)"
						 * ,
						 * "current and requested client ip address matching for security purpose session id :"
						 * +session.getId());
						 */
						// ServletException e1 = new
						// ServletException("Failed validation");
						SecurityFilterException e1 = new SecurityFilterException(
								"Failed Validation");
						FLogger.error(
								"securityLoggerError",
								"SellOnlineAuthenticationProvider",
								"authenticate",
								"Current client IP address does not match with requested IP address session id :"
										+ session.getId());
						FLogger.error(
								"securityLoggerError",
								"currentIPAddress : "
										+ currentIPAddress
										+ " clientIpSession : "
										+ clientIpSession
										+ " trueClientIp : "
										+ trueClientIp
										+ " akamaiFlag : "
										+ akamaiFlag
										+ " checkTrueClientIP : "
										+ check
										+ " , Class : "
										+ this.str_className
										+ " , Method :  "
										+ this.str_MethodName
										+ " , Message : Current client IP address does not match with requested IP address session id :"
										+ session.getId());
						throw e1;
					}

				}
			}
			fileIs = null;
		}

		String queryString = requ.getQueryString();
		if (("wsdl").equalsIgnoreCase(queryString)) {
			ServletException e = new ServletException("WSDL accessing");
			FLogger.error("securityLoggerError", "AccessControlFilter",
					"Access Control Filter", "Attemp of opening wsdl");
			throw e;
		}

		Map paramMap = req.getParameterMap();
		Set keys = paramMap.keySet();
		Iterator<String> itr = keys.iterator();
		String key = null;
		String strValue = null;
		String[] strValueArray = null;
		Object objValue = null;

		// Added by Kaushik for Whitelisting URL
		boolean isWhiteList = false;
		if (itr.hasNext()) {
			for (String url : whiteListURLArray) {
				if (requ.getRequestURI().contains(url)) {
					isWhiteList = true;
					break;
				}
			}
		}

		while (itr.hasNext()) {
			key = itr.next();
			if (paramMap.get(key) instanceof String[]) {
				strValueArray = (String[]) paramMap.get(key);
				if (!key.equalsIgnoreCase("j_username")
						&& !key.equalsIgnoreCase("j_password")
						&& !key.equalsIgnoreCase("imageurl")
						&& !key.equalsIgnoreCase("oldPassword")
						&& !key.equalsIgnoreCase("newPassword")
						&& !key.equalsIgnoreCase("confirmPassword")
						&& !key.equalsIgnoreCase("pgiRequest")
						&& !key.equalsIgnoreCase("pgiResponse")
						&& !key.equalsIgnoreCase("pdfRequest")
						&& !key.equalsIgnoreCase("ReqParam")
						&& !key.equalsIgnoreCase("code")
						&& !key.equalsIgnoreCase("oauth_token")
						&& !key.equalsIgnoreCase("reurl")
						&& !key.equalsIgnoreCase("cashPolicyHolderName")
						&& !key.equalsIgnoreCase("gclid")) {

					for (int i = 0; i < strValueArray.length; i++) {
						strValue = strValueArray[i];
						if (!isWhiteList) {
							if (org.apache.commons.lang3.StringUtils
									.equalsIgnoreCase(requ.getMethod(), "GET")) {
								if (!StringUtils.equals(key, "_tk")) {
									if (!isJSONValid(strValue)) {
										String encodedstrValue = encodeHTML(strValue);
										if (!strValue
												.equalsIgnoreCase(encodedstrValue)) {
											// ////System.out.println("Tampered Request");
											// ////System.out.println("Original Parameter"+strValue);
											// //System.out.println();
											ServletException e = new ServletException(
													"Tampered Request");

											FLogger.error(
													"securityLoggerError",
													"IP-Address : "
															+ currentIPAddress
															+ " , Class : "
															+ this.str_className
															+ " , Method :  "
															+ this.str_MethodName
															+ " , Message : Invalid input atempt");
											FLogger.error(
													"securityLoggerError",
													"JavaEncodingFilter",
													"Java Encoding Filter",
													"Invalid Input");
											throw e;
										}
									}
								}
							}
						}

						if (regexPatternMatching(strValue)) {

						} else {
							// ////System.out.println("Invalid data"+strValue);
							ServletException e = new ServletException(
									"Failed validation");

							FLogger.error(
									"securityLoggerError",
									"IP-Address : "
											+ currentIPAddress
											+ " , Class : "
											+ this.str_className
											+ " , Method :  "
											+ this.str_MethodName
											+ " , Message : Invalid input atempt");
							FLogger.error("securityLoggerError",
									"JavaEncodingFilter",
									"Java Encoding Filter", "Invalid Input");
							throw e;

						}
					}
				}
			} else if (paramMap.get(key) instanceof String) {
				strValue = (String) paramMap.get(key);
			} else {
				objValue = paramMap.get(key);
			}

		}

		/******* Default UserVO creation ********/
		IPruUser userVo = (IPruUser) session.getAttribute("userVO");
		String url = requ.getServletPath();
		Properties prop = new Properties();
		FileInputStream fis = null;

		try {
			if (MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES != null) {
				prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
			} else {
				fis = new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
				prop.load(fis);
			}
		} catch (FileNotFoundException e) {
			FLogger.info(
					"securityLogger",
					"JavaEncoding",
					"attemptAuthentication",
					"File not found exception found at the time of loading properties in attemptAuthentication ");
			e.printStackTrace();
		} catch (IOException e) {
			FLogger.info("securityLogger", "JavaEncoding",
					"attemptAuthentication",
					"IOException found at the time of loading properties in attemptAuthentication ");
			e.printStackTrace();
		}
		finally {
			if (fis != null) {
				fis.close();
				fis = null;
			}
		}
		if (null == userVo) {
			// create new UserVO
			userVo = populateUserVO(requ);
			// ////System.out.println("UserVo in session :"+userVo);

			session.setAttribute("userVO", userVo);

		}
		// Praveen - UID

		if (userVo.getNonLoggedInUid() != null
				&& userVo.isNonLoggedinFlag() == true) // For Non Logged In
		{

			String uid = null;
			if (requ != null) {
				if (StringUtils.isNotBlank(queryString)
						&& queryString.contains("WEBSITE")
						&& StringUtils.isNotBlank(requ.getParameter("agentid"))) {
					uid = requ.getParameter("agentid");
				} else {
					uid = requ.getParameter("UID");
				}
			}

			if (userVo.getSessionDevice() != null) {
				session.setAttribute("sessionDeviceFlag",
						userVo.getSessionDevice());
			}

			if (uid != null && !uid.isEmpty()) {
				if (uid.equals(userVo.getNonLoggedInUid())) {
					// do nothing
				} else {
					userVo.setNonLoggedInUid(uid);
					// HashMap<String,SalesDataEntryPO> uidDetailsPOMap =
					// (HashMap<String,SalesDataEntryPO>)
					// (requ.getSession().getServletContext().getAttribute("UID_DETAILS_MAP"));
					// SalesDataEntryPO uidDetailsPO =
					// getValidUIDDetails(userVo.getNonLoggedInUid(),
					// uidDetailsPOMap);
					// Added by Ritika for valid UID existence-------STARTS
					/*
					 * if(uidDetailsPO == null ||
					 * StringUtils.isBlank(uidDetailsPO.getAgentName())){
					 * SecurityFilterException e1= new
					 * SecurityFilterException("Failed UID Validation");
					 * FLogger.error("securityLoggerError", "JavaEncoding",
					 * "doFilter", "No such UID exists for your role ", e1);
					 * FLogger.error("securityLoggerError", "JavaEncoding",
					 * "doFilter", "No such UID exists for your role", e1);
					 * throw e1; }
					 */
					// Added by Ritika for valid UID existence-------ENDS
					// userVo.setSalesDataModel(uidDetailsPO);
					// userVo.setAgentId(uidDetailsPO.getStr_Agent_Code());
					// userVo.setUsername(uid);
				}
			}

		}// Added by Ritika for valid UID existence-------STARTS
		else { // For Logged IN SellOnline/Partner JSON where UID is provided in
				// url---Security Breach
			String uid = null;
			if (requ != null) {
				uid = requ.getParameter("UID");
				if (uid != null && !uid.isEmpty()) {
					// ServletException e1 = new ServletException(
					// "Failed validation for UID");
					SecurityFilterException e1 = new SecurityFilterException(
							"Failed UID Validation");
					FLogger.error("securityLoggerError", "JavaEncoding",
							"doFilter", "No such UID exists for your role", e1);
					FLogger.error("securityLoggerError", "JavaEncoding",
							"doFilter", "No such UID exists for your role", e1);
					throw e1;
				}
			}
		}
		// Added by Ritika for valid UID existence-------ENDS
		// ////System.out.println("Intranet method has been called");
		boolean isIntranet = intranetAccess(requ);
		// boolean isIntranet = true;
		// ////System.out.println("End of Intranet method");
		if (isIntranet) {
			userVo.setUserDomain("intranet");
		} else {
			userVo.setUserDomain("internet");
		}

		chain.doFilter(req, res);
	}

	private static IPruUser populateUserVO(HttpServletRequest requ) {
		// TODO Auto-generated method stub
		Properties prop = new Properties();
		String websiteSource = "";
		String requFunc = "";
		String sellOnlineRequestedFunctionality = "";
		if (requ.getParameter("websiteSource") != null) {
			websiteSource = requ.getParameter("websiteSource");
		} else if (requ.getSession().getAttribute("websiteSource") != null) {
			websiteSource = (String) requ.getSession().getAttribute(
					"websiteSource");
		}
		if (requ.getParameter("reqFunc") != null) {
			requFunc = requ.getParameter("reqFunc");

		} else if (requ.getSession().getAttribute("reqFunc") != null) {
			requFunc = (String) requ.getSession().getAttribute("reqFunc");
		}

		HttpSession session = ((HttpServletRequest) requ).getSession();
		FileInputStream fis = null;

		try {
			if (websiteSource != null && !websiteSource.isEmpty()) {
				sellOnlineRequestedFunctionality = requFunc;

				if (MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_THIRDPARTY_CONSTANTS_PROPERTIES != null) {
					// ////System.out.println("Inside CONSTANT_IPRUCONFIG_THIRDPARTY_CONSTANTS_PROPERTIES");
					prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_THIRDPARTY_CONSTANTS_PROPERTIES;
				} else {
					// ////System.out.println("Inside CONSTANT_IPRUCONFIG_THIRDPARTY_CONSTANTS");
					fis = new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_THIRDPARTY_CONSTANTS);

					prop.load(fis);
				}

			} else {
				fis = new FileInputStream(GroupConstants.CONSTANT_USER_VO);
				prop.load(fis);
			}
			// prop.load(new
			// FileInputStream(GroupCommonConstants.CONSTANT_USER_VO)); //to
			// load for every request
		} catch (Exception e) {
			// FLogger.debug("securityLoggerDebug", "JavaEncoding",
			// "populateUserVO",
			// "Exception Ocurred: "+e.getMessage());
			e.printStackTrace();
		}
		finally {
			if (fis != null) {
				try {
					fis.close();
				}
				catch (IOException e) {
					e.printStackTrace();
				}
				fis = null;
			}
		}

		IPruUser userVo = new IPruUser();
		Map<String, String> accessMatrix = new HashMap<String, String>();
		Map<String, String> additionalUserDetails = new HashMap<String, String>();

		/* Default values population */
		// Praveen - UID
		userVo.setNonLoggedinFlag(true);
		// userVo.setNonLoggedInUid(prop.getProperty("UID")); //setting default
		// UID
		// HashMap<String,SalesDataEntryPO> uidDetailsPOMap =
		// (HashMap<String,SalesDataEntryPO>)
		// (requ.getSession().getServletContext().getAttribute("UID_DETAILS_MAP"));
		// SalesDataEntryPO uidDetailsPO =
		// getValidUIDDetails(userVo.getNonLoggedInUid(), uidDetailsPOMap);
		// userVo.setSalesDataModel(uidDetailsPO);
		// userVo.setAgentId(uidDetailsPO.getStr_Agent_Code());
		userVo.setRoles(prop.getProperty("ROLE"));
		userVo.setLandingPage(prop.getProperty("LANDING_PAGE"));
		userVo.setUsername(prop.getProperty("UID"));
		userVo.setThirdpartyRole(prop.getProperty("ROLE"));
		userVo.setThirdpartyLoginSource(websiteSource);
		userVo.setGroupsRequestedFunctionality(sellOnlineRequestedFunctionality);
		String remoteIp = requ.getRemoteAddr();
		String userIp = requ.getHeader("True-Client-IP");
		userVo.setRemoteIp(remoteIp);
		userVo.setUserIp(userIp);

		/** Populate access matrix & additional details ***/
		for (String key : prop.stringPropertyNames()) {
			String value = prop.getProperty(key);
			if (key.startsWith(accessMatrixPrefix)) {
				accessMatrix.put(key.replace(accessMatrixPrefix, ""), value); // access
																				// matrix
																				// population
			} else if (key.startsWith(addtnlUserDtlsPrefix)) {
				additionalUserDetails.put(
						key.replace(addtnlUserDtlsPrefix, ""), value); // additional
																		// details
																		// population
			}

		}
		// //System.out.println(accessMatrix);
		userVo.setAdditionalUserDetails((HashMap<String, String>) additionalUserDetails);
		userVo.setAccessMatrix((HashMap<String, String>) accessMatrix);

		if (session.getAttribute("sessionDeviceFlag") != null) {
			userVo.setSessionDevice((String) session
					.getAttribute("sessionDeviceFlag"));
		}

		/***/
		return userVo;
	}

	/*
	 * public static SalesDataEntryPO getValidUIDDetails(String agentId,
	 * HashMap<String, SalesDataEntryPO> uidDetailsPOMap) { //BolLogger
	 * bolLogger=BolLogger.getLogger(ApplicationFormHandler.class);
	 * SalesDataEntryPO oUidDetailsPO = new SalesDataEntryPO(); SalesDataEntryPO
	 * oUidDetailsPO1 = new SalesDataEntryPO();
	 * 
	 * if (agentId != null && !("").equals(agentId) && uidDetailsPOMap != null
	 * && uidDetailsPOMap.size() >0) {
	 * 
	 * if (uidDetailsPOMap.containsKey(agentId)) { oUidDetailsPO1 =
	 * uidDetailsPOMap.get(agentId); if(oUidDetailsPO1!=null) {
	 * oUidDetailsPO.setStr_Agent_Code(oUidDetailsPO1.getStr_Agent_Code());
	 * oUidDetailsPO.setAgentUID(oUidDetailsPO1.getAgentUID());
	 * oUidDetailsPO.setStr_FSC_Code(oUidDetailsPO1.getStr_FSC_Code());
	 * oUidDetailsPO.setStr_Bank(oUidDetailsPO1.getStr_Bank());
	 * oUidDetailsPO.setStr_Branch(oUidDetailsPO1.getStr_Branch());
	 * oUidDetailsPO.setStr_Source(oUidDetailsPO1.getStr_Source());
	 * oUidDetailsPO.setStr_Channel(oUidDetailsPO1.getStr_Channel());
	 * oUidDetailsPO.setStr_CSR_LIM_code(oUidDetailsPO1.getStr_CSR_LIM_code());
	 * oUidDetailsPO.setStr_ICICI_Acc_No(oUidDetailsPO1.getStr_ICICI_Acc_No());
	 * oUidDetailsPO.setStr_Cafos_Code(oUidDetailsPO1.getStr_Cafos_Code());
	 * oUidDetailsPO.setStr_Sp_Code(oUidDetailsPO1.getStr_Sp_Code());
	 * oUidDetailsPO
	 * .setStr_Opportunity_ID(oUidDetailsPO1.getStr_Opportunity_ID()); } } else
	 * { //oUidDetailsPO =
	 * uidDetailsPOMap.get(BOLConstants.BOL_DEFAULT_AGENT_ID); }
	 * 
	 * } else { //oUidDetailsPO =
	 * uidDetailsPOMap.get(BOLConstants.BOL_DEFAULT_AGENT_ID); }
	 * 
	 * 
	 * UidDetailService uidDetailService1 = new UidDetailService();
	 * 
	 * String agentName = null; try { agentName =
	 * uidDetailService1.getAgentName(oUidDetailsPO.getStr_Agent_Code()); }
	 * catch (Exception e) { //bolLogger.debug("agenet ID not found");
	 * e.printStackTrace(); } oUidDetailsPO.setAgentName(agentName);
	 * 
	 * 
	 * return oUidDetailsPO; }
	 */
	public boolean intranetAccess(HttpServletRequest request) {

		boolean isIntranet = true;
		Properties ipAddressObtained = new Properties();
		if (MasterPropertiesFileLoader.CONSTANT_IPADDRESS_OBTAINED_MAPPING_PROPERTIES != null) {
			ipAddressObtained = MasterPropertiesFileLoader.CONSTANT_IPADDRESS_OBTAINED_MAPPING_PROPERTIES;
		} else {
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(GroupConstants.CONSTANT_IPADDRESS_OBTAINED_MAPPING);
				ipAddressObtained.load(fis);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				request.getSession().setAttribute("isIntranetStr", "true");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				request.getSession().setAttribute("isIntranetStr", "true");
			}
			finally {
				if (fis != null) {
					try {
						fis.close();
					}
					catch (IOException e) {
						e.printStackTrace();
					}
					fis = null;
				}
			}
		}

		int IP_169 = Integer.parseInt(ipAddressObtained.getProperty("IP_169"));
		int IP_254 = Integer.parseInt(ipAddressObtained.getProperty("IP_254"));
		int IP_172 = Integer.parseInt(ipAddressObtained.getProperty("IP_172"));
		int IP_16 = Integer.parseInt(ipAddressObtained.getProperty("IP_16"));
		int IP_192 = Integer.parseInt(ipAddressObtained.getProperty("IP_192"));
		int IP_168 = Integer.parseInt(ipAddressObtained.getProperty("IP_168"));
		int IP_0 = Integer.parseInt(ipAddressObtained.getProperty("IP_0"));
		// int IP_255=Integer.parseInt(ipAddressObtained.getProperty("IP_255"));
		int IP_10 = Integer.parseInt(ipAddressObtained.getProperty("IP_10"));
		int IP_31 = Integer.parseInt(ipAddressObtained.getProperty("IP_31"));

		String requestIPAddress = request.getRemoteAddr();
		HttpSession session = ((HttpServletRequest) request).getSession();
		String[] ipPartStr = null;

		// ////System.out.println("Remote address :: "+requestIPAddress);

		if (requestIPAddress.contains(".")) {
			ipPartStr = requestIPAddress.split("\\.");
		} else if (requestIPAddress.contains(":")) {
			ipPartStr = requestIPAddress.split(":");
		}

		int[] ipPart = new int[ipPartStr.length];

		for (int n = 0; n < ipPart.length; n++) {
			ipPart[n] = Integer.parseInt(ipPartStr[n]);
		}

		if (ipPart[0] == (IP_10)) {
			isIntranet = true;
		} else if (ipPart[0] == (IP_0) && ipPart[1] == (IP_0)) {
			// ////System.out.println("1st ip"+IP_0+"second ip"+IP_0);
			isIntranet = true;
		} else if (ipPart[0] == (IP_169) && ipPart[1] == (IP_254)) {
			isIntranet = true;
		} else if (ipPart[0] == (IP_172)) {

			for (int i = IP_16; i <= IP_31; i++) {
				if (ipPart[1] == (i))
					isIntranet = true;
			}
		} else if (ipPart[0] == (IP_192) && ipPart[1] == (IP_168)) {
			isIntranet = true;
		} else {
			isIntranet = false;
		}

		return isIntranet;
	}

	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		try {
			whitelisturl = MasterPropertiesFileLoader
					.propertyFileLoader(GroupConstants.CONSTANT_WHITELISTURL_XSS_PROPERTIES);
			whitelistUrl = whitelisturl.getProperty("whitelisturl");
			whiteListURLArray = whitelistUrl.split(",");
			contentsecurityconfi = MasterPropertiesFileLoader
					.propertyFileLoader(GroupConstants.CONTENT_SECURITY_POLICY_PROPERTIES);
			contentSecurityConfi = contentsecurityconfi
					.getProperty("contentSecurityConfi");
			contentSecurityConfi_IFRAME = contentsecurityconfi.getProperty("contentSecurityConfi_IFRAME");
			header = contentsecurityconfi.getProperty("header");
			header_IFRAME = contentsecurityconfi.getProperty("header_IFRAME").trim();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		populateUserVO(null);
	}
}
