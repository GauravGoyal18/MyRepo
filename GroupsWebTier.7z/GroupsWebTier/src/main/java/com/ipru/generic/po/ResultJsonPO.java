package com.ipru.generic.po;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;

public class ResultJsonPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Serializable result;
	private Collection results;
	private Map resultMap;

	public Serializable getResult() {
		return result;
	}

	public void setResult(Serializable result) {
		this.result = result;
	}

	public Collection getResults() {
		return results;
	}

	public void setResults(Collection results) {
		this.results = results;
	}

	public Map getResultMap() {
		return resultMap;
	}

	public void setResultMap(Map resultMap) {
		this.resultMap = resultMap;
	}
	
	
	
	

}
