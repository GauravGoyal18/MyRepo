package com.ipru.generic.po;

public class FileUploadResultPo {

	private String docName;
	private String documentName;
	private long docSize;
	private String docType;
	private String functionality;
	private String uploadMsg;
	private String errorCode;
	private String clientId;
	private String contentType;
	private String docPath;
	private String policyNo;
	private String role;
	private String docFileType;
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public long getDocSize() {
		return docSize;
	}
	public void setDocSize(long docSize) {
		this.docSize = docSize;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getFunctionality() {
		return functionality;
	}
	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getUploadMsg() {
		return uploadMsg;
	}
	public void setUploadMsg(String uploadMsg) {
		this.uploadMsg = uploadMsg;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getDocPath() {
		return docPath;
	}
	public void setDocPath(String docPath) {
		this.docPath = docPath;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getDocFileType() {
		return docFileType;
	}
	public void setDocFileType(String docFileType) {
		this.docFileType = docFileType;
	}
	@Override
	public String toString() {
		return "FileUploadResultPo [docName=" + docName + ", documentName="
				+ documentName + ", docSize=" + docSize + ", docType="
				+ docType + ", functionality=" + functionality + ", uploadMsg="
				+ uploadMsg + ", errorCode=" + errorCode + ", clientId="
				+ clientId + ", contentType=" + contentType + ", docPath="
				+ docPath + ", policyNo=" + policyNo + ", role=" + role
				+ ", docFileType=" + docFileType + "]";
	}
	
}
