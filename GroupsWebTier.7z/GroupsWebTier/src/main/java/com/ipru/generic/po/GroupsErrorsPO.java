package com.ipru.generic.po;

import java.io.Serializable;

public class GroupsErrorsPO implements Serializable {
	
	private static final long serialVersionUID = 1L;

    private String errorMsg;

    @Override
	public String toString() {
		return errorMsg;
	}

	public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }


}
