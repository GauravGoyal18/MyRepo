package com.ipru.otp.po;

import org.apache.commons.lang3.StringUtils;

import com.ipru.groups.po.GroupsBasePo;

/**
 * @author VivekGrewal554674(TCS)
 */
public class OTPNumberParamBean extends GroupsBasePo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String advisorCode = "";
	private String advisorName = "";
	private String handleClickCallBack = "";
	private String functionality = "";
	private String custFirstName = "";
	private String custLastName = "";
	private String personalEmailId = "";
	private String verfcnStatusElemId = "";
	private String loginRole = "";

	public String getLoginRole() {
		return loginRole;
	}

	public void setLoginRole(String loginRole) {
		this.loginRole = loginRole;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setEmail1Valid(boolean isEmail1Valid) {
		this.isEmail1Valid = isEmail1Valid;
	}

	public void setEmail2Valid(boolean isEmail2Valid) {
		this.isEmail2Valid = isEmail2Valid;
	}

	public void setMobileValid(boolean isMobileValid) {
		this.isMobileValid = isMobileValid;
	}

	public String getVerfcnStatusElemId() {
		return verfcnStatusElemId;
	}

	public void setVerfcnStatusElemId(String verfcnStatusElemId) {
		this.verfcnStatusElemId = verfcnStatusElemId;
	}

	public String getCustFirstName() {
		return custFirstName;
	}

	public void setCustFirstName(String custFirstName) {
		this.custFirstName = custFirstName;
	}

	public String getCustLastName() {
		return custLastName;
	}

	public void setCustLastName(String custLastName) {
		this.custLastName = custLastName;
	}

	public String getFunctionality() {
		return functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}

	private boolean isEmail1Valid = Boolean.FALSE;
	private boolean isEmail2Valid = Boolean.FALSE;
	private boolean isMobileValid = Boolean.FALSE;

	public boolean isEmail1Valid() {
		if (email1 != null && email1.indexOf('@') != -1)
			isEmail1Valid = Boolean.TRUE;
		return isEmail1Valid;
	}

	public boolean isEmail2Valid() {
		if (email2 != null && email2.indexOf('@') != -1)
			isEmail2Valid = Boolean.TRUE;
		return isEmail2Valid;
	}

	public boolean isMobileValid() {
		if (StringUtils.isNotBlank(mobile) && mobile.trim().matches("[0-9]+") && mobile.length() >= 10) {
			isMobileValid = Boolean.TRUE;
		}
		return isMobileValid;
	}

	public String getHandleClickCallBack() {
		return handleClickCallBack;
	}

	public void setHandleClickCallBack(String handleClickCallBack) {
		this.handleClickCallBack = handleClickCallBack;
	}

	public String getAdvisorCode() {
		return advisorCode;
	}

	public void setAdvisorCode(String advisorCode) {
		this.advisorCode = advisorCode;
	}

	public String getAdvisorName() {
		return advisorName;
	}

	public void setAdvisorName(String advisorName) {
		this.advisorName = advisorName;
	}

	public String getEmail1() {
		return email1;
	}

	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	public String getEmail2() {
		return email2;
	}

	public void setEmail2(String email2) {
		this.email2 = email2;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getOtpNumber() {
		return otpNumber;
	}

	public void setOtpNumber(String otpNumber) {
		this.otpNumber = otpNumber;
	}

	private String email1 = "";
	private String email2 = "";
	private String mobile = "";
	private String custId = "";
	private String otpNumber = "";

	private String identifierCode = "";
	private String identifierType = "";

	public String getIdentifierCode() {
		return identifierCode;
	}

	public void setIdentifierCode(String identifierCode) {
		this.identifierCode = identifierCode;
	}

	public String getIdentifierType() {
		return identifierType;
	}

	public void setIdentifierType(String identifierType) {
		this.identifierType = identifierType;
	}

	public String getPersonalEmailId() {
		return personalEmailId;
	}

	public void setPersonalEmailId(String personalEmailId) {
		this.personalEmailId = personalEmailId;
	}
}
