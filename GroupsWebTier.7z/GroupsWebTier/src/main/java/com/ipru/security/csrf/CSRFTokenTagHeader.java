package com.ipru.security.csrf;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.lang3.StringUtils;

import com.tcs.logger.FLogger;

public class CSRFTokenTagHeader extends TagSupport {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean plainToken = false;
	private String g_StrMethodName = "";

	@Override
	public int doStartTag() throws JspException {
		//g_StrMethodName = "doStartTag";
		final CSRFTokenService csrfTokenService = HelperRegistry.getHelper(super.pageContext.getServletContext(), super.pageContext.getRequest(), CSRFTokenService.class, "csrfTokenService");
		final String token = csrfTokenService.setTokenInSession((HttpServletRequest) super.pageContext.getRequest());
		FLogger.info("securityLogger", "CSRFTokenTagHeader", "doStartTag","Adding token to Form Post");
		
		if(!StringUtils.isBlank(token))
			try {
				if(plainToken) {
					pageContext.getOut().write(token);
//				   ////System.out.println("Token-----:::"+token);
				}
				else {
					pageContext.getOut().write(String.format("<input type=\"hidden\" name=\"%1$s\" id=\"%1$s\" value=\"%2$s\" />", CSRFTokenService.TOKEN_PARAMETER_NAME, token));
//					////System.out.println("Not a Plain Token-----:::"+token);
				}
			} catch (IOException e) {				
				
				FLogger.error("securityLoggerError", this.getClass().getCanonicalName(), g_StrMethodName,e.getMessage());
			}
		return SKIP_BODY;
	}

}

