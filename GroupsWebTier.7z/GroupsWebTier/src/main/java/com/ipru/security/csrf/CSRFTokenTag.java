package com.ipru.security.csrf;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;
 
import org.apache.commons.lang3.StringUtils;
import com.tcs.logger.FLogger;
 

 
/**
 * Creates a hidden input field with the CSRF Token
 * @author michael.simons, 2011-09-20
 */
public class CSRFTokenTag extends TagSupport {
	private static final long serialVersionUID = 745177955805541350L;
 
	private boolean plainToken = false;
	private String g_StrMethodName = "";
 
	@Override
	public int doStartTag() throws JspException {
		g_StrMethodName = "doStartTag";
		final CSRFTokenService csrfTokenService = HelperRegistry.getHelper(super.pageContext.getServletContext(), super.pageContext.getRequest(), CSRFTokenService.class, "csrfTokenService");
		final String token = csrfTokenService.getTokenFromSession((HttpServletRequest) super.pageContext.getRequest());
		
		FLogger.info("securityLogger", "CSRFTokenTag", "doStartTag","Adding token to Form Post");
		
		if(!StringUtils.isBlank(token))
			try {
				if(plainToken) {
					pageContext.getOut().write(token);
//				   ////System.out.println("Token-----:::"+token);
				}
				else {
					//pageContext.getOut().write(String.format("<input type=\"hidden\" name=\"%1$s\" id=\"%1$s\" value=\"%2$s\" data-ng-model=\"xsrfToken\" ng-init=\"xsrfToken=1111\"/>", CSRFTokenService.TOKEN_PARAMETER_NAME, token));
					//pageContext.getOut().write(String.format("<input type=\"hidden\" name=\"%1$s\" id=\"%1$s\" value=\"%2$s\" data-ng-model=\"xsrfToken\" />", CSRFTokenService.TOKEN_PARAMETER_NAME, token));
					pageContext.getOut().write(String.format("<input type=\"hidden\" name=\"%1$s\" id=\"%1$s\" value=\"%2$s\" />", CSRFTokenService.TOKEN_PARAMETER_NAME, token));
//					////System.out.println("Not a Plain Token-----:::"+token);
				}
			} catch (IOException e) {				
				
				FLogger.error("securityLoggerError", this.getClass().getCanonicalName(), g_StrMethodName,e.getMessage());
			}
		return SKIP_BODY;
	}
 
	@Override
	public int doEndTag() throws JspException {
		return EVAL_PAGE;
	}
 
	public boolean isPlainToken() {
		return plainToken;
	}
 
	public void setPlainToken(boolean plainToken) {
		this.plainToken = plainToken;
	}
 
	public static String getTokenParameterName() {
		return CSRFTokenService.TOKEN_PARAMETER_NAME;
	}
}