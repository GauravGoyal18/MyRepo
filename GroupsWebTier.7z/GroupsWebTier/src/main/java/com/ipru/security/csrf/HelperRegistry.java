package com.ipru.security.csrf;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;

import org.springframework.util.ObjectUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.support.RequestContextUtils;
import org.apache.commons.lang3.StringUtils;

import com.tcs.logger.FLogger;

public class HelperRegistry {
	
	
	
	@SuppressWarnings("unchecked")
	public static <T> T getHelper(final ServletContext servletContext,
			ServletRequest servletRequest, final Class<T> clazz, final String name) {
			     final WebApplicationContext wc =
			RequestContextUtils.getWebApplicationContext(servletRequest,
			servletContext);
			  
			     T rv = null;
			     if(wc != null) {
			         if(StringUtils.isBlank(name)) {
			             //rv = wc.getBeansOfType(clazz).
			         }
			         else {
			             rv = (T)wc.getBean(name, clazz);
			         }

			     }
			     return rv;

	}
}
