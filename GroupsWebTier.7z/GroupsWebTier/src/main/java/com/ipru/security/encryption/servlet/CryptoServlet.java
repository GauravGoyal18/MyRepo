package com.ipru.security.encryption.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.KeyPair;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.Date;

import javacryption.aes.AesCtr;
import javacryption.jcryption.JCryption;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.logger.FLogger;

/**
 * Servlet implementation class CryptoServlet
 */
public class CryptoServlet extends HttpServlet {

	 

    /**

    * serialVersionUID

    */

    private static final long serialVersionUID = 4510110365995157499L;



    /**

    * Handles a POST request

    *

     * @see HttpServlet

    */

    public void doPost(HttpServletRequest req, HttpServletResponse res)

                  throws IOException, ServletException {

           HttpServletRequest request = (HttpServletRequest) req;

           HttpServletResponse response = (HttpServletResponse) res;



           /** Generates a KeyPair for RSA **/

           if (req.getParameter("generateKeyPair") != null

                        && req.getParameter("generateKeyPair").equals("true")) {



                  JCryption jc = new JCryption();

                  KeyPair keys = jc.getKeyPair();

                  request.getSession()

                               .setAttribute("jCryptionKeys", keys);

                  String e = jc.getPublicExponent();

                  String n = jc.getKeyModulus();

                  String md = String.valueOf(jc.getMaxDigits());



                  /** Sends response **/

                  PrintWriter out = response.getWriter();

                  out.print("{\"e\":\"" + e + "\",\"n\":\"" + n

                               + "\",\"maxdigits\":\"" + md + "\"}");

                  //////System.out.println("{\"e\":\"" + e + "\",\"n\":\"" + n

                    //      + "\",\"maxdigits\":\"" + md + "\"}");

                  return;

           }

           /** jCryption handshake **/

           else if (req.getParameter("handshake") != null

                        && req.getParameter("handshake").equals("true")) {



                  /** Decrypts password using private key **/

                  JCryption jc = new JCryption((KeyPair) request.getSession()

                               .getAttribute("jCryptionKeys"));

                  String key = jc.decrypt(req.getParameter("key"));



                  request.getSession()

                               .removeAttribute("jCryptionKeys");

                  request.getSession()

                               .setAttribute("jCryptionKey", key);

                 // ////System.out.println("enc key"+key);

                  /** Encrypts password using AES **/

                  String ct = AesCtr.encrypt(key, key, 256);



                  /** Sends response **/

                  PrintWriter out = response.getWriter();

                  out.print("{\"challenge\":\"" + ct + "\"}");

                 // ////System.out.println("{\"challenge after encrypting\":\"" + ct + "\"}");

                  return;

           }

           /** jCryption request to decrypt a String **/

           else if (req.getParameter("decryptData") != null

                        && req.getParameter("decryptData").equals("true")

                        && req.getParameter("jCryption") != null) {



                  /** Decrypts the request using password **/

                  String key = (String) request.getSession().getServletContext()

                               .getAttribute("jCryptionKey");



                  String pt = AesCtr.decrypt(req.getParameter("jCryption"), key, 256);



                  /** Sends response **/

                  PrintWriter out = response.getWriter();

                  out.print("{\"data\":\"" + pt + "\"}");

                  //////System.out.println("{\"data\":\"" + pt + "\"}");
                  return;

           }

           /** jCryption request to encrypt a String **/

           else if (req.getParameter("encryptData") != null

                        && req.getParameter("encryptData").equals("true")

                        && req.getParameter("jCryption") != null) {



                  /** Encrypts the request using password **/

                  String key = (String) request.getSession().getServletContext()

                               .getAttribute("jCryptionKey");



                  String ct = AesCtr.encrypt(req.getParameter("jCryption"), key, 256);



                  /** Sends response **/

                  PrintWriter out = response.getWriter();

                  out.print("{\"data\":\"" + ct + "\"}");

                 // ////System.out.println("{\"data\":\"" + ct + "\"}");
                  return;

           }

           /** A test request from jCryption **/

           else if (req.getParameter("decryptTest") != null

                        && req.getParameter("decryptTest").equals("true")) {



                  /** Encrypts a timestamp **/

                  String key = (String) request.getSession().getServletContext()

                               .getAttribute("jCryptionKey");



                  String date = DateFormat.getInstance().format(new Date());



                  String ct = AesCtr.encrypt(date, key, 256);



                  /** Sends response **/

                  PrintWriter out = response.getWriter();

                  out.print("{\"encrypted\":\"" + ct + "\", \"unencrypted\":\""

                               + date + "\"}");
                  //////System.out.println("{\"encrypted\":\"" + ct + "\", \"unencrypted\":\""

                  //             + date + "\"}");

                  return;

           }     

          



          

    }



    /**

    * Handles a GET request

    *

     * @see HttpServlet

    */

    public void doGet(HttpServletRequest req, HttpServletResponse res)

                  throws IOException, ServletException {

           doPost(req, res);

    }

   

   

   

    public String decriptPassword(HttpServletRequest req,String loginPass){   

    String key = (String)req.getSession().getAttribute("jCryptionKey");

    String encUrl=loginPass.replaceAll(" ","+");

    if(key==null||encUrl==null) {
    	FLogger.info("securityLogger","CryptoServlet","decriptPassword(HttpServletRequest req,String loginPass)","Either key or url is null. key="+key+" and url="+encUrl);
    	FLogger.info("securityLogger","CryptoServlet","decriptPassword(HttpServletRequest req,String loginPass)","Trace is "+Arrays.toString(new Exception().getStackTrace()));
    }
    String pt = AesCtr.decrypt(encUrl, key, 256);
    return pt;

 }

   

    public static void main(String args[]) {

           String pt = AesCtr.decrypt("ZAPahm0a0lQ4JYr1GBak", "02cab456edcba255fcf581a1749bbcad0fb6c898653d7fe6df72ccda28bdc06d2c412bd404eb52a8697d7d1d750a133989683b4fc36ece443ffdd8c228b62f75", 256);

         //  ////System.out.println("pt:"+pt);

          

    }

}
