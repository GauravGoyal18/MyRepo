package com.ipru.security.csrf;

import java.security.SecureRandom;
 
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
 

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.ipru.security.csrf.CSRFTokenService;
import com.tcs.logger.FLogger;

import org.apache.commons.codec.binary.Base64;

@Service("csrfTokenService")
public class CSRFTokenServiceImpl implements CSRFTokenService {
	private final SecureRandom random = new SecureRandom();
 
	@Override
	public String generateToken() {
		String salt =RandomStringUtils.random(20, 0, 0, true, true);
		
	//	//System.out.println(salt+salt.length());
		return salt;
	}
 
	@Override
	public String getTokenFromSession(final HttpServletRequest request) {
		return  this.getTokenFromSessionImpl(request.getSession(false));
	}
 
	String getTokenFromSessionImpl(final HttpSession session) {
		String token = null;
		if(session != null) {
			token = (String) session.getAttribute(TOKEN_ATTRIBUTE_NAME);
			if(StringUtils.isBlank(token)) {
				session.setAttribute(TOKEN_ATTRIBUTE_NAME, (token = generateToken()));
				FLogger.info("securityLoggerError", "CSRFTokenServiceImpl", "getTokenFromSessionImpl(final HttpServletRequest request)", "new token in session generated sessionId : "+session.getId()+" Token : "+token);
			}
		}
		return token;
	}
 
	@Override
	public boolean acceptsTokenIn(HttpServletRequest request) {
		boolean rv = false;
		// Token is only verified if principal is not null
		if(request!=null && request.getServletPath()!=null &&  request.getServletPath().contains("uploadfiles") || request.getServletPath().contains("onlogout")) 
		{
			rv = true;
		}
		else {
			final HttpSession session = request.getSession(false);
			rv = session != null && (this.getTokenFromSessionImpl(session).equals(request.getParameter(TOKEN_PARAMETER_NAME)) || this.getTokenFromSessionImpl(session).equals(request.getHeader(TOKEN_PARAMETER_NAME)));
		}
		return rv;
	}

public static void main(String[] args) {
	new CSRFTokenServiceImpl().generateToken();
}

@Override
public String setTokenInSession(HttpServletRequest request) {
	// TODO Auto-generated method stub
	return  this.setTokenInSessionImpl(request);
}

private String setTokenInSessionImpl(final HttpServletRequest request) {
	String token = null;
	HttpSession session = request.getSession(false);
	//String flowId = obj.getFlowId(request);
	//FLogger.info("CSRFTokenTag", "CSRFTokenServiceImpl : ", "setTokenInSessionImpl","Setting token in session");
	if (session != null ){ 
		token = (String) session.getAttribute(TOKEN_ATTRIBUTE_NAME);
		session.setAttribute(TOKEN_ATTRIBUTE_NAME, (token = generateToken()));
		FLogger.info("securityLogger", "CSRFTokenServiceImpl", "setTokenInSessionImpl(final HttpServletRequest request)", "new token is session is set sessionId sessionId : "+session.getId() +" token : "+token);
		
	}
	return token;
}


}
