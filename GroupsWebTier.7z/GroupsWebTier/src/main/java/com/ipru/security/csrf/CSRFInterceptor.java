package com.ipru.security.csrf;

import java.util.Enumeration;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.logger.FLogger;

public class CSRFInterceptor implements HandlerInterceptor {
	@Autowired
	private CSRFTokenService csrfTokenService;
	public final static String TOKEN_PARAMETER_NAME1 = "_tk";
	private static Properties prop = null;

	static {
		try {
			prop = MasterPropertiesFileLoader.propertyFileLoader(GroupConstants.CONSTANT_CSRFURL_PROPERITIES);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		boolean rv = true;
		String tokenValue = null;
		// FLogger.info("", "CSRFInterceptor",
		// "preHandle","CsrfInteceptor Initiated");

		StringBuffer reqBuf = request.getRequestURL();// http://localhost:9080/GroupsDigitization/YYEmployeeForm.htm
		String reqPage = reqBuf.substring(reqBuf.lastIndexOf("/") + 1, reqBuf.length()); // YYEmployeeForm.htm
		final HttpSession session = request.getSession(false);
		CSRFTokenServiceImpl CSRFTokenServiceImpl = new CSRFTokenServiceImpl();
		String keyParam = prop.getProperty(reqPage);

		if ("GET".equalsIgnoreCase(request.getMethod())) {

			if (request.getQueryString() != null && keyParam != null && request.getQueryString().contains(keyParam)) {

				FLogger.error("securityLoggerError", "CSRFInterceptor", "preHandle", "CsrfInteceptor Post request initiated Method :  " + request.getMethod() + " Id : " + request.getSession().getId()
						+ "URL : " + reqPage + " forbiddent :  " + HttpServletResponse.SC_FORBIDDEN + "  rv: false");
				response.addHeader("IPRU-iDigital-InvalidCSRFToken", Boolean.toString(true));
				response.sendError(HttpServletResponse.SC_FORBIDDEN);
				rv = false;

			}
			FLogger.info("securityLogger", "CSRFInterceptor", "preHandle", "request.getMethod() : " + request.getMethod() + "url : " + reqPage + " request.getParameter(TOKEN_PARAMETER_NAME) : "
					+ request.getParameter(TOKEN_PARAMETER_NAME1));

			Enumeration headerNames = request.getHeaderNames();
			tokenValue = request.getHeader("_tk");
			// tokenValue = "";
			// //System.out.println(tokenValue+" Token value ((((((((((((((((((((((((((((");
			if (session != null && null != tokenValue) {
				if (!csrfTokenService.acceptsTokenIn(request)) {
					FLogger.error("securityLoggerError", "CSRFInterceptor", "preHandle", "CsrfInteceptor GET request initiated Method :  " + request.getMethod() + " Id : "
							+ request.getSession().getId() + "URL : " + reqPage + " forbiddent :  " + HttpServletResponse.SC_FORBIDDEN + "  rv: false");

					response.addHeader("IPRU-iDigital-InvalidCSRFToken", Boolean.toString(true));
					response.sendError(HttpServletResponse.SC_FORBIDDEN);
					rv = false;
				}
			}
		}

		if (request.getContentType() == null || (request.getContentType() != null && !(request.getContentType().toLowerCase().indexOf("multipart/form-data") > -1))) {

			if (CSRFTokenService.METHODS_TO_CHECK.contains(StringUtils.defaultIfEmpty(request.getMethod(), "").toUpperCase()) && !csrfTokenService.acceptsTokenIn(request)) {

				FLogger.error("securityLoggerError", "CSRFInterceptor", "preHandle", "CsrfInteceptor Post request initiated Method :  " + request.getMethod() + " Id : " + request.getSession().getId()
						+ "URL : " + reqPage + " forbiddent :  " + HttpServletResponse.SC_FORBIDDEN + " rv: false");
				response.addHeader("IPRU-iDigital-InvalidCSRFToken", Boolean.toString(true));
				response.sendError(HttpServletResponse.SC_FORBIDDEN);
				rv = false;

			}

		}

		return rv;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
	}

	public CSRFTokenService getCsrfTokenService() {

		return csrfTokenService;
	}

	public void setCsrfTokenService(CSRFTokenService csrfTokenService) {

		this.csrfTokenService = csrfTokenService;
	}

}
