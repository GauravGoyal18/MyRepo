package com.ipru.groups.handler;

import org.springframework.webflow.execution.RequestContext;

import com.ipru.otp.po.OTPNumberParamBean;

public class ProfilePOCHandler extends IneoBaseHandler {

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		// TODO Auto-generated method stub
		
	}/*
	
	*//**
	 * 
	 *//*
	
	private static final long serialVersionUID = 1L;
	public static final String ErrorMsg="Something Went Wrong Please Try Again!";
	
	@MethodPost
	public Event getBizRequestForProfileAccessDetails(RequestContext context) throws Exception{
		
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "getBizRequestForProfileAccessDetails Method Start ");

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				
				List<FieldAccessMappingVO> fieldAccessMappingVoList = null;
				
				fieldAccessMappingVoList = getFieldAccessMappingList(context);
				IPruUser userVo = new IPruUser();
				String policyNo = null;
				String role = null;
				String screenName = null;
				List<RoleScreenAccessMappingVO> accessMappingList;

				if (httpSession != null) {  
					screenName = (String) context.getFlowScope().get("screenName");
					
					userVo = (IPruUser) httpSession.getAttribute("userVO");
			
		
		if (userVo!= null  && screenName!=null && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {  // userVO b nahi null hoga
			policyNo = userVo.getPolicyNo();
		
			FLogger.error("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "When page load Policy No in session : " + policyNo);
			role = userVo.getRoles();
		
			FLogger.error("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "When page load role in session : " + role);
			accessMappingList = userVo.getLstRoleScreenAccessMapping();
		
			
			ProfileUpdateLoadRequestPO profileUpdateLoadRequestPO = new ProfileUpdateLoadRequestPO();
			profileUpdateLoadRequestPO.setPolicyNo(policyNo);
			profileUpdateLoadRequestPO.setRole(role);
			profileUpdateLoadRequestPO.setScreenName(screenName);
			ProfileUpdateLoadRequestVO profileUpdateLoadRequestVO=null;
			if(profileUpdateLoadRequestPO!=null)
				{
					profileUpdateLoadRequestVO = dozerBeanMapper.map(profileUpdateLoadRequestPO, ProfileUpdateLoadRequestVO.class);
				}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "profileUpdateLoadRequestPO  is null");
				throw new IPruException("Error","GPU01", ErrorMsg);
			}

			if (profileUpdateLoadRequestVO!= null) {
				if(CollectionUtils.isNotEmpty(accessMappingList) && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)){
				profileUpdateLoadRequestVO.setAccessMappingList(accessMappingList);
				profileUpdateLoadRequestVO.setFieldAccessMappingList(fieldAccessMappingVoList);
				Object[] paramArray = new Object[1];
				paramArray[0] = profileUpdateLoadRequestVO;
				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				context.getFlowScope().put("loadDashboardBizReq", obj_bizReq);
				}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "accessMappingList and  fieldAccessMappingVoList is null");
			
					throw new IPruException("Error","GPU01", ErrorMsg);
				}

			}
			else {
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "UserVo  is null");
				
				throw new IPruException("Error","GPU01", ErrorMsg);
			}
			}
			else{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");
			
				throw new IPruException("Error","GPU01", ErrorMsg);
			}
		}
		else {
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "session is null");
		
			throw new IPruException("Error","GPU01", ErrorMsg);
		}
	}
	else {
		FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "Session is null && context is Null");
		throw new IPruException("Error","GPU01", ErrorMsg);
	}
		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "context should not be null",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "getBizRequestForProfileAccessDetails Method End ");

		return success();
	}
	
	@MethodPost
	public Event getBizResponseForProfileAccessDetails(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseForProfileAccessDetails", "getBizResponseForProfileAccessDetails Method Start");
		   Properties prop=new Properties();
	       prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateLoadRequestDetailsVO profileUpdateLoadRequestDetailsVO = null;
		
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson="";

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				if (httpSession != null) {
					bizRes = (BizResponse) context.getFlowScope().get("bizResForProfileAccessDetails");
					
					if (bizRes != null) {
						responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
							throwINeoFlowException(bizRes.getStatusVO(), context);
						}
						else {
							profileUpdateLoadRequestDetailsVO = (ProfileUpdateLoadRequestDetailsVO) bizRes.getTransferObjects().get("response1");
							if (profileUpdateLoadRequestDetailsVO != null) {
								ProfileUpdateLoadRequestDetailsPO profileUpdateLoadRequestDetailsPO=dozerBeanMapper.map(profileUpdateLoadRequestDetailsVO, ProfileUpdateLoadRequestDetailsPO.class);
								if(profileUpdateLoadRequestDetailsPO!=null){
								List<ProfilePOCPO> data=new ArrayList<ProfilePOCPO>();
									ProfilePOCPO profilePOCPO=null;
									
								Map<String, FieldAccessMappingPO> map =profileUpdateLoadRequestDetailsPO.getFieldAccessMappingMap();
								if(!map.isEmpty() && map!=null && prop!=null){
										for (Entry<String, FieldAccessMappingPO> entry : map.entrySet())
										{
											profilePOCPO=new ProfilePOCPO();
											String getId=entry.getKey().toString();
											profilePOCPO.setRdComponent(getId);//setID here
											
											if(prop.getProperty("companyAddressChangeProp").equals(profilePOCPO.getRdComponent()))//form Enable purpose
											{
												profilePOCPO.setOpShow(prop.getProperty("editopShow"));
											}
											if(prop.getProperty("contactPersonChangeProp").equals(profilePOCPO.getRdComponent()))//form Enable purpose
											{
												profilePOCPO.setOpShow(prop.getProperty("editopShow"));
											}
											if(prop.getProperty("authorizedSignatoryChangeProp").equals(profilePOCPO.getRdComponent()))//form Enable purpose
												{
												profilePOCPO.setOpShow(prop.getProperty("editopShow"));
											}
											if(prop.getProperty("bankAccountDetailsChangeProp").equals(profilePOCPO.getRdComponent()))//form Enable purpose
											{
											profilePOCPO.setOpShow(prop.getProperty("editopShow"));
											}
											FieldAccessMappingPO fieldAccessMappingVO=entry.getValue();
											FieldAccessMappingPO fieldAccessMappingPO=dozerBeanMapper.map(fieldAccessMappingVO, FieldAccessMappingPO.class);
											int filedId=(int)fieldAccessMappingPO.getRdComponentPosId();
											profilePOCPO.setRdComponentPosId(filedId);

											int filedGroupCode=(int) fieldAccessMappingPO.getRdParentComponentId();
											
											profilePOCPO.setRdParentComponentId(filedGroupCode);
											
											int ngShow=Integer.parseInt(fieldAccessMappingPO.getOpShow());
											profilePOCPO.setOpShow(fieldAccessMappingPO.getOpShow());
											profilePOCPO.setOpShowDisabled(fieldAccessMappingPO.getOpShowDisabled());
											profilePOCPO.setOpShowEdit(fieldAccessMappingPO.getOpShowEdit());
											data.add(profilePOCPO);
										}
										
										if(CollectionUtils.isNotEmpty(data)){
											List filedIdList=new ArrayList();
											ResultJsonPO result = new ResultJsonPO();
											Map<String,Object> map1 = new HashMap<String,Object>(1);
											for (ProfilePOCPO profilePOCPO1 : data) {
												if(profilePOCPO1!=null){
													map1.put(profilePOCPO1.getRdComponent(), profilePOCPO1);
													filedIdList.add(profilePOCPO1.getRdComponent());
												}
											}
											httpSession.setAttribute("filedIdList",filedIdList);
											httpSession.setAttribute("profileAccessDetails",map1);
											result.setResultMap(map1);
											Gson gson = new Gson();
											resultJson = gson.toJson(result);
											context.getFlowScope().put("Response", resultJson);
										}
										else
										{
											 throw new IPruException("Error","GPU01", ErrorMsg);
										}
										
								}
								else{
									FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "map should not be null");
									 throw new IPruException("Error","GPU01", ErrorMsg);
								}
								}
								else
								{
									FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "profileUpdateLoadRequestDetailsPO should not be null");
									 throw new IPruException("Error","GPU01", ErrorMsg);
									
								}
								
							}
							else {
								FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "Data from service should not be null");
								 throw new IPruException("Error","GPU01", ErrorMsg);
							}
						}
					}
					else {
						FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "bizRes should not be null");
						 throw new IPruException("Error","GPU01", ErrorMsg);
					}

				}

				else {
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "Session is null");
					 throw new IPruException("Error","GPU01", ErrorMsg);
				}
			}
			else {
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestForProfileAccessDetails", "Context from session is null");
				 throw new IPruException("Error","GPU01", ErrorMsg);
			}
		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseForProfileAccessDetails", "context should not be null");
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseForProfileAccessDetails", "getBizResponseForProfileAccessDetails Method End");

		return success();
	}

	
	
	@MethodPost
	public Event getBizResponseCompanyAddressChangeJson(RequestContext context)throws Exception
	{
		try{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseCompanyAddressChangeJson", "getBizResponseCompanyAddressChangeJson Method Start ");
		String resultJson="";
	
		Properties prop=new Properties();
	    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
	    if(prop!=null){
	    		ProfileUpdateUtil utility=new ProfileUpdateUtil();
	    		String[] CompanyAddreeArray=utility.getCompanyAddressChangeArray();
		if(CompanyAddreeArray!=null && CompanyAddreeArray.length>0){
				TreeSet<String> actualFormField = new TreeSet<String>(Arrays.asList(CompanyAddreeArray));
				Map<String,Object> map = new HashMap<String,Object>();
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if(httpSession!=null){
					map=(Map<String, Object>) httpSession.getAttribute("profileAccessDetails");
		
					if(!map.isEmpty() && map!=null){
						Iterator it = map.entrySet().iterator();
						List<ProfileUpdateDetailsPo> poList=new ArrayList();
						while (it.hasNext()) {
						ProfileUpdateDetailsPo po=new ProfileUpdateDetailsPo();
						Map.Entry pair = (Map.Entry)it.next(); 
	       
						String key=(String)(pair.getKey());
	       
						if(key!=null)
						{
							if(actualFormField.contains(key))
							{
								po.setFieldName(key);
								poList.add(po);
							}
						}
	       
					}
	   
	    ResultJsonPO result = new ResultJsonPO();
	    Map<String,Object> getPoListMap = new HashMap<String,Object>(1);
	    if(CollectionUtils.isNotEmpty(poList)){
	    	
		
			for (ProfileUpdateDetailsPo profilePOCVO : poList) {
				if(profilePOCVO!=null){
					
					
					getPoListMap.put(profilePOCVO.getFieldName(), profilePOCVO);
					
				}
			}
	    }
	  
		result.setResultMap(getPoListMap);
		Gson gson = new Gson();
		resultJson = gson.toJson(result);
		context.getFlowScope().put("Response", resultJson);
		}
		else{
			
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadgetCityDetails", "Map Response  should not be null");
	    	throw new IPruException("Error","GPU01", ErrorMsg);
		}
		}
		else
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadgetCityDetails", "HttpSession should not be null");
	    	throw new IPruException("Error","GPU01", ErrorMsg);
		}
		}
		
		else{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadgetCityDetails", "CompanyAddreeArray should not be null");
	    	throw new IPruException("Error","GPU01", ErrorMsg);
		}
	    }
	    else
	    {
	    	FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadgetCityDetails", "properties object should not be null");
	    	throw new IPruException("Error","GPU01", ErrorMsg);
	    }
		
	}
	catch(Exception e)
	{
		FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseCompanyAddressChangeJson", "Exception came",e);
		throwINeoFlowException(e, "GPU01", context);
	}
	FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseCompanyAddressChangeJson", "getBizResponseCompanyAddressChangeJson Method End ");
	       return success();
		
	}
	
	
	@MethodPost
	public Event getBizResponseContactPersonChangeJson(RequestContext context)throws Exception
	{
		try{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseContactPersonChangeJson", "getBizResponseContactPersonChangeJson Method Start ");
		String resultJson="";
		Properties prop=new Properties();
	    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
	    
	    if(prop!=null){
	    	ProfileUpdateUtil utility=new ProfileUpdateUtil();
	    	String[] ContactPersonChangeArray=utility.getContactPersonChangeArray();
		 if(ContactPersonChangeArray!=null && ContactPersonChangeArray.length>0){
		 TreeSet<String> actualFormField = new TreeSet<String>(Arrays.asList(ContactPersonChangeArray));
		Map<String,Object> map = new HashMap<String,Object>();
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		if(httpSession!=null){
		map=(Map<String, Object>) httpSession.getAttribute("profileAccessDetails");
		if(!map.isEmpty() && map!=null){
		Iterator it = map.entrySet().iterator();
		List<ProfileUpdateDetailsPo> poList=new ArrayList();
	    while (it.hasNext()) {
	    	ProfileUpdateDetailsPo po=new ProfileUpdateDetailsPo();
	        Map.Entry pair = (Map.Entry)it.next();
	       
	       String key=(String)(pair.getKey());
	    
	       if(key!=null)
	       {
	    	  if(actualFormField.contains(key))
	    	  {
	    			po.setFieldName(key);
	    			poList.add(po);
	    	  }
	       }
	       
	    }
	   
	    ResultJsonPO result = new ResultJsonPO();
	    Map<String,Object> getPoListMap = new HashMap<String,Object>(1);
	    if(CollectionUtils.isNotEmpty(poList)){
	    	
		
			for (ProfileUpdateDetailsPo profilePOCVO : poList) {
				if(profilePOCVO!=null){
					
					
					getPoListMap.put(profilePOCVO.getFieldName(), profilePOCVO);
					
				}
			}
	    }
	  
		result.setResultMap(getPoListMap);
		Gson gson = new Gson();
		resultJson = gson.toJson(result);
		context.getFlowScope().put("Response", resultJson);
		}
		else
		{
			 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseContactPersonChangeJson", "Map  should not be null");
			    throw new IPruException("Error","GPU01", ErrorMsg); 
		}
		}
		else
		{
			 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseContactPersonChangeJson", "HttpSession should not be null");
			    throw new IPruException("Error","GPU01", ErrorMsg); 
		}
		 }
		 else
		 {
			 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseContactPersonChangeJson", "ContactPersonChangeArray Array should not be null");
		    throw new IPruException("Error","GPU01", ErrorMsg); 
		 }
	    }
	    else
	    {
	    	FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseContactPersonChangeJson", "properties object should not be null");
	    	throw new IPruException("Error","GPU01", ErrorMsg);
	    }
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseCompanyAddressChangeJson", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseContactPersonChangeJson", "getBizResponseContactPersonChangeJson Method End ");
	       return success();
		
	}

	
	@MethodPost
	public Event getBizResponseAuthoritySignatoryChangeJson(RequestContext context)throws Exception
	{	
	FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseAuthoritySignatoryChangeJson", "getBizResponseAuthoritySignatoryChangeJson Method Start ");
		try{
			
		String resultJson="";
		Properties prop=new Properties();
	    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
	    
	    if(prop!=null){
	    	  ProfileUpdateUtil utility=new ProfileUpdateUtil();
	    	  String[] AuthoritySigChnageArray=utility.getAuthoritySigChangeArray();	  
		 if(AuthoritySigChnageArray!=null && AuthoritySigChnageArray.length>0){
		TreeSet<String> actualFormField = new TreeSet<String>(Arrays.asList(AuthoritySigChnageArray));
		Map<String,Object> map = new HashMap<String,Object>();
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		if(httpSession!=null){
		map=(Map<String, Object>) httpSession.getAttribute("profileAccessDetails");
		if(!map.isEmpty() && map!=null){
		Iterator it = map.entrySet().iterator();
		List<ProfileUpdateDetailsPo> poList=new ArrayList();
	    while (it.hasNext()) {
	    	ProfileUpdateDetailsPo po=new ProfileUpdateDetailsPo();
	        Map.Entry pair = (Map.Entry)it.next();
	       
	       String key=(String)(pair.getKey());
	    
	       if(key!=null)
	       {
	    	  if(actualFormField.contains(key))
	    	  {
	    			po.setFieldName(key);
	    			poList.add(po);
	    	  }
	       }
	       
	    }
	   
	    ResultJsonPO result = new ResultJsonPO();
	    Map<String,Object> getPoListMap = new HashMap<String,Object>(1);
	    if(CollectionUtils.isNotEmpty(poList)){
	    	
		
			for (ProfileUpdateDetailsPo profilePOCVO : poList) {
				if(profilePOCVO!=null){
					
					
					getPoListMap.put(profilePOCVO.getFieldName(), profilePOCVO);
					
				}
			}
	    }
	
		result.setResultMap(getPoListMap);
		Gson gson = new Gson();
		resultJson = gson.toJson(result);
		context.getFlowScope().put("Response", resultJson);
		}
		else
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseAuthoritySignatoryChangeJson", "Map should not be null");
		    throw new IPruException("Error","GPU01", ErrorMsg);
		}
		}
		else{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseAuthoritySignatoryChangeJson", "HttpSession should not be null");
		    throw new IPruException("Error","GPU01", ErrorMsg);
			
		}
		 }
		 else{
			 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseAuthoritySignatoryChangeJson", "AuthoritySigChnageArray Array should not be null");
		    throw new IPruException("Error","GPU01", ErrorMsg);
		 }
	    }
	    else
	    {
	    	FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseAuthoritySignatoryChangeJson", "properties object should not be null");
	    	throw new IPruException("Error","GPU01", ErrorMsg);
	    }
		
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseAuthoritySignatoryChangeJson", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseAuthoritySignatoryChangeJson", "getBizResponseAuthoritySignatoryChangeJson Method End ");
	       return success();
		
	}
	
	@MethodPost
	public Event getBizResponseBankAccountDetailsChangeJson(RequestContext context)throws Exception
	{	
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseBankAccountDetailsChangeJson", "getBizResponseBankAccountDetailsChangeJson Method Start ");
		 ProfileUpdateUtil utility=new ProfileUpdateUtil();
		try{
		String resultJson="";
		Properties prop=new Properties();
	    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
	    
	    if(prop!=null){
	   
	    String[] BankAccountDetailsArray=utility.getBankAccountDetailsChangeArray();
	
		 if(BankAccountDetailsArray!=null && BankAccountDetailsArray.length>0){
		TreeSet<String> actualFormField = new TreeSet<String>(Arrays.asList(BankAccountDetailsArray));
		Map<String,Object> map = new HashMap<String,Object>();
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		if(httpSession!=null){
		map=(Map<String, Object>) httpSession.getAttribute("profileAccessDetails");
		if(!map.isEmpty() && map!=null){
		Iterator it = map.entrySet().iterator();
		List<ProfileUpdateDetailsPo> poList=new ArrayList();
	    while (it.hasNext()) {
	    	ProfileUpdateDetailsPo po=new ProfileUpdateDetailsPo();
	        Map.Entry pair = (Map.Entry)it.next();
	       
	       String key=(String)(pair.getKey());
	      // //System.out.println(key);
	       if(key!=null)
	       {
	    	  if(actualFormField.contains(key))
	    	  {
	    			po.setFieldName(key);
	    			poList.add(po);
	    	  }
	       }
	       
	    }
	   
	    ResultJsonPO result = new ResultJsonPO();
	    Map<String,Object> getPoListMap = new HashMap<String,Object>(1);
	    if(CollectionUtils.isNotEmpty(poList)){
	    	
		
			for (ProfileUpdateDetailsPo profilePOCVO : poList) {
				if(profilePOCVO!=null){
					
					
					getPoListMap.put(profilePOCVO.getFieldName(), profilePOCVO);
					
				}
			}
	    }
	
		result.setResultMap(getPoListMap);
		Gson gson = new Gson();
		resultJson = gson.toJson(result);
		context.getFlowScope().put("Response", resultJson);
		}
		else
		{
			 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseBankAccountDetailsChangeJson", "Map should not be null");
			 throw new IPruException("Error","GPU01", ErrorMsg);
			
		}
		}
		else
		{
			 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseBankAccountDetailsChangeJson", "httpSession should not be null");
			 throw new IPruException("Error","GPU01", ErrorMsg);
		}
		 }
		 else
		 {
			 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseBankAccountDetailsChangeJson", "BankAccountDetailsArray should not be null");
			 throw new IPruException("Error","GPU01", ErrorMsg);
			 
		 }
	    }
	    else
	    {
	    	 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseBankAccountDetailsChangeJson", "properties should not be null");
			 throw new IPruException("Error","GPU01", ErrorMsg);
	    }

		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseBankAccountDetailsChangeJson", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseBankAccountDetailsChangeJson", "getBizResponseBankAccountDetailsChangeJson Method End ");
	       return success();
		
	}
	
	
	@MethodPost
	public Event getBizResponsegetAuthSignJson(RequestContext context)throws Exception{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponsegetAuthSignJson", "getBizResponsegetAuthSignJson Method Start ");
		try{
		String resultJson = null;
		Map<String,Object> map = new HashMap<String,Object>();
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		if(httpSession!=null){
		map=(Map<String, Object>) httpSession.getAttribute("profileAccessDetails");
		if(!map.isEmpty() && map!=null){
		Iterator it = map.entrySet().iterator();
		List<ProfileUpdateDetailsPo> poList=new ArrayList();
	    while (it.hasNext()) {
	    	ProfileUpdateDetailsPo po=new ProfileUpdateDetailsPo();
	        Map.Entry pair = (Map.Entry)it.next(); 
	       String key=(String)(pair.getKey());
	       if(key!=null)
	       {
	    	  
	    			po.setFieldName(key);
	    			poList.add(po);
	       }
	       
	    }
	   
	    ResultJsonPO result = new ResultJsonPO();
	    Map<String,Object> getPoListMap = new HashMap<String,Object>(1);
	    if(CollectionUtils.isNotEmpty(poList)){
	    	
		
			for (ProfileUpdateDetailsPo profilePOCVO : poList) {
				if(profilePOCVO!=null){
					
					
					getPoListMap.put(profilePOCVO.getFieldName(), profilePOCVO);
					
				}
			}
	    }
	
		result.setResultMap(getPoListMap);
		Gson gson = new Gson();
		resultJson = gson.toJson(result);
		context.getFlowScope().put("Response", resultJson);
		}
		else
		{
			 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponsegetAuthSignJson", "RollAcessMaping data should not be null");
			 throw new IPruException("Error","GPU01", ErrorMsg);
		}
		}
		else
		{
			 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponsegetAuthSignJson", "httpSession should not be null");
			 throw new IPruException("Error","GPU01", ErrorMsg);
		}
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponsegetAuthSignJson", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponsegetAuthSignJson", "getBizResponsegetAuthSignJson Method End ");
	       return success();
	}
	

	*//**********************************************************Drop Down List Data here************************************************************************//*
	@MethodPost
	public Event getBizRequestforOnloadgetSameAs(RequestContext context)throws Exception
	{
		try{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetSameAs", "getBizRequestforOnloadgetSameAs Method start ");
		BizRequest obj_bizReq = new BizRequest();
		context.getFlowScope().put("submitBizReq",obj_bizReq); 
		
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadgetSameAs", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetSameAs", "getBizRequestforOnloadgetSameAs Method End ");
		return success();
	}
	
	@MethodPost
	public Event getBizResponseforOnloadgetSameAs(RequestContext context) throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetSameAs", "getBizResponseforOnloadgetSameAs Method start ");
		String responselist = "";
		String responseCheck="";
		HttpSession httpSession = ((HttpServletRequest) context
				.getExternalContext().getNativeRequest()).getSession();
		try{
			if(context!=null){
				BizResponse bizRes = new BizResponse();
				bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadSameAs");
				if(bizRes!=null){
						responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								} else {
								
									Gson gson = new Gson();
									List data = (List) bizRes.getTransferObjects().get("response1");
									if(CollectionUtils.isNotEmpty(data))
									{
										httpSession.setAttribute("OnloadSameAs", data);
										responselist= gson.toJson(data);
										context.getFlowScope().put("Response",responselist);
									}
									else{
										
										FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetSameAs", "response should not be null");
									 throw new IPruException("Error","GPU01", ErrorMsg);
									}
									
								}
					}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetSameAs", "bizRes should not be null");
					 throw new IPruException("Error","GPU01", ErrorMsg);
						
				}
			
				}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetSameAs", "context should not be null");
						
					throw new IPruException("Error","GPU01", ErrorMsg);	
					
				}
			}
		catch(Exception e)
			{
			e.printStackTrace();
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetSameAs", "Exception came",e);
				throwINeoFlowException(e, "GPU01", context);
			}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetSameAs", "getBizResponseforOnloadgetSameAs Method End ");
		return success();
	}
	
	// get CityDetails

	@MethodPost
	public Event getBizRequestforOnloadgetCityDetails(RequestContext context)throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetCityDetails", "getBizRequestforOnloadgetCityDetails Method Start ");
		try{
		BizRequest obj_bizReq = new BizRequest();
		context.getFlowScope().put("submitBizReq",obj_bizReq); 
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadgetCityDetails", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetCityDetails", "getBizRequestforOnloadgetCityDetails Method End ");
		return success();
	}
	
	@MethodPost
	public Event getBizResponseforOnloadgetCityDetails(RequestContext context)throws Exception
	{
 		HttpSession httpSession = ((HttpServletRequest) context
				.getExternalContext().getNativeRequest()).getSession();
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetCityDetails", "getBizResponseforOnloadgetCityDetails Method Start ");
		String responselist = "";
		String responseCheck="";
		
		try{
			if(context!=null){
				BizResponse bizRes = new BizResponse();
				bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadCityDetails");
				if(bizRes!=null){
						responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								} else {
								
									Gson gson = new Gson();
									List<DropDownObjVO> response = (List<DropDownObjVO>) bizRes.getTransferObjects().get("response1");
									List cityDetails=new ArrayList();
									Map<String,String> map=new HashMap<String,String>();
									DropDownObjPO po=null;
									
									if(response!=null){
									for(int i=0;i<response.size();i++)
									{	po=new DropDownObjPO();
									DropDownObjVO vo=(DropDownObjVO)response.get(i);
										dozerBeanMapper.map(vo,po);
										cityDetails.add(po.getValue());
										map.put(po.getKey(), po.getValue());
									}
									
									
									if(CollectionUtils.isNotEmpty(cityDetails) && !map.isEmpty() && map!=null)
									{
										httpSession.setAttribute("OnloadCityDetails", cityDetails);
										responselist= gson.toJson(map);
										context.getFlowScope().put("Response",responselist);
									}
									else{
										
										FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetCityDetails", "cityDetails and map should not be null");
										 throw new IPruException("Error","GPU01", ErrorMsg);
									}
									}
									else
									{
					
											
											FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetCityDetails", "response should not be null");
											 throw new IPruException("Error","GPU01", ErrorMsg);
									}
									
								}
					}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetCityDetails", "bizRes should not be null");
						
					 throw new IPruException("Error","GPU01", ErrorMsg);
				}
			
				}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetCityDetails", "context should not be null");
					 throw new IPruException("Error","GPU01", ErrorMsg);
				}
			}
		catch(Exception e)
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetCityDetails", "Exception came",e);
				throwINeoFlowException(e, "GPU01", context);
			}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetCityDetails", "getBizResponseforOnloadgetCityDetails Method End ");
		return success();
	}
	
	//Trustee Type Details
	
	@MethodPost
	public Event getBizRequestforOnloadgetTrusteeTypeDetails(RequestContext context) throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetTrusteeTypeDetails", "getBizRequestforOnloadgetTrusteeTypeDetails Method Start ");
		try{
		BizRequest obj_bizReq = new BizRequest();
		context.getFlowScope().put("submitBizReq",obj_bizReq); 
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadgetTrusteeTypeDetails", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetTrusteeTypeDetails", "getBizRequestforOnloadgetTrusteeTypeDetails Method End ");
		return success();
	}
	
	
	
	
	@MethodPost
	public Event getBizResponseforOnloadgetTrusteeTypeDetails(RequestContext context) throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetTrusteeTypeDetails", "getBizResponseforOnloadgetTrusteeTypeDetails Method Start ");
		String responselist = "";
		String responseCheck="";
		HttpSession httpSession = ((HttpServletRequest) context
				.getExternalContext().getNativeRequest()).getSession();
		try{
			if(context!=null){
				BizResponse bizRes = new BizResponse();
				bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadTrusteeTypeDetails");
				if(bizRes!=null){
						responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								} else {
								
									Gson gson = new Gson();
									List data = (List) bizRes.getTransferObjects().get("response1");
									
									if(CollectionUtils.isNotEmpty(data))
									{
										
										httpSession.setAttribute("OnloadTrusteeTypeDetails", data);
										responselist= gson.toJson(data);
										context.getFlowScope().put("Response",responselist);
									}
									else{
										
										FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetTrusteeTypeDetails", "response should not be null");
										 throw new IPruException("Error","GPU01", ErrorMsg);
									}
									
								}
					}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetTrusteeTypeDetails", "bizRes should not be null");
						
					 throw new IPruException("Error","GPU01", ErrorMsg);
				}
			
				}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetTrusteeTypeDetails", "context should not be null");
					 throw new IPruException("Error","GPU01", ErrorMsg);
				}
			}
		catch(Exception e)
			{
			
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetTrusteeTypeDetails", "Exception came",e);
				throwINeoFlowException(e, "GPU01", context);
			}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetTrusteeTypeDetails", "getBizResponseforOnloadgetTrusteeTypeDetails Method End ");
		return success();
	}
	
	//get PhoneType Details
	@MethodPost
	public Event getBizRequestforOnloadgetPhoneTypeDetails(RequestContext context) throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetPhoneTypeDetails", "getBizRequestforOnloadgetPhoneTypeDetails Method Start ");
		try{
		BizRequest obj_bizReq = new BizRequest();
		context.getFlowScope().put("submitBizReq",obj_bizReq); 
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadgetPhoneTypeDetails", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetPhoneTypeDetails", "getBizRequestforOnloadgetPhoneTypeDetails Method");
		return success();
	}
	@MethodPost
	public Event getBizResponseforOnloadgetPhoneTypeDetails(RequestContext context) throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetPhoneTypeDetails", "getBizResponseforOnloadgetPhoneTypeDetails Method Start");
		String responselist = "";
		String responseCheck="";
		
		HttpSession httpSession = ((HttpServletRequest) context
				.getExternalContext().getNativeRequest()).getSession();
		
		try{
			if(context!=null){
				BizResponse bizRes = new BizResponse();
				bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadPhoneTypeDetails");
				if(bizRes!=null){
						responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								} else {
								
									Gson gson = new Gson();
									List data = (List) bizRes.getTransferObjects().get("response1");
									if(CollectionUtils.isNotEmpty(data))
									{
										
										httpSession.setAttribute("OnloadgetPhoneTypeDetails", data);
										responselist= gson.toJson(data);
										context.getFlowScope().put("Response",responselist);
									}
									else{
										
										FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetPhoneTypeDetails", "response should not be null");
										 throw new IPruException("Error","GPU01", ErrorMsg);
									}
									
								}
					}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetPhoneTypeDetails","bizRes should not be null ");
						FLogger.info("profileUdpate", "CompanyAddressChangeHandler", "getBizResponseforSubmitCompanyAddressChange", "bizRes should not be null ");
					throw new IPruException("Error","GPU01", ErrorMsg);
				}
			
				}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetPhoneTypeDetails"," context should not be null ");
						FLogger.info("profileUdpate", "CompanyAddressChangeHandler", "getBizResponseforSubmitCompanyAddressChange", "context should not be null ");
					throw new IPruException("Error","GPU01", ErrorMsg);
				}
			}
		catch(Exception e)
			{
			throwINeoFlowException(e, "GPU01", context);
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetPhoneTypeDetails", "Exception came",e);
			
			}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetPhoneTypeDetails", "getBizResponseforOnloadgetPhoneTypeDetails Method End");
		return success();
	}
	
//get Designation Details
	@MethodPost
	public Event getBizRequestforOnloadgetDesignationDetails(RequestContext context) throws Exception
	{FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetDesignationDetails", "getBizRequestforOnloadgetDesignationDetails Method Start");
		try{
		BizRequest obj_bizReq = new BizRequest();
		context.getFlowScope().put("submitBizReq",obj_bizReq); 
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetDesignationDetails", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetDesignationDetails", "getBizRequestforOnloadgetDesignationDetails Method End");
		return success();
	}
	
	@MethodPost
	public Event getBizResponseforOnloadgetDesignationDetails(RequestContext context) throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetDesignationDetails", "getBizResponseforOnloadgetDesignationDetails Method Start ");
		String responselist = "";
		String responseCheck="";
		HttpSession httpSession = ((HttpServletRequest) context
				.getExternalContext().getNativeRequest()).getSession();
		
		try{
			if(context!=null){
				BizResponse bizRes = new BizResponse();
				bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadDesignationDetails");
				if(bizRes!=null){
						responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								} else {
								
									Gson gson = new Gson();
									List data = (List) bizRes.getTransferObjects().get("response1");
									if(CollectionUtils.isNotEmpty(data))
									{
										//////System.out.println("*****************data data data*************************"+data.toString());
										httpSession.setAttribute("OnloadDesignationDetails", data);
										responselist= gson.toJson(data);
										context.getFlowScope().put("Response",responselist);
									}
									else{
										
										FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetDesignationDetails", "response should not be null");
										 throw new IPruException("Error","GPU01", ErrorMsg);
									}
									
								}
					}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetDesignationDetails", "bizRes should not be null ");
						FLogger.info("profileUdpate", "CompanyAddressChangeHandler", "getBizResponseforSubmitCompanyAddressChange", "bizRes should not be null ");
					throw new IPruException("Error","GPU01", ErrorMsg);
				}
			
				}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetDesignationDetails", "context should not be null ");
						FLogger.info("profileUdpate", "CompanyAddressChangeHandler", "getBizResponseforSubmitCompanyAddressChange", ");
					throw new IPruException("Error","GPU01", ErrorMsg);
				}
			}
		catch(Exception e)
			{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetDesignationDetails", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
			}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetDesignationDetails", "getBizResponseforOnloadgetDesignationDetails Method End");
		return success();
	}
	
	
	
	//get Titile Details
	@MethodPost
	public Event getBizRequestforOnloadgetTitleDetails(RequestContext context) throws Exception
	{	FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetTitleDetails", "getBizRequestforOnloadgetTitleDetails Method Start");
		try{
		BizRequest obj_bizReq = new BizRequest();
		context.getFlowScope().put("submitBizReq",obj_bizReq); 
		}
		catch(Exception e)
		{
			throwINeoFlowException(e, "GPU01", context);
		FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadgetTitleDetails", "Exception came",e);
			
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetTitleDetails", "getBizRequestforOnloadgetTitleDetails Method End");
		return success();
		
	}
	@MethodPost
	public Event getBizResponseforOnloadgetTitleDetails(RequestContext context) throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetTitleDetails", "getBizResponseforOnloadgetTitleDetails Method End");
		String responselist = "";
		String responseCheck="";
		HttpSession httpSession = ((HttpServletRequest) context
				.getExternalContext().getNativeRequest()).getSession();
		try{
			if(context!=null){
				BizResponse bizRes = new BizResponse();
				bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadTitleDetails");
				if(bizRes!=null){
						responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								} else {
								
									Gson gson = new Gson();
									List data = (List) bizRes.getTransferObjects().get("response1");
									ArrayList data=new ArrayList();
									data.add("Ms");
									data.add("Mr");
									if(CollectionUtils.isNotEmpty(data))
									{
										//////System.out.println("*****************data data data*************************"+data.toString());
										httpSession.setAttribute("OnloadTitleDetails", data);
										responselist= gson.toJson(data);
										context.getFlowScope().put("Response",responselist);
									}
									else{
										
										FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetTitleDetails", "response should not be null");
										 throw new IPruException("Error","GPU01", ErrorMsg);
									}
									
								}
					}
				else
				{
					FLogger.info("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetTitleDetails", "bizRes should not be null ");
						FLogger.info("profileUdpate", "CompanyAddressChangeHandler", "getBizResponseforSubmitCompanyAddressChange", "bizRes should not be null ");
					throw new IPruException("Error","GPU01", ErrorMsg);
				}
			
				}
				else
				{
					FLogger.info("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetTitleDetails", "context should not be null ");
						FLogger.info("profileUdpate", "CompanyAddressChangeHandler", "getBizResponseforSubmitCompanyAddressChange", );
					throw new IPruException("Error","GPU01", ErrorMsg);
				}
			}
		catch(Exception e)
			{
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetTitleDetails", "Exception came",e);
			}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadgetTitleDetails", "getBizResponseforOnloadgetTitleDetails Method End");
		return success();
	}
	//get State Details Data
	@MethodPost
		public Event getBizRequestforOnloadgetStateDetailsData(RequestContext context) throws Exception
		{
		
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetStateDetailsData", "getBizRequestforOnloadgetStateDetailsData Method Start");
		try{
			
		
			BizRequest obj_bizReq = new BizRequest();
					context.getFlowScope().put("submitBizReq",obj_bizReq); 
		}
		catch(Exception e)
		{
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadgetTitleDetails", "Exception came",e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadgetStateDetailsData", "getBizRequestforOnloadgetStateDetailsData Method End");			
		return success();
		
		}
	@MethodPost
		public Event getBizResponseforOnloadStateDetailsData(RequestContext context) throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadStateDetailsData", "getBizResponseforOnloadStateDetailsData Method Start");
	String responselist = "";
	String responseCheck="";
	HttpSession httpSession = ((HttpServletRequest) context
			.getExternalContext().getNativeRequest()).getSession();
	
	try{
		if(context!=null){
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadStateDetailsData");
			if(bizRes!=null){
					responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
							throwINeoFlowException(bizRes.getStatusVO(), context);
							} else {
							
								Gson gson = new Gson();
								List<DropDownObjVO> response = (List<DropDownObjVO>) bizRes.getTransferObjects().get("response1");
								DropDownObjPO po=null;
								List<String> data=new ArrayList<String>();
								for(int i=0;i<response.size();i++)
								{			po=new DropDownObjPO();
									DropDownObjVO vo=(DropDownObjVO)response.get(i);
									dozerBeanMapper.map(vo,po);
									data.add(po.getValue());
								}
								if(CollectionUtils.isNotEmpty(data))
								{
									httpSession.setAttribute("OnloadStateDetailsData", data);
									responselist= gson.toJson(data);
									context.getFlowScope().put("Response",responselist);
								}
								else{
									
									FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadStateDetailsData", "response should not be null");
									 throw new IPruException("Error","GPU01", ErrorMsg);
								}
								
							}
				}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadStateDetailsData", "bizRes should not be null ");
				throw new IPruException("Error","GPU01", ErrorMsg);
					
			}
		
			}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadStateDetailsData", "context should not be null ");
				throw new IPruException("Error","GPU01", ErrorMsg);				
			}
		}
	catch(Exception e)
		{
		throwINeoFlowException(e, "GPU01", context);
		FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadStateDetailsData", "Exception came",e);
		}
	FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadStateDetailsData", "getBizResponseforOnloadStateDetailsData Method End");
	return success();
}

	@MethodPost
	public Event getBizRequestforOnloadAddressTypeData(RequestContext context) throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "getBizRequestforOnloadAddressTypeData Method Start");
		try{
		BizRequest obj_bizReq = new BizRequest();
		context.getFlowScope().put("submitBizReq",obj_bizReq); 
		}
		catch(Exception e)
		{
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "Exception came",e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "getBizRequestforOnloadAddressTypeData Method End");
		return success();
	}
	@MethodPost
	public Event getBizResponseforOnloadAddressTypeData(RequestContext context) throws Exception
	{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadAddressTypeData", "getBizResponseforOnloadAddressTypeData Method Start");
		String responselist = "";
		String responseCheck="";
		HttpSession httpSession = ((HttpServletRequest) context
				.getExternalContext().getNativeRequest()).getSession();
		
		try{
			if(context!=null){
				BizResponse bizRes = new BizResponse();
				bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadAddressTypeData");
				if(bizRes!=null){
						responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								} else {
								
									Gson gson = new Gson();
									List<DropDownObjVO> response = (List<DropDownObjVO>) bizRes.getTransferObjects().get("response1");
									DropDownObjPO po=null;
									List<String> data=new ArrayList<String>();
									for(int i=0;i<response.size();i++)
									{			po=new DropDownObjPO();
										DropDownObjVO vo=(DropDownObjVO)response.get(i);
										dozerBeanMapper.map(vo,po);
										data.add(po.getValue());
									}
									
									if(CollectionUtils.isNotEmpty(data))
									{
										httpSession.setAttribute("OnloadAddressTypeData", data);
										responselist= gson.toJson(data);
										context.getFlowScope().put("Response",responselist);
									}
									else{
										
										FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadAddressTypeData", "response should not be null");
										 throw new IPruException("Error","GPU01", ErrorMsg);
									}
									
								}
					}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadAddressTypeData", "bizRes should not be null ");
					throw new IPruException("Error","GPU01", ErrorMsg);		
				}
			
				}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadAddressTypeData", "context should not be null ");
					throw new IPruException("Error","GPU01", ErrorMsg);		
				}
			}
		catch(Exception e)
			{
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforOnloadAddressTypeData", "Exception came",e);
			}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforOnloadAddressTypeData", "getBizResponseforOnloadAddressTypeData Method End");
		return success();
	}


	      
	*//********************************************************** Edit Operation Mehtod *************************************************************************//*
	@MethodPost
	public Event getBizRequestforEditOperation(RequestContext p_ObjContext) throws Exception{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforEditOperation", "getBizRequestforEditOperation Method Start");
		ProfileUpdateUtil utility=new ProfileUpdateUtil();
		try{
			
			Properties prop=new Properties();
		    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		
		if(p_ObjContext!=null){
		
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext
					.getExternalContext().getNativeRequest()).getSession();
		HttpServletRequest request = (HttpServletRequest)p_ObjContext.getExternalContext().getNativeRequest();
		
		if(request!=null && httpSession!=null){		
		Gson gson = new Gson();
	
		ProfileUpdateSubmitPO profileUpdateSubmitPO = gsonJSON.fromJson(request.getReader(), ProfileUpdateSubmitPO.class);
		if(profileUpdateSubmitPO!=null){
		Map<String,String> companyAddressChangeMap=profileUpdateSubmitPO.getProfileUpdateEditMap();
		List<UploadFilePO> UploadFilePOList=profileUpdateSubmitPO.getUploadFileList();
		if(companyAddressChangeMap!=null && !companyAddressChangeMap.isEmpty()){
			
		ArrayList dataFromSession=new ArrayList();
		Map<String,Object> map = new HashMap<String,Object>(1);
	
		map=(Map<String, Object>) httpSession.getAttribute("profileAccessDetails");
		
		if(!map.isEmpty() && map!=null)
			{
		Iterator itr2 = map.entrySet().iterator();
		while (itr2.hasNext()) {
				Map.Entry pair1 = (Map.Entry)itr2.next();
		
				dataFromSession.add(pair1.getKey().toString());
			}
		}
		else
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "map Should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
		}
		
		
		ProfileUpdateDetailsPo validatePo=new ProfileUpdateDetailsPo();
		if(CollectionUtils.isNotEmpty(dataFromSession))//get ArrayList here contain old value new value and Corresponding Functionality Id
		{
			
			if(!companyAddressChangeMap.isEmpty() && companyAddressChangeMap!=null && companyAddressChangeMap.size()==Integer.parseInt(prop.getProperty("editOperationdatalength")))
			{
				Iterator itr2 = companyAddressChangeMap.entrySet().iterator();
				
				
				while (itr2.hasNext()) {
				Map.Entry pair1 = (Map.Entry)itr2.next();
				
				String getFiledName=pair1.getKey().toString();
				
				 if(StringUtils.isNotBlank(getFiledName)){
					
					 boolean resultOfEnum=utility.checkEditProfileUpdateaEnum(getFiledName);
					 if(resultOfEnum){
					 	ProfileUpdateEditEnum poEnum=ProfileUpdateEditEnum.valueOf(getFiledName);
					 
					 	if(poEnum!=null){
					 		switch(poEnum){
					 		case fieldName:
					 			////System.out.println(pair1.getValue().toString());
					 			if(dataFromSession.contains(pair1.getValue().toString()))
					 			{
					 				validatePo.setFieldName(String.valueOf(pair1.getValue()));
					 			}
					 			else
					 			{
					 				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "Error Occured In Given Map for Edit");
					 				throw new IPruException("Error","GPU01", ErrorMsg);	
					 			}
					 			break;
					 		case newValue:
					 			validatePo.setNewValue(String.valueOf(pair1.getValue()));
					 			break;
					 		case index:
					 			String index=pair1.getValue().toString();
					 			String fieldName=validatePo.getFieldName().toString();
					 			//int listIndex=Integer.parseInt(oldValue.substring(oldValue.length() - 1));
					 			String oldValueEdit=utility.checkEditFieldDetails(Integer.parseInt(index),fieldName,httpSession,prop);
					 			if(StringUtils.isNotEmpty(oldValueEdit))
					 			{
					 				validatePo.setOldValue(String.valueOf(oldValueEdit));
					 			}
					 			else
					 			{
					 				throw new IPruException("Error","GPU01", ErrorMsg);	
					 			}
					 			//validatePo.setOldValue(pair1.getValue().toString());
					 			break;
					 			
					 		default:
					 			break;
					 		}//end of switch
					 	}//end if poEnum
					 	else{
					 		FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "ProfileUpdateEditEnum should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
					 	}
					 }
					 else
					 {
						 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "ProfileUpdateEditEnum value not contain please try again! ");
							throw new IPruException("Error","GPU01", ErrorMsg);	 
					 }
				 }//end of if
				 else
				 {
					 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "Enum String Should not be null");
					 throw new IPruException("Error","GPU01", ErrorMsg);	
				 }
				 
				}//end of while
			}//end of map
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "Error Occured In Given Map for Edit");
				throw new IPruException("Error","GPU01", ErrorMsg);	
				
			}
		}//end of data session
		else
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "dataFromSession List Should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
		}
		
	
						
						 ProfileUpdateValidator validator=new ProfileUpdateValidator();
						 String validation=null;
						
						 if(validator!=null && validatePo!=null){
							  validation= validator.ValidateEditProfileUpdateDetailsPo(validatePo,httpSession);//get Sorted Field Id and New Value Corresponding Functionality
							 
							  if (StringUtils.isNotBlank(validation)) {
								  ////System.out.println("validation : "+validation);
									this.setValidationErrorMessages(validation);
									//throw new IPruException("Error","GPU01", validation);
									throwINeoFlowException(new ServiceException("GPU01"),"GPU01", p_ObjContext); //TODO:please make solution for that
								}
						  
						
						 
						 ProfileUpdateDetailsVo profileUpdateDetailsVo = new ProfileUpdateDetailsVo();
						    	
						 if(profileUpdateDetailsVo!=null && validatePo!=null)
						 {
						    	dozerBeanMapper.map(validatePo,profileUpdateDetailsVo);//dozerBeanMapper mapping used for Po to Vo Bean
						 }
							else
							{
								FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "profileUpdateDetailsVo and  validatePo Should not be null");
								throw new IPruException("Error","GPU01", ErrorMsg);	
							}
							ProfileUpdateServiceVO profileUpdateServiceVO=new ProfileUpdateServiceVO();
						 	List<ProfileUpdateDetailsVo> requestData=new ArrayList();
							
							if(utility!=null && profileUpdateDetailsVo!=null && !map.isEmpty()){
							profileUpdateDetailsVo=utility.getProfileUpdateDataForEdit(profileUpdateDetailsVo, map, httpSession);
							requestData.add(profileUpdateDetailsVo);
							TreeSet<String> actualFormField = new TreeSet<String>(Arrays.asList(utility.getEditOperationArray()));
							
							
							if(actualFormField.contains(profileUpdateDetailsVo.getFieldName())){
								UploadFileVO uploadFileVO=null;
								List<UploadFileVO> UploadFileDetails=new ArrayList();
								if(CollectionUtils.isNotEmpty(UploadFilePOList)){
								for(int i=0;i<UploadFilePOList.size();i++)
								 {
									UploadFilePO uploadFilePO=UploadFilePOList.get(i);
									String documentName=uploadFilePO.getDocName();
									long docSize=uploadFilePO.getDocSize();
									 int dot = documentName.lastIndexOf(".");
									 String extension=documentName.substring(dot + 1);
									if((extension.equalsIgnoreCase("PDF") || extension.equalsIgnoreCase("JPEG") || extension.equalsIgnoreCase("TIFF") || extension.equalsIgnoreCase("JPG")) && (docSize<=Long.parseLong(prop.getProperty("oneMb"))))
									{
									
									 uploadFileVO=new UploadFileVO();
									 dozerBeanMapper.map((UploadFilePO)UploadFilePOList.get(i),//dozerBeanMapper mapping used for Po to Vo Bean
											 uploadFileVO);
									 UploadFileDetails.add(uploadFileVO);
									}
									else{
										throw new IPruException("Error","GPU01", "File should be JPEG or TIFF or PDF and File size less than 2MB");
									}
								 }
								}
								else
								{
									 throw new IPruException("Error","GPU01", "Please Upload AtLeast One File");	
									
								}
								
							
								profileUpdateServiceVO.setGetProfileUpdateDetailsVoList(requestData);
								profileUpdateServiceVO.setGetUploadFileVOList(UploadFileDetails);
								
							}
							else
							{
								profileUpdateServiceVO.setGetProfileUpdateDetailsVoList(requestData);
							
							}
							if(profileUpdateServiceVO!=null){
							Object[] paramArray = new Object[1];
							paramArray[0] = profileUpdateServiceVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);
							p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq); 
								
							}
							else
								{
								FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "profileUpdateDetailsVo Should not be null");
								throw new IPruException("Error","GPU01", ErrorMsg);	
								}
							}
							else
							{
								FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "Utility Should not be null");
								throw new IPruException("Error","GPU01", ErrorMsg);	
							}
							
							  }
							  else
							  {
								  FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "validator and  poValidateData Should not be null");
									throw new IPruException("Error","GPU01", ErrorMsg);	
							
							  }
		
				
		}
		else
			{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "companyAddressChangeMap Should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		}
		else
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "ProfileUpdateSubmitPO  Should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
			
		}
		}
		else
			{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "httpSession and request Should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		
		

		}
		
		else
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "Context Should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
			
		}
		
		
		
		}
		catch(Exception e)
		{
			throwINeoFlowException(e, "GPU01", p_ObjContext);
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "Exception came",e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforEditOperation", "getBizRequestforEditOperation Method End");
		return success();
	
		
	}

	
	@ MethodPost
	public Event getBizResponseEditOperation(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseEditOperation", "getBizResponseEditOperation Method Start");
		boolean response = false;
		String serviceResponse=null;
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		try{
			if(context!=null){
				bizRes = (BizResponse) context.getFlowScope().get("bizResEditOperation");
				if(bizRes!=null){
					responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								}
							else {
								response = (Boolean) bizRes.getTransferObjects().get("response1");
					
								if(response)
										serviceResponse="Record Inserted Successfully!";
									else
										serviceResponse="Error Occured While Inserting Record Please Try Again!";
									context.getFlowScope().put("Response",serviceResponse);
								}		
						}
						else{
							FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "bizRes should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
								
						}
				}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "context should not be null");
				throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		}
	catch(Exception e)
		{
		throwINeoFlowException(e, "GPU01", context);
		FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforEditOperation", "Exception came",e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseEditOperation", "getBizResponseEditOperation Method End");
		return success();
	}
	
	
	*//**********************************************************On load data list get Here**************************************************************************//*
	@MethodPost
	public Event getBizRequestforLoadContactPersonChange(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforLoadContactPersonChange", "getBizRequestforLoadContactPersonChange Method Start");
		
		try{
			BizRequest obj_bizReq = new BizRequest();
			
			 IPruUser userVo = null;
			 
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			 if (httpSession != null) {
			userVo = (IPruUser) httpSession.getAttribute("userVO");
			if(userVo!=null){
			Object paramArray[]=new Object[2];
			paramArray[0]=userVo.getPolicyNo();
			paramArray[1]=userVo.getRoles();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("submitBizReq",obj_bizReq); 
			}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "userVo should not be null");	
				 throw new IPruException("Error","GPU01", ErrorMsg);
			}
			 }
			 else
			 {
				 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "HttpSession should not be null");
				 throw new IPruException("Error","GPU01", ErrorMsg);
			 }
			}
			catch(Exception e)
			{
				throwINeoFlowException(e, "GPU01", p_ObjContext);
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforLoadContactPersonChange", "Exception came",e);
			}
			FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforLoadContactPersonChange", "getBizRequestforLoadContactPersonChange Method End");
			return success();
	
	}
	
	
	@MethodPost
	public Event getBizResponseforLoadContactPersonChange(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforLoadContactPersonChange", "getBizResponseforLoadContactPersonChange Method Start");
		HttpSession httpSession = ((HttpServletRequest) context
				.getExternalContext().getNativeRequest()).getSession();
		boolean response = false;
		String responselist="";
		Gson gson = new Gson();
		String serviceResponse=null;
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		try{
			if(context!=null){
				bizRes = (BizResponse) context.getFlowScope().get("bizResForLoadcontactPersonChange");
				if(bizRes!=null){
					responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								}
							else {
							List<ContactPersonChangeVO> data= (List<ContactPersonChangeVO>) bizRes.getTransferObjects().get("response1");
							
							ContactPersonChangePO po=null;
					
						List<ContactPersonChangePO>	ContactPersonChangePoList=new ArrayList();
						for(int i=0;i<data.size();i++)
						{
							po=new ContactPersonChangePO();
							ContactPersonChangeVO vo=(ContactPersonChangeVO)data.get(i);
							 dozerBeanMapper.map(vo,po);
							 ContactPersonChangePoList.add(po);
							
						}
						
					
						
						
						if(CollectionUtils.isNotEmpty(ContactPersonChangePoList))
						{
							httpSession.setAttribute("ContactPersonChangePoList", ContactPersonChangePoList);
							responselist= gson.toJson(ContactPersonChangePoList);
							context.getFlowScope().put("Response",responselist);
						}
						else{
							
							FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadContactPersonChange", "response should not be null");
							 throw new IPruException("Error","GPU01", ErrorMsg);
						}
							////System.out.println(po);
								}		
						}
						else{
							FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadContactPersonChange", "bizRes should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
								
						}
				}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadContactPersonChange", "context should not be null");
				throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		}
	catch(Exception e)
		{
		throwINeoFlowException(e, "GPU01", context);
		FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadCompanyAddressChange", "Exception came",e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforLoadCompanyAddressChange", "getBizResponseforLoadCompanyAddressChange Method End");
		return success();
	}
	
	
	

	

	@MethodPost
	public Event getBizRequestforLoadCompanyAddressChange(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforLoadCompanyAddressChange", "getBizRequestforLoadCompanyAddressChange Method Start");
		
	
		try{
		BizRequest obj_bizReq = new BizRequest();
		
		 IPruUser userVo = null;
		 
		HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
		 if (httpSession != null) {
		userVo = (IPruUser) httpSession.getAttribute("userVO");
		if(userVo!=null){
		Object paramArray[]=new Object[2];
		paramArray[0]=userVo.getPolicyNo();
		paramArray[1]=userVo.getRoles();
		obj_bizReq.addbusinessObjects("service-obj1", paramArray);
		p_ObjContext.getFlowScope().put("submitBizReq",obj_bizReq); 
		}
		else
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "userVo should not be null");	
			 throw new IPruException("Error","GPU01", ErrorMsg);
		}
		 }
		 else
		 {
			 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "HttpSession should not be null");
			 throw new IPruException("Error","GPU01", ErrorMsg);
		 }
		}
		catch(Exception e)
		{
			throwINeoFlowException(e, "GPU01", p_ObjContext);
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "Exception came",e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "getBizRequestforOnloadAddressTypeData Method End");
		return success();
	}
	
	@MethodPost
	public Event getBizResponseforLoadCompanyAddressChange(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforLoadCompanyAddressChange", "getBizResponseforLoadCompanyAddressChange Method Start");
		boolean response = false;
		String responselist="";
		Gson gson = new Gson();
		String serviceResponse=null;
		List<CompanyAddressChangeVO> data=new LinkedList();
		HttpSession httpSession = ((HttpServletRequest) context
				.getExternalContext().getNativeRequest()).getSession();
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		Properties prop=new Properties();
	    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
	
		try{
			if(context!=null){
				bizRes = (BizResponse) context.getFlowScope().get("bizResForLoadCompanyAddressChange");
				if(bizRes!=null){
					responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								}
							else {
								data= (List<CompanyAddressChangeVO>) bizRes.getTransferObjects().get("response1");
								
							CompanyAddressChangePO po=null;
							if(CollectionUtils.isNotEmpty(data)){
							List<CompanyAddressChangePO> CompanyAddressChangePOList=new LinkedList();
						for(int i=0;i<data.size();i++)
						{
							po=new CompanyAddressChangePO();
							CompanyAddressChangeVO vo=(CompanyAddressChangeVO)data.get(i);
							 dozerBeanMapper.map(vo,po);
							 
							 
							 
							 CompanyAddressChangePOList.add(po);
						}
						
						if(CollectionUtils.isNotEmpty(CompanyAddressChangePOList))
						{
							httpSession.setAttribute("CompanyAddressChangePOList", CompanyAddressChangePOList);
							responselist= gson.toJson(CompanyAddressChangePOList);
							context.getFlowScope().put("Response",responselist);
						}
						else{
							
							FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadCompanyAddressChange", "response should not be null");
							 throw new IPruException("Error","GPU01", ErrorMsg);
						}
							}
						else{
							FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadCompanyAddressChange", "Response should not be null from bizRes object");
							 throw new IPruException("Error","GPU01", ErrorMsg);
						}
							}
						}
						
						
						else{
							FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadCompanyAddressChange", "bizRes should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
								
						}
				}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadCompanyAddressChange", "context should not be null");
				throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		}
	catch(Exception e)
		{
		throwINeoFlowException(e, "GPU01", context);
		FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadCompanyAddressChange", "Exception came",e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforLoadCompanyAddressChange", "getBizResponseforLoadCompanyAddressChange Method End");
		return success();
	}
	
	
	
	
	@MethodPost
	public Event getBizRequestforLoadAuthorisedSignatoryChange(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforLoadAuthorisedSignatoryChange", "getBizRequestforLoadAuthorisedSignatoryChange Method Start");
		try{
			BizRequest obj_bizReq = new BizRequest();
			
			 IPruUser userVo = null;
			 
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			 if (httpSession != null) {
			userVo = (IPruUser) httpSession.getAttribute("userVO");
			if(userVo!=null){
			Object paramArray[]=new Object[2];
			paramArray[0]=userVo.getPolicyNo();
			paramArray[1]=userVo.getRoles();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("submitBizReq",obj_bizReq); 
			}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "userVo should not be null");	
				 throw new IPruException("Error","GPU01", ErrorMsg);
			}
			 }
			 else
			 {
				 FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "HttpSession should not be null");
				 throw new IPruException("Error","GPU01", ErrorMsg);
			 }
		}
			catch(Exception e)
			{
				throwINeoFlowException(e, "GPU01", p_ObjContext);
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforOnloadAddressTypeData", "Exception came",e);
			}
			FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforLoadAuthorisedSignatoryChange", "getBizRequestforLoadAuthorisedSignatoryChange Method End");
			return success();
	}
	@MethodPost
	public Event getBizResponseforLoadAuthorisedSignatoryChange(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforLoadAuthorisedSignatoryChange", "getBizResponseforLoadAuthorisedSignatoryChange Method Start");
		boolean response = false;
		String serviceResponse=null;
		String responselist="";
		Gson gson = new Gson();
		HttpSession httpSession = ((HttpServletRequest) context
				.getExternalContext().getNativeRequest()).getSession();
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		try{
			if(context!=null){
				bizRes = (BizResponse) context.getFlowScope().get("bizResForLoadCompanyAddressChange");
				if(bizRes!=null){
					responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								}
							else {
							List<AuthoritySignatoryChangeVO> data= (List<AuthoritySignatoryChangeVO>) bizRes.getTransferObjects().get("response1");
							AuthoritySignatoryChangePO po=null;
							List<AuthoritySignatoryChangePO> AuthoritySignatoryChangePOList=new ArrayList();
						for(int i=0;i<data.size();i++)
						{
							po=new AuthoritySignatoryChangePO();
							AuthoritySignatoryChangeVO vo=(AuthoritySignatoryChangeVO)data.get(i);
							 dozerBeanMapper.map(vo,po);
							 AuthoritySignatoryChangePOList.add(po);
						}
						
						if(CollectionUtils.isNotEmpty(AuthoritySignatoryChangePOList))
						{
							httpSession.setAttribute("AuthoritySignatoryChangePOList", AuthoritySignatoryChangePOList);
							responselist= gson.toJson(AuthoritySignatoryChangePOList);
							context.getFlowScope().put("Response",responselist);
						}
						else{
							
							FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadAuthorisedSignatoryChange", "response should not be null");
							 throw new IPruException("Error","GPU01", ErrorMsg);
						}
						
						////System.out.println(po);
						}		
						}
						else{
							FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadAuthorisedSignatoryChange", "bizRes should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
								
						}
				}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadAuthorisedSignatoryChange", "context should not be null");
				throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		}
	catch(Exception e)
		{
		throwINeoFlowException(e, "GPU01", context);
		FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponseforLoadAuthorisedSignatoryChange", "Exception came",e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponseforLoadAuthorisedSignatoryChange", "getBizResponseforLoadAuthorisedSignatoryChange Method End");
		return success();
	}
	
	
	
	@MethodPost
	public Event getBizRequestforLoadBankAccountDetailsChangee(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforLoadBankAccountDetailsChangee", "getBizRequestforLoadBankAccountDetailsChangee Method Start");
		Gson gson = new Gson();
		try{
		//////System.out.println("In handler: getBizRequestforSubmitCompanyAddressChange : called when form is submitted");
		if(p_ObjContext!=null){
		HttpServletRequest request = (HttpServletRequest)p_ObjContext.getExternalContext().getNativeRequest();
		////System.out.println(ToStringBuilder.reflectionToString(request)); 
		if(request!=null){
			BankAccountDetailsChangePo bankAccountDetailsChangePo = new BankAccountDetailsChangePo();
			bankAccountDetailsChangePo.setBankAccount_bankName("BankNameTesting");
			bankAccountDetailsChangePo.setBankAccount_accountNumber("AccountNumber");
			bankAccountDetailsChangePo.setBankAccount_MICRCode("MICRCode");
			bankAccountDetailsChangePo.setBankAccount_IFSCCode("IFSCCode");
			bankAccountDetailsChangePo.setBankAccount_bankAddress1("BankAddress1");
			bankAccountDetailsChangePo.setBankAccount_bankAddress2("BankAddress2");
			bankAccountDetailsChangePo.setBankAccount_bankAddress3("BankAddress3");
			bankAccountDetailsChangePo.setBankAccount_documentName("DocumentName");

		Object[] paramArray = new Object[1];
		if(bankAccountDetailsChangePo!=null)
		{
		String companyAddressChangePoJson=gson.toJson(bankAccountDetailsChangePo);
		
		p_ObjContext.getFlowScope().put("Response", companyAddressChangePoJson); 
		////System.out.println("companyAddressChangePoJsoncompanyAddressChangePoJsoncompanyAddressChangePoJsoncompanyAddressChangePoJson"+companyAddressChangePoJson);
		}
		else{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforLoadBankAccountDetailsChangee",  "companyAddressChangePo should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
			
		}
		}
		else{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforLoadBankAccountDetailsChangee",  "request should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
			
		}
		}
		else
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforLoadBankAccountDetailsChangee",  "p_ObjContext should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
			
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throwINeoFlowException(e, "GPU01", p_ObjContext);
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizRequestforLoadBankAccountDetailsChangee", "Exception came",e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizRequestforLoadBankAccountDetailsChangee", "getBizRequestforLoadBankAccountDetailsChangee Method End");
		return success();
	}
	
	
	*//**********************************************************save data into database operations**************************************************************************//*
	@MethodPost
	public Event getBizRequestforSubmitCompanyAddressChange(RequestContext p_ObjContext) throws Exception {
 		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "getBizRequestforSubmitCompanyAddressChange Method Start");
		Gson gson = new Gson();
		 Properties prop=new Properties();
		    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES; 
		    ProfileUpdateUtil utility=new ProfileUpdateUtil();
		try{
		
			if(p_ObjContext!=null){//get Context Object
				HttpServletRequest request = (HttpServletRequest)p_ObjContext.getExternalContext().getNativeRequest();
				if(request!=null){//get Request Object
					HttpSession httpSession = ((HttpServletRequest) p_ObjContext
							.getExternalContext().getNativeRequest()).getSession();//get HttpSessionObject
					
					if(httpSession!=null){
						ProfileUpdateDetailsPo po=null;
						ProfileUpdateSubmitPO profileUpdateSubmitPO = gsonJSON.fromJson(request.getReader(), ProfileUpdateSubmitPO.class);
						
						Map<String,ProfileUpdateDetailsPo> companyAddressChangeMap=profileUpdateSubmitPO.getProfileUpdateMap();
						
						List<UploadFilePO> UploadFilePOList=profileUpdateSubmitPO.getUploadFileList();
						
						
						//Map<String,ProfileUpdateDetailsPo> companyAddressChangeMap=profileUpdateSubmitPO.getProfileUpdateMap();
						List<ProfileUpdateDetailsPo> poList=new ArrayList<ProfileUpdateDetailsPo>();
						if(!companyAddressChangeMap.isEmpty() && companyAddressChangeMap!=null){
						Iterator itr3 = companyAddressChangeMap.entrySet().iterator();
						 while (itr3.hasNext()) {
						        Map.Entry pair = (Map.Entry)itr3.next(); 
						        poList.add((ProfileUpdateDetailsPo)pair.getValue()); 
						    }	
						
				  List<ProfileUpdateDetailsPo> poValidateData=new ArrayList<ProfileUpdateDetailsPo>();
				  ProfileUpdateUtil checkEnum=new ProfileUpdateUtil();
				  if(CollectionUtils.isNotEmpty(poList)){
				    for(int i=0;i<poList.size();i++)
				  	{
					  ProfileUpdateDetailsPo validatePo=(ProfileUpdateDetailsPo)poList.get(i);  
					  if(validatePo!=null){
						  String enumFieldName=validatePo.getFieldName().toString();
						
						 if(StringUtils.isNotBlank(enumFieldName)){
							 boolean  resultOfEnum=checkEnum.checkProfileUpdateEnum(enumFieldName);
							 if(resultOfEnum){
							 	ProfileUpdateEnum poEnum=ProfileUpdateEnum.valueOf(enumFieldName);//pending for check null
							 	if(poEnum!=null){
							 		switch(poEnum)
							 		{
					  case companyAddress_addressType_new:  
						  poValidateData.add(validatePo);
						
					  break;
					  case companyAddress_sameAs_new:
						  poValidateData.add(validatePo);
					  break;
					  case companyAddress_address1_new:
						  
						  Map<String,String> getCompanyAddressDetails=profileUpdateSubmitPO.getCompanyAddressDetails();
						  String address=utility.getCompanyAddressAndValidate(getCompanyAddressDetails);
						  //System.out.println(getCompanyAddressDetails.toString());
						  poValidateData.add(validatePo);
					  break;
					  case companyAddress_address2_new:
						  poValidateData.add(validatePo);
					  break;
					  case companyAddress_address3_new:
						  poValidateData.add(validatePo);
					  break;
					  case companyAddress_country_new:
						  poValidateData.add(validatePo);				
					  break;
					  case companyAddress_state_new:
						  poValidateData.add(validatePo);
					
					  break;
					  case companyAddress_city_new:
						  poValidateData.add(validatePo);
					  break;
					  case companyAddress_pincode_new:
						  poValidateData.add(validatePo);
					  break;
					  default:
					  break;
							 		}//if end of if
					  }//end of switch
							 	else
							 	{
							 		 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "Enum should not be null");
							 		throw new IPruException("Error","GPU01", ErrorMsg);	
							 	}
							 }
							 else
							 {
								 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "Enum1 should not be null");
							 		throw new IPruException("Error","GPU01", ErrorMsg);	
							 }
						 }//end of if
						 else
						 {
							
							 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "Field Name should not be null for Enum");
							 throw new IPruException("Error","GPU01", ErrorMsg);
						 }
					  }//end of if
					  else
					  {
						  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "ValidatePo Object Should not be null");
						  throw new IPruException("Error","GPU01", ErrorMsg);	
					  }
				  	}//end of for
				   }//end of if
				   else
				   {
						FLogger.info("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "PoList should not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
				   }
				  String validation=null;
				  ProfileUpdateValidator validator=new ProfileUpdateValidator();
				  if(validator!=null && poValidateData!=null && CollectionUtils.isNotEmpty(poValidateData)){
					  validation= validator.ValidateProfileUpdateDetailsPo(prop.getProperty("compAddChange"),poValidateData,httpSession);//get validated Field Id and New Value Corresponding Functionality
					 
					  if (StringUtils.isNotBlank(validation)) {
					
							this.setValidationErrorMessages(validation);
							FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitCompanyAddressChange", "Validation Error"+validation);
							throwINeoFlowException(new ServiceException("GPU01"),"GPU01",p_ObjContext); 
					  }
					
				
				    ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
					List<ProfileUpdateDetailsVo> voList=new ArrayList<ProfileUpdateDetailsVo>();
				    
					if(CollectionUtils.isNotEmpty(poValidateData)){
					for(int i=0;i<poValidateData.size();i++)
				    {
				    	profileUpdateDetailsVo=new ProfileUpdateDetailsVo();
				 
				    	dozerBeanMapper.map((ProfileUpdateDetailsPo)poValidateData.get(i),//dozerBeanMapper mapping used for Po to Vo Bean
				    			profileUpdateDetailsVo);
				  
				    	voList.add(profileUpdateDetailsVo);
				    	
				    }
					}
					else
					{
					//	////System.out.println("poValidateData should not be null");
						
						throw new IPruException("Error","GPU01", ErrorMsg);	
					}
				    ProfilePOCHandler poh=new ProfilePOCHandler();
				    Map<String,Object> map = new HashMap<String,Object>(1);
				    map= (Map<String, Object>) httpSession.getAttribute("profileAccessDetails");
					Map<String, FieldAccessMappingPO> map=(Map<String, FieldAccessMappingPO>)p_ObjContext.getFlowScope().get("companyAddressRoleAccessMatrix");
					if(utility!=null && map!=null && !map.isEmpty() && httpSession!=null && prop!=null && CollectionUtils.isNotEmpty(voList))
					{
				 List<ProfileUpdateDetailsVo> getProfileUpdateVo=utility.getProfileUpdateData(map,voList,httpSession);//get FullyPrepared Vo class to save 
				 
				 	UploadFileVO uploadFileVO=null;
				 	
					List<UploadFileVO> UploadFileDetails=new ArrayList();
					if(CollectionUtils.isNotEmpty(UploadFilePOList)){
					for(int i=0;i<UploadFilePOList.size();i++)
					 {
						
						UploadFilePO uploadFilePO=UploadFilePOList.get(i);
						String documentName=uploadFilePO.getDocName();
						long docSize=uploadFilePO.getDocSize();
						 int dot = documentName.lastIndexOf(".");
						 String extension=documentName.substring(dot + 1);
						if((extension.equalsIgnoreCase("PDF") || extension.equalsIgnoreCase("JPEG") || extension.equalsIgnoreCase("TIFF") || extension.equalsIgnoreCase("JPG")) && (docSize<=Long.parseLong(prop.getProperty("oneMb"))))
						{
						 uploadFileVO=new UploadFileVO();
						 dozerBeanMapper.map((UploadFilePO)UploadFilePOList.get(i),//dozerBeanMapper mapping used for Po to Vo Bean
								 uploadFileVO);
						 UploadFileDetails.add(uploadFileVO);
						}
						else
						{
							FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "File Should be JPEG or PDF or TIFF and size should be less than 2MB");
							throw new IPruException("Error","GPU01", "File Should be JPEG or PDF or TIFF and size should be less than 1MB");		
						}
					 }
					}
					else
					{
						 throw new IPruException("Error","GPU01", "Please Upload File And Size Should Be Less Than 1MB");	
						
					}
					
					ProfileUpdateServiceVO profileUpdateServiceVO=new ProfileUpdateServiceVO();
					profileUpdateServiceVO.setGetProfileUpdateDetailsVoList(getProfileUpdateVo);
					profileUpdateServiceVO.setGetUploadFileVOList(UploadFileDetails);
					
					
				 
				 if(profileUpdateServiceVO!=null)
				 {
						Object[] paramArray = new Object[1];
						paramArray[0] = profileUpdateServiceVO;
						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);
						p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq); 
						
				 }
				 else
				 {
						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "getProfileUpdateVo not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
				 }
					}
					else
					{
						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "utility or map or httpSession or prop should not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
					}
				 }
					  else
					  {
						  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "validator and poValidateData should not be null"); 
						 
						  throw new IPruException("Error","GPU01", ErrorMsg);	
					  }
			
					}
					else{
						
						  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "companyAddressChangeMap should not be null");
						  throw new IPruException("Error","GPU01", ErrorMsg);	
					}
				}
					 else
					  {
						  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "session should not be null");
						  throw new IPruException("Error","GPU01", ErrorMsg);	
					  }
				}
				
				else
				{
						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "request should not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
				}
				
				
			}
			else
			{
						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "context should not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
				
				
			}
		}
		catch(Exception e){
		
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitCompanyAddressChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", p_ObjContext);
		}
		FLogger.info("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "getBizRequestforSubmitCompanyAddressChange Method End");
			return success();
				
	}
	
	private void setValue(String fieldName, ProfileUpdateDetailsPo validatePo, List<ProfileUpdateDetailsPo> poValidateData ) {
		validatePo.getFieldName();
	
		  validatePo.setNewValue(validatePo.getNewValue().equals(fieldName)?null:validatePo.getNewValue());
		  
		  poValidateData.add(validatePo);
		  
	}
	@ MethodPost
	public Event getBizResponseforSubmitCompanyAddressChange(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitCompanyAddressChange", "getBizResponseforSubmitCompanyAddressChange Method Start");
		String responseCheck = "";
		
		String serviceResponse = null;
		boolean response=false;
		try{
			if(context!=null){
				BizResponse bizRes = new BizResponse();
				bizRes = (BizResponse) context.getFlowScope().get("bizResForSubmitCompanyAddressChange");
				if(bizRes!=null){
						responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								} else {
								
									response = (Boolean) bizRes.getTransferObjects().get("response1");
									if(response)
										serviceResponse="Record Inserted Successfully!";
									else
										serviceResponse="Error Occured While Inserting Record Please Try Again!";
									
									context.getFlowScope().put("Response",serviceResponse);
								}
					}
				else
				{

					FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseforSubmitCompanyAddressChange", "bizRes should not be null");	
					 throw new IPruException("Error","GPU01", ErrorMsg);	
					
				}
			
				}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseforSubmitCompanyAddressChange", "context should not be null");
					throw new IPruException("Error","GPU01", ErrorMsg);	
						
				}
			}
		catch(Exception e)
			{
			
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseforSubmitCompanyAddressChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
				
			}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitCompanyAddressChange", "getBizResponseforSubmitCompanyAddressChange Method End");
		return success();
	
	}
	
	
	@MethodPost
	public Event getBizRequestforSubmitContactPersonChange(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitContactPersonChange", "getBizRequestforSubmitContactPersonChange Method start");
		Gson gson = new Gson();
		
		 Properties prop=new Properties();
		    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		

			try{
			////System.out.println("In handler: getBizRequestforSubmitContactPersonChange : called when form is submitted");
				if(p_ObjContext!=null){//get Context Object
					HttpServletRequest request = (HttpServletRequest)p_ObjContext.getExternalContext().getNativeRequest();
					if(request!=null){//get Request Object
						HttpSession httpSession = ((HttpServletRequest) p_ObjContext
								.getExternalContext().getNativeRequest()).getSession();//get HttpSessionObject
						
						if(httpSession!=null){
							ProfileUpdateDetailsPo po=null;
							ProfileUpdateSubmitPO profileUpdateSubmitPO = gsonJSON.fromJson(request.getReader(), ProfileUpdateSubmitPO.class);
						if(profileUpdateSubmitPO!=null){
							Map<String,ProfileUpdateDetailsPo> contactPersonChangeMap=profileUpdateSubmitPO.getProfileUpdateMap();
							
						
							List<ProfileUpdateDetailsPo> poList=new ArrayList<ProfileUpdateDetailsPo>();
							if(!contactPersonChangeMap.isEmpty() && contactPersonChangeMap!=null){
							Iterator itr3 = contactPersonChangeMap.entrySet().iterator();

							 while (itr3.hasNext()) {
							    	
							        Map.Entry pair = (Map.Entry)itr3.next(); 
							        poList.add((ProfileUpdateDetailsPo)pair.getValue());
							      
							    }	
								
						
					    List<ProfileUpdateDetailsPo> poValidateData=new ArrayList<ProfileUpdateDetailsPo>();
					    ProfileUpdateUtil checkEnum=new ProfileUpdateUtil();
					  if(CollectionUtils.isNotEmpty(poList)){
					    for(int i=0;i<poList.size();i++)
					  	{
						  ProfileUpdateDetailsPo validatePo=(ProfileUpdateDetailsPo)poList.get(i);  
						  if(validatePo!=null){
							  String enumFieldName=validatePo.getFieldName().toString();
							
							
							  
							 if(StringUtils.isNotBlank(enumFieldName)){
								
								 boolean  resultOfEnum=checkEnum.checkProfileUpdateEnum(enumFieldName);
								 if(resultOfEnum){
								 	ProfileUpdateEnum poEnum=ProfileUpdateEnum.valueOf(enumFieldName);//TODO:pending for check null
								 	if(poEnum!=null){
								 		switch(poEnum)
								 		{
						  case contactPerson_title_new:
							  poValidateData.add(validatePo);
						 break;
						  case contactPerson_firstName_new:
							  poValidateData.add(validatePo);
						 break;
						  case contactPerson_middleName_new:
							  poValidateData.add(validatePo);
						 break;
						  case contactPerson_lastName_new:
							  poValidateData.add(validatePo);
					     break;
						  case contactPerson_Designation_new:
							  poValidateData.add(validatePo);
						
							
						  break;
						  case contactPerson_DesignationOther_new:
							  poValidateData.add(validatePo);
							
						
						  break;
						  case contactPerson_emailId_new:
							  poValidateData.add(validatePo);
						  break;
						  case contactPerson_phoneType_new:
							  poValidateData.add(validatePo);
						
					
						  break;
						  case contactPerson_countryCode_new:
							  poValidateData.add(validatePo);
							 
							
						  break;
						  case contactPerson_areaCode_new:
							  poValidateData.add(validatePo);
							
						
						  break;
						  case contactPerson_number_new:
							  poValidateData.add(validatePo);
						 break;
						  case contactPerson_extension_new:
							  poValidateData.add(validatePo);
						
						
						  break;
						  default:
						  break;
								}//if end of if
						  }//end of switch
								 	else
								 	{
								 		FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "enum should not be null");
								 		throw new IPruException("Error","GPU01", ErrorMsg);	
								 	
								 	}
								 }
								 else
								 {
									 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "enum1 should not be null");
								 		throw new IPruException("Error","GPU01", ErrorMsg);
								 }
							 }//end of if
							 else
							 {
								  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "Field Name should not be null for Enum");
								  throw new IPruException("Error","GPU01", ErrorMsg);	
								 
							 }
						  }//end of if
						  else
						  {
							  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "validatePo Object Should not be null");
							  throw new IPruException("Error","GPU01", ErrorMsg);	
							
						  }
					  	}//end of for
					   }//end of if
					   else
					   {
						   FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "poList should not be null");
						   throw new IPruException("Error","GPU01", ErrorMsg);	
						  
					   }
					    
					   
				
						  String validation=null;
					  ProfileUpdateValidator validator=new ProfileUpdateValidator();
					 if(validator!=null && CollectionUtils.isNotEmpty(poValidateData)){
						  validation= validator.ValidateProfileUpdateDetailsPo(prop.getProperty("contactPerChange"),poValidateData,httpSession);//get validated Field Id and New Value Corresponding Functionality
						 
						  if (StringUtils.isNotBlank(validation)) {
							  ////System.out.println("validation : "+validation);
								this.setValidationErrorMessages(validation);
								FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "Validation Error"+validation);
								throwINeoFlowException(new ServiceException("GRPPFCC",validation), p_ObjContext); //TODO:Please Check
							}
						
					
					    ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
						List<ProfileUpdateDetailsVo> voList=new ArrayList<ProfileUpdateDetailsVo>();
					    
						if(CollectionUtils.isNotEmpty(poValidateData)){
						for(int i=0;i<poValidateData.size();i++)
					    {
					    	profileUpdateDetailsVo=new ProfileUpdateDetailsVo();
					 
					    	dozerBeanMapper.map((ProfileUpdateDetailsPo)poValidateData.get(i),//dozerBeanMapper mapping used for Po to Vo Bean
					    			profileUpdateDetailsVo);
					  
					    	voList.add(profileUpdateDetailsVo);
					    	
					    }
						}
						else
						{
							
							FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "poValidateData should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
						
							
							
						}
					    ProfilePOCHandler poh=new ProfilePOCHandler();
					
					    Map<String,Object> map = new HashMap<String,Object>();
					    map= (Map<String, Object>) httpSession.getAttribute("profileAccessDetails");
						ProfileUpdateUtil utility=new ProfileUpdateUtil();
						if(utility!=null && map!=null && !map.isEmpty() && httpSession!=null && prop!=null && CollectionUtils.isNotEmpty(voList))
						{
							List<ProfileUpdateDetailsVo> getProfileUpdateVo=utility.getProfileUpdateData(map,voList,httpSession);//get FullyPrepared Vo class to save 
					 
					 if(getProfileUpdateVo!=null)
					 {
							Object[] paramArray = new Object[1];
							paramArray[0] = getProfileUpdateVo;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);
							p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq); 
							
					 }
					 else
					 {
						 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "getProfileUpdateVo not be null");
						 throw new IPruException("Error","GPU01", ErrorMsg);	
						
					 }
					 
					 
					 
					 
						}
						else
						{
							FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "utility or map or httpSession or prop should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
							
						}
						  
						  
					  }
						  else
						  {
								FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "validator and poValidateData should not be null");
								throw new IPruException("Error","GPU01", ErrorMsg);	
							
						  }
						 
						    
				
					  
					 
						}
						else{
							FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "companyAddressChangeMap should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
							
						}
					}
						 else
						  {
							 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "ContactPersonChangepo should not be null");
							 throw new IPruException("Error","GPU01", ErrorMsg);	
							
						  }
					}
						else
						{
							FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "session should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
						}
					}
					else
					{
						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "request should not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
						
					}
					
					
				}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "context should not be null");
					throw new IPruException("Error","GPU01", ErrorMsg);	
				}
			}
			catch(Exception e){
				FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitContactPersonChange", "Exception came ", e);
				throwINeoFlowException(e, "GPU01", p_ObjContext);
			}
			FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitContactPersonChange", "getBizRequestforSubmitContactPersonChange Method End");
				return success();
					
		}
	
	
	

	
	@ MethodPost
	public Event getBizResponseforSubmitContactPersonChange(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitContactPersonChange", "getBizResponseforSubmitContactPersonChange Method Start");
		boolean response = false;
		String serviceResponse=null;
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		try{
			if(context!=null){
				bizRes = (BizResponse) context.getFlowScope().get("bizResForSubmitcontactPersonChange");
				if(bizRes!=null){
					responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
								}
							else {
								response = (Boolean) bizRes.getTransferObjects().get("response1");
					
								if(response)
										serviceResponse="Record Inserted Successfully!";
									else
										serviceResponse="Error Occured While Inserting Record Please Try Again!";
									//////System.out.println("eInsure in getResponse method :   "+serviceResponse);
									context.getFlowScope().put("Response",serviceResponse);
								}		
						}
						else{
							FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseforSubmitContactPersonChange", "bizRes should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
							
						}
				}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseforSubmitContactPersonChange", "context should not be null");
				throw new IPruException("Error","GPU01", ErrorMsg);	
				
			}
		}
	catch(Exception e)
		{
		FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseforSubmitContactPersonChange", "Exception came ", e);
		throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitContactPersonChange", "getBizResponseforSubmitContactPersonChange Method End");
		return success();
	}
	
	
	
	
	@MethodPost
	public Event getBizRequestforSubmitAuthorisedSignatoryChange(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthorisedSignatoryChange", "getBizRequestforSubmitAuthorisedSignatoryChange Method Start");
		Gson gson = new Gson();
		
		 Properties prop=new Properties();
		    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		   

		try{
		////System.out.println("In handler: getBizRequestforSubmitCompanyAddressChange : called when form is submitted");
			if(p_ObjContext!=null){//get Context Object
				HttpServletRequest request = (HttpServletRequest)p_ObjContext.getExternalContext().getNativeRequest();
				if(request!=null){//get Request Object
					HttpSession httpSession = ((HttpServletRequest) p_ObjContext
							.getExternalContext().getNativeRequest()).getSession();//get HttpSessionObject
					
					if(httpSession!=null){
				
					ProfileUpdateDetailsPo po=null;
			
					
					ProfileUpdateSubmitPO profileUpdateSubmitPO = gsonJSON.fromJson(request.getReader(), ProfileUpdateSubmitPO.class);
					
					
					Map<String,ProfileUpdateDetailsPo> authorisedSignatoryChangeMap=profileUpdateSubmitPO.getProfileUpdateMap();
					
					List<UploadFilePO> UploadFilePOList=profileUpdateSubmitPO.getUploadFileList();
					List<ProfileUpdateDetailsPo> poList=new ArrayList<ProfileUpdateDetailsPo>();
					if(!authorisedSignatoryChangeMap.isEmpty() && authorisedSignatoryChangeMap!=null){
					Iterator itr3 = authorisedSignatoryChangeMap.entrySet().iterator();

					 while (itr3.hasNext()) {
					    	
					        Map.Entry pair = (Map.Entry)itr3.next(); 
					        poList.add((ProfileUpdateDetailsPo)pair.getValue());
					      
					    }	
					
			
				    List<ProfileUpdateDetailsPo> poValidateData=new ArrayList<ProfileUpdateDetailsPo>();
				    ProfileUpdateUtil checkEnum=new ProfileUpdateUtil();
				  if(CollectionUtils.isNotEmpty(poList)){
				    for(int i=0;i<poList.size();i++)
				  	{
					  ProfileUpdateDetailsPo validatePo=(ProfileUpdateDetailsPo)poList.get(i);  
					  if(validatePo!=null){
						  String enumFieldName=validatePo.getFieldName().toString();
						  
						 if(StringUtils.isNotBlank(enumFieldName)){
							 
								 boolean  resultOfEnum=checkEnum.checkProfileUpdateEnum(enumFieldName);
								 if(resultOfEnum){
							 
							 	ProfileUpdateEnum poEnum=ProfileUpdateEnum.valueOf(enumFieldName);//pending for check null
							 	if(poEnum!=null){
							 		switch(poEnum)
							 		{
					  case authorized_title_new:
					
						  poValidateData.add(validatePo);
						
					  break;
					  case authorized_firstName_new:
						
						  poValidateData.add(validatePo);
						
					  break;
					  case authorized_middleName_new:
					
						  poValidateData.add(validatePo);
						
					  break;
					  case authorized_lastName_new:
						
						  poValidateData.add(validatePo);
						  
					  break;
					  case authorized_active_new:
						
						  poValidateData.add(validatePo);
						
					  break;
					  case authorized_type_new:
						
						  poValidateData.add(validatePo);
					 break;
					  case authorized_emailId_new:
						
						  poValidateData.add(validatePo);
						
					  break;
					  case authorized_phoneType_new:
						
						  poValidateData.add(validatePo);
					
					  break;
					  case authorized_countryCode_new:
						
						  poValidateData.add(validatePo);
						
					  break;
					  case authorized_areaCode_new:
						
						  poValidateData.add(validatePo);
						
					  break;
					  case authorized_number_new:
					
						  poValidateData.add(validatePo);
					
					  break;
					  case authorized_extension_new:
						 
						  poValidateData.add(validatePo);
						
					  break;
					
					  default:
						
					  break;
							 		}//if end of if
					  }//end of switch
							 	else
							 	{
							 		FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","enum should not be null");
							 		throw new IPruException("Error","GPU01", ErrorMsg);	
							 		
							 	}
								 }
								 else
								 {
									 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","enum should not be null");
							 		throw new IPruException("Error","GPU01", ErrorMsg);	
									 
								 }
						 }//end of if
						 else
						 {
							 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","Field Name should not be null for Enum");
							 throw new IPruException("Error","GPU01", ErrorMsg);	
							
						 }
					  }//end of if
					  else
					  {
						  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","validatePo Object Should not be null");
						  throw new IPruException("Error","GPU01", ErrorMsg);	
						  
					  }
				  	}//end of for
				   }//end of if
				   else
				   {
					   FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","poList should not be null");
					   throw new IPruException("Error","GPU01", ErrorMsg);
				   }
				    
				   
				String validation=null;
				  ProfileUpdateValidator validator=new ProfileUpdateValidator();
				  if(validator!=null && CollectionUtils.isNotEmpty(poValidateData)){
					  validation= validator.ValidateProfileUpdateDetailsPo(prop.getProperty("authSigChange"),poValidateData,httpSession);//get validated Field Id and New Value Corresponding Functionality
					 
					  if (StringUtils.isNotBlank(validation)) {
						  ////System.out.println("validation : "+validation);
							this.setValidationErrorMessages(validation);
							FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange", "Validation Error"+validation);
							throwINeoFlowException(new ServiceException("GPU01"),"GPU01",p_ObjContext); 
						
						}
					
				
				    ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
					List<ProfileUpdateDetailsVo> voList=new ArrayList<ProfileUpdateDetailsVo>();
				    
					if(CollectionUtils.isNotEmpty(poValidateData)){
					for(int i=0;i<poValidateData.size();i++)
				    {
				    	profileUpdateDetailsVo=new ProfileUpdateDetailsVo();
				 
				    	dozerBeanMapper.map((ProfileUpdateDetailsPo)poValidateData.get(i),//dozerBeanMapper mapping used for Po to Vo Bean
				    			profileUpdateDetailsVo);
				  
				    	voList.add(profileUpdateDetailsVo);
				    	
				    }
					}
					else
					{
						
						 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","poValidateData should not be null");
						 throw new IPruException("Error","GPU01", ErrorMsg);	
						
					}
				    ProfilePOCHandler poh=new ProfilePOCHandler();
				
				    Map<String,Object> map = new HashMap<String,Object>(1);
				    map= (Map<String, Object>) httpSession.getAttribute("profileAccessDetails");
					ProfileUpdateUtil utility=new ProfileUpdateUtil();
					if(utility!=null && map!=null && !map.isEmpty() && httpSession!=null && prop!=null && CollectionUtils.isNotEmpty(voList))
					{
				 List<ProfileUpdateDetailsVo> getProfileUpdateVo=utility.getProfileUpdateData(map,voList,httpSession);//get FullyPrepared Vo class to save 
				
				
				 
				 UploadFileVO uploadFileVO=null;
				List<UploadFileVO> UploadFileDetails=new ArrayList();
				if(CollectionUtils.isNotEmpty(UploadFilePOList)){
				for(int i=0;i<UploadFilePOList.size();i++)
				 {
					UploadFilePO uploadFilePO=UploadFilePOList.get(i);
					String documentName=uploadFilePO.getDocName();
					long docSize=uploadFilePO.getDocSize();
					 int dot = documentName.lastIndexOf(".");
					 String extension=documentName.substring(dot + 1);
					if(extension.equalsIgnoreCase("PDF") && docSize<=Long.parseLong(prop.getProperty("twoMb")))
					{
					 uploadFileVO=new UploadFileVO();
					 dozerBeanMapper.map((UploadFilePO)UploadFilePOList.get(i),//dozerBeanMapper mapping used for Po to Vo Bean
							 uploadFileVO);
					 UploadFileDetails.add(uploadFileVO);
					}
					else
					{
						 throw new IPruException("Error","GPU01", "Upload Only PDF File And Size Should Be Less Than 2MB");
					}
				 }
				}
				else
				{
					 throw new IPruException("Error","GPU01", ErrorMsg);	
					
				}
				
				ProfileUpdateServiceVO profileUpdateServiceVO=new ProfileUpdateServiceVO();
				profileUpdateServiceVO.setGetProfileUpdateDetailsVoList(getProfileUpdateVo);
				profileUpdateServiceVO.setGetUploadFileVOList(UploadFileDetails);
				
				
				if(profileUpdateServiceVO!=null)
				 {
						Object[] paramArray = new Object[1];
						paramArray[0] = profileUpdateServiceVO;
						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);
						p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq); 
						
				 }
				 else
				 {
					 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","getProfileUpdateVo not be null");
					 throw new IPruException("Error","GPU01", ErrorMsg);	
					
				 }
				 
				 
				 
				 
					}
					else
					{
						  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","utility or map or httpSession or prop should not be null");
						  throw new IPruException("Error","GPU01", ErrorMsg);	
						 
					}
					  
					  
				  }
					  else
					  {
						  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","validator and poValidateData should not be null");
						  throw new IPruException("Error","GPU01", ErrorMsg);	
						  
					  }
					}
					else{
						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","companyAddressChangeMap should not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
						
					}
				}
					 else
					  {
						 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","session should not be null");
						 throw new IPruException("Error","GPU01", ErrorMsg);	
					
					  }
				}
				
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","request should not be null");
					throw new IPruException("Error","GPU01", ErrorMsg);	
					
				}
				
				
			}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange","context should not be null");
				throw new IPruException("Error","GPU01", ErrorMsg);	
				
			}
		}
		catch(Exception e){
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitAuthorisedSignatoryChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", p_ObjContext);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthorisedSignatoryChange", "getBizRequestforSubmitAuthorisedSignatoryChange Method End");
			return success();
				
	}
	
	
	
	@ MethodPost
	public Event getBizResponseforSubmitAuthorisedSignatoryChange(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitAuthorisedSignatoryChange", "getBizResponseforSubmitAuthorisedSignatoryChange Method Start");
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		try{
			if(context!=null){
				bizRes = (BizResponse) context.getFlowScope().get("bizResForSubmitAuthorisedSignatoryChange");
				if(bizRes!=null){
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					} else {
						String serviceResponse = null;
						boolean response=false;
						response = (Boolean) bizRes.getTransferObjects().get("response1");
						if(response)
							serviceResponse="Record Inserted Successfully!";
						else
							serviceResponse="Error Occured While Inserting Record Please Try Again!";
						//////System.out.println("eInsure in getResponse method :   "+serviceResponse);
						context.getFlowScope().put("Response",serviceResponse);
					}
					
				}else{
					
					FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseforSubmitAuthorisedSignatoryChange", "bizRes should not be null");
					throw new IPruException("Error","GPU01", ErrorMsg);	
				}
				
			}else{
			
				FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseforSubmitAuthorisedSignatoryChange", "context should not be null");
				throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		}catch(Exception e){
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseforSubmitAuthorisedSignatoryChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitAuthorisedSignatoryChange", "getBizResponseforSubmitAuthorisedSignatoryChange Method End");
		return success();
	}
	

	
	
	
	@MethodPost
	public Event getBizRequestforSubmitBankAccountDetailsChange(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitBankAccountDetailsChange", "getBizRequestforSubmitBankAccountDetailsChange Method Start");
		
		Gson gson = new Gson();
		
		 Properties prop=new Properties();
		    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		   

		try{
			if(p_ObjContext!=null){//get Context Object
				HttpServletRequest request = (HttpServletRequest)p_ObjContext.getExternalContext().getNativeRequest();
				if(request!=null){//get Request Object
					HttpSession httpSession = ((HttpServletRequest) p_ObjContext
							.getExternalContext().getNativeRequest()).getSession();//get HttpSessionObject
					
					if(httpSession!=null){
					
					ProfileUpdateSubmitPO profileUpdateSubmitPO = gsonJSON.fromJson(request.getReader(), ProfileUpdateSubmitPO.class);
					
					
					Map<String,ProfileUpdateDetailsPo> bankDetailsChangeMap=profileUpdateSubmitPO.getProfileUpdateMap();
					
					List<UploadFilePO> UploadFilePOList=profileUpdateSubmitPO.getUploadFileList();
					List<ProfileUpdateDetailsPo> poList=new ArrayList<ProfileUpdateDetailsPo>();
					if(!bankDetailsChangeMap.isEmpty() && bankDetailsChangeMap!=null){
					Iterator itr3 = bankDetailsChangeMap.entrySet().iterator();

					 while (itr3.hasNext()) {
					    	
					        Map.Entry pair = (Map.Entry)itr3.next(); 
					        poList.add((ProfileUpdateDetailsPo)pair.getValue());
					      
					    }	
					
				    List<ProfileUpdateDetailsPo> poValidateData=new ArrayList<ProfileUpdateDetailsPo>();
				    ProfileUpdateUtil checkEnum=new ProfileUpdateUtil();
				    if(CollectionUtils.isNotEmpty(poList)){
				    for(int i=0;i<poList.size();i++)
				  	{
					  ProfileUpdateDetailsPo validatePo=(ProfileUpdateDetailsPo)poList.get(i);  
					  if(validatePo!=null){
						  String enumFieldName=validatePo.getFieldName().toString();
						  
						 if(StringUtils.isNotBlank(enumFieldName)){
							  
								 boolean  resultOfEnum=checkEnum.checkProfileUpdateEnum(enumFieldName);
								 if(resultOfEnum){
							 	ProfileUpdateEnum poEnum=ProfileUpdateEnum.valueOf(enumFieldName);//pending for check null
							 	if(poEnum!=null){
							 		switch(poEnum)
							 		{
					  case bankAccount_bankName_new:
						  poValidateData.add(validatePo);
					
					  break;
					  case bankAccount_accountNumber_new:
						  poValidateData.add(validatePo);
						
					  break;
					  case bankAccount_MICRCode_new:
						  poValidateData.add(validatePo);
						
					  break;
					  case bankAccount_IFSCCode_new:
						  poValidateData.add(validatePo);
						
					  break;
					  case bankAccount_address1_new:
						  poValidateData.add(validatePo);
						 
					  break;
					  case bankAccount_address2_new:
						  poValidateData.add(validatePo);
						  
					  break;
					  case bankAccount_address3_new:
						  poValidateData.add(validatePo);
						
					  break;
				
					  default:
						
					  break;
							 		}//if end of if
					  }//end of switch
							 	else
							 	{
							 		 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "enum should not be null");
							 		throw new IPruException("Error","GPU01", ErrorMsg);	
							 	}
								 }
								 else
								 {
									 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "enum should not be null");
								 		throw new IPruException("Error","GPU01", ErrorMsg);	
								 }
						 }//end of if
						 else
						 {
							 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "Field Name should not be null for Enum");
							 throw new IPruException("Error","GPU01", ErrorMsg);	
						 }
					  }//end of if
					  else
					  {
						  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "validatePo Object Should not be null");
						  throw new IPruException("Error","GPU01", ErrorMsg);	
					  }
				  	}//end of for
				   }//end of if
				   else
				   {
					   FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "poList should not be null");
					   throw new IPruException("Error","GPU01", ErrorMsg);	
				   }
				    
				  	String validation=null;
					  ProfileUpdateValidator validator=new ProfileUpdateValidator();
					  if(validator!=null && CollectionUtils.isNotEmpty(poValidateData)){
					  validation= validator.ValidateProfileUpdateDetailsPo(prop.getProperty("bankAddChnage"),poValidateData,httpSession);//get validated Field Id and New Value Corresponding Functionality
					 
					  if (StringUtils.isNotBlank(validation)) {
						  ////System.out.println("validation : "+validation);
							this.setValidationErrorMessages(validation);
							FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "Validation Error"+validation);
							throwINeoFlowException(new ServiceException("GRPPFCC",validation), p_ObjContext);
						}
					
				
				    ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
					List<ProfileUpdateDetailsVo> voList=new ArrayList<ProfileUpdateDetailsVo>();
				    
					if(CollectionUtils.isNotEmpty(poValidateData)){
					for(int i=0;i<poValidateData.size();i++)
				    {
				    	profileUpdateDetailsVo=new ProfileUpdateDetailsVo();
				 
				    	dozerBeanMapper.map((ProfileUpdateDetailsPo)poValidateData.get(i),//dozerBeanMapper mapping used for Po to Vo Bean
				    			profileUpdateDetailsVo);
				  
				    	voList.add(profileUpdateDetailsVo);
				    	
				    }
					}
					else
					{
					
						
						 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "poValidateData should not be null");
						
					}
				    ProfilePOCHandler poh=new ProfilePOCHandler();
				    
				    Map<String,Object> map = new HashMap<String,Object>(1);
				    map= (Map<String, Object>) httpSession.getAttribute("profileAccessDetails");
					ProfileUpdateUtil utility=new ProfileUpdateUtil();
					if(utility!=null && map!=null && !map.isEmpty() && httpSession!=null && prop!=null && CollectionUtils.isNotEmpty(voList))
					{
				 List<ProfileUpdateDetailsVo> getProfileUpdateVo=utility.getProfileUpdateData(map,voList,httpSession);//get FullyPrepared Vo class to save 
				 
				
				 
				 	UploadFileVO uploadFileVO=null;
					List<UploadFileVO> UploadFileDetails=new ArrayList();
					if(CollectionUtils.isNotEmpty(UploadFilePOList)){
					
					for(int i=0;i<UploadFilePOList.size();i++)
					 {
						
						 uploadFileVO=new UploadFileVO();
						 dozerBeanMapper.map((UploadFilePO)UploadFilePOList.get(i),//dozerBeanMapper mapping used for Po to Vo Bean
								 uploadFileVO);
						 UploadFileDetails.add(uploadFileVO);
					 }
					}
					else
					{
						 throw new IPruException("Error","GPU01", ErrorMsg);	
						
					}
					
					ProfileUpdateServiceVO profileUpdateServiceVO=new ProfileUpdateServiceVO();
					profileUpdateServiceVO.setGetProfileUpdateDetailsVoList(getProfileUpdateVo);
					profileUpdateServiceVO.setGetUploadFileVOList(UploadFileDetails);
					
					
					if(profileUpdateServiceVO!=null)
					 {
							Object[] paramArray = new Object[1];
							paramArray[0] = profileUpdateServiceVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);
							p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq); 
							
					 }
				 else
				 {
					 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "getProfileUpdateVo not be null");
					 throw new IPruException("Error","GPU01", ErrorMsg);	
				 }
				 
				 
				 
				 
					}
					else
					{
						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "utility or map or httpSession or prop should not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
					}
					  
					  
				  }
					  else
					  {
						  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "companyAddressChangeMap should not be null");
						  throw new IPruException("Error","GPU01", ErrorMsg);	
					  }
					 
				
					}
					else{
						 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "companyAddressChangeMap should not be null");
						 throw new IPruException("Error","GPU01", ErrorMsg);	
					}
				}
					 else
					  {
						 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "session should not be null");
						 throw new IPruException("Error","GPU01", ErrorMsg);	
					  }
				}
				
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "request should not be null");
					throw new IPruException("Error","GPU01", ErrorMsg);	
				}
				
				
			}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "context should not be null");
				throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		}
		catch(Exception e){
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestforSubmitBankAccountDetailsChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", p_ObjContext);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitBankAccountDetailsChange", "getBizRequestforSubmitBankAccountDetailsChange Method End");
			return success();
				
	}
	

	@ MethodPost
	public Event getBizResponseforSubmitBankAccountDetailsChange(RequestContext context) throws Exception {
	//	////System.out.println("In handler: getBizResponseforSubmitBankAccountDetailsChange : Response method");
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitBankAccountDetailsChange", "getBizResponseforSubmitBankAccountDetailsChange Method Start");
		String responseCheck = "";
		String serviceResponse = null;
		boolean response=false;
		try{
			if(context!=null){
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForSubmitBankAccountDetailsChange");
				if(bizRes!=null){
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					} else {
			
						response = (Boolean) bizRes.getTransferObjects().get("response1");
						if(response)
							serviceResponse="Record Inserted Successfully!";
						else
							serviceResponse="Error Occured While Inserting Record Please Try Again!";
						//////System.out.println("eInsure in getResponse method :   "+serviceResponse);
						context.getFlowScope().put("Response",serviceResponse);
					}
				}
				else{
					FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizResponseforSubmitBankAccountDetailsChange", "bizRes should not be null");
					throw new IPruException("Error","GPU01", ErrorMsg);	
				}
			}
		
		else
			{
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizResponseforSubmitBankAccountDetailsChange", "context should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseforSubmitBankAccountDetailsChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitBankAccountDetailsChange", "getBizResponseforSubmitBankAccountDetailsChange Method End");
		return success();
	
	}
	
	
	
	
	
	
	@MethodPost
	public Event getBizRequestUsingIFSCCodeBankDetails(RequestContext context)throws Exception
	{	
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestUsingIFSCCodeBankDetails", "getBizRequestUsingIFSCCodeBankDetails Method Start");
		 Properties prop=new Properties();
		    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		   
		try{
			if(context!=null){//get Context Object
				HttpServletRequest request = (HttpServletRequest)context.getExternalContext().getNativeRequest();
				if(request!=null){//get Request Object
					HttpSession httpSession = ((HttpServletRequest) context
							.getExternalContext().getNativeRequest()).getSession();//get HttpSessionObject
					
					if(httpSession!=null){
					
					ProfileUpdateSubmitPO profileUpdateSubmitPO = gsonJSON.fromJson(request.getReader(), ProfileUpdateSubmitPO.class);
					if(profileUpdateSubmitPO!=null){
					
					Map<String,ProfileUpdateDetailsPo> bankDetailsChangeMap=profileUpdateSubmitPO.getProfileUpdateMap();
					
					
					//List<ProfileUpdateDetailsPo> poList=new ArrayList();
					if(!bankDetailsChangeMap.isEmpty() && bankDetailsChangeMap!=null){
					Iterator itr3 = bankDetailsChangeMap.entrySet().iterator();
					ProfileUpdateDetailsPo po=null;
					 while (itr3.hasNext()) {
					    	
					        Map.Entry pair = (Map.Entry)itr3.next(); 
					      if(pair.getKey().equals(prop.getProperty("bankAccountIFSCCode_new")))
					      {
					    	  po=(ProfileUpdateDetailsPo)pair.getValue();  
					      }
					     
					       
					    }	//end of while
					 
					 ProfileUpdateDetailsVo vo=new ProfileUpdateDetailsVo();
					
				      if(po!=null)
				      {
				    	  
				    	  String b=po.getNewValue();
				    	  
				    	  if(CommonValidationUtil.ValidateRequired(b) 
				    			  && CommonValidationUtil.isMatchedPattern(b, GroupFormValidationConstant.IFSC_CODE_VALIDATION_FORGROUP) 
				    			  && CommonValidationUtil.ValidateMaxLength(b, 11)){
				    			
				    		  vo = dozerBeanMapper.map(po, ProfileUpdateDetailsVo.class);
					    	 // //System.out.println(vo);
				    		  
				    		

				    		}
				    		else {
				    			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestUsingIFSCCodeBankDetails", "Entered IFSC Code Not Valid Please Try Again!");
								throw new IPruException("Error","GPU01", "Entered IFSC Code Not Valid Please Try Again!");	
				    		}
				    	  
				    	  
				    	  
				    	 
				      }
				      else
				      {
				    	  FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestUsingIFSCCodeBankDetails", "poList data Should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
				      }
				    if(vo!=null){
				      
				    	Object[] paramArray = new Object[1];
						paramArray[0] = vo.getNewValue();
						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);
						context.getFlowScope().put("submitBizReq", obj_bizReq);
				    }
				    else
				    {
				    	 FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestUsingIFSCCodeBankDetails", "Vo data Should not be null");
							throw new IPruException("Error","GPU01", ErrorMsg);	
				    }
					 
					}
					else
					{
						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestUsingIFSCCodeBankDetails", "bankDetailsChangeMap Should not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
					}
					}
				
					else
					{
						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestUsingIFSCCodeBankDetails", "profileUpdateSubmitPO Should not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
					}
					
					//end profileUpdateSubmitPO
					}
					else
					{
						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestUsingIFSCCodeBankDetails", "HttpSession Should not be null");
						throw new IPruException("Error","GPU01", ErrorMsg);	
					}
				}
				else
				{
					FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestUsingIFSCCodeBankDetails", "Request Should not be null");
					throw new IPruException("Error","GPU01", ErrorMsg);	
				}
			}
			else
			{
				FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestUsingIFSCCodeBankDetails", "Context Should not be null");
				throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		}//end try
	
			catch(Exception e)
			{
				FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizRequestUsingIFSCCodeBankDetails", "Exception came ", e);
				throwINeoFlowException(e, "GPU01", context);
			
			}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestUsingIFSCCodeBankDetails", "getBizRequestUsingIFSCCodeBankDetails Method Start");
		return success();
		
	}
	
	
	
	@ MethodPost
	public Event getBizResponseUsingIFSCCodeBankDetails(RequestContext context) throws Exception {
	//	////System.out.println("In handler: getBizResponseforSubmitBankAccountDetailsChange : Response method");
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseUsingIFSCCodeBankDetails", "getBizResponseUsingIFSCCodeBankDetails Method Start");
		String responseCheck = "";
		String serviceResponse = null;
		boolean response=false;
		try{
			if(context!=null){
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResUsingIFSCCodeBankDetails");
				if(bizRes!=null){
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					} else {
			
						responseCheck =(String)bizRes.getTransferObjects().get("response1");
						//System.out.println(responseCheck);
						if(response)
							serviceResponse="Record Inserted Successfully!";
						else
							serviceResponse="Error Occured While Inserting Record Please Try Again!";
						//////System.out.println("eInsure in getResponse method :   "+serviceResponse);
						context.getFlowScope().put("Response",serviceResponse);
					}
				}
				else{
					FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizResponseUsingIFSCCodeBankDetails", "bizRes should not be null");
					throw new IPruException("Error","GPU01", ErrorMsg);	
				}
			}
		
		else
			{
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizResponseUsingIFSCCodeBankDetails", "context should not be null");
			throw new IPruException("Error","GPU01", ErrorMsg);	
			}
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler","getBizResponseUsingIFSCCodeBankDetails", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseUsingIFSCCodeBankDetails", "getBizResponseUsingIFSCCodeBankDetails Method End");
		return success();
	
	}
	
	
	@MethodPost
	public Event getBizResponseforsaveEditDetailsJson(RequestContext context)throws Exception{
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponsegetAuthSignJson", "getBizResponsegetAuthSignJson Method Start ");
		try{
			String resultJson="";
			Map map=new HashMap();
			map.put("fieldName", "");
			map.put("newValue", "");
			map.put("index", "");
		//result.setResultMap(getPoListMap);
			Gson gson = new Gson();
			resultJson = gson.toJson(map);
			context.getFlowScope().put("Response",resultJson);
		
		}
		catch(Exception e)
		{
			FLogger.error("PROFILEUPDATEError", "ProfilePOCHandler", "getBizResponsegetAuthSignJson", "Exception came",e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfilePOCHandler", "getBizResponsegetAuthSignJson", "getBizResponsegetAuthSignJson Method End ");
	       return success();
	}
	
	
	
	
	
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		// TODO Auto-generated method stub
		
	}
	
	
*/}
	


