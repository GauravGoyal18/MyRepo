package com.ipru.groups.handler;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.ThirdPartyAutoLogin.PreLoginThirdPartyInfoPO;
import com.ipru.groups.security.encryption.Crypto;
import com.ipru.groups.utilities.EncodingUtility;
import com.ipru.groups.utilities.EncryptionPBEMD5DES;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodGet;

public class SSOGroupsHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

	private static final String CLASS_NAME = SSOGroupsHandler.class.getName();
	private static final String CUST_SERVICE_LOG = "SSOGroupsHandler";

	@MethodGet
	public Event getSingleSignOnData(RequestContext context) throws Throwable {

		String methodName = "getSingleSignOnData";
		FLogger.info(CUST_SERVICE_LOG, CLASS_NAME, methodName, "Method Start");
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		IPruUser obj = (IPruUser) httpSession.getAttribute("userVO");

		Crypto ad = new Crypto();
		Gson gson = new Gson();
		//String userId = obj.getUsername();
		//String policyNo=obj.getPolicyNo();
		//String clientId = obj.getClientId();
		String userId = "ibmtrust";
		String policyNo="00002285";
		String clientId = "00002285";
		Date date = new Date();
		long milliseconds = date.getTime();

		// String role="G15";
		// add timestamp

		// String custId=userprofile.getClientId();
		clientId = ad.encrypt(clientId, "WEBSITE123", 1);

		// String reqFunc="dashboard";
		String source = "WEBSITE";

		////System.out.println("<<<RNR>>>Link is :- clientId1222=" + userId);

		PreLoginThirdPartyInfoPO thirdpartydetailjson = new PreLoginThirdPartyInfoPO();
		thirdpartydetailjson.setUserId(userId);
		// thirdpartydetailjson.setReqFunc(reqFunc);
		// thirdpartydetailjson.setPassword(password);
		// thirdpartydetailjson.setPolicyNo(policyNo);
		thirdpartydetailjson.setClientId(clientId);
		// thirdpartydetailjson.setRole(role);
		thirdpartydetailjson.setWebsiteSource(source);
		thirdpartydetailjson.setMilliseconds(milliseconds);
		String link2 = gson.toJson(thirdpartydetailjson);
		EncryptionPBEMD5DES edd = new EncryptionPBEMD5DES();
		GroupSecurityUtil groupSecurityUtil = new GroupSecurityUtil();
		////System.out.println("<<<RNR>>>Link is :- clientId12333ssssss33=" + link2);
		link2 = edd.encrypt(link2, "WEBSITE123", 1);
		link2 = EncodingUtility.encodeBase64(link2);
		////System.out.println("<<<RNR>>>Link is :- clientId12assddd33333=" + link2);
		context.getFlowScope().put("isValid", true);

		context.getFlowScope().put("searchResultJson", link2);
		FLogger.info(CUST_SERVICE_LOG, CLASS_NAME, methodName, "Method Start");
		return success();
	}

}
