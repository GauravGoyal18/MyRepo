package com.ipru.groups.servlet;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.POST;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.groups.po.DownloadExcelUtil;
import com.ipru.groups.vo.TrackerVO;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;

/**
 * Servlet implementation class ExcelDownload
 */

public class MemberDownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
		
		
	}
 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		FLogger.info("MemberDataLogger", "ExcelDownload", "doPost", "method to download xlsx starts");
		   
		String filePath=null;
		IPruUser userVo = new IPruUser();
		String policyNo = null;
		String role = null;
		String memberType = null;
		String productType = null;
		System.out.println("Inside servlet");
		
		HttpSession session = (request).getSession();
		List result=null;
		 FileInputStream in = null;
	  	ServletOutputStream out = null; 
		
	    if(session!=null){
	    	userVo = (IPruUser) session.getAttribute("userVO");
	    	
	    	if(userVo!=null){
	    		memberType = userVo.getRoleType();
	    		productType = userVo.getProductType();
	    	}
	    	/*if(StringUtils.isEmpty(memberType)){
	    		throw new Exception();
	    	}*/
	    	if(memberType.equals("TRUST")){
			result=(List) session.getAttribute("memberDataTrustPOList");
	    	}
	    	if (memberType.equals("TERM") || memberType.equals("GTRUST")){
	    		result=(List) session.getAttribute("memberDataTermPOList");
	    	}
			if(result!=null){
				DownloadExcelUtil downloadExcelUtil=new DownloadExcelUtil();
				try {
					
					
					filePath =downloadExcelUtil.createExcel(result,memberType,productType);
				}catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
									      
				
			}else{
				FLogger.error("MemberDataLogger", "ExcelDownload", "doPost", "result cannot be null");
				 throw new ServletException("result cannot be null");
			}	
			
		}else{
			FLogger.error("MemberDataLogger", "ExcelDownload", "doPost", "session cannot be null");
			 throw new ServletException("session cannot be null");
		}
	    
		
		
	    File file=null;
		InputStream fis=null;
		String fileName=null;
		try {
			file = new File(filePath);
			fis = new FileInputStream(file);
			 fileName = file.getName();
		}
		catch (FileNotFoundException e) {
			FLogger.error("MemberDataLogger", "ExcelDownload", "doPost", e.getMessage(), e);
		}
		catch (IOException e) {
			FLogger.error("MemberDataLogger","ExcelDownload", "doPost", e.getMessage(), e);
		}
		
		
		if (fileName == null || fileName.equals("")) {
			FLogger.error("MemberDataLogger", "ExcelDownload", "doPost", "File Name can't be null or empty.");
			throw new ServletException("File Name can't be null or empty");
		}
		if (!file.exists()) {
			FLogger.error("MemberDataLogger", "ExcelDownload", "doPost", "File doesn't exists on server.");
			throw new ServletException("File doesn't exists on server.");
		}
		
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		ServletOutputStream objServletOutputStream = null;
		byte[] bufferData = new byte[65536];
		int read = 0;
		while ((read = fis.read(bufferData)) != -1) {
			output.write(bufferData, 0, read);
		}

		 try {
				if(fis!=null)
					fis.close();
			}
			catch (Exception e) {
				FLogger.error("MemberDataLogger", "ExcelDownload","doPost",e.getMessage());
				e.printStackTrace();
			} finally {
				fis=null;
			}
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
		response.setContentType("application/vnd.ms-excel");
		output.flush();
		response.setContentLength(output.size());
		objServletOutputStream = response.getOutputStream();
		output.writeTo(objServletOutputStream);
		objServletOutputStream.flush();
		////System.out.println("File downloaded at client successfully");
		FLogger.info("MemberDataLogger", "ExcelDownload", "doPost", "method to download xlsx end");
		
		
	}
	
}
