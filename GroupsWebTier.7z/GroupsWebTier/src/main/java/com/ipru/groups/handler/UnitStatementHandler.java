package com.ipru.groups.handler;

import java.io.BufferedReader;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.generic.po.ResultJsonPO;
import com.ipru.groups.po.ReportWrapperPO;
import com.ipru.groups.po.TransactionDetailsPO;
import com.ipru.groups.po.UnitStatementLoadRequestPO;
import com.ipru.groups.po.UnitStatementLoadResponsePO;
import com.ipru.groups.po.UnitStatementPDFGeneratorVO;
import com.ipru.groups.po.UnitStatementPO;
import com.ipru.groups.po.UnitStatementRequestPO;
import com.ipru.groups.profile.bean.ProfilePOCPO;
import com.ipru.groups.utilities.DateUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.utilities.UnitStatementConstants;
import com.ipru.groups.utilities.UnitStatementPojoUtil;
import com.ipru.groups.vo.CustomerDetailsVO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FtlToPdfVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.ReportWrapperVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.groups.vo.TransactionDetailsVO;
import com.ipru.groups.vo.UnitStatementDataVO;
import com.ipru.groups.vo.UnitStatementLoadRequestVO;
import com.ipru.groups.vo.UnitStatementLoadResponseVO;
import com.ipru.groups.vo.UnitStatementResponseVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class UnitStatementHandler extends IneoBaseHandler {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String ErrorMsg = "Something went wrong please try again!";

	@MethodPost
	public Event getBizRequestforSubmitUnitStatementRollAccessMapping(
			RequestContext context) throws Exception {
		FLogger.info("UnitStatementLogger", "UnitStatementHandler",
				"getBizRequestforSubmitUnitStatementRollAccessMapping",
				"getBizRequestforSubmitUnitStatementRollAccessMapping Method Start ");

		try {

			HttpSession httpSession = ((HttpServletRequest) context
					.getExternalContext().getNativeRequest()).getSession();
			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;

			fieldAccessMappingVoList = getFieldAccessMappingList(context);
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String screenName = null;
			List<RoleScreenAccessMappingVO> accessMappingList;

			userVo = (IPruUser) httpSession.getAttribute("userVO");
			if (userVo == null
					&& CollectionUtils.isEmpty(fieldAccessMappingVoList)) {

				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforSubmitUnitStatementRollAccessMapping",
						"fieldAccessMappingVoList and uservo should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}

			screenName = (String) context.getFlowScope().get("screenName");

			policyNo = userVo.getPolicyNo();

			FLogger.error("UnitStatementLogger", "UnitStatementHandler",
					"getBizRequestforSubmitUnitStatementRollAccessMapping",
					"When page load Policy No in session : " + policyNo);
			role = userVo.getRoles();

			FLogger.error("UnitStatementLogger", "UnitStatementHandler",
					"getBizRequestforSubmitUnitStatementRollAccessMapping",
					"When page load role in session : " + role);
			if (StringUtils.isEmpty(policyNo) && StringUtils.isEmpty(role)) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforSubmitUnitStatementRollAccessMapping",
						"PolicyNumber and role should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);

			}

			accessMappingList = userVo.getLstRoleScreenAccessMapping();

			if (CollectionUtils.isEmpty(accessMappingList)) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforSubmitUnitStatementRollAccessMapping",
						"accessMappingList should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}

			UnitStatementLoadRequestPO unitStatementLoadRequestPO = new UnitStatementLoadRequestPO();
			unitStatementLoadRequestPO.setPolicyNo(policyNo);
			unitStatementLoadRequestPO.setRole(role);
			unitStatementLoadRequestPO.setScreenName(screenName);

			UnitStatementLoadRequestVO unitStatementLoadRequestVO = null;

			if (unitStatementLoadRequestPO == null) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforSubmitUnitStatementRollAccessMapping",
						"unitStatementLoadRequestPO  is null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}

			unitStatementLoadRequestVO = dozerBeanMapper.map(
					unitStatementLoadRequestPO,
					UnitStatementLoadRequestVO.class);

			if (unitStatementLoadRequestVO == null) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforSubmitUnitStatementRollAccessMapping",
						"unitStatementLoadRequestVO  is null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}

			unitStatementLoadRequestVO.setAccessMappingList(accessMappingList);
			unitStatementLoadRequestVO
					.setFieldAccessMappingList(fieldAccessMappingVoList);
			Object[] paramArray = new Object[1];
			paramArray[0] = unitStatementLoadRequestVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			context.getFlowScope().put("submitBizReq", obj_bizReq);

		} catch (Exception e) {
			FLogger.error("UnitStatementLogger", "UnitStatementHandler",
					"getBizRequestforSubmitUnitStatementRollAccessMapping",
					"Exception Occured ", e);
			throwINeoFlowException(e, "US01", context);
		}

		FLogger.info("UnitStatementLogger", "UnitStatementHandler",
				"getBizRequestforSubmitUnitStatementRollAccessMapping",
				"getBizRequestforSubmitUnitStatementRollAccessMapping Method End ");

		return success();
	}

	@MethodPost
	public Event getBizResponseforSubmitUnitStatementRollAccessMapping(
			RequestContext context) throws Exception {

		FLogger.info("UnitStatementLogger", "UnitStatementHandler",
				"getBizResponseforSubmitUnitStatementRollAccessMapping",
				"getBizResponseforSubmitUnitStatementRollAccessMapping Method Start");
		UnitStatementLoadResponseVO unitStatementLoadResponseVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {
			bizRes = (BizResponse) context.getFlowScope().get(
					"bizResForUnitStatementAccessMappingData");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				} else {
					unitStatementLoadResponseVO = (UnitStatementLoadResponseVO) bizRes
							.getTransferObjects().get("response1");

					if (unitStatementLoadResponseVO == null) {
						FLogger.error(
								"UnitStatementLogger",
								"UnitStatementHandler",
								"getBizResponseforSubmitUnitStatementRollAccessMapping",
								"unitStatementLoadResponseVO should not be null");
						throw new IPruException("Error", "US01", ErrorMsg);
					}

					UnitStatementLoadResponsePO unitStatementLoadResponsePO = dozerBeanMapper
							.map(unitStatementLoadResponseVO,
									UnitStatementLoadResponsePO.class);

					if (unitStatementLoadResponsePO == null) {
						FLogger.error(
								"UnitStatementLogger",
								"UnitStatementHandler",
								"getBizResponseforSubmitUnitStatementRollAccessMapping",
								"unitStatementLoadResponsePO should not be null");
						throw new IPruException("Error", "US01", ErrorMsg);
					}

					List<ProfilePOCPO> data = new ArrayList<ProfilePOCPO>();

					Map<String, FieldAccessMappingVO> map = unitStatementLoadResponsePO
							.getFieldAccessMappingMap();

					if (map.isEmpty()) {
						FLogger.error(
								"UnitStatementLogger",
								"UnitStatementHandler",
								"getBizResponseforSubmitUnitStatementRollAccessMapping",
								"map should not be null");
						throw new IPruException("Error", "US01", ErrorMsg);
					}

					context.getFlowScope().put("unitStatementRoleAccessMatrix",
							map);
					ResultJsonPO resultMap = new ResultJsonPO();
					resultMap.setResultMap(map);
					resultJson = gsonJSON.toJson(resultMap);
					context.getFlowScope().put("Response", resultJson);

				}
			} else {
				FLogger.error(
						"UnitStatementLogger",
						"UnitStatementHandler",
						"getBizResponseforSubmitUnitStatementRollAccessMapping",
						"bizRes should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}

		} catch (Exception e) {
			FLogger.error("UnitStatementLogger", "UnitStatementHandler",
					"getBizResponseforSubmitUnitStatementRollAccessMapping",
					"Exception Occured ", e);
			throwINeoFlowException(e, "US01", context);
		}

		FLogger.info("UnitStatementLogger", "UnitStatementHandler",
				"getBizResponseforSubmitUnitStatementRollAccessMapping",
				"getBizResponseforSubmitUnitStatementRollAccessMapping Method End");

		return success();
	}

	@MethodPost
	public Event getBizRequestforUnitStatementSubmit(RequestContext p_ObjContext)
			throws Exception {
		FLogger.info("UnitStatementLogger", "UnitStatementHandler",
				"getBizRequestforUnitStatementSubmit",
				"getBizRequestforUnitStatementSubmit Method Start");

		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;

		FunctionalityMasterVO functionality;

		try {
			Map<String, FieldAccessMappingVO> map = (Map<String, FieldAccessMappingVO>) p_ObjContext
					.getFlowScope().get("unitStatementRoleAccessMatrix");
			if (map.isEmpty()) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						"ContactPersonRoleAccessMatrix Should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}
			HttpServletRequest request = (HttpServletRequest) p_ObjContext
					.getExternalContext().getNativeRequest();
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext
					.getExternalContext().getNativeRequest()).getSession();

			StringBuffer jb = new StringBuffer();
			String line = null;

			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}

			functionality = this.getFunctionality(p_ObjContext);

			if (functionality == null) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						"functionality Should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}

			UnitStatementRequestPO unitStatementRequestPO = gsonJSON.fromJson(
					jb.toString(), UnitStatementRequestPO.class);

			if (unitStatementRequestPO == null) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						"unitStatementRequestPO Should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}
			UnitStatementPO unitStatementPO = unitStatementRequestPO
					.getUnitStatementPO();

			if (StringUtils.isEmpty(unitStatementPO.getStartDate())
					&& StringUtils.isEmpty(unitStatementPO.getEndDate())) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						"getStartDate and getEndDate Should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}

			UnitStatementPojoUtil utility = new UnitStatementPojoUtil();

			String checkMandatoryresult = utility.checkMandatoryFields(
					unitStatementPO, map);

			if (StringUtils.isNotEmpty(checkMandatoryresult)) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						"checkMandatoryresult" + checkMandatoryresult);
				throw new IPruException("Error", "US01", checkMandatoryresult);
			}

			SimpleDateFormat sdf1=new SimpleDateFormat("dd MMMM,yyyy");
			SimpleDateFormat sdf2=new SimpleDateFormat("dd/MM/yyyy");
			
			

			Date startDate1=sdf1.parse(unitStatementPO.getStartDate());
			String startDate=sdf2.format(startDate1);
			
			Date endDate1=sdf1.parse(unitStatementPO.getEndDate());
			String endDate=sdf2.format(endDate1);
			
			if (startDate1.after(endDate1)) {

				throw new IPruException("Error", "US01",
						"Todate date should not be greater than From date");

			}

			int tmpDay, tmpMonth, tmpyear;

			String[] arrFromdate = startDate.split("/");
			String[] arrTodate = endDate.split("/");
			tmpDay = Integer.parseInt(arrFromdate[0]); // fromDate.substring(3,
														// 5));
			tmpMonth = Integer.parseInt(arrFromdate[1]); // fromDate.substring(0,
															// 2));
			tmpyear = Integer.parseInt(arrFromdate[2]);// fromDate.substring(6,10
														// ));
			// Date dtFrom = new Date(tmpyear,tmpMonth,tmpDay );//Commented as
			// its deprecated code
			Calendar calNew = Calendar.getInstance();
			calNew.set(tmpyear, tmpMonth - 1, tmpDay, 0, 0, 0);
			Date dtFrom = new Date(calNew.getTimeInMillis());

			tmpDay = Integer.parseInt(arrTodate[0]); // toDate.substring(3, 5));
			tmpMonth = Integer.parseInt(arrTodate[1]); // toDate.substring(0,
														// 2));
			tmpyear = Integer.parseInt(arrTodate[2]); // toDate.substring(6,10
														// )) ;
			// Date dtTo = new Date(tmpyear,tmpMonth,tmpDay );//Commented as its
			// deprecated code
			calNew.set(tmpyear, tmpMonth - 1, tmpDay, 0, 0, 0);
			Date dtTo = new Date(calNew.getTimeInMillis());
			Date todayDate = new Date();
			// Date restrictDate = new Date(2006-1900,3,1); //1st april
			// 2006//Commented as its deprected code

			calNew.set(2007, 3, 1, 0, 0, 0); // 1st april 2007
			Date restrictDate = new Date(calNew.getTimeInMillis());
			double diffFromDtnToDt = DateUtil.dayDiff(dtFrom, dtTo);

			if (diffFromDtnToDt >= 366.00) {
				FLogger.error(
						"UnitStatementLogger",
						"UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						" just - 1 yr validation check redirecting to error page as date is tempered with some tool");
				throw new IPruException("Error", "US01",
						"Date Entered By you is out of range, Please provide date between one year duration");
			}

			if (dtFrom.compareTo(restrictDate) < 0
					|| dtTo.compareTo(todayDate) > 0) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						"Date Entered By you is out of range, Please provide date between one year duration");
				throw new IPruException("Error", "US01",
						"Date Entered By you is out of range, Please provide date between one year duration");
			}

			IPruUser userVo = null;
			ReportWrapperPO reportWrapperPO = new ReportWrapperPO();

			userVo = (IPruUser) httpSession.getAttribute("userVO");

			if (userVo == null) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						"userVo should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}

			reportWrapperPO.setPolicyNo(userVo.getPolicyNo());
			reportWrapperPO.setClientId(userVo.getClientId());
			reportWrapperPO.setMemberEmpid(userVo.getEmpId());
			reportWrapperPO.setRole(userVo.getRoleType());
			reportWrapperPO.setFirstDate(startDate);
			reportWrapperPO.setLastDate(endDate);

			if (reportWrapperPO == null) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						"reportWrapperPO should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}

			ReportWrapperVO reportWrapperVO = dozerBeanMapper.map(
					reportWrapperPO, ReportWrapperVO.class);

			if (reportWrapperVO == null) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						"reportWrapperVO should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}

			p_ObjContext.getFlowScope().put("unitStatementFrontEndDetails",
					reportWrapperVO);
			Object[] paramArray = new Object[1];
			paramArray[0] = reportWrapperVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		} catch (Exception e) {

			FLogger.error("UnitStatementLogger", "UnitStatementHandler",
					"getBizRequestForProfileContactPersonChangeSubmit",
					"Exception came ", e);
			throwINeoFlowException(e, "US01", p_ObjContext);
		}
		FLogger.info("UnitStatementLogger", "UnitStatementHandler",
				"getBizRequestForProfileContactPersonChangeSubmit",
				"getBizRequestForProfileContactPersonChangeSubmit Method End");
		return success();

	}

	@MethodPost
	public Event getBizResponseforUnitStatementSubmit(RequestContext p_ObjContext)
			throws Exception {
		
		try
		{
			
			FLogger.info("UnitStatementLogger", "UnitStatementHandler",
					"getBizResponseforUnitStatementSubmit",
					"getBizResponseforUnitStatementSubmit Method Start");
		

			
			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			HttpSession httpSession = request.getSession();

			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForUnitStatementSubmitData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.info("UnitStatementLogger", "UnitStatementHandler",
							"getBizResponseforUnitStatementSubmit",
							"responseCheck null");
					throw new IPruException("Error", "US01", "No fund data found between provided duration");
				}
				else
				{
					FtlToPdfVO ftlToPdfVO=(FtlToPdfVO)bizRes.getTransferObjects().get("response1");
					
					if(ftlToPdfVO==null)
					{
						
						FLogger.info("UnitStatementLogger", "UnitStatementHandler",
								"getBizResponseforUnitStatementSubmit",
								"ftlToPdfVO null");
						
						throw new IPruException("Error","US01","No fund data found between provided duration");
					}
					
					httpSession.setAttribute("statementDownloadData", ftlToPdfVO);
					p_ObjContext.getFlowScope().put("Response", "success");
				}
			}
			else
			{
				
				FLogger.info("UnitStatementLogger", "UnitStatementHandler",
						"getBizResponseforUnitStatementSubmit",
						"ftlToPdfVO null");

				throw new IPruException("Error","US01","Some Error Occured");
			}
		}
		catch(Exception e)
		{
		
			FLogger.info("UnitStatementLogger", "UnitStatementHandler",
					"getBizResponseforUnitStatementSubmit",
					"Exception came",e);
			throwINeoFlowException(e, "US01", p_ObjContext);
		}
		
		FLogger.info("UnitStatementLogger", "UnitStatementHandler",
				"getBizResponseforUnitStatementSubmit",
				"getBizResponseforUnitStatementSubmit Method end");
		return success();
	}
	

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
