package com.ipru.groups.handler;

import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.ClaimsPMJJBYOnloadPO;
import com.ipru.groups.po.ClaimsPMJJBYSubmitPO;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.validators.ClaimsPMJJBYValidator;
import com.ipru.groups.vo.ClaimsPMJJBYOnloadVO;
import com.ipru.groups.vo.ClaimsPMJJBYSubmitVO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;

public class ClaimsPMJJBYHandler extends IneoBaseHandler {

	public Event getRequestOnLoadData(RequestContext context) throws Exception {
		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getRequestOnLoadData", " Method Start ");

		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PMJJBY_PROPERTIES;
		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String accountNumber = null;

			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");
				// policyNo = userVo.getPolicyNo();
				policyNo = prop.getProperty("policyNo");
				accountNumber = prop.getProperty("accountNO");

				ClaimsPMJJBYOnloadVO claimsPMJJBYOnloadVO = new ClaimsPMJJBYOnloadVO();
				claimsPMJJBYOnloadVO.setPolicyNo(policyNo);
				claimsPMJJBYOnloadVO.setAccountNumber(accountNumber);
				Object[] paramArray = new Object[1];
				paramArray[0] = claimsPMJJBYOnloadVO;
				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				context.getFlowScope().put("claimsPMJJBYBizReq", obj_bizReq);

			}
			else {
				FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getRequestOnLoadData", "session is null");
				throw new IPruException("Error", "GRPCL03", "No Data Found");
			}

		}
		catch (Exception e) {
			FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getRequestOnLoadData", "context should not be null" + e);
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getRequestOnLoadData", " Method End ");
		return success();
	}

	public Event getResponseOnLoadData(RequestContext context) throws Exception {
		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getResponseOnLoadData", " Method Start ");

		Gson gson = new Gson();

		BizResponse response = new BizResponse();
		try {
			response = (BizResponse) context.getFlowScope().get("bizResClaimsPMJJBYOnLoadData");
			long functionalityId = getFunctionalityId(context);
			// long functionalityId =17;
			List<ClaimsPMJJBYOnloadVO> claimsPMJJBYOnloadVOList = (List<ClaimsPMJJBYOnloadVO>) response.getTransferObjects().get("response1");

			if (CollectionUtils.isNotEmpty(claimsPMJJBYOnloadVOList)) {
				ClaimsPMJJBYOnloadVO claimsPMJJBYOnloadVO = claimsPMJJBYOnloadVOList.get(0);
				ClaimsPMJJBYOnloadPO claimsPMJJBYOnloadPO = dozerBeanMapper.map(claimsPMJJBYOnloadVO, ClaimsPMJJBYOnloadPO.class);
				claimsPMJJBYOnloadPO.setFunctionalityId(String.valueOf(functionalityId));
				context.getFlowScope().put("Response", gsonJSON.toJson(claimsPMJJBYOnloadPO));

			}
			else {
				FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getResponseOnLoadData", "claimsPMJJBYOnloadVOList is null");
				throw new IPruException("Error", "GRPCL03", "No Data Found");
			}
		}
		catch (Exception e) {
			FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getResponseOnLoadData", "context should not be null" + e);
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getResponseOnLoadData", " Method End ");
		return success();
	}

	public Event getRequestSubmit(RequestContext context) throws Exception {
		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getRequestSubmit", " Method Start ");

		HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
		ClaimsPMJJBYSubmitPO claimsPMJJBYSubmitPO = gsonJSON.fromJson(request.getReader(), ClaimsPMJJBYSubmitPO.class);
		FunctionalityMasterVO functionality = getFunctionality(context);

		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PMJJBY_PROPERTIES;
		try {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			
			if (httpSession != null) {
				IPruUser userVo = new IPruUser();
				userVo = (IPruUser) httpSession.getAttribute("userVO");
				String memberType = null;
				String productType = null;
				String role = null;
				memberType = prop.getProperty("memberType");
				productType = prop.getProperty("productType");
				role = userVo.getRoles();
				if (claimsPMJJBYSubmitPO.equals(null) && CollectionUtils.isEmpty(claimsPMJJBYSubmitPO.getBeneficiary())) {
					FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getRequestSubmit", "claimsPMJJBYSubmitPO should not be empty");
					throw new IPruException("Error", "GRPCL03", "claimsPMJJBYSubmitPO should not be empty");
				}
				ClaimsPMJJBYValidator claimsPMJJBYValidator = new ClaimsPMJJBYValidator();
				String errorMsg = claimsPMJJBYValidator.validateSubmit(claimsPMJJBYSubmitPO);
				if (StringUtils.isNotBlank(errorMsg)) {
					this.setValidationErrorMessages(errorMsg);
					FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getRequestSubmit", "Data from request should not be null");
					throwINeoFlowException(new ServiceException("GRPCL03"), "GRPCL03", context);
				}
				ClaimsPMJJBYSubmitVO claimsPMJJBYSubmitVO = dozerBeanMapper.map(claimsPMJJBYSubmitPO, ClaimsPMJJBYSubmitVO.class);
				claimsPMJJBYSubmitVO.setFunctionality(functionality);
				claimsPMJJBYSubmitVO.setMemberType(memberType);
				claimsPMJJBYSubmitVO.setProductType(productType);
				claimsPMJJBYSubmitVO.setClientId(claimsPMJJBYSubmitVO.getPolicyNo());
				claimsPMJJBYSubmitVO.setRole(role);
				Object[] paramArray = new Object[1];
				paramArray[0] = claimsPMJJBYSubmitVO;
				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);
				context.getFlowScope().put("ClaimsPMJJBYSubmit", obj_bizReq);
			}else{
				FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getRequestSubmit", "Session should not be empty");
				throw new IPruException("Error", "GRPCL03", "Session should not be empty");
			}
		}
		catch (Exception e) {
			FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getRequestSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getRequestSubmit", " Method End ");
		return success();
	}

	public Event getResponseSubmit(RequestContext context) throws Exception {
		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getResponseSubmit", " Method Start ");
		String responseCheck = "";
		String result = null;
		BizResponse bizres = new BizResponse();
		try {
			bizres = (BizResponse) context.getFlowScope().get("bizResClaimsPMJJBYSubmit");
			if (bizres != null) {
				responseCheck = (String) bizres.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "Error")) {
					FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getResponseSubmit", "Response is null");
					throw new IPruException("Error", "GRPCL03", "Response is null");
				}
				else {
					result = (String) bizres.getTransferObjects().get("response1");
					if (StringUtils.isNotEmpty(result)) {					
						context.getFlashScope().put("Response", result);
					}
					else {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getResponseSubmit", "No data Found");
						throw new IPruException("Error", "GRPCL03", "No data Found");
					}

				}
			}
		}
		catch (Exception e) {
			FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getResponseSubmit", "context should not be null" + e);
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYHandler", "getResponseSubmit", " Method End ");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
