package com.ipru.groups.handler;

import java.io.BufferedReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.generic.po.ResultJsonPO;
import com.ipru.groups.po.UnitStatementGratuityRequestPO;
import com.ipru.groups.po.UnitStmtLoadReqGratuityAccessMappingPO;
import com.ipru.groups.po.UnitStmtLoadResGratuityAcceeMappingPO;
import com.ipru.groups.utilities.DateUtil;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FtlToPdfVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.groups.vo.UnitStatementGratuityRequestVO;
import com.ipru.groups.vo.UnitStatementGratuityVO;
import com.ipru.groups.vo.UnitStmtLoadReqGratuityAccessMappingVO;
import com.ipru.groups.vo.UnitStmtLoadResGratuityAcceeMappingVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class UnitStatementGratuityHandler extends IneoBaseHandler {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String ErrorMsg = "Something went wrong please try again!";
	
	
	
	@MethodPost
	public Event getBizRequestforGetUnitStatementGratuityRollAccessMapping(
			RequestContext context) throws Exception {
		FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
				"getBizRequestforGetUnitStatementGratuityRollAccessMapping",
				"getBizRequestforGetUnitStatementGratuityRollAccessMapping Method Start");


		try {

			HttpSession httpSession = ((HttpServletRequest) context
					.getExternalContext().getNativeRequest()).getSession();
			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;

			fieldAccessMappingVoList = getFieldAccessMappingList(context);
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String screenName = null;
			List<RoleScreenAccessMappingVO> accessMappingList;

			userVo = (IPruUser) httpSession.getAttribute("userVO");
			if (userVo == null
					&& CollectionUtils.isEmpty(fieldAccessMappingVoList)) {

				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforGetUnitStatementGratuityRollAccessMapping",
						"fieldAccessMappingVoList and uservo should not be null");
				throw new IPruException("Error", "USGI01", ErrorMsg);
			}

			screenName = (String) context.getFlowScope().get("screenName");

			policyNo = userVo.getPolicyNo();

			FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
					"getBizRequestforGetUnitStatementGratuityRollAccessMapping",
					"When page load Policy No in session : " + policyNo);
			role = userVo.getRoles();

			FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
					"getBizRequestforSubmitUnitStatementRollAccessMapping",
					"When page load role in session : " + role);
			if (StringUtils.isEmpty(policyNo) && StringUtils.isEmpty(role)) {
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementRollAccessMapping",
						"PolicyNumber and role should not be null");
				throw new IPruException("Error", "USGI01", ErrorMsg);

			}

			accessMappingList = userVo.getLstRoleScreenAccessMapping();

			if (CollectionUtils.isEmpty(accessMappingList)) {
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementRollAccessMapping",
						"accessMappingList should not be null");
				throw new IPruException("Error", "USGI01", ErrorMsg);
			}

			UnitStmtLoadReqGratuityAccessMappingPO unitStmtLoadReqGratuityAccessMappingPO = new UnitStmtLoadReqGratuityAccessMappingPO();
			unitStmtLoadReqGratuityAccessMappingPO.setPolicyNo(policyNo);
			unitStmtLoadReqGratuityAccessMappingPO.setRole(role);
			unitStmtLoadReqGratuityAccessMappingPO.setScreenName(screenName);
			

			if (unitStmtLoadReqGratuityAccessMappingPO == null) {
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementRollAccessMapping",
						"unitStmtLoadReqGratuityAccessMappingPO  is null");
				throw new IPruException("Error", "USGI01", ErrorMsg);
			}

			
			UnitStmtLoadReqGratuityAccessMappingVO unitStmtLoadReqGratuityAccessMappingVO = null;
			unitStmtLoadReqGratuityAccessMappingVO = dozerBeanMapper.map(
					unitStmtLoadReqGratuityAccessMappingPO,
					UnitStmtLoadReqGratuityAccessMappingVO.class);

		

			if (unitStmtLoadReqGratuityAccessMappingVO == null) {
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementRollAccessMapping",
						"unitStmtLoadReqGratuityAccessMappingVO  is null");
				throw new IPruException("Error", "USGI01", ErrorMsg);
			}

			
		

			unitStmtLoadReqGratuityAccessMappingVO.setAccessMappingList(accessMappingList);
			unitStmtLoadReqGratuityAccessMappingVO.setFieldAccessMappingList(fieldAccessMappingVoList);
			Object[] paramArray = new Object[1];
			paramArray[0] = unitStmtLoadReqGratuityAccessMappingVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			context.getFlowScope().put("submitBizReq", obj_bizReq);

		} catch (Exception e) {
			FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
					"getBizRequestforSubmitUnitStatementRollAccessMapping",
					"Exception Occured ", e);
			throwINeoFlowException(e, "USGI01", context);
		}

		FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
				"getBizRequestforGetUnitStatementGratuityRollAccessMapping",
				"getBizRequestforGetUnitStatementGratuityRollAccessMapping Method End");


		return success();
	}

	
	@MethodPost
	public Event getBizResponseforGetUnitStatementGratuityRollAccessMapping(
			RequestContext context) throws Exception {

		FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
				"getBizResponseforGetUnitStatementGratuityRollAccessMapping",
				"getBizResponseforGetUnitStatementGratuityRollAccessMapping Method Start");
		UnitStmtLoadResGratuityAcceeMappingVO unitStmtLoadResGratuityAcceeMappingVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {
			bizRes = (BizResponse) context.getFlowScope().get(
					"bizResForGetUnitStatementGratuityRollAccessMapping");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				} else {
					unitStmtLoadResGratuityAcceeMappingVO = (UnitStmtLoadResGratuityAcceeMappingVO) bizRes
							.getTransferObjects().get("response1");

					if (unitStmtLoadResGratuityAcceeMappingVO == null) {
						FLogger.info(
								"UnitStatementGratuityLogger",
								"UnitStatementGratuityHandler",
								"getBizResponseforGetUnitStatementGratuityRollAccessMapping",
								"getBizResponseforGetUnitStatementGratuityRollAccessMapping should not be null");
						throw new IPruException("Error", "USGI01", ErrorMsg);
					}

					UnitStmtLoadResGratuityAcceeMappingPO unitStmtLoadResGratuityAcceeMappingPO = dozerBeanMapper
							.map(unitStmtLoadResGratuityAcceeMappingVO,
									UnitStmtLoadResGratuityAcceeMappingPO.class);

					if (unitStmtLoadResGratuityAcceeMappingPO == null) {
						FLogger.info(
								"UnitStatementGratuityLogger",
								"UnitStatementGratuityHandler",
								"getBizResponseforGetUnitStatementGratuityRollAccessMapping",
								"unitStmtLoadResGratuityAcceeMappingPO should not be null");
						throw new IPruException("Error", "USGI01", ErrorMsg);
					}
					if(unitStmtLoadResGratuityAcceeMappingVO.getFieldAccessMappingMap().isEmpty())
					{
						FLogger.info(
								"UnitStatementGratuityLogger",
								"UnitStatementGratuityHandler",
								"getBizResponseforGetUnitStatementGratuityRollAccessMapping",
								"unitStmtLoadResGratuityAcceeMappingVO.getFieldAccessMappingMap() should not be null");
						throw new IPruException("Error", "USGI01", ErrorMsg);
					}
					

					ResultJsonPO resultMap = new ResultJsonPO();
					resultMap.setResultMap(unitStmtLoadResGratuityAcceeMappingVO.getFieldAccessMappingMap());
					resultJson = gsonJSON.toJson(resultMap);
					context.getFlowScope().put("Response", resultJson);

				}
			} else {
				FLogger.info(
						"UnitStatementGratuityLogger",
						"UnitStatementGratuityHandler",
						"getBizResponseforGetUnitStatementGratuityRollAccessMapping",
						"bizRes should not be null");
				throw new IPruException("Error", "USGI01", ErrorMsg);
			}

		} catch (Exception e) {
			FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
					"getBizResponseforGetUnitStatementGratuityRollAccessMapping",
					"Exception Occured ", e);
			throwINeoFlowException(e, "USGI01", context);
		}

		FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
				"getBizResponseforGetUnitStatementGratuityRollAccessMapping",
				"getBizResponseforGetUnitStatementGratuityRollAccessMapping Method End");

		return success();
	}
	
	
	@MethodPost
	public Event getBizRequestforSubmitUnitStatementGratuity(
			RequestContext p_ObjContext) throws Exception {
		FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
				"getBizRequestforSubmitUnitStatementGratuity",
				"getBizRequestforSubmitUnitStatementGratuity Method Start");

		

		FunctionalityMasterVO functionality=null;;

		try {
			
			HttpServletRequest request = (HttpServletRequest) p_ObjContext
					.getExternalContext().getNativeRequest();
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext
					.getExternalContext().getNativeRequest()).getSession();

			StringBuffer jb = new StringBuffer();
			String line = null;

			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}
			IPruUser userVo = new IPruUser();
			

			userVo = (IPruUser) httpSession.getAttribute("userVO");
			functionality = this.getFunctionality(p_ObjContext);
/*
			if (functionality == null) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",TODO:Please add here 
						"getBizRequestforUnitStatementSubmit",
						"functionality Should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}*/

			UnitStatementGratuityRequestPO unitStatementGratuityRequestPO = gsonJSON.fromJson(
					jb.toString(), UnitStatementGratuityRequestPO.class);

			if (unitStatementGratuityRequestPO == null) {
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementGratuity",
						"unitStatementGratuityRequestPO Should not be null");
				throw new IPruException("Error", "USGI01", ErrorMsg);
			}
			//UnitStatementGratuityPO unitStatementGratuityPO = unitStatementGratuityRequestPO.getUnitStatementGratuityPO();

			/*if (StringUtils.isEmpty(unitStatementGratuityPO.getStartDate())
					&& StringUtils.isEmpty(unitStatementGratuityPO.getEndDate())) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						"getStartDate and getEndDate Should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}*/
			
			if(StringUtils.isEmpty(unitStatementGratuityRequestPO.getUnitStatementGratuityPO().getStartDate()))
			{
				
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementGratuity",
						"Please Enter From Date");
				throw new IPruException("Error", "USGI01",
						"Please Enter From Date");
				
			}
			
			if(StringUtils.isEmpty(unitStatementGratuityRequestPO.getUnitStatementGratuityPO().getEndDate()))
			{
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementGratuity",
						"Please Enter End Date");
				throw new IPruException("Error", "USGI01",
						"Please Enter End Date");
			}
			
			
			SimpleDateFormat sdf1=new SimpleDateFormat("dd MMMM,yyyy");
			SimpleDateFormat sdf2=new SimpleDateFormat("dd/MM/yyyy");
			
			

			Date startDate1=sdf1.parse(unitStatementGratuityRequestPO.getUnitStatementGratuityPO().getStartDate());
			String startDate=sdf2.format(startDate1);
			
			Date endDate1=sdf1.parse(unitStatementGratuityRequestPO.getUnitStatementGratuityPO().getEndDate());
			String endDate=sdf2.format(endDate1);
			
		
		    
		    
			if (startDate1.after(endDate1)) {

				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementGratuity",
						"Todate date should not be greater than From date");
				throw new IPruException("Error", "USGI01",
						"Todate date should not be greater than From date");

			}

			
			int tmpDay, tmpMonth, tmpyear;

			String[] arrFromdate = startDate.split("/");
			String[] arrTodate = endDate.split("/");
			tmpDay = Integer.parseInt(arrFromdate[0]); // fromDate.substring(3,
														// 5));
			tmpMonth = Integer.parseInt(arrFromdate[1]); // fromDate.substring(0,
															// 2));
			tmpyear = Integer.parseInt(arrFromdate[2]);// fromDate.substring(6,10
		
			Calendar calNew = Calendar.getInstance();
			calNew.set(tmpyear, tmpMonth - 1, tmpDay, 0, 0, 0);
			Date dtFrom = new Date(calNew.getTimeInMillis());

			tmpDay = Integer.parseInt(arrTodate[0]); // toDate.substring(3, 5));
			tmpMonth = Integer.parseInt(arrTodate[1]); // toDate.substring(0,
														// 2));
			tmpyear = Integer.parseInt(arrTodate[2]); // toDate.substring(6,10
			
			calNew.set(tmpyear, tmpMonth - 1, tmpDay, 0, 0, 0);
			Date dtTo = new Date(calNew.getTimeInMillis());
	
			
			calNew.set(2007, 3, 1, 0, 0, 0); // 1st april 2007

			double diffFromDtnToDt = DateUtil.dayDiff(dtFrom, dtTo);
			
			if (diffFromDtnToDt >= 366.00) {
				FLogger.error(
						"UnitStatementLogger",
						"UnitStatementHandler",
						"getBizRequestforUnitStatementSubmit",
						" just - 1 yr validation check redirecting to error page as date is tempered with some tool");
				throw new IPruException("Error", "USGI01",
						"Date Entered By you is out of range, Please provide date between one year duration");
			}
			
			
			unitStatementGratuityRequestPO.getUnitStatementGratuityPO().setStartDate(startDate);
			unitStatementGratuityRequestPO.getUnitStatementGratuityPO().setEndDate(endDate);
			
			unitStatementGratuityRequestPO.getUnitStatementGratuityPO().setClientId(userVo.getClientId());
			unitStatementGratuityRequestPO.getUnitStatementGratuityPO().setClientName(userVo.getClientName());
			
			
			if(unitStatementGratuityRequestPO==null)
			{
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementGratuity",
						"unitStatementGratuityRequestPO shpud not be null");
				throw new IPruException("Error", "USGI01",
						"SomeThing went wrong please try again!");
			}
			UnitStatementGratuityRequestVO unitStatementGratuityRequestVO=new UnitStatementGratuityRequestVO();
			UnitStatementGratuityVO unitStatementGratuityVO=null;
			unitStatementGratuityRequestVO = dozerBeanMapper.map(unitStatementGratuityRequestPO,UnitStatementGratuityRequestVO.class);
			
			if(unitStatementGratuityRequestVO==null)
			{
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementGratuity",
						"unitStatementGratuityRequestVO shpud not be null");
				throw new IPruException("Error", "USGI01",
						"SomeThing went wrong please try again!");
			}
			
			unitStatementGratuityVO=dozerBeanMapper.map(unitStatementGratuityRequestPO.getUnitStatementGratuityPO(), UnitStatementGratuityVO.class);
		
			if(unitStatementGratuityVO==null)
					{
				
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementGratuity",
						"unitStatementGratuityVO shpud not be null");
				throw new IPruException("Error", "USGI01",
						"SomeThing went wrong please try again!");
			
					}
	
			
		
			Object[] paramArray = new Object[1];
			paramArray[0] = unitStatementGratuityVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		} catch (Exception e) {

			FLogger.info("getBizRequestforSubmitUnitStatementGratuity", "UnitStatementGratuityHandler",
					"getBizRequestforSubmitUnitStatementGratuity",
					"Exception came ", e);
			throwINeoFlowException(e, "USGI01", p_ObjContext);
		}
		FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
				"getBizRequestforSubmitUnitStatementGratuity",
				"getBizRequestforSubmitUnitStatementGratuity Method End");
		return success();

	}

	
	@MethodPost
	public Event getBizResponseforSubmitUnitStatementGratuity(
			RequestContext p_ObjContext) throws Exception {
		
		try
		{
			
			FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
					"getBizResponseforSubmitUnitStatementGratuity",
					"getBizResponseforSubmitUnitStatementGratuity Method Start");
		

			
			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			HttpSession httpSession = request.getSession();

			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForFetchUnitStatementGratuity");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
							"getBizRequestforSubmitUnitStatementGratuity",
							"responseCheck null");
					throw new IPruException("Error", "USGI01", "No fund data found between provided duration");
				}
				else
				{
					FtlToPdfVO ftlToPdfVO=(FtlToPdfVO)bizRes.getTransferObjects().get("response1");
					
					if(ftlToPdfVO==null)
					{
						
						FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
								"getBizRequestforSubmitUnitStatementGratuity",
								"ftlToPdfVO null");
						
						throw new IPruException("Error","USGI01","No fund data found between provided duration");
					}
					
					httpSession.setAttribute("statementDownloadData", ftlToPdfVO);
					p_ObjContext.getFlowScope().put("Response", "success");
				}
			}
			else
			{
				
				FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
						"getBizRequestforSubmitUnitStatementGratuity",
						"ftlToPdfVO null");

				throw new IPruException("Error","USGI01","Some Error Occured");
			}
		}
		catch(Exception e)
		{
		
			FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
					"getBizRequestforSubmitUnitStatementGratuity",
					"Exception came",e);
			throwINeoFlowException(e, "USGI01", p_ObjContext);
		}
		
		FLogger.info("UnitStatementGratuityLogger", "UnitStatementGratuityHandler",
				"getBizResponseforSubmitUnitStatementGratuity",
				"getBizResponseforSubmitUnitStatementGratuity Method end");
		return success();
	}
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
