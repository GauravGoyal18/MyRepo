package com.ipru.groups.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.BidStatementPO;
import com.ipru.groups.validators.BIDStatementValidator;
import com.ipru.groups.vo.BidStatementVO;
import com.ipru.groups.vo.FtlToPdfVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;

public class BIDStatementHandler extends IneoBaseHandler{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Event getBizRequestForFetchBIDStatement(RequestContext context) throws Exception
	{
		
		FLogger.info("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "Method start");

		try
		{
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			IPruUser userVo = null;
			if(request==null)
			{
				FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "Found Null REquest");
				
				throw new IPruException("Error","BIDSTMT01","Some Error Occured");
				
			}
			HttpSession httpSession = request.getSession();
			if(httpSession==null)
			{
				
				FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "Found Null session");

				throw new IPruException("Error","BIDSTMT01","Null Seesion found");
			}
			
			userVo = (IPruUser) httpSession.getAttribute("userVO");
			if(userVo==null)
			{
				FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "Found Null session");

				throw new IPruException("Error","BIDSTMT01","Null Seesion found");
			}
			String policyKey=userVo.getPolicyKey();
			String roleType=userVo.getRoleType();
		
			
			BidStatementPO bidStatementPO = gsonJSON.fromJson(request.getReader(), BidStatementPO.class);
			if(bidStatementPO==null)
			{
				FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "bidStatementPO is null");
				throw new IPruException("Error","BIDSTMT01","Some Error Occured");
			}
			BIDStatementValidator validator=new BIDStatementValidator();
			String errorSuccessMessage=validator.validateBid(bidStatementPO);
			if (StringUtils.isNotBlank(errorSuccessMessage)) {

				this.setValidationErrorMessages(errorSuccessMessage);
				FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "errorSuccessMessage");
				//throw new IPruException("Error","BIDSTMT01","Null Seesion found");
				throwINeoFlowException(new ServiceException("BIDSTMT01"), "BIDSTMT01", context);

			}
			FLogger.info("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "Validation Successful");
			BidStatementVO bidStatementVO = dozerBeanMapper.map(bidStatementPO, BidStatementVO.class);
			
			if(bidStatementVO==null)
			{
				FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "bidStatementVO is null");
				throw new IPruException("Error","BIDSTMT01","Some Error Occured");
			}
			

			bidStatementVO.setPolicyNo(userVo.getPolicyNo());
			bidStatementVO.setPolicyKey(policyKey);
			bidStatementVO.setClientName(userVo.getClientName());
			bidStatementVO.setLocation(userVo.getUnitName());
			bidStatementVO.setRenewalNo(userVo.getRenewalNo());
			bidStatementVO.setRoleType(userVo.getRoleType());
			
			if("term".equalsIgnoreCase(roleType))//roleType.equalsIgnoreCase("term"))
			{
				bidStatementVO.setUnitCode(userVo.getUnitCode());
			}
			Object[] paramArray = new Object[1];
			paramArray[0] = bidStatementVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			context.getFlowScope().put("bidStatementFetchDataBizReq", obj_bizReq);
		}
		catch(Exception e)
		{
			FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "Exception ", e);
			throwINeoFlowException(e, "BIDSTMT01", context);
		}
		
		FLogger.info("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "Method success");

		return success();
	}
	
	
	public Event getBizResponseForFetchBIDStatement(RequestContext context) throws Exception
	{
		
		try
		{
			
			
			FLogger.info("BIDStatementLogger", "BIDStatementHandler", "getBizResponseForFetchBIDStatement", "Method start");

			
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			HttpSession httpSession = request.getSession();

			if(httpSession==null)
			{
				FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizResponseForFetchBIDStatement", "httpSession is null");
				throw new IPruException("Error","BIDSTMT01","Null Seesion data");

			}
			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) context.getFlowScope().get("bizResForFetchBIDStatement");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throw new IPruException("Error", "BIDSTMT01", "Some Error Occured,Please try again later");
				}
				else
				{
					FtlToPdfVO ftlToPdfVO=(FtlToPdfVO)bizRes.getTransferObjects().get("response1");
					
					if(ftlToPdfVO==null)
					{
						FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizResponseForFetchBIDStatement", "bidResponseList is null");
						throw new IPruException("Error","BIDSTMT01","Some Error Occured");
					}
					
					httpSession.setAttribute("statementDownloadData", ftlToPdfVO);
					//String result = gsonJSON.toJson(nomineeUpdateTransactionPo);
					context.getFlowScope().put("Response", "success");
				}
			}
			else
			{
				FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizResponseForFetchBIDStatement", "bizRes is null");
				throw new IPruException("Error","BIDSTMT01","Some Error Occured");
			}
		}
		catch(Exception e)
		{
			FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizResponseForFetchBIDStatement", "Some Error Occured",e);

			throwINeoFlowException(e, "BIDSTMT01", context);
		}
		return success();
	}
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		// TODO Auto-generated method stub
		
	}

}
