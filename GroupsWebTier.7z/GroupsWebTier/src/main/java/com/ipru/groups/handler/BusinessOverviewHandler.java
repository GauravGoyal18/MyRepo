package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.BusinessOverviewResponsePO;
import com.ipru.groups.vo.BusinessOverviewRequestVO;
import com.ipru.groups.vo.BusinessOverviewResponseVO;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BusinessOverviewHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final String CLASS_NAME = BusinessOverviewHandler.class.getCanonicalName();
	private static final String INFO_LOGGER_NAME = "BusinessOverviewLogger";
	private static final String ERROR_LOGGER_NAME = "BusinessOverviewLogger";
	

	private static final long serialVersionUID = 1L;

	@MethodPost
	public Event getBizRequestBusinessOverview(RequestContext context) throws Exception {
		 final String METHOD_NAME = "getBizRequestBusinessOverview";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, " Method Start");
		Gson gson = new Gson();
		
		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
				String nationalCode = null;
				String branchCode = null;
				String loginType = null;
				String brokerType=null;

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {
						
						FscDetailsVO fscDetailVo = userVo.getFscdetails();
						if(fscDetailVo != null){
							branchCode = fscDetailVo.getBranchCode();// Will get from session
							loginType = fscDetailVo.getLogin_type();// Will get from session
							nationalCode = fscDetailVo.getNationalCode(); // Will get from session
							brokerType=fscDetailVo.getFscChannel();
						}
						/*branchCode = userVo.getFscdetails().getReferral_code();// Will get from session
						loginType = userVo.getFscdetails().getFscChannel();// Will get from session
						nationalCode =  userVo.getFscdetails().getNationalCode();// Will get from session*/
						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

						if (request != null) {
							BusinessOverviewRequestVO businessOverviewRequestVO = new BusinessOverviewRequestVO();
							businessOverviewRequestVO.setNationalCode(nationalCode);
							businessOverviewRequestVO.setBranchCode(branchCode);
							businessOverviewRequestVO.setLoginType(loginType);
							businessOverviewRequestVO.setBrokerType(brokerType);

							Object[] paramArray = new Object[1];

							if (businessOverviewRequestVO != null) {
								paramArray[0] = businessOverviewRequestVO;
								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);
								context.getFlowScope().put("BizRequestBusinessOverviewOnLoad", obj_bizReq);
							}
						}
						else {

							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "request should not be null");
							throw new IPruException("Error", "GRPBO", "request should not be null");
						}
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
						throw new IPruException("Error", "GRPBO", "userVo should not be null");
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
					throw new IPruException("Error", "GRPBO", "httpSession should not be null");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Context should not be null");
				throw new IPruException("Error", "GRPBO", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBO", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, " Method End ");
		return success();
	}

	@MethodPost
	public Event getBizResponseBusinessOverviewOnLoad(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseBusinessOverviewOnLoad";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		 
	
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		
		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForBusinessOverviewOnLoad");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {

						List<BusinessOverviewResponseVO> businessOverviewResponseVOList = (List<BusinessOverviewResponseVO>) bizRes.getTransferObjects().get("response1");

						List<BusinessOverviewResponsePO> businessOverviewResponsePOList = null;
						if (businessOverviewResponseVOList != null) {
							businessOverviewResponsePOList = new ArrayList<BusinessOverviewResponsePO>();

							for (BusinessOverviewResponseVO businessOverviewResponseVO : businessOverviewResponseVOList) {

								BusinessOverviewResponsePO businessOverviewResponsePO = dozerBeanMapper.map(businessOverviewResponseVO, BusinessOverviewResponsePO.class);

								businessOverviewResponsePOList.add(businessOverviewResponsePO);
							}

						}
						String callJsonString = gsonJSON.toJson(businessOverviewResponsePOList);
						FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "callJsonString::" + callJsonString);
						context.getFlowScope().put("Response", callJsonString);
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBO", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");

		return success();

	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}
}
