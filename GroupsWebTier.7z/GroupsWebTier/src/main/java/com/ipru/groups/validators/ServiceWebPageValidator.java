package com.ipru.groups.validators;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ipru.groups.po.ServiceWebPageMenuPO;
import com.ipru.groups.po.ServiceWebPageSubmitRequestPO;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.ServiceWebPageMenuVO;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public class ServiceWebPageValidator {

	private final StringBuilder errorMessageBuilder = new StringBuilder(1);
	private Properties prop = new Properties();

	public String validateServiceWebPageSubmitRequestPO(RequestContext context, ServiceWebPageSubmitRequestPO serviceWebPageSubmitRequestPO) throws Exception {

		FLogger.info("GROUPLogger", "ServiceWebPageValidator", "validateServiceWebPageSubmitRequestPO", "method start");

		String policyNoInSession = null;
		String menuMapVOString = null;
		HashMap<String, ServiceWebPageMenuVO> menuMap = null;
		Gson gson = new GsonBuilder().serializeNulls().create();

		if (context != null) {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			if (httpSession != null) {
				IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
				// ////System.out.println("UserVo in session : " + userVo);

				if (userVo != null) {
					policyNoInSession = userVo.getPolicyNo();

					HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
					if (request != null) {
						errorMessageBuilder.setLength(0);

						if (serviceWebPageSubmitRequestPO != null) {

							menuMapVOString = (String) context.getFlowScope().get("menuMapVOString");

							menuMap = gson.fromJson(menuMapVOString, HashMap.class);

//							////System.out.println(">>>>>>>>>>>>> menuMap : " + menuMap);

							prop = MasterPropertiesFileLoader.CONSTANT_SERVICEWEBPAGE_LENGTH_PROPERTIES;

							if (!validateRequestedMenu(serviceWebPageSubmitRequestPO.getSelectedMenu(), menuMap)) {
								errorMessageBuilder.append("Please Select Request Menu.");
							}
							if (!validateDetailOfRequest(serviceWebPageSubmitRequestPO.getDetailOfRequest())) {
								errorMessageBuilder.append("Please Enter Valid Detail of request.");
							}
							if (!validatePolicyNo(serviceWebPageSubmitRequestPO.getPolicyNumber(), policyNoInSession)) {
								errorMessageBuilder.append("Policy No is not valid.");
							}
						}
						else {
							errorMessageBuilder.append("Please Enter Valid Details.");
						}

					}
				}
			}
		}

		FLogger.info("GROUPLogger", "ServiceWebPageValidator", "validateServiceWebPageSubmitRequestPO", "method end");

		return errorMessageBuilder.toString();
	}

	private boolean validateDetailOfRequest(String detailOfRequest) {

		long length = Long.valueOf(prop.getProperty("DetailOfRequest"));

		if (CommonValidationUtil.ValidateRequired(detailOfRequest) && CommonValidationUtil.ValidateAddress(detailOfRequest) && detailOfRequest.length() < length) {
			return true;

		}
		else {
			return false;
		}
	}

	private boolean validatePolicyNo(String policyNo, String policyNoInSession) {
		long length = Long.valueOf(prop.getProperty("DetailOfRequest"));

		if (CommonValidationUtil.ValidateRequired(policyNo) && StringUtils.equalsIgnoreCase(policyNo, policyNoInSession) && policyNo.length() < length) {
			return true;

		}
		else {
			return false;
		}
	}

	private boolean validateRequestedMenu(ServiceWebPageMenuPO selectedMenu, HashMap<String, ServiceWebPageMenuVO> menuMap) {
		////System.out.println(">>>>>>>>>> selectedMenu.getRequestMenuID() : " + selectedMenu.getRequestMenuID());
		if (selectedMenu != null) {
			Iterator it = menuMap.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry) it.next();
				//System.out.println(pair.getKey() + " = " + pair.getValue());
				if (pair.getKey().equals(selectedMenu.getRequestMenuID().toString())) {
					return true;
				}
				else {
					//System.out.println(pair.getKey() + "*****************" + selectedMenu.getRequestMenuID());
				}
			}
			/*
			 * Set<Long> keySet = menuMap.keySet();
			 * ////System.out.println(">>>>>>>>>>>>>> keySet : "+keySet); for(Long
			 * key : keySet){ //System.out.println(); if(Long.valueOf(key) ==
			 * selectedMenu.getRequestMenuID()) return true; }
			 */

			/*
			 * if (keySet .contains(selectedMenu.getRequestMenuID())) { return
			 * true; } else{ return false; }
			 */
		}
		return false;
	}
	
	private boolean validateUploadFileList(List<UploadFilePO> uploadFileList) {
		
		if(uploadFileList == null){
			return true;
		} else {
			for (UploadFilePO uploadFilePO : uploadFileList){
				// check size 
				// check extension
				
			}
			return true;
		}		
	}

}
