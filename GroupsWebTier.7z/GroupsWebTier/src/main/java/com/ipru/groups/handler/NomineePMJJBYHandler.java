package com.ipru.groups.handler;

import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.NomineePMJJBYPO;
import com.ipru.groups.po.NomineePMJJBYSubmitPO;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.validators.NomineePMJJBYValidator;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.NomineePMJJBYSubmitVO;
import com.ipru.groups.vo.NomineePMJJBYVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class NomineePMJJBYHandler extends IneoBaseHandler{
	
	
	/**
	 * ipru29847
	 */
	private static final long serialVersionUID = 1L;




	public Event getRequestPrePopulateNomineePMJJBY(RequestContext context) throws Exception {
		FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getRequestPrePopulateNomineePMJJBY", " Method Start ");
		
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PMJJBY_PROPERTIES;
		
		
		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
	
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String accountNumber=null;
			NomineePMJJBYVO nomineePMJJBYVO=null;
			
			if (httpSession != null) {
				    
				   userVo = (IPruUser) httpSession.getAttribute("userVO");
			 
										
					policyNo = prop.getProperty("policyNo");
					accountNumber = prop.getProperty("accountNO");
					
					
					NomineePMJJBYPO nomineePMJJBYPO=new NomineePMJJBYPO();
					nomineePMJJBYPO.setPolicyNo(policyNo);
					nomineePMJJBYPO.setAccountNumber(accountNumber);
					if (nomineePMJJBYPO != null) {
						nomineePMJJBYVO=dozerBeanMapper.map(nomineePMJJBYPO,NomineePMJJBYVO.class);
					}

					if(nomineePMJJBYVO==null)
					{
						throw new IPruException("Error", "GRPCL03", "No Data Found");
						
					}
					
			}
			else {
				FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYHandlerNomineePMJJBYHandler", "getRequestPrePopulateNomineePMJJBY", "session is null");
				throw new IPruException("Error", "GRPCL03", "No Data Found");
			}	
					
					
					
					Object[] paramArray = new Object[1];
					paramArray[0] = nomineePMJJBYVO;
					BizRequest obj_bizReq = new BizRequest();
					obj_bizReq.addbusinessObjects("service-obj1", paramArray);

					context.getFlowScope().put("nomineePMJJBYBizReq", obj_bizReq);
				
		

		}
		catch (Exception e) {
			FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getRequestPrePopulateNomineePMJJBY", "context should not be null" + e);
			throwINeoFlowException(e, "GRPCL03", context);
		}
		
		FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getRequestPrePopulateNomineePMJJBY", " Method End ");
		return success();
	}
	
	
	public Event getResponsePrePopulateNomineePMJJBY(RequestContext context) throws Exception {
		FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getResponsePrePopulateNomineePMJJBY", " Method Start ");
		
		Gson gson = new Gson();
     try{
		BizResponse response = new BizResponse();
		response = (BizResponse) context.getFlowScope().get("bizResNomineePMJJBYOnLoadData");
					
		List<NomineePMJJBYVO>nomineePMJJBYOnloadVOList = (List<NomineePMJJBYVO>) response.getTransferObjects().get("response1");
		
		
		
		
		if(CollectionUtils.isNotEmpty(nomineePMJJBYOnloadVOList)){			
			NomineePMJJBYVO nomineePMJJBYOnloadVO=nomineePMJJBYOnloadVOList.get(0);
			NomineePMJJBYPO nomineesPMJJBYOnloadPO=dozerBeanMapper.map(nomineePMJJBYOnloadVO, NomineePMJJBYPO.class);
			context.getFlowScope().put("Response", gsonJSON.toJson(nomineesPMJJBYOnloadPO));

		}else{
			FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getResponsePrePopulateNomineePMJJBY", "nomineePMJJBYOnloadVOList is null");
			throw new IPruException("Error", "GRPCL03", "No Data Found");
		}
     }
     catch(Exception e ){
    	 FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getRequestPrePopulateNomineePMJJBY", "context should not be null" + e);
			throwINeoFlowException(e, "GRPCL03", context);
    	 
     }
		FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getResponsePrePopulateNomineePMJJBY", " Method End ");
		return success();
	}
	
	
	
	@MethodPost
	public Event getBizRequestforSubmitNomineePMJJBY(RequestContext context) throws Exception {

		   FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getBizRequestforSubmitNomineePMJJBY", "getBizRequestforSubmitNominee Method start");
		   
		    Properties prop = new Properties();
			prop = MasterPropertiesFileLoader.CONSTANT_PMJJBY_PROPERTIES;
			NomineePMJJBYSubmitPO nomineePMJJBYSubmitPO=null;
			FunctionalityMasterVO functionality =null;
			String memberType = null;
			String productType = null;
			String role=null;
       try{
		
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			
	   if(httpSession!=null){
			
			  IPruUser userVo = new IPruUser();
			  userVo = (IPruUser) httpSession.getAttribute("userVO");

		      role =userVo.getRoles();
            // Convert json to object
			 nomineePMJJBYSubmitPO = gsonJSON.fromJson(request.getReader(), NomineePMJJBYSubmitPO.class);
			 functionality = getFunctionality(context);
			
			memberType = prop.getProperty("memberType");
			productType = prop.getProperty("productType");
		}
				
			
			if (nomineePMJJBYSubmitPO==null) {
				   FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getBizRequestforSubmitNomineePMJJBY", "nomineeSubmitPO should not be empty");
				   throw new IPruException("Error", "GRPCL03", "nomineeSubmitPO should not be empty");
			}

			NomineePMJJBYValidator nomineePMJJBYValidator=new NomineePMJJBYValidator(); 
			String errorMsg =nomineePMJJBYValidator.validateSubmit(nomineePMJJBYSubmitPO);
			
			if (StringUtils.isNotBlank(errorMsg)) {
				//this.setValidationErrorMessages(errorMsg);
				FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getBizRequestforSubmitNomineePMJJBY", "Data from request should not be null");
				//throwINeoFlowException(new ServiceException("GRPCL03"), "GRPCL03", context);
				throw new IPruException("Error", "GRPCL03", errorMsg);

			}
			
			NomineePMJJBYSubmitVO nomineePMJJBYSubmitVO = dozerBeanMapper.map(nomineePMJJBYSubmitPO, NomineePMJJBYSubmitVO.class);
		
			nomineePMJJBYSubmitVO.setFunctionality(functionality);
			nomineePMJJBYSubmitVO.setMemberType(memberType);
			nomineePMJJBYSubmitVO.setProductType(productType);
			nomineePMJJBYSubmitVO.setRole(role);
			nomineePMJJBYSubmitVO.setClientId(nomineePMJJBYSubmitVO.getPolicyNo());

			
			Object[] paramArray = new Object[1];
			paramArray[0] = nomineePMJJBYSubmitVO;

            BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			context.getFlowScope().put("saveBizReqNomineePMJJBY", obj_bizReq);
       }catch(Exception e){
    	   
			FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getBizRequestforSubmitNomineePMJJBY", " Exception came ",e);
			throwINeoFlowException(e, "GRPCL03", context);


       }
       
		
			FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getBizRequestforSubmitNomineePMJJBY", " Method End ");
			return success();
	}
	
	
	// respone of 
	public Event getBizResponseforNomineePMJJBY(RequestContext context) throws Exception {
       
		FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getBizResponseforNomineePMJJBY", " Method Start ");
       
		String responseCheck = "";
        String result = null;
      try{
        BizResponse bizres = new BizResponse();
        bizres = (BizResponse) context.getFlowScope().get("bizResForSubmitNomineePMJJBY");
        if (bizres != null) {
            responseCheck = (String) bizres.getStatusVO().getStatus();
            if (StringUtils.equalsIgnoreCase(responseCheck, "Error")) {
                FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getBizResponseforNomineePMJJBY", "Response is null");
                throw new IPruException("Error", "GRPCL03", "Response is null");
            }
            else {
                result = (String) bizres.getTransferObjects().get("response1");
                if (StringUtils.isNotEmpty(result)) {
                    String result2 = gsonJSON.toJson(result);
                    context.getFlashScope().put("Response", result);
                }
                else {
                    FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getBizResponseforNomineePMJJBY", "No data Found");
                    throw new IPruException("Error", "GRPCL03", "No data Found");
                }

            }
        }
        }catch(Exception e){
        	FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getBizRequestforSubmitNomineePMJJBY", "Exception came ",e);
			throwINeoFlowException(e, "GRPCL03", context);
        	
        }

        FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYHandler", "getBizResponseforNomineePMJJBY", " Method End ");
        return success();
    } 

	
	

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		// TODO Auto-generated method stub
		
	}

}
