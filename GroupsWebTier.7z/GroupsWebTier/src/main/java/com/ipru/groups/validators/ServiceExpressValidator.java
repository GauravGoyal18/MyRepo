package com.ipru.groups.validators;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ipru.groups.po.ServiceExpressPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public class ServiceExpressValidator {
	
	private final StringBuilder errorMessageBuilder = new StringBuilder(1);
	private Properties prop = new Properties();

	public String validateServiceExpressPageSubmitRequestPO(RequestContext context, ServiceExpressPO serviceExpressPO)  throws Exception{
		// TODO Auto-generated method stub
		FLogger.info("GROUPLogger", "ServiceExpressValidator", "validateServiceExpressPageSubmitRequestPO", "method start");
		String policyNoInSession = null;
		Gson gson = new GsonBuilder().serializeNulls().create();
		if (context != null) {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			if (httpSession != null) {
				IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
				
				if (userVo != null) {
					policyNoInSession = userVo.getPolicyNo();

					HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
					if (request != null) {
						errorMessageBuilder.setLength(0);
						
						if (serviceExpressPO != null) {
		
							if (!validatelocation(serviceExpressPO.getLocation())) {
								errorMessageBuilder.append("Please Select location.\n");
							}
							if (!validateempcount(serviceExpressPO.getEmpCount())) {
								errorMessageBuilder.append("Please enter valid employee count.\n");
							}
							if (!validateSPOCname(serviceExpressPO.getSPOCname())) {
								errorMessageBuilder.append("Please enter valid SPOCName.\n");
							}
							if (!validatemobile(serviceExpressPO.getMobilenumber())) {
								errorMessageBuilder.append("Please enter valid mobile number.\n");
							}
							if (!validatelandline(serviceExpressPO.getLandlinenumber())) {
								errorMessageBuilder.append("Please enter valid landline number.\n");
							}
							if (!validatedescription(serviceExpressPO.getDescription())) {
								errorMessageBuilder.append("Please enter valid description.\n");
							}
						}
						else {
							errorMessageBuilder.append("Please Enter Valid Details.\n");


						}
					}
				}
			}
		}
		FLogger.info("GROUPLogger", "ServiceExpressValidator", "validateServiceExpressPageSubmitRequestPO", "method end");

		return errorMessageBuilder.toString();
		
	}
	private boolean validatelocation(String location) {
		if(StringUtils.isNotEmpty(location)){
		if (CommonValidationUtil.ValidateRequired(location) && CommonValidationUtil.ValidateAddress(location) && CommonValidationUtil.ValidateMaxLength(location, 200)) {
			return true;

		}
		else {
			return false;
		}
		}
		else{
			return false;
		}
	}

	
	private boolean validateempcount(String count) {
		if (CommonValidationUtil.ValidateRequired(count) && CommonValidationUtil.ValidateNumeric(count)) {
			return true;

		}
		else {
			return false;
		}
	}
	
	private boolean validateSPOCname(String Spocname) {
		if(StringUtils.isNotEmpty(Spocname)){
		if (CommonValidationUtil.ValidateRequired(Spocname) && CommonValidationUtil.ValidateAlpha((Spocname)) && CommonValidationUtil.ValidateMaxLength(Spocname, 100)) {
			return true;

		}
		else {
			return false;
		}
		}
		else
		{
			return false;
		}
	}
	
	private boolean validatemobile(String mobile) {
		if(StringUtils.isNotBlank(mobile)){
	if (CommonValidationUtil.ValidateRequired(mobile) && CommonValidationUtil.isMatchedPattern(mobile,GroupFormValidationConstant.INDIAN_MOBILE_VALIDATION) 
			&& CommonValidationUtil.ValidateMaxLength(mobile,10)) {
			return true;

		}
		else {
			return false;
		}
		}
		else
		{
			return false;
		}
	}
	
	private boolean validatelandline(String landline) {
		if(StringUtils.isNotBlank(landline)){
	if (CommonValidationUtil.ValidateRequired(landline) && CommonValidationUtil.isMatchedPattern(landline,GroupFormValidationConstant.LANDLINE_REGEX) 
			&& CommonValidationUtil.ValidateMaxLength(landline,11)) {
			return true;

		}
		else {
			return false;
		}
		}
		else
		{
			return false;
		}
	}
	
	private boolean validatedescription(String description) {
		if(StringUtils.isNotEmpty(description)){
		if (CommonValidationUtil.ValidateRequired(description) && CommonValidationUtil.ValidateAddress(description) && CommonValidationUtil.ValidateMaxLength(description, 500)) {
			return true;

		}
		else {
			return false;
		}
		}
		else{
			return false;
		}
	}
	
}
