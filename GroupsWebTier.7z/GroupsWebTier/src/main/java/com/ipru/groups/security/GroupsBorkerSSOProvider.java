package com.ipru.groups.security;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ipru.groups.service.WebserviceInvoke;
import com.ipru.groups.vo.BrokerDashboardDetailsVO;
import com.ipru.groups.vo.CoiResponseDataVO;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.security.user.IPruUser;
import com.tcs.exception.SecurityException;
import com.tcs.logger.FLogger;

public class GroupsBorkerSSOProvider {
	
	/**
	 * @author Rohitash
	 */

  
	LoginProcessService1 lps = null;
	FscDetailsVO fscdetails=null;
	public IPruUser getBrokerSSOProvider(IPruUser userVO,	Authentication authentication) throws SSOGroupDefaultException {
		// TODO Auto-generated method stub
		//String fsc_client_Id = String.valueOf(((IPruUser) authentication.getPrincipal()).getFsc_client_Id());
		//String websiteSource = String.valueOf(((IPruUser) authentication.getPrincipal()).getWebsiteSource());
		
		String referral_code =null;
	try {  
			
		
		
		lps = new LoginProcessService1();
		
		FLogger.info("securityLogger", "GroupsBorkerSSOProvider", "getBrokerSSOProvider", "ssoLogin Start");

		//referral_code = lps.groupBorkerLoginSSO(userVO);     
		//List<String> paramList = new ArrayList<String>();        
		//paramList.add(userVO.getFsc_client_Id());
		
		 fscdetails=new FscDetailsVO();
		fscdetails.setFsc_client_id(userVO.getFsc_client_Id());

		String output = WebserviceInvoke.getInstance().invokePrePopulateDetailsForFscDetailsFind(fscdetails,"securityLogger");
		 fscdetails =  new Gson().fromJson(output.toString(), new TypeToken<FscDetailsVO>() {   
		}.getType());
		
		
		referral_code=fscdetails.getReferral_code();
	 
		if (!StringUtils.isEmpty(referral_code)) {  
			userVO = lps.loginFscClientID(userVO,fscdetails);       
			
		  }else if(userVO.getFscdetails()==null){   
				FLogger.info("securityLogger", "GroupsBorkerSSOProvider", "getBrokerSSOProvider", "password should not be null");
	
				throw new SSOGroupDefaultException("Broker not registered");  
			}
			else {
				     FLogger.info("securityLogger", "GroupsBorkerSSOProvider", "getBrokerSSOProvider", "password should not be null");
	
				     throw new SSOGroupDefaultException("Broker not registered");
			   }

	           	FLogger.info("securityLogger", "GroupsBorkerSSOProvider", "getBrokerSSOProvider", "ssoLogin End");
		
		}catch (Exception e) {

			throw new SSOGroupDefaultException("Broker not registered");
		}   
		return  userVO;
	}

}
