package com.ipru.groups.utilities;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.ipru.enums.UnitStatementEnum;
import com.ipru.groups.po.UnitStatementPO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.tcs.logger.FLogger;

public class UnitStatementPojoUtil {
	public String checkMandatoryFields(UnitStatementPO unitStatementPO,Map<String,FieldAccessMappingVO> backEnd)
	{
		FLogger.info("UnitStatementLogger", "UnitStatementPojoUtil class to UnitStatementHandler class", "checkMandatoryFields", "checkMandatoryFields Method Start");	
		StringBuffer errorMessageBuilder = new StringBuffer(1);
			errorMessageBuilder.append(validatePO(unitStatementPO.getStartDate(),backEnd,UnitStatementEnum.startDate.name()));
			errorMessageBuilder.append(validatePO(unitStatementPO.getEndDate(),backEnd,UnitStatementEnum.endDate.name()));
			FLogger.info("UnitStatementLogger", "UnitStatementPojoUtil class to UnitStatementHandler class", "checkMandatoryFields", "checkMandatoryFields Method end");	
		
			return errorMessageBuilder.toString();	
	}

	
	private String validatePO(String pojoData,Map<String,FieldAccessMappingVO> backEnd,String key)
	{
		FLogger.info("UnitStatementLogger", "UnitStatementPojoUtil class to UnitStatementHandler class", "checkMandatoryFields", "validatePO Method Start");	
		StringBuffer errorMessageBuilder = new StringBuffer(1);
		
		FieldAccessMappingVO vo=backEnd.get(key);
	
		String result=mandatoryCheck(Integer.parseInt(vo.getOpMandatory()),String.valueOf(pojoData),key);
		if(StringUtils.isEmpty(result))
		{
			
		}
		else
		{
			errorMessageBuilder.append(result);	
		}
		
		FLogger.info("UnitStatementLogger", "UnitStatementPojoUtil class to UnitStatementHandler class", "checkMandatoryFields", "validatePO Method End");	
		return errorMessageBuilder.toString();
	}
	
	
	private String mandatoryCheck(int mandatory,String newValue,String key)
	{
		FLogger.info("UnitStatementLogger", "UnitStatementPojoUtil class to UnitStatementHandler class", "checkMandatoryFields", "mandatoryCheck Method Start");	
		String result="";
		boolean flag=false;
		
		if(mandatory==1)
		{
			flag=StringUtils.isEmpty(newValue);
			if(flag)
			{
				result=key+" is Mandatory Please Fill. ";
			}
		}

		FLogger.info("UnitStatementLogger", "UnitStatementPojoUtil class to UnitStatementHandler class", "checkMandatoryFields", "mandatoryCheck Method End");	
		return result;
	}


}
