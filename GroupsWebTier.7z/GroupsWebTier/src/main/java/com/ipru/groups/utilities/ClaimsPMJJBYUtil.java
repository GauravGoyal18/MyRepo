package com.ipru.groups.utilities;

import java.util.ArrayList;
import java.util.List;

import com.ipru.groups.po.ClaimsBenPMJJBYSubmitPO;
import com.ipru.groups.po.ClaimsPMJJBYDropDownPO;
import com.ipru.groups.po.ClaimsPMJJBYSubmitPO;
import com.ipru.groups.po.UploadFilePO;
import com.tcs.logger.FLogger;

public class ClaimsPMJJBYUtil {
	
	public ClaimsPMJJBYDropDownPO getDropDownList(){
		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYUtil", "getDropDownList", " Method Start ");
		
		List reasonList=new ArrayList();
		reasonList.add("Accident");
		reasonList.add("ASTHMA");
		reasonList.add("Burns");
		reasonList.add("Cancer");
		reasonList.add("Cardiac Arrest");
		reasonList.add("Carcinoma Oesophagus");
		reasonList.add("High Fever");
		reasonList.add("Illness");
		reasonList.add("NATURAL DEATH");
		reasonList.add("Renal Failure");
		reasonList.add("Suicide");
		
		List typeOfPaymentList=new ArrayList();
		typeOfPaymentList.add("credit");
		typeOfPaymentList.add("cheque");
		
		
		List genderList=new ArrayList();
		genderList.add("male");
		genderList.add("female");
		
		ClaimsPMJJBYDropDownPO claimsPMJJBYDropDownPO=new ClaimsPMJJBYDropDownPO();
		claimsPMJJBYDropDownPO.setGenderList(genderList);
		claimsPMJJBYDropDownPO.setReason(reasonList);
		claimsPMJJBYDropDownPO.setTypeOfPaymentList(typeOfPaymentList);
		
		
		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYUtil", "getDropDownList", " Method End ");
		return claimsPMJJBYDropDownPO;
	}

}
