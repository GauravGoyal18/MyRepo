package com.ipru.groups.validators;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.CoiPO;
import com.ipru.groups.po.ForgotPasswordRequestPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.utilities.SessionKeyConstants;
import com.tcs.logger.FLogger;

public class ForgotPasswordValidator {

	private final String LOGGER_NAME = "ForgotPasswordLogger";
	private final String CLASS_NAME = "ForgotPasswordValidator";
	private String METHOD_NAME = null;
	Properties prop = new Properties();
	
	
	public String validateEmailMobile(ForgotPasswordRequestPO forgotPasswordRequestPO) throws Exception {
		METHOD_NAME = "validateEmailMobile";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		StringBuilder errorMessage = new StringBuilder();

		if (MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES != null) {
			prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
		}
		if (forgotPasswordRequestPO == null) {
			errorMessage.append("Please Enter your registered email id and mobile no.");
		}
		else {

			if (!validateMobileNo(forgotPasswordRequestPO)) {
				errorMessage.append("Please Enter valid Mobile Number");
			}

			if (!validateEmail(forgotPasswordRequestPO.getEmailId())) {
				errorMessage.append("Please Enter valid Email Id");
			}
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return errorMessage.toString();
	}

	public String validateForgotPassword(ForgotPasswordRequestPO forgotPasswordRequestPO, RequestContext context) throws Exception {
		METHOD_NAME = "validateForgotPassword";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		
		StringBuilder errorMessage = new StringBuilder();
		
		if (context != null) {

			ForgotPasswordRequestPO forgotRequestPoFromSession =(ForgotPasswordRequestPO) GroupSecurityUtil.getAttributeFromSession(context, "forgotPasswordRequestPO");

			if (forgotPasswordRequestPO == null) {
				errorMessage.append("Please Enter valid details");
			}
			else {
				if (!(forgotPasswordRequestPO.getNewPassword().equals(forgotPasswordRequestPO.getConfirmPassword()))) {
					FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Old password and new password should not be same");
					errorMessage.append("New Password and confirm password should be same");
				}
				if(forgotRequestPoFromSession != null && forgotPasswordRequestPO != null){
					if((forgotRequestPoFromSession.getMobileNo() != forgotPasswordRequestPO.getMobileNo()) && !(forgotRequestPoFromSession.getEmailId().equalsIgnoreCase(forgotPasswordRequestPO.getEmailId()))){
						FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Contact Details are not matching with verified contact details.");
						errorMessage.append("Contact Details are not matching with verified contact details.");
					} else {
						GroupSecurityUtil.removeAttributeInSession(context, "forgotPasswordRequestPO");
					}
				}
			}
		}
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return errorMessage.toString();
	}

	private boolean validateMobileNo(ForgotPasswordRequestPO forgotPasswordRequestPO) {
		if((forgotPasswordRequestPO.getCountryName().equals(prop.getProperty("INDIA")))||(forgotPasswordRequestPO.getCountryName().equals("")))
		{
		if ((StringUtils.isNotBlank(String.valueOf(forgotPasswordRequestPO.getMobileNo())) && CommonValidationUtil.isMatchedPattern(String.valueOf(forgotPasswordRequestPO.getMobileNo()), GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) || (String.valueOf(forgotPasswordRequestPO.getMobileNo())).equals("-"))) {
			return true;
		}
		}
		if(!(forgotPasswordRequestPO.getCountryName().equals(prop.getProperty("INDIA"))))
		{
			if ((StringUtils.isNotBlank(String.valueOf(forgotPasswordRequestPO.getMobileNo())) && CommonValidationUtil.isMatchedPattern(String.valueOf(forgotPasswordRequestPO.getMobileNo()), GroupFormValidationConstant.NRI_REGEX) || (String.valueOf(forgotPasswordRequestPO.getMobileNo())).equals("-"))) {
			return true;
		}
			else {
				return false;
			
		}
		}
		return false;
	
		
	}

	private boolean validateEmail(String emailId) {
		if ((CommonValidationUtil.isMatchedPattern(emailId, GroupFormValidationConstant.EMAILID_VALIDATION) && StringUtils.isNotBlank(emailId)) || emailId.equals("-")) {
			return true;
		}
		else {
			return false;
		}
	}

}
