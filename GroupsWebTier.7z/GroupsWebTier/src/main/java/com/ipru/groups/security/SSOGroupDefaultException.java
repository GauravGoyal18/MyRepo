package com.ipru.groups.security;

import org.springframework.security.core.AuthenticationException;

public class SSOGroupDefaultException extends AuthenticationException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SSOGroupDefaultException(String authentication) {
		super(authentication);
	}

	public SSOGroupDefaultException(String authentication, Throwable t) {
		super(authentication, t);
	}

	// TODO Auto-generated constructor stub
}
