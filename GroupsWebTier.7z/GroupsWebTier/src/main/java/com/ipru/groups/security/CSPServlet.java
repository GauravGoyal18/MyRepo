package com.ipru.groups.security;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.logger.FLogger;

/**
 * Servlet implementation class CSPServlet
 */
public class CSPServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CSPServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

		       BufferedReader br = new BufferedReader(new  InputStreamReader(request.getInputStream()));
			    String json = "";
			    if(br != null){
				json = br.readLine();
			    }
			     try {	 
			    	 FLogger.info("securityLogger", "CSPServlet", "doPost", "JsonValue :"+json);
			     }
			      catch(Exception e) {  
				    e.printStackTrace();
			      }
			      finally{
				// ////System.out.println("Content Security Policy Report is now in the datafile"); 
			      }
		      }

}
