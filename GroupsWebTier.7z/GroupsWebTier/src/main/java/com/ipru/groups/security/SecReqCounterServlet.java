package com.ipru.groups.security;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ipru.groups.utilities.ContextKeyConstants;

import com.ipru.groups.utilities.GroupConstants;
import com.ipru.security.user.SessReqCounterVO;
import com.tcs.logger.FLogger;
/**
 * Servlet implementation class SecReqCounterServlet
 */
public class SecReqCounterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SecReqCounterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String invSess;
		@SuppressWarnings("unchecked")
		ConcurrentHashMap<String,Object> concurrentSessionMap = (ConcurrentHashMap<String,Object>)request.getSession().getServletContext().getAttribute(ContextKeyConstants.CONCURRENT_SESSION_MAP_CONTEXT);
		HttpSession session = ((HttpServletRequest) request).getSession();
		if(concurrentSessionMap!=null){
		SessReqCounterVO sessCounterVo = (SessReqCounterVO)concurrentSessionMap.get(session.getId());
		if(sessCounterVo!=null){
		AtomicInteger reqCount=sessCounterVo.getRequestCounter();
		////System.out.println("Session : "+session.getId()+" reqCount : "+reqCount);
		FLogger.debug("securityLoggerError", "SecReqCounterServlet", "doGet(HttpServletRequest request, HttpServletResponse response)", "Session : "+session.getId()+" reqCount : "+reqCount);
		//////System.out.println("sessCounterVo.getRequestCounter();"+sessCounterVo.getRequestCounter());
		if(reqCount!=null && reqCount.get()<1){
			
			 invSess=GroupConstants.INVALIDTAE_SESSION;
		}
		else{
			
			invSess=GroupConstants.CONTINUE_SESSION;
		}
		////System.out.println("Session : "+session.getId()+" reqCount : "+reqCount+" invSess : "+invSess);
		FLogger.debug("securityLoggerError", "SecReqCounterServlet", "doGet(HttpServletRequest request, HttpServletResponse response)", "Session : "+session.getId()+" reqCount : "+reqCount+" invSess : "+invSess);
		out.write(invSess);
		}
		}
	
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {}

}
