package com.ipru.groups.servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.ipru.groups.po.TrackerOpenClosePO;
import com.ipru.groups.utilities.TrackerUtil;
import com.tcs.logger.FLogger;

/**
 * Servlet implementation class ExcelDownload
 */

public class ExcelDownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		FLogger.info("TRACKERLogger", "ExcelDownload", "doPost", "method to download xls starts");
		String filePath = null;
		
		try{			
		
		HttpSession session = request.getSession();
		
		if (session != null) {
			TrackerOpenClosePO trackerOpenClosePO = (TrackerOpenClosePO) session.getAttribute("trackerOpenClosePO");
			if(!trackerOpenClosePO.equals(null)){
			String param = null;
			//param=request.getParameter("key");
			JsonParser parser = new JsonParser();
			JsonElement obj1 = parser.parse(request.getReader());
			param = obj1.getAsString();
			TrackerUtil util=new TrackerUtil();
			if(param.equals(null)){
				FLogger.error("TRACKERLogger", "ExcelDownload", "doPost", "param cannot be null");
				throw new ServletException("Not able to download.");
			}
			
			filePath=util.getExcelData(trackerOpenClosePO,param);
			if(filePath.equals(null)){
				FLogger.error("TRACKERLogger", "ExcelDownload", "doPost", "filePath cannot be null");
				throw new ServletException("filePath cannot be null");
			}
			}else{
				FLogger.error("TRACKERLogger", "ExcelDownload", "doPost", "trackerOpenClosePO cannot be null");
				throw new ServletException("trackerOpenClosePO cannot be null");
			}
		}
		else {
			FLogger.error("TRACKERLogger", "ExcelDownload", "doPost", "session cannot be null");
			throw new ServletException("session cannot be null");
		}

		File file = new File(filePath);
		String fileName = file.getName();
		if (fileName == null || fileName.equals("")) {
			FLogger.error("TRACKERLogger", "ExcelDownload", "doPost", "File Name can't be null or empty.");
			throw new ServletException("File Name can't be null or empty");
		}
		if (!file.exists()) {
			FLogger.error("TRACKERLogger", "ExcelDownload", "doPost", "File doesn't exists on server.");
			throw new ServletException("File doesn't exists on server.");
		}

		ServletContext ctx = getServletContext();
		InputStream fis = new FileInputStream(file);
		String mimeType = ctx.getMimeType(file.getAbsolutePath());
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		ServletOutputStream objServletOutputStream = null;
		byte[] bufferData = new byte[65536];
		int read = 0;
		while ((read = fis.read(bufferData)) != -1) {
			output.write(bufferData, 0, read);
		}

		fis.close();
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
		response.setContentType(mimeType != null? mimeType:"vnd.ms-excel");
		output.flush();
		response.setContentLength(output.size());
		objServletOutputStream = response.getOutputStream();
		output.writeTo(objServletOutputStream);
		objServletOutputStream.flush();
		System.out.println("File downloaded at client successfully");
		FLogger.info("TRACKERLogger", "ExcelDownload", "doPost", "method to download xls end");

	}catch(Exception e){
		e.printStackTrace();		
	}
	}
}
