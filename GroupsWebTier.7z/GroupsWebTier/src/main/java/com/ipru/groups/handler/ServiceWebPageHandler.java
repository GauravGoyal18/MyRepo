package com.ipru.groups.handler;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.reflect.TypeToken;
import com.ipru.IPruException;
import com.ipru.groups.po.ServiceWebPageMenuListPO;
import com.ipru.groups.po.ServiceWebPageMenuPO;
import com.ipru.groups.po.ServiceWebPageRequestPO;
import com.ipru.groups.po.ServiceWebPageSubmitRequestPO;
import com.ipru.groups.po.ServiceWebPageTransPO;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.utilities.CommonFileUploadUtil;
import com.ipru.groups.validators.ServiceWebPageValidator;
import com.ipru.groups.vo.ServiceWebPageMenuVO;
import com.ipru.groups.vo.ServiceWebPageRequestVO;
import com.ipru.groups.vo.ServiceWebPageSubmitRequestVO;
import com.ipru.groups.vo.ServiceWebPageTransVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ServiceWebPageHandler extends IneoBaseHandler {

	private static final long serialVersionUID = 1L;

	@MethodPost
	public Event getBizRequestForLoadServiceWebPageMenu(RequestContext context) throws Exception {
		FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "Method start");

		try {
			if (context != null) { // context htao
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				
				String selectedOption = null;
				
				selectedOption = (String) context.getFlowScope().get("selectedOption");
				
				////System.out.println("*****************  selectedMenu : "+selectedOption);

				IPruUser userVo = null;
				String policyNo = null;
				String role = null;
				String productCategory = null;
				String memberType = null;

				if (httpSession != null) {  // session b har baar milega
					userVo = (IPruUser) httpSession.getAttribute("userVO");
					////System.out.println("UserVo in session : " + userVo);

					if (userVo != null) {  // userVO b nahi null hoga
						policyNo = userVo.getPolicyNo();
						FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "Policy No in session : " + policyNo);

						role = userVo.getRoles();
						FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "role in session : " + role);
						
						productCategory = userVo.getProductType();
						FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "productType in session : " + productCategory);
						
						memberType = userVo.getRoleType();
						FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "memberType in session : " + memberType);

						ServiceWebPageRequestPO serviceWebPageRequestPO = new ServiceWebPageRequestPO();
						serviceWebPageRequestPO.setPolicyNo(policyNo);
						serviceWebPageRequestPO.setRole(role);
						serviceWebPageRequestPO.setProductCategory(productCategory);
						serviceWebPageRequestPO.setMemberType(memberType);
						serviceWebPageRequestPO.setSelectedOption(selectedOption);

						ServiceWebPageRequestVO serviceWebPageRequestVO = dozerBeanMapper.map(serviceWebPageRequestPO, ServiceWebPageRequestVO.class);

						if (serviceWebPageRequestVO != null) {

							Object[] paramArray = new Object[1];
							paramArray[0] = serviceWebPageRequestVO;

							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("loadMenuBizReq", obj_bizReq);

						}
						else {
							FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "Policy Number is null");
							throw new IPruException("Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "UserVo from session is null");
						throw new IPruException("Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "Session is null");
					throw new IPruException("Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}

		FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "Method end.");

		return success();
	}

	@SuppressWarnings("unchecked")
	@MethodPost
	public Event getBizResponseForLoadServiceWebPageMenu(RequestContext context) throws Exception {

		FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "Method start");

		List<ServiceWebPageMenuVO> menuVOList = null;
		List<ServiceWebPageMenuPO> menuPOList = new ArrayList<ServiceWebPageMenuPO>();
		long functionalityId = getFunctionalityId(context);

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		IPruUser userVo = new IPruUser();
		String policyNo = null;

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				if (httpSession != null) {
					userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {
						policyNo = userVo.getPolicyNo();

						bizRes = (BizResponse) context.getFlowScope().get("bizResForLoadServiceWebPageMenu");
						if (bizRes != null) {
							responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
							}
							else {
								menuVOList = (List<ServiceWebPageMenuVO>) bizRes.getTransferObjects().get("response1");

								HashMap<String, ServiceWebPageMenuVO> menuMap = new HashMap<String, ServiceWebPageMenuVO>();

								for (ServiceWebPageMenuVO serviceWebPageMenuVO : menuVOList) {
									if (serviceWebPageMenuVO != null) {
										menuMap.put(String.valueOf(serviceWebPageMenuVO.getRequestMenuID()), serviceWebPageMenuVO);
										ServiceWebPageMenuPO serviceWebPageMenuPO = dozerBeanMapper.map(serviceWebPageMenuVO, ServiceWebPageMenuPO.class);

										menuPOList.add(serviceWebPageMenuPO);
									}
								}

								String menuMapVOString = gsonJSON.toJson(menuMap);
								context.getFlowScope().put("menuMapVOString", menuMapVOString);

								ServiceWebPageMenuListPO menuListPO = new ServiceWebPageMenuListPO();
								menuListPO.setMenuList(menuPOList);
								menuListPO.setPolicyNo(policyNo);
								menuListPO.setFunctionalityId(functionalityId);

								String menuListJsonString = gsonJSON.toJson(menuListPO, ServiceWebPageMenuListPO.class);

								context.getFlowScope().put("Response", menuListJsonString);
							}
						}
						else {
							FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "bizRes should not be null");
							throw new IPruException("Something went wrong. Please try again later.");
						}

					}
					else {
						FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "UserVo from session is null");
						throw new IPruException("Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "Session is null");
					throw new IPruException("Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "Exception came ", e);
			throwINeoFlowException(e, "GRYY02", context);
		}

		FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "Method end");

		return success();
	}

	@MethodPost
	public Event getBizRequestForServiceWebPageSubmit(RequestContext context) throws Exception {
		FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "Method start ");
		CommonFileUploadUtil commonFileUploadUtil=new CommonFileUploadUtil();
		String clientId = null;
		String policyNo = null;
		String menuMapVOString = null;
		String role= null;
		String screenName = null;
		HashMap<String, ServiceWebPageMenuVO> menuMap = null;
		long functionalityId = this.getFunctionalityId(context);

		try {
			if (context != null) {

				menuMapVOString = (String) context.getFlowScope().get("menuMapVOString");

				Type t = new TypeToken<HashMap<String, ServiceWebPageMenuVO>>() {
				}.getType();

				menuMap = gsonJSON.fromJson(menuMapVOString, t);

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				
				screenName = (String) context.getFlowScope().get("screenName");

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {
						clientId = userVo.getClientId();
						policyNo = userVo.getPolicyNo();
						role = userVo.getRoles();
						
						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
						if (request != null) {
							ServiceWebPageSubmitRequestPO serviceWebPageSubmitRequestPO = gsonJSON.fromJson(request.getReader(), ServiceWebPageSubmitRequestPO.class);
							/*
							 * System.out
							 * .println("serviceWebPageSubmitRequestPO : " +
							 * serviceWebPageSubmitRequestPO);
							 */

							ServiceWebPageValidator serviceWebPageValidator = new ServiceWebPageValidator();

							String validation = serviceWebPageValidator.validateServiceWebPageSubmitRequestPO(context, serviceWebPageSubmitRequestPO); // pass
																																						// context
							List<UploadFilePO> uploadFilePOList=(List<UploadFilePO>)serviceWebPageSubmitRequestPO.getUploadFileList();	
							
							if(CollectionUtils.isEmpty(uploadFilePOList)){
								
							}else {
							
								String checkFileUploadStatus=commonFileUploadUtil.checkUploadFileContent(uploadFilePOList, context,"ServiceWebPageLogger");
								if(!StringUtils.isEmpty(checkFileUploadStatus))
								{
									throw new IPruException("Error", "GRPSWP01", checkFileUploadStatus);
								}
							}
							// -
																																						// done
							/*ssss
							 * ////System.out.println(">>>>>>>>>>   validation >>>>"
							 * + validation);
							 */// length validations - done

							if (StringUtils.isNotBlank(validation)) {
								FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestForServiceWebPageSubmit", "Validation errors : "+validation);
								this.setValidationErrorMessages(validation);
								throw new IPruException("Error", "GRPSWP01", validation); 
							}

							if (serviceWebPageSubmitRequestPO != null) {
								serviceWebPageSubmitRequestPO.setClientId(clientId);

								// In PO not everything

								ServiceWebPageMenuPO menuPO = serviceWebPageSubmitRequestPO.getSelectedMenu();
								ServiceWebPageMenuVO menuVO = null;
								if (menuPO != null) {
									long menuId = menuPO.getRequestMenuID();

									Iterator it = menuMap.entrySet().iterator();
									while (it.hasNext()) {
										Map.Entry pair = (Map.Entry) it.next();
										//System.out.println(pair.getKey() + " = " + pair.getValue());
										ServiceWebPageMenuVO value = (ServiceWebPageMenuVO) pair.getValue();
										if (value.getRequestMenuID().equals(menuId)) {
											menuVO = value;
										}
									}

								}

								ServiceWebPageSubmitRequestVO serviceWebPageSubmitRequestVO = dozerBeanMapper.map(serviceWebPageSubmitRequestPO, ServiceWebPageSubmitRequestVO.class);
								serviceWebPageSubmitRequestVO.setSelectedMenu(menuVO);
								serviceWebPageSubmitRequestVO.setScreenName(screenName);
								serviceWebPageSubmitRequestVO.setFunctionalityId(functionalityId);

								Object[] paramArray = new Object[1];
								paramArray[0] = serviceWebPageSubmitRequestVO;

								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);

								context.getFlowScope().put("serviceWebPageSubmitBizReq", obj_bizReq);

							}
							else {
								FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestForServiceWebPageSubmit", "serviceWebPageSubmitRequestPO from request should not be null");
								throw new IPruException("Something went wrong. Please try again later.");
							}
						}
						else {
							FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestForServiceWebPageSubmit", "Http Request should not be null");
							throw new IPruException("Something went wrong. Please try again later.");
						}

					}
					else {
						FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestForServiceWebPageSubmit", "UserVO in session should not be null");
						throw new IPruException("Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestForServiceWebPageSubmit", "Session should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestForServiceWebPageSubmit", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizRequestForServiceWebPageSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}

		FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizRequestforLoadServiceWebPage", "Method end ");
		return success();
	}

	@MethodPost
	public Event getBizResponseForServiceWebPageSubmit(RequestContext context) throws Exception {

		FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "Method start");
		ServiceWebPageTransVO serviceWebPageTransVO = new ServiceWebPageTransVO();
		ServiceWebPageTransPO serviceWebPageTransPO = new ServiceWebPageTransPO();

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForServiceWebPageSubmit");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {
						serviceWebPageTransVO = (ServiceWebPageTransVO) bizRes.getTransferObjects().get("response1");

						if (serviceWebPageTransVO != null) {
							dozerBeanMapper.map(serviceWebPageTransVO, serviceWebPageTransPO);
						}

						String callJsonString = gsonJSON.toJson(serviceWebPageTransPO, ServiceWebPageTransPO.class);
						FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "callJsonString::" + callJsonString);
						context.getFlowScope().put("Response", callJsonString);
					}
				}
				else {
					FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ServiceWebPageError", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "Exception came ", e);
			throwINeoFlowException(e, "GRYY02", context);
		}

		FLogger.info("ServiceWebPageLogger", "ServiceWebPageHandler", "getBizResponseForLoadServiceWebPageMenu", "Method end");

		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
