package com.ipru.groups.servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

import com.ipru.groups.pdfgen.TemplateCoreServiceImpl;
import com.ipru.groups.utilities.GroupCommonUtils;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.vo.PmjjbyVO;
import com.tcs.logger.FLogger;
import com.tcs.pdfgenerator.core.service.ITemplateCoreService;
import com.tcs.pdfgenerator.exception.PDFGeneratorException;
import com.tcs.pdfgenerator.service.FTL2PDFGenerator;
import com.tcs.pdfgenerator.util.PDFGeneratorUtils;

/**
 * Servlet implementation class ExcelDownload
 */

public class PmjjbyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		FLogger.info("PmjjbyLogger", "PmjjbyServlet", "doPost", "method to Download pdf starts");
		String filePath = null;

		HttpSession session = request.getSession();
		List<PmjjbyVO> pmjjbyVOList = new ArrayList<PmjjbyVO>();

		try {

			if (session == null) {
				FLogger.info("PmjjbyLogger", "PmjjbyServlet", "doPost", "session is null");
				throw new ServletException("session is null");
			}

			String pmjjbyFtlPath = "Pmjjby.ftl";
			long TimeStamp = new Date().getTime();
			ITemplateCoreService service = new TemplateCoreServiceImpl();
			String destination = GroupCommonUtils.createDirWithTodaysDate(GroupConstants.CONSTANT_DOCUMENT_UPLOAD_PATH);

			if (destination == null) {
				FLogger.info("PmjjbyLogger", "PmjjbyServlet", "doPost", "destination is null");
				throw new ServletException("Null data found");
			}

			// String fileUploadPath = destination + "/pmjjby_" + TimeStamp +
			// ".pdf";

			PmjjbyVO pmjjbyVO = (PmjjbyVO) session.getAttribute("pmjjbyVO");

			if (pmjjbyVO.getPolicyNo().isEmpty()) {
				pmjjbyVO.setPolicyNo("-");
			}
			if (pmjjbyVO.getRenewalNo().isEmpty()) {
				pmjjbyVO.setRenewalNo("-");
			}
			if (pmjjbyVO.getMasterPolicyNo().isEmpty()) {
				pmjjbyVO.setMasterPolicyNo("-");
			}
			if (pmjjbyVO.getSubPolicyNo().isEmpty()) {
				pmjjbyVO.setSubPolicyNo("-");
			}
			if (pmjjbyVO.getProposer().isEmpty()) {
				pmjjbyVO.setProposer("-");
			}
			if (pmjjbyVO.getNameOfAssured().isEmpty()) {
				pmjjbyVO.setNameOfAssured("-");
			}
			if (pmjjbyVO.getAgeOfAssured().isEmpty()) {
				pmjjbyVO.setAgeOfAssured("-");
			}
			if (pmjjbyVO.getDobOfAssured().isEmpty()) {
				pmjjbyVO.setDobOfAssured("-");
			}
			if (pmjjbyVO.getAgeOfLifeAssured().isEmpty()) {
				pmjjbyVO.setAgeOfLifeAssured("-");
			}
			if (pmjjbyVO.getMemberIdNo().isEmpty()) {
				pmjjbyVO.setMemberIdNo("-");
			}
			if (pmjjbyVO.getDateOfCOC().isEmpty()) {
				pmjjbyVO.setDateOfCOC("-");
			}
			if (pmjjbyVO.getSumAssured().isEmpty()) {
				pmjjbyVO.setSumAssured("-");
			}
			if (pmjjbyVO.getPremium().isEmpty()) {
				pmjjbyVO.setPremium("-");
			}
			if (pmjjbyVO.getUinNo().isEmpty()) {
				pmjjbyVO.setUinNo("-");
			}
			if (pmjjbyVO.getSignedOnDate().isEmpty()) {
				pmjjbyVO.setSignedOnDate("-");
			}
			if (pmjjbyVO.getProductCode().isEmpty()) {
				pmjjbyVO.setProductCode("-");
			}
			if (pmjjbyVO.getPolicyIsSuredDate().isEmpty()) {
				pmjjbyVO.setPolicyIsSuredDate("-");
			}
			if (pmjjbyVO.getSchemeName().isEmpty()) {
				pmjjbyVO.setSchemeName("-");
			}
			if (pmjjbyVO.getAddress().isEmpty()) {
				pmjjbyVO.setAddress("-");
			}
			if (pmjjbyVO.getTerminateDate().isEmpty()) {
				pmjjbyVO.setTerminateDate("-");
			}
			if (pmjjbyVO.getAnnualrenDate().isEmpty()) {
				pmjjbyVO.setAnnualrenDate("-");
			}
			if (pmjjbyVO.getPremiumMode().isEmpty()) {
				pmjjbyVO.setPremiumMode("-");
			}
			if (pmjjbyVO.getApplicationDT().isEmpty()) {
				pmjjbyVO.setApplicationDT("-");
			}
			if (pmjjbyVO.getFolioNo().isEmpty()) {
				pmjjbyVO.setFolioNo("-");
			}
			if (pmjjbyVO.getPanNo().isEmpty()) {
				pmjjbyVO.setPanNo("-");
			}
			if (pmjjbyVO.getEmailId().isEmpty()) {
				pmjjbyVO.setEmailId("-");
			}
			if (pmjjbyVO.getPmjjbyUId().isEmpty()) {
				pmjjbyVO.setPmjjbyUId("-");
			}
			if (pmjjbyVO.getNominee().isEmpty()) {
				pmjjbyVO.setNominee("-");
			}
			if (pmjjbyVO.getMumbaiOnDt().isEmpty()) {
				pmjjbyVO.setMumbaiOnDt("-");
			}
			if (pmjjbyVO.getBankAccNo().isEmpty()) {
				pmjjbyVO.setBankAccNo("-");
			}
			if (pmjjbyVO.getTrantype().isEmpty()) {
				pmjjbyVO.setTrantype("-");
			}
			if (StringUtils.isEmpty(pmjjbyVO.getNomineeAge())) {
				pmjjbyVO.setNomineeAge("-");
			}
			if(StringUtils.isEmpty(pmjjbyVO.getNomineeRelation())){
				pmjjbyVO.setNomineeRelation("-");
			}
			if(StringUtils.isEmpty(pmjjbyVO.getAppointeeName()))
			{
				pmjjbyVO.setAppointeeName("-");
			}
 
			byte[] bufferData = FTL2PDFGenerator.getPDFGeneratorInstance.generatePDFTemplate(PDFGeneratorUtils.createTemplateBean(pmjjbyFtlPath, pmjjbyVO), service);

			// File file=new File(fileUploadPath);
			// if(!file.exists())
			// {
			// FLogger.info("PmjjbyLogger", "PmjjbyServlet", "doPost",
			// "File does not exist");
			// throw new ServletException("File does not exist");
			// }

			// InputStream fis = new FileInputStream(file);
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			ServletOutputStream objServletOutputStream = null;
			// byte[] bufferData = new byte[65536];
			// int read=0;
			// while((read = fis.read(bufferData))!= -1){
			// output.write(bufferData, 0, read);
			// }

			// fis.close();
			output.write(bufferData);
			response.addHeader("Content-Disposition", "attachment; filename=\"" + "pmjjby.pdf" + "\"");
			response.setContentType("application/pdf");
			output.flush();
			response.setContentLength(output.size());
			objServletOutputStream = response.getOutputStream();
			output.writeTo(objServletOutputStream);
			objServletOutputStream.flush();

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			session.removeAttribute("pmjjbyPOList");

		}
		FLogger.info("PmjjbyLogger", "PmjjbyServlet", "doPost", "method to Download pdf end");
	}
}
