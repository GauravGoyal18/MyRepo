package com.ipru.groups.validators;

import com.ipru.IPruException;
import com.ipru.groups.po.ChangePasswordPO;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public class ChangePasswordValidator {

	public String validatePassword(ChangePasswordPO changePasswordPO,IPruUser userVO) throws IPruException{
		FLogger.info("ChangePasswordLogger", "ChangePasswordValidator", "validatePassword", "Method Start");
		
		if(changePasswordPO != null && userVO != null){
			
			if(!changePasswordPO.getOldPassword().equals(userVO.getPassword())){				
				FLogger.error("ChangePasswordLogger", "ChangePasswordValidator", "validatePassword", "Incorrect old Password");
				throw new IPruException("Error", "GRPPFCC", "Entered old password is incorrect");
			}
			if(changePasswordPO.getOldPassword().equals(changePasswordPO.getNewPassword())){
				FLogger.error("ChangePasswordLogger", "ChangePasswordValidator", "validatePassword", "Old password and new password should not be same");
				throw new IPruException("Error", "GRPPFCC", "Old password and new password should not be same");
			}
			if(!changePasswordPO.getNewPassword().equals(changePasswordPO.getConfirmPassword())){
				FLogger.error("ChangePasswordLogger", "ChangePasswordValidator", "validatePassword", "Old password and new password should not be same");
				throw new IPruException("Error", "GRPPFCC", "New Password and confirm password should be same");
			}				
		}else{
			FLogger.error("ChangePasswordLogger", "ChangePasswordValidator", "validatePassword", "Blank Data");
			throw new IPruException("Error", "GRPPFCC", "No data found");
		}

		FLogger.info("ChangePasswordLogger", "ChangePasswordValidator", "validatePassword", "Method End");
		return null;
	}
	
}
