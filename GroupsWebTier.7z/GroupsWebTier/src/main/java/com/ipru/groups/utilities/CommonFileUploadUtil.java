package com.ipru.groups.utilities;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.generic.po.FileUploadResultPo;
import com.ipru.groups.po.UploadFilePO;
import com.tcs.logger.FLogger;

public class CommonFileUploadUtil {
	StringBuilder errorMessageBuilder = new StringBuilder(1);
	
	String errorMsg="Some thing went wrong please try again!";
	
	public String checkUploadFileContent(List<UploadFilePO> uploadFilePOList,RequestContext p_ObjContext,String loggerName)throws Exception
	{
		if(CollectionUtils.isEmpty(uploadFilePOList))
		{
			return errorMessageBuilder.append(errorMsg).toString();
		}
		
		FLogger.info(loggerName, "CommonFileUploadUtil", "checkUploadFileContent", "checkUploadFileContent Start");
		HttpSession httpSession = ((HttpServletRequest) ((RequestContext) p_ObjContext).getExternalContext().getNativeRequest()).getSession();
	
		Map<String,FileUploadResultPo> fileUploadResultMap=(Map<String,FileUploadResultPo>)httpSession.getAttribute("fileUploadResultMap");
		
		FLogger.info(loggerName, "CommonFileUploadUtil", "checkUploadFileContent", "fileUploadResultMap End");
		if(fileUploadResultMap.isEmpty())
		{
			FLogger.info(loggerName, "CommonFileUploadUtil", "checkUploadFileContent", "fileUploadResultMap empty");
			return errorMessageBuilder.append(errorMsg).toString();
		}
		
		for(UploadFilePO uploadFilePO:uploadFilePOList)
		{
			FileUploadResultPo fileUploadResultPo=null;
			if(StringUtils.isEmpty(uploadFilePO.getDocName()))
			{
				FLogger.info(loggerName, "CommonFileUploadUtil", "checkUploadFileContent", "uploadFilePO.getDocName() found null");
				return errorMessageBuilder.append("Document Name Should not be null").toString();
			}
			else
			{
				fileUploadResultPo=(FileUploadResultPo)fileUploadResultMap.get(uploadFilePO.getDocumentName());
				if(fileUploadResultPo!=null && uploadFilePO!=null)
				{
					if(fileUploadResultPo.getDocumentName().equals(uploadFilePO.getDocumentName())){
						errorMessageBuilder=checkFileContent(fileUploadResultPo,uploadFilePO,loggerName);
					}
					else
					{
						FLogger.info(loggerName, "CommonFileUploadUtil", "checkUploadFileContent", "uploadFilePO.getDocumentName() found match");
						errorMessageBuilder.append("Enter document not valid:-"+uploadFilePO.getDocumentName()+"  ");
					}
				}
				
			}
			
			
		}
		
		
		httpSession.removeAttribute("fileUploadResultMap");
		FLogger.info(loggerName, "CommonFileUploadUtil", "checkUploadFileContent", "checkUploadFileContent End");
		return errorMessageBuilder.toString();
	}
	
	
	
	
	private StringBuilder checkFileContent(FileUploadResultPo fileUploadResultPo,UploadFilePO uploadFilePO,String loggerName)throws Exception
	{
		
		FLogger.info(loggerName, "CommonFileUploadUtil", "checkFileContent", "checkFileContent start");
		
		if(checkFileUploadValidation(fileUploadResultPo.getPolicyNo(),uploadFilePO.getPolicyNo()))
		{
			
			errorMessageBuilder.append("policyNumber not valid :-"+uploadFilePO.getDocumentName());
		}
		
		if(checkFileUploadValidation(fileUploadResultPo.getClientId(),uploadFilePO.getClientId()))
		{
			errorMessageBuilder.append("Client Id not valid :-"+uploadFilePO.getDocumentName());
		}
		
		if(checkFileUploadValidation(fileUploadResultPo.getDocFileType(),uploadFilePO.getDocFileType()))
		{
			errorMessageBuilder.append("Doc Type not valid :-"+uploadFilePO.getDocumentName());
		}
		
		if(checkFileUploadValidation(fileUploadResultPo.getFunctionality(),uploadFilePO.getFunctionality()))
		{
			errorMessageBuilder.append(" some thing went wrong :-"+uploadFilePO.getDocumentName());
		}
		
		if(checkFileUploadValidation(fileUploadResultPo.getContentType(),uploadFilePO.getContentType()))
		{
			errorMessageBuilder.append(" Content type not Valid :-"+uploadFilePO.getDocumentName());
		}
		if(checkFileUploadValidation(fileUploadResultPo.getRole(),uploadFilePO.getRole()))
		{
			errorMessageBuilder.append(" Role not Valid :-"+uploadFilePO.getDocumentName());
		}
	

		FLogger.info(loggerName, "CommonFileUploadUtil", "checkFileContent", "checkFileContent end"+errorMessageBuilder);
		return errorMessageBuilder;
	}
	
	
	private boolean checkFileUploadValidation(String fromBackEnd,String fromFrontEnd)throws Exception
	{
		boolean status=true;
		if(fromBackEnd.equals(fromFrontEnd))
		{
			return false;
		}
		return status;
	}

}
