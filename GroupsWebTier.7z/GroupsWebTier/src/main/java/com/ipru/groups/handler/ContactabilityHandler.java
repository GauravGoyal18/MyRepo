package com.ipru.groups.handler;

import javacryption.aes.AesCtr;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.ContactabilityRequestPO;
import com.ipru.groups.utilities.EncryptionUtil;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.SessionKeyConstants;
import com.ipru.groups.validators.DashboardEmailMobileValidator;
import com.ipru.groups.vo.ContactabilityRequestVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ContactabilityHandler extends IneoBaseHandler {
	
	private static final long serialVersionUID = 1L;
	private final String LOGGER_NAME = "ContactabilityLogger";
	private final String CLASS_NAME = "ContactabilityHandler";
	private String METHOD_NAME = null;

	@MethodPost
	public Event getBizRequestForEmailMobileSubmit(RequestContext context) throws Exception {
		METHOD_NAME = "getBizRequestForEmailMobileSubmit";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		String memberType = null;
		String firstName = null;
		String lastName = null;
		
		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
					////System.out.println("userVo : " + userVo);

					if (userVo != null) {
						memberType = userVo.getRoleType();
						firstName = userVo.getFirstName();
						lastName = userVo.getLastName();
						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
						if (request != null) {
							ContactabilityRequestPO contactabilityRequestPO = gsonJSON.fromJson(request.getReader(), ContactabilityRequestPO.class);

							DashboardEmailMobileValidator dashboardEmailMobileValidator = new DashboardEmailMobileValidator();

							String validation = dashboardEmailMobileValidator.validateEmailMobileRequestPO(context, contactabilityRequestPO);

							if (StringUtils.isNotBlank(validation)) {
								FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Validation errors : " + validation);
								this.setValidationErrorMessages(validation);
								throwINeoFlowException(new ServiceException("GRPPFCC"), context);
							}
							
							GroupSecurityUtil.setAttributeInSession(context, "contactabilityRequestPO", contactabilityRequestPO);
							
							if (contactabilityRequestPO != null) {
								
								String encProperty = contactabilityRequestPO.getProperty();
								if(encProperty != null){
									String key = (String) httpSession.getAttribute("jCryptionKey");
									encProperty=encProperty.replaceAll(" ","+");
									String decProperty = AesCtr.decrypt(encProperty, key, 256);
									
									// Encrypt the property with SHA-256 algorithm to store in DB
									contactabilityRequestPO.setProperty(EncryptionUtil.encryptSHA256(decProperty,"UTF-8"));
									
									context.getFlowScope().put("contactabilityRequestPO", contactabilityRequestPO);
									
									FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "property:"+decProperty); // Need to be removed.
								}
								
								ContactabilityRequestVO contactabilityRequestVO = dozerBeanMapper.map(contactabilityRequestPO, ContactabilityRequestVO.class);
								contactabilityRequestVO.setMemberType(memberType);
								contactabilityRequestVO.setFirstName(firstName);
								contactabilityRequestVO.setLastName(lastName);

								Object[] paramArray = new Object[1];
								paramArray[0] = contactabilityRequestVO;

								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);

								context.getFlowScope().put("bizReq", obj_bizReq);
							}							
							else {
								FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "contactabilityRequestPO from request should not be null");
								throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
							}
						}
						else {
							FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Http Request should not be null");
							throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UserVO in session should not be null");
						throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "session should not be null");
					throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPCU01", context);
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return success();
	}
	
	@MethodPost
	public Event getBizResponseForEmailMobileSubmit(RequestContext context) throws Exception {
		METHOD_NAME = "getBizResponseForEmailMobileSubmit";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						bizRes = (BizResponse) context.getFlowScope().get("bizRes");

						if (bizRes != null) {
							responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
							}
							else {
								String isEmailMobileExistString = (String) bizRes.getTransferObjects().get("response1");

								if (StringUtils.isBlank(isEmailMobileExistString)){
									FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "isEmailMobileExistString is blank.");
									throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
								} else if(StringUtils.startsWith(isEmailMobileExistString, "ERROR")){
									FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, isEmailMobileExistString);
									throw new IPruException("Error","GRPCU01",isEmailMobileExistString);									
								}else {
									ContactabilityRequestPO contactabilityRequestPO = (ContactabilityRequestPO) context.getFlowScope().get("contactabilityRequestPO");
									
									if (contactabilityRequestPO != null) {
										
										String emailId = contactabilityRequestPO.getEmailId();
										String mobileNo = contactabilityRequestPO.getMobileNo();

										userVo.setEmailId(emailId);
										userVo.setMobileNo(String.valueOf(mobileNo));

										GroupSecurityUtil.setAttributeInSession(context, "userVO", userVo);

										IPruUser userVo1 = (IPruUser) httpSession.getAttribute("userVO");

										////System.out.println("userVo1 : " + userVo1);
										context.getFlowScope().put("Response", "Success");
									}
									else{
										FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "contactabilityRequestPO from context is null");
										throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
									}									
								}
							}
						} else {
							FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
							throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
						}
					} else {
						FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UserVO in session should not be null");
						throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
					}
				} else {
					FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "session should not be null");
					throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
				}
			} else {
				FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPCU01", context);
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}
	
	@MethodPost
	public Event getBizRequestForEmailMobileSave(RequestContext context) throws Exception {
		METHOD_NAME = "getBizRequestForEmailMobileSave";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		String memberType = null;
		String webClientId = null;
		String clientId = null;
		Boolean isOTPValidated = false;
		String firstName = null;
		String lastName = null;

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					// Check whether OTP is verified or not.
					isOTPValidated = (Boolean) GroupSecurityUtil.getAttributeFromSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);
					
					if(!isOTPValidated){
						throwINeoFlowException(new ServiceException("PFPAY31"), context);
					}
					
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
					if (userVo != null) {
						memberType = userVo.getRoleType();
						webClientId = userVo.getWebClientId();
						clientId = userVo.getClientId();
						firstName = userVo.getFirstName();
						lastName = userVo.getLastName();

						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
						if (request != null) {
							ContactabilityRequestPO contactabilityRequestPO = gsonJSON.fromJson(request.getReader(), ContactabilityRequestPO.class);

							DashboardEmailMobileValidator dashboardEmailMobileValidator = new DashboardEmailMobileValidator();

							String validation = dashboardEmailMobileValidator.validateEmailMobileRequestPO(context, contactabilityRequestPO);

							if (StringUtils.isNotBlank(validation)) {
								FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Validation errors : " + validation);
								this.setValidationErrorMessages(validation);
								throwINeoFlowException(new ServiceException("GRPPFCC"), context);
							}

							if (contactabilityRequestPO != null) {
								
								String encProperty = contactabilityRequestPO.getProperty();
								if(encProperty != null){
									String key = (String) httpSession.getAttribute("jCryptionKey");
									encProperty=encProperty.replaceAll(" ","+");
									String decProperty = AesCtr.decrypt(encProperty, key, 256);
									
									// Encrypt the property with SHA-256 algorithm to store in DB
									contactabilityRequestPO.setProperty(EncryptionUtil.encryptSHA256(decProperty,"UTF-8"));
									
									FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "property:"+decProperty); // Need to be removed.
								}
								
								ContactabilityRequestVO contactabilityRequestVO = dozerBeanMapper.map(contactabilityRequestPO, ContactabilityRequestVO.class);
								contactabilityRequestVO.setWebClientId(webClientId);
								contactabilityRequestVO.setMemberType(memberType);
								contactabilityRequestVO.setClientId(clientId);
								contactabilityRequestVO.setFirstName(firstName);
								contactabilityRequestVO.setLastName(lastName);

								Object[] paramArray = new Object[1];
								paramArray[0] = contactabilityRequestVO;

								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);

								context.getFlowScope().put("bizReq", obj_bizReq);
							}
							else {
								FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "contactabilityRequestPO from request should not be null");
								throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
							}
						}
						else {
							FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Http Request should not be null");
							throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UserVO in session should not be null");
						throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "session should not be null");
					throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPCU01", context);
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	@MethodPost
	public Event getBizResponseForEmailMobileSave(RequestContext context) throws Exception {
		METHOD_NAME = "getBizResponseForEmailMobileSave";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						bizRes = (BizResponse) context.getFlowScope().get("bizRes");

						if (bizRes != null) {
							responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
							}
							else {
								String isEmailMobileUpdatedString = (String) bizRes.getTransferObjects().get("response1");

								if (StringUtils.isNotBlank(isEmailMobileUpdatedString) && StringUtils.equalsIgnoreCase(isEmailMobileUpdatedString, "true")) {
									userVo.setEmailMobileUpdated(true);
									GroupSecurityUtil.setAttributeInSession(context, "userVO", userVo);
									
									context.getFlowScope().put("Response", "Success");
								} else {
									FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "isEmailMobileUpdatedString is not true.");
									throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
								}
							}
						} else {
							FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
							throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
						}
					} else {
						FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UserVO in session should not be null");
						throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
					}
				} else {
					FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "session should not be null");
					throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
				}
			} else {
				FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPCU01", context);
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}
	
	/*@MethodPost
	public Event getBizRequestForOnLogOut(RequestContext context){
		METHOD_NAME = "getBizRequestForOnLogOut";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		HttpServletRequest request=(HttpServletRequest) context.getExternalContext().getNativeRequest();

		if(httpSession != null){
			httpSession.invalidate();
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		}
		context.getFlowScope().put("Response", "Success");
		return success();
	}*/
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		METHOD_NAME = "setOtpCallBacks";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		paramBean.setFunctionality("CONTACTABILITY");
		setTransactionalOTPCallback(Boolean.TRUE);
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");		
	}

}
