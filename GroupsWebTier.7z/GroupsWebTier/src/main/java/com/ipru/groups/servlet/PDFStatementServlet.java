package com.ipru.groups.servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ipru.groups.pdfgen.TemplateCoreServiceImpl;
import com.ipru.groups.vo.FtlToPdfVO;
import com.tcs.logger.FLogger;
import com.tcs.pdfgenerator.core.service.ITemplateCoreService;
import com.tcs.pdfgenerator.exception.PDFGeneratorException;
import com.tcs.pdfgenerator.service.FTL2PDFGenerator;
import com.tcs.pdfgenerator.util.PDFGeneratorUtils;

public class PDFStatementServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession(false);
	
		FLogger.info("BIDStatementLogger", "BidStatementServlet", "doPost", "Method start");

		
		try {
		
		if(session==null)
		{
			//throw
			
			FLogger.info("BIDStatementLogger", "BidStatementServlet", "doPost", "session is null");
			throw new ServletException("session is null");
		
		}
		FtlToPdfVO ftlToPdf=(FtlToPdfVO)session.getAttribute("statementDownloadData");
		//System.out.println(bidResponseList.toString());
		//createFTLConfigInstance();
		
		//ITemplateCoreService templateCoreService = new TemplateServiceImpl();
		if(ftlToPdf==null)
		{
			//throw
			
			FLogger.info("BIDStatementLogger", "BidStatementServlet", "doPost", "ftlToPdf is null");
			throw new ServletException("Found null data");
		
		}
		
		
		ITemplateCoreService service= new TemplateCoreServiceImpl();
	
	byte[] bufferData=FTL2PDFGenerator.getPDFGeneratorInstance.generatePDFTemplate(PDFGeneratorUtils.createTemplateBean(ftlToPdf.getFtlName(), ftlToPdf.getObjectData()), service);

		 
		   ByteArrayOutputStream output = new ByteArrayOutputStream();
		     ServletOutputStream objServletOutputStream = null; 
		     output.write(bufferData);

	   //   fis.close();
	      response.addHeader("Content-Disposition",  "attachment; filename=\"" + ftlToPdf.getPdfName() + "\"");
	      response.setContentType("application/pdf");
	      output.flush();
	      response.setContentLength(output.size());
	      objServletOutputStream = response.getOutputStream();
	      output.writeTo(objServletOutputStream);
	      objServletOutputStream.flush();
	      
		
		
		
		
		
		
		
			FLogger.info("BIDStatementLogger", "BidStatementServlet", "doPost", "Method end");

		
		
		}
		catch (PDFGeneratorException e) {
			// TODO Auto-generated catch block
			
			FLogger.info("BIDStatementLogger", "BidStatementServlet", "doPost", "Error occured while generating pdf");

			//e.printStackTrace();
			  ServletOutputStream objServletOutputStream = response.getOutputStream();
			  objServletOutputStream.flush();
		}
		catch(Exception e)
		{
			
			FLogger.info("BIDStatementLogger", "BidStatementServlet", "doPost", "Error occured",e);

			//e.printStackTrace();
			  ServletOutputStream objServletOutputStream = response.getOutputStream();
			  objServletOutputStream.flush();

		}
		
		finally
		{
			session.removeAttribute("statementDownloadData");
			
			
		}
		
		
	}
	

}
