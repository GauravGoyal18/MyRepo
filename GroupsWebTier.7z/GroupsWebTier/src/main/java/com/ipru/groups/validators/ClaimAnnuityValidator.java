package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.ipru.IPruException;
import com.ipru.groups.po.ClaimAnnuityBenSubmitPO;
import com.ipru.groups.po.ClaimAnnuityDropDownPO;
import com.ipru.groups.po.ClaimAnnuityOptionPO;
import com.ipru.groups.po.ClaimAnnuitySpousePO;
import com.ipru.groups.po.ClaimAnnuitySubmitPO;
import com.ipru.groups.utilities.ClaimAnnuityUtil;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.tcs.logger.FLogger;

public class ClaimAnnuityValidator {

	public String getVaidateData(ClaimAnnuitySubmitPO claimAnnuitySubmitPO, Map<String, ClaimAnnuityOptionPO> map, String policyNo, String empId) throws IPruException, ParseException {
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Method Start");

		if (claimAnnuitySubmitPO != null) {

			String opt = claimAnnuitySubmitPO.getAnnuityOption();

			ClaimAnnuityOptionPO claimAnnuityOptionPO = map.get(opt);

			if (!claimAnnuityOptionPO.getDownloadShow().equals("Y")) {
				if (!claimAnnuitySubmitPO.getPolicyNo().equals(policyNo)) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Policy Number");
					throw new IPruException("Error", "GRPPFCC", "Invalid Policy Number");
				}
				/*
				 * if (!claimAnnuitySubmitPO.getEmpId().equals(empId)) {
				 * FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator",
				 * "getVaidateData", "Exception Occured, Invalid Employee ID");
				 * throw new IPruException("Error", "GRPPFCC",
				 * "Invalid Employee ID"); }
				 */
				if (!dropDownChk(claimAnnuitySubmitPO.getSalutation())) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Salutation");
					throw new IPruException("Error", "GRPPFCC", "Invalid Salutation");
				}
				if (!validateAlpSpaceField(claimAnnuitySubmitPO.getEmpName(), 50, 1, "Y")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Employee Name");
					throw new IPruException("Error", "GRPPFCC", "Invalid Employee Name");
				}
				if (!validateDate(claimAnnuitySubmitPO.getDob())) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Date of Birth");
					throw new IPruException("Error", "GRPPFCC", "Invalid Date of Birth");
				}
				if (!validateDoubleField(claimAnnuitySubmitPO.getPurchasedPrice())) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Gross Purchase Price");
					throw new IPruException("Error", "GRPPFCC", "Invalid Gross Purchase Price");
				}
				if (!validateLongField(claimAnnuitySubmitPO.getAnnuityCal(), 20, 0, "Y")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Pension payout");
					throw new IPruException("Error", "GRPPFCC", "Invalid Pension payout");
				}
				if (!annuityOptChk(map, claimAnnuitySubmitPO.getAnnuityOption())) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Annuity Option Selected");
					throw new IPruException("Error", "GRPPFCC", "Invalid Annuity Option Selected");
				}
				if (!dropDownChk(claimAnnuitySubmitPO.getFrequency())) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Frequency of pension payout ");
					throw new IPruException("Error", "GRPPFCC", "Invalid Frequency of pension payout ");
				}
				if (!dropDownChk(claimAnnuitySubmitPO.getPaymentMode())) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Payment mode ");
					throw new IPruException("Error", "GRPPFCC", "Invalid Payment mode ");
				}
				if (!validatePanField(claimAnnuitySubmitPO.getPan(), 10)) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Pan Number ");
					throw new IPruException("Error", "GRPPFCC", "Invalid Pan Number");
				}
				if (!dropDownChk(claimAnnuitySubmitPO.getGender())) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Gender");
					throw new IPruException("Error", "GRPPFCC", "Invalid Gender");
				}
				if (!validateAddressField(claimAnnuitySubmitPO.getAddress1(), 200, 1, "Y")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Address 1");
					throw new IPruException("Error", "GRPPFCC", "Invalid Address 1");
				}
				if (!validateAddressField(claimAnnuitySubmitPO.getAddress2(), 200, 1, "Y")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Address 2");
					throw new IPruException("Error", "GRPPFCC", "Invalid Address 2");
				}
				if (!validateAddressField(claimAnnuitySubmitPO.getAddress3(), 200, 1, "Y")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Address 3");
					throw new IPruException("Error", "GRPPFCC", "Invalid Address 3");
				}
				if (!validateAlpSpaceField(claimAnnuitySubmitPO.getState(), 50, 1, "Y")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid State");
					throw new IPruException("Error", "GRPPFCC", "Invalid State");
				}
				if (!validateAlpSpaceField(claimAnnuitySubmitPO.getCity(), 50, 1, "Y")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid City");
					throw new IPruException("Error", "GRPPFCC", "Invalid City");
				}
				if (!validateNumericField(claimAnnuitySubmitPO.getPinCode(), 6, 6, "Y")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Pin Code");
					throw new IPruException("Error", "GRPPFCC", "Invalid Pin Code");
				}
				if (!validateNumericField(claimAnnuitySubmitPO.getLandlineNo(), 12, 0, "N")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Landline nomber");
					throw new IPruException("Error", "GRPPFCC", "Invalid Landline nomber");
				}
				if (!validateMobField(claimAnnuitySubmitPO.getMobNo(), 12, 0, "N")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Mobile nomber");
					throw new IPruException("Error", "GRPPFCC", "Invalid Mobile nomber");
				}
				if (!validateEmailField(claimAnnuitySubmitPO.getEmailId(), 50)) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Email Id");
					throw new IPruException("Error", "GRPPFCC", "Invalid Email Id");
				}
				if (!dropDownChk(claimAnnuitySubmitPO.getMaritalStatus())) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Maritial Status");
					throw new IPruException("Error", "GRPPFCC", "Invalid Maritial Status");
				}
				if (!validateAlpSpaceField(claimAnnuitySubmitPO.getBankName(), 100, 0, "N")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Bank Name");
					throw new IPruException("Error", "GRPPFCC", "Invalid Bank Name");
				}
				if (!validateAddressField(claimAnnuitySubmitPO.getBankAddress(), 200, 0, "N")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Branch Address");
					throw new IPruException("Error", "GRPPFCC", "Invalid Branch Address");
				}
				if (!validateNumericField(claimAnnuitySubmitPO.getAccNo(), 20, 0, "N")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Branch Address");
					throw new IPruException("Error", "GRPPFCC", "Invalid Bank Account Number");
				}
				if (!validateIfscField(claimAnnuitySubmitPO.getIfscCode(), 20)) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid IFSC Code");
					throw new IPruException("Error", "GRPPFCC", "Invalid IFSC Code");
				}
				if (!validateNumericField(claimAnnuitySubmitPO.getMicrCode(), 9, 0, "N")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid MICR Code");
					throw new IPruException("Error", "GRPPFCC", "Invalid MICR Code");
				}
				if (!validateLongField(claimAnnuitySubmitPO.getTds(), 3, 0, "N") || claimAnnuitySubmitPO.getTds() > 100) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid TDS");
					throw new IPruException("Error", "GRPPFCC", "Invalid TDS");
				}
				ClaimAnnuitySpousePO claimAnnuitySpousePO = null;
				claimAnnuitySpousePO = claimAnnuitySubmitPO.getSpouse();
				if (claimAnnuityOptionPO.getIsSpouseVisible().equals("Y")) {
					if (!validateAlpSpaceField(claimAnnuitySpousePO.getName(), 50, 1, "Y")) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Spouse Name");
						throw new IPruException("Error", "GRPPFCC", "Invalid Spouse Name");
					}
					if (!validateDate(claimAnnuitySpousePO.getDateofBirth())) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Spouse Date Of Birth");
						throw new IPruException("Error", "GRPPFCC", "Invalid Spouse Date Of Birth");
					}
					if (!dropDownChk(claimAnnuitySpousePO.getGender())) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Gender");
						throw new IPruException("Error", "GRPPFCC", "Invalid Gender");
					}
					if (!validateAddressField(claimAnnuitySpousePO.getAddress1(), 200, 1, "Y")) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Spouse Address 1");
						throw new IPruException("Error", "GRPPFCC", "Invalid Spouse Address 1");
					}
					if (!validateAddressField(claimAnnuitySpousePO.getAddress2(), 200, 1, "Y")) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Spouse Address 2");
						throw new IPruException("Error", "GRPPFCC", "Invalid Spouse Address 2");
					}
					if (!validateAddressField(claimAnnuitySpousePO.getAddress3(), 200, 1, "Y")) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Spouse Address 3");
						throw new IPruException("Error", "GRPPFCC", "Invalid Spouse Address 3");
					}
					if (!validateAlpSpaceField(claimAnnuitySpousePO.getState(), 50, 1, "Y")) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid State");
						throw new IPruException("Error", "GRPPFCC", "Invalid State");
					}
					if (!validateAlpSpaceField(claimAnnuitySpousePO.getCity(), 50, 1, "Y")) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid City");
						throw new IPruException("Error", "GRPPFCC", "Invalid City");
					}
					if (!validateNumericField(claimAnnuitySpousePO.getPinCode(), 6, 1, "Y")) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Pin Code");
						throw new IPruException("Error", "GRPPFCC", "Invalid Pin Code");
					}
					if (!validateNumericField(claimAnnuitySpousePO.getLandlineNo(), 20, 1, "Y")) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Landline Number");
						throw new IPruException("Error", "GRPPFCC", "Invalid Landline Number");
					}
					if (!validateMobField(claimAnnuitySpousePO.getMobileNo(), 12, 10, "Y")) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Mobile Number");
						throw new IPruException("Error", "GRPPFCC", "Invalid Mobile Number");
					}

				}

				Set<ClaimAnnuityBenSubmitPO> claimAnnuityBenSubmitSet = new HashSet<ClaimAnnuityBenSubmitPO>();
				if (claimAnnuityOptionPO.getIsBeneficiaryVisible().equals("Y")) {
					int i = 1;
					int totalAllocation = 0;
					claimAnnuityBenSubmitSet = claimAnnuitySubmitPO.getBeneficiary();
					for (ClaimAnnuityBenSubmitPO claimAnnuityBenSubmitPO : claimAnnuityBenSubmitSet) {
						if (i <= 10) {

							if (!validateAlpSpaceField(claimAnnuityBenSubmitPO.getBenName(), 50, 1, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Beneficiary Name");
								throw new IPruException("Error", "GRPPFCC", "Invalid Beneficiary Name");
							}
							if (!validateDate(claimAnnuityBenSubmitPO.getBenDob())) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Beneficiary Date Of Birth");
								throw new IPruException("Error", "GRPPFCC", "Invalid Beneficiary Date Of Birth");
							}
							if (!dropDownChk(claimAnnuityBenSubmitPO.getGender())) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Gender");
								throw new IPruException("Error", "GRPPFCC", "Invalid Gender");
							}
							if (!validateAlpSpaceField(claimAnnuityBenSubmitPO.getRelWithAnnty(), 20, 1, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Relation with Annuitant");
								throw new IPruException("Error", "GRPPFCC", "Invalid Relation with Annuitant");
							}
							if (!validateAlpSpaceField(claimAnnuityBenSubmitPO.getAppointeeName(), 50, 0, "N")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Relation");
								throw new IPruException("Error", "GRPPFCC", "Invalid Relation");
							}
							if (!validateAlpSpaceField(claimAnnuityBenSubmitPO.getRelWithBen(), 20, 0, "N")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Relation with Beneficiary");
								throw new IPruException("Error", "GRPPFCC", "Invalid Relation with Beneficiary");
							}

							if (!validateLongField(claimAnnuityBenSubmitPO.getAllocationPer(), 3, 1, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Allocation Percentage");
								throw new IPruException("Error", "GRPPFCC", "Invalid Allocation Percentage");
							}
							if (!validateAddressField(claimAnnuityBenSubmitPO.getAddress1(), 200, 1, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Beneficiary Address 1");
								throw new IPruException("Error", "GRPPFCC", "Invalid Beneficiary Address 1");
							}
							if (!validateAddressField(claimAnnuityBenSubmitPO.getAddress2(), 200, 1, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Beneficiary Address 2");
								throw new IPruException("Error", "GRPPFCC", "Invalid Beneficiary Address 2");
							}
							if (!validateAddressField(claimAnnuityBenSubmitPO.getAddress3(), 200, 1, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, Invalid Beneficiary Address 3");
								throw new IPruException("Error", "GRPPFCC", "Invalid Beneficiary Address 3");
							}

							if (!validateAlpSpaceField(claimAnnuityBenSubmitPO.getState(), 50, 1, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid State");
								throw new IPruException("Error", "GRPPFCC", "Invalid State");
							}
							if (!validateAlpSpaceField(claimAnnuityBenSubmitPO.getCity(), 50, 1, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid City");
								throw new IPruException("Error", "GRPPFCC", "Invalid City");
							}
							if (!validateNumericField(claimAnnuityBenSubmitPO.getPinCode(), 6, 1, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Pin Code");
								throw new IPruException("Error", "GRPPFCC", "Invalid Pin Code");
							}
							if (!validateNumericField(claimAnnuityBenSubmitPO.getLandlineNo(), 20, 1, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Landline Number");
								throw new IPruException("Error", "GRPPFCC", "Invalid Landline Number");
							}
							if (!validateMobField(claimAnnuityBenSubmitPO.getMobileNo(), 12, 10, "Y")) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Mobile Number");
								throw new IPruException("Error", "GRPPFCC", "Invalid Mobile Number");
							}
							if (!dropDownChk(claimAnnuityBenSubmitPO.getMaritalStatus())) {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Marital Status");
								throw new IPruException("Error", "GRPPFCC", "Invalid Marital Status");
							}
							claimAnnuityBenSubmitPO.setBeneficiaryPos(String.valueOf(i));
							claimAnnuityBenSubmitPO.setRequstedTime(new Date());
							totalAllocation = (int) (totalAllocation + claimAnnuityBenSubmitPO.getAllocationPer());
							i++;
						}
						else {
							FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, You can add only 3 Beneficiary");
							throw new IPruException("Error", "GRPPFCC", "You can add only 3 Beneficiary");
						}
					}
					if (totalAllocation != 100) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Allocation Share% should be 100%");
						throw new IPruException("Error", "GRPPFCC", "Allocation Share% should be 100%");
					}

				}
				else {
					ClaimAnnuityBenSubmitPO claimAnnuityBenSubmitPO = new ClaimAnnuityBenSubmitPO();
					claimAnnuityBenSubmitPO.setBenName(null);
					claimAnnuityBenSubmitPO.setBenDob(null);
					claimAnnuityBenSubmitPO.setGender(null);
					claimAnnuityBenSubmitPO.setRelWithAnnty(null);
					claimAnnuityBenSubmitPO.setAppointeeName(null);
					claimAnnuityBenSubmitPO.setRelWithBen(null);
					claimAnnuityBenSubmitPO.setAllocationPer(null);
					claimAnnuityBenSubmitPO.setAddress1(null);
					claimAnnuityBenSubmitPO.setAddress2(null);
					claimAnnuityBenSubmitPO.setAddress3(null);
					claimAnnuityBenSubmitPO.setState(null);
					claimAnnuityBenSubmitPO.setCity(null);
					claimAnnuityBenSubmitPO.setPinCode(null);
					claimAnnuityBenSubmitPO.setLandlineNo(null);
					claimAnnuityBenSubmitPO.setMobileNo(null);
					claimAnnuityBenSubmitPO.setMaritalStatus(null);
					claimAnnuityBenSubmitPO.setBeneficiaryPos("");
					claimAnnuityBenSubmitSet.add(claimAnnuityBenSubmitPO);
					claimAnnuitySubmitPO.setBeneficiary(claimAnnuityBenSubmitSet);
				}
				if (claimAnnuityOptionPO.getIsPanFileVisible().equals("Y")) {
					if (claimAnnuitySubmitPO.getPanUploadFileList().size() > 1 && claimAnnuitySubmitPO.getPanUploadFileList().size() == 0) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, You need to upload 1 file for Pancard");
						throw new IPruException("Error", "GRPPFCC", "You need to upload 1 file for Pancard");
					}
				}
				if (claimAnnuityOptionPO.getIsSpouseDobFileVisible().equals("Y")) {
					if (claimAnnuitySubmitPO.getDobUploadFileList().size() > 1 && claimAnnuitySubmitPO.getDobUploadFileList().size() == 0) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, You need to upload 1 file for Spouse Date of Birth");
						throw new IPruException("Error", "GRPPFCC", "You need to upload 1 file for Spouse Date of Birth");
					}
				}
				if (claimAnnuityOptionPO.getIsBenDobFileVisible().equals("Y")) {
					if (claimAnnuitySubmitPO.getBenDobUploadFileList().size() > 1 && claimAnnuitySubmitPO.getBenDobUploadFileList().size() == 0) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, You need to upload 1 file for Beneficiary Date of Birth");
						throw new IPruException("Error", "GRPPFCC", "You need to upload 1 file for Beneficiary Date of Birth");
					}
				}
				if (claimAnnuityOptionPO.getIsAgeProofVisible().equals("Y")) {
					if (claimAnnuitySubmitPO.getAgeProofUploadFileList().size() > 1 && claimAnnuitySubmitPO.getAgeProofUploadFileList().size() == 0) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, You need to upload 1 file for age proof");
						throw new IPruException("Error", "GRPPFCC", "You need to upload 1 file for age proof");
					}
				}
			}
			else {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, claimAnnuity page should not be displayed");
				throw new IPruException("Error", "GRPPFCC", "Invalid Attempt");
			}

		}
		else {
			FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Exception Occured, claimAnnuitySubmitPO found null");
			throw new IPruException("Error", "GRPPFCC", "Found null Data");
		}

		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityValidator", "getVaidateData", "Method End");
		return null;
	}

	private boolean validateAlpNumField(String val, Integer max, Integer min, String mend) {

		if (mend.equals("Y")) {
			if (StringUtils.isAlphanumeric(val) && CommonValidationUtil.ValidateMaxLength(val, max) && CommonValidationUtil.ValidateMinLength(val, min)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			if (StringUtils.isAlphanumeric(val) && CommonValidationUtil.ValidateMaxLength(val, max)) {
				return true;
			}
			else {
				return false;
			}
		}

	}

	private boolean validateLongField(Long val, Integer max, Integer min, String mend) {

		String longval = String.valueOf(val);
		if (mend.equals("Y")) {
			if (StringUtils.isNumeric(longval) && CommonValidationUtil.ValidateMaxLength(longval, max) && CommonValidationUtil.ValidateMinLength(longval, min)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			if (StringUtils.isNumeric(longval) && CommonValidationUtil.ValidateMaxLength(longval, max)) {
				return true;
			}
			else {
				return false;
			}
		}

	}

	private boolean validateDoubleField(double val) {

		Double longval = val;
		if (longval != null) {
			return true;
		}

		else {
			return false;
		}

	}

	private boolean validateAlpSpaceField(String val, Integer num, Integer min, String mend) {

		if (mend.equals("Y")) {
			if (StringUtils.isNotEmpty(val) && val.matches("^[a-zA-Z .]*$") && CommonValidationUtil.ValidateMaxLength(val, num) && CommonValidationUtil.ValidateMinLength(val, min)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			if (StringUtils.isNotEmpty(val) && StringUtils.isAlphaSpace(val) && CommonValidationUtil.ValidateMaxLength(val, num)) {
				return true;
			}
			else {
				return false;
			}
		}

	}

	private boolean validateDate(String dob) throws ParseException {
		if (StringUtils.isNotEmpty(dob)) {
			try {
				SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
				Date date1 = format1.parse(dob);
				Date today = new Date();
				if (date1.before(today)) {

					if (CommonValidationUtil.ValidateRequired(dob)) {

						return true;
					}
					else {

						return false;
					}
				}
				else {
					return false;
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateDate", "Exception came ", e);	
				return false;
			}
		}
		else {
			return false;
		}
	}

	private boolean annuityOptChk(Map<String, ClaimAnnuityOptionPO> map, String option) throws ParseException {

		if (map.containsKey(option)) {
			return true;
		}
		else {
			return false;
		}
	}

	private boolean dropDownChk(String dropDownOpt) throws ParseException {

		ClaimAnnuityDropDownPO claimAnnuityDropDownPO = new ClaimAnnuityDropDownPO();
		ClaimAnnuityUtil utils = new ClaimAnnuityUtil();
		claimAnnuityDropDownPO = utils.dropDownList();

		if (claimAnnuityDropDownPO.getMaritalStatusList().contains(dropDownOpt)) {
			return true;
		}
		else if (claimAnnuityDropDownPO.getPaymentModeList().contains(dropDownOpt)) {
			return true;
		}
		else if (claimAnnuityDropDownPO.getPenPayList().contains(dropDownOpt)) {
			return true;
		}
		else if (claimAnnuityDropDownPO.getSalutationList().contains(dropDownOpt)) {
			return true;
		}
		else if (claimAnnuityDropDownPO.getGenderList().contains(dropDownOpt)) {
			return true;
		}
		else {
			return false;
		}
	}

	private boolean validatePanField(String val, Integer max) {

		if ((CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.PAN_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, max) && StringUtils.isNotBlank(val))
				|| val.equals("-")) {
			return true;
		}
		else {
			return false;
		}

	}

	private boolean validateAddressField(String val, Integer max, Integer min, String mend) {

		if (mend.equals(mend)) {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.ADDRESS_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, max)
					&& CommonValidationUtil.ValidateMinLength(val, min)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.ADDRESS_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, max)) {
				return true;
			}
			else {
				return false;
			}
		}
	}

	private boolean validateMobField(String val, Integer max, Integer min, String mend) {

		if (mend.equals("Y")) {
			if ((CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(val, max)
					&& StringUtils.isNotBlank(val)) || val.equals("-")) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			if ((CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(val, max)) || val.equals("-")) {
				return true;
			}
			else {
				return false;
			}
		}

	}

	private boolean validateEmailField(String val, Integer num) {
		if (StringUtils.isNotBlank(val)) {
			if ((CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.EMAILID_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, num)) || val.equals("-")) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return true;
		}

	}

	private boolean validateNumericField(String val, Integer num, Integer min, String mend) {
		if (mend.equals("Y")) {
			if ((CommonValidationUtil.ValidateNumeric(val) && CommonValidationUtil.ValidateMaxLength(val, num) && CommonValidationUtil.ValidateMinLength(val, min)) || val.equals("-")) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			if ((CommonValidationUtil.ValidateNumeric(val) && CommonValidationUtil.ValidateMaxLength(val, num)) || val.equals("-")) {
				return true;

			}
			else {
				return false;
			}
		}

	}

	private boolean validateIfscField(String val, Integer num) {

		if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.IFSC_CODE_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(val, num)) {
			return true;
		}
		else {
			return false;
		}

	}
}
