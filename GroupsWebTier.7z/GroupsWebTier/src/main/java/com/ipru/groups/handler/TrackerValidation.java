package com.ipru.groups.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ipru.enums.TrackerType;
import com.ipru.groups.po.TrackerRequestPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.tcs.logger.FLogger;

public class TrackerValidation {

	private final StringBuilder errorMessageBuilder = new StringBuilder(1);

	public String validateTracker(RequestContext context, TrackerRequestPO trackerRequestPO) throws Exception {

		FLogger.info("TRACKERLogger", "TrackerValidation", "validateTracker", "method start");

		Gson gson = new GsonBuilder().serializeNulls().create();

		if (context != null) {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			if (httpSession != null) {

				HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
				if (request != null) {
					errorMessageBuilder.setLength(0);

					if (trackerRequestPO != null) {

						if (!validateFunctionality(trackerRequestPO.getFunctionality())) {
							errorMessageBuilder.append("Please Select Proper Request Type.\n");
						}

						/*if (!validateDate(trackerRequestPO.getToDate(), trackerRequestPO.getFromDate())) {
							errorMessageBuilder.append("Please Enter Valid date.\n");
						}*/

					}
					else {
						errorMessageBuilder.append("Please Enter Valid Details.\n");
					}

				}

			}
		}

		FLogger.info("TRACKERLogger", "TrackerValidation", "validateTracker", "method end");

		return errorMessageBuilder.toString();
	}

	private boolean validateDate(String toDate, String fromDate) throws Exception {
		if (CommonValidationUtil.validateDate(toDate, fromDate)) {
			return true;
		}
		else {
			return false;
		}
	}

	private boolean validateFunctionality(String functionality) {
		if (CommonValidationUtil.ValidateRequired(functionality) && enumTrackerCheck(functionality)) {
			return true;
		}
		else {
			return false;
		}

	}

	public static boolean enumTrackerCheck(String input) {
		boolean flag = false;
		TrackerType[] enumval = TrackerType.values();
		if (input.equals(enumval[0].toString()) || input.equals(enumval[1].toString()) || input.equals(enumval[2].toString())) {
			flag = true;
		}
		return flag;
	}

	// enumTrackerCheck should be in your class

}
