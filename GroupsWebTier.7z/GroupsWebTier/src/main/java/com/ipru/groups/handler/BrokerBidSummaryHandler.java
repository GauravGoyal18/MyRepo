package com.ipru.groups.handler;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.bidsummary.BidSummaryResponse;
import com.ipru.groups.po.GroupsBasePo;
import com.ipru.groups.validators.BrokerBidSummaryValidator;
import com.ipru.groups.vo.GroupsBaseVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BrokerBidSummaryHandler extends IneoBaseHandler {
	private static final long serialVersionUID = 1L;
	public static final String CLASSNAME = BrokerBidSummaryHandler.class.getCanonicalName();
	public static final String LOGGERNAME = "BrokerBidSummaryLogger";
	private static final String ERROR_LOGGER_NAME = "BrokerBidSummaryLogger";
	String ErrorMsg = "Something went wrong please try again!";

	@MethodPost
	public Event getBizResponseForBrokerBidSummary(RequestContext p_ObjContext) throws Exception {
		final String METHODNAME = "getBizResponseForBrokerBidSummary";
		FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, " Method Start");

		try {

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			HttpSession httpSession = request.getSession();

			IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

			if (userVo == null) {
				FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME, "userVo Should not be null");
				throw new IPruException("Error", "GRPBBS01", ErrorMsg);
			}
			Set<String> policyNoSet = new HashSet<String>();

			/*
			 * policyNoSet.add("00000004"); policyNoSet.add("00000002");
			 * policyNoSet.add("00000003");
			 */

			for (String str : userVo.getFscdetails().getPolicyNoList()) {
				policyNoSet.add(str);
			}
			// policyNoSet.add("00000003"); }

			if (CollectionUtils.isEmpty(policyNoSet)) {
				throw new IPruException("Error", "GRPBBS01", ErrorMsg);
			}

			p_ObjContext.getFlowScope().put("bidBrokerSummrypolicyNoSet", policyNoSet);
			String responseCheck = gsonJSON.toJson(policyNoSet);
			p_ObjContext.getFlowScope().put("Response", responseCheck);

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASSNAME, METHODNAME, "Exception Occurred ", e);
			throwINeoFlowException(e, "GRPBBS01", p_ObjContext);
		}

		FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Method End");
		return success();
	}

	@MethodPost
	public Event getBizRequestBrokerBidSummaryGrid(RequestContext context) throws Exception {
		final String METHODNAME = "getBizResponseBrokerBidSummaryGrid";
		FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Method start");

		GroupsBasePo brokerBidSummaryPO = null;

		String policyNo = null;
		Set<String> policySet = null;

		try {

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

			brokerBidSummaryPO = gsonJSON.fromJson(request.getReader(), GroupsBasePo.class);

			if (brokerBidSummaryPO == null) {
				throw new IPruException("Error", "GRPBBS01", ErrorMsg);

			}

			policySet = (Set<String>) context.getFlowScope().get("bidBrokerSummrypolicyNoSet");

			// policyList=new HashSet<String>(1);

			if (CollectionUtils.isEmpty(policySet)) {
				throw new IPruException("Error", "GRPBBS01", ErrorMsg);
			}

			BrokerBidSummaryValidator validator = new BrokerBidSummaryValidator();

			String errorMsg = validator.validateBrokerBidSummary(brokerBidSummaryPO, policySet);

			if (StringUtils.isNotEmpty(errorMsg)) {
				this.setValidationErrorMessages(errorMsg);
				FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Data from request should not be null");
				throwINeoFlowException(new ServiceException("GRPBBS01"), "GRPBBS01", context);
			}

			GroupsBaseVO brokerBidSummaryVO = dozerBeanMapper.map(brokerBidSummaryPO, GroupsBaseVO.class);
			if (brokerBidSummaryVO == null) {
				throw new IPruException("Error", "GRPBBS01", "brokerBidSummaryVO should not be null");

			}

			if (brokerBidSummaryVO.getPolicyNo() == null) {
				throw new IPruException("Error", "GRPBBS01", "PolicyNUmber should not be null");
			}

			Object[] paramArray = new Object[1];
			paramArray[0] = brokerBidSummaryVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			context.getFlowScope().put("fetchBrokerBidSummaryGridData", obj_bizReq);
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASSNAME, METHODNAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBBS01", context);
		}
		FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Method end");
		return success();
	}

	@MethodPost
	public Event getBizResponseForFetchBIDSummary(RequestContext p_ObjContext) throws Exception {
		final String METHODNAME = "getBizResponseForFetchBIDSummary";
		try {
			FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Method Start");

			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResBrokerBidSummaryGridData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Error while getting response from service");
					throwINeoFlowException(new Exception(), "GRBID02", p_ObjContext);
				}
				else {

					List<BidSummaryResponse> bidSummaryResponseList = (List<BidSummaryResponse>) bizRes.getTransferObjects().get("response1");

					if (CollectionUtils.isEmpty(bidSummaryResponseList)) {
						FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "bidSummaryResponseList should not be null");

					}
					String resultJson = gsonJSON.toJson(bidSummaryResponseList);
					p_ObjContext.getFlowScope().put("Response", resultJson);
				}
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Exception Occurred ", e);
			throwINeoFlowException(e, "GRBID01", p_ObjContext);
		}

		FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Method End");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}