package com.ipru.groups.handler;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.AnnuityCalculatorPO;
import com.ipru.groups.po.AnnuityLoadResponsePO;
import com.ipru.groups.po.AnnuityResultDataPO;
import com.ipru.groups.validators.AnnuityCalculatorValidator;
import com.ipru.groups.vo.AnnuityCalculatorVO;
import com.ipru.groups.vo.AnnuityLoadResponseVO;
import com.ipru.groups.vo.AnnuityRequestVO;
import com.ipru.groups.vo.AnnuityResultDataVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class AnnuityCalculatorHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Event getBizRequestForAnnuityLoad(RequestContext p_ObjContext) throws Exception {
		FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestForAnnuityLoad", "Method Start");

		String policyNo = null;
		String clientId = null;
		String empId = null;
		List<RoleScreenAccessMappingVO> accessMappingList;

		try {
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();

			IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

			if (userVo != null) {
				policyNo = userVo.getPolicyNo();
				clientId = userVo.getClientId();
				empId = userVo.getEmpId();
				accessMappingList = userVo.getLstRoleScreenAccessMapping();

				AnnuityRequestVO requestVO = new AnnuityRequestVO();
				requestVO.setClientId(clientId);
				requestVO.setPolicyNo(policyNo);
				requestVO.setEmpId(empId);
				requestVO.setAccessMappingList(accessMappingList);

				Object[] paramArray = new Object[1];
				paramArray[0] = requestVO;

				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				p_ObjContext.getFlowScope().put("annuityLoadDataBizReq", obj_bizReq);
			}

		}
		catch (Exception e) {
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestForAnnuityLoad", "Exception ", e);
			throwINeoFlowException(e, "GRPANC01", p_ObjContext);
		}

		FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestForAnnuityLoad", "Method End");
		return success();
	}

	public Event getBizResponseForAnnuityLoad(RequestContext p_ObjContext) throws Exception {
		FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseForAnnuityLoad", "Method Start");

		try {
			String responseCheck = "";
			BizResponse bizRes = new BizResponse();
			AnnuityLoadResponseVO annuityLoadResponseVO = null;
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForAnnuityLoadData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throw new IPruException("Error", "GRPANC01", "Request can not be processed, Please try again later");
				}
				else {
					annuityLoadResponseVO = (AnnuityLoadResponseVO) bizRes.getTransferObjects().get("response1");

					if (annuityLoadResponseVO == null) {
						FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseForAnnuityLoad", "annuityResultDataVO is null ");

						throw new IPruException("Error", "GRPANC01", "Request can not be processed, Please try again later");
					}

					AnnuityLoadResponsePO responsePO = dozerBeanMapper.map(annuityLoadResponseVO, AnnuityLoadResponsePO.class);
					String gsonString = gsonJSON.toJson(responsePO);

					FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseForAnnuityLoad", "gsonString " + gsonString);

					p_ObjContext.getFlowScope().put("Response", gsonString);
				}
			}
		}
		catch (Exception e) {
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseForAnnuityLoad", "Exception ", e);
			throwINeoFlowException(e, "GRPANC01", p_ObjContext);
		}

		FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseForAnnuityLoad", "Method End");
		return success();
	}

	public Event getBizRequestforAnnuitySubmit(RequestContext p_ObjContext) throws Exception {
		FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestforAnnuitySubmit", "getBizRequestforAnnuitySubmit Method Start");

		try {

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			if (request != null) {
				HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
				if (httpSession == null) {
					throw new IPruException("Error", "GRPANC01", "Found null session");
				}

				FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestforAnnuitySubmit", "getBizRequestforAnnuitySubmit not null request");

				AnnuityCalculatorPO annuityCalculatorPo = gsonJSON.fromJson(request.getReader(), AnnuityCalculatorPO.class);

				// ////System.out.println("annuityCalculatorPoannuityCalculatorPo"+annuityCalculatorPo.toString());

				if (annuityCalculatorPo == null) {
					FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestforAnnuitySubmit", "annuityCalculatorPo is null");
					throw new IPruException("Error", "GRPANC01", "Found null data");
				}
				// call validation
				AnnuityCalculatorValidator validator = new AnnuityCalculatorValidator();
				String errorSuccessMessage = validator.annuityValidate(annuityCalculatorPo);
				// ////System.out.println("errorSuccessMessageerrorSuccessMessageerrorSuccessMessage"+errorSuccessMessage);

				if (StringUtils.isNotBlank(errorSuccessMessage)) {

					this.setValidationErrorMessages(errorSuccessMessage);
					FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestforAnnuitySubmit", "annuityCalculatorPo validation fails " + errorSuccessMessage);
					/*
					 * throw new
					 * IPruException("Error","GRPNOUP",errorSuccessMessage);
					 */
					throwINeoFlowException(new ServiceException("GRPANC01"), "GRPANC01", p_ObjContext);

				}
				FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestforAnnuitySubmit", "getBizRequestforAnnuitySubmit validation success");

				// po to vo

				AnnuityCalculatorVO annuityCalculatorVO = dozerBeanMapper.map(annuityCalculatorPo, AnnuityCalculatorVO.class);
				if (annuityCalculatorVO == null) {
					FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestforAnnuitySubmit", "annuityCalculatorVO is null");
					throw new IPruException("Error", "GRPANC01", "Found null data");
				}
				// ////System.out.println("annuityCalculatorVOannuityCalculatorVOannuityCalculatorVO"+annuityCalculatorVO.toString());
				Object[] paramArray = new Object[1];
				paramArray[0] = annuityCalculatorVO;

				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				p_ObjContext.getFlowScope().put("annuitySubmitDataBizReq", obj_bizReq);

				FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestforAnnuitySubmit", "getBizRequestforAnnuitySubmit end");

			}

		}
		catch (Exception e) {
			// e.printStackTrace();

			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizRequestforAnnuitySubmit", "Exception ", e);
			throwINeoFlowException(e, "GRPANC01", p_ObjContext);
		}
		return success();
	}

	@MethodPost
	public Event getBizResponseforforAnnuitySubmit(RequestContext p_ObjContext) throws Exception {
		FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseforforAnnuitySubmit", "method start");

		try {
			String responseCheck = "";
			BizResponse bizRes = new BizResponse();
			AnnuityResultDataVO annuityResultDataVO = null;

			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForAnnuitySubmitData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throw new IPruException("Error", "GRPANC01", "Request can not be processed, Please try again later");
				}
				else {
					annuityResultDataVO = (AnnuityResultDataVO) bizRes.getTransferObjects().get("response1");
					// ////System.out.println("annuityResultDataPOannuityResultDataVOVOOOOOOOOO"+annuityResultDataVO.toString());
					if (annuityResultDataVO == null) {
						FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseforforAnnuitySubmit", "annuityResultDataVO is null ");

						throw new IPruException("Error", "GRPANC01", "Request can not be processed, Please try again later");
					}
					AnnuityResultDataPO annuityResultDataPO = dozerBeanMapper.map(annuityResultDataVO, AnnuityResultDataPO.class);
					FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseforforAnnuitySubmit", "AnnuityResultDataPO");

					if (annuityResultDataPO == null) {
						FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseforforAnnuitySubmit", "annuityResultDataPO is null ");

						throw new IPruException("Error", "GRPANC01", "Request can not be processed, Please try again later");
					}
					String gsonString = gsonJSON.toJson(annuityResultDataPO);

					// ////System.out.println("annuityResultDataPOannuityResultDataPOannuityResultDataPO"+annuityResultDataPO.toString());

					FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseforforAnnuitySubmit", "gsonString " + gsonString);

					p_ObjContext.getFlowScope().put("Response", gsonString);

				}

			}

		}
		catch (Exception e) {
			// e.printStackTrace();
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseforforAnnuitySubmit", "Exception ", e);
			throwINeoFlowException(e, "GRPANC01", p_ObjContext);
		}
		FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorHandler", "getBizResponseforforAnnuitySubmit", "method end");

		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
