package com.ipru.groups.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.utilities.EncodingUtility;
import com.ipru.groups.utilities.EncryptionPBEMD5DES;
import com.tcs.logger.FLogger;

public class DownloadFileServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		FLogger.info("FileDownloadLogger", "DownloadFileServlet", "doPost", "Start method");

		HttpSession session = request.getSession(false);
		FileInputStream in = null;
		ServletOutputStream out = null;
		String contentType = null;

		try {
			if (session == null) {
				FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost", "Found null session");

				throw new ServletException("Found null session");
			}

			/*
			 * String transactionId = request.getParameter("data");
			 * transactionId="5"; if(transactionId==null) {
			 * FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost",
			 * "Found null data"); throw new
			 * ServletException("Something went wrong"); }
			 */
			/*
			 * FLogger.info("FileDownloadLogger", "DownloadFileServlet", "doPost",
			 * "transactionId from context" + transactionId);
			 */

			UploadFilePO document = (UploadFilePO) session.getAttribute("DownloadFileData");

			if(document==null)
			{
				FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost", "Found null data from session.");
				throw new ServletException("Fount null data.");
			}
			// chck coming transaction id wth session id
			/*
			 * if (Long.parseLong(transactionId) != document.getDocId()) {
			 * FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost",
			 * "transactionId did not match" + transactionId + "," +
			 * document.getDocId()); throw new
			 * ServletException("Something went wrong"); }
			 */
			String encryptedPath = document.getDocPath();
			if(encryptedPath==null)
			{
				FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost", "Found null data from session.");
				throw new ServletException("Fount null data.");
			}
			String path = EncryptionPBEMD5DES.decrypt(EncodingUtility.decodeBase64(encryptedPath), EncodingUtility.CONSTANT_DOCUMENT_PATH_ENCRYPTION_KEY, 1);

			FLogger.info("FileDownloadLogger", "DownloadFileServlet", "doPost", "path" + path);

			String fileName = document.getDocName();
			//System.out.println(path + "," + fileName);
			if (path == null || fileName == null) {
				FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost", "Found null data");

				throw new ServletException("Found null data");
			}
			File file = new File(path);
			/*if (!file.exists()) {
				FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost", "File doesn't exists on server.");
				throw new ServletException("File doesn't exists on server.");
			}*/
			
			if(!file.exists()){
				if(path.startsWith("/Image_138/")){
					path = path.replaceFirst("/Image_138/", "/Image/");
					file = new File(path);
					if (!file.exists()) {
						FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost", "File doesn't exists on server.");
						throw new ServletException("File doesn't exists on server.");
					}
				} else if(path.startsWith("/Image/")){
					path = path.replaceFirst("/Image/", "/Image_138/");
					file = new File(path);
					if (!file.exists()) {
						FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost", "File doesn't exists on server.");
						throw new ServletException("File doesn't exists on server.");
					}
				} else {
					FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost", "File doesn't exists on server.");
					throw new ServletException("File doesn't exists on server.");
				}
			}
			
			out = response.getOutputStream();
			in = new FileInputStream(path);

			contentType = document.getContentType();
			response.setContentType(contentType);
			response.addHeader("content-disposition", "attachment; filename=" + fileName);

			int octet;
			while ((octet = in.read()) != -1)
				out.write(octet);

			out.flush();

			FLogger.info("FileDownloadLogger", "DownloadFileServlet", "doPost", "method end");

		}
		catch (IOException e) {
			// e.printStackTrace();
			FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost", "Some error occured" , e);

			 ServletOutputStream objServletOutputStream = response.getOutputStream();
			  objServletOutputStream.flush();
		}
		catch (Exception e) {
			// e.printStackTrace();
			FLogger.error("FileDownloadLogger", "DownloadFileServlet", "doPost", "Some error occured" , e);

			 ServletOutputStream objServletOutputStream = response.getOutputStream();
			  objServletOutputStream.flush();
		}
		finally {

			// session.removeAttribute("downloadFileToken");
			session.removeAttribute("DownloadFileData");
			session.removeAttribute("downloadFileRequestPOSession");
			if(in!=null)
			in.close();
			if(out!=null)
			out.close();

		}

	}

}
