package com.ipru.groups.security.handler;
import java.io.Serializable;
import java.math.BigInteger;
import java.security.SecureRandom;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.webflow.execution.RequestContext;

import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.security.exception.GroupsSecurityException;
import com.ipru.security.user.IPruUser;

/**
 * 
 * @author Ajay: IPRU22591
 * This class is used to prevent site from CSRF(Cross side request forgery)
 * 
 */
public final class CsrfImplementation implements Serializable {
	private CsrfImplementation(){
		super();
	}
	/**
	 * 
	 * @param requestContext
	 * @return String :csrfToken
	 * This method return random Alpha-numeric token and sets in session
	 */
	public static String genrateCsrfToken(RequestContext requestContext)
	{
		String csrfToken="";
		//csrfToken = ESAPI.randomizer().getRandomString(8,DefaultEncoder.CHAR_ALPHANUMERICS);	
		csrfToken = new BigInteger(130, new SecureRandom()).toString(32);
		
		HttpSession httpSession =((HttpServletRequest)requestContext.getExternalContext().getNativeRequest()).getSession();
		httpSession.setAttribute("csrfToken",csrfToken);
		return csrfToken;	
	}
	/**
	 * 
	 * @param requestContext
	 * @param csrfToken
	 * @throws Exception
	 * this method compare csrf token from request and session 
	 * if token is same remove parameter from session and return
	 * else throw Exception
	 */
	public static void checkCsrfTokens(RequestContext requestContext, String csrfToken) throws GroupsSecurityException
	{
	
	HttpSession httpSession =((HttpServletRequest)requestContext.getExternalContext().getNativeRequest()).getSession();
	String csrfTokenFromSession=(String)httpSession.getAttribute("csrfToken");
	String csrfTokenFromRequest=csrfToken;
	if(null!=csrfTokenFromSession&&null!=csrfTokenFromRequest&&csrfTokenFromRequest.equals(csrfTokenFromSession))
	{
		httpSession.removeAttribute("csrfToken");
	return;	
	}
	if(null!=csrfTokenFromSession)
	{
		httpSession.removeAttribute("csrfToken");
	}
	Object userInSessionObj = GroupSecurityUtil.getAttributeFromSession(requestContext, "userVO");
	IPruUser userInSession = null;
	if(userInSessionObj!=null&&userInSessionObj instanceof IPruUser){
		userInSession = (IPruUser)userInSessionObj;
		throw new GroupsSecurityException("Authentication failed :: Possibly forged HTTP request without proper CSRF token detected :: LoggedIn UserId :: "+userInSession.getUserId()+ " :: userName :: "+userInSession.getUserName());
	}else {
		throw new GroupsSecurityException("Authentication failed :: Possibly forged HTTP request without proper CSRF token detected ");
	}
	
	}
	
	
	/**
	 * 
	 * @param requestContext
	 * @param SessionKey
	 * @return csrfToken
	 * This method return random Alpha-numeric token and sets in session
	 * This method is to be used when multiple functionality with respect to CSRF has to be open in diff tab of same browser so that 
	 * session wont collide as session id would be diffrent
	 * it is recommended to have sessionKey like eg: "csrfToken_finctionalityName"
	 */
	public static String genrateCsrfToken(RequestContext requestContext,String SessionKey)
	{
		String csrfToken="";
		//csrfToken = ESAPI.randomizer().getRandomString(8,DefaultEncoder.CHAR_ALPHANUMERICS);	
		csrfToken = new BigInteger(130, new SecureRandom()).toString(32);
		
		HttpSession httpSession =((HttpServletRequest)requestContext.getExternalContext().getNativeRequest()).getSession();
		httpSession.setAttribute(SessionKey,csrfToken);
		return csrfToken;	
	}
	/**
	 * 
	 * @param requestContext
	 * @param csrfToken
	 * @param SessionKey
	 * @throws Exception
	 * this method compare csrf token from request and session 
	 * if token is same remove parameter from session and return
	 * else throw Exception
	 * This method is to be used when multiple functionality with respect to CSRF has to be open in diff tab of same browser so that 
	 * session wont collide as session id would be diffrent
	 * it is recommended to have sessionKey like eg: "csrfToken_finctionalityName"
	 */
	public static void checkCsrfTokens(RequestContext requestContext, String csrfToken,String SessionKey) throws GroupsSecurityException
	{
	
	HttpSession httpSession =((HttpServletRequest)requestContext.getExternalContext().getNativeRequest()).getSession();
	String csrfTokenFromSession=(String)httpSession.getAttribute(SessionKey);
	String csrfTokenFromRequest=csrfToken;
	if(null!=csrfTokenFromSession&&null!=csrfTokenFromRequest&&csrfTokenFromRequest.equalsIgnoreCase(csrfTokenFromSession))
	{
		httpSession.removeAttribute(SessionKey);
	return;	
	}
	if(null!=csrfTokenFromSession)
	{
		httpSession.removeAttribute(SessionKey);
	}
	Object userInSessionObj = GroupSecurityUtil.getAttributeFromSession(requestContext, "userVO");
	IPruUser userInSession = null;
	if(userInSessionObj!=null&&userInSessionObj instanceof IPruUser){
		userInSession = (IPruUser)userInSessionObj;
		throw new GroupsSecurityException("Authentication failed :: Possibly forged HTTP request without proper CSRF token detected :: LoggedIn UserId :: "+userInSession.getUserId()+ " :: userName :: "+userInSession.getUserName());
	}else {
		throw new GroupsSecurityException("Authentication failed :: Possibly forged HTTP request without proper CSRF token detected ");
	}
	}


}
