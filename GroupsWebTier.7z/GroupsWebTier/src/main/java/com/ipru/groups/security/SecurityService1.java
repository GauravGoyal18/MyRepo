package com.ipru.groups.security;

import com.tcs.logger.FLogger;
import com.tcs.security.IBaseService;
import com.tcs.security.auth.IAuthStore;

public class SecurityService1 extends IBaseService {
	private IAuthStore localAuthStore;
	FLogger logger = FLogger.getInstance();
	String thisClass = getClass().toString();
	String thisMethod = "";

	String message = "";

	public String getMessage() {
		return message;
	}

	public SecurityService1(IAuthStore authStore) {
		this.localAuthStore = authStore;
	}

	public String handleService(Object p_ObjObj1, Object p_ObjObj2) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	public boolean authenticateUser(String p_paramUserName, String p_paramUserPwd) throws Exception {
		boolean l_StrResult = false;
		this.thisMethod = "authenticateUser";
		FLogger.info("securityLogger", this.thisClass, this.thisMethod, "****authenticateUser Called****");
		try {
			l_StrResult = this.localAuthStore.isValidUser(p_paramUserName, p_paramUserPwd);
			message = ((MyDBAdaptor) this.localAuthStore).getMessage();

		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return l_StrResult;
	}

	public boolean isUserlocked(String p_paramUserName, String p_paramUserPwd) throws Exception {
		boolean l_StrResult = false;
		this.thisMethod = "lockedUser";
		try {
			l_StrResult = this.localAuthStore.isUserLocked(p_paramUserName);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return l_StrResult;
	}

	public boolean isUserActive(String p_paramUserName, String p_paramUserPwd) throws Exception {
		boolean l_StrResult = false;
		this.thisMethod = "authenticateUser";
		try {
			l_StrResult = this.localAuthStore.isUserActive(p_paramUserName, p_paramUserPwd);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return l_StrResult;
	}
}
