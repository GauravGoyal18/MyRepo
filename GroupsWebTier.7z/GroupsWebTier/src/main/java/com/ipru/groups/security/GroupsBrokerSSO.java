package com.ipru.groups.security;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.ipru.groups.po.GroupRetailLoginInfoPO;
import com.ipru.groups.po.GroupsBrokerPO;
import com.ipru.groups.security.encryption.EncryptionAES256;
import com.ipru.groups.utilities.EncodingUtility;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.logger.FLogger;

public class GroupsBrokerSSO {

	GroupsBrokerPO brokerPO= new GroupsBrokerPO();
	
	
	
	public GroupsBrokerPO getBrokerDetails(String groupBrokerbean, Properties prop) throws SSOGroupDefaultException {   
		 
						     
		if (!StringUtils.isEmpty(groupBrokerbean)) {    
		
			String decryptkey = prop.getProperty("GRP_BROKERKEY");
		try {
				
				brokerPO = groupRetailParseRequest(groupBrokerbean, decryptkey);  
			
			  } 
		
		catch (Exception e) {
				// TODO Auto-generated catch block
				SSOGroupDefaultException authException = new SSOGroupDefaultException("Request is not valid") {  
				};
				FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "GroupBrokerLoginInfoPO is not parsed ");
				throw authException;
			}
			if (brokerPO != null) {
				/*if (StringUtils.isEmpty(brokerPO.getMobileNo()) || StringUtils.isEmpty(brokerPO.getEmailId())
						|| StringUtils.isEmpty(brokerPO.getWebClientId()) || brokerPO.getMilliseconds() == 0) {
					SSOGroupDefaultException authException = new SSOGroupDefaultException("Email Id and mobile number not registered") {
					};
					FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "GroupRetailLoginInfoPO is not parsed ");
					throw authException;
				}*/
			}
			else {
				SSOGroupDefaultException authException = new SSOGroupDefaultException("Request is not valid") {  
				};
				FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "GroupBrokerLoginInfoPO is not parsed ");
				throw authException;
			  }
			
		}else{
			
			SSOGroupDefaultException authException = new SSOGroupDefaultException("Request is not valid") {
			};
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "GroupBrokerLoginInfoPO is not parsed ");
			throw authException;
		}
		
		return brokerPO;
	
	
	
	
	}
	
	
	
	private GroupsBrokerPO groupRetailParseRequest(String encryptedcontent, String decryptkey) throws Exception {
		// TODO Auto-generated method stub
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "groupRetailParseRequest", "Method start for single sign on");

		//GroupRetailLoginInfoPO groupRetailLoginInfoPO = new GroupRetailLoginInfoPO();
		try {
			brokerPO = this.getSSODecodingValue(this.getSSOAES256DecryptedJSON(encryptedcontent, decryptkey));
		}
		catch (JsonSyntaxException ex) {
			ex.printStackTrace();
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "GroupRetailLoginInfoPO", "got Exception While single sign on", ex);
		}
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "groupRetailParseRequest", "Method end for single sign on");
		return brokerPO;
	}	
	
	private GroupsBrokerPO getSSOAES256DecryptedJSON(String encryptedcontent, String decryptkey) throws Exception {
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "getSSOAES256DecryptedJSON", " Method start for Decryption JSON");
		//GroupRetailLoginInfoPO groupRetailLoginInfoPO = new GroupRetailLoginInfoPO();
		Gson gson = new Gson();
		try {
			brokerPO =gson.fromJson(EncryptionAES256.decrypt(encryptedcontent, decryptkey), GroupsBrokerPO.class);
		}
		catch (JsonSyntaxException e) {
			e.printStackTrace();
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "GroupRetailLoginInfoPO", "Got Exception while Decrypted JSON ", e);
			throw e;
		}
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "getSSOAES256DecryptedJSON", " Method End for Decryption JSON");
		return brokerPO;
	}

	private GroupsBrokerPO getSSODecodingValue(GroupsBrokerPO brokerPO) throws Exception {
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "getSSODecodingValue", " Method start for SSOEncodingValue JSON");
		try {
			if (!StringUtils.isEmpty(brokerPO.getFscClientId())) {
				String decodedWcId = EncodingUtility.decodeBase64(brokerPO.getFscClientId());
				brokerPO.setFscClientId(!StringUtils.isEmpty(decodedWcId) ? decodedWcId : null);
			}
			else {
				FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "GroupRetailLoginInfoPO", "WebClientId should not be null");
				brokerPO.setFscClientId(null);
			  }
		}
		catch (Exception e) {
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "GroupRetailLoginInfoPO", "Got Exception While Decoding Value", e);
			throw e;
		}
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "getSSODecodingValue", " Method End for SSOEncodingValue JSON");
		return brokerPO;
	}


}
