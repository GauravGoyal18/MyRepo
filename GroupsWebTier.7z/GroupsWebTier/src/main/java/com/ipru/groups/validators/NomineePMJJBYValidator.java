package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.joda.time.Years;

import com.ipru.IPruException;

import com.ipru.groups.po.NomineeBenPMJJBYSubmitPO;
import com.ipru.groups.po.NomineePMJJBYSubmitPO;
import com.ipru.groups.po.UploadFilePO;

import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.logger.FLogger;

public class NomineePMJJBYValidator {

	Years age = null;
	final StringBuilder errorMessageBuilder = new StringBuilder(1);

	public String validateSubmit(NomineePMJJBYSubmitPO nomineePMJJBYSubmitPO)
			throws IPruException, ParseException {
		FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYValidator",
				"validateSubmit", " Method Start ");
		if (nomineePMJJBYSubmitPO != null) {

			if (!validateAlpNumField(nomineePMJJBYSubmitPO.getPolicyNo(), 100,
					1)) {
				FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYValidator",
						"validateSubmit",
						"Exception Occured, Invalid Master Policy Number");
				errorMessageBuilder.append("Invalid Master Policy Number. ");

				// throw new IPruException("Error", "GRPPFCC",
				// "Invalid Master Policy Number");
			}
			if (!validateAlpSpaceField(nomineePMJJBYSubmitPO.getSchemeName(),
					100, 1)) {
				FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYValidator",
						"validateSubmit",
						"Exception Occured, Invalid Scheme Name");
				errorMessageBuilder.append("Invalid Scheme Name. ");

				// throw new IPruException("Error", "GRPPFCC",
				// "Invalid Scheme Name");
			}
			if (!validateNumericField(nomineePMJJBYSubmitPO.getAccountNumber(),
					100, 1)) {
				FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYValidator",
						"validateSubmit",
						"Exception Occured, Invalid Account Number");
				errorMessageBuilder.append("Invalid Account Number. ");

				// throw new IPruException("Error", "GRPPFCC",
				// "Invalid Account Number");
			}

			if (!validateDate(nomineePMJJBYSubmitPO.getEffectiveDate())) {
				FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYValidator",
						"validateSubmit",
						"Exception Occured, Invalid Death Date");
				errorMessageBuilder.append("Invalid Death Date. ");

				// throw new IPruException("Error", "GRPPFCC",
				// "Invalid Death Date");
			}

			int i = 1;
			@SuppressWarnings("unchecked")
			Set<NomineeBenPMJJBYSubmitPO> claimsBenPMJJBYSubmitPOSet = nomineePMJJBYSubmitPO
					.getBeneficiary();
			for (NomineeBenPMJJBYSubmitPO nomineeBenPMJJBYSubmitPO : claimsBenPMJJBYSubmitPOSet) {

				if (i <= 3) {
					if (!validateAlpSpaceField(
							nomineeBenPMJJBYSubmitPO.getBeneficiaryName(), 100,
							1)) {
						FLogger.error("NomineePMJJBYLogger",
								"NomineePMJJBYValidator", "validateSubmit",
								"Exception Occured, Invalid Beneficiary Name");
						errorMessageBuilder
								.append("Invalid Beneficiary Name. ");

						// throw new IPruException("Error", "GRPPFCC",
						// "Invalid Beneficiary Name");
					}
					if (!validateAlpSpaceField(
							nomineeBenPMJJBYSubmitPO.getRelation(), 100, 1)) {
						FLogger.error("NomineePMJJBYLogger",
								"NomineePMJJBYValidator", "validateSubmit",
								"Exception Occured, Invalid Relation");
						errorMessageBuilder.append("Invalid Relation. ");

						// throw new IPruException("Error", "GRPPFCC",
						// "Invalid Relation");
					}
					if (!validateNumericField(
							nomineeBenPMJJBYSubmitPO.getSharePercentage(), 3, 1)) {
						FLogger.error("NomineePMJJBYLogger",
								"NomineePMJJBYValidator", "validateSubmit",
								"Exception Occured, Invalid Share Percentage");
						errorMessageBuilder
								.append("Invalid Share Percentage. ");

						// throw new IPruException("Error", "GRPPFCC",
						// "Invalid Share Percentage");
					}
					if (!validateDate(nomineeBenPMJJBYSubmitPO
							.getBeneficiaryDOB())) {
						FLogger.error("NomineePMJJBYLogger",
								"NomineePMJJBYValidator", "validateSubmit",
								"Exception Occured, Invalid Beneficiary Date Of Birth");
						errorMessageBuilder
								.append("Invalid Beneficiary Date Of Birth. ");

						// throw new IPruException("Error", "GRPPFCC",
						// "Invalid Relation");
					}
					if (!validateDropDown(nomineeBenPMJJBYSubmitPO.getGender())) {
						FLogger.error("NomineePMJJBYLogger",
								"NomineePMJJBYValidator", "validateSubmit",
								"Exception Occured, Invalid Gender");
						errorMessageBuilder.append("Invalid Gender. ");
						// throw new IPruException("Error", "GRPPFCC",
						// "Invalid Gender");
					}

					if (!validateAddressField(
							nomineeBenPMJJBYSubmitPO.getBenAddress(), 400, 1)) {
						FLogger.error("NomineePMJJBYLogger",
								"NomineePMJJBYValidator", "validateSubmit",
								"Exception Occured, Invalid Address");
						errorMessageBuilder.append("Invalid Address. ");

						// throw new IPruException("Error", "GRPPFCC",
						// "Invalid Address");
					}
					if (!validateAlpSpaceField(
							nomineeBenPMJJBYSubmitPO.getCity(), 20, 1)) {
						FLogger.error("NomineePMJJBYLogger",
								"NomineePMJJBYValidator", "validateSubmit",
								"Exception Occured, Invalid City");
						errorMessageBuilder.append("Invalid City. ");

						// throw new IPruException("Error", "GRPPFCC",
						// "Invalid City");
					}
					if (!validateNumericField(
							nomineeBenPMJJBYSubmitPO.getPincode(), 6, 1)) {
						FLogger.error("NomineePMJJBYLogger",
								"NomineePMJJBYValidator", "validateSubmit",
								"Exception Occured, Invalid Pin Code");
						errorMessageBuilder.append("Invalid Pin Code. ");

						// throw new IPruException("Error", "GRPPFCC",
						// "Invalid Pin Code");
					}

					nomineeBenPMJJBYSubmitPO.setBeneficiaryPos(String
							.valueOf(i));
				} else {
					FLogger.error("NomineePMJJBYLogger",
							"NomineePMJJBYValidator", "validateSubmit",
							"Exception Occured, You can add only 3 Beneficiary");
					errorMessageBuilder
							.append("You can add only 3 Beneficiary. ");

					// throw new IPruException("Error", "GRPPFCC",
					// "You can add only 3 Beneficiary");
				}

			}

		} else {
			FLogger.error("NomineePMJJBYLogger", "NomineePMJJBYValidator",
					"validateSubmit", "claimsPMJJBYSubmitPO is null");
			// throw new IPruException("Error", "GRPCL03",
			// "claimsPMJJBYSubmitPO is null");
			errorMessageBuilder.append("claimsPMJJBYSubmitPO is null. ");

		}

		FLogger.info("NomineePMJJBYLogger", "NomineePMJJBYValidator",
				"validateSubmit", " Method Start ");
		return errorMessageBuilder.toString();

	}

	private boolean validateNumericField(String val, Integer num, Integer min) {

		if (CommonValidationUtil.ValidateNumeric(val)
				&& CommonValidationUtil.ValidateMaxLength(val, num)
				&& CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		} else {
			return false;
		}

	}

	private boolean validateAlpSpaceField(String val, Integer num, Integer min) {

		if (StringUtils.isAlphaSpace(val)
				&& CommonValidationUtil.ValidateMaxLength(val, num)
				&& CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		} else {
			return false;
		}

	}

	private boolean validateAlpNumField(String val, Integer num, Integer min) {

		if (StringUtils.isAlphanumeric(val)
				&& CommonValidationUtil.ValidateMaxLength(val, num)
				&& CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		} else {
			return false;
		}

	}

	private boolean validateDate(String date) throws ParseException {
		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy",
				Locale.ENGLISH);

		Date date1 = format1.parse(date);

		Date today = new Date();

		if (date1.before(today)) {

			if (CommonValidationUtil.ValidateRequired(date)) {

				return true;
			} else {

				return false;
			}
		} else {
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	private boolean validateDropDown(String val) {

		List genderList = new ArrayList();
		genderList.add("male");
		genderList.add("female");

		
		  if(genderList.contains(val))
				  { return true;
				  } 
		  else
		  { 
			  return false;
		  }
		

		
	}

	private boolean validateAddressField(String val, Integer max, Integer min) {

		if (CommonValidationUtil.isMatchedPattern(val,
				GroupFormValidationConstant.ADDRESS_VALIDATION)
				&& CommonValidationUtil.ValidateMaxLength(val, max)
				&& CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;
		} else {
			return false;
		}

	}

	private boolean validateIfscField(String val, Integer num, Integer min) {

		if (CommonValidationUtil.isMatchedPattern(val,
				GroupFormValidationConstant.IFSC_CODE_VALIDATION_FORGROUP)
				&& CommonValidationUtil.ValidateMaxLength(val, num)
				&& CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;
		} else {
			return false;
		}

	}

}
