package com.ipru.groups.utilities;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.ipru.groups.po.GstDropDownPO;
import com.tcs.logger.FLogger;

public class GstUtil {

	
	public GstDropDownPO dropDownList(){
		FLogger.info("GstLogger", "GstUtil", "dropDownList", "dropDownList Method Started");
		
	List cob=new ArrayList();
		cob.add("NonResidentEntity");
		cob.add("ForeignCompanyRegisteredInIndia");
		cob.add("ForeignLimitedLiabilityPartnership");
		cob.add("GovernmentDepartment");
		cob.add("HinduUndividedFamily");
		cob.add("LocalAuthority");		
		cob.add("Others");
		cob.add("Partnership");
		cob.add("PrivateLimitedCompany");
		cob.add("Proprietorship");	
		
		List custType=new ArrayList();
		custType.add("EouStpEhtp");
		custType.add("General");
		custType.add("Government");
		custType.add("Others");
		custType.add("Overseas");
		custType.add("relatedParty");
		custType.add("Sez");		
		
		List registrationStatusList=new ArrayList();
		registrationStatusList.add("arnGenerated");
		registrationStatusList.add("notApplicable");
		registrationStatusList.add("provisionIdObtained");
		registrationStatusList.add("tobeCommenced");
		registrationStatusList.add("Enrolled");	
		
		List state=new ArrayList();
		state.add("Andaman and Nicobar");
		state.add("Andhra Pradesh");
		state.add("Arunachal Pradesh"); 
		state.add("Assam");
		state.add("Bihar");
		state.add("Chandigarh");
		state.add("Chattisgarh"); 
		state.add("Dadra and Nagar Haveli");
		state.add("Daman & Diu");
		state.add("Delhi");
		state.add("Goa");
		state.add("Gujarat");
		state.add("Haryana");
		state.add("Himachal Pradesh");
		state.add("Jammu & Kashmir");
		state.add("Jharkhand");
		state.add("Karnataka");
		state.add("Kerala");
		state.add("Lakshadweep");
		state.add("Madhya Pradesh");
		state.add("Maharashtra");
		state.add("Manipur");
		state.add("Meghalaya");
		state.add("Mizoram");
		state.add("Nagaland");
		state.add("Orissa");
		state.add("Pondicherry");
		state.add("Punjab");
		state.add("Rajasthan");
		state.add("Sikkim");
		state.add("Tamil Nadu");
		state.add("Telangana");
		state.add("Tripura");
		state.add("Uttar Pradesh");
		state.add("Uttarakhand");
		state.add("West Bengal");
		
		 Map obj=new LinkedHashMap();
		   obj.put("Andaman and Nicobar","35");
		   obj.put("Andhra Pradesh","37");
		   obj.put("Arunachal Pradesh","12");
		   obj.put("Assam","18");
		   obj.put("Bihar","10");
		   obj.put("Chandigarh","04");
		   obj.put("Chattisgarh","22");
		   obj.put("Dadra and Nagar Haveli","26");
		   obj.put("Daman & Diu","25");
		   obj.put("Delhi","07");
		   obj.put("Goa","30");
		   obj.put("Gujarat","24");
		   obj.put("Haryana","06");
		   obj.put("Himachal Pradesh","02");
		   obj.put("Jammu & Kashmir","01");
		   obj.put("Jharkhand","20");
		   obj.put("Karnataka","29");
		   obj.put("Kerala","32");
		   obj.put("Lakshadweep","31");
		   obj.put("Madhya Pradesh","23");
		   obj.put("Maharashtra","27");
		   obj.put("Manipur","14");
		   obj.put("Meghalaya","17");
		   obj.put("Mizoram","15");
		   obj.put("Nagaland","13");
		   obj.put("Orissa","21");
		   obj.put("Pondicherry","34");
		   obj.put("Punjab","03");
		   obj.put("Rajasthan","08");
		   obj.put("Sikkim","11");
		   obj.put("Tamil Nadu","33");
		   obj.put("Telangana","36");
		   obj.put("Tripura","16");
		   obj.put("Uttar Pradesh","09");
		   obj.put("Uttarakhand","05");
		   obj.put("West Bengal","19");
		   
		   
		   
		  
		
		GstDropDownPO gstDropDownPO=new GstDropDownPO();
		gstDropDownPO.setState(state);
		gstDropDownPO.setStateAndStateCode(obj);
		gstDropDownPO.setCob(cob);
		gstDropDownPO.setCustType(custType);		
		gstDropDownPO.setRegistrationStatusList(registrationStatusList);
		
		FLogger.info("GstLogger", "GstUtil", "dropDownList", "dropDownList Method Started");
		return gstDropDownPO;
	}
}
