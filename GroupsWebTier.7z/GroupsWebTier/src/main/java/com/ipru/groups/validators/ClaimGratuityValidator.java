package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.ClaimGratuityLeavePO;
import com.ipru.groups.po.ClaimGratuityPO;
import com.ipru.groups.po.ClaimGratuityWithDrawalUnitPO;
import com.ipru.groups.po.CoiPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.utilities.JsonUtils;
import com.tcs.logger.FLogger;

public class ClaimGratuityValidator {

	public String validateClaimGratuity(ClaimGratuityPO claimGratuityPO) throws Exception {

		FLogger.info("ClaimGratuityLogger", "ClaimGratuityValidator", "validateClaimGratuity", "Method start");
		
		Set<ClaimGratuityWithDrawalUnitPO> claimGratuityWithDrawalUnitPO=null;
		String claimType=claimGratuityPO.getClaimType();
		String majorMinor=claimGratuityPO.getMajorMinor();
		Set<ClaimGratuityLeavePO> claimGratuityLeavePO=new HashSet<ClaimGratuityLeavePO>();
		if(!CollectionUtils.isEmpty(claimGratuityPO.getLeaveArray()))
		{
			claimGratuityLeavePO=claimGratuityPO.getLeaveArray();
		}
		

		List<String> relationList=new ArrayList<String>();
		relationList.add("Father");
		relationList.add("Mother");
		relationList.add("Daughter");
		relationList.add("Son");
		List<String> claimTypes=new ArrayList<String>();
		claimTypes.add("death");
		claimTypes.add("retirement");
		claimTypes.add("resignation");

		StringBuilder errorMessage = new StringBuilder();
		if (!validateWithDrawalPercentage(claimGratuityPO.getWithdrawalUnit())) {
			errorMessage.append("Withdrawal Percentage should be 100%");
		}
		if (!validateClaimtype(claimGratuityPO.getClaimType(),claimTypes)) {
			errorMessage.append("ClaimType is Not Valid");
		}
		if(!validateName(claimGratuityPO.getEmployeeName(),30))
		{
			errorMessage.append("Employee Name Should be lessthan 30 character");
		}
		if (!validateEmpId(claimGratuityPO.getMemberId())) {
			errorMessage.append("Please Enter Valid Member Id");
		}
		if (!validateDob(claimGratuityPO.getDoj())) {
			errorMessage.append("Invalid Date Of Joining");
		}
		if (!validateDob(claimGratuityPO.getLwd())) {
			errorMessage.append("Invalid Last Working day");
		}
		/*if (!validateLastDrawnSalary(claimGratuityPO.getLastDrawnSalary())) {
			errorMessage.append("Invalid Last Drawan salary");
		}*/
		if (!validateNameOfPayee(claimGratuityPO.getPayeeName())) {
			errorMessage.append("Payee Name is not valid");
		}
		
		for(ClaimGratuityLeavePO leave:claimGratuityLeavePO)
		{
			if(!(leave.getFromDate().equals("")) && !(leave.getToDate().equals("")))
			{
				if (!validateLeaveDates(leave.getFromDate(),leave.getToDate())) {
					errorMessage.append("Leave Taken To Date Should not be less Than From Date");
				}
				
			}
		}
		
		
		if (claimType.equalsIgnoreCase("death")) {
			
			if (!validateDob(claimGratuityPO.getDateOfDeath())) {
				errorMessage.append("Invalid Date Of Death");
			}
			if (!validatecauseOfClaim(claimGratuityPO.getCauseOfClaim())) {
				errorMessage.append("Invalid Cause Of Claim");
			}
			if (!validateAddress(claimGratuityPO.getAddressLine1())) {
				errorMessage.append("Invalid AddressLine1");
			}
			if (!validateAddress(claimGratuityPO.getAddressLine2())) {
				errorMessage.append("Invalid AddressLine2");
			}
			if (!validateAddress(claimGratuityPO.getAddressLine3())) {
				errorMessage.append("Invalid AddressLine3");
			}
			
			if (!validateNatureOfDisability(claimGratuityPO.getDisability())) {
				errorMessage.append("Nature of disability is not valid");
			}
			
			
			if(!validateName(claimGratuityPO.getBeneficiaryFirstName(),30))
			{
				errorMessage.append("Beneficiary FirstName Count Should be lessthan 30 character");
			}
			
			if(!validateName(claimGratuityPO.getBeneficiaryMiddleName(),30))
			{
				errorMessage.append("Beneficiary MiddleName Count Should be lessthan 30 character");
			}
			
			if(!validateName(claimGratuityPO.getBeneficiarySurName(),30))
			{
				errorMessage.append("Beneficiary SurName Count Should be lessthan 30 character");
			}
			
			if(!validateBenAppointeeRelation(claimGratuityPO.getBeneficiaryRelation(),relationList))
			{
				errorMessage.append("Beneficiary Relation Should not be null");
			}
			
			if (!validateDob(claimGratuityPO.getDateOfDeath())) {
				errorMessage.append("Invalid Date Of Death");
			}
			if(majorMinor.equalsIgnoreCase("minor"))
			{				
		
			if(!validateName(claimGratuityPO.getAppointeeFirstName(),30))
			{
				errorMessage.append("Appointee FirstName Count Should be lessthan 30 character");
			}
			if(!validateName(claimGratuityPO.getAppointeeMiddleName(),30))
			{
				errorMessage.append("Appointee MiddleName Count Should be lessthan 30 character");
			}
			if(!validateName(claimGratuityPO.getAppointeeSurName(),30))
			{
				errorMessage.append("Appointee SurName Count Should be lessthan 30 character");
			}
			if(!validateName(claimGratuityPO.getAppointeeRelation(),30))
			{
				errorMessage.append("Appointee Relation Count Should be lessthan 30 character");
			}
			}
		
		}
		
		
		
		if (!validateDob(claimGratuityPO.getDob())) {
			errorMessage.append("Invalid Date Of Birth");
		}
		
		
		
		if (!validatePolicy(claimGratuityPO.getPolicyNumber())) {
			errorMessage.append("Please Enter Valid Policy Number");
		}
		

		FLogger.info("ClaimGratuityLogger", "ClaimGratuityValidator", "validateClaimGratuity", "Method end with message" + errorMessage.toString());

		return errorMessage.toString();
	}

	

	public boolean validateWithDrawalPercentage(Set<ClaimGratuityWithDrawalUnitPO> withDrawalUnitList) {
		//StringBuilder errorMessage = new StringBuilder();
		int totalpercentage=0;
		boolean valid=true;
		
		for(ClaimGratuityWithDrawalUnitPO withDrawalUnitSet:withDrawalUnitList)
		{
			totalpercentage=totalpercentage+withDrawalUnitSet.getWithdrawalPercent();
		}
		
		if(totalpercentage!=100)
		{
			valid=false;
			
		}
		

		return valid;
	}

	private boolean validatePolicy(String policyNumber) {

		if (CommonValidationUtil.ValidateRequired(policyNumber) && CommonValidationUtil.ValidateNumeric(policyNumber) && CommonValidationUtil.ValidateMaxLength(policyNumber, 8)) {
			return true;

		}
		else {
			return false;
		}
	}
	
	private boolean validateEmpId(String empId) {

		if (CommonValidationUtil.ValidateRequired(empId) && CommonValidationUtil.ValidateNumeric(empId)&& StringUtils.isNotEmpty(empId)) {
			return true;

		}
		else {
			return false;
		}
	}
	
	private boolean validateLastDrawnSalary(Long salary) {

		if (CommonValidationUtil.ValidateRequired(salary)) {
			return true;

		}
		else {
			return false;
		}
	}

	



	private boolean validateCompanyAddress(String companyName) {

		if (CommonValidationUtil.ValidateAddress(companyName)) {
			return true;

		}
		else {
			return false;
		}
	}
	

	
	private boolean validateDob(String dod) throws ParseException {
		if (StringUtils.isNotEmpty(dod)) {
			SimpleDateFormat format1 = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
			Date date1 = format1.parse(dod);
			Date today = new Date();
			if (date1.before(today)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	private boolean validateName(String val, Integer num) {
		
		if (StringUtils.isNotEmpty(val) && StringUtils.isAlphaSpace(val) && CommonValidationUtil.ValidateMaxLength(val, num)) {
			return true;

		}
		else {
			return false;
		}

	}
	
	private boolean validateAddress(String address) {
		if ((CommonValidationUtil.isMatchedPattern(address, GroupFormValidationConstant.ADDRESS_VALIDATION) && StringUtils.isNotBlank(address))) {
			return true;
		}
		else {
			return false;
		}
	}
	
private boolean validateNameOfPayee(String val) {
		
		if (StringUtils.isNotEmpty(val) && StringUtils.isAlphaSpace(val)) {
			return true;

		}
		else {
			return false;
		}

	}
private boolean validatecauseOfClaim(String val) {
		
		if (StringUtils.isNotEmpty(val) && StringUtils.isAlphaSpace(val)) {
			return true;

		}
		else {
			return false;
		}

	}
	
	private boolean validateBenAppointeeRelation(String val,List<String> relationList) {
		
		boolean flag=false;
		
		
		if(relationList.contains(val))
		{
			flag=true;
		}
		
		
		
		return flag;
		
	}
	
	private boolean validateClaimtype(String val,List<String> claimType) {
		
		boolean flag=false;
		
		
		if(claimType.contains(val))
		{
			flag=true;
		}
		
		
		
		return flag;
		
	}
	
private boolean validateNatureOfDisability(String val) {
		
		if (StringUtils.isNotEmpty(val) && StringUtils.isAlphaSpace(val)) {
			return true;

		}
		else {
			return false;
		}

	}

private boolean validateLeaveDates(String frmDate,String toDate) throws ParseException {
	if (StringUtils.isNotEmpty(frmDate) && StringUtils.isNotEmpty(toDate)) {
		SimpleDateFormat format1 = new SimpleDateFormat("mm/dd/yyyy", Locale.ENGLISH);
		Date fromDate = format1.parse(frmDate);
		Date toDate1 = format1.parse(toDate);
		//Date today = new Date();
		if (fromDate.before(toDate1) || fromDate.equals(toDate1)) {
			return true;
		}
		else {
			return false;
		}
	}
	else {
		return false;
	}
}
	
	public String  validatePolicyEmpId(ClaimGratuityPO claimGratuityPO)
	{
		StringBuilder errorMessage = new StringBuilder();
		
		if (!validatePolicy(claimGratuityPO.getPolicyNumber())) {
			errorMessage.append("Please Enter Valid Policy Number");
		}
		if (!validateEmpId(claimGratuityPO.getMemberId())) {
			errorMessage.append("Please Enter Valid Member Id");
		}
		
		return errorMessage.toString();
	}
	
	
	
	 private static final String CLASSNAME = ClaimGratuityValidator.class
             .getCanonicalName();
	 private static ClaimGratuityValidator instance;
	 
	 public static ClaimGratuityValidator getInstance() {
         if (instance == null) {
                         synchronized (CLASSNAME) {
                                         instance = new ClaimGratuityValidator();
                         }
         }
         return instance;
}
	 
	 
	
	
}
