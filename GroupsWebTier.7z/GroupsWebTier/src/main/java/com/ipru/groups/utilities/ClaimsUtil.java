package com.ipru.groups.utilities;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.enums.ClaimsEnum;
import com.ipru.groups.po.BeneficiaryPO;
import com.ipru.groups.po.ClaimBeneficiaryPO;
import com.ipru.groups.po.ClaimsDeathNonDeathPO;
import com.ipru.groups.po.ClaimsRequestPO;
import com.ipru.groups.po.ClaimsRequestTransactionPO;
import com.ipru.groups.po.ClaimsSubmitPO;
import com.ipru.groups.po.DownloadFileRequestPO;
import com.ipru.groups.vo.ClaimsBeneficiaryVO;
import com.ipru.groups.vo.ClaimsRequestTransactionVO;
import com.ipru.groups.vo.ClaimsRequestVO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.UploadFileVO;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public class ClaimsUtil {

	public List getClaimsBeneficiaryList(ClaimsSubmitPO claimsSubmitPO) throws IPruException {
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getClaimsBeneficiaryList", "getClaimsRequestList Method Start");

		List<ClaimBeneficiaryPO> claimsBeneficiaryList = new ArrayList<ClaimBeneficiaryPO>();

		int i = 1;
		for (BeneficiaryPO beneficiaryPO : claimsSubmitPO.getBeneficiary()) {
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getBeneficiaryDOB(), ClaimsEnum.beneficiaryDOB.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getBankAccountNUMBER(), ClaimsEnum.bankAccountNumber.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getBankName(), ClaimsEnum.bankName.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getBeneficiaryName(), ClaimsEnum.beneficiaryName.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getStreetOrArea(), ClaimsEnum.areaOrStreet.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getCity(), ClaimsEnum.city.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getState(), ClaimsEnum.states.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getFlatOrUnitNumber(), ClaimsEnum.flatOrUnitNumber.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getPincode(), ClaimsEnum.pinCord.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getSharePercentage(), ClaimsEnum.share.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getLandmark(), ClaimsEnum.landMark.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getIfscCode(), ClaimsEnum.IFSCcode.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getCompanyOrBuildingName(), ClaimsEnum.companyOrBuildingName.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getAppointeeName(), ClaimsEnum.appointeeName.name(), String.valueOf(i)));
			claimsBeneficiaryList.add(createClaimBeneficiaryPO(beneficiaryPO.getRelation(), ClaimsEnum.relation.name(), String.valueOf(i)));
			i++;

		}

		if (CollectionUtils.isEmpty(claimsBeneficiaryList)) {
			FLogger.error("ClaimsLogger", "ClaimsUtil", "getClaimsBeneficiaryList", "claimsBeneficiaryList is null");
			throw new IPruException("Error", "GRPCL03", "claimsBeneficiaryList is null");
		}

		FLogger.info("ClaimsLogger", "ClaimsUtil", "getClaimsBeneficiaryList", "getClaimsRequestList Method End");

		return claimsBeneficiaryList;
	}

	public List getClaimsRequestList(ClaimsSubmitPO claimsSubmitPO,String productType) throws IPruException {

		FLogger.info("ClaimsLogger", "ClaimsUtil", "getClaimsRequestList", "getClaimsRequestList Method Start");

		List<ClaimsRequestPO> claimsRequestList = new ArrayList<ClaimsRequestPO>();

		claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getEmployeeId(), ClaimsEnum.employeeId.name()));
		claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getEmployeeName(), ClaimsEnum.employeeName.name()));		
		claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getCause(), ClaimsEnum.claimCause.name()));
		claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getEventDate(), ClaimsEnum.claimEventDate.name()));
		claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getPan(), ClaimsEnum.panName.name()));
		if(!productType.equals("TERM")){
			claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getCommutation(), ClaimsEnum.commutationPercentage.name()));
			claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getGratuityApplicable(), ClaimsEnum.gratuityApplicable.name()));
			claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getMobileNumber(), ClaimsEnum.mobileNumber.name()));			
			claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getEmployeeEmailId_1(), ClaimsEnum.employeeEmailId_1.name()));
			claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getEmployeeEmailId_2(), ClaimsEnum.employeeEmailId_2.name()));
			claimsRequestList.add(createClaimsRequestPO(claimsSubmitPO.getAnnuity(), ClaimsEnum.annuityPercentage.name()));
		}
		

		if (CollectionUtils.isEmpty(claimsRequestList)) {
			FLogger.error("ClaimsLogger", "ClaimsUtil", "getClaimsRequestList", "claimsRequestList is null");
			throw new IPruException("Error", "GRPCL03", "claimsRequestList is null");
		}

		FLogger.info("ClaimsLogger", "ClaimsUtil", "getClaimsRequestList", "getClaimsRequestList Method End");
		return claimsRequestList;
	}

	private ClaimBeneficiaryPO createClaimBeneficiaryPO(String newValue, String fieldName, String beneficiaryPos) {

		FLogger.info("ClaimsLogger", "ClaimsUtil", "createClaimBeneficiaryPO", "createClaimBeneficiaryPO Method Start");

		ClaimBeneficiaryPO claimBeneficiaryPO = new ClaimBeneficiaryPO();
		claimBeneficiaryPO.setNewValue(newValue);
		claimBeneficiaryPO.setFieldName(fieldName);
		claimBeneficiaryPO.setBeneficiaryPos(beneficiaryPos);

		FLogger.info("ClaimsLogger", "ClaimsUtil", "createClaimBeneficiaryPO", "createClaimBeneficiaryPO Method End");
		return claimBeneficiaryPO;
	}

	private ClaimsRequestPO createClaimsRequestPO(String newValue, String fieldName) {

		FLogger.info("ClaimsLogger", "ClaimsUtil", "createClaimsRequestPO", "createClaimsRequestPO Method Start");

		ClaimsRequestPO claimsRequestPO = new ClaimsRequestPO();
		claimsRequestPO.setNewValue(newValue);
		claimsRequestPO.setFieldName(fieldName);

		FLogger.info("ClaimsLogger", "ClaimsUtil", "createClaimsRequestPO", "createClaimsRequestPO Method End");
		return claimsRequestPO;

	}

	public ClaimsRequestTransactionVO getclaimsRequestTransactionVO(List<ClaimsRequestVO> claimsRequestVOList, List<ClaimsBeneficiaryVO> claimsBeneficiaryVOList, ClaimsSubmitPO claimsSubmitPO, Map<String, FieldAccessMappingVO> map, RequestContext p_ObjContext) throws Exception {
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getclaimsRequestTransactionVO", "getclaimsRequestTransactionVO Method Start");
		HttpSession httpSession = ((HttpServletRequest) ((RequestContext) p_ObjContext).getExternalContext().getNativeRequest()).getSession();// get
																																				// HttpSessionObject
		IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
		if (userVo == null) {
			FLogger.error("ClaimsLogger", "ClaimsUtil", "getclaimsRequestTransactionVO", "userVo Should not be null");
			throw new IPruException("Error", "GRPCL03", "Some Thing Went Wrong Please Try Again!");
		}
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getclaimsRequestTransactionVO", "getProfileUpdateDataForEdit Method  PolicyNumber:" + userVo.getPolicyNo() + " userVo.getClientId()"
				+ userVo.getClientId() + " Role" + userVo.getRoles());

		ClaimsRequestTransactionVO claimsRequestTransactionVO = new ClaimsRequestTransactionVO();

		claimsRequestTransactionVO.setPolicyNo(userVo.getPolicyNo());
		claimsRequestTransactionVO.setClientId(userVo.getClientId());
		claimsRequestTransactionVO.setRole(userVo.getRoles());
		claimsRequestTransactionVO.setMemberType(userVo.getRoleType());
		claimsRequestTransactionVO.setProductType(userVo.getProductType());
		claimsRequestTransactionVO.setUnitId(userVo.getUnitCode());
		claimsRequestTransactionVO.setMemberId(userVo.getEmpId());
		claimsRequestTransactionVO.setProductType(userVo.getProductType());
		/*if(userVo.getRoleType().equals("GTRUST") || userVo.getRoleType().equals("TERM")){
			claimsRequestTransactionVO.setApprovalStatus("APPROVED");
		}else{
			claimsRequestTransactionVO.setApprovalStatus("PENDING");
		}*/
		
		//claimsRequestTransactionVO.setApprovalStatus("PENDING");
		claimsRequestTransactionVO.setClaimType("DEATH_CLAIM");
		claimsRequestTransactionVO.setCurrentDate(new Date());

		for (ClaimsRequestVO claimsRequestVO : claimsRequestVOList) {
			Iterator itr = map.entrySet().iterator();
			while (itr.hasNext()) {

				Map.Entry pair = (Map.Entry) itr.next();
				if (pair.getKey().equals(claimsRequestVO.getFieldName())) {
					FieldAccessMappingVO profile = (FieldAccessMappingVO) pair.getValue();
					claimsRequestVO.setFieldCode(String.valueOf(profile.getRdComponentPosId()));
					claimsRequestVO.setFieldGroupCode(String.valueOf(profile.getRdParentComponentId()));
					claimsRequestVO.setClientId(userVo.getClientId());
					claimsRequestVO.setCurrentDate(new Date());
					claimsRequestVO.setCategory("i");
					claimsRequestTransactionVO.getClaimsRequestVOSet().add(claimsRequestVO);

				}// end of pair if

			}// end of while

		}// end of for

		for (ClaimsBeneficiaryVO claimsBeneficiaryVO : claimsBeneficiaryVOList) {
			Iterator itr = map.entrySet().iterator();
			while (itr.hasNext()) {

				Map.Entry pair = (Map.Entry) itr.next();
				if (pair.getKey().equals(claimsBeneficiaryVO.getFieldName())) {
					FieldAccessMappingVO profile = (FieldAccessMappingVO) pair.getValue();
					claimsBeneficiaryVO.setFieldCode(String.valueOf(profile.getRdComponentPosId()));
					claimsBeneficiaryVO.setFieldGroupCode(String.valueOf(profile.getRdParentComponentId()));
					claimsBeneficiaryVO.setClientId(userVo.getClientId());
					claimsBeneficiaryVO.setCurrentDate(new Date());
					claimsBeneficiaryVO.setCategory("i");
					claimsRequestTransactionVO.getClaimsBeneficiaryVOSet().add(claimsBeneficiaryVO);

				}// end of pair if

			}// end of while

		}// end of for

		FLogger.info("ClaimsLogger", "ClaimsUtil", "getclaimsRequestTransactionVO", "getclaimsRequestTransactionVO Method End");
		return claimsRequestTransactionVO;
	}

	public ClaimsDeathNonDeathPO getClaimsDeathNonDeathList(List<ClaimsRequestTransactionPO> claimsRequestTransactionPOList) throws IPruException {
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getClaimsDeathNonDeathList", "getClaimsDeathNonDeathList Method Start");
		ClaimsDeathNonDeathPO claimsDeathNonDeathPO = null;

		List<ClaimsRequestTransactionPO> deathList = new ArrayList<ClaimsRequestTransactionPO>();
		List<ClaimsRequestTransactionPO> nonDeathList = new ArrayList<ClaimsRequestTransactionPO>();

		if (claimsRequestTransactionPOList != null) {

			claimsDeathNonDeathPO = new ClaimsDeathNonDeathPO();
			for (ClaimsRequestTransactionPO claimsRequestTransactionPO : claimsRequestTransactionPOList) {
				if (claimsRequestTransactionPO.getClaimType().equals("DEATH_CLAIM")) {
					deathList.add(claimsRequestTransactionPO);
				}
				if (claimsRequestTransactionPO.getClaimType().equals("NON_DEATH_CLAIM")) {
					nonDeathList.add(claimsRequestTransactionPO);
				}
			}
			claimsDeathNonDeathPO.setDeathList(deathList);
			claimsDeathNonDeathPO.setNonDeathList(nonDeathList);
		}
		else {
			FLogger.error("ClaimsLogger", "ClaimsUtil", "getDownloadData", "claimsRequestTransactionPOList Should not be null");
			throw new IPruException("Error", "GRPCL03", "claimsRequestTransactionPOList Should not be null");
		}
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getClaimsDeathNonDeathList", "getClaimsDeathNonDeathList Method End");
		return claimsDeathNonDeathPO;
	}

	public List<ClaimsRequestTransactionVO> getClaimsRequestTransactionVOList(Map<String, ClaimsRequestTransactionVO> claimsRequestTransactionVOMap, List<ClaimsRequestTransactionPO> claimsRequestTransactionPOList) throws IPruException {
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getClaimsRequestTransactionVOList", "getClaimsRequestTransactionVOList Method Start");
		List<ClaimsRequestTransactionVO> claimsRequestTransactionVOList = null;
		if (claimsRequestTransactionVOMap != null && claimsRequestTransactionPOList != null) {
			claimsRequestTransactionVOList = new ArrayList<ClaimsRequestTransactionVO>();
			for (ClaimsRequestTransactionPO claimsRequestTransactionPO : claimsRequestTransactionPOList) {

				String txnId = String.valueOf(claimsRequestTransactionPO.getCustomerTrxnId());
				claimsRequestTransactionVOList.add(claimsRequestTransactionVOMap.get(txnId));
			}
		}else{
			FLogger.error("ClaimsLogger", "ClaimsUtil", "getDownloadData", "claimsRequestTransactionVOMap and claimsRequestTransactionPOList Should not be null");
			throw new IPruException("Error", "GRPCL03", "claimsRequestTransactionVOMap and claimsRequestTransactionPOList Should not be null");
		}
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getClaimsRequestTransactionVOList", "getClaimsRequestTransactionVOList Method End");
		return claimsRequestTransactionVOList;
	}

	public DownloadFileRequestPO getDownloadData(Map<String, ClaimsRequestTransactionVO> claimsRequestTransactionVOMap, ClaimsRequestTransactionVO claimsRequestTransactionVO) throws IPruException {
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getDownloadData", "getDownloadData Method Start");
		DownloadFileRequestPO downloadFileRequestPO = null;
		if (!claimsRequestTransactionVOMap.equals(null) && !claimsRequestTransactionVO.equals(null)) {

			claimsRequestTransactionVO = (ClaimsRequestTransactionVO) claimsRequestTransactionVOMap.get(String.valueOf(claimsRequestTransactionVO.getCustomerTrxnId()));
			UploadFileVO uploadFileVO = new UploadFileVO();
			if(CollectionUtils.isNotEmpty(claimsRequestTransactionVO.getUploadFileVOSet())){
				uploadFileVO.setDocId(claimsRequestTransactionVO.getUploadFileVOSet().iterator().next().getDocId());
				claimsRequestTransactionVO.getUploadFileVOSet();
				downloadFileRequestPO = new DownloadFileRequestPO();
				downloadFileRequestPO.setFileId(String.valueOf(uploadFileVO.getDocId()));
				downloadFileRequestPO.setFileName("Claim_Data");
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(new Date());
				downloadFileRequestPO.setTimeToken(calendar.getTimeInMillis());
			}else{
				FLogger.error("ClaimsLogger", "ClaimsUtil", "getDownloadData", "Uploaded file Should not be null");
				throw new IPruException("Error", "GRPCL03", "File Not Found");				
			}			
		}
		else {
			FLogger.error("ClaimsLogger", "ClaimsUtil", "getDownloadData", "claimsRequestTransactionVOMap and claimsRequestTransactionVO Should not be null");
			throw new IPruException("Error", "GRPCL03", "File Not Found");
		}
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getDownloadData", "getDownloadData Method End");
		return downloadFileRequestPO;
	}

	public ClaimsSubmitPO getClaimsSubmitData(List<ClaimsRequestTransactionPO> claimsRequestTransactionPOList) throws IPruException {
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getClaimsSubmitData", "getClaimsSubmitData Method Start");
		ClaimsSubmitPO claimsSubmitPO = new ClaimsSubmitPO();
		for (ClaimsRequestTransactionPO claimsRequestTransactionPO : claimsRequestTransactionPOList) {

			claimsSubmitPO = claimsData(claimsRequestTransactionPO);
			claimsSubmitPO.setTransactionId(claimsRequestTransactionPO.getCustomerTrxnId());
		}
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getClaimsSubmitData", "getClaimsSubmitData Method End");
		return claimsSubmitPO;
	}

	public ClaimsSubmitPO claimsData(ClaimsRequestTransactionPO claimsRequestTransactionPO) throws IPruException {
		FLogger.info("ClaimsLogger", "ClaimsUtil", "claimsData", "claimsData Method Start");
		String fieldName = null;
		String msg = null;
		ClaimsSubmitPO claimsSubmitPO = new ClaimsSubmitPO();
		if(!claimsRequestTransactionPO.equals(null)){
		for (ClaimsRequestPO claimsRequestPO : claimsRequestTransactionPO.getClaimsRequestVOSet()) {
			//System.out.println(claimsRequestPO.getFieldName());
			fieldName = claimsRequestPO.getFieldName();
			ClaimsEnum val = ClaimsEnum.valueOf(fieldName);

			switch (val) {
				case employeeId:
					claimsSubmitPO.setEmployeeId(claimsRequestPO.getNewValue());
					break;
				case employeeName:
					claimsSubmitPO.setEmployeeName(claimsRequestPO.getNewValue());
					break;
				case annuityPercentage:
					claimsSubmitPO.setAnnuity(claimsRequestPO.getNewValue());
					break;
				case claimCause:
					claimsSubmitPO.setCause(claimsRequestPO.getNewValue());
					break;
				case claimEventDate:
					claimsSubmitPO.setEventDate(claimsRequestPO.getNewValue());
					break;
				case commutationPercentage:
					claimsSubmitPO.setCommutation(claimsRequestPO.getNewValue());
					break;
				case gratuityApplicable:
					claimsSubmitPO.setGratuityApplicable(claimsRequestPO.getNewValue());
					break;
				case mobileNumber:
					claimsSubmitPO.setMobileNumber(claimsRequestPO.getNewValue());
					break;
				case panName:
					claimsSubmitPO.setPan(claimsRequestPO.getNewValue());
					break;
				case employeeEmailId_1:
					claimsSubmitPO.setEmployeeEmailId_1(claimsRequestPO.getNewValue());
					break;
				case employeeEmailId_2:
					claimsSubmitPO.setEmployeeEmailId_2(claimsRequestPO.getNewValue());
					break;
				default:
					msg = "invalid Data";
					break;
			}

		}
	}else{
		FLogger.error("ClaimsLogger", "ClaimsUtil", "claimsData", "claimsRequestTransactionPO Should not be null");
		throw new IPruException("Error", "GRPCL03", "claimsRequestTransactionPO should not be null");
	}

		Set<ClaimBeneficiaryPO> claimsBeneficiaryVOSet = claimsRequestTransactionPO.getClaimsBeneficiaryVOSet();

		if (claimsBeneficiaryVOSet != null) {

			Map<String, List<ClaimBeneficiaryPO>> beneficiaryPOMap = this.getBeneficiaryMap(claimsBeneficiaryVOSet);

			List<BeneficiaryPO> beneficiaryPOList = new ArrayList<BeneficiaryPO>();

			Iterator it = beneficiaryPOMap.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry) it.next();

				String benPos = (String) pair.getKey();
				List<ClaimBeneficiaryPO> benPOList = (List<ClaimBeneficiaryPO>) pair.getValue();

				BeneficiaryPO beneficiaryPO = new BeneficiaryPO();

				for (ClaimBeneficiaryPO claimsBeneficiaryPO : benPOList) {
					fieldName = claimsBeneficiaryPO.getFieldName();
					ClaimsEnum val = ClaimsEnum.valueOf(fieldName);

					switch (val) {
						case beneficiaryName:
							beneficiaryPO.setBeneficiaryName(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case beneficiaryDOB:
							beneficiaryPO.setBeneficiaryDOB(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case appointeeName:
							beneficiaryPO.setAppointeeName(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case share:
							beneficiaryPO.setSharePercentage(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case relation:
							beneficiaryPO.setRelation(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case companyOrBuildingName:
							beneficiaryPO.setCompanyOrBuildingName(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case flatOrUnitNumber:
							beneficiaryPO.setFlatOrUnitNumber(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case areaOrStreet:
							beneficiaryPO.setStreetOrArea(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case landMark:
							beneficiaryPO.setLandmark(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case pinCord:
							beneficiaryPO.setPincode(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case states:
							beneficiaryPO.setState(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case city:
							beneficiaryPO.setCity(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case bankAccountNumber:
							beneficiaryPO.setBankAccountNUMBER(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case bankName:
							beneficiaryPO.setBankName(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						case IFSCcode:
							beneficiaryPO.setIfscCode(claimsBeneficiaryPO.getNewValue());
							beneficiaryPO.setBenPos(claimsBeneficiaryPO.getBeneficiaryPos());
							break;
						default:
							msg = "invalid Data";
							break;
					}
				}

				beneficiaryPOList.add(beneficiaryPO);

			}

			claimsSubmitPO.setBeneficiary(beneficiaryPOList);
		}
		FLogger.info("ClaimsLogger", "ClaimsUtil", "claimsData", "claimsData Method End");
		return claimsSubmitPO;
	}

	public Map<String, List<ClaimBeneficiaryPO>> getBeneficiaryMap(Set<ClaimBeneficiaryPO> claimsBeneficiaryVOSet) throws IPruException {
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getBeneficiaryMap", "getBeneficiaryMap Method Start");
		Map<String, List<ClaimBeneficiaryPO>> beneficiaryPOMap = null;

		if (claimsBeneficiaryVOSet != null) {
			beneficiaryPOMap = new HashMap<String, List<ClaimBeneficiaryPO>>();

			for (ClaimBeneficiaryPO claimsBeneficiaryPO : claimsBeneficiaryVOSet) {
				String benPos = claimsBeneficiaryPO.getBeneficiaryPos();

				if (beneficiaryPOMap.get(benPos) == null) {
					List<ClaimBeneficiaryPO> benList = new ArrayList<ClaimBeneficiaryPO>();
					benList.add(claimsBeneficiaryPO);
					beneficiaryPOMap.put(benPos, benList);
				}
				else {
					List<ClaimBeneficiaryPO> benList = beneficiaryPOMap.get(benPos);
					benList.add(claimsBeneficiaryPO);
					beneficiaryPOMap.put(benPos, benList);
				}
			}
		}else{
			FLogger.error("ClaimsLogger", "ClaimsUtil", "getBeneficiaryMap", "claimsBeneficiaryVOSet Should not be null");
			throw new IPruException("Error", "GRPCL03", "claimsBeneficiaryVOSet should not be null");
		}
		FLogger.info("ClaimsLogger", "ClaimsUtil", "getBeneficiaryMap", "getBeneficiaryMap Method End");
		return beneficiaryPOMap;
	}

}
