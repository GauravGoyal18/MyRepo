package com.ipru.groups.viewpreparer;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//import com.tcs.logger.FLogger;

import java.io.Serializable;

import org.apache.tiles.Attribute;
import org.apache.tiles.AttributeContext;
import org.apache.tiles.preparer.ViewPreparer;
import org.apache.tiles.request.Request;

/**
 *
 * @author 318786
 */
public class TilesViewer implements Serializable, ViewPreparer {

    private static String s_StrUrl;
    

    public void execute(Request reqContext, AttributeContext attrContext) {
      
    	attrContext.setTemplateAttribute(Attribute.createTemplateAttribute(s_StrUrl));
		//Tushit changes : attrContext.setTemplate(s_StrUrl);
    }

    public String getUrl() {
      
        return s_StrUrl;
    }

    public void setUrl(String p_StrUrl) {
    	
      
        TilesViewer.s_StrUrl = p_StrUrl;
       
    }
}