package com.ipru.groups.viewpreparer;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//import com.tcs.logger.FLogger;
import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

import org.apache.tiles.Attribute;
import org.apache.tiles.AttributeContext;
import org.apache.tiles.preparer.ViewPreparer;
import org.apache.tiles.request.Request;
import org.apache.tiles.request.servlet.ServletUtil;

import com.tcs.logger.FLogger;
import com.tcs.po.TemplatePO;
import com.tcs.session.constants.SessionConstants;

/**
 * 
 * @author 318786
 */
@SuppressWarnings("serial")
public class TilesLayoutManager implements Serializable, ViewPreparer {

	public void execute(Request reqContext,
			AttributeContext attrContext) {
		////System.out.println("Tiles layout manager called");
		FLogger.info("GROUPLogger", "TilesViewer", "execute",
				"method that gets triggered if viewpreparer is called from tiles");
		HttpServletRequest req = (HttpServletRequest) ServletUtil.getServletRequest(reqContext).getRequest();

		// read layout from templateVO
		
		TemplatePO l_ObjTempPO = (TemplatePO) req
				.getAttribute(SessionConstants.TEMPLATE_PO);// (TemplatePO)
															// req.getSession().getAttribute(SessionConstants.TEMPLATE_PO);//
		
		// Getting Layout from TemplatePO
		String l_StrLayout;
		String l_StrTheme;
		/*if (l_ObjTempPO == null) {
			l_StrLayout = "desktop";// l_ObjTempPO.getM_Layout();
			l_StrTheme = "themeA";// l_ObjTempPO.getM_Theme();
		} else {
			l_StrLayout = l_ObjTempPO.getM_Layout();
			l_StrTheme = l_ObjTempPO.getM_Theme();

		}*/

		
		Attribute attr1 = new Attribute(attrContext.getAttribute("header"));
		Attribute attr3 = new Attribute(attrContext.getAttribute("footer"));
		attrContext.setTemplateAttribute(Attribute.createTemplateAttribute(""+ attrContext.getTemplateAttribute()));
		//Tushit changes :attrContext.setTemplate("/WEB-INF/layouts/" + l_StrLayout + attrContext.getTemplate());
		//attrContext.setTemplate("/WEB-INF/Layouts/layoutA/standard/home.jsp");
		//Attribute attr2 = new Attribute("Dev/" + l_StrTheme + "/Css/Theme.css");
		//attrContext.putAttribute("ThemeCss", attr2);

		// set theme
		attrContext.putAttribute("header", attr1);
		attrContext.putAttribute("footer", attr3);
	}

	public String getUrl() {
		FLogger.info("GROUPLogger", "TilesViewer", "getUrl",
				"method te retreive Url");

		return null;
	}

}