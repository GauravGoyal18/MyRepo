package com.ipru.groups.handler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.BrokerPaidCommissionVO;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BrokerPaidCommissionHandler extends IneoBaseHandler {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String ErrorMsg = "Something went wrong please try again!";
	private static final String CLASS_NAME = BrokerPaidCommissionHandler.class.getCanonicalName();
	private static final String INFO_LOGGER_NAME = "BrokerPaidCommissionLogger";
	private static final String ERROR_LOGGER_NAME = "BrokerPaidCommissionLogger";

	@MethodPost
	public Event getBizRequestforPaidCommissionOnLoad(RequestContext p_ObjContext) throws Exception {
		final String METHOD_NAME = "getBizRequestforPaidCommissionOnLoad";
		try {
			Properties prop = new Properties();
			prop = MasterPropertiesFileLoader.CONSTANT_BROKER_PROPERTIES;

			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();

			String getpropertyStartDate = prop.getProperty("startDate");

			String brokerCode = null;

			if (httpSession != null) {
				IPruUser userVO = (IPruUser) httpSession.getAttribute("userVO");

				if (userVO == null) {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVO should not be null");
					throw new IPruException("Error", "GRPPCB01", "userVO should not be null");
				}

				FscDetailsVO fscDetailVo = userVO.getFscdetails();
				if (fscDetailVo == null) {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "fscDetailVo should not be null");
					throw new IPruException("Error", "GRPPCB01", "fscDetailVo should not be null");
				}

				brokerCode = fscDetailVo.getBranchCode() != null ? fscDetailVo.getBranchCode() : fscDetailVo.getNationalCode();

				if (StringUtils.isEmpty(brokerCode)) {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "brokerCode should not be null");
					throw new IPruException("Error", "GRPPCB01", "fscDetailVo should not be null");
				}

				SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MMM-yyyy");
				Date getProprtyDate = sdf2.parse(getpropertyStartDate);
				String startDate = sdf2.format(getProprtyDate);
				String endDate = sdf2.format(new Date());

				BrokerPaidCommissionVO brokerPaidCommissionVO = new BrokerPaidCommissionVO();
				brokerPaidCommissionVO.setStartDate(startDate);
				brokerPaidCommissionVO.setEndDate(endDate);
				brokerPaidCommissionVO.setBrokerCode(brokerCode);

				Object[] paramArray = new Object[1];

				if (brokerPaidCommissionVO != null) {
					paramArray[0] = brokerPaidCommissionVO;
					BizRequest obj_bizReq = new BizRequest();
					obj_bizReq.addbusinessObjects("service-obj1", paramArray);
					p_ObjContext.getFlowScope().put("requestOnLoadPaidCommision", obj_bizReq);
				}

			}

			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
				throw new IPruException("Error", "GRPPCB01", "userVo should not be null");
			}

		}

		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPPCB01", p_ObjContext);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End ");
		return success();
	}

	/*
	 * @MethodPost public Event
	 * getBizRequestforSubmitPaidCommission(RequestContext p_ObjContext) throws
	 * Exception { final String METHOD_NAME =
	 * "getBizRequestforSubmitPaidCommission"; FLogger.info(INFO_LOGGER_NAME,
	 * CLASS_NAME, METHOD_NAME, " Method Start"); FunctionalityMasterVO
	 * functionality; try { HttpServletRequest request = (HttpServletRequest)
	 * p_ObjContext.getExternalContext().getNativeRequest(); HttpSession
	 * httpSession = ((HttpServletRequest)
	 * p_ObjContext.getExternalContext().getNativeRequest()).getSession();
	 * StringBuffer jb = new StringBuffer(); String line = null; BufferedReader
	 * reader = request.getReader(); while ((line = reader.readLine()) != null)
	 * { jb.append(line); } functionality = this.getFunctionality(p_ObjContext);
	 * if (functionality == null) { FLogger.error("UnitStatementLogger",
	 * "UnitStatementHandler", "getBizRequestforUnitStatementSubmit",
	 * "functionality Should not be null"); throw new IPruException("Error",
	 * "US01", ErrorMsg); } IPruUser userVo = (IPruUser)
	 * httpSession.getAttribute("userVO"); if (userVo == null) {
	 * FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME,
	 * "userVo Should not be null"); throw new IPruException("Error",
	 * "GRPPCB01", ErrorMsg); } BrokerPaidCommissionPO paidCommissionPO =
	 * gsonJSON.fromJson(jb.toString(), BrokerPaidCommissionPO.class); if
	 * (paidCommissionPO == null) { FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,
	 * METHOD_NAME, "paidCommissionPO Should not be null"); throw new
	 * IPruException("Error", "GRPPCB01", ErrorMsg); } //
	 * brokerInfoPO.setPolicyNo(userVo.getPolicyNo()); Set
	 * paidCommissionpolicyList = (Set)
	 * p_ObjContext.getFlowScope().get("paidCommissionpolicyList"); if
	 * (CollectionUtils.isEmpty(paidCommissionpolicyList)) {
	 * FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME,
	 * "paidCommissionpolicyList Should not be null"); throw new
	 * IPruException("Error", "GRPPCB01", ErrorMsg); } if
	 * (!paidCommissionpolicyList.contains(paidCommissionPO.getPolicyNo())) {
	 * FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME,
	 * "policyNumber not match"); throw new IPruException("Error", "GRPPCB01",
	 * ErrorMsg); } SimpleDateFormat sdf1 = new
	 * SimpleDateFormat("dd MMMM,yyyy"); SimpleDateFormat sdf2 = new
	 * SimpleDateFormat("dd-MMM-yyyy"); Date startDate1 =
	 * sdf1.parse(paidCommissionPO.getStartDate()); String startDate =
	 * sdf2.format(startDate1); Date endDate1 =
	 * sdf1.parse(paidCommissionPO.getEndDate()); String endDate =
	 * sdf2.format(endDate1); if (startDate1.after(endDate1)) { throw new
	 * IPruException("Error", "GRPPCB01",
	 * "Todate date should not be greater than From date"); }
	 * paidCommissionPO.setStartDate(startDate);
	 * paidCommissionPO.setEndDate(endDate); BrokerPaidCommissionVO
	 * paidCommissionVO = dozerBeanMapper.map(paidCommissionPO,
	 * BrokerPaidCommissionVO.class); if (paidCommissionVO == null) {
	 * FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME,
	 * "paidCommissionVO should not be null"); throw new IPruException("Error",
	 * "GRPPCB01", ErrorMsg); } Object[] paramArray = new Object[1];
	 * paramArray[0] = paidCommissionVO; BizRequest obj_bizReq = new
	 * BizRequest(); obj_bizReq.addbusinessObjects("service-obj1", paramArray);
	 * p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq); } catch
	 * (Exception e) { FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME,
	 * "Exception came ", e); throwINeoFlowException(e, "GRPPCB01",
	 * p_ObjContext); } FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME,
	 * " Method End"); return success(); }
	 */

	@MethodPost
	public Event getBizResponseforOnLoadPaidCommission(RequestContext p_ObjContext) throws Exception {
		final String METHOD_NAME = "getBizResponseforOnLoadPaidCommission";
		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, " Method Start");

			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForPaidCommission");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "responseCheck null");
					throw new IPruException("Error", "GRPPCB01", "No fund data found Please try again!");
				}
				else {
					String url = (String) bizRes.getTransferObjects().get("response1");

					if (StringUtils.isEmpty(url)) {
						FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "responseCheck null");
						throw new IPruException("Error", "GRPPCB01", "Some Error Occured");
					}
					responseCheck = gsonJSON.toJson(url);
					p_ObjContext.getFlowScope().put("Response", responseCheck);

				}
			}
			else {

				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "url null");

				throw new IPruException("Error", "GRPPCB01", "Some Error Occured");
			}
		}
		catch (Exception e) {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came", e);
			throwINeoFlowException(e, "GRPPCB01", p_ObjContext);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, " Method end");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
