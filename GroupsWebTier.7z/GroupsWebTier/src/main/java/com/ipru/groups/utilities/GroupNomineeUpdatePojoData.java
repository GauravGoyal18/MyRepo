package com.ipru.groups.utilities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.NomineeUpdateLoadDataPo;
import com.ipru.groups.po.NomineeUpdateSubmitPo;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.NomineeUpdateSubmitVo;
import com.ipru.groups.vo.NomineeUpdateTransactionVo;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public class GroupNomineeUpdatePojoData {

	public NomineeUpdateTransactionVo getNomineeUpdateSubmitPojoData(NomineeUpdateTransactionVo nomineeUpdateTransactionVo , RequestContext p_ObjContext) throws IPruException {
		HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
		IPruUser userVo = new IPruUser();
		Properties prop = new Properties();
		List<NomineeUpdateSubmitVo> nomineeUpdateSubmitVoList2 = new ArrayList();
		String policyNo = null;
		String clientId = null;
		String role = null;
		String memberId = null;
		String modelName = null;
		String category = null;
		String productType = null;
		String memberType = null;
		Set<NomineeUpdateSubmitVo> nomineeUpdateSubmitVoSet=nomineeUpdateTransactionVo.getNomineeUpdateSubmitVoSet();
		if (httpSession != null) {
			userVo = (IPruUser) httpSession.getAttribute("userVO");
			 Map<String, FieldAccessMappingVO> fieldAccessMappingMap=null;
			 NomineeUpdateLoadDataPo nomineeUpdateLoadDataPo= (NomineeUpdateLoadDataPo)p_ObjContext.getFlowScope().get("loadNomineeUpdateData");	 
			 fieldAccessMappingMap=nomineeUpdateLoadDataPo.getFieldAccessMappingMap();
			 
			 if(fieldAccessMappingMap==null)
			 {
				 FLogger.info("nomineeUpdate", "GroupNomineeUpdatePojoData", "getNomineeUpdateSubmitPojoData", "property file should not be null");
				throw new IPruException("Error", "GRPNOUP", "found null data"); 
			 }
			if (userVo != null) {
				policyNo = userVo.getPolicyNo();
				clientId = userVo.getClientId();
				role = userVo.getRoles();
				productType = userVo.getProductType();
				memberId = userVo.getEmpId();
		
				memberType = userVo.getRoleType();
				prop = MasterPropertiesFileLoader.CONSTANT_NOMINEEUPDATE_PROPERTIES;

				if (prop != null) {

					if (prop.getProperty("modelName") != null)
						modelName = prop.getProperty("modelName");

					if (prop.getProperty("category") != null)
						category = prop.getProperty("category");
					
					/*for (Iterator iterator = nomineeUpdateSubmitVoSet.iterator(); iterator.hasNext();) {
						NomineeUpdateSubmitVo nomineeUpdateSubmitVo = (NomineeUpdateSubmitVo) iterator.next();
						
					}*/
					for (Iterator iterator = nomineeUpdateSubmitVoSet.iterator(); iterator.hasNext();) {
						NomineeUpdateSubmitVo nomineePojo =  (NomineeUpdateSubmitVo) iterator.next();
						String fieledIdWithExt = nomineePojo.getFieldId();
						int extention = fieledIdWithExt.indexOf('_');
						if (extention == -1) {
							throw new IPruException("Error", "GRPNOUP", "Some Error Occred");

						}

						String fieldId = fieledIdWithExt.substring(0, extention);
						FieldAccessMappingVO fieldAccessMappingVO=fieldAccessMappingMap.get(fieldId);
						if (String.valueOf(fieldAccessMappingVO.getRdComponentPosId()) != null){
							//nomineePojo.setFieldCode(prop.getProperty(fieldId + "_fieldCode"));
							nomineePojo.setFieldCode(String.valueOf(fieldAccessMappingVO.getRdComponentPosId()));}
						if (String.valueOf(fieldAccessMappingVO.getRdParentComponentId()) != null){
							//nomineePojo.setFieldGroupCode(prop.getProperty(fieldId + "_fieldGroupCode"));
							nomineePojo.setFieldGroupCode(String.valueOf(fieldAccessMappingVO.getRdParentComponentId()));
							}
						nomineePojo.setModelName(modelName);
						
						nomineePojo.setMemberId(memberId);
						nomineePojo.setModelName(modelName);
						nomineePojo.setCategory(category);
						nomineePojo.setCurrentDate(new Date());

						if (nomineePojo != null)
							nomineeUpdateSubmitVoList2.add(nomineePojo);

					}// for
					
					nomineeUpdateTransactionVo.setPolicyNo(policyNo);
					nomineeUpdateTransactionVo.setClientId(clientId);
					nomineeUpdateTransactionVo.setRole(role);
					nomineeUpdateTransactionVo.setProductType(productType);
					nomineeUpdateTransactionVo.setMemberType(memberType);
					nomineeUpdateTransactionVo.setNomineeUpdateSubmitVoSet(nomineeUpdateSubmitVoSet);
				}// prop
				else {
					FLogger.info("nomineeUpdate", "GroupNomineeUpdatePojoData", "getNomineeUpdateSubmitPojoData", "property file should not be null");
					throw new IPruException("Error", "GRPNOUP", "property file should not be null");
				}

			}// userVo

			else {
				FLogger.info("nomineeUpdate", "GroupNomineeUpdatePojoData", "getNomineeUpdateSubmitPojoData", "UserVo should not be null");
				throw new IPruException("Error", "GRPNOUP", "UserVo should not be null");
			}

		}// session
		else {
			FLogger.info("nomineeUpdate", "GroupNomineeUpdatePojoData", "getNomineeUpdateSubmitPojoData", "found session null");
			throw new IPruException("Error", "GRPNOUP", "found session null");
		}

		return nomineeUpdateTransactionVo;
	}

	public void sortNomineeUpdateSubmitPoList(List<NomineeUpdateSubmitPo> list, RequestContext p_ObjContext) throws IPruException {

		try {
			FLogger.info("NomineeUpdateLogger", "GroupNomineeUpdatePojoData", "sortNomineeUpdateSubmitPoList", "sortNomineeUpdateSubmitPoList method start");

			Collections.sort(list, new Comparator<NomineeUpdateSubmitPo>() {

				int count = 0;

				public int compare(NomineeUpdateSubmitPo o1, NomineeUpdateSubmitPo o2) {

					String id1 = o1.getFieldId();
					String id2 = o2.getFieldId();
					if (id1 != null && !id1.equalsIgnoreCase(" ") && id2 != null && !id2.equalsIgnoreCase(" ")) {
						int extention = id1.indexOf('_');
						String fieldId = id1.substring(extention + 1, id1.length());
						int extention2 = id2.indexOf('_');

						String fieldId2 = id2.substring(extention2 + 1, id2.length());
						o1.setFieldCode(fieldId);
						o2.setFieldCode(fieldId2);
						return o1.getFieldCode().compareTo(o2.getFieldCode());
					}

					return 0;

				}
			});

			FLogger.info("NomineeUpdateLogger", "GroupNomineeUpdatePojoData", "sortNomineeUpdateSubmitPoList", "sortNomineeUpdateSubmitPoList method end");
		}
		catch (Exception e) {
			throw new IPruException("Error", "GRPNOUP", "Some Exception Occured");

		}
	}

}
