package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;
import com.ipru.IPruException;
import com.ipru.groups.po.RetirementCalenderPO;
import com.ipru.groups.po.RetirementCalenderRequestPO;
import com.ipru.groups.vo.RetirementCalenderRequestVO;
import com.ipru.groups.vo.RetirementCalenderVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class RetirementCalenderHandler extends IneoBaseHandler {

	private static final long serialVersionUID = 1L;
	String ErrorMsg = "SomeThing went wrong please try again!";

	@MethodPost
	public Event getBizRequestForRetirementCalenderData(RequestContext context)
			throws Exception {
		FLogger.info("RetirementCalenderLogger", "RetirementCalenderHandler",
				"getBizRequestForRetirementCalenderData",
				"getBizRequestForRetirementCalenderData Method Start ");

		try {

			HttpSession httpSession = ((HttpServletRequest) context
					.getExternalContext().getNativeRequest()).getSession();

			IPruUser userVo = new IPruUser();
			String policyNo = null;
			// String role=null;

			userVo = (IPruUser) httpSession.getAttribute("userVO");

			if (userVo == null) {
				FLogger.error("RetirementCalenderLogger",
						"RetirementCalenderHandler",
						"getBizRequestForRetirementCalenderData",
						"userVo is null ");
				throw new IPruException("Error", "RC01", ErrorMsg);
			}

			policyNo = userVo.getPolicyNo();

			if (StringUtils.isEmpty(policyNo)) {
				FLogger.error("RetirementCalenderLogger",
						"RetirementCalenderHandler",
						"getBizRequestForRetirementCalenderData",
						"policyNo is null ");
				throw new IPruException("Error", "RC01", ErrorMsg);
			}

			/*
			 * role = userVo.getRoles();
			 * 
			 * if(StringUtils.isEmpty(role)) {
			 * FLogger.error("RetirementCalenderLogger",
			 * "RetirementCalenderHandler",
			 * "getBizRequestForRetirementCalenderData", "role is null "); throw
			 * new IPruException("Error", "GPU01", ErrorMsg); }
			 */

			RetirementCalenderRequestPO retirementCalenderRequestPO = new RetirementCalenderRequestPO();
			retirementCalenderRequestPO.setPolicyNumber(policyNo);
			// retirementCalenderRequestPO.setRole(role);

			if (retirementCalenderRequestPO == null) {
				FLogger.error("RetirementCalenderLogger",
						"RetirementCalenderHandler",
						"getBizRequestForRetirementCalenderData",
						"retirementCalenderRequestPO is null ");
				throw new IPruException("Error", "RC01", ErrorMsg);
			}

			RetirementCalenderRequestVO retirementCalenderRequestVO = new RetirementCalenderRequestVO();

			if (retirementCalenderRequestPO != null) {
				retirementCalenderRequestVO = dozerBeanMapper.map(
						retirementCalenderRequestPO,
						RetirementCalenderRequestVO.class);
			}

			if (retirementCalenderRequestVO == null) {
				FLogger.error("RetirementCalenderLogger",
						"RetirementCalenderHandler",
						"getBizRequestForRetirementCalenderData",
						"retirementCalenderRequestVO is null ");
				throw new IPruException("Error", "RC01", ErrorMsg);
			}

			Object[] paramArray = new Object[1];
			paramArray[0] = retirementCalenderRequestVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			context.getFlowScope().put("loadBizRequest", obj_bizReq);

		} catch (Exception e) {
			FLogger.error("RetirementCalenderLogger",
					"RetirementCalenderHandler",
					"getBizRequestForRetirementCalenderData",
					"Exception Occured ", e);
			throwINeoFlowException(e, "RC01", context);
		}

		FLogger.info("RetirementCalenderLogger", "RetirementCalenderHandler",
				"getBizRequestForRetirementCalenderData",
				"getBizRequestForRetirementCalenderData Method End ");

		return success();
	}

	@MethodPost
	public Event getBizResponseForRetirementCalenderData(RequestContext context)
			throws Exception {
		FLogger.info("RetirementCalenderLogger", "RetirementCalenderHandler",
				"getBizResponseForRetirementCalenderData",
				"getBizResponseForRetirementCalenderData Method Start");
		String responseCheck = "";
		String resultJson = "";
		// boolean response = false;
		List<RetirementCalenderVO> retirementCalenderVOlist = new ArrayList();

		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get(
					"bizResForProfileRetirementCalenderData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				} else {

					retirementCalenderVOlist = (List<RetirementCalenderVO>) bizRes
							.getTransferObjects().get("response1");

					if (CollectionUtils.isEmpty(retirementCalenderVOlist)) {
						FLogger.error("RetirementCalenderLogger",
								"RetirementCalenderHandler",
								"getBizResponseForRetirementCalenderData",
								"retirementCalenderRequestVOlist should not be null");
						throw new IPruException("Error", "RC01",
								"No data found");

					}
					RetirementCalenderPO retirementCalenderPO = null;
					List<RetirementCalenderPO> retirementCalenderPOList = new ArrayList<>();

					for (RetirementCalenderVO retirementCalenderVO : retirementCalenderVOlist) {
						retirementCalenderPO = dozerBeanMapper.map(
								retirementCalenderVO,
								RetirementCalenderPO.class);
						retirementCalenderPOList.add(retirementCalenderPO);
					}

					if (CollectionUtils.isEmpty(retirementCalenderPOList)) {
						FLogger.error("RetirementCalenderLogger",
								"RetirementCalenderHandler",
								"getBizResponseForRetirementCalenderData",
								"retirementCalenderPOList should not be null");
						throw new IPruException("Error", "RC01",
								"No data Found");

					}

					resultJson = gsonJSON.toJson(retirementCalenderPOList);
					context.getFlowScope().put("Response", resultJson);

				}
			}
		} catch (Exception e) {
			FLogger.error("RetirementCalenderLogger",
					"RetirementCalenderHandler",
					"getBizResponseForRetirementCalenderData",
					"Exception came ", e);
			throwINeoFlowException(e, "RC01", context);
		}
		FLogger.info("RetirementCalenderLogger", "RetirementCalenderHandler",
				"getBizResponseForRetirementCalenderData",
				"getBizResponseForRetirementCalenderData Method End");
		return success();

	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
