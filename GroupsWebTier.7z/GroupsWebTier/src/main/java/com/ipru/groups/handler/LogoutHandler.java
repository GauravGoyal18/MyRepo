package com.ipru.groups.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.otp.po.OTPNumberParamBean;
import com.tcs.security.annotations.MethodGet;

public class LogoutHandler extends IneoBaseHandler {
	
	@MethodGet
	public Event getRequest(RequestContext context){
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		HttpServletRequest request=(HttpServletRequest) context.getExternalContext().getNativeRequest();

		if(httpSession != null  && request.getMethod().equalsIgnoreCase("POST")){
			httpSession.invalidate();
			return success();
		}
		else
		{
			//FLogger.info("Web Tier", "LogoutHandler", "getRequest", "Logout attempted from get request");
			httpSession.invalidate();
			return error();
		}
	}
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub
		
	}

}
