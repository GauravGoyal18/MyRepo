package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.BrokerTopCustomerResponsePO;
import com.ipru.groups.po.NewTabCoiPO;
import com.ipru.groups.vo.BrokerTopCustomerResponseVO;
import com.ipru.groups.vo.BrokerTopCustomerVO;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.groups.vo.NewTabCoiVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BrokerTopCustomerHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final String CLASS_NAME = BrokerTopCustomerHandler.class.getCanonicalName();
	private static final String INFO_LOGGER_NAME = "BrokerTopCustomerLogger";
	private static final String ERROR_LOGGER_NAME = "BrokerTopCustomerLogger";

	@MethodPost
	public Event getBizRequestOnLoadTopCustomer(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestOnLoadTopCustomer";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start");
		Gson gson = new Gson();

		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
			/*	String clientName = null;
				String policyNo = null;*/
				String branchCode = null;
				String loginType = null;
				String nationalCode = null;
				String brokerType=null;
				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {
						FscDetailsVO fscDetailVo = userVo.getFscdetails();
						if(fscDetailVo != null){
							branchCode = fscDetailVo.getBranchCode();// Will get from session
							loginType = fscDetailVo.getLogin_type();// Will get from session
							nationalCode = fscDetailVo.getNationalCode(); // Will get from session
							brokerType=fscDetailVo.getFscChannel();
						}
						
					/*	policyNo = userVo.getPolicyNo();
						clientName = userVo.getClientName();*/
						/*branchCode = userVo.getFscdetails().getReferral_code();
						policyNo = userVo.getPolicyNo();
						clientName = userVo.getClientName();
						loginType = userVo.getFscdetails().getFscChannel();
						nationalCode=userVo.getFscdetails().getNationalCode();*/
						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

						if (request != null) {
							BrokerTopCustomerVO brokerTopCustomerVO = new BrokerTopCustomerVO();
			/*				brokerTopCustomerVO.setPolicyNo(policyNo);
							brokerTopCustomerVO.setClientName(clientName);*/
							brokerTopCustomerVO.setBranchCode(branchCode);
							brokerTopCustomerVO.setLoginType(loginType);
							brokerTopCustomerVO.setNationalCode(nationalCode);
							brokerTopCustomerVO.setBrokerType(brokerType);

							Object[] paramArray = new Object[1];

							if (brokerTopCustomerVO != null) {
								paramArray[0] = brokerTopCustomerVO;
								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);
								context.getFlowScope().put("requestOnLoadTopCustomer", obj_bizReq);
							}

						}
						else {

							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "request should not be null");
							throw new IPruException("Error", "GRPBTC", "request should not be null");
						}
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
						throw new IPruException("Error", "GRPBTC", "userVo should not be null");
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
					throw new IPruException("Error", "GRPBTC", "httpSession should not be null");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Context should not be null");
				throw new IPruException("Error", "GRPBTC", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBTC", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End ");
		return success();
	}

	@MethodPost
	public Event getBizResponseOnLoadTopCustomer(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseOnLoadTopCustomer";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResBrokerTopCustomer");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {

						List<BrokerTopCustomerResponseVO> brokerTopCustomerResponseVOlist = (List<BrokerTopCustomerResponseVO>) bizRes.getTransferObjects().get("response1");

						List<BrokerTopCustomerResponsePO> brokerTopCustomerResponsePOList = null;
						if (brokerTopCustomerResponseVOlist != null) {
							brokerTopCustomerResponsePOList = new ArrayList<BrokerTopCustomerResponsePO>();

							for (BrokerTopCustomerResponseVO brokerTopCustomerResponseVO : brokerTopCustomerResponseVOlist) {

								BrokerTopCustomerResponsePO brokerTopCustomerResponsePO = dozerBeanMapper.map(brokerTopCustomerResponseVO, BrokerTopCustomerResponsePO.class);

								brokerTopCustomerResponsePOList.add(brokerTopCustomerResponsePO);
							}

						}
						String callJsonString = gsonJSON.toJson(brokerTopCustomerResponsePOList);
						FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "callJsonString::" + callJsonString);
						context.getFlowScope().put("Response", callJsonString);
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBTC", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");

		return success();

	}

	@MethodPost
	public Event getBizRequestNewTab(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestNewTab";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		/* Gson gson = new Gson(); */

		NewTabCoiPO newTabCoiPO = null;
		String templateId = null;
		String policynumber = null;

		try {

			/* if (context != null) { */

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			if (httpSession != null) {
				IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null) {

					// policyNo = userVo.getPolicyNo();
					policynumber = "21144665";
					// clientId = userVo.getClientId();
					templateId = "T642";

					newTabCoiPO = gsonJSON.fromJson(request.getReader(), NewTabCoiPO.class);// handle
																							// null
																							// //
																							// newTabCoiPO

					if (newTabCoiPO == null) {
						throw new Exception();
					}

					newTabCoiPO.setpolicynumber(policynumber);
					newTabCoiPO.setTemplateId(templateId);

					NewTabCoiVO newTabCoiVO = dozerBeanMapper.map(newTabCoiPO, NewTabCoiVO.class);// handle
																									// null
																									// newTabCoiVO

					if (newTabCoiVO == null) {
						throw new Exception();
					}
					Object[] paramArray = new Object[1];
					paramArray[0] = newTabCoiVO;
					BizRequest obj_bizReq = new BizRequest();
					obj_bizReq.addbusinessObjects("service-obj1", paramArray);
					context.getFlowScope().put("bizReqNewTab", obj_bizReq);

				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
					throw new IPruException("Error", "GRPBTC", "userVo should not be null");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
				throw new IPruException("Error", "GRPBTC", "httpSession should not be null");
			}
			/*
			 * } else { FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME,
			 * METHOD_NAME, "Context should not be null"); throw new
			 * IPruException("Error", "GRPBTC", "Context should not be null"); }
			 */
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBTC", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return success();
	}

	@MethodPost
	public Event getBizResponsenewTab(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponsenewTab";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {

			bizRes = (BizResponse) context.getFlowScope().get("bizResNewTab");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Error came while getting response from service");

					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					String strDataJson = (String) bizRes.getTransferObjects().get("response1");

					if (StringUtils.isEmpty(strDataJson)) {
						FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "responseCheck null");
						throw new IPruException("Error", "GRPBTC", "Some Error Occured");
					}
					responseCheck = gsonJSON.toJson(strDataJson);

					// CHECK NULL responseCheck
					if (responseCheck == null) {
						throw new Exception();
					}
					context.getFlowScope().put("Response", responseCheck);

				}
			}
			else {

				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "url null");

				throw new IPruException("Error", "GRPBTC", "Some Error Occured");
			}

		}
		catch (Exception e) {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came", e);
			throwINeoFlowException(e, "GRPBTC", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, " Method end");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
