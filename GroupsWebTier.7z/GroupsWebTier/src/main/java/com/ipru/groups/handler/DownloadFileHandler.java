package com.ipru.groups.handler;


import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.groups.po.DocumentRequestPo;
import com.ipru.groups.po.DownloadFileRequestPO;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.vo.UploadFileVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;



public class DownloadFileHandler extends IneoBaseHandler{

	//onentry token from session
	public Event getBizRequestforDownloadFileHandler(RequestContext p_ObjContext) throws Exception
	{
		try
		{
		
		FLogger.info("FileDownloadLogger", "DownloadFileHandler", "getBizRequestforDownloadFileHandler", "Start Method");

		HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
		if (httpSession == null) {			
		FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizRequestforDownloadFileHandler", "found null session");
		String gsonString="ERROR";
		p_ObjContext.getFlowScope().put("Response",gsonString);
		return error();
		}
		DownloadFileRequestPO downloadFileRequestPO=(DownloadFileRequestPO)httpSession.getAttribute("downloadFileRequestPOSession");
		/*DownloadFileRequestPO downloadFileRequestPO=new DownloadFileRequestPO();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
	
		downloadFileRequestPO.setTimeToken(calendar.getTimeInMillis());
		downloadFileRequestPO.setFileId("5");
		downloadFileRequestPO.setFileName("Amrut");
		*/
		if(downloadFileRequestPO==null)
		{
			FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizRequestforDownloadFileHandler", "found null data");
			String gsonString="ERROR";
			p_ObjContext.getFlowScope().put("Response",gsonString);
			return error();
		}
		
		long timeTokenFromSession=downloadFileRequestPO.getTimeToken();
		
		Calendar calendar1 = Calendar.getInstance();
		calendar1.setTime(new Date());
		long diff=calendar1.getTimeInMillis()-timeTokenFromSession;
	
		FLogger.info("FileDownloadLogger", "DownloadFileHandler", "getBizRequestforDownloadFileHandler", "difference betwwen time"+diff);


        if(diff>30*60*1000)
        {
        	FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizRequestforDownloadFileHandler", "found invalidate session");

			String gsonString="ERROR";
			p_ObjContext.getFlowScope().put("Response",gsonString);
			return error();
        }

		String downloadFileIdFromSession=downloadFileRequestPO.getFileId();
		//downloadFileIdFromSession="5";
		
		FLogger.info("FileDownloadLogger", "DownloadFileHandler", "getBizRequestforDownloadFileHandler", "downloadFileIdFromSession"+downloadFileIdFromSession);

		
		if(downloadFileIdFromSession.isEmpty())
		{
			FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizRequestforDownloadFileHandler", "found null downloadFileId");

			String gsonString="ERROR";
			p_ObjContext.getFlowScope().put("Response",gsonString);
			return error();
		}
	
		Object[] paramArray = new Object[1];
		paramArray[0] = downloadFileIdFromSession;
		BizRequest obj_bizReq = new BizRequest();
		obj_bizReq.addbusinessObjects("service-obj1", paramArray);
		FLogger.info("FileDownloadLogger", "DownloadFileHandler", "getBizRequestforDownloadFileHandler", "downloadFileId"+downloadFileIdFromSession);

		p_ObjContext.getFlowScope().put("downloadFileBizRequest", obj_bizReq);
		
		FLogger.info("FileDownloadLogger", "DownloadFileHandler", "getBizRequestforDownloadFileHandler", "Method End");
		}
		catch(Exception e)
		{
			FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizRequestforDownloadFileHandler", "Some error occured",e);
			//e.printStackTrace();
			String gsonString="ERROR";
			p_ObjContext.getFlowScope().put("Response",gsonString);
			return error();
		}
		return success();
	}
	
	public Event getBizResponseforDownloadFileHandler(RequestContext p_ObjContext) throws Exception
	{
		
		try
		{
		FLogger.info("FileDownloadLogger", "DownloadFileHandler", "getBizResponseforDownloadFileHandler", "Method start");

		HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
		if(httpSession==null)
		{
			FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizResponseforDownloadFileHandler", "Found null session");
			String gsonString="ERROR";
			p_ObjContext.getFlowScope().put("Response",gsonString);
			return error();
		}
		DownloadFileRequestPO downloadFileRequestPO=(DownloadFileRequestPO)httpSession.getAttribute("downloadFileRequestPOSession");

		/*DownloadFileRequestPO downloadFileRequestPO=new DownloadFileRequestPO();
		downloadFileRequestPO.setFileName("Amrut");
*/
		if(downloadFileRequestPO==null)
		{
			FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizResponseforDownloadFileHandler", "Error occured found null downloadFileRequestPO1");
			String gsonString="ERROR";
			p_ObjContext.getFlowScope().put("Response",gsonString);
			return error();
		}
		BizResponse bizRes = new BizResponse();
		bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForFileDownload");
		String responseCheck = "";
		if (bizRes != null) {
			
			responseCheck = (String) bizRes.getStatusVO().getStatus();
			if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {

				FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizResponseforDownloadFileHandler", "Error occured");
				String gsonString="ERROR";
				p_ObjContext.getFlowScope().put("Response",gsonString);
				return error();
			}
			else
			{
				//vo to po
				UploadFileVO documentUploadVo =(UploadFileVO)bizRes.getTransferObjects().get("response1");
				
				
				if(documentUploadVo==null)
				{
					
					FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizResponseforDownloadFileHandler", "Found null data documentUploadVo");
					String gsonString="ERROR";
					p_ObjContext.getFlowScope().put("Response",gsonString);
					return error();
				}
				FLogger.info("FileDownloadLogger", "DownloadFileHandler", "getBizResponseforDownloadFileHandler", "documentUploadVo"+documentUploadVo.toString());

				UploadFilePO documentUploadPo = null;
				documentUploadPo = dozerBeanMapper.map(documentUploadVo, UploadFilePO.class);
				
				if(documentUploadPo==null)
				{
					FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizResponseforDownloadFileHandler", "Found null data documentUploadPo");
					String gsonString="ERROR";
					p_ObjContext.getFlowScope().put("Response",gsonString);
					return error();
				}
				documentUploadPo.setDocName(downloadFileRequestPO.getFileName());
				FLogger.info("FileDownloadLogger", "DownloadFileHandler", "getBizResponseforDownloadFileHandler", "putting value In session");

				httpSession.setAttribute("DownloadFileData", documentUploadPo);
				DocumentRequestPo documentRequestPo=new DocumentRequestPo();
				documentRequestPo.setDocName(documentUploadPo.getDocName());
				documentRequestPo.setContentType(documentUploadPo.getContentType());
				//content type and file name 
				String resultJson = gsonJSON.toJson(documentRequestPo);
				p_ObjContext.getFlowScope().put("Response", resultJson);

			}
		}
		
		}
		catch(Exception e)
		{
			FLogger.error("FileDownloadLogger", "DownloadFileHandler", "getBizResponseforDownloadFileHandler", "Some error occured",e);
			String gsonString="ERROR";
			e.printStackTrace();
			p_ObjContext.getFlowScope().put("Response",gsonString);
			return error();
		}
		return success();
	}
	
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		// TODO Auto-generated method stub
		
	}

}
