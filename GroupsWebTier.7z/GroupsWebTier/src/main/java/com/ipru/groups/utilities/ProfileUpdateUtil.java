package com.ipru.groups.utilities;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.FieldAccessMappingPO;
import com.ipru.groups.po.ProfileUpdateDetailsPo;
import com.ipru.groups.po.profileupdate.FieldMeta;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.ProfileUpdateDetailsVo;
import com.ipru.groups.vo.ProfileUpdateTranscationVO;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;


public class ProfileUpdateUtil {

public ProfileUpdateTranscationVO getProfileUpdateData(Map<String, FieldAccessMappingVO> map, List<ProfileUpdateDetailsVo> voList,RequestContext p_ObjContext,FunctionalityMasterVO functionality)throws Exception{
	FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class", "getProfileUpdateData", "getProfileUpdateData Method Start");
	HttpSession httpSession = ((HttpServletRequest) ((RequestContext) p_ObjContext).getExternalContext().getNativeRequest()).getSession();//get HttpSessionObject
	

	IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
	if(userVo==null)
	{
		FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getProfileUpdateData", "userVo Should not be null");
		throw new IPruException("Error","GPU01", "Some Thing Went Wrong Please Try Again!");	
	}
	
	FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class", "getProfileUpdateData", "getProfileUpdateData Method  PolicyNumber:"+userVo.getPolicyNo()+" userVo.getClientId()"+userVo.getClientId()+" Role"+userVo.getRoles());
	ProfileUpdateTranscationVO profileUpdateTranscationVO=new ProfileUpdateTranscationVO();
	ProfileUpdateDetailsVo profileUpdateDetailsVo=null;
	profileUpdateTranscationVO.setPolicyNo(userVo.getPolicyNo());
	profileUpdateTranscationVO.setClientId(userVo.getClientId());
	profileUpdateTranscationVO.setRole(userVo.getRoles());
	profileUpdateTranscationVO.setUnitId(userVo.getUnitCode());
	profileUpdateTranscationVO.setMemberId(userVo.getEmpId());
	profileUpdateTranscationVO.setTrusteeName(userVo.getClientName());
	profileUpdateTranscationVO.setCategory("I");
	profileUpdateTranscationVO.setProductType(userVo.getProductType());
	profileUpdateTranscationVO.setMemberType(userVo.getRoleType());
	profileUpdateTranscationVO.setFunctionality(functionality);
	
	for(int i=0;i<voList.size();i++)
	{    	
		ProfileUpdateDetailsVo vo=voList.get(i);
		Iterator itr = map.entrySet().iterator();
			while (itr.hasNext()) {
    	
				Map.Entry pair = (Map.Entry)itr.next(); 
				if(pair.getKey().equals(vo.getFieldName()))
					{
					FieldAccessMappingVO profile=(FieldAccessMappingVO) pair.getValue();
						
						profileUpdateDetailsVo=new ProfileUpdateDetailsVo();
						profileUpdateDetailsVo.setSubfieldCode("");
						profileUpdateDetailsVo.setFieldName(vo.getFieldName());
						profileUpdateDetailsVo.setFieldCode((int)profile.getRdComponentPosId());
						profileUpdateDetailsVo.setFieldGroupCode((int)profile.getRdParentComponentId());
						profileUpdateDetailsVo.setOldValue("");
						profileUpdateDetailsVo.setNewValue(vo.getNewValue());
						profileUpdateTranscationVO.getProfileUpdateDetailsVOSet().add(profileUpdateDetailsVo);
					
					}//end of pair if
				else
				{
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class","getProfileUpdateData","some error occred in ProfileUpdateHandler class");
					
				}
     
        }//end of while
   
}//end of for

FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class", "getProfileUpdateData", "getProfileUpdateData Method End PolicyNumber:"+userVo.getPolicyNo()+" userVo.getClientId()"+userVo.getClientId()+" Role"+userVo.getRoles());
return profileUpdateTranscationVO;
		
}


public ProfileUpdateTranscationVO getProfileUpdateDataForEdit(List<ProfileUpdateDetailsVo> profileUpdateDetailsVOList,Map<String, FieldAccessMappingVO> map,RequestContext p_ObjContext,FunctionalityMasterVO functionality)throws Exception
	{
	FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class", "getProfileUpdateDataForEdit", "getProfileUpdateDataForEdit Method Start");
	HttpSession httpSession = ((HttpServletRequest) ((RequestContext) p_ObjContext).getExternalContext().getNativeRequest()).getSession();//get HttpSessionObject
	IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
	if(userVo==null)
	{
		FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getProfileUpdateData", "userVo Should not be null");
		throw new IPruException("Error","GPU01", "Some Thing Went Wrong Please Try Again!");	
	}
	FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class", "getProfileUpdateDataForEdit", "getProfileUpdateDataForEdit Method  PolicyNumber:"+userVo.getPolicyNo()+" userVo.getClientId()"+userVo.getClientId()+" Role"+userVo.getRoles());
	ProfileUpdateTranscationVO profileUpdateTranscationVO=new ProfileUpdateTranscationVO();
	ProfileUpdateDetailsVo profileUpdateDetailsVo=null;
	profileUpdateTranscationVO.setPolicyNo(userVo.getPolicyNo());
	profileUpdateTranscationVO.setClientId(userVo.getClientId());
	profileUpdateTranscationVO.setRole(userVo.getRoles());
	profileUpdateTranscationVO.setUnitId(userVo.getUnitCode());
	profileUpdateTranscationVO.setMemberId(userVo.getEmpId());
	profileUpdateTranscationVO.setTrusteeName(userVo.getClientName());
	profileUpdateTranscationVO.setCategory("U");
	profileUpdateTranscationVO.setProductType(userVo.getProductType());
	profileUpdateTranscationVO.setMemberType(userVo.getRoleType());
	profileUpdateTranscationVO.setFunctionality(functionality);
	
	for(int i=0;i<profileUpdateDetailsVOList.size();i++)
	{    	
		ProfileUpdateDetailsVo profileUpdateDetailsVOData=profileUpdateDetailsVOList.get(i);
		Iterator itr = map.entrySet().iterator();
			while (itr.hasNext()) {
    	
				Map.Entry pair = (Map.Entry)itr.next(); 
				if(pair.getKey().equals(profileUpdateDetailsVOData.getFieldName()))
					{
					FieldAccessMappingVO profile=(FieldAccessMappingVO) pair.getValue();
						
						profileUpdateDetailsVo=new ProfileUpdateDetailsVo();
						profileUpdateDetailsVo.setSubfieldCode("");
						profileUpdateDetailsVo.setFieldName(profileUpdateDetailsVOData.getFieldName());
						profileUpdateDetailsVo.setFieldCode((int)profile.getRdComponentPosId());
						profileUpdateDetailsVo.setFieldGroupCode((int)profile.getRdParentComponentId());
						profileUpdateDetailsVo.setOldValue(profileUpdateDetailsVOData.getOldValue());
						profileUpdateDetailsVo.setNewValue(profileUpdateDetailsVOData.getNewValue());
						profileUpdateDetailsVo.setUpdateReqId(profileUpdateDetailsVOData.getUpdateReqId());
						profileUpdateTranscationVO.getProfileUpdateDetailsVOSet().add(profileUpdateDetailsVo);
					}//end of pair if
				else
				{
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class","getProfileUpdateData","some error occred in ProfileUpdateHandler class");
					
				}
     
        }//end of while
   
}//end of for
	FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class", "getProfileUpdateDataForEdit", "getProfileUpdateDataForEdit Method End");
	return profileUpdateTranscationVO;
	}



public String checkMandatoryFields(List<ProfileUpdateDetailsPo> poValidateData,Map<String,FieldAccessMappingVO> backEnd)
{
	FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class", "checkMandatoryFields", "getProfileUpdateDataForEdit Method Start");	
	final StringBuffer errorMessageBuilder = new StringBuffer(1);
	for(ProfileUpdateDetailsPo profileUpdateDetailsPo:poValidateData)
	{
		FieldAccessMappingVO vo=backEnd.get(profileUpdateDetailsPo.getFieldName());
		String result=mandatoryCheck(Integer.parseInt(vo.getOpMandatory()),String.valueOf(profileUpdateDetailsPo.getFieldName()),String.valueOf(profileUpdateDetailsPo.getNewValue()));
		if(StringUtils.isEmpty(result))
		{
			
		}
		else
		{
			errorMessageBuilder.append(result);	
		}
		
	}
	FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class", "checkMandatoryFields", "checkMandatoryFields Method End");	
	
	return errorMessageBuilder.toString();	
}

private String mandatoryCheck(int mandatory,String newValue,String key)
{
	FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class", "checkMandatoryFields", "checkMandatoryFields Method Start");	
	String result="";
	boolean flag=false;
	
	if(mandatory==1)
	{
		flag=StringUtils.isEmpty(newValue);
		if(flag)
		{
			result=key+" is Mandatory Please Fill. ";
		}
	}
	FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler class to ProfileUpdateHandler class", "mandatoryCheck", "mandatoryCheck Method End");	
	return result;
}





}
