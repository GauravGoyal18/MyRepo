package com.ipru.groups.handler;

import javacryption.aes.AesCtr;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.reflect.TypeToken;
import com.ipru.IPruException;
import com.ipru.groups.po.SignUpPolicyDetailsPO;
import com.ipru.groups.utilities.EncryptionUtil;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.SessionKeyConstants;
import com.ipru.groups.validators.SignUpValidator;
import com.ipru.groups.vo.SignUpChangePasswordVO;
import com.ipru.groups.vo.SignUpMasterSheetDetailsVO;
import com.ipru.groups.vo.SignUpPolicyDetailsVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.GroupsUserAuthInfoNew;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class SignUpHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = SignUpHandler.class.getCanonicalName();
	private static final String INFO_LOGGER_NAME = "SignUpLogger";
	private static final String ERROR_LOGGER_NAME = "SignUpLogger";

	@MethodPost
	public Event getBizRequestForCheckPolicyDetails(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestForCheckPolicyDetails";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

		try {
			if (context != null) {
				HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

				if (request != null) {
					SignUpPolicyDetailsPO signUpPolicyDetailsPO = gsonJSON.fromJson(request.getReader(), SignUpPolicyDetailsPO.class);

					if (signUpPolicyDetailsPO != null) {

						SignUpValidator validator = new SignUpValidator();

						String validation = validator.validatePolicyDetails(signUpPolicyDetailsPO);

						if (StringUtils.isNotBlank(validation)) {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Validation errors : " + validation);
							this.setValidationErrorMessages(validation);
							throw new IPruException("Error", "GRPSP01", validation);
						}

						GroupSecurityUtil.setAttributeInSession(context, "signUpPolicyDetailsPO", signUpPolicyDetailsPO);

						SignUpPolicyDetailsVO signUpLoadVO = dozerBeanMapper.map(signUpPolicyDetailsPO, SignUpPolicyDetailsVO.class);

						Object[] paramArray = new Object[1];
						paramArray[0] = signUpLoadVO;

						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);

						context.getFlowScope().put("bizReqForCheckPolicyDetails", obj_bizReq);
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "signUpLoadPO from request should not be null");
						throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "request should not be null");
					throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSP01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return success();
	}

	@MethodPost
	public Event getBizResponseForCheckPolicyDetails(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseForCheckPolicyDetails";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String responseString = null;
		SignUpMasterSheetDetailsVO masterSheetDetails = null;

		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForCheckPolicyDetails");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {
						responseString = (String) bizRes.getTransferObjects().get("response1");

						if (StringUtils.isBlank(responseString)) {
							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "isEmailMobileExistString is blank.");
							throw new IPruException("Error","GRPSP01","Something went wrong. Please try again later.");
						}
						else if(StringUtils.startsWith(responseString, "ERROR")){
							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, responseString);
							throw new IPruException("Error","GRPSP01",responseString);
						} else {
							masterSheetDetails = gsonJSON.fromJson(responseString, SignUpMasterSheetDetailsVO.class);
							GroupSecurityUtil.setAttributeInSession(context, "masterSheetDetailsForSignUp", masterSheetDetails);
							context.getFlowScope().put("Response", "Success");
						}
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
					throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSP01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return success();
	}

	@MethodPost
	public Event getBizRequestForEmailMobileSubmit(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestForEmailMobileSubmit";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

		try {
			if (context != null) {
				HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

				if (request != null) {
					SignUpPolicyDetailsPO signUpPolicyDetailsPO = gsonJSON.fromJson(request.getReader(), SignUpPolicyDetailsPO.class);

					if (signUpPolicyDetailsPO != null) {

						SignUpValidator validator = new SignUpValidator();

						String validation = validator.validateContactDetails(signUpPolicyDetailsPO, context);

						if (StringUtils.isNotBlank(validation)) {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Validation errors : " + validation);
							this.setValidationErrorMessages(validation);
							throw new IPruException("Error", "GRPSP01", validation);
						}

						GroupSecurityUtil.setAttributeInSession(context, "signUpPolicyDetailsPO", signUpPolicyDetailsPO);

						SignUpPolicyDetailsVO signUpLoadVO = dozerBeanMapper.map(signUpPolicyDetailsPO, SignUpPolicyDetailsVO.class);

						Object[] paramArray = new Object[1];
						paramArray[0] = signUpLoadVO;

						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);

						context.getFlowScope().put("bizReqForSignUpContactSubmit", obj_bizReq);
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "signUpLoadPO from request should not be null");
						throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "request should not be null");
					throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSP01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return success();
	}

	@MethodPost
	public Event getBizResponseForEmailMobileSubmit(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseForEmailMobileSubmit";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		GroupsUserAuthInfoNew groupsUserAuthInfoNew = null;

		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForSignUpContactSubmit");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {
						String response = (String) bizRes.getTransferObjects().get("response1");

						if (response.contains("Error-")) {
							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, response);
							throw new IPruException("Error", "GRPSP01", response);
						}
						else if ("NOT_MATCHED".equals(response)) {

						}
						else {
							groupsUserAuthInfoNew = gsonJSON.fromJson(response, new TypeToken<GroupsUserAuthInfoNew>() {
							}.getType());
							if (groupsUserAuthInfoNew != null) {
								GroupSecurityUtil.setAttributeInSession(context, "groupsUserAuthInfoNewDetailsForSignUp", groupsUserAuthInfoNew);
							}
						}

						// Set Details related to OTP in session.
						setOtpDetailsInSession(context);

						context.getFlowScope().put("Response", "Success");

					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
					throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSP01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	public void setOtpDetailsInSession(RequestContext context) throws Exception {

		if (context != null) {
			SignUpPolicyDetailsPO signUpPolicyDetailsPO = (SignUpPolicyDetailsPO) GroupSecurityUtil.getAttributeFromSession(context, "signUpPolicyDetailsPO");
			IPruUser userVo = (IPruUser) GroupSecurityUtil.getAttributeFromSession(context, "userVO");
			SignUpMasterSheetDetailsVO masterSheetDetails = (SignUpMasterSheetDetailsVO) GroupSecurityUtil.getAttributeFromSession(context, "masterSheetDetailsForSignUp");

			if (userVo != null && signUpPolicyDetailsPO != null && masterSheetDetails != null) {
				userVo.setEmailId(signUpPolicyDetailsPO.getEmailId());
				userVo.setMobileNo(String.valueOf(signUpPolicyDetailsPO.getMobileNo()));
				userVo.setPolicyNo(signUpPolicyDetailsPO.getPolicyNo());
				userVo.setClientId(masterSheetDetails.getClientId());
				userVo.setUsername(masterSheetDetails.getClientName());
				userVo.setClientName(masterSheetDetails.getClientName());

				GroupSecurityUtil.setAttributeInSession(context, "userVO", userVo);
			}
		}

	}

	public Event getBizRequestForSignUpChangePasswordSubmit(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestForEmailMobileSubmit";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

		boolean isOTPValidated = false;
		SignUpMasterSheetDetailsVO masterSheetDetails = null;
		GroupsUserAuthInfoNew groupsUserAuthInfoNew = null;
		try {
			if (context != null) {
				isOTPValidated = (Boolean) GroupSecurityUtil.getAttributeFromSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);

				HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
				if (request != null) {
					SignUpPolicyDetailsPO signUpPolicyDetailsPO = gsonJSON.fromJson(request.getReader(), SignUpPolicyDetailsPO.class);
					if (signUpPolicyDetailsPO != null) {

						String encProperty1 = signUpPolicyDetailsPO.getNewPassword();

						if (encProperty1 != null) {
							String key = (String) GroupSecurityUtil.getAttributeFromSession(context, "jCryptionKey");
							encProperty1 = encProperty1.replaceAll(" ", "+");
							String decProperty = AesCtr.decrypt(encProperty1, key, 256);
							signUpPolicyDetailsPO.setNewPassword(EncryptionUtil.encryptSHA256(decProperty, "UTF-8"));
							signUpPolicyDetailsPO.setMd5Password(EncryptionUtil.encryptMD5(decProperty));
						}

						String encProperty2 = signUpPolicyDetailsPO.getConfirmPassword();

						if (encProperty2 != null) {
							String key = (String) GroupSecurityUtil.getAttributeFromSession(context, "jCryptionKey");
							encProperty2 = encProperty1.replaceAll(" ", "+");
							String decProperty = AesCtr.decrypt(encProperty2, key, 256);
							signUpPolicyDetailsPO.setConfirmPassword(EncryptionUtil.encryptSHA256(decProperty, "UTF-8"));
						}

						SignUpValidator validator = new SignUpValidator();

						String validation = validator.validatePasswordDetails(signUpPolicyDetailsPO, context);

						if (StringUtils.isNotBlank(validation)) {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Validation errors : " + validation);
							this.setValidationErrorMessages(validation);
							throw new IPruException("Error", "GRPSP01", validation);
						}
						else {

							if (!isOTPValidated) { // write this after
													// validation.
								FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "OTP is not validated.");
								throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
							}
							else {
								GroupSecurityUtil.removeAttributeInSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);
							}

							GroupSecurityUtil.removeAttributeInSession(context, "signUpPolicyDetailsPO");
							masterSheetDetails = (SignUpMasterSheetDetailsVO) GroupSecurityUtil.getAttributeFromSession(context, "masterSheetDetailsForSignUp");
							GroupSecurityUtil.removeAttributeInSession(context, "masterSheetDetailsForSignUp");
							groupsUserAuthInfoNew = (GroupsUserAuthInfoNew) GroupSecurityUtil.getAttributeFromSession(context, "groupsUserAuthInfoNewDetailsForSignUp");
							GroupSecurityUtil.removeAttributeInSession(context, "groupsUserAuthInfoNewDetailsForSignUp");
						}

						SignUpPolicyDetailsVO signUpLoadVO = dozerBeanMapper.map(signUpPolicyDetailsPO, SignUpPolicyDetailsVO.class);
						
						SignUpChangePasswordVO signUpChangePasswordVO = new SignUpChangePasswordVO();
						signUpChangePasswordVO.setGroupsUserAuthInfoNew(groupsUserAuthInfoNew);
						signUpChangePasswordVO.setMasterSheetDetails(masterSheetDetails);
						signUpChangePasswordVO.setSignUpPolicyDetailsVO(signUpLoadVO);

						Object[] paramArray = new Object[1];
						paramArray[0] = signUpChangePasswordVO;

						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);

						context.getFlowScope().put("bizReqForSignUpChangePasswordSubmit", obj_bizReq);
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "signUpLoadPO from request should not be null");
						throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "request should not be null");
					throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSP01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return success();
	}

	public Event getBizResponseForSignUpChangePasswordSubmit(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseForSignUpChangePasswordSubmit";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForSignUpChangePasswordSubmit");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {
						String response = (String) bizRes.getTransferObjects().get("response1");

						if (response.equals("SUCCESS")) {
							context.getFlowScope().put("Response", "Success");
						}
						else {
							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, response);
							throw new IPruException("Error", "GRPSP01", response);
						}
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
					throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPSP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSP01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		final String METHOD_NAME = "setOtpCallBacks";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		paramBean.setFunctionality("SIGN_UP");
		setTransactionalOTPCallback(Boolean.TRUE);
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
	}

}
