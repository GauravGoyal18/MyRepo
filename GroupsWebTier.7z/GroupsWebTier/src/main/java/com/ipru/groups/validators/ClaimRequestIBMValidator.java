package com.ipru.groups.validators;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.groups.po.ClaimExcelDataPO;
import com.ipru.groups.po.ClaimIbmDropDownPO;
import com.ipru.groups.po.ClaimRequestIBMPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.vo.ClaimExcelDataVO;
import com.ipru.groups.vo.ClaimRequestIBMVO;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public class ClaimRequestIBMValidator {
	String str="Something Went Wrong Please Try Again. ";
	   
	   public String recheckClaimRequestAnnuityScannedData(ClaimRequestIBMPO claimRequestIBMPO,RequestContext p_ObjContext) throws Exception{
			final StringBuilder errorMessageBuilder = new StringBuilder(1);
			FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMValidator",
					"recheckClaimRequestAnnuityScannedData", "recheckClaimRequestAnnuityScannedData Method start");
		   
		   ClaimRequestIBMVO claimRequestIBMVO= (ClaimRequestIBMVO) p_ObjContext.getFlowScope().get("claimRequestIBMVOData");
		   
		  if(claimRequestIBMVO==null)
		  {
			  errorMessageBuilder.append(str);
		  }
		  
		  if(!validateTwoFields(claimRequestIBMPO.getPolicyNo()==null?"":claimRequestIBMPO.getPolicyNo(),claimRequestIBMVO.getPolicyNo()==null?"":claimRequestIBMVO.getPolicyNo()))
		  {
			  errorMessageBuilder.append("Please enter valid Policy No. ");
		  }
		  
		  if(!validateTwoFields(claimRequestIBMPO.getEmployeeId()==null?"":claimRequestIBMPO.getEmployeeId(),claimRequestIBMVO.getEmployeeId()==null?"":claimRequestIBMVO.getEmployeeId()))
		  {
			  errorMessageBuilder.append("Please enter valid Employee ID. ");
		  }
		  
		  
		  if(!validateTwoFields(claimRequestIBMPO.getTypeOfClaim()==null?"":claimRequestIBMPO.getTypeOfClaim(),claimRequestIBMVO.getTypeOfClaim()==null?"":claimRequestIBMVO.getTypeOfClaim()))
		  {
			  errorMessageBuilder.append("Please select valid Type Of claim. ");
		  }
		  
		  if(!validateTwoFields(claimRequestIBMPO.getGratuityApplicable()==null?"":claimRequestIBMPO.getGratuityApplicable(),claimRequestIBMVO.getGratuityApplicable()==null?"":claimRequestIBMVO.getGratuityApplicable()))
		  {
			  errorMessageBuilder.append("Please select valid Gratuity Applicable. ");
		  }
		  
		  
		  if(!validateTwoFields(claimRequestIBMPO.getCommutationPer()==null?"":claimRequestIBMPO.getCommutationPer(),claimRequestIBMVO.getCommutationPer()==null?"":claimRequestIBMVO.getCommutationPer()))
		  {
			  errorMessageBuilder.append("Please enter  valid Commutation Per. ");
		  }
		  
		  if(!validateTwoFields(claimRequestIBMPO.getAnnuityPer()==null?"":claimRequestIBMPO.getAnnuityPer(),claimRequestIBMVO.getAnnuityPer()==null?"":claimRequestIBMVO.getAnnuityPer()))
		  {
			  errorMessageBuilder.append("Please enter valid Annuity. ");
		  }
		   
		  if(!validateTwoFields(claimRequestIBMPO.getEmpName()==null?"":claimRequestIBMPO.getEmpName(),claimRequestIBMVO.getEmpName()==null?"":claimRequestIBMVO.getEmpName()))
		  {
			  errorMessageBuilder.append("Please enter valid Name(as per PAN card). ");
		  }
		  
		  
		  if(!validateTwoFields(claimRequestIBMPO.getBeneficiary()==null?"":claimRequestIBMPO.getBeneficiary(),claimRequestIBMVO.getBeneficiary()==null?"":claimRequestIBMVO.getBeneficiary()))
		  {
			  errorMessageBuilder.append("Please enter valid Beneficiary Name. ");
		  }
		  
		  if(!validateTwoFields(claimRequestIBMPO.getBeneficiaryPayMode()==null?"":claimRequestIBMPO.getBeneficiaryPayMode(),claimRequestIBMVO.getBeneficiaryPayMode()==null?"":claimRequestIBMVO.getBeneficiaryPayMode()))
		  {
			  errorMessageBuilder.append("Please enter valid Beneficiary Pay Mode. ");
		  }
		   
		  
		  if(!validateTwoFields(claimRequestIBMPO.getIfscCode()==null?"":claimRequestIBMPO.getIfscCode(),claimRequestIBMVO.getIfscCode()==null?"":claimRequestIBMVO.getIfscCode()))
		  {
			  errorMessageBuilder.append("Please enter valid IFSC Code. ");
		  }
		  
		  if(!validateTwoFields(claimRequestIBMPO.getMicrCode()==null?"":claimRequestIBMPO.getMicrCode(),claimRequestIBMVO.getMicrCode()==null?"":claimRequestIBMVO.getMicrCode()))
		  {
			  errorMessageBuilder.append("Please enter valid MICR Code. ");
		  }
		  
		  if(!validateTwoFields(claimRequestIBMPO.getBankName()==null?"":claimRequestIBMPO.getBankName(),claimRequestIBMVO.getBankName()==null?"":claimRequestIBMVO.getBankName()))
		  {
			  errorMessageBuilder.append("Please enter valid Bank Name. ");
		  }
		  
		  
		  if(!validateTwoFields(claimRequestIBMPO.getBankAccountNo()==null?"":claimRequestIBMPO.getBankAccountNo(),claimRequestIBMVO.getBankAccountNo()==null?"":claimRequestIBMVO.getBankAccountNo()))
		  {
			  errorMessageBuilder.append("Please enter valid BankAccount No. ");
		  }
		  
		  if(!validateTwoFields(claimRequestIBMPO.getAddress()==null?"":claimRequestIBMPO.getAddress(),claimRequestIBMVO.getAddress()==null?"":claimRequestIBMVO.getAddress()))
		  {
			  errorMessageBuilder.append("Please enter valid Address. ");
		  }
		  
		  
		  FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMValidator",
					"recheckClaimRequestAnnuityScannedData", "recheckClaimRequestAnnuityScannedData Method end");
		return errorMessageBuilder.toString();
	   }
	   
	   
	   
	   public String ValidateClaimRequestValidator(ClaimRequestIBMPO claimRequestIBMPO,RequestContext p_ObjContext) throws Exception{
		   FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMValidator",
					"ValidateClaimRequestValidator", "ValidateClaimRequestValidator Method start");
		
		  
		 //List<ClaimIbmDropDownPO> typeOFClaimsList= (List<ClaimIbmDropDownPO>) p_ObjContext.getFlowScope().get("onloadTypesOfClaims");
		   //List<ClaimIbmDropDownPO> gratuityOptions= (List<ClaimIbmDropDownPO>) p_ObjContext.getFlowScope().get("onloadGratuityOptions");
		   List<ClaimIbmDropDownPO> annuityPerOptions= (List<ClaimIbmDropDownPO>) p_ObjContext.getFlowScope().get("onclaimIbmAnnuityPerOptions");
		   List<ClaimIbmDropDownPO> commutationOption= (List<ClaimIbmDropDownPO>) p_ObjContext.getFlowScope().get("onclaimCommutationOption");
		   List<ClaimIbmDropDownPO> beneficiaryPayModeOptions= (List<ClaimIbmDropDownPO>) p_ObjContext.getFlowScope().get("beneficiaryPayModeOptions");
		   
		   ClaimExcelDataVO claimExcelDataPOData= (ClaimExcelDataVO) p_ObjContext.getFlowScope().get("claimExcelDataPOData");
			final StringBuilder errorMessageBuilder = new StringBuilder(1);
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			
			IPruUser userVO = (IPruUser) httpSession.getAttribute("userVO");
		
			if(!validatePolicyNumber(claimRequestIBMPO.getPolicyNo()==null?"":claimRequestIBMPO.getPolicyNo(),userVO))
			{
				errorMessageBuilder.append("Please enter valid Policy No. ");
			}
			
			/*if(!validateEmployeeId(claimRequestIBMPO.getEmployeeId()==null?"":claimRequestIBMPO.getEmployeeId(),userVO))
			{
				errorMessageBuilder.append("Please enter valid Employee ID. ");
			}*/
			
			if(!validateTypeOfClaim(claimRequestIBMPO.getTypeOfClaim()==null?"":claimRequestIBMPO.getTypeOfClaim(),claimExcelDataPOData.getType_of_claim()))
			{
				errorMessageBuilder.append("Please select valid Type Of claim. ");
			}
			
			if(!validateGratuityOptions(claimRequestIBMPO.getGratuityApplicable()==null?"":claimRequestIBMPO.getGratuityApplicable(),claimExcelDataPOData.getGratuity_Applicable()))
			{
				errorMessageBuilder.append("Please select valid Gratuity Applicable. ");
			}
			
			
			if(!validateCommutationPer(claimRequestIBMPO.getCommutationPer()==null?"":claimRequestIBMPO.getCommutationPer(),commutationOption))
			{
				errorMessageBuilder.append("Please enter  valid Commutation Per. ");
			}
			
			
			if(!validateannuityPer(claimRequestIBMPO.getAnnuityPer()==null?"":claimRequestIBMPO.getAnnuityPer(),annuityPerOptions))
			{
				errorMessageBuilder.append("Please enter valid Annuity. ");
			}
			
			if(!validateEmployeeName(claimRequestIBMPO.getEmpName()==null?"":claimRequestIBMPO.getEmpName()))
			{
				errorMessageBuilder.append("Please enter valid Name(as per PAN card). ");
			}
			
			if(!validateBeneficiaryName(claimRequestIBMPO.getBeneficiary()==null?"":claimRequestIBMPO.getBeneficiary()))
			{
				errorMessageBuilder.append("Please enter valid Beneficiary Name. ");
			}
			
			if(!validatebeneficiaryPayMode(claimRequestIBMPO.getBeneficiaryPayMode()==null?"":claimRequestIBMPO.getBeneficiaryPayMode(),beneficiaryPayModeOptions))
			{
				errorMessageBuilder.append("Please select Beneficiary Pay Mode. ");
			}
			
			if(!validateIfscCode(claimRequestIBMPO.getIfscCode()==null?"":claimRequestIBMPO.getIfscCode()))
			{
				errorMessageBuilder.append("Please enter valid IFSC Code. ");
			}
			
			if(!validateMicrCode(claimRequestIBMPO.getMicrCode()==null?"":claimRequestIBMPO.getMicrCode()))
			{
				errorMessageBuilder.append("Please enter valid MICR Code. ");
			}
			
			if(!validateBankName(claimRequestIBMPO.getBankName()==null?"":claimRequestIBMPO.getBankName()))
			{
				errorMessageBuilder.append("Please enter valid Bank Name. ");
			}
			
			
			if(!validateBankAccountNumber(claimRequestIBMPO.getBankAccountNo()==null?"":claimRequestIBMPO.getBankAccountNo()))
			{
				errorMessageBuilder.append("Please enter valid BankAccount No. ");
			}
			
			if(!validateAddress(claimRequestIBMPO.getAddress()==null?"":claimRequestIBMPO.getAddress()))
			{
				errorMessageBuilder.append("Please enter valid Address. ");
			}
			
			  FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMValidator",
						"ValidateClaimRequestValidator", "ValidateClaimRequestValidator Method end");
			return errorMessageBuilder.toString();
				
	   }
	   
	   
	   private boolean validateAddress(String  b) {
			
			if(StringUtils.isNotEmpty(b))
			{
				if(CommonValidationUtil.ValidateAddress(b) && CommonValidationUtil.ValidateMaxLength(b, 100))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else{
				return false;
			}
			
	 }
	   
	   private boolean validateBankAccountNumber(String  b) {
			
			if(StringUtils.isNotEmpty(b))
			{
				if(CommonValidationUtil.ValidateRequired(b) && CommonValidationUtil.isMatchedPattern(b, GroupFormValidationConstant.ACCOUNTNUMBER_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(b, 20))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else{
				return false;
			}
			
	 }
	   	
	   
	   private boolean validateBankName(String  b) {
			
			if(StringUtils.isNotEmpty(b))
			{
				if(CommonValidationUtil.ValidateRequired(b) && CommonValidationUtil.ValidateAlphaWithSpace(b) && CommonValidationUtil.ValidateMaxLength(b, 50))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else{
				return false;
			}
			
	 }
	   	
	   
	   
	   private boolean validateMicrCode(String  b) {//TODO:please Change  Validation formicr
			
			if(StringUtils.isNotEmpty(b))
			{
				if(CommonValidationUtil.ValidateRequired(b) && CommonValidationUtil.isMatchedPattern(b, GroupFormValidationConstant.MICR_CODE_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(b, 9) &&  CommonValidationUtil.ValidateMinLength(b, 9))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else{
				return false;
			}
			
	 }
	   
	   
	   private boolean validateIfscCode(String  b) {
			
			if(StringUtils.isNotEmpty(b))
			{
				if(CommonValidationUtil.ValidateRequired(b) && CommonValidationUtil.isMatchedPattern(b, GroupFormValidationConstant.IFSC_CODE_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(b, 11) &&  CommonValidationUtil.ValidateMinLength(b, 11))
				
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else{
				return false;
			}
			
	 }
	   
	   
	   private boolean validatebeneficiaryPayMode(String  b,List<ClaimIbmDropDownPO>  obj) {
		   return isPojoContainElement(obj,b);
			/*if(StringUtils.isNotEmpty(b))
			{
				if(CommonValidationUtil.ValidateAlphaWithSpace(b) && CommonValidationUtil.ValidateMaxLength(b, 30))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else{
				return false;
			}
			*/
	 }
	   
	   private boolean validateBeneficiaryName(String  b) {
			
			if(StringUtils.isNotEmpty(b))
			{
				if(CommonValidationUtil.ValidateAlphaWithNonMultipleSpace(b) && CommonValidationUtil.ValidateMaxLength(b, 30))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else{
				return false;
			}
			
	 }
	   
		
	   private boolean validateEmployeeName(String  b) {
			
			if(StringUtils.isNotEmpty(b))
			{
				if(CommonValidationUtil.ValidateMaxLength(b, 30))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else{
				return true;
			}
			
	 }
	   
	   private boolean validateannuityPer(String b,List<ClaimIbmDropDownPO>  obj) {
		   return isPojoContainElement(obj,b);
			/*
			if(StringUtils.isNotEmpty(b))
			{
				if(obj.equals(b))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else{
				return false;
			}*/
			
	 }
	   private boolean validateCommutationPer(String b,List<ClaimIbmDropDownPO>  obj) {
		   return isPojoContainElement(obj,b);
			/*if(StringUtils.isNotEmpty(b))
			{
				if(obj.getValue().equals(b))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else{
				return false;
			}*/
			
	 }
	   
	   private boolean validateGratuityOptions(String  b,String obj) {
		   return isPojoContainSame(obj,b);
			
			/*	if(StringUtils.isNotEmpty(b))
				{
					if(obj.getValue().equals(b))
					{
						return true;
					}
					else
					{
						return false;
					}	
				}
				else{
					return false;
				}*/
		 }
	   
	   private boolean validateTypeOfClaim(String  b,String obj) {
		   return isPojoContainSame(obj,b);
			
		/*	if(StringUtils.isNotEmpty(b))
			{
				if(obj.contains(b))
				{
					return true;
				}
				else
				{
					return false;
				}	
			}
			else{
				return false;
			}*/
	 }

		 private boolean validateEmployeeId(String  b,IPruUser userVO) {
				
				if(StringUtils.isNotEmpty(b))
				{
					if(b.equals(userVO.getEmpId()))
					{
						return true;
					}
					else
					{
						return false;
					}	
				}
				else{
					return false;
				}
		 }
			
			 private boolean validatePolicyNumber(String  b,IPruUser userVO) {
					
					if(StringUtils.isNotEmpty(b))
					{
						if(b.equals(userVO.getPolicyNo()))
						{
							return true;
						}
						else
						{
							return false;
						}	
					}
					else{
						return false;
					}
			 }
			 
			 private boolean validateTwoFields(String a,String b)
			 {
				 
				 if(a.equals(b))
				 {
					 return true;
				 }
				 return false;
			 }
			
			 
			 
	private boolean isPojoContainElement(List<ClaimIbmDropDownPO> listObj,String b)
		{
		

		for(ClaimIbmDropDownPO po:listObj)
		{
			if(po.getKey().equals(b))
			{
				return true;
			}
		
		}
		return false;
		}
	
	
	private boolean isPojoContainSame(String a,String b)
	{
	if(a.equals(b))
	{
		return true;
	}
	return false;
	}
}
				 
				
			   
