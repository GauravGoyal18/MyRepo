package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.ipru.IPruException;
import com.ipru.groups.po.BidStatementPO;
import com.tcs.logger.FLogger;

public class BIDStatementValidator {

	public String validateBid(BidStatementPO bidStatementPO) throws IPruException
	{
		try
		{
			
		FLogger.info("BIDStatementLogger", "BIDStatementValidator", "validateBid", "Method start");

		StringBuilder errorMessage=new StringBuilder();
		
		String fromDateString=bidStatementPO.getFromDate();
		String toDateString=bidStatementPO.getToDate();

		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
		Date fromDate=format1.parse(fromDateString);
		Date toDate=format1.parse(toDateString);
		if ((toDate.compareTo(new Date())>0) && (fromDate.compareTo(new Date())>0) ) {
           // ////System.out.println("Date1 is after Date2");
			FLogger.error("BIDStatementLogger", "BIDStatementValidator", "validateBid", "Invalid Date");
            errorMessage.append("Enter valid date");
        } 
		if((toDate.compareTo(fromDate) < 0))
		{
			FLogger.error("BIDStatementLogger", "BIDStatementValidator", "validateBid", "Date1 is after Date2");
            errorMessage.append("To Date must be Greater than From date");
		}
		FLogger.error("BIDStatementLogger", "BIDStatementValidator", "validateBid", "Method start");
		FLogger.info("BIDStatementLogger", "BIDStatementValidator", "validateBid", "Method end");
		return errorMessage.toString();
		}
		catch(ParseException e)
		{
			FLogger.error("BIDStatementLogger", "BIDStatementValidator", "validateBid", "Date Format is not valid" ,e);

			throw new IPruException("Error","BIDSTMT01","Some Error Occured");
		}
	}
}
