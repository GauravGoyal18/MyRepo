package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.joda.time.LocalDate;
import org.joda.time.Years;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.BeneficiaryPO;
import com.ipru.groups.po.ClaimBeneficiaryPO;
import com.ipru.groups.po.ClaimsDropDownData;
import com.ipru.groups.po.ClaimsRequestPO;
import com.ipru.groups.po.ClaimsSubmitPO;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.ClaimDropDownVO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.tcs.logger.FLogger;

public class ClaimsValidator {

	private final StringBuilder errorMessageBuilder = new StringBuilder(1);
	Years age = null;

	public String validateClaimSubmit(ClaimsSubmitPO claimsSubmitPO, RequestContext p_ObjContext, List<ClaimsRequestPO> claimsRequestList, Map<String, FieldAccessMappingVO> map, List<UploadFilePO> uploadFilePOList, List<ClaimBeneficiaryPO> claimsBeneficiaryList, String productType) throws IPruException, ParseException {

		FLogger.info("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "method start");

		errorMessageBuilder.setLength(0);

		ClaimsDropDownData claimsDropDownData = (ClaimsDropDownData) p_ObjContext.getFlowScope().get("claimsDropDownData");

		if (claimsSubmitPO != null) {
			if (claimsDropDownData != null) {

				ArrayList gratuity = new ArrayList();
				gratuity.add("YES");
				gratuity.add("NO");

				List<ClaimDropDownVO> states = claimsDropDownData.getState();
				List<ClaimDropDownVO> cities = claimsDropDownData.getCity();
				List<ClaimDropDownVO> relations = claimsDropDownData.getRelation();
				List<ClaimDropDownVO> causes = claimsDropDownData.getCause();

				if (states == null || states.size() <= 0 && cities == null || cities.size() <= 0 && causes == null || causes.size() >= 0 && relations == null || relations.size() <= 0) {
					FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, claimsDropDownData Found null Data");
					throw new IPruException("Error", "GRPPFCC", "Found null Data");
				}

				if (!validateDropDown(causes, claimsSubmitPO.getCause())) {
					FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid cause data");
					throw new IPruException("Error", "GRPPFCC", "Invalid cause data");
				}
				if (!validateAlpNumField(claimsSubmitPO.getEmployeeId(), 12, 1)) {
					FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Employee Id data");
					throw new IPruException("Error", "GRPPFCC", "Invalid Employee Id data");
				}
				if (!validateAlpField(claimsSubmitPO.getEmployeeName(), 100)) {
					FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Employee Name data");
					throw new IPruException("Error", "GRPPFCC", "Invalid Employee Name data");
				}
				if (!validatePanField(claimsSubmitPO.getPan(), 10, 10)) {
					FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Pan Card data");
					throw new IPruException("Error", "GRPPFCC", "Invalid Pan Card data");
				}

				if (!validateDob(claimsSubmitPO.getEventDate())) {
					FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Event Date data");
					throw new IPruException("Error", "GRPPFCC", "Invalid Event Date data");
				}
				if (!productType.equals("TERM")) {
					if (!validateMobField(claimsSubmitPO.getMobileNumber(), 10, 10)) {
						FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Mobile Number data");
						throw new IPruException("Error", "GRPPFCC", "Invalid Mobile Number data");
					}
					if (!validateNumericField(claimsSubmitPO.getCommutation(), 3)) {
						FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Commutation data");
						throw new IPruException("Error", "GRPPFCC", "Invalid Commutation data");
					}
					if (!validateNumericField(claimsSubmitPO.getAnnuity(), 3)) {
						FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Annuity data");
						throw new IPruException("Error", "GRPPFCC", "Invalid Annuity data");
					}
					if (Integer.parseInt(claimsSubmitPO.getCommutation()) + Integer.parseInt(claimsSubmitPO.getAnnuity()) != 100) {
						FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Commutation and Annuity should be 100%");
						throw new IPruException("Error", "GRPPFCC", "Commutation and Annuity should be 100%");
					}
					if (!gratuity.contains(claimsSubmitPO.getGratuityApplicable())) {
						FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Gratuity data");
						throw new IPruException("Error", "GRPPFCC", "Invalid Gratuity data");
					}
					if (!validateEmailField(claimsSubmitPO.getEmployeeEmailId_1(), 50, 1)) {
						FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid EmployeeMailID 1 data");
						throw new IPruException("Error", "GRPPFCC", "Invalid EmployeeMailID 1 data");
					}
					if (!validateEmail2Field(claimsSubmitPO.getEmployeeEmailId_2(), 50)) {
						FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid EmployeeMailID 2 data");
						throw new IPruException("Error", "GRPPFCC", "Invalid EmployeeMailID 2 data");
					}
				}
				else {
					if (StringUtils.isNotEmpty(claimsSubmitPO.getMobileNumber()) && StringUtils.isNotEmpty(claimsSubmitPO.getCommutation()) && StringUtils.isNotEmpty(claimsSubmitPO.getAnnuity())
							&& StringUtils.isNotEmpty(claimsSubmitPO.getGratuityApplicable()) && StringUtils.isNotEmpty(claimsSubmitPO.getEmployeeEmailId_1())
							&& StringUtils.isNotEmpty(claimsSubmitPO.getEmployeeEmailId_2())) {
						FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Mobile Number data");
						throw new IPruException("Error", "GRPPFCC", "Invalid Mobile Number data");
					}

				}
				int i = 1;
				List<BeneficiaryPO> beneficiary = claimsSubmitPO.getBeneficiary();
				int totalSharePercentage = 0;
				for (BeneficiaryPO beneficiaryPO : beneficiary) {

					if (i <= 10) {
						if (!validateDropDown(states, beneficiaryPO.getState())) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid state data");
							throw new IPruException("Error", "GRPPFCC", "Invalid state data");
						}
						if (!validateDropDown(cities, beneficiaryPO.getCity())) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid city data");
							throw new IPruException("Error", "GRPPFCC", "Invalid city data");
						}
						if (!validateDropDown(relations, beneficiaryPO.getRelation())) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid relation data");
							throw new IPruException("Error", "GRPPFCC", "Invalid relation data");
						}					

						if (validateDobForAppt(beneficiaryPO.getBeneficiaryDOB(), beneficiaryPO.getAppointeeName()) && validateDob(beneficiaryPO.getBeneficiaryDOB())) {
							if (!validateAlpField(beneficiaryPO.getAppointeeName(), 100)) {
								FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Appointee Name data");
								throw new IPruException("Error", "GRPPFCC", "Invalid Appointee Name data");
							}
						}else{
							if (!validateAlpField(beneficiaryPO.getBeneficiaryName(), 100)) {
								FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Beneficiary Name data");
								throw new IPruException("Error", "GRPPFCC", "Invalid Beneficiary Name data");
							}
						}
						totalSharePercentage = totalSharePercentage + Integer.parseInt(beneficiaryPO.getSharePercentage());

						if (!validateNumericField(beneficiaryPO.getSharePercentage(), 3)) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid SharePercentage data");
							throw new IPruException("Error", "GRPPFCC", "Invalid SharePercentage data");
						}
						if (!validateAlpNumSpaceField(beneficiaryPO.getCompanyOrBuildingName(), 100)) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Company Or BuildingName data");
							throw new IPruException("Error", "GRPPFCC", "Invalid Company Or BuildingName data");
						}
						if (!validateAlpNumSpaceField(beneficiaryPO.getFlatOrUnitNumber(), 100)) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Flat Or UnitNumber data");
							throw new IPruException("Error", "GRPPFCC", "Invalid Flat Or UnitNumber data");
						}
						if (!validateAlpNumSpaceField(beneficiaryPO.getStreetOrArea(), 100)) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Street Or Area data");
							throw new IPruException("Error", "GRPPFCC", "Invalid Street Or Area data");
						}
						if (!validateAlpNumSpaceField(beneficiaryPO.getLandmark(), 100)) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Landmark data");
							throw new IPruException("Error", "GRPPFCC", "Invalid Landmark data");
						}
						if (!validateNumericField(beneficiaryPO.getPincode(), 6)) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Pincode data");
							throw new IPruException("Error", "GRPPFCC", "Invalid Pincode data");
						}
						if (!validateNumericField(beneficiaryPO.getBankAccountNUMBER(), 20)) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Bank Account Number data");
							throw new IPruException("Error", "GRPPFCC", "Invalid Bank Account Number data");
						}
						if (!validateAlpField(beneficiaryPO.getBankName(), 100)) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Bank Name data");
							throw new IPruException("Error", "GRPPFCC", "Invalid Bank Name data");
						}
						if (!validateIfscField(beneficiaryPO.getIfscCode(), 11)) {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid Ifsc Code data");
							throw new IPruException("Error", "GRPPFCC", "Invalid Ifsc Code data");
						}

						i++;
					}

					else {
						FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "More then 10 Beneficiary cannot be added");
						throw new IPruException("Error", "GRPPFCC", "More then 10 Beneficiary cannot be added");
					}
				}
				if (totalSharePercentage != 100) {
					FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Beneficiary Share% should be 100%");
					throw new IPruException("Error", "GRPPFCC", "Beneficiary Share% should be 100%");
				}
				String errormsg = checkMandatoryFields(claimsRequestList, claimsBeneficiaryList, map, productType);

				if (StringUtils.isNotEmpty(errormsg)) {
					FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", errormsg);
					throw new IPruException("Error", "GRPCL03", errormsg);
				}

				Properties prop = new Properties();
				prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
				if (CollectionUtils.isNotEmpty(uploadFilePOList)) {
					for (UploadFilePO uploadFilePO : uploadFilePOList) {

						String documentName = uploadFilePO.getDocName();
						long docSize = uploadFilePO.getDocSize();
						int dot = documentName.lastIndexOf(".");
						String extension = documentName.substring(dot + 1);
					}
				}
				else {
					FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, Invalid file Uploaded");
					throw new IPruException("Error", "GRPPFCC", "Found null Data");
				}
			}
			else {
				FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, claimsDropDownData Found null Data from context");
				throw new IPruException("Error", "GRPPFCC", "Found null Data");
			}
		}
		else {
			FLogger.error("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "Exception Occured, claimsSubmitPO found null");
			throw new IPruException("Error", "GRPPFCC", "Found null Data");
		}
		FLogger.info("ClaimsLogger", "ClaimsValidator", "validateClaimSubmit", "method end");
		return null;

	}

	private boolean validateDropDown(List<ClaimDropDownVO> listData, String strData) {
		ArrayList single = new ArrayList();

		for (ClaimDropDownVO claimDropDownVO : listData) {
			single.add(claimDropDownVO.getValue());
			if (single.contains(strData)) {
				return true;
			}
		}

		return false;
	}

	private boolean validateNumericField(String val, Integer num) {

		if (StringUtils.isNotEmpty(val) && CommonValidationUtil.ValidateNumeric(val) && CommonValidationUtil.ValidateMaxLength(val, num)) {
			return true;

		}
		else {
			return false;
		}

	}

	private boolean validateNumericField(String val, Integer max, Integer min) {

		if (StringUtils.isNotEmpty(val) && CommonValidationUtil.ValidateNumeric(val) && CommonValidationUtil.ValidateMaxLength(val, max) && CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		}
		else {
			return false;
		}

	}

	private boolean validateAlpField(String val, Integer num) {

		if (StringUtils.isNotEmpty(val) && StringUtils.isAlphaSpace(val) && CommonValidationUtil.ValidateMaxLength(val, num)) {
			return true;

		}
		else {
			return false;
		}

	}

	private boolean validateAlpNumSpaceField(String val, Integer num) {

		if (StringUtils.isNotEmpty(val)) {
			if (StringUtils.isAlphanumericSpace(val) && CommonValidationUtil.ValidateMaxLength(val, num)) {
				return true;

			}
			else {
				return false;
			}
		}
		else {
			return false;
		}

	}

	private boolean validateAlpNumField(String val, Integer max, Integer min) {

		if (StringUtils.isNotEmpty(val)) {
			if (StringUtils.isAlphanumeric(val) && CommonValidationUtil.ValidateMaxLength(val, max) && CommonValidationUtil.ValidateMinLength(val, min)) {
				return true;

			}
			else {
				return false;
			}
		}
		else {
			return false;
		}

	}

	private boolean validateIfscField(String val, Integer num) {

		if (StringUtils.isNotEmpty(val)) {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.IFSC_CODE_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(val, num)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}

	}

	private boolean validatePanField(String val, Integer max, Integer min) {

		if (StringUtils.isNotEmpty(val)) {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.PAN_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, max)
					&& CommonValidationUtil.ValidateMinLength(val, min)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}

	}

	private boolean validateMobField(String val, Integer max, Integer min) {

		if (StringUtils.isNotEmpty(val)) {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(val, max)
					&& CommonValidationUtil.ValidateMinLength(val, min)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}

	}

	private boolean validateEmailField(String val, Integer num, Integer min) {
		if (StringUtils.isNotEmpty(val)) {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.EMAILID_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, num)
					&& CommonValidationUtil.ValidateMinLength(val, min)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return true;
		}

	}

	private boolean validateEmail2Field(String val, Integer num) {

		if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.EMAILID_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, num)) {
			return true;
		}
		else if (val.equals("")) {
			return true;
		}
		else {
			return false;
		}
	}

	private boolean validateDob(String dob) throws ParseException {
		if (StringUtils.isNotEmpty(dob)) {
			SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
			Date date1 = format1.parse(dob);
			Date today = new Date();
			if (date1.before(today)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}

	public boolean validateDobForAppt(String dob, String appointee) throws ParseException, IPruException {

		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);

		Date date1 = format1.parse(dob);
		Calendar myCal = Calendar.getInstance();
		myCal.setTime(date1);

		Date today = new Date();

		if (date1.before(today)) {

			if (CommonValidationUtil.ValidateRequired(dob)) {// for date

				LocalDate birthdate = new LocalDate(myCal.get(Calendar.YEAR), myCal.get(Calendar.MONTH) + 1, myCal.get(Calendar.DATE));

				LocalDate now = new LocalDate();
				age = Years.yearsBetween(birthdate, now);

				if (age != null) {
					if (age.isLessThan(Years.years(18))) {
						if (StringUtils.isNotBlank(appointee)) {
							return true;
						}
						else {
							FLogger.error("ClaimsLogger", "ClaimsValidator", "validateDobForAppt", "Appointee name cannot be blank as age is less then 18");
							throw new IPruException("Error", "GRPPFCC", "Appointee name cannot be blank as age is less then 18");
						}
					}
					else {
						return false;
					}
				}
				else {
					FLogger.error("ClaimsLogger", "ClaimsValidator", "validateDobForAppt", "Exception Occured, Found null Data");
					throw new IPruException("Error", "GRPPFCC", "Found null Data");
				}
			}
			else {

				return false;
			}
		}

		else {
			return false;
		}
	}

	public String checkMandatoryFields(List<ClaimsRequestPO> claimsRequestList, List<ClaimBeneficiaryPO> claimsBeneficiaryList, Map<String, FieldAccessMappingVO> map, String productType) {
		FLogger.info("ClaimsLogger", "ClaimsValidator", "checkMandatoryFields", "checkMandatoryFields Method Start");
		final StringBuffer errorMessageBuilder = new StringBuffer(1);

		for (ClaimsRequestPO claimsRequestPO : claimsRequestList) {
			String result = null;
			FieldAccessMappingVO vo = map.get(claimsRequestPO.getFieldName());
			result = mandatoryCheck(Integer.parseInt(vo.getOpMandatory()), String.valueOf(claimsRequestPO.getFieldName()), String.valueOf(claimsRequestPO.getNewValue()));
			if (StringUtils.isEmpty(result)) {

			}
			else {
				errorMessageBuilder.append(result);
			}

		}
		for (ClaimBeneficiaryPO claimsBeneficiaryPO : claimsBeneficiaryList) {
			FieldAccessMappingVO vo = map.get(claimsBeneficiaryPO.getFieldName());
			String result = mandatoryCheck(Integer.parseInt(vo.getOpMandatory()), String.valueOf(claimsBeneficiaryPO.getFieldName()), String.valueOf(claimsBeneficiaryPO.getNewValue()));
			if (StringUtils.isEmpty(result)) {

			}
			else {
				errorMessageBuilder.append(result);
			}

		}
		FLogger.info("ClaimsLogger", "ClaimsValidator", "checkMandatoryFields", "checkMandatoryFields Method End");

		return errorMessageBuilder.toString();
	}

	private String mandatoryCheck(int mandatory, String newValue, String key) {
		FLogger.info("ClaimsLogger", "ClaimsValidator", "mandatoryCheck", "mandatoryCheck Method Start");
		String result = "";
		boolean flag = false;

		if (mandatory == 1) {
			flag = StringUtils.isEmpty(newValue);
			if (flag) {
				result = key + " is Mandatory Please Fill. ";
			}
		}
		FLogger.info("ClaimsLogger", "ClaimsValidator", "mandatoryCheck", "mandatoryCheck Method End");
		return result;
	}

}
