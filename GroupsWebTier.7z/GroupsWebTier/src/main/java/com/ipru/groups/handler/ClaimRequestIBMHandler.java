package com.ipru.groups.handler;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.ClaimAnnuityIBMReqPO;
import com.ipru.groups.po.ClaimExcelDataPO;
import com.ipru.groups.po.ClaimIbmDropDownPO;
import com.ipru.groups.po.ClaimReqIBMredirectPO;
import com.ipru.groups.po.ClaimRequestIBMPO;
import com.ipru.groups.po.ClaimRequestIBMSubmitPO;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.utilities.CommonFileUploadUtil;
import com.ipru.groups.validators.ClaimRequestIBMValidator;
import com.ipru.groups.vo.ClaimAnnuityIBMReqVO;
import com.ipru.groups.vo.ClaimAnnuityIBMSubmitVO;
import com.ipru.groups.vo.ClaimExcelDataVO;
import com.ipru.groups.vo.ClaimReqIBMredirectVO;
import com.ipru.groups.vo.ClaimRequestIBMVO;
import com.ipru.groups.vo.FtlToPdfVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.UploadFileVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ClaimRequestIBMHandler extends IneoBaseHandler {

	public static final String ErrorMsg = "Something Went Wrong Please Try Again!";

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@MethodPost
	public Event getBizRequestforOnloadPrePopulateClaimRedirectionDetails(RequestContext p_ObjContext) throws Exception {

		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforOnloadPrePopulateClaimRedirectionDetails", "getBizRequestforOnloadPrePopulateClaimRedirectionDetails Method Start ");

		try {

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			IPruUser userVO = (IPruUser) httpSession.getAttribute("userVO");

			ClaimReqIBMredirectPO claimReqIBMredirectPO = new ClaimReqIBMredirectPO();

			if (StringUtils.isEmpty(userVO.getPolicyNo()) && StringUtils.isEmpty(userVO.getEmpId())) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}

			claimReqIBMredirectPO.setPolicyNo(userVO.getPolicyNo());
			claimReqIBMredirectPO.setClientId(userVO.getEmpId());

			ClaimReqIBMredirectVO claimReqIBMRedirectVO = dozerBeanMapper.map(claimReqIBMredirectPO, ClaimReqIBMredirectVO.class);

			if (claimReqIBMRedirectVO == null) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}

			Object[] paramArray = new Object[1];
			paramArray[0] = claimReqIBMRedirectVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {
			throwINeoFlowException(e, "CRAI01", p_ObjContext);
			FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforOnloadPrePopulateClaimRedirectionDetails", "Exception came", e);

		}

		return success();

	}

	@MethodPost
	public Event getBizResponseforOnloadPrePopulateClaimRedirectionDetails(RequestContext p_ObjContext) throws Exception {

		try {

			FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimRedirectionDetails", "getBizResponseforOnloadPrePopulateClaimRedirectionDetails Method Start");

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			String resultJson = "";
			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForloadPrePopulateClaimRedirectionDetails");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimRedirectionDetails", "responseCheck null");
					throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again!");
				}
				else {
					ClaimReqIBMredirectVO claimReqIBMredirectVO = (ClaimReqIBMredirectVO) bizRes.getTransferObjects().get("response1");

					if (claimReqIBMredirectVO == null) {

					}

					ClaimReqIBMredirectPO claimReqIBMredirectPO = dozerBeanMapper.map(claimReqIBMredirectVO, ClaimReqIBMredirectPO.class);

					if (claimReqIBMredirectPO == null) {
						FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimRedirectionDetails", "ftlToPdfVO null");
					}
					if(claimReqIBMredirectVO.getIsClaimReq()==1){
						p_ObjContext.getFlowScope().put("yesNo", true);
					}else{
						p_ObjContext.getFlowScope().put("yesNo", false);
					}
					resultJson = gsonJSON.toJson(claimReqIBMredirectPO);
					p_ObjContext.getFlowScope().put("Response", resultJson);
				}
			}
			else {

				FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimRedirectionDetails", "ftlToPdfVO null");

				throw new IPruException("Error", "CRAI01", "Some Error Occured");
			}
		}
		catch (Exception e) {

			FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimRedirectionDetails", "Exception came", e);
			throwINeoFlowException(e, "CRAI01", p_ObjContext);
		}

		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimRedirectionDetails", "getBizResponseforOnloadPrePopulateClaimRedirectionDetails Method end");
		return success();
	}

	@MethodPost
	public Event getBizRequestforCliamRequestIBMModelSubmit(RequestContext p_ObjContext) throws Exception {

		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforCliamRequestIBMModelSubmit", "getBizRequestforCliamRequestIBMModelSubmit Method Start ");

		try {

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			StringBuffer jb = new StringBuffer();
			String line = null;
			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}

			ClaimRequestIBMSubmitPO claimRequestIBMSubmitPO = gsonJSON.fromJson(jb.toString(), ClaimRequestIBMSubmitPO.class);

			if (claimRequestIBMSubmitPO == null) {
				throw new IPruException("Error", "CRAI01", "Some Error Occured");
			}
			ClaimRequestIBMPO claimRequestIBMPO = claimRequestIBMSubmitPO.getClaimRequestIBMPO();

			if (claimRequestIBMPO == null) {
				throw new IPruException("Error", "CRAI01", "Some Error Occured");
			}

			ClaimRequestIBMValidator claimValidator = new ClaimRequestIBMValidator();

			String validationError = claimValidator.ValidateClaimRequestValidator(claimRequestIBMPO, p_ObjContext);

			if (StringUtils.isNotEmpty(validationError)) {

				throw new IPruException("Error", "CRAI01", validationError);
			}

			ClaimRequestIBMVO claimRequestIBMVO = dozerBeanMapper.map(claimRequestIBMPO, ClaimRequestIBMVO.class);

			if (claimRequestIBMVO == null) {
				throw new IPruException("Error", "CRAI01", validationError);
			}
			p_ObjContext.getFlowScope().put("claimRequestIBMVOData", claimRequestIBMVO);
			Object[] paramArray = new Object[1];
			paramArray[0] = claimRequestIBMVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {
			throwINeoFlowException(e, "CRAI01", p_ObjContext);
			FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforCliamRequestIBMModelSubmit", "Exception came", e);

		}
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforCliamRequestIBMModelSubmit", "getBizRequestforCliamRequestIBMModelSubmit Method end ");

		return success();

	}

	@MethodPost
	public Event getBizResponseforSubmitCliamRequestIBMModel(RequestContext p_ObjContext) throws Exception {

		try {

			FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforSubmitCliamRequestIBMModel", "getBizResponseforSubmitCliamRequestIBMModel Method Start");

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			HttpSession httpSession = request.getSession();

			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForCliamRequestIBMModel");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforSubmitCliamRequestIBMModel", "responseCheck null");
					throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again!");
				}
				else {
					FtlToPdfVO ftlToPdfVO = (FtlToPdfVO) bizRes.getTransferObjects().get("response1");

					if (ftlToPdfVO == null) {

						FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforSubmitCliamRequestIBMModel", "ftlToPdfVO null");

						throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
					}

					httpSession.setAttribute("statementDownloadData", ftlToPdfVO);
					p_ObjContext.getFlowScope().put("Response", "success");
				}
			}
			else {

				FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforSubmitCliamRequestIBMModel", "ftlToPdfVO null");

				throw new IPruException("Error", "CRAI01", "Some Error Occured");
			}
		}
		catch (Exception e) {

			FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforSubmitCliamRequestIBMModel", "Exception came", e);
			throwINeoFlowException(e, "US01", p_ObjContext);
		}

		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforSubmitCliamRequestIBMModel", "getBizResponseforSubmitCliamRequestIBMModel Method end");
		return success();
	}

	@MethodPost
	public Event getBizResponseforOnloadAnnuityPerOptions(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadAnnuityPerOptions", "getBizResponseforOnloadAnnuityPerOptions Method End");
		String responselist = "";
		try {
			ClaimIbmDropDownPO claimIbmDropDownPO = null;
			List<ClaimIbmDropDownPO> claimIbmDropDownPOList = new ArrayList();
			ArrayList<String> data = new ArrayList<String>();
			data.add("0");
			data.add("66.67");
			data.add("50");
			data.add("100");
			for (int i = 0; i < data.size(); i++) {
				claimIbmDropDownPO = new ClaimIbmDropDownPO();
				claimIbmDropDownPO.setKey(String.valueOf(data.get(i)));
				claimIbmDropDownPO.setValue(String.valueOf(data.get(i)));
				claimIbmDropDownPOList.add(claimIbmDropDownPO);

			}

			if (CollectionUtils.isNotEmpty(claimIbmDropDownPOList)) {
				context.getFlowScope().put("onclaimIbmAnnuityPerOptions", claimIbmDropDownPOList);
				responselist = gsonJSON.toJson(claimIbmDropDownPOList);
				context.getFlowScope().put("Response", responselist);
			}
			else {

				FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadAnnuityPerOptions", "response should not be null");
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again!");
			}

		}
		catch (Exception e) {
			throwINeoFlowException(e, "CRAI01", context);
			FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "ClaimRequestIBMHandler", "Exception came", e);
		}
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadAnnuityPerOptions", "getBizResponseforOnloadAnnuityPerOptions Method End");
		return success();
	}
	
	
	
	@MethodPost
	public Event getBizResponseforOnloadBeneficiaryPayModeOptions(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPayMode", "getBizResponseforOnloadPayMode Method End");
		String responselist = "";
		try {
			ClaimIbmDropDownPO claimIbmDropDownPO = null;
			List<ClaimIbmDropDownPO> claimIbmDropDownPOList = new ArrayList();
			ArrayList<String> data = new ArrayList<String>();
			data.add("E");
			for (int i = 0; i < data.size(); i++) {
				claimIbmDropDownPO = new ClaimIbmDropDownPO();
				claimIbmDropDownPO.setKey(String.valueOf(data.get(i)));
				claimIbmDropDownPO.setValue(String.valueOf(data.get(i)));
				claimIbmDropDownPOList.add(claimIbmDropDownPO);

			}

			if (CollectionUtils.isNotEmpty(claimIbmDropDownPOList)) {
				context.getFlowScope().put("beneficiaryPayModeOptions", claimIbmDropDownPOList);
				responselist = gsonJSON.toJson(claimIbmDropDownPOList);
				context.getFlowScope().put("Response", responselist);
			}
			else {

				FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPayMode", "response should not be null");
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again!");
			}

		}
		catch (Exception e) {
			throwINeoFlowException(e, "CRAI01", context);
			FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "ClaimRequestIBMHandler", "Exception came", e);
		}
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadAnnuityPerOptions", "getBizResponseforOnloadAnnuityPerOptions Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseforOnloadCommutationOption(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadCommutationOption", "getBizResponseforOnloadCommutationOption Method start");
		String responselist = "";
		try {

			ClaimIbmDropDownPO claimIbmDropDownPO = null;
			List<ClaimIbmDropDownPO> claimIbmDropDownPOList = new ArrayList();
			ArrayList<String> data = new ArrayList<String>();
			data.add("0");
			data.add("33.33");
			data.add("50");
			data.add("100");

			for (int i = 0; i < data.size(); i++) {
				claimIbmDropDownPO = new ClaimIbmDropDownPO();
				claimIbmDropDownPO.setKey(String.valueOf(data.get(i)));
				claimIbmDropDownPO.setValue(String.valueOf(data.get(i)));
				claimIbmDropDownPOList.add(claimIbmDropDownPO);

			}

			if (CollectionUtils.isNotEmpty(claimIbmDropDownPOList)) {
				context.getFlowScope().put("onclaimCommutationOption", claimIbmDropDownPOList);
				responselist = gsonJSON.toJson(claimIbmDropDownPOList);
				context.getFlowScope().put("Response", responselist);
			}
			else {

				FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadCommutationOption", "response should not be null");
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}

		}
		catch (Exception e) {
			throwINeoFlowException(e, "CRAI01", context);
			FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadCommutationOption", "Exception came", e);
		}
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadCommutationOption", "getBizResponseforOnloadCommutationOption Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseforOnloadgetTypeOfClaims(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadgetTypeOfClaims", "getBizResponseforOnloadgetTypeOfClaims Method Start");
		String responselist = "";
		try {

			ClaimIbmDropDownPO claimIbmDropDownPO = null;
			List<ClaimIbmDropDownPO> claimIbmDropDownPOList = new ArrayList();
			ArrayList<String> data = new ArrayList();
			data.add("Retirement");
			data.add("Resignation");

			for (int i = 0; i < data.size(); i++) {
				claimIbmDropDownPO = new ClaimIbmDropDownPO();
				claimIbmDropDownPO.setKey(String.valueOf(data.get(i)));
				claimIbmDropDownPO.setValue(String.valueOf(data.get(i)));
				claimIbmDropDownPOList.add(claimIbmDropDownPO);

			}

			if (CollectionUtils.isNotEmpty(claimIbmDropDownPOList)) {
				context.getFlowScope().put("onloadTypesOfClaims", claimIbmDropDownPOList);
				responselist = gsonJSON.toJson(claimIbmDropDownPOList);
				context.getFlowScope().put("Response", responselist);
			}
			else {

				FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadgetTypeOfClaims", "response should not be null");
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}

		}
		catch (Exception e) {
			throwINeoFlowException(e, "CRAI01", context);
			FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadgetTypeOfClaims", "Exception came", e);
		}
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadgetTypeOfClaims", "getBizResponseforOnloadgetTypeOfClaims Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseforOnloadgetGratuityOptions(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadgetGratuityOptions", "getBizResponseforOnloadgetGratuityOptions Method start");
		String responselist = "";
		try {
			ClaimIbmDropDownPO claimIbmDropDownPO = null;
			List<ClaimIbmDropDownPO> claimIbmDropDownPOList = new ArrayList();
			ArrayList<String> data = new ArrayList();
			data.add("Yes");
			data.add("No");

			for (int i = 0; i < data.size(); i++) {
				claimIbmDropDownPO = new ClaimIbmDropDownPO();
				claimIbmDropDownPO.setKey(String.valueOf(data.get(i)));
				claimIbmDropDownPO.setValue(String.valueOf(data.get(i)));
				claimIbmDropDownPOList.add(claimIbmDropDownPO);

			}

			if (CollectionUtils.isNotEmpty(claimIbmDropDownPOList)) {
				context.getFlowScope().put("onloadGratuityOptions", claimIbmDropDownPOList);
				responselist = gsonJSON.toJson(claimIbmDropDownPOList);
				context.getFlowScope().put("Response", responselist);
			}
			else {

				FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadgetGratuityOptions", "response should not be null");
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}

		}
		catch (Exception e) {
			throwINeoFlowException(e, "CRAI01", context);
			FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadgetGratuityOptions", "Exception came", e);
		}
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadgetGratuityOptions", "getBizResponseforOnloadgetGratuityOptions Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseforOnloadPrepopulateDataforClaimRequest(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrepopulateDataforClaimRequest", "getBizResponseforOnloadPrepopulateDataforClaimRequest Method Start");
		String responselist = "";
		try {
			FunctionalityMasterVO functionality;

			functionality = this.getFunctionality(context);
			if (functionality == null) {
				FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrepopulateDataforClaimRequest", "functionalityId  should not be null");
				throw new IPruException("Error", "CRAI01", ErrorMsg);
			}

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			IPruUser userVO = (IPruUser) httpSession.getAttribute("userVO");
			ClaimRequestIBMPO claimRequestIBMPO = new ClaimRequestIBMPO();
			claimRequestIBMPO.setPolicyNo(userVO.getPolicyNo());
			claimRequestIBMPO.setEmployeeId(userVO.getEmpId());
			claimRequestIBMPO.setFunctionalityId(String.valueOf(functionality.getFunctionalityId()));

			if (claimRequestIBMPO == null) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again!");
			}

			functionality = this.getFunctionality(context);
			if (functionality == null) {
				FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrepopulateDataforClaimRequest", "functionalityId  should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			responselist = gsonJSON.toJson(claimRequestIBMPO);
			context.getFlowScope().put("Response", responselist);

		}
		catch (Exception e) {
			throwINeoFlowException(e, "CRAI01", context);
			FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrepopulateDataforClaimRequest", "Exception came", e);
		}
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrepopulateDataforClaimRequest", "getBizResponseforOnloadPrepopulateDataforClaimRequest Method End");
		return success();
	}

	@MethodPost
	public Event getBizRequestforClaimRequestIBMPOSubmitWithDownload(RequestContext p_ObjContext) throws Exception {
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforClaimRequestIBMPOSubmitWithDownload", "getBizRequestforClaimRequestIBMPOSubmitWithDownload Method Start ");

		FunctionalityMasterVO functionality;
		CommonFileUploadUtil commonFileUploadUtil = new CommonFileUploadUtil();

		try {

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			IPruUser userVO = (IPruUser) httpSession.getAttribute("userVO");
			
			StringBuffer jb = new StringBuffer();
			String line = null;
			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}

			ClaimRequestIBMSubmitPO claimRequestIBMSubmitPO = gsonJSON.fromJson(jb.toString(), ClaimRequestIBMSubmitPO.class);

			if (claimRequestIBMSubmitPO == null) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again!");
			}

			functionality = this.getFunctionality(p_ObjContext);

			if (functionality == null) {
				FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforClaimRequestIBMPOSubmitWithDownload", "functionalityId  should not be null");
				throw new IPruException("Error", "CRAI01", ErrorMsg);
			}
			
			 ClaimRequestIBMVO claimRequestIBMVO1= (ClaimRequestIBMVO) p_ObjContext.getFlowScope().get("claimRequestIBMVOData");
			
			 
			 if(claimRequestIBMVO1==null)
			 {
				 throw new IPruException("Error", "CRAI01", "Your claim request is not yet received from your trust.");
			 }
			 
			 if(!(claimRequestIBMVO1.getTypeOfClaim().equalsIgnoreCase("Resignation")) && !(claimRequestIBMVO1.getTypeOfClaim().equalsIgnoreCase("Retirement")))
			 {
				 throw new IPruException("Error", "CRAI01", "Your claim request type is not Resignation or Retirement.");
			 }
			 
			 
			
			if (claimRequestIBMSubmitPO.getClaimRequestIBMPO() == null && claimRequestIBMSubmitPO.getUploadFileList1() == null && claimRequestIBMSubmitPO.getUploadFileList2() == null
					&& claimRequestIBMSubmitPO.getUploadFileList3() == null && claimRequestIBMSubmitPO.getUploadFileList4() == null) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again!");
			}

			ClaimRequestIBMPO claimRequestIBMPO = claimRequestIBMSubmitPO.getClaimRequestIBMPO();

			List<UploadFilePO> uploadFilePO1 = claimRequestIBMSubmitPO.getUploadFileList1();
			List<UploadFilePO> uploadFilePO2 = claimRequestIBMSubmitPO.getUploadFileList2();
			List<UploadFilePO> uploadFilePO3 = claimRequestIBMSubmitPO.getUploadFileList3();
			List<UploadFilePO> uploadFilePO4 = claimRequestIBMSubmitPO.getUploadFileList4();

			List<UploadFilePO> uploadFilePOList = new ArrayList();

			for (UploadFilePO po : uploadFilePO1) {
				uploadFilePOList.add(po);
			}

			for (UploadFilePO po1 : uploadFilePO2) {
				uploadFilePOList.add(po1);
			}

			for (UploadFilePO po3 : uploadFilePO3) {
				uploadFilePOList.add(po3);
			}

			for (UploadFilePO po4 : uploadFilePO4) {
				uploadFilePOList.add(po4);
			}

			String checkFileUploadStatus = commonFileUploadUtil.checkUploadFileContent(uploadFilePOList, p_ObjContext, "ClaimAnnuityRequestlogger");
			if (StringUtils.isNotEmpty(checkFileUploadStatus)) {
				throw new IPruException("Error", "GRPSWP01", checkFileUploadStatus);
			}

			if (CollectionUtils.isEmpty(uploadFilePO1)) {
				throw new IPruException("Error", "CRAI01", "Please select atleast one file");
			}
			if (uploadFilePO1.size() != 1) {
				throw new IPruException("Error", "CRAI01", "Can not upload more than one Cancelled Cheque Copy");
			}

			if (CollectionUtils.isEmpty(uploadFilePO2)) {
				throw new IPruException("Error", "CRAI01", "Please select atleast one file");
			}
			if (uploadFilePO2.size() != 1) {
				throw new IPruException("Error", "CRAI01", "Can not upload more than one Scanned Claim Document ");
			}

			if (CollectionUtils.isEmpty(uploadFilePO3)) {
				throw new IPruException("Error", "CRAI01", "Please select atleast one file");
			}
			if (uploadFilePO3.size() > 3) {
				throw new IPruException("Error", "CRAI01", "Please upload ITR Returns - last 3 Years. Only Three document required ");
			}

			if (CollectionUtils.isEmpty(uploadFilePO4)) {
				throw new IPruException("Error", "CRAI01", "Please select atleast one file");
			}
			if (uploadFilePO4.size() != 1) {
				throw new IPruException("Error", "CRAI01", "Can not upload more than one Pan Card");
			}

			if (claimRequestIBMPO == null) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}

			ClaimRequestIBMValidator claimValidator = new ClaimRequestIBMValidator();
			String validationError = claimValidator.recheckClaimRequestAnnuityScannedData(claimRequestIBMPO, p_ObjContext);

			if (StringUtils.isNotBlank(validationError)) {
				throw new IPruException("Error", "CRAI01", validationError);
			}

			String validationError1 = claimValidator.ValidateClaimRequestValidator(claimRequestIBMPO, p_ObjContext);

			Double total = Double.parseDouble(claimRequestIBMPO.getAnnuityPer()) + Double.parseDouble(claimRequestIBMPO.getCommutationPer());

			if (total != 100 || total != 100.0) {
				throw new IPruException("Error", "CRAI01", "Sum of commutation and annuity should be 100");
			}
			if (StringUtils.isNotEmpty(validationError1)) {

				throw new IPruException("Error", "CRAI01", validationError1);
			}

			List<List<UploadFilePO>> uploadList = new ArrayList<List<UploadFilePO>>();
			uploadList.add(uploadFilePO1);
			uploadList.add(uploadFilePO2);
			uploadList.add(uploadFilePO3);
			uploadList.add(uploadFilePO4);

			if (CollectionUtils.isEmpty(uploadList)) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}

			claimRequestIBMSubmitPO.setClaimRequestIBMPOUploadList(uploadList);
			claimRequestIBMSubmitPO.setFunctionality(functionality);

			ClaimAnnuityIBMSubmitVO claimAnnuityIBMSubmitVO = dozerBeanMapper.map(claimRequestIBMSubmitPO, ClaimAnnuityIBMSubmitVO.class);

			ClaimRequestIBMVO claimRequestIBMVO = dozerBeanMapper.map(claimRequestIBMSubmitPO.getClaimRequestIBMPO(), ClaimRequestIBMVO.class);

			if (claimAnnuityIBMSubmitVO == null) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}
			List<UploadFileVO> uploadFileVO1 = (List<UploadFileVO>) claimAnnuityIBMSubmitVO.getUploadFileList1();
			List<UploadFileVO> uploadFileVO2 = claimAnnuityIBMSubmitVO.getUploadFileList2();
			List<UploadFileVO> uploadFileVO3 = claimAnnuityIBMSubmitVO.getUploadFileList3();
			List<UploadFileVO> uploadFileVO4 = claimAnnuityIBMSubmitVO.getUploadFileList4();

			List<List<UploadFileVO>> uploadList1 = new ArrayList<List<UploadFileVO>>();

			uploadList1.add(uploadFileVO1);
			uploadList1.add(uploadFileVO2);
			uploadList1.add(uploadFileVO3);
			uploadList1.add(uploadFileVO4);

			if (CollectionUtils.isEmpty(uploadList1)) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}

			claimAnnuityIBMSubmitVO.setClaimRequestIBMVO(claimRequestIBMVO);
			claimAnnuityIBMSubmitVO.setClaimRequestIBMVOUploadList(uploadList1);

			if (claimAnnuityIBMSubmitVO.getClaimRequestIBMVO() == null && CollectionUtils.isEmpty(claimAnnuityIBMSubmitVO.getClaimRequestIBMVOUploadList())) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}

			claimAnnuityIBMSubmitVO.getClaimRequestIBMVO().setClientId(userVO.getClientId());
			claimAnnuityIBMSubmitVO.getClaimRequestIBMVO().setRole(userVO.getRoles());
			
			
			Object[] paramArray = new Object[1];
			paramArray[0] = claimAnnuityIBMSubmitVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {
			throwINeoFlowException(e, "CRAI01", p_ObjContext);
			FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadgetTitleDetails", "Exception came", e);

		}
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforClaimRequestIBMPOSubmitWithDownload", "getBizRequestforClaimRequestIBMPOSubmitWithDownload Method end ");

		return success();

	}

	@MethodPost
	public Event getBizResponseforClaimRequestIBMPOSubmitWithDownload(RequestContext p_ObjContext) throws Exception {

		try {

			FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforClaimRequestIBMPOSubmitWithDownload", "getBizResponseforClaimRequestIBMPOSubmitWithDownload Method Start");

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForClaimRequestIBMVOSubmitWithDownload");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforClaimRequestIBMPOSubmitWithDownload", "responseCheck null");
					throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again!");
				}
				else {
					Long claimId = (Long) bizRes.getTransferObjects().get("response1");

					if (claimId == null) {

						FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforClaimRequestIBMPOSubmitWithDownload", "ftlToPdfVO null");

						throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
					}

					p_ObjContext.getFlowScope().put("Response", claimId);
				}
			}
			else {

				FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforClaimRequestIBMPOSubmitWithDownload", "ftlToPdfVO null");

				throw new IPruException("Error", "CRAI01", "Some Error Occured");
			}
		}
		catch (Exception e) {

			FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforClaimRequestIBMPOSubmitWithDownload", "Exception came", e);
			throwINeoFlowException(e, "CRAI01", p_ObjContext);
		}

		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforClaimRequestIBMPOSubmitWithDownload", "getBizResponseforClaimRequestIBMPOSubmitWithDownload Method end");
		return success();
	}
	
	
	
	@MethodPost
	public Event getBizRequestforOnloadPrePopulateClaimAnnuityIBMDetails(RequestContext p_ObjContext) throws Exception {

		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforOnloadPrePopulateClaimAnnuityIBMDetails", "getBizRequestforOnloadPrePopulateClaimAnnuityIBMDetails Method Start ");

		try {

			//HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			IPruUser userVO = (IPruUser) httpSession.getAttribute("userVO");

			ClaimAnnuityIBMReqPO claimAnnuityIBMReqPO = new ClaimAnnuityIBMReqPO();

			if (StringUtils.isEmpty(userVO.getPolicyNo()) && StringUtils.isEmpty(userVO.getEmpId())) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}
			claimAnnuityIBMReqPO.setEmployeeId(userVO.getEmpId());
			
			ClaimAnnuityIBMReqVO claimAnnuityIBMReqVO = dozerBeanMapper.map(claimAnnuityIBMReqPO, ClaimAnnuityIBMReqVO.class);

			if (claimAnnuityIBMReqVO == null) {
				throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again");
			}

			Object[] paramArray = new Object[1];
			paramArray[0] = claimAnnuityIBMReqVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {
			throwINeoFlowException(e, "CRAI01", p_ObjContext);
			FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforOnloadPrePopulateClaimAnnuityIBMDetails", "Exception came", e);

		}
		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizRequestforOnloadPrePopulateClaimAnnuityIBMDetails", "getBizRequestforOnloadPrePopulateClaimAnnuityIBMDetails Method End ");
		return success();

	}
	
	
	@MethodPost
	public Event getBizResponseforOnloadPrePopulateClaimAnnuityIBMDetails(RequestContext p_ObjContext) throws Exception {

		try {

			FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimAnnuityIBMDetails", "getBizResponseforOnloadPrePopulateClaimAnnuityIBMDetails Method Start");

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			String responselist="";
			ClaimExcelDataPO claimExcelDataPO=null;
			List<ClaimExcelDataPO> claimExcelDataPOList=new ArrayList();
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForloadPrePopulateClaimAnnuityIBMDetails");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimAnnuityIBMDetails", "responseCheck null");
					throw new IPruException("Error", "CRAI01", "Some thing went wrong please try again!");
				}
				else {
					
					FunctionalityMasterVO functionality;
					functionality = this.getFunctionality(p_ObjContext);
					
					if (functionality == null) {
						FLogger.error("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrepopulateDataforClaimRequest", "functionalityId  should not be null");
						throw new IPruException("Error", "CRAI01", ErrorMsg);
					}

					List<ClaimExcelDataVO> claimExcelDataVOlist = (List<ClaimExcelDataVO>) bizRes.getTransferObjects().get("response1");
					
					if(!CollectionUtils.isEmpty(claimExcelDataVOlist))
					{
						for(ClaimExcelDataVO claimExcelDataVO:claimExcelDataVOlist){
							claimExcelDataPO=new ClaimExcelDataPO();
							claimExcelDataPO = dozerBeanMapper.map(claimExcelDataVO, ClaimExcelDataPO.class);
							
						
							claimExcelDataPOList.add(claimExcelDataPO);
						}
						
						p_ObjContext.getFlowScope().put("claimExcelDataPOData", claimExcelDataVOlist.get(0));
						
						claimExcelDataPO=claimExcelDataPOList.get(0);
						claimExcelDataPO.setFunctionalityId(String.valueOf(functionality.getFunctionalityId()));
						
						responselist = gsonJSON.toJson(claimExcelDataPO);
						p_ObjContext.getFlowScope().put("Response", responselist);
					}
					else{
						responselist = gsonJSON.toJson(claimExcelDataPOList);
						p_ObjContext.getFlowScope().put("Response", responselist);
					}
					
				}
			}
			else {

				FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimAnnuityIBMDetails", "ftlToPdfVO null");

				throw new IPruException("Error", "CRAI01", "Some Error Occured");
			}
		}
		catch (Exception e) {

			FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimAnnuityIBMDetails", "Exception came", e);
			throwINeoFlowException(e, "CRAI01", p_ObjContext);
		}

		FLogger.info("ClaimAnnuityRequestlogger", "ClaimRequestIBMHandler", "getBizResponseforOnloadPrePopulateClaimAnnuityIBMDetails", "getBizResponseforOnloadPrePopulateClaimAnnuityIBMDetails Method end");
		return success();
	}
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
