package com.ipru.groups.handler;

import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.BrokerAccruedResponsePO;
import com.ipru.groups.scheduler.SpaarcCallLogScheduler;

import com.ipru.groups.vo.BrokerAccruedRequestVO;
import com.ipru.groups.vo.BrokerAccruedResponseVO;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BrokerAccruedCommissionHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final String CLASS_NAME = BrokerAccruedCommissionHandler.class.getCanonicalName();
	private static final String INFO_LOGGER_NAME = "BrokerAccruedCommissionSummaryLogger";
	private static final String ERROR_LOGGER_NAME = "BrokerAccruedCommissionSummaryLogger";

	@MethodPost
	public Event getBizRequestOnLoadAccruedCommission(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestOnLoadAccruedCommission";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start");
		Gson gson = new Gson();

		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
/*				String clientName = null;
				String policyNo = null;*/
				String branchCode = null;
				String loginType = null;
				String nationalCode = null;
				String brokerType=null;
				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");


					if (userVo != null) {
						FscDetailsVO fscDetailVo = userVo.getFscdetails();
						if(fscDetailVo != null){
							branchCode = fscDetailVo.getBranchCode();// Will get from session
							loginType = fscDetailVo.getLogin_type();// Will get from session
							nationalCode = fscDetailVo.getNationalCode(); // Will get from session
							brokerType=fscDetailVo.getFscChannel();
						}
						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

						if (request != null) {
							BrokerAccruedRequestVO brokerAccruedRequestVO = new BrokerAccruedRequestVO();
			/*				brokerAccruedRequestVO.setPolicyNo(policyNo);
							brokerAccruedRequestVO.setClientName(clientName);*/
							brokerAccruedRequestVO.setBranchCode(branchCode);
							brokerAccruedRequestVO.setLoginType(loginType);
							brokerAccruedRequestVO.setNationalCode(nationalCode);
							brokerAccruedRequestVO.setBrokerType(brokerType);

							Object[] paramArray = new Object[1];

							if (brokerAccruedRequestVO != null) {
								paramArray[0] = brokerAccruedRequestVO;
								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);
								context.getFlowScope().put("BrokerAccruedBizReqOnLoad", obj_bizReq);
							}
						}
						else {

							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "request should not be null");
							throw new IPruException("Error", "GRPBAC", "request should not be null");
						}
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
						throw new IPruException("Error", "GRPBAC", "userVo should not be null");
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
					throw new IPruException("Error", "GRPBAC", "httpSession should not be null");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Context should not be null");
				throw new IPruException("Error", "GRPBAC", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBAC", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, " Method End ");
		return success();
	}

	@MethodPost
	public Event getBizResponseOnLoadAccruedCommission(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseOnLoadAccruedCommission";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForBrokerAccruedOnLoad");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {

						List<BrokerAccruedResponseVO> brokerAccruedResponseVOList = (List<BrokerAccruedResponseVO>) bizRes.getTransferObjects().get("response1");

						List<BrokerAccruedResponsePO> brokerAccruedResponsePOList = null;
						if (brokerAccruedResponseVOList != null) {
							brokerAccruedResponsePOList = new ArrayList<BrokerAccruedResponsePO>();

							for (BrokerAccruedResponseVO brokerAccruedResponseVO : brokerAccruedResponseVOList) {

								BrokerAccruedResponsePO brokerAccruedResponsePO = dozerBeanMapper.map(brokerAccruedResponseVO, BrokerAccruedResponsePO.class);

								brokerAccruedResponsePOList.add(brokerAccruedResponsePO);
							}

						}
						String callJsonString = gsonJSON.toJson(brokerAccruedResponsePOList);
						FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "callJsonString::" + callJsonString);
						context.getFlowScope().put("Response", callJsonString);
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBAC", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");

		return success();

	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
