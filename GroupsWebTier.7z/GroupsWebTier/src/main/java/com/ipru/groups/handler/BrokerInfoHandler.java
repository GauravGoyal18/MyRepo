package com.ipru.groups.handler;

import java.io.BufferedReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.generic.po.ResultJsonPO;
import com.ipru.groups.po.BrokerInfoPO;
import com.ipru.groups.po.ReportWrapperPO;
import com.ipru.groups.po.UnitStatementLoadRequestPO;
import com.ipru.groups.po.UnitStatementLoadResponsePO;
import com.ipru.groups.po.UnitStatementPO;
import com.ipru.groups.po.UnitStatementRequestPO;
import com.ipru.groups.profile.bean.ProfilePOCPO;
import com.ipru.groups.utilities.DateUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.utilities.UnitStatementPojoUtil;
import com.ipru.groups.vo.BrokerInfoVO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FtlToPdfVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.ReportWrapperVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.groups.vo.UnitStatementLoadRequestVO;
import com.ipru.groups.vo.UnitStatementLoadResponseVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BrokerInfoHandler extends IneoBaseHandler {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String ErrorMsg = "Something went wrong please try again!";
	
	@MethodPost
	public Event getBizRequestforSubmitBrokerInfo(RequestContext p_ObjContext) throws Exception {
		FLogger.info("BrokerInfoLogger", "BrokerInfoHandler", "getBizRequestforSubmitBrokerInfo", "getBizRequestforSubmitBrokerInfo Method Start");

		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
	
		FunctionalityMasterVO functionality;

		try {
			
			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();

			StringBuffer jb = new StringBuffer();
			String line = null;

			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}

			functionality = this.getFunctionality(p_ObjContext);

			/*	if (functionality == null) {
				FLogger.error("UnitStatementLogger", "UnitStatementHandler", "getBizRequestforUnitStatementSubmit", "functionality Should not be null");
				throw new IPruException("Error", "US01", ErrorMsg);
			}*/
			
			IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

			if (userVo == null) {  
				FLogger.error("BrokerInfoLogger", "BrokerInfoHandler", "getBizRequestforSubmitBrokerInfo", "userVo Should not be null");
				throw new IPruException("Error", "BR01", ErrorMsg);
			}

		
			BrokerInfoPO brokerInfoPO = gsonJSON.fromJson(jb.toString(), BrokerInfoPO.class);

			if (brokerInfoPO == null) {
				FLogger.error("BrokerInfoLogger", "BrokerInfoHandler", "getBizRequestforSubmitBrokerInfo", "brokerInfoPO Should not be null");
				throw new IPruException("Error", "BR01", ErrorMsg);
			}

			brokerInfoPO.setPolicyNo(userVo.getPolicyNo());
			//brokerInfoPO.setPolicyNo("00002285");
			
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd MMMM,yyyy");
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MMM-yyyy");

			Date startDate1 = sdf1.parse(brokerInfoPO.getStartDate());
			String startDate = sdf2.format(startDate1);

			Date endDate1 = sdf1.parse(brokerInfoPO.getEndDate());
			String endDate = sdf2.format(endDate1);

			if (startDate1.after(endDate1)) {

				throw new IPruException("Error", "BR01", "Todate date should not be greater than From date");

			}
			
			brokerInfoPO.setStartDate(startDate);
			brokerInfoPO.setEndDate(endDate);
			BrokerInfoVO brokerInfoVO = dozerBeanMapper.map(brokerInfoPO, BrokerInfoVO.class);

			if (brokerInfoVO == null) {
				FLogger.error("BrokerInfoLogger", "BrokerInfoHandler", "getBizRequestforSubmitBrokerInfo", "brokerInfoPO should not be null");
				throw new IPruException("Error", "BR01", ErrorMsg);
			}

		
			Object[] paramArray = new Object[1];
			paramArray[0] = brokerInfoVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {

			FLogger.error("BrokerInfoLogger", "BrokerInfoHandler", "getBizRequestforSubmitBrokerInfo", "Exception came ", e);
			throwINeoFlowException(e, "BR01", p_ObjContext);
		}
		FLogger.info("BrokerInfoLogger", "BrokerInfoHandler", "getBizRequestforSubmitBrokerInfo", "getBizRequestforSubmitBrokerInfo Method End");
		return success();

	}

	@MethodPost
	public Event getBizResponseforSubmitBrokerInfo(RequestContext p_ObjContext) throws Exception {

		try {

			FLogger.info("BrokerInfoLogger", "BrokerInfoHandler", "getBizResponseforSubmitBrokerInfo", "getBizResponseforSubmitBrokerInfo Method Start");

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			HttpSession httpSession = request.getSession();

			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForBrokerInfo");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.info("BrokerInfoLogger", "BrokerInfoHandler", "getBizResponseforSubmitBrokerInfo", "responseCheck null");
					throw new IPruException("Error", "BR01", "No fund data found between provided duration");
				}
				else {
					String url = (String) bizRes.getTransferObjects().get("response1");
					
					if(StringUtils.isEmpty(url))
					{
						FLogger.info("BrokerInfoLogger", "BrokerInfoHandler", "getBizResponseforSubmitBrokerInfo", "responseCheck null");
						throw new IPruException("Error", "BR01", "url");	
					}
					
					p_ObjContext.getFlowScope().put("Response",url);
				}
			}
			else {

				FLogger.info("BrokerInfoLogger", "BrokerInfoHandler", "getBizResponseforSubmitBrokerInfo", "url null");

				throw new IPruException("Error", "BR01", "Some Error Occured");
			}
		}
		catch (Exception e) {

			FLogger.info("UnitStatementLogger", "UnitStatementHandler", "getBizResponseforUnitStatementSubmit", "Exception came", e);
			throwINeoFlowException(e, "BR01", p_ObjContext);
		}

		FLogger.info("UnitStatementLogger", "UnitStatementHandler", "getBizResponseforUnitStatementSubmit", "getBizResponseforUnitStatementSubmit Method end");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
