package com.ipru.groups.security;

import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.ipru.groups.po.GroupRetailLoginInfoPO;
import com.ipru.groups.security.encryption.EncryptionAES256;
import com.ipru.groups.utilities.EncodingUtility;
import com.tcs.logger.FLogger;

public class GroupsRetailSSO {

	public GroupRetailLoginInfoPO getRetailDetails(String groupRetailBean, Properties prop) throws SSOGroupDefaultException {
		// TODO Auto-generated method stub

		GroupRetailLoginInfoPO groupRetailLoginInfoPO = new GroupRetailLoginInfoPO();

		if (!StringUtils.isEmpty(groupRetailBean)) {
			try {
				String decryptkey = prop.getProperty("GroupRetailKey");
				groupRetailLoginInfoPO = groupRetailParseRequest(groupRetailBean, decryptkey);
				if (groupRetailLoginInfoPO != null) {
					if (StringUtils.isEmpty(groupRetailLoginInfoPO.getMobileNo()) || StringUtils.isEmpty(groupRetailLoginInfoPO.getEmailId())
							|| StringUtils.isEmpty(groupRetailLoginInfoPO.getWebClientId()) || groupRetailLoginInfoPO.getMilliseconds() == 0) {
						SSOGroupDefaultException authException = new SSOGroupDefaultException("Request is not valid") {
						};
						FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "GroupRetailLoginInfoPO is not parsed ");
						throw authException;
					}
				}
				else {
					SSOGroupDefaultException authException = new SSOGroupDefaultException("Request is not valid") {
					};
					FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "GroupRetailLoginInfoPO is not parsed ");
					throw authException;
				}
			}
			catch (Exception e) {
				throw new SSOGroupDefaultException("Request is not valid");
			}

		}

		return groupRetailLoginInfoPO;

	}

	private GroupRetailLoginInfoPO groupRetailParseRequest(String encryptedcontent, String decryptkey) throws Exception {

		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "groupRetailParseRequest", "Method start for single sign on");

		GroupRetailLoginInfoPO groupRetailLoginInfoPO = new GroupRetailLoginInfoPO();

		groupRetailLoginInfoPO = this.getSSODecodingValue(this.getSSOAES256DecryptedJSON(encryptedcontent, decryptkey));

		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "groupRetailParseRequest", "Method end for single sign on");

		return groupRetailLoginInfoPO;

	}

	private GroupRetailLoginInfoPO getSSOAES256DecryptedJSON(String encryptedcontent, String decryptkey) throws Exception {

		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "getSSOAES256DecryptedJSON", " Method start for Decryption JSON");

		GroupRetailLoginInfoPO groupRetailLoginInfoPO = new GroupRetailLoginInfoPO();

		Gson gson = new Gson();

		groupRetailLoginInfoPO = gson.fromJson(EncryptionAES256.decrypt(encryptedcontent, decryptkey), GroupRetailLoginInfoPO.class);

		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "getSSOAES256DecryptedJSON", " Method End for Decryption JSON");

		return groupRetailLoginInfoPO;

	}

	private GroupRetailLoginInfoPO getSSODecodingValue(GroupRetailLoginInfoPO groupRetailLoginInfoPO) throws Exception {

		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "getSSODecodingValue", " Method start for SSOEncodingValue JSON");

		if (!StringUtils.isEmpty(groupRetailLoginInfoPO.getWebClientId())) {

			String decodedWcId = EncodingUtility.decodeBase64(groupRetailLoginInfoPO.getWebClientId());

			groupRetailLoginInfoPO.setWebClientId(!StringUtils.isEmpty(decodedWcId) ? decodedWcId : null);

		}

		else {

			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "GroupRetailLoginInfoPO", "WebClientId should not be null");

			groupRetailLoginInfoPO.setWebClientId(null);

		}

		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "getSSODecodingValue", " Method End for SSOEncodingValue JSON");

		return groupRetailLoginInfoPO;

	}

}
