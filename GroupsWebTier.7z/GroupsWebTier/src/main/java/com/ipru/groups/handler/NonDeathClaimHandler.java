package com.ipru.groups.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.ClaimsRequestTransactionPO;
import com.ipru.groups.po.NonDeathClaimSubmitRequestPO;
import com.ipru.groups.po.NonDeathClaimTransactionPO;
import com.ipru.groups.validators.NonDeathClaimValidator;
import com.ipru.groups.vo.ClaimsRequestTransactionVO;
import com.ipru.groups.vo.NonDeathClaimSubmitRequestVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class NonDeathClaimHandler extends IneoBaseHandler {

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

	@MethodPost
	public Event getBizRequestforSubmitClaims(RequestContext context) throws Exception {

		FLogger.info("NonDeathClaimLogger", "NonDeathClaimHandler", "getBizRequestforSubmitClaims", "Method start ");

		String clientId = null;
		String policyNo = null;
		String role = null;
		String productType = null;
		String memberType = null;

		long functionalityId = this.getFunctionalityId(context);

		try {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			if (httpSession != null) {
				IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
				if (userVo != null) {
					clientId = userVo.getClientId();
					policyNo = userVo.getPolicyNo();
					role = userVo.getRoles();
					productType = userVo.getProductType();
					memberType = userVo.getRoleType();

					HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
					if (request != null) {
						NonDeathClaimSubmitRequestPO nonDeathClaimSubmitRequestPO = gsonJSON.fromJson(request.getReader(), NonDeathClaimSubmitRequestPO.class);

						NonDeathClaimValidator nonDeathClaimValidator = new NonDeathClaimValidator();

						String validation = nonDeathClaimValidator.validateNonDeathClaimSubmitRequestPO(context, nonDeathClaimSubmitRequestPO);

						if (StringUtils.isNotBlank(validation)) {
							FLogger.error("NonDeathClaimError", "NonDeathClaimHandler", "getBizRequestforSubmitClaims", "Validation errors : " + validation);
							this.setValidationErrorMessages(validation);
							throw new IPruException("Error", "GRPNDC01", validation);
						}

						if (nonDeathClaimSubmitRequestPO != null) {

							NonDeathClaimSubmitRequestVO nonDeathClaimSubmitRequestVO = dozerBeanMapper.map(nonDeathClaimSubmitRequestPO, NonDeathClaimSubmitRequestVO.class);

							nonDeathClaimSubmitRequestVO.setClientId(clientId);
							nonDeathClaimSubmitRequestVO.setPolicyNo(policyNo);
							nonDeathClaimSubmitRequestVO.setRole(role);
							nonDeathClaimSubmitRequestVO.setMemberType(memberType);
							nonDeathClaimSubmitRequestVO.setProductType(productType);
							nonDeathClaimSubmitRequestVO.setFunctionalityId(functionalityId);

							Object[] paramArray = new Object[1];
							paramArray[0] = nonDeathClaimSubmitRequestVO;

							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("saveBizReq", obj_bizReq);
						}
					}
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("NonDeathClaimError", "NonDeathClaimHandler", "getBizRequestforSubmitClaims", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}

		FLogger.info("NonDeathClaimLogger", "NonDeathClaimHandler", "getBizRequestforSubmitClaims", "Method end ");
		return success();
	}

	@MethodPost
	public Event getBizResponseforSubmitClaims(RequestContext context) throws Exception {
		FLogger.info("NonDeathClaimLogger", "NonDeathClaimHandler", "getBizResponseforSubmitClaims", "Method start ");

		ClaimsRequestTransactionVO claimsRequestTransactionVO = new ClaimsRequestTransactionVO();
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			bizRes = (BizResponse) context.getFlowScope().get("saveBizRes");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error("NonDeathClaimError", "NonDeathClaimHandler", "getBizResponseforSubmitClaims", "Error came while getting response from service");
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {
					claimsRequestTransactionVO = (ClaimsRequestTransactionVO) bizRes.getTransferObjects().get("response1");

					if (claimsRequestTransactionVO != null) {
						ClaimsRequestTransactionPO claimsRequestTransactionPO = dozerBeanMapper.map(claimsRequestTransactionVO, ClaimsRequestTransactionPO.class);
						String callJsonString = gsonJSON.toJson(claimsRequestTransactionPO, ClaimsRequestTransactionPO.class);
						FLogger.info("NonDeathClaimLogger", "NonDeathClaimHandler", "getBizResponseforSubmitClaims", "callJsonString::" + callJsonString);
						context.getFlowScope().put("Response", callJsonString);
					}
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("NonDeathClaimError", "NonDeathClaimHandler", "getBizResponseforSubmitClaims", "Exception came ", e);
			throwINeoFlowException(e, "GRYY02", context);
		}

		FLogger.info("NonDeathClaimLogger", "NonDeathClaimHandler", "getBizResponseforSubmitClaims", "Method end ");
		return success();
	}

}
