package com.ipru.groups.security;

import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;

import com.google.gson.reflect.TypeToken;
import com.ipru.enums.Role;
import com.ipru.groups.service.WebserviceInvoke;
import com.ipru.groups.utilities.EncryptionUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.BrokerDashboardDetailsVO;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.security.dao.IPruUserDetailDAOHibernateImpl;
import com.ipru.security.user.GroupsUserAuthInfo;
import com.ipru.security.user.GroupsUserAuthInfoNew;
import com.ipru.security.user.IPruUser;
import com.tcs.exception.SecurityException;
import com.tcs.logger.FLogger;
import com.tcs.security.IBaseService;
import com.tcs.security.UserService;
import com.tcs.security.auth.IAuthStore;
import com.tcs.security.config.SecurityConfig;
import com.tcs.security.user.Autherization;
import com.tcs.security.user.IUser;

public class LoginProcessService1 extends IBaseService {
	private IAuthStore localAuthStore = null;
	String message = "";
	Boolean isPolicyStatusValidForLogin = Boolean.FALSE;

	public String getMessage() {
		return message;
	}

	String appIdForSPAARC = "";
	String autoLoginPassword = "";
	String appIdForTABLET = "";
	boolean isSocialLogin = false;
	private SecurityService1 securityService = null;
	private UserService userService = null;
	Properties prop;

	public LoginProcessService1(IAuthStore authStore) {
		this.localAuthStore = authStore;
	}

	public LoginProcessService1() {
		try {
			prop = new Properties();
			prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
		}
		catch (Exception e) {
			FLogger.info("securityLogger", "LoginProcessService1", "LoginProcessService1()", "Exception found at the time of loading properties file");
			e.printStackTrace();
		}

		try {
			localAuthStore = SecurityManager.getAdaptor(SecurityConfig.INSTANCE.getAdaptorUsed());
			securityService = new SecurityService1(localAuthStore);
			userService = new UserService(localAuthStore);
		}
		catch (Exception e) {
			FLogger.info("securityLogger", "LoginProcessService1", "LoginProcessService1()", "Exception found at instantiation of LoginProcessService class");
			e.printStackTrace();
		}

	}

	public String handleService(Object pObjObj1, Object pObjObj2) {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	public IUser login(String p_paramUserName, String p_paramUserPwd) throws SecurityException, Exception {
		FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword,String loginThroughUserIdEmailMobile )", "Login method called for user :"
				+ p_paramUserName);
		IUser iuser = null;
		boolean isActive = false;
		boolean isLocked = false;
		IPruUser userObjI = null;
		try {

			try {
				userObjI = (IPruUser) userService.getUser(p_paramUserName, p_paramUserPwd);
				iuser = userObjI;
				userService.updateLastLoginDate(p_paramUserName);
			}
			catch (Exception e) {
				FLogger.error("securityLoggerError", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword,String loginThroughUserIdEmailMobile)", "Exception found in retrieving user:"
						+ p_paramUserName);
				e.printStackTrace();
				throw new SecurityException("1220");
			}

			if (userObjI != null) {
				isActive = true;
			}
			else
				isActive = false;
			if (isActive) {
				FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "DB Authentication :" + p_paramUserName);
				boolean accountExpired = userObjI.getAccountExpired();
				if (userObjI.getAccountLocked()) {
					isLocked = true;
				}
				else
					isLocked = false;
				if (!isLocked) {
					FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "Got is locked False:" + p_paramUserName);
					if (accountExpired) {
						FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "Login through user id not allowed:" + p_paramUserName);
						message = "loginWithEmailMobile";
						throw new SecurityException("1222");
					}
					else {
						boolean authenticated = securityService.authenticateUser(p_paramUserName, p_paramUserPwd);
						message = securityService.getMessage();
						if (authenticated) {
							FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "Got is authenticated true:" + p_paramUserName);
						}
						else {
							FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "Got is authenticated false:" + p_paramUserName);
							throw new SecurityException("1200");
						}
					}

				}
				else {
					FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "User Locked:" + p_paramUserName);
					message = "userLocked";
					throw new SecurityException("1221");
				}
			}
			else {
				FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "User Authentication through LDAP and not active:" + p_paramUserName);

				if (!isActive) {
					FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "Invalid user :" + p_paramUserName);
					throw new SecurityException("1220");
				}
				if (isActive) {
					FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "User is active :" + p_paramUserName);
					if (p_paramUserPwd.equalsIgnoreCase("AppAutoAuth") && isSocialLogin) {
						iuser = userService.getUser(p_paramUserName);

						userService.updateLastLoginDate(p_paramUserName);
					}
					else if (p_paramUserPwd.equalsIgnoreCase("AppAutoAuth")) {
					}
					else {
						FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "Setting values to userVO & updating login time :"
								+ p_paramUserName);

						if (StringUtils.isBlank(((IPruUser) iuser).getRoles())) {
							userService = new UserService(localAuthStore);
							try {
								iuser = userService.getUser(p_paramUserName);

								userService.updateLastLoginDate(p_paramUserName);

							}

							catch (Exception e) {
								FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "Error Setting values to userVO & updating login time :"
										+ p_paramUserName);
								e.printStackTrace();
								throw new SecurityException("1220");
							}
						}
					}
				}
			}
		}
		catch (Exception e) {
			FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "Exception found in login in LoginProcessService1 :" + p_paramUserName);
			e.printStackTrace();
			throw e;
		}
		if (iuser != null) {
			((IPruUser) iuser).setLoginTime(new Date());
			((IPruUser) iuser).setLoginThroughUserIdEmailMobile(prop.getProperty("LOGIN_USERID"));
		}
		return iuser;
	}

	public String getHashedPassword(String decryptedPswd, String userIdEmailMobile) {
		Boolean isPasswordValid = null;
		String password = null;
		FLogger.info("securityLogger", "LoginProcessService1", "getHashedPassword(String decryptedPswd, String userId)", "isPasswordValid::" + isPasswordValid);
		if (userIdEmailMobile.equalsIgnoreCase(prop.getProperty("LOGIN_USERID")))
			password = EncryptionUtil.encryptMD5(decryptedPswd);
		else if (userIdEmailMobile.equalsIgnoreCase(prop.getProperty("LOGIN_EMAIL_MOBILE")))
			password = EncryptionUtil.encryptSHA256(decryptedPswd);
		return password;
	}

	public IPruUser ssoLogin(IPruUser ipruUser) throws SecurityException {
		FLogger.info("securityLogger", "LoginProcessService1", "ssoLogin(IPruUser ipruUser)", "Calling ssoLogin");
		// Session session = null;
		try {

			IPruUserDetailDAOHibernateImpl ipruUserDao = null;
			ipruUserDao = new IPruUserDetailDAOHibernateImpl("GroupSecurity");
			// session = ipruUserDao.getSession();
			ipruUser = ipruUserDao.authenticateWebsiteGroupUser(ipruUser);
			// check if user is already present in GROUPS_USERAUTHINFO. If not,
			// insert else update.
			if (ipruUser.getRoles() != null) {
				ipruUser = ipruUserDao.getUserData(ipruUser);
				if (ipruUser.getPolicyNo() != null) {
					ipruUser = ipruUserDao.getDigiRole(ipruUser);
					ipruUser = ipruUserDao.insertOrUpdateUser(ipruUser);
					ipruUser = ipruUserDao.getUserDetails(ipruUser);
				}
				else {
					FLogger.error("securityLoggerError", "LoginProcessService1", "ssoLogin(IPruUser ipruUser)", "Policy no of user " + ipruUser.getUserId() + " cannot be null");
					throw new SecurityException("1200");
				}
			}
			else {
				FLogger.error("securityLoggerError", "LoginProcessService1", "ssoLogin(IPruUser ipruUser)", "Role of user " + ipruUser.getUserId() + " cannot be null");
				throw new SecurityException("1200");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("securityLoggerError", "LoginProcessService1", "ssoLogin(IPruUser ipruUser)", "Exception occured while ssoLogin " + e.getMessage());
			throw new SecurityException("1200");

		}
		finally {
			FLogger.info("securityLogger", "LoginProcessService1", "ssoLogin(String userName, String password, String usrRole)", "In finally");
			/*
			 * if (session != null && session.isOpen()) { session.flush();
			 * FLogger.info("securityLogger", "IPruUserDetailDAOHibernateImpl",
			 * " getDigiRole(IPruUser ipruUser)", "closing session");
			 * session.close(); }
			 */
		}
		return ipruUser;

	}

	/*
	 * public IPruUser getUserData(IPruUser userVO) {
	 * FLogger.info("securityLogger", "LoginProcessService1",
	 * "getUserData(IPruUser userVO)", "get user data called"); Session session
	 * = null; try { IPruUserDetailDAOHibernateImpl ipruUserDao = null;
	 * ipruUserDao = new IPruUserDetailDAOHibernateImpl("GroupSecurity"); userVO
	 * = ipruUserDao.getUserData(userVO); } catch (Exception e) {
	 * FLogger.error("securityLoggerError", "LoginProcessService1",
	 * "getUserData(IPruUser userVO)",
	 * "Exception occured while gettinguserdata " + e.getMessage());
	 * e.printStackTrace(); } finally { if (session != null && session.isOpen())
	 * { FLogger.info("securityLogger", "LoginProcessService1",
	 * "getUserData(IPruUser userVO)", "closing website session");
	 * session.flush(); session.close(); } } return userVO; }
	 */

	public IPruUser getUserDetails(IPruUser userVO) {
		FLogger.info("securityLogger", "LoginProcessService1", "getUserDetails(IPruUser userVO)", "getUserDetails called");
		try {
			IPruUserDetailDAOHibernateImpl ipruUserDao = null;
			ipruUserDao = new IPruUserDetailDAOHibernateImpl("GroupSecurity");
			// Session session = ipruUserDao.getSession();
			userVO = ipruUserDao.getUserDetails(userVO);
		}
		catch (Exception e) {
			FLogger.error("securityLoggerError", "LoginProcessService1", "getUserDetails(IPruUser userVO)", "Exception occured while gettinguserdetails " + e.getMessage());
			e.printStackTrace();
		}
		finally {
			FLogger.info("securityLogger", "LoginProcessService1", "getUserDetails(IPruUser userVO)", "In finally");
		}
		return userVO;
	}

	/*
	 * public IPruUser getGroupDigiRoleByDigiRole(IPruUser userVO) {
	 * FLogger.info("securityLogger", "LoginProcessService1",
	 * "getUserDetails(IPruUser userVO)", "getUserDetails called"); try {
	 * IPruUserDetailDAOHibernateImpl ipruUserDao = null; ipruUserDao = new
	 * IPruUserDetailDAOHibernateImpl("security"); userVO =
	 * ipruUserDao.getGroupPolicyDigiRoleByDigiRole(userVO); } catch (Exception
	 * e) { FLogger.error("securityLoggerError", "LoginProcessService1",
	 * "getUserDetails(IPruUser userVO)",
	 * "Exception occured while gettinguserdetails " + e.getMessage());
	 * e.printStackTrace(); } finally { FLogger.info("securityLogger",
	 * "LoginProcessService1", "getUserDetails(IPruUser userVO)", "In finally");
	 * } return userVO; }
	 */

	public IPruUser groupLogin(IPruUser userVO) throws SecurityException {
		// Session session = null;
		try {
			IPruUserDetailDAOHibernateImpl ipruUserDao = null;
			ipruUserDao = new IPruUserDetailDAOHibernateImpl("GroupSecurity");
			// session = ipruUserDao.getSession();
			userVO = ipruUserDao.getGroupPolicyDigiRoleByDigiRole(userVO);
			userVO = ipruUserDao.getUserData(userVO);
			userVO = ipruUserDao.getUserDetails(userVO);

			return userVO;
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("securityLoggerError", "LoginProcessService1", "ssoLogin(IPruUser ipruUser)", "Exception occured while ssoLogin " + e.getMessage());
			throw new SecurityException("1200");

		}
		finally {
			FLogger.info("securityLogger", "LoginProcessService1", "ssoLogin(String userName, String password, String usrRole)", "In finally");
			/*
			 * if (session != null && session.isOpen()) { session.flush();
			 * FLogger.info("securityLogger", "IPruUserDetailDAOHibernateImpl",
			 * " groupLogin(IPruUser userVO)", "closing session");
			 * session.close(); }
			 */
		}
	}

	public IPruUser groupLoginEmailmobile(IPruUser userVO) throws SecurityException {

		try {
			IPruUserDetailDAOHibernateImpl ipruUserDao = null;
			ipruUserDao = new IPruUserDetailDAOHibernateImpl("GroupSecurity");

			userVO = ipruUserDao.getPolicyDetailMap(userVO);
			userVO = ipruUserDao.getUserDataList(userVO);
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("securityLoggerError", "LoginProcessService1", "groupLoginEmailmobile(IPruUser ipruUser)", "Exception occured" + e.getMessage());
			throw new SecurityException("1200");

		}
		return userVO;
	}

	public IPruUser loginWithEmailMobile(String username, String password) throws Exception {
		FLogger.info("securityLogger", "LoginProcessService1", "loginWithEmailMobile(String p_StrUserName, String p_StrPassword)", "loginWithEmailMobile method called for user :" + username);
		boolean isActive = false;
		boolean isLocked = false;
		IPruUser user = null;
		try {
			IPruUserDetailDAOHibernateImpl userDetailDAOHibernateImpl = new IPruUserDetailDAOHibernateImpl("GroupSecurity");
			GroupsUserAuthInfoNew groupsUserAuthInfoNew = userDetailDAOHibernateImpl.getUserThroughEmailMobile(username);
			GroupsUserAuthInfoNew newUser = null;
			if (groupsUserAuthInfoNew != null) {
				user = new IPruUser();
				user.setUsername(username);
				user.setUserId(username);
				user.setPassword(groupsUserAuthInfoNew.getProperty());
				user.setUserIdInt(groupsUserAuthInfoNew.getUserid());
				user.setFirstLoginStatus(groupsUserAuthInfoNew.getFirstLogin());
				user.setLastPasswordUpdateDate(groupsUserAuthInfoNew.getLastPasswordUpdateDate());
				user.setWebClientId(groupsUserAuthInfoNew.getWebClientId());
				user.setDbValidation(false);
				user.setLoginThroughUserIdEmailMobile(prop.getProperty("LOGIN_EMAIL_MOBILE"));
				if (groupsUserAuthInfoNew != null && groupsUserAuthInfoNew.getIsuserlocked().equalsIgnoreCase("true"))
					user.setAccountLocked(true);
				else
					user.setAccountLocked(false);
				if (groupsUserAuthInfoNew != null && groupsUserAuthInfoNew.getIsvaliduser().equalsIgnoreCase("true"))
					user.setAccountExpired(false);
				else if (groupsUserAuthInfoNew != null && groupsUserAuthInfoNew.getIsvaliduser().equalsIgnoreCase("false"))
					user.setAccountExpired(true);
				user.setFirstName(groupsUserAuthInfoNew.getFirstName());
				user.setLastName(groupsUserAuthInfoNew.getLastName());
				user.setEmailId(groupsUserAuthInfoNew.getEmailId());
				user.setMobileNo(groupsUserAuthInfoNew.getMobileNo().toString());
				user.setRoles("USER");
				Autherization a = new Autherization();
				a.setRole("USER");
				user.setAutherization(a);
				isActive = true;
			}
			else {
				isActive = false;
			}
			if (isActive) {
				FLogger.info("securityLogger", "LoginProcessService1", "loginWithEmailMobile(String p_StrUserName, String p_StrPassword)", "DB Authentication through email mobile:" + username);
				if (user.getAccountLocked()) {
					isLocked = true;
				}
				else
					isLocked = false;
				if (!isLocked) {

					FLogger.info("securityLogger", "LoginProcessService1", "loginWithEmailMobile(String p_StrUserName, String p_StrPassword)", "Got is locked False :" + username);
					FLogger.info("securityLogger", "IPruUserDetailDAOHibernateImpl", "IsValidUser", "user found with username " + username);
					FLogger.info("securityLogger", "IPruUserDetailDAOHibernateImpl", "IsValidUser", "PPPPPPPPPPPPPPPPPP " + username);
					int faultyLoginAttempts = 0;
					if (groupsUserAuthInfoNew.getLoginAttempts() != 0) {
						faultyLoginAttempts = groupsUserAuthInfoNew.getLoginAttempts();
					}

					if (StringUtils.equals(groupsUserAuthInfoNew.getProperty(), password)) {
						FLogger.info("securityLogger", "IPruUserDetailDAOHibernateImpl", "IsValidUser", "user name and password is valid for user : " + username);

						newUser = new GroupsUserAuthInfoNew();
						newUser = groupsUserAuthInfoNew;
						newUser.setLoginAttempts(0);

						IPruUserDetailDAOHibernateImpl iPruUserDetailDAOHibernateImpl = new IPruUserDetailDAOHibernateImpl("GroupSecurity");
						iPruUserDetailDAOHibernateImpl.updateGroupsUserAuthinfoNew(newUser);
					}
					else if (!(StringUtils.equals(groupsUserAuthInfoNew.getProperty(), password))) // replace

					{
						FLogger.info("securityLogger", "IPruUserDetailDAOHibernateImpl", "IsValidUser", "password is invalid for user : " + username + " so faultyattempt is incremented");
						FLogger.info("securityLogger", "IPruUserDetailDAOHibernateImpl", "IsValidUser", "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD " + password + " iiiiiiiiiiiiiiiiiii "
								+ groupsUserAuthInfoNew.getProperty());

						faultyLoginAttempts += 1;
						newUser = new GroupsUserAuthInfoNew();
						newUser = groupsUserAuthInfoNew;
						if (faultyLoginAttempts >= 15) {
							newUser.setIsuserlocked("true");
						}

						newUser.setLoginAttempts(faultyLoginAttempts);
						IPruUserDetailDAOHibernateImpl iPruUserDetailDAOHibernateImpl = new IPruUserDetailDAOHibernateImpl("GroupSecurity");
						iPruUserDetailDAOHibernateImpl.updateGroupsUserAuthinfoNew(newUser);
						FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "User Locked:" + username);
						message = "incorrectPassword";
						throw new SecurityException("1200");
					}
				}
				else {
					FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "User Locked:" + username);
					message = "userLocked";
					throw new SecurityException("1221");
				}
			}
			else {
				FLogger.info("securityLogger", "LoginProcessService1", "loginWithEmailMobile(String p_StrUserName, String p_StrPassword)", "User with email Id/Mobile no. not found:" + username);

				if (!isActive) {
					FLogger.info("securityLogger", "LoginProcessService1", "loginWithEmailMobile(String p_StrUserName, String p_StrPassword)", "Invalid user :" + username);
					throw new SecurityException("1220");
				}
			}
		}
		catch (Exception e) {
			FLogger.info("securityLogger", "LoginProcessService1", "login(String p_StrUserName, String p_StrPassword)", "Exception found in login in LoginProcessService1 :" + username);
			e.printStackTrace();
			throw e;
		}

		return user;
	}

	public String groupLoginWithSingleSignOn(IPruUser userVO) throws SSOGroupDefaultException {
		FLogger.info("securityLogger", "LoginProcessService1", "groupLoginWithSingleSignOn", "Method Start");
		String property = null;
		try {
			IPruUserDetailDAOHibernateImpl userDetailDAOHibernateImpl = new IPruUserDetailDAOHibernateImpl("GroupSecurity");

			GroupsUserAuthInfoNew groupsUserAuthInfoNew = userDetailDAOHibernateImpl.getPropertySingleSignOn(Long.parseLong(userVO.getMobileNo()), userVO.getEmailId(), userVO.getWebClientId());
			if (groupsUserAuthInfoNew != null)
				property = groupsUserAuthInfoNew.getProperty() != null ? groupsUserAuthInfoNew.getProperty() : null;
		}
		catch (Exception e) {
			throw new SSOGroupDefaultException("Email Id and mobile number not registered", e);
		}

		FLogger.info("securityLogger", "LoginProcessService1", "groupLoginWithSingleSignOn", "Method End");
		return property;
	}

	public IPruUser SSOGrouploginWithEmailMobile(String username, String password) throws SSOGroupDefaultException {
		IPruUser iPruUser = null;
		try {

			iPruUser = (IPruUser) this.loginWithEmailMobile(username, password);
		}
		catch (Exception e) {
			throw new SSOGroupDefaultException("Email Id and mobile number not registered", e);
		}
		return iPruUser;
	}

	public IPruUser SSOGroupLoginEmailmobile(IPruUser userVO) throws SSOGroupDefaultException {
		IPruUser iPruUser = null;
		try {

			iPruUser = (IPruUser) this.groupLoginEmailmobile(userVO);
		}
		catch (SecurityException e) {
			throw new SSOGroupDefaultException("Email Id and mobile number not registered", e);
		}
		catch (Exception e) {
			throw new SSOGroupDefaultException("Email Id and mobile number not registered", e);
		}
		return iPruUser;

	}

	
	/********************************************** login Borker ******************************************************/
	
	
	/*public String groupBorkerLoginSSO(FscDetailsVO fscdetails) throws SSOGroupDefaultException {
		// TODO Auto-generated method stub
		FLogger.info("securityLogger", "LoginProcessService1", "groupBorkerLoginSSO", "Method Start");
		String property = null;

		//IPruUserDetailDAOHibernateImpl userDetailDAOHibernateImpl = new IPruUserDetailDAOHibernateImpl("IneoDigital");
	try {
		Session session = userDetailDAOHibernateImpl.getSession();
		FscDetailsVO fscdetails = userDetailDAOHibernateImpl.getBorkerPropertySSO(userVO.getFsc_client_Id());
		if (fscdetails != null)
			property = fscdetails.getReferral_code() != null ? fscdetails.getReferral_code() : null;
       
		}
		catch (Exception e) {
			throw new SSOGroupDefaultException("Broker not registered", e);
		}
		FLogger.info("securityLogger", "LoginProcessService1", "groupBorkerLoginSSO", "Method End");
		return property;
	}*/

	public IPruUser SSOGrouploginBorker(IPruUser userVO, FscDetailsVO fscdetails)throws SSOGroupDefaultException {
		// TODO Auto-generated method stub
		//IPruUser iPruUser = null;
		try {

			userVO = (IPruUser) this.loginFscClientID(userVO,fscdetails);
		}
		catch (Exception e) {
			throw new SSOGroupDefaultException("Broker not registered", e);
		}
		return userVO;
	}

	public IPruUser loginFscClientID(IPruUser user, FscDetailsVO fscdetails) throws Exception {
		// TODO Auto-generated method stub
		//IPruUser user = null;
		FLogger.info("securityLogger", "LoginProcessService1", "loginFscClientID", "Method Start");

		boolean isActive = false;
		boolean isLocked = false;
	//	FscDetailsVO fscdetails =null;
		try {

					/*IPruUserDetailDAOHibernateImpl userDetailDAOHibernateImpl = new IPruUserDetailDAOHibernateImpl("IneoDigital");
				
					fscdetails = userDetailDAOHibernateImpl.getBorkerReferral_codeSSO(fscdetails);*/
					
					
				if(fscdetails !=null)	{
					
					FLogger.info("securityLogger", "LoginProcessService1", "loginFscClientID", "fscdetails IN IF"+fscdetails);
					 String branchcode =fscdetails.getReferral_code();
					  String NationalCode =fscdetails.getNationalCode();   
					 // String roletype="BR"; 
					  String roletype=fscdetails.getFscChannel();   
					if(NationalCode!=null && roletype!=null && branchcode!=null )
					{
						fscdetails.setBranchCode(fscdetails.getReferral_code());
						fscdetails.setLogin_type("BRANCH_BROKER");
						
						fscdetails=BrokerPolicyListService.getPolicyListBranch(fscdetails);
						
					}else
						if(branchcode!=null && roletype!=null && NationalCode==null )
						{
							    
							fscdetails.setNationalCode(fscdetails.getReferral_code());
							fscdetails.setLogin_type("NATIONAL_BROKER");
							fscdetails=BrokerPolicyListService.getPolicyListNational(fscdetails);


						}   
					 
					//user = new IPruUser(); // why new IPruUSer
					user.setRoles(fscdetails.getFscChannel());
					user.setLoginThroughUserIdEmailMobile(prop.getProperty("GRP_BROKERSOURCE"));
					user.setSsoLogin(prop.getProperty("GRP_BROKERSOURCE"));
					user.setFscdetails(fscdetails);
					Autherization a = new Autherization();
					a.setRole(fscdetails.getFscChannel()); 
					user.setAutherization(a);
					isActive = true;  
				}
		   }
		catch (Exception e) {
			
			FLogger.info("securityLogger", "LoginProcessService1", "loginFscClientID", "Exception found in login in LoginProcessService1 :" + fscdetails);
			e.printStackTrace();
			throw e;
		}
		
		return user;
	}

}