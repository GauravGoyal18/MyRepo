package com.ipru.groups.security;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;

import javacryption.aes.AesCtr;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.concurrent.SessionIdentifier;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.util.Assert;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.ipru.ThirdPartyAutoLogin.PreLoginThirdPartyInfoPO;
import com.ipru.groups.po.GroupRetailLoginInfoPO;
import com.ipru.groups.po.GroupsBrokerPO;
import com.ipru.groups.security.encryption.UserIdPasswordCrypto;
import com.ipru.groups.utilities.EncodingUtility;
import com.ipru.groups.utilities.EncryptionPBEMD5DES;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.security.dao.IPruUserDetailDAOHibernateImpl;
import com.ipru.security.dao.RoleBasedLoginDAO;
import com.ipru.security.encryption.servlet.CryptoServlet;
import com.ipru.security.user.GroupsUserAuthInfo;
import com.ipru.security.user.GroupsUserAuthInfoNew;
import com.ipru.security.user.IPruUser;
import com.ipru.security.user.LoginHistory;
import com.tcs.logger.FLogger;

public class GroupsAuthenticationFilter extends AbstractAuthenticationProcessingFilter {
	public static final String SPRING_SECURITY_FORM_USERNAME_KEY = "j_username";
	public static final String SPRING_SECURITY_FORM_PASSWORD_KEY = "j_password";
	private String usernameParameter = SPRING_SECURITY_FORM_USERNAME_KEY;
	private String passwordParameter = SPRING_SECURITY_FORM_PASSWORD_KEY;
	IPruUserDetailDAOHibernateImpl ipruDaoObj = new IPruUserDetailDAOHibernateImpl("security");
	Properties prop = new Properties();
	private static String defaultFilterProcessesUrl = "/j_spring_security_check";

	protected GroupsAuthenticationFilter() {
		super(defaultFilterProcessesUrl);
	}

	public GroupsAuthenticationFilter(String defaultFilterProcessesUrl) {
		super(defaultFilterProcessesUrl);
		Assert.notNull(defaultFilterProcessesUrl, "Configuration error :: DefaultFilterProcessesUrl must be specified");
	}

	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException, IOException, ServletException {
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "attemptAuthentication", "attempt authentication called");
		// Start variable declaration
		String username = "";
		String password = "";
		String loginThroughUserIdEmailMobile = "";
		String userId = "";
		IPruUser userVO = new IPruUser();
		Authentication auth = null;
		HttpSession session = null;

		session = request.getSession(false);
		String websiteSource = "";
		String clientId = "";
		String sessionid = "";
		String mobileNo = "";
		String emailId = "";
		String webClientId = "";
		String fscClientId = "";
		String fscChannel="";
		String source="";
		String ssoLogin = "";
		SessionIdentifier sessionObj = new SessionIdentifier();
		
		try {
			if (MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES != null) {
				prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
			}
			else {
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
					prop.load(fis);
				}
				catch (Exception e) {
					FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Exception occured while loading constants.properties file");
				}
				finally {
					if (fis != null) {
						fis.close();
						fis = null;
					}
				}

			}
		}
		catch (FileNotFoundException e) {
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "File not found exception found at the time of loading properties in attemptAuthentication ");
			e.printStackTrace();
		}
		catch (IOException e) {
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "IOException found at the time of loading properties in attemptAuthentication ");
			e.printStackTrace();
		}
		try {
			loginThroughUserIdEmailMobile = obtainLoginThroughUserIdEmailMobile(request);  

			PreLoginThirdPartyInfoPO preLoginThirdPartyInfoPO = new PreLoginThirdPartyInfoPO();
			String thirdpartybean = request.getParameter("thirdpartyBean") != null ? request.getParameter("thirdpartyBean") : (String) request.getAttribute("thirdpartyBean");
			try {
				if (thirdpartybean != null && !("").equalsIgnoreCase(thirdpartybean)) {
					String decryptkey = prop.getProperty("UniqueKey");
					preLoginThirdPartyInfoPO = parse(thirdpartybean, decryptkey, request);
					if (preLoginThirdPartyInfoPO.getUserId() == null || preLoginThirdPartyInfoPO.getClientId() == null) {
						AuthenticationException authException = new AuthenticationException("preLoginThirdPartyInfoPO is not parsedd") {
						};
						FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "preLoginThirdPartyInfoPO is not parsed ");
						throw authException;
					}
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Error occurred while parsing preLoginThirdPartyInfoPO ");
			}
			// String groupsRequestedFunctionality = (String)
			// request.getAttribute("reqFunc") != null ? (String)
			// request.getAttribute("reqFunc") :
			// request.getParameter("reqFunc");
			
			
			/**************************** Single Sign On ******************************/
		
			
			 source = request.getParameter("websiteSource") != null ? request.getParameter("websiteSource") : (String) request.getAttribute("websiteSource");
			GroupsRetailSSO groupsSSO = new GroupsRetailSSO();
			GroupsBrokerSSO groupsBrokerSSO = new GroupsBrokerSSO();
			
			GroupRetailLoginInfoPO groupRetailLoginInfoPO= null;
			GroupsBrokerPO groupsBorkerPO=null;
			String brokerSource= prop.getProperty("GRP_BROKERSOURCE");
			String memberSource= prop.getProperty("GRP_MEMBERSOURCE");

		if(source!=null)
		{
			 if(isSourceValid(source))
			 {	
				if(brokerSource!=null && brokerSource.equals(getValidSource(source))) {
					String groupBrokerbean = request.getParameter("GroupRetailBean") != null ? request.getParameter("GroupRetailBean") : (String) request.getAttribute("GroupRetailBean");
					groupsBorkerPO =groupsBrokerSSO.getBrokerDetails(groupBrokerbean,prop);
					userVO.setSsoLogin(brokerSource); 
					
					 userVO.setLoginThroughUserIdEmailMobile(brokerSource) ;  
					 fscClientId = groupsBorkerPO.getFscClientId();
					 fscChannel=   groupsBorkerPO.getFscChannel();  
				
				}else if (memberSource !=null && memberSource.equals(getValidSource(source))) {
					String groupRetailBean = request.getParameter("GroupRetailBean") != null ? request.getParameter("GroupRetailBean") : (String) request.getAttribute("GroupRetailBean");
					groupRetailLoginInfoPO=groupsSSO.getRetailDetails(groupRetailBean, prop);
					
					   userVO.setSsoLogin(memberSource);
					   loginThroughUserIdEmailMobile = prop.getProperty("LOGIN_EMAIL_MOBILE");
					   userVO.setLoginThroughUserIdEmailMobile(loginThroughUserIdEmailMobile) ;   
					  
				
				  }		
				   else {  
					   SSOGroupDefaultException authException = new SSOGroupDefaultException("Input Source is Invalid");
					 {
					};
					FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Input Source is Invalid " );
					throw authException;
				   }
						   
			}else{
				   SSOGroupDefaultException authException = new SSOGroupDefaultException("Input Source is Invalid");  
				 {
				};
				FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Input Source is Invalid " );
				throw authException;
				  
			  }
			 
			 
		} 
			
			
		    //userVO = new IPruUser();

			

			//loginThroughUserIdEmailMobile = prop.getProperty("LOGIN_EMAIL_MOBILE");
			websiteSource = preLoginThirdPartyInfoPO.getWebsiteSource();
			String decryptKey = prop.getProperty(websiteSource + "key");
			
			/* Single Sign On */
			ssoLogin = userVO.getSsoLogin();

			if (websiteSource != null && !websiteSource.equals("")) {   
				FLogger.info("securityLogger", "GroupsAuthenticationFilter", "attemptAuthentication", "Logging in through Single sign on");
				long milliseconds = preLoginThirdPartyInfoPO.getMilliseconds();
				Date date = new Date();
				long currMilliseconds = date.getTime();
				//long difference = 2 * 60 * 1000;
				long difference =  Long.valueOf(prop.getProperty("DiffernceSSOLoginTime"));   
				if (currMilliseconds - milliseconds <= difference) {
					userId = preLoginThirdPartyInfoPO.getUserId();
					username = userId;
					clientId = decryptValue(preLoginThirdPartyInfoPO.getClientId(), decryptKey);
				}

				else {
					AuthenticationException authException = new AuthenticationException("Timestamp is not valid") {
					};
					FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Timestamp is not valid " + ToStringBuilder.reflectionToString(username));
					throw authException;
				}

			}
			else if (memberSource!=null && memberSource.equals(source)) {

				FLogger.info("securityLogger", "GroupsAuthenticationFilter", "attemptAuthentication", "Logging in through Single sign on Group Retail");
				long milliseconds = groupRetailLoginInfoPO.getMilliseconds();
				Date date = new Date();
				long currMilliseconds = date.getTime();
				//long difference = 2 * 60 * 1000;
				long difference =  Long.valueOf(prop.getProperty("DiffernceSSOLoginTime"));
				if (currMilliseconds - milliseconds <= difference) {

					mobileNo = groupRetailLoginInfoPO.getMobileNo();
					emailId = groupRetailLoginInfoPO.getEmailId();
					webClientId = groupRetailLoginInfoPO.getWebClientId();
					username = mobileNo;
				

				}
				else {
					SSOGroupDefaultException authException = new SSOGroupDefaultException("Timestamp is not valid") {
					};
					FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Timestamp is not valid " + ToStringBuilder.reflectionToString(username));
					throw authException;
				} 

			}
			
			else if (brokerSource!=null && brokerSource.equals(source)) {

				FLogger.info("securityLogger", "GroupsAuthenticationFilter", "attemptAuthentication", "Logging in through Single sign on Group BROKER");
				long milliseconds = groupsBorkerPO.getTimestampMs();
				Date date = new Date();
				long currMilliseconds = date.getTime();
				//long difference = 2 * 60 * 1000; 
				String hhh =prop.getProperty("DiffernceSSOLoginTime");  
			    long difference =  Long.parseLong(prop.getProperty("DiffernceSSOLoginTime"));
				if (currMilliseconds - milliseconds <= difference) {

					
					fscClientId = groupsBorkerPO.getFscClientId();
					fscChannel=   groupsBorkerPO.getFscChannel();
					

				}
				else {
					SSOGroupDefaultException authException = new SSOGroupDefaultException("Timestamp is not valid") {
					};
					FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Timestamp is not valid " + ToStringBuilder.reflectionToString(username));
					throw authException;
				}

			}
			else {
				FLogger.info("securityLogger", "GroupsAuthenticationFilter", "attemptAuthentication", "Logging in through :" + username);
				username = request.getParameter(usernameParameter);
				if (username != null) {
					username = username.trim();  
				}

				password = obtainPassword(request);
			}

		}
		catch (SSOGroupDefaultException e) {
			throw new SSOGroupDefaultException(e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Exception occured is " + e.getMessage());
		}

		String jCryptionKey = null;

		if (session != null) {
			jCryptionKey = this.getJCryptionKey(request);
			session.invalidate();
		}
		session = request.getSession(true);
		session.setAttribute("jCryptionKey", jCryptionKey);
		
		if(source !=null)
		{
		 session.setAttribute("fsc_client_Id",fscClientId); 
	     session.setAttribute("fscchannel",fscChannel );  
	     session.setAttribute("mobileNo",mobileNo );
		}

		if (username == null) {
			username = "";
		}
		if (password == null) {
			password = "";
		}
		username = username.trim();

		userVO.setUsername(username);
		userVO.setUserId(username);
		userVO.setWebsiteSource(websiteSource);
		userVO.setClientId(clientId);
		userVO.setLoginThroughUserIdEmailMobile(loginThroughUserIdEmailMobile);
		userVO.setMobileNo(mobileNo);
		userVO.setEmailId(emailId);
		userVO.setWebClientId(webClientId);
		userVO.setFsc_client_Id(fscClientId);

		Properties propLogin = new Properties();
		FileInputStream fileIs = null;
		try {
			fileIs = new FileInputStream(GroupConstants.CONSTANT_C + "/temp.properties");
			propLogin.load(fileIs);
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Exception occured while loading temp.properties file");
		}
		finally {
			if (fileIs != null)
				fileIs.close();
			fileIs = null;
		}
		if (request != null) {
			String loginMethod = propLogin.getProperty("REQUEST_METHOD");
			if (request.getMethod().equalsIgnoreCase(loginMethod)) {
				AuthenticationException authException = new AuthenticationException("Invalid login attempt") {
				};
				FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Login attempted from get request " + ToStringBuilder.reflectionToString(userVO));

				throw authException;
			}
		}

		UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(userVO, password);

		sessionid = session.getId();
		sessionObj.setSessionId(sessionid);
		authRequest.setDetails(sessionObj);
		try {
			// Calling Provider
			FLogger.info("securityLogger", "GroupsAuthenticationFilter", "attemptAuthentication", "Provider has been called");
			auth = this.getAuthenticationManager().authenticate(authRequest);
			session.setAttribute("userVO", (IPruUser) (auth.getPrincipal()));
			setDetails(request, authRequest);
		}
		catch (AuthenticationException e) {
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "AuthenticationException found at the time of calling provider in attemptAuthentication ");

			e.printStackTrace();
			throw e;
		}
		catch (Exception e) {
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Exception found at the time of calling provider in attemptAuthentication ");

			e.printStackTrace();
		}
		return auth;
		
		
		
		
	}



	

	private String decryptValue(String encodedValue, String encodeKey) {
		String clearText = "";
		if (encodedValue != null) {
			try {
				clearText = UserIdPasswordCrypto.decryptValue(encodedValue, encodeKey);
			}
			catch (Exception e) {
				FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "decryptValue", "Exception found decrypting" + e.getMessage());
				e.printStackTrace();
			}
		}
		return clearText;
	}

	/**
	 * This filter by default responds to <code>/j_spring_security_check</code>.
	 * 
	 * @return the default 
	 */
	public String getDefaultFilterProcessesUrl() {

		return "/j_spring_security_check";
	}

	/**
	 * Enables subclasses to override the composition of the password, such as
	 * by including additional values and a separator.
	 * <p>
	 * This might be used for example if a postcode/zipcode was required in
	 * addition to the password. A delimiter such as a pipe (|) should be used
	 * to separate the password and extended value(s). The
	 * <code>AuthenticationDao</code> will need to generate the expected
	 * password in a corresponding manner.
	 * </p>
	 * 
	 * @param request
	 *            so that request attributes can be retrieved
	 * @return the password that will be presented in the
	 *         <code>Authentication</code> request token to the
	 *         <code>AuthenticationManager</code>
	 */
	protected String obtainPassword(HttpServletRequest request) {
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "obtainPassword", "obtainPassword has been called");
		CryptoServlet cs = new CryptoServlet();
		LoginProcessService1 loginService = new LoginProcessService1();
		String password = "";
		String decryptedPswd = cs.decriptPassword(request, request.getParameter(passwordParameter));
		String loginThroughUserIdEmailMobile = obtainLoginThroughUserIdEmailMobile(request);
		password = loginService.getHashedPassword(decryptedPswd, loginThroughUserIdEmailMobile);

		return password;
	}

	protected String obtainLoginThroughUserIdEmailMobile(HttpServletRequest request) {
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "obtainLoginThroughUserIdEmailMobile", "obtainLoginThroughUserIdEmailMobile has been called");
		String loginThroughUserIdEmailMobile = request.getParameter("userIdEmailMobile");

		String key = (String) request.getSession().getAttribute("jCryptionKey");

		if (loginThroughUserIdEmailMobile != null) {

			loginThroughUserIdEmailMobile = loginThroughUserIdEmailMobile.replaceAll(" ", "+");

			loginThroughUserIdEmailMobile = AesCtr.decrypt(loginThroughUserIdEmailMobile, key, 256);
		}

		return loginThroughUserIdEmailMobile;
	}

	public String getJCryptionKey(HttpServletRequest request) {

		return (String) request.getSession().getAttribute("jCryptionKey");
	}

	protected String obtainLoginThroughSingleSignOn(HttpServletRequest request) {
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "obtainLoginThroughSingleSignOn", "obtainLoginThroughSingleSignOn has been called");
		return StringUtils.isEmpty(request.getParameter("GroupRetailBean")) ? "" : request.getParameter("GroupRetailBean");
	}

	/**
	 * Enables subclasses to override the composition of the username, such as
	 * by including additional values and a separator.
	 * 
	 * @param request
	 *            so that request attributes can be retrieved
	 * @return the username that will be presented in the
	 *         <code>Authentication</code> request token to the
	 *         <code>AuthenticationManager</code>
	 */
	protected String obtainUsername(HttpServletRequest request) {

		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "obtainUsername", "obtainUsername has been called");

		if (null != request.getParameter(usernameParameter) && request.getParameter(usernameParameter).length() > 5) {
			return request.getParameter(usernameParameter);
		}
		else {
			FLogger.info("securityLogger", "GroupsAuthenticationFilter", "obtainUsername", "User name is less than 5");
			request.getSession().setAttribute("autoLogin", "false");
			return request.getParameter(usernameParameter);
		}

	}

	/**
	 * Provided so that subclasses may configure what is put into the
	 * authentication request's details property.
	 * 
	 * @param request
	 *            that an authentication request is being created for
	 * @param authRequest
	 *            the authentication request object that should have its details
	 *            set
	 */

	protected void setDetails(HttpServletRequest request, UsernamePasswordAuthenticationToken authRequest) {
		authRequest.setDetails(authenticationDetailsSource.buildDetails(request));
	}

	/**
	 * Sets the parameter name which will be used to obtain the username from
	 * the login request.
	 * 
	 * @param usernameParameter
	 *            the parameter name. Defaults to "j_username".
	 */
	public void setUsernameParameter(String usernameParameter) {
		Assert.hasText(usernameParameter, "Username parameter must not be empty or null");
		this.usernameParameter = usernameParameter;
	}

	/**
	 * Sets the parameter name which will be used to obtain the password from
	 * the login request..
	 * 
	 * @param passwordParameter
	 *            the parameter name. Defaults to "j_password".
	 */
	public void setPasswordParameter(String passwordParameter) {
		Assert.hasText(passwordParameter, "Password parameter must not be empty or null");
		this.passwordParameter = passwordParameter;
	}

	/*
	 * public int getOrder() { return
	 * FilterChainOrder.AUTHENTICATION_PROCESSING_FILTER; }
	 */
	String getUsernameParameter() {
		return usernameParameter;
	}

	String getPasswordParameter() {
		return passwordParameter;
	}

	// ---------------------------Added for extracting MAC address
	// -----------------------
	static String getMacAddress(byte[] macBytes) {
		final StringBuilder strBuilder = new StringBuilder();

		for (int i = 0; i < macBytes.length; i++) {
			strBuilder.append(String.format("%02X%s", macBytes[i], (i < macBytes.length - 1) ? "-" : ""));
		}

		return strBuilder.toString().toUpperCase();
	}

	protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, Authentication authResult) throws IOException, ServletException {
		super.successfulAuthentication(request, response, authResult);

		// Start variable declaration
		String currentIp = "";
		String trueIp = "";
		byte[] mac;
		String currentMAC = "tempmac";
		IPruUser userVO = (IPruUser) authResult.getPrincipal();
		String userName = userVO.getUsername();
		String fsc_ClientID = userVO.getFsc_client_Id();
		GroupsUserAuthInfo user = new GroupsUserAuthInfo();
		GroupsUserAuthInfoNew user1 = new GroupsUserAuthInfoNew();

		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd MMM yyyy hh:mm a");
		Date lastSuccessfulLoginDate = null;
		String strLastSuccessfulLoginDate = "-";
		String lastSuccessfulIpAddress = "-";
		String currentIpAddress = "";
		InetAddress ip;
		IPruUser userVo = (IPruUser) request.getSession().getAttribute("userVO");

		Properties prop = new Properties();
		try {
			if (MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES != null) {
				prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
			}
			else {
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
					prop.load(fis);
				}
				catch (Exception e) {
					FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Exception occured while loading constants.properties file");
				}
				finally {
					if (fis != null) {
						fis.close();
						fis = null;
					}
				}

			}
		}
		catch (FileNotFoundException e) {
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "File not found exception found at the time of loading properties in attemptAuthentication ");
			e.printStackTrace();
		}
		catch (IOException e) {
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "IOException found at the time of loading properties in attemptAuthentication ");
			e.printStackTrace();
		}

		try {
			ip = InetAddress.getByName(request.getRemoteAddr());
			InetAddress ipAdd = InetAddress.getLocalHost();
			currentIp = ip.getHostAddress();
			userVo.setRemoteIp(currentIp);
			trueIp = request.getHeader("True-Client-IP");
			userVo.setUserIp(trueIp);

			final Enumeration<NetworkInterface> inetAddresses = NetworkInterface.getNetworkInterfaces();
			ArrayList<String> addrs = new ArrayList<String>();
			while (inetAddresses.hasMoreElements()) {
				final byte[] macBytes = inetAddresses.nextElement().getHardwareAddress();
				if (macBytes == null)
					continue;
				addrs.add(getMacAddress(macBytes));
			}
			currentMAC = addrs.get(0);
			userVo.setMacAddress(currentMAC);

		}
		catch (UnknownHostException e) {
			e.printStackTrace();
		}
		String loginThroughEmailMobile = userVo.getLoginThroughUserIdEmailMobile();
		if (loginThroughEmailMobile != null && loginThroughEmailMobile.equalsIgnoreCase(prop.getProperty("LOGIN_USERID"))) {
			user = ipruDaoObj.onSuccessfulLogin(userName, currentIp, currentMAC);
			if (user != null) {

				if (user.getLastSuccessfulLoginTime() != null) {
					lastSuccessfulLoginDate = user.getLastSuccessfulLoginTime();
					strLastSuccessfulLoginDate = dateFormatter.format(lastSuccessfulLoginDate);
				}

				if (user.getLastSuccessfullIpAddress() != null && !user.getLastSuccessfullIpAddress().equals("")) {
					lastSuccessfulIpAddress = user.getLastSuccessfullIpAddress();
				}
				if (user.getCurrentIpAddress() != null && !user.getCurrentIpAddress().equals("")) {
					currentIpAddress = user.getCurrentIpAddress();
				}
			}
			else {
				HttpServletRequest requ = (HttpServletRequest) request;
				currentIpAddress = requ.getRemoteAddr();
			}
			userVo.setUserIdInt(user.getUserid());
			userVo.setLoginTime(user.getCurrentLoginTime());

		}
		else if (loginThroughEmailMobile != null && loginThroughEmailMobile.equalsIgnoreCase(prop.getProperty("LOGIN_EMAIL_MOBILE"))) {
			user1 = ipruDaoObj.onSuccessfulLoginThroughEmailMobile(userName, currentIp, currentMAC);
			if (user1 != null) {

				if (user1.getLastSuccessfulLoginTime() != null) {
					lastSuccessfulLoginDate = user1.getLastSuccessfulLoginTime();
					strLastSuccessfulLoginDate = dateFormatter.format(lastSuccessfulLoginDate);
				}

				if (user1.getLastSuccessfullIpAddress() != null && !user1.getLastSuccessfullIpAddress().equals("")) {
					lastSuccessfulIpAddress = user1.getLastSuccessfullIpAddress();
				}
				if (user1.getCurrentIpAddress() != null && !user1.getCurrentIpAddress().equals("")) {
					currentIpAddress = user1.getCurrentIpAddress();
				}
			}
			else {
				HttpServletRequest requ = (HttpServletRequest) request;
				currentIpAddress = requ.getRemoteAddr();
			}
			userVo.setUserIdInt(user1.getUserid());
			userVo.setLoginTime(user1.getCurrentLoginTime());
		}
		else if(loginThroughEmailMobile != null && loginThroughEmailMobile.equalsIgnoreCase(prop.getProperty("GRP_BROKERSOURCE"))) {
			//user1 = ipruDaoObj.onSuccessfulLoginBrokerSSO(fsc_ClientID, currentIp, currentMAC);
			
		}

		String loggedInUserName = "";

		if (userVo.getFirstName() != null && userVo.getLastName() != null)
			loggedInUserName = userVo.getFirstName().concat(" ".concat(userVo.getLastName()));
		else if (userVo.getFirstName() != null && userVo.getLastName() == null)
			loggedInUserName = userVo.getFirstName();
		else if (userVo.getFscdetails() != null )
			loggedInUserName = userVo.getFscdetails().getFsc_Name();
		request.getSession().setAttribute("lastSuccesfulLoginTime", strLastSuccessfulLoginDate);
		request.getSession().setAttribute("lastSuccesfulLoginIP", lastSuccessfulIpAddress);
		request.getSession().setAttribute("currentIPAddress", currentIpAddress);
		request.getSession().setAttribute("trueClientIp", request.getHeader("True-Client-IP"));
		request.getSession().setAttribute("loggedInUsername", loggedInUserName);
		request.getSession().setAttribute("userVO", userVo);  
	}

	protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException, ServletException {
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "unsuccessfulAuthentication", "unsuccessfulAuthentication has been called");
		super.unsuccessfulAuthentication(request, response, failed);
		String currentIp = "";
		String trueIp = "";
		String currentMAC = "tempmac";
		InetAddress ip;
		HttpSession session = null;
		session = request.getSession(true);
		
		
		Properties prop = new Properties();
		try {
			if (MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES != null) {
				prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
			}
			else {
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
					prop.load(fis);
				}
				catch (Exception e) {
					FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "Exception occured while loading constants.properties file");
				}
				finally {
					if (fis != null) {
						fis.close();
						fis = null;
					}
				}

			}
		}
		catch (FileNotFoundException e) {
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "File not found exception found at the time of loading properties in attemptAuthentication ");
			e.printStackTrace();
		}
		catch (IOException e) {
			FLogger.error("securityLoggerError", "GroupsAuthenticationFilter", "attemptAuthentication", "IOException found at the time of loading properties in attemptAuthentication ");
			e.printStackTrace();
		}

		try {
			ip = InetAddress.getByName(request.getRemoteAddr());
			InetAddress ipAdd = InetAddress.getLocalHost();
			currentIp = ip.getHostAddress();
			trueIp = request.getHeader("True-Client-IP");
			final Enumeration<NetworkInterface> inetAddresses = NetworkInterface.getNetworkInterfaces();
			ArrayList<String> addrs = new ArrayList<String>();
			while (inetAddresses.hasMoreElements()) {
				final byte[] macBytes = inetAddresses.nextElement().getHardwareAddress();
				if (macBytes == null)
					continue;
				addrs.add(getMacAddress(macBytes));
			}
			currentMAC = addrs.get(0);

		}
		catch (UnknownHostException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String browserDetails = (String) request.getHeader("User-Agent");
			String loginThroughEmailMobile = obtainLoginThroughUserIdEmailMobile(request);// request.getParameter("userIdEmailMobile");
			String SSOGroupLogin = obtainLoginThroughSingleSignOn(request); 
			String websiteSource = obtainLoginThroughSingleSignOnSourcs(request);
			GroupsUserAuthInfo user = new GroupsUserAuthInfo();
			GroupsUserAuthInfoNew user1 = new GroupsUserAuthInfoNew();
			LoginHistory audit = new LoginHistory();
			IPruUser iPruUser = new IPruUser();
			if ("GRP_BROKER".equals(websiteSource)) {  
				FLogger.info("securityLoggerError", "GroupsAuthenticationFilter", "SSOGroupLoginBroker", "SSOGroup Broker login Failure Start");
				RoleBasedLoginDAO roleDAO = new RoleBasedLoginDAO("GroupSecurity");				
				String fscchannel= String.valueOf(session.getAttribute("fscchannel")); 
				String fscclientid=String.valueOf(session.getAttribute("fsc_client_Id"));  
				roleDAO.saveLoginHistoryBrokerSSO(fscchannel ,fscclientid, currentIp, currentMAC,browserDetails,false);    
				//audit = ipruDaoObj.onUnSuccessfulBorkerSSO(session.getAttribute("groupsBorkerPO") != null ? String.valueOf(session.getAttribute("fsc_client_Id")) : "-", currentIp, currentMAC);
				//this.getSSOGroupUnSuccessfullLogin(session, user1, iPruUser, currentIp, trueIp, browserDetails); 

			}
			else	
			if ("GRP_MEMBER".equals(websiteSource)) {
				FLogger.info("securityLoggerError", "GroupsAuthenticationFilter", "SSOGroupLoginRetail", "SSOGroup Retail login Failure Start");
				user1 = ipruDaoObj.onUnSuccessfulLoginThroughEmailMobile(session.getAttribute("mobileNo") != null ? String.valueOf(session.getAttribute("mobileNo")) : "-", currentIp, currentMAC);
				this.getSSOGroupUnSuccessfullLogin(session, user1, iPruUser, currentIp, trueIp, browserDetails);

			}
			else if (!StringUtils.isEmpty(loginThroughEmailMobile)) {
				if (loginThroughEmailMobile.equals(prop.getProperty("LOGIN_USERID"))) {
					user = ipruDaoObj.onUnSuccessfulLogin(request.getParameter(usernameParameter), currentIp, currentMAC);
					iPruUser.setRoles(user.getRole());
					iPruUser.setUserId(user.getFname());
					iPruUser.setMacAddress(user.getLastUnsuccessfulMACAddress());
					iPruUser.setLoginTime(user.getLastUnsuccessculLoginTime());
					iPruUser.setRemoteIp(currentIp);
					iPruUser.setUserIp(trueIp);
					iPruUser.setPassword(this.obtainPassword(request));
					ipruDaoObj.saveLoginHistoryDetails(iPruUser, false, browserDetails, user.getPsswrd());

				}
				else if (loginThroughEmailMobile.equals(prop.getProperty("LOGIN_EMAIL_MOBILE"))) {

					user1 = ipruDaoObj.onUnSuccessfulLoginThroughEmailMobile(request.getParameter(usernameParameter), currentIp, currentMAC);
					iPruUser.setRoles("USER");
					iPruUser.setUserId(request.getParameter(usernameParameter));
					iPruUser.setMacAddress(user1.getLastUnsuccessfulMACAddress());
					iPruUser.setLoginTime(user1.getLastUnsuccessculLoginTime());
					iPruUser.setRemoteIp(currentIp);
					iPruUser.setUserIp(trueIp);
					iPruUser.setPassword(this.obtainPassword(request));
					ipruDaoObj.saveLoginHistoryDetails(iPruUser, false, browserDetails, user1.getProperty());

				}
			}
			else {
				FLogger.info("securityLoggerError", "GroupsAuthenticationFilter", "SSOGroupLogin", "unAuthorized User Activity login Failure Start");
				iPruUser.setRoles("unAuthorized");
				iPruUser.setUserId("unAuthorized");
				iPruUser.setMacAddress(null);
				iPruUser.setLoginTime(null);
				iPruUser.setRemoteIp(currentIp);
				iPruUser.setUserIp(trueIp);
				iPruUser.setPassword(null);
				ipruDaoObj.saveLoginHistoryDetails(iPruUser, false, browserDetails, user1.getProperty());
				FLogger.info("securityLoggerError", "GroupsAuthenticationFilter", "SSOGroupLogin", "unAuthorized User Activity login Failure Start");

			}

		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String obtainLoginThroughSingleSignOnSourcs(
			HttpServletRequest request) {
		FLogger.info("securityLogger", "GroupsAuthenticationFilter", "obtainLoginThroughSingleSignOnSourcs", "obtainLoginThroughSingleSignOnSourcs has been called");
		String source = request.getParameter("websiteSource") != null ? request.getParameter("websiteSource") : (String) request.getAttribute("websiteSource");

		return source;
	}

	public static PreLoginThirdPartyInfoPO parse(String encryptedcontent, String decryptkey, HttpServletRequest request) throws Exception {  
		PreLoginThirdPartyInfoPO prelogininfopo = new PreLoginThirdPartyInfoPO();
		try {
			Gson gson = new Gson();
			String decryptcontent = EncryptionPBEMD5DES.decrypt(EncodingUtility.decodeBase64(encryptedcontent), decryptkey, 1);
			if (decryptcontent != null) {
				prelogininfopo = gson.fromJson(decryptcontent, PreLoginThirdPartyInfoPO.class);
			}
		}
		catch (JsonSyntaxException ex) {
			ex.printStackTrace();
		}
		return prelogininfopo;
	}


	private void getSSOGroupUnSuccessfullLogin(HttpSession session, GroupsUserAuthInfoNew user1, IPruUser iPruUser, String currentIp, String trueIp, String browserDetails) {
		FLogger.info("securityLoggerError", "GroupsAuthenticationFilter", "getSSOGroupUnSuccessfullLogin", "  Failure Start");
		String property = null;
		iPruUser.setRoles("SSOGroupRetailUser");
		iPruUser.setUserId(session.getAttribute("mobileNo") != null ? String.valueOf(session.getAttribute("mobileNo")) : "-");
		if (user1 != null) {

			iPruUser.setMacAddress(user1.getLastUnsuccessfulMACAddress());
			iPruUser.setLoginTime(user1.getLastUnsuccessculLoginTime());
			property = user1.getProperty();
		}
		else {
			FLogger.info("securityLoggerError", "GroupsAuthenticationFilter", "getSSOGroupUnSuccessfullLogin", "  GroupsUserAuthInfoNew should not be null Start");
			iPruUser.setMacAddress(null);
			iPruUser.setLoginTime(new Date());
		}
		iPruUser.setRemoteIp(currentIp);
		iPruUser.setUserIp(trueIp);
		ipruDaoObj.saveLoginHistoryDetails(iPruUser, false,browserDetails, property);
		session.removeAttribute("mobileNo");
		FLogger.info("securityLoggerError", "GroupsAuthenticationFilter", "getSSOGroupUnSuccessfullLogin", "  Failure Start");
	}
	
	//************** validation in source*************//
	
	private String getValidSource(String inputSrc){
		return prop.getProperty(inputSrc+"SOURCE");
		
	}
	
	private boolean isSourceValid(String inputSrc) {
		if(StringUtils.isBlank(inputSrc) || StringUtils.isBlank(getValidSource(inputSrc))){
		return false;	
		}
		return true;
	}
	
	
}
