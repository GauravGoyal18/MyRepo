package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDate;
import org.joda.time.Years;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.enums.NomineeUpdateAppointeeEnum;
import com.ipru.groups.enums.NomineeUpdateEnum;
import com.ipru.groups.enums.NomineeUpdateMandateApointeeEnum;
import com.ipru.groups.handler.NomineeUpdateHandler;
import com.ipru.groups.po.NomineeUpdateLoadDataPo;
import com.ipru.groups.po.NomineeUpdateParameters;
import com.ipru.groups.po.NomineeUpdateRelationPo;
import com.ipru.groups.po.NomineeUpdateSubmitPo;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.tcs.logger.FLogger;

public class NomineeUpdateValidator {
	private final StringBuilder errorMessageBuilder = new StringBuilder(1);
	ArrayList<String> relations = new ArrayList<String>();
	ArrayList<String> genders = new ArrayList<String>();

	boolean result = false;
	boolean validateAppointee[] = null;
	boolean appointeeDetailsFlag[] = null;
	List<String> nomineeDetails = new ArrayList<String>();
	List<String> nomineeMandateDetails = new ArrayList<String>();
	List<String> appointeeDetails = new ArrayList<String>();
	List<String> appointeeMandateDetails = new ArrayList<String>();
	Map<String, ArrayList<String>> appointeeList = null;
	NomineeUpdateParameters param = new NomineeUpdateParameters();
	String feildIdToBePrint = "";
	int noOfRows = 0;
	String benName = null;
	String appointeeName = null;
	Years age = null;

	public String validateNomineeUpdateSubmitPo(List<NomineeUpdateSubmitPo> nomineeUpdateSubmitPoList, RequestContext p_ObjContext) throws Exception {
		FLogger.info("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "method start");

		errorMessageBuilder.setLength(0);
		genders.add("male");
		genders.add("female");
		param.setGenders(genders);
		HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
		Map<String, FieldAccessMappingVO> fieldAccessMappingMap = null;
		if (httpSession != null) {
			List<NomineeUpdateRelationPo> nomineeUpdateRelationPoList = (List<NomineeUpdateRelationPo>) httpSession.getAttribute("nomineeUpdateRelation");
			//////System.out.println("nomineeUpdateRelationPoListnomineeUpdateRelationPoListnomineeUpdateRelationPoList" + nomineeUpdateRelationPoList.toString() + nomineeUpdateRelationPoList.size());

			if (nomineeUpdateRelationPoList == null || nomineeUpdateRelationPoList.size() <= 0) {
				FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured,nomineeUpdateRelationPoList Found null Data");

				throw new IPruException("Error", "GRPNOUP", "Found null Data");
			}
			NomineeUpdateLoadDataPo nomineeUpdateLoadDataPo = (NomineeUpdateLoadDataPo) p_ObjContext.getFlowScope().get("loadNomineeUpdateData");

			if (nomineeUpdateLoadDataPo != null) {
				fieldAccessMappingMap = nomineeUpdateLoadDataPo.getFieldAccessMappingMap();

				if (fieldAccessMappingMap.isEmpty()) {
					FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, Found null Data fieldAccessMappingMap");
					throw new IPruException("Error", "GRPNOUP", "Found null Data");
				}
				if (!nomineeUpdateLoadDataPo.isRequestPerDay()) {

					fieldAccessMappingMap = nomineeUpdateLoadDataPo.getFieldAccessMappingMap();

					FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, More than one request");
					throw new IPruException("Error", "GRPNOUP", "You can not send more than one request per day");
				}
			}
			else {
				FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, Found null Data from context");
				throw new IPruException("Error", "GRPNOUP", "Found null Data");
			}

			for (int i = 0; i < nomineeUpdateRelationPoList.size(); i++) {
				if (nomineeUpdateRelationPoList.get(i) != null) {
					NomineeUpdateRelationPo nomineeUpdateRelationPo = nomineeUpdateRelationPoList.get(i);
					relations.add(nomineeUpdateRelationPo.getValue());
					param.setRelations(relations);
					//////System.out.println("relationsrelationsrelationsrelationsrelationsrelations" + relations.toString());
				}
				else {

					FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, Found null Data");
					throw new IPruException("Error", "GRPNOUP", "Found null Data");

				}
			}

		}
		else {
			FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, Found null session");
			throw new IPruException("Error", "GRPNOUP", "Found null session");
		}

		if (nomineeUpdateSubmitPoList == null || nomineeUpdateSubmitPoList.size() <= 0) {
			FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured,nomineeUpdateSubmitPoList Found null Data");
			throw new IPruException("Error", "GRPNOUP", "Found null Data");

		}

		Map<String, ArrayList<String>> fieldList = getAllFields(nomineeUpdateSubmitPoList);
		// ////System.out.println("fieldListfieldList "+fieldList.toString());
		appointeeDetailsFlag = new boolean[fieldList.size()];
		validateAppointee = new boolean[fieldList.size()];
		getMandateDataForNomineeAndAppointee(fieldAccessMappingMap);
		if (fieldList != null && fieldList.size() > 0) {
			result = validateMandateFileds(fieldList);
		}
		else {
			FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, Null Data Found");
			throw new IPruException("Error", "GRPNOUP", " Null Data Found");
		}
		if (!result) {

			FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, Please Enter all Mandatory Feilds");
			throw new IPruException("Error", "GRPNOUP", "Please Enter all Mandatory Feilds");
		}

		result = validateNoOfRows(noOfRows);
		if (!result) {
			FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, Number of Nominee should not be greater than 10");
			throw new IPruException("Error", "GRPNOUP", "Number of Nominee should not be greater than 10");
		}

		for (int i = 0; i < nomineeUpdateSubmitPoList.size(); i++) {

			if (nomineeUpdateSubmitPoList.get(i) != null) {

				NomineeUpdateSubmitPo nomineeUpdateSubmitPo = nomineeUpdateSubmitPoList.get(i);
				String fieledIdWithExt = nomineeUpdateSubmitPo.getFieldId();
				int extention = fieledIdWithExt.indexOf('_');
				int nomineeCount = Integer.parseInt(fieledIdWithExt.substring(extention + 1, fieledIdWithExt.length()));
				if (extention == -1) {
					FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, Something went Wrong");
					throw new IPruException("Error", "GRPNOUP", "Something Went wrong");

				}
				String fieldId = fieledIdWithExt.substring(0, extention);

				if (!checkNomineeUpdateEnum(fieldId)) {
					continue;
				}
				result = validateIdAndValue(fieldId, nomineeUpdateSubmitPo.getValue(), nomineeCount);
				if (!result) {
					FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Please Enter Valid value for " + feildIdToBePrint);
					errorMessageBuilder.append("Please Enter Valid value for " + feildIdToBePrint + "\n");
					return errorMessageBuilder.toString();
				}

			}

		}

		for (int k = 0; k < validateAppointee.length; k++) {
			if (validateAppointee[k]) {
				// if validate appointee flag is true then only validate
				// apoointe

				result = validateAppointeeMandateFileds(fieldList, String.valueOf(k));
				if (!result) {
					throw new IPruException("Error", "GRPNOUP", "Please Enter all Mandatory Feilds");

				}
				for (int i = 0; i < nomineeUpdateSubmitPoList.size(); i++) {

					if (nomineeUpdateSubmitPoList.get(i) != null) {

						NomineeUpdateSubmitPo nomineeUpdateSubmitPo = nomineeUpdateSubmitPoList.get(i);
						String fieledIdWithExt = nomineeUpdateSubmitPo.getFieldId();
						int extention = fieledIdWithExt.indexOf('_');
						if (extention == -1) {
							FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, Something went Wrong");
							throw new IPruException("Error", "GRPNOUP", "Something Went wrong");

						}
						String fieldId = fieledIdWithExt.substring(0, extention);

						if (!checkNomineeUpdateAppointeeEnum(fieldId)) {

							continue;
						}

						result = validateIdAndValueForAppointee(fieldId, nomineeUpdateSubmitPo.getValue());
						if (!result) {
							FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Please Enter Valid value for " + feildIdToBePrint);
							errorMessageBuilder.append("Please Enter Valid value for " + feildIdToBePrint + "\n");
							return errorMessageBuilder.toString();
						}

					}

				}
			}

		}// for

		FLogger.info("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "validateNomineeUpdateSubmitPo method end");

		return errorMessageBuilder.toString();
	}

	private boolean validateNoOfRows(int rows) {

		if (rows > 10) {
			return false;
		}
		else
			return true;
	}

	private boolean validateAlpha(NomineeUpdateParameters parameters) {
		String value = parameters.getValue();
		if (CommonValidationUtil.ValidateRequired(value) && CommonValidationUtil.ValidateAlpha(value) && CommonValidationUtil.ValidateLengths(value, 1, 200)) {
			return true;
		}
		else {
			return false;
		}
	}
	public static boolean ValidateAlphaWithSpace(NomineeUpdateParameters parameters) {
		String value = parameters.getValue();
		if (CommonValidationUtil.ValidateRequired(value) && CommonValidationUtil.ValidateAlphaWithSpace(value) && CommonValidationUtil.ValidateLengths(value, 1, 200)) {
			return true;
		}
		else {
			return false;
		}

	}
	private boolean validateAppointeeDob(NomineeUpdateParameters parameters) throws ParseException {

		String value = parameters.getValue();
		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
		// SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");

		Date date1 = format1.parse(value);

		Date today = new Date();

		if (date1.before(today)) {

			if (CommonValidationUtil.ValidateRequired(value)) {

				return true;
			}
			else {

				return false;
			}
		}
		else {

			return false;
		}
	}

	public boolean validateDob(NomineeUpdateParameters parameters) throws ParseException, IPruException {

		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
		// SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");
		String value = parameters.getValue();
		int nomineeCount = parameters.getNomineeCount();
		Date date1 = format1.parse(value);
		Calendar myCal = Calendar.getInstance();
		myCal.setTime(date1);
		// boolean[] appointeeDetailsFlag=parameters.getAppointeeDetailsFlag();
		Date today = new Date();

		if (date1.before(today)) {

			// String date2=format2.format(date1);

			if (CommonValidationUtil.ValidateRequired(value)) {// for date

				LocalDate birthdate = new LocalDate(myCal.get(Calendar.YEAR), myCal.get(Calendar.MONTH) + 1, myCal.get(Calendar.DATE));
				// //System.out.println(myCal.get(Calendar.YEAR)+","+myCal.get(Calendar.MONTH)+","+myCal.get(Calendar.DATE)+","+date1.getYear()+","+date1.getMonth()+","+date1.getDate());
				// ////System.out.println("age**************"+birthdate);
				LocalDate now = new LocalDate();
				age = Years.yearsBetween(birthdate, now);
				// ////System.out.println("age**************"+age);

				/*if (age != null) {
					if (age.isLessThan(Years.years(18))) {

						if (appointeeDetailsFlag[nomineeCount]) {
							// ////System.out.println("age is lessssssssssssssssssssssssssss");

							// if age is less than 18 then we shoud validate
							// appintee details

							// call apointee validation function

							// for validate apponitee uncomment this
							validateAppointee[nomineeCount] = true;

						}
						else {

							// ////System.out.println("age is less than 18 so Appointee details should be capture");
							FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateDob", "Exception Occured, age is less than 18 so Appointee details should be capture");
							throw new IPruException("Error", "GRPNOUP", "Age is less than 18 so Appointee details should be capture");

						}

					}
					else {
						if (appointeeDetailsFlag[nomineeCount]) {
							// malitious activity

							// age is greater than 18 but still appointee
							// details exixist then throw
							// ////System.out.println("age is greater than 18 but still appointee details exixist then throw");
							FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateDob", "Exception Occured, Something went Wrong");
							throw new IPruException("Error", "GRPNOUP", "Something Went wrong");

						}

					}

				}
				else {
					FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateNomineeUpdateSubmitPo", "Exception Occured, Found null Data");
					throw new IPruException("Error", "GRPNOUP", "Found null Data");
				}
*/
				return true;

			}
			else {

				return false;
			}

		}

		else {
			return false;
		}
	}

	private boolean validateShare(NomineeUpdateParameters parameters) {
		String value = parameters.getValue();
		if (CommonValidationUtil.ValidateRequired(value) && CommonValidationUtil.ValidateNumeric(value) && CommonValidationUtil.ValidateMaxLength(value, 3)) {
			NomineeUpdateHandler.totalSharePercent = NomineeUpdateHandler.totalSharePercent + Integer.parseInt(value);

			return true;

		}
		else {
			return false;
		}
	}

	private boolean validatePinCode(NomineeUpdateParameters parameters) {
		String value = parameters.getValue();
		if (CommonValidationUtil.ValidateRequired(value) && CommonValidationUtil.ValidateNumeric(value) && CommonValidationUtil.ValidateMaxLength(value, 6)) {
			return true;

		}
		else {
			return false;
		}
	}

	private boolean validateAddress(NomineeUpdateParameters parameters) {
		String value = parameters.getValue();
		if (CommonValidationUtil.ValidateRequired(value) && CommonValidationUtil.ValidateAddress(value)) {
			return true;

		}
		else {
			return false;
		}
	}

	private boolean validateRelation(NomineeUpdateParameters parameters) {
		//////System.out.println("relationsrelationsrelationsrelationsrelationsrelations inside validateRelation" + relations.toString());

		String value = parameters.getValue();
		if (relations.contains(value)) {
			if (!validateAlpha(parameters))
				return false;

			return true;

		}
		else {
			return false;
		}
	}

	private boolean validateGender(NomineeUpdateParameters parameters) {

		String value = parameters.getValue();

		if (genders.contains(value)) {

			if (!validateAlpha(parameters)) {
				return false;
			}

			return true;

		}
		else {
			return false;
		}
	}

	private boolean validateIdAndValue(String fieldId, String value, int nomineeCount) throws Exception {

		boolean result = false;
		// Properties prop = new Properties();
		// String methodName=null;
		// prop = MasterPropertiesFileLoader.CONSTANT_NOMINEEUPDATE_PROPERTIES;

		param.setNomineeCount(nomineeCount);
		param.setValue(value);
		/*
		 * if(prop!=null) { methodName=prop.getProperty(fieldId); }
		 * NomineeUpdateValidator validator=new NomineeUpdateValidator();
		 * ////System.out.println("methodNamemethodNamemethodName"+methodName); try
		 * { Method method = validator.getClass().getDeclaredMethod(methodName,
		 * NomineeUpdateParameters.class); result=(Boolean)
		 * method.invoke(validator, param);
		 * ////System.out.println("result is ***********************"+result); }
		 * catch(InvocationTargetException e) { e.printStackTrace(); }
		 * catch(Exception e) { e.printStackTrace(); }
		 */
		NomineeUpdateEnum nomineeUpdateEnum = NomineeUpdateEnum.valueOf(fieldId);

		switch (nomineeUpdateEnum) {
			case beneficaryName:
				result = ValidateAlphaWithSpace(param);
				feildIdToBePrint = "Beneficary First Name";

				break;
			case dob:

				result = validateDob(param);
				feildIdToBePrint = "Date Of Birth";

				break;
			case relation:
				result = validateRelation(param);

				feildIdToBePrint = "Relation";

				break;
			case gender:
				result = validateGender(param);

				feildIdToBePrint = "Gender";

				break;
			case beneficaryLastName:
				result = ValidateAlphaWithSpace(param);
				feildIdToBePrint = "Beneficary Last Name";

				break;
			case share:
				result = validateShare(param);
				// NomineeUpdateHandler.totalSharePercent=NomineeUpdateHandler.totalSharePercent+Integer.parseInt(value);
				feildIdToBePrint = "Share";

				break;

			default:
				break;
		}

		return result;
	}

	private boolean validateIdAndValueForAppointee(String fieldId, String value) throws IPruException {

		param.setValue(value);
		boolean result = false;
		NomineeUpdateAppointeeEnum nomineeUpdateAppointeeEnum = NomineeUpdateAppointeeEnum.valueOf(fieldId);
		switch (nomineeUpdateAppointeeEnum) {
			case apointeeFirstappointeeName:
				result = ValidateAlphaWithSpace(param);
				feildIdToBePrint = "Appointee First Name";

				break;
			case apointeeDob:
				try {
					result = validateAppointeeDob(param);
					feildIdToBePrint = "Appointee Date Of Birth";
				}
				catch (Exception e) {
					throw new IPruException("Error", "GRPNOUP", "Please Enter Valid date");

				}
				break;
			case apointeeRelation:
				result = validateRelation(param);
				// result=validateAlpha(value);
				feildIdToBePrint = "Appointee Relation";

				break;
			case apointeeGender:
				result = validateGender(param);
				// result=validateAlpha(value);
				feildIdToBePrint = "Appointee Gender";

				break;
			case apointeeLasttappointeeName:
				result = ValidateAlphaWithSpace(param);
				feildIdToBePrint = "Appointee Last Name";

				break;

			default:
				break;

		}

		return result;
	}

	public Map<String, ArrayList<String>> getAllFields(List<NomineeUpdateSubmitPo> nomineeUpdateSubmitPoList) throws IPruException {

		String fieledIdWithExt = null;
		String fieldId = null;
		String prevNomineeNumber = null;
		ArrayList<String> values = new ArrayList<String>();
		Map<String, ArrayList<String>> result = new HashMap<String, ArrayList<String>>();
		for (int i = 0; i < nomineeUpdateSubmitPoList.size(); i++) {

			// ////System.out.println("data***********************************************"+result.toString());
			// ////System.out.println("value***********************************************"+values.toString());

			if (nomineeUpdateSubmitPoList.get(i) == null) {
				FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "getAllFields", "Exception Occured, Something went Wrong");
				throw new IPruException("Error", "GRPNOUP", "Something Went wrong");// malitious
																					// request
			}
			else {
				NomineeUpdateSubmitPo nomineePojo = nomineeUpdateSubmitPoList.get(i);
				fieledIdWithExt = nomineePojo.getFieldId();
				if (fieledIdWithExt == null) {
					FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "getAllFields", "Exception Occured, Something went Wrong");
					throw new IPruException("Error", "GRPNOUP", "Something Went wrong");// malitious
																						// request
				}
				int extention = fieledIdWithExt.indexOf('_');

				if (extention == -1) {
					FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "getAllFields", "Exception Occured, Something went Wrong");
					throw new IPruException("Error", "GRPNOUP", "Something Went wrong");// malitious
																						// request
				}

				fieldId = fieledIdWithExt.substring(0, extention);
				String nomineeNumber = fieledIdWithExt.substring(extention + 1, fieledIdWithExt.length());
				if (nomineeNumber == null) {
					FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "getAllFields", "Exception Occured, Something went Wrong");
					throw new IPruException("Error", "GRPNOUP", "Something Went wrong");
					// malitious request
				}
				if (prevNomineeNumber == null || prevNomineeNumber.equalsIgnoreCase("")) {
					prevNomineeNumber = nomineeNumber;
				}
				else {
					if (!nomineeNumber.equalsIgnoreCase(prevNomineeNumber)) {

						if (Integer.parseInt(prevNomineeNumber) + 1 != Integer.parseInt(nomineeNumber)) {
							FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "getAllFields", "Exception Occured, Something went Wrong");
							throw new IPruException("Error", "GRPNOUP", "Something Went wrong");
							// malitious request
						}

						ArrayList<String> newValues = new ArrayList<String>();
						for (int k = 0; k < values.size(); k++) {
							newValues.add(values.get(k));
						}
						result.put(prevNomineeNumber, newValues);
						// ////System.out.println("inside data***********************************"+result.toString());
						values.clear();
						// ////System.out.println("size***********************************************"+result.size());
						prevNomineeNumber = nomineeNumber;

					}
				}

				if (!values.contains(fieldId)) {
					values.add(fieldId);
				}
				else {
					throw new IPruException("Error", "GRPNOUP", "Duplicate value insertion");
				}

			}

		}

		noOfRows = Integer.parseInt(prevNomineeNumber) + 1;

		result.put(prevNomineeNumber, values);
		return result;
	}

	public boolean validateAppointeeMandateFileds(Map<String, ArrayList<String>> fieldList, String key) throws IPruException {

		if (fieldList != null && fieldList.size() > 0) {

			ArrayList values = fieldList.get(key);

			if (values == null || values.size() <= 0) {

				FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateMandateFileds", "Exception Occured, Null Data Found");
				throw new IPruException("Error", "GRPNOUP", "Null Data Found");
			}

			/*
			 * if(values.size()>11) { FLogger.error("NomineeUpdateLogger",
			 * "NomineeUpdateValidator", "validateMandateFileds",
			 * "Exception Occured, Not proper Data"); throw new
			 * IPruException("Error","GRPNOUP","Enter Proper Data"); } else {
			 */

			// for (NomineeUpdateMandateApointeeEnum
			// nomineeUpdateMandateApointeeEnum :
			// NomineeUpdateMandateApointeeEnum.values()) {

			/*
			 * if(nomineeUpdateMandateApointeeEnum==null) {
			 * FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator",
			 * "validateMandateFileds", "Exception Occured, Null Data Found");
			 * throw new IPruException("Error","GRPNOUP","Null Data Found"); }
			 */
			for (int j = 0; j < appointeeMandateDetails.size(); j++) {

				if (values.contains(appointeeMandateDetails.get(j))) {

					continue;
				}
				else {
					// errorMessageBuilder.append("Enter mandatory Details \n");

					errorMessageBuilder.append("Enter mandatory Details \n");
					return false;

				}
			}

			// }

		}
		else {

			FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateMandateFileds", "Exception Occured, Null Data Found");
			throw new IPruException("Error", "GRPNOUP", "Null Data Found");
		}

		return true;
	}

	public boolean validateMandateFileds(Map<String, ArrayList<String>> fieldList) throws IPruException {

		if (fieldList != null && fieldList.size() > 0) {
			for (String key : fieldList.keySet()) {
				ArrayList values = fieldList.get(key);

				if (values == null || values.size() <= 0) {

					FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateMandateFileds", "Exception Occured, Null Data Found");
					throw new IPruException("Error", "GRPNOUP", "Null Data Found");
				}

				/*
				 * if(values.size()>11)//from propertoes {
				 * FLogger.error("NomineeUpdateLogger",
				 * "NomineeUpdateValidator", "validateMandateFileds",
				 * "Exception Occured, Not proper Data"); throw new
				 * IPruException("Error","GRPNOUP","Enter Proper Data"); } else
				 * {
				 */

				/*
				 * List<String> nomineeDetails=new ArrayList<String>();
				 * List<String> nomineeMandateDetails=new ArrayList<String>();
				 */
			//	////System.out.println("nomineeMandateDetailsnomineeMandateDetailsnomineeMandateDetails" + nomineeMandateDetails.toString());
			//	////System.out.println("nomineeDetailsnomineeDetailsnomineeDetailsnomineeDetails" + nomineeDetails.toString());
				/*
				 * for (NomineeUpdateMandateEnum nomineeUpdateEnum :
				 * NomineeUpdateMandateEnum.values()) {
				 * if(nomineeUpdateEnum==null) {
				 * FLogger.error("NomineeUpdateLogger",
				 * "NomineeUpdateValidator", "validateMandateFileds",
				 * "Exception Occured, Null Data Found"); throw new
				 * IPruException("Error","GRPNOUP","Null Data Found"); }
				 * if(values.contains(nomineeUpdateEnum.toString())) { continue;
				 * } else {
				 * //errorMessageBuilder.append("Enter mandatory Details \n");
				 * errorMessageBuilder.append("Enter mandatory Details \n");
				 * return false; } }
				 */

				for (int j = 0; j < nomineeMandateDetails.size(); j++) {
					if (values.contains(nomineeMandateDetails.get(j))) {

						continue;
					}
					else {
						// errorMessageBuilder.append("Enter mandatory Details \n");
						errorMessageBuilder.append("Enter mandatory Details \n");
						return false;

					}
				}

				int i = 0;
				/*
				 * for (NomineeUpdateAppointeeEnum nomineeUpdateAppointeeEnum :
				 * NomineeUpdateAppointeeEnum.values()) {
				 * if(nomineeUpdateAppointeeEnum==null) {
				 * FLogger.error("NomineeUpdateLogger",
				 * "NomineeUpdateValidator", "validateMandateFileds",
				 * "Exception Occured, Null Data Found"); throw new
				 * IPruException("Error","GRPNOUP","Null Data Found"); }
				 * if(values.contains(nomineeUpdateAppointeeEnum.toString())) {
				 * appointeeDetailsFlag[Integer.parseInt(key)]=true; break; }
				 * else {
				 * //errorMessageBuilder.append("Enter mandatory Details \n");
				 * appointeeDetailsFlag[Integer.parseInt(key)]= false; continue;
				 * } }
				 */
				for (int j = 0; j < appointeeMandateDetails.size(); j++) {
					if (values.contains(appointeeMandateDetails.get(j))) {

						appointeeDetailsFlag[Integer.parseInt(key)] = true;
						break;
					}
					else {
						// errorMessageBuilder.append("Enter mandatory Details \n");
						appointeeDetailsFlag[Integer.parseInt(key)] = false;

						continue;

					}
				}
				param.setAppointeeDetailsFlag(appointeeDetailsFlag);

				// }

			}
		}
		else {

			FLogger.error("NomineeUpdateLogger", "NomineeUpdateValidator", "validateMandateFileds", "Exception Occured, Null Data Found");
			throw new IPruException("Error", "GRPNOUP", "Null Data Found");
		}

		return true;
	}

	public boolean checkNomineeUpdateEnum(String test) {
		for (NomineeUpdateEnum nomineeUpdateEnum : NomineeUpdateEnum.values()) {
			if (nomineeUpdateEnum.name().equals(test)) {
				return true;
			}
		}

		return false;
	}

	public boolean checkNomineeUpdateAppointeeEnum(String test) {
		for (NomineeUpdateAppointeeEnum nomineeUpdateAppointeeEnum : NomineeUpdateAppointeeEnum.values()) {
			if (nomineeUpdateAppointeeEnum.name().equals(test)) {
				return true;
			}
		}

		return false;
	}

	public boolean checkNomineeUpdateMandateApointeeEnum(String test) {
		for (NomineeUpdateMandateApointeeEnum nomineeUpdateMandateApointeeEnum : NomineeUpdateMandateApointeeEnum.values()) {
			if (nomineeUpdateMandateApointeeEnum.name().equals(test)) {
				return true;
			}
		}

		return false;
	}

	public void getMandateDataForNomineeAndAppointee(Map<String, FieldAccessMappingVO> fieldAccessMappingMap) {

		// nomineeDetails=;
		// nomineeMandateDetails=;

		Iterator<String> itr = fieldAccessMappingMap.keySet().iterator();
		while (itr != null && itr.hasNext()) {
			FieldAccessMappingVO fieldAccessMappingPO = fieldAccessMappingMap.get(itr.next());

			if (fieldAccessMappingPO.getRdComponent().startsWith("apointee")) {

				appointeeDetails.add(fieldAccessMappingPO.getRdComponent());
				if (fieldAccessMappingPO.getOpMandatory().equalsIgnoreCase("1")) {
					appointeeMandateDetails.add(fieldAccessMappingPO.getRdComponent());
				}
			}
			else {

				if (!fieldAccessMappingPO.getRdComponent().equalsIgnoreCase("nomineeUpdate") && !fieldAccessMappingPO.getRdComponent().equalsIgnoreCase("apponiteeDetails")) {
					nomineeDetails.add(fieldAccessMappingPO.getRdComponent());
					if (fieldAccessMappingPO.getOpMandatory().equalsIgnoreCase("1")) {
						nomineeMandateDetails.add(fieldAccessMappingPO.getRdComponent());
					}
				}
			}

		}

	}

}
