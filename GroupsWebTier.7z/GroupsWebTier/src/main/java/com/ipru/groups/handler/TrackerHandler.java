package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;
import org.apache.commons.collections4.CollectionUtils;
import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.ServiceTrackerTransformerPO;
import com.ipru.groups.po.TrackerOpenClosePO;
import com.ipru.groups.po.TrackerRequestPO;
import com.ipru.groups.po.TrackerResponsePO;
import com.ipru.groups.utilities.TrackerUtil;
import com.ipru.groups.vo.ServiceTrackerTransformerVO;
import com.ipru.groups.vo.ServiceWebpageCallVO;
import com.ipru.groups.vo.TrackerRequestVO;
import com.ipru.groups.vo.TrackerResponseVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class TrackerHandler extends IneoBaseHandler {

	@MethodPost
	public Event getBizRequestOnLoad(RequestContext context) throws Exception {
		FLogger.info("TRACKERLogger", "TrackerHandler", "getBizRequestOnLoad", "getBizRequestOnLoad Method Start");
		Gson gson = new Gson();

		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
				String clientId = null;
				String policyNo = null;

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {
						
						policyNo = userVo.getPolicyNo();
						clientId = userVo.getClientId();
						
						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

						if (request != null) {
							ServiceWebpageCallVO serviceWebpageCallVO = new ServiceWebpageCallVO();
							serviceWebpageCallVO.setClientId(clientId);
							serviceWebpageCallVO.setPolicyNo(policyNo);
						
							
							Object[] paramArray = new Object[1];

							if (serviceWebpageCallVO != null) {
								paramArray[0] = serviceWebpageCallVO;
								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);
								context.getFlowScope().put("trackerBizReqOnLoad", obj_bizReq);
							}
							else {
								FLogger.error("TRACKERLogger", "TrackerHandler", "getBizRequestOnLoad", "trackervo should not be null");
								throw new IPruException("Error", "GRPT01", "trackervo should not be null");
							}

						}
						else {

							FLogger.error("TRACKERLogger", "TrackerHandler", "getBizRequestOnLoad", "request should not be null");
							throw new IPruException("Error", "GRPT01", "request should not be null");
						}
					}
					else {
						FLogger.error("TRACKERLogger", "TrackerHandler", "getBizRequestOnLoad", "userVo should not be null");
						throw new IPruException("Error", "GRPT01", "userVo should not be null");
					}
				}
				else {
					FLogger.error("TRACKERLogger", "TrackerHandler", "getBizRequestOnLoad", "httpSession should not be null");
					throw new IPruException("Error", "GRPT01", "httpSession should not be null");
				}
			}
			else {
				FLogger.error("TRACKERLogger", "TrackerHandler", "getBizRequestOnLoad", "Context should not be null");
				throw new IPruException("Error", "GRPT01", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("TRACKERLogger", "TrackerHandler", "getBizRequestOnLoad", "Exception came ", e);
			throwINeoFlowException(e, "GRPT01", context);
		}
		FLogger.info("TRACKERLogger", "TrackerHandler", "getBizRequestOnLoad", "onEntry of getBizRequestOnLoad Method End ");
		return success();
	}
	
	@MethodPost
	public Event getBizResponsetOnLoad(RequestContext context) throws Exception {

		FLogger.info("TRACKERLogger", "TrackerHandler", "getBizResponsetOnLoad", "onEntry of getBizResponsetOnLoad Method ");
		try {

			Gson gson = new Gson();

			BizResponse response = new BizResponse();
			response = (BizResponse) context.getFlowScope().get("bizResForSubmitTrackerOnLoad");
			List<ServiceTrackerTransformerVO> serviceTrackerTransformerVOList = (List<ServiceTrackerTransformerVO>) response.getTransferObjects().get("response1");
			List<ServiceTrackerTransformerPO> serviceTrackerTransformerPOList=new ArrayList<ServiceTrackerTransformerPO>();
			TrackerResponsePO trackerResponsePO = null;			
			List value = null;
			if (serviceTrackerTransformerVOList == null) {
				FLogger.error("TRACKERLogger", "TrackerHandler", "getBizResponsetOnLoad", "serviceTrackerTransformerVOList is Empty");
				throw new IPruException("Error", "GRPT01", "No Data Found");
			}
		
				for (ServiceTrackerTransformerVO serviceTrackerTransformerVO : serviceTrackerTransformerVOList) {
					ServiceTrackerTransformerPO serviceTrackerTransformerPO = new ServiceTrackerTransformerPO();
					serviceTrackerTransformerPO=dozerBeanMapper.map(serviceTrackerTransformerVO, ServiceTrackerTransformerPO.class);
					serviceTrackerTransformerPOList.add(serviceTrackerTransformerPO);					
				}		
				
				TrackerOpenClosePO trackerOpenClosePO=new TrackerOpenClosePO();
				TrackerUtil util=new TrackerUtil();
				trackerOpenClosePO=util.getOpenCloseData(serviceTrackerTransformerPOList);
				if(trackerOpenClosePO==null)
				{
					FLogger.error("TRACKERLogger", "TrackerHandler", "getBizResponsetOnLoad", "serviceTrackerTransformerVOList is Empty");
					throw new IPruException("Error", "GRPT01", "serviceTrackerTransformerVOList is Empty");
				}
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				httpSession.setAttribute("trackerOpenClosePO", trackerOpenClosePO);
				
				
				context.getFlowScope().put("Response", gsonJSON.toJson(trackerOpenClosePO));
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("TRACKERLogger", "TrackerHandler", "getBizResponsetOnLoad", "Exception came", e);
			throwINeoFlowException(e, "GRPT01", context);
		}
		FLogger.info("TRACKERLogger", "TrackerHandler", "getBizResponsetOnLoad", "onEntry of getBizResponsetOnLoad Method End");
		return success();

	}
	
	

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}
}
