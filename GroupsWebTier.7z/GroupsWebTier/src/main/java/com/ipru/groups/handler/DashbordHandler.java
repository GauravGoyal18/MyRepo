package com.ipru.groups.handler;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.DashboardDetailsPO;
import com.ipru.groups.po.DashboardLoadRequestPO;
import com.ipru.groups.po.PolicyDetailsPO;
import com.ipru.groups.vo.DashboardDetailsVO;
import com.ipru.groups.vo.DashboardLoadRequestVO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.SaMemberStatus;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.ipru.security.user.PolicyDetails;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class DashbordHandler extends IneoBaseHandler {

	@MethodPost
	public Event getBizRequestForIsValidUserForSwitch(RequestContext context) throws Exception {
		FLogger.info("DashboardLogger", "DashbordHandler", "getBizRequestForIsValidUserForSwitch", "Method start");

		try {
			if (context != null) { // context htao
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				IPruUser userVo = new IPruUser();

				if (httpSession != null) {  // session b har baar milega

					userVo = (IPruUser) httpSession.getAttribute("userVO");
					// ////System.out.println("UserVo in session : " + userVo);

					SaMemberStatus saMemberStatus = new SaMemberStatus();
					saMemberStatus.setClientId(userVo.getClientId());
					saMemberStatus.setPolicyNo(userVo.getPolicyNo());

					Object[] paramArray = new Object[1];
					paramArray[0] = saMemberStatus;

					BizRequest obj_bizReq = new BizRequest();
					obj_bizReq.addbusinessObjects("service-obj1", paramArray);

					context.getFlowScope().put("loadIsValidUserForSwitchBizReq", obj_bizReq);

				}
				else {
					FLogger.error("DashboardError", "DashbordHandler", "getBizRequestForIsValidUserForSwitch", "Session is null");
					throw new IPruException("Session is null");
				}
			}
			else {
				FLogger.error("DashboardError", "DashbordHandler", "getBizRequestForLoadDashboardDetails", "context should not be null");
				throw new IPruException("context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("DashboardError", "DashbordHandler", "getBizRequestForLoadDashboardDetails", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}

		FLogger.info("DashboardLogger", "DashbordHandler", "getBizRequestForLoadDashboardDetails", "Method end.");

		return success();
	}

	@MethodPost
	public Event getBizResponseForIsValidUserForSwitch(RequestContext context) throws Exception {
		String responseCheck = "";
		BizResponse bizRes = new BizResponse();
		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				bizRes = (BizResponse) context.getFlowScope().get("bizResForIsValidUserForSwitch");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();

					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error("DashboardLogger", "DashbordHandler", "getBizResponseForIsValidUserForSwitch", "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {

						IPruUser userVo = new IPruUser();

						if (httpSession != null) {

							userVo = (IPruUser) httpSession.getAttribute("userVO");

							List<SaMemberStatus> isValidUserForSwitchList = (List<SaMemberStatus>) bizRes.getTransferObjects().get("response1");

							userVo.setIsValidUser(isValidUserForSwitchList.get(0).getStatus());

							// }
							String callJsonString = gsonJSON.toJson(isValidUserForSwitchList);
							FLogger.info("DashboardLogger", "DashbordHandler", "getBizResponseForIsValidUserForSwitch", "callJsonString::" + callJsonString);
							context.getFlowScope().put("Response", callJsonString);
							// }
						}
					}
				}
				else {
					FLogger.error("DashboardLogger", "DashbordHandler", "getBizResponseForIsValidUserForSwitch", "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error("DashboardLogger", "DashbordHandler", "getBizResponseForIsValidUserForSwitch", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("DashboardLogger", "DashbordHandler", "getBizResponseForIsValidUserForSwitch", "Exception came ", e);
			throwINeoFlowException(e, "GRPBO", context);
		}
		FLogger.info("DashboardLogger", "DashbordHandler", "getBizResponseForIsValidUserForSwitch", "Method end");

		return success();

	}

	@MethodPost
	public Event getBizRequestCheckValidUserForSwitch(RequestContext context) throws Exception {
		String METHOD_NAME = "getBizRequestCheckValidUserForSwitch";
		FLogger.info("DashboardLogger", "DashbordHandler", METHOD_NAME, "Method start ");
		String message = null;

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
					if (request != null) {
						String saMemberStatus = gsonJSON.fromJson(request.getReader(), String.class);

						if (saMemberStatus != null) {

							String validUser = userVo.getIsValidUser();

							String status = saMemberStatus;
							if (validUser.equalsIgnoreCase(status)) {
								message = validUser;
								context.getFlowScope().put("Response", message);

							}

							else {
								FLogger.error("DashboardLogger", "DashbordHandler", METHOD_NAME, "saMemberStatus from request should not be null");
								throw new IPruException("Error", "GRPFP01", "Switching options are not applicable for this member account");
							}

						}
						else {
							FLogger.error("DashboardLogger", "DashbordHandler", METHOD_NAME, "saMemberStatus from request should not be null");
							throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error("DashboardLogger", "DashbordHandler", METHOD_NAME, "request should not be null");
						throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error("DashboardLogger", "DashbordHandler", METHOD_NAME, "Session should not be null");
					throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error("DashboardLogger", "DashbordHandler", METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("DashboardLogger", "DashbordHandler", METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPFP01", context);
		}

		FLogger.info("DashboardLogger", "DashbordHandler", METHOD_NAME, "Method end ");
		return success();
	}

	@MethodPost
	public Event getBizRequestForLoadDashboardDetails(RequestContext context) throws Exception {
		FLogger.info("DashboardLogger", "DashbordHandler", "getBizRequestForLoadDashboardDetails", "Method start");

		try {
			if (context != null) { // context htao
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				IPruUser userVo = new IPruUser();
				String screenName = null;

				if (httpSession != null) {  // session b har baar milega
					screenName = (String) context.getFlowScope().get("screenName");

					userVo = (IPruUser) httpSession.getAttribute("userVO");
					// ////System.out.println("UserVo in session : " + userVo);

					DashboardLoadRequestPO dashboardLoadRequestPO = new DashboardLoadRequestPO();
					dashboardLoadRequestPO.setScreenName(screenName);
					dashboardLoadRequestPO.setUserVO(userVo);

					DashboardLoadRequestVO dashboardLoadRequestVO = dozerBeanMapper.map(dashboardLoadRequestPO, DashboardLoadRequestVO.class);

					Object[] paramArray = new Object[1];
					paramArray[0] = dashboardLoadRequestVO;

					BizRequest obj_bizReq = new BizRequest();
					obj_bizReq.addbusinessObjects("service-obj1", paramArray);

					context.getFlowScope().put("loadDashboardBizReq", obj_bizReq);

				}
				else {
					FLogger.error("DashboardError", "DashbordHandler", "getBizRequestForLoadDashboardDetails", "Session is null");
					throw new IPruException("Session is null");
				}
			}
			else {
				FLogger.error("DashboardError", "DashbordHandler", "getBizRequestForLoadDashboardDetails", "context should not be null");
				throw new IPruException("context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("DashboardError", "DashbordHandler", "getBizRequestForLoadDashboardDetails", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}

		FLogger.info("DashboardLogger", "DashbordHandler", "getBizRequestForLoadDashboardDetails", "Method end.");

		return success();
	}

	@SuppressWarnings("unchecked")
	@MethodPost
	public Event getBizResponseForLoadDashboardDetails(RequestContext context) throws Exception {

		FLogger.info("DashboardLogger", "DashbordHandler", "getBizResponseForLoadDashboardDetails", "Method start");

		DashboardDetailsVO dashboardDetailsVO = null;
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		IPruUser userVo = null;
		PolicyDetails selectedPolicy = null;
		boolean isEmailMobileUpdated = false;

		try {
			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					userVo = (IPruUser) httpSession.getAttribute("userVO");
					selectedPolicy = userVo.getSelectedPolicy();
				}
				bizRes = (BizResponse) context.getFlowScope().get("bizResForLoadDashboardDetails");

				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {
						dashboardDetailsVO = (DashboardDetailsVO) bizRes.getTransferObjects().get("response1");
						if (dashboardDetailsVO != null) {
							userVo.setUnitName(dashboardDetailsVO.getPolicyDetailList().get(0).getUnitName());
							userVo.setClientName(dashboardDetailsVO.getPolicyDetailList().get(0).getTrustName());
							DashboardDetailsPO dashboardDetailsPO = dozerBeanMapper.map(dashboardDetailsVO, DashboardDetailsPO.class);
							dashboardDetailsPO.setSelectedPolicy(selectedPolicy);
							if (null != dashboardDetailsPO.getSelectedPolicy())
								dashboardDetailsPO.getSelectedPolicy().setIsValidUser(userVo.getIsValidUser());
							String dashboardDetailsPOJsonString = gsonJSON.toJson(dashboardDetailsPO, DashboardDetailsPO.class);

							context.getFlowScope().put("Response", dashboardDetailsPOJsonString);
						}
						else {
							FLogger.error("DashboardError", "DashbordHandler", "getBizResponseForLoadDashboardDetails", "Data from service should not be null");
							throw new IPruException("Data from Service should not be null");
						}
					}
				}
				else {
					FLogger.error("DashboardError", "DashbordHandler", "getBizResponseForLoadDashboardDetails", "bizRes should not be null");
					throw new IPruException("bizRes should not be null");
				}

			}

			else {
				FLogger.error("DashboardError", "DashbordHandler", "getBizResponseForLoadDashboardDetails", "context should not be null");
				throw new IPruException("context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("DashboardError", "DashbordHandler", "getBizResponseForLoadDashboardDetails", "Exception came ", e);
			throwINeoFlowException(e, "GRYY02", context);
		}

		FLogger.info("DashboardLogger", "DashbordHandler", "getBizResponseForLoadDashboardDetails", "Method end");

		return success();
	}

	public Event getBizRequestForChangePolicyDetails(RequestContext context) throws Exception {
		FLogger.info("DashboardLogger", "DashbordHandler", "getBizRequestForChangePolicyDetails", "Method start");

		String clientId = null;
		HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
		if (request != null) {
			PolicyDetailsPO policyDetailsPO = (PolicyDetailsPO) gsonJSON.fromJson(request.getReader(), PolicyDetailsPO.class);

			if (policyDetailsPO != null) {
				clientId = policyDetailsPO.getClientId();

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					IPruUser userVO = (IPruUser) httpSession.getAttribute("userVO");

					Map<String, PolicyDetails> policyDetailMap = userVO.getPolicyDetailMap();

					if (policyDetailMap != null) {
						PolicyDetails policyDetails = policyDetailMap.get(clientId);

						userVO.setPolicyNo(policyDetails.getPolicyNo());
						userVO.setClientId(policyDetails.getClientId());
						userVO.setRoles(policyDetails.getRole());
						userVO.setRoleType(policyDetails.getRoleType());
						userVO.setEmpId(policyDetails.getEmpId());
						userVO.setTitle(policyDetails.getTitle());
						userVO.setDateOfJoiningScheme(policyDetails.getDateOfJoiningScheme());
						userVO.setDob(policyDetails.getDob());
						userVO.setClientName(policyDetails.getClientName());
						userVO.setPanNo(policyDetails.getPanNumber());
						userVO.setWorkPhone(policyDetails.getWorkPhone());
						userVO.setHomePhone(policyDetails.getHomePhone());
						userVO.setWorkEmailId(policyDetails.getWorkEmailId());
						userVO.setHomeEmailId(policyDetails.getHomeEmailId());
						userVO.setProductType(policyDetails.getProductType());
						userVO.setIsValidUser(policyDetails.getIsValidUser());
						userVO.setAccessMatrix(policyDetails.getAccessMatrix());
						userVO.setLstRoleScreenAccessMapping(policyDetails.getLstRoleScreenAccessMapping());
						userVO.setScreenDisplayed(policyDetails.getScreensDisplayed());
						userVO.setScreenAccessDeniedList(policyDetails.getScreenAccessDeniedList());
						userVO.setLandingPage(policyDetails.getLandingPage());
						List<FieldAccessMappingVO> fieldAccessMappingList = policyDetails.getFieldAccessMappingVoList();
						userVO.setFieldAccessMappingVoList(fieldAccessMappingList);

						userVO.setSelectedPolicy(policyDetails);

						httpSession.setAttribute("userVO", userVO);

						context.getFlowScope().put("Response", "Success");
					}
				}
			}
		}

		FLogger.info("DashboardLogger", "DashbordHandler", "getBizRequestForChangePolicyDetails", "Method end");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {

	}

	/*
	 * private boolean isEmailMobileCheckEnabled(List<RoleScreenAccessMappingVO>
	 * accessMappingList) { ////System.out.println("accessMappingList : "+
	 * accessMappingList); if(accessMappingList != null){
	 * for(RoleScreenAccessMappingVO roleScreenAccessMappingVO :
	 * accessMappingList){ if(roleScreenAccessMappingVO != null &&
	 * StringUtils.isNotEmpty(roleScreenAccessMappingVO.getScreenCode()) &&
	 * StringUtils.equals("otpEmailMobile",
	 * roleScreenAccessMappingVO.getScreenCode())){ return true; } } } return
	 * false; }
	 */

}
