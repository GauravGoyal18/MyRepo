package com.ipru.groups.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public final class GroupSecurityUtil {

	

	public static Properties constantsProp = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;

	public static Properties getConstantsProp() {
		FileInputStream fis = null;
		if (constantsProp == null) {
			constantsProp = new Properties();
			try {
				fis = new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
				constantsProp.load(fis);
			}
			catch (FileNotFoundException e) {
				FLogger.error("GROUPLogger", "GroupSecurityUtil", "getConstantsProp", "File Not found Error", e);
			}
			catch (IOException e) {
				FLogger.error("GROUPLogger", "GroupSecurityUtil", "getConstantsProp", "IO Exception occurred", e);
			}
			finally {
				try {
					if(fis!=null)
						fis.close();
				}
				catch (Exception e) {
					FLogger.error("GROUPLoggerError", "GroupSecurityUtil", "getConstantsProp",
							"Exception Ocurred in finally of getConstantsProp: "+e.getMessage());
					e.printStackTrace();
				} finally {
					fis=null;
				}
			}
		}
		return constantsProp;
	}


	public static Object getAttributeFromSession(RequestContext context, String attributeName) {
		Object attributeValue = null;
		if (context != null) {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			if (!StringUtils.isBlank(attributeName) && httpSession.getAttribute(attributeName) != null) {
				attributeValue = httpSession.getAttribute(attributeName);
			}
		}
		return attributeValue;
	}

	public static void setAttributeInSession(RequestContext context, String attributeName, Object attributeValue) {
		if (context != null) {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			if (StringUtils.isNotBlank(attributeName)) {
				httpSession.removeAttribute(attributeName);

				httpSession.setAttribute(attributeName, attributeValue);
			}
		}
	}

	public static void removeAttributeInSession(RequestContext context, String attributeName) {
		if (context != null) {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			if (StringUtils.isNotBlank(attributeName)) {
				httpSession.removeAttribute(attributeName);
			}
		}
	}

	public static Map<String, String> getAuthTypeMaster() {
		Map<String, String> authTypeMasters = new HashMap<String, String>(1);
		authTypeMasters.put("OtpOnEntry", "OTPONENTRY");
		authTypeMasters.put("OtpOnSubmit", "OTPONSUBMIT");
		return Collections.unmodifiableMap(authTypeMasters);
	}

	public static boolean isReadAccess(RequestContext context, String priveledge) {
		boolean isReadAccess = Boolean.FALSE;
		if (StringUtils.isNotBlank(priveledge)) {
			Map<String, String> accessMatrix = getUserAccessMatrix(context);
			if (accessMatrix != null && MapUtils.isNotEmpty(accessMatrix)) {
				String access = accessMatrix.get(priveledge);
				if (StringUtils.isNotBlank(access) && access.contains("R")) {
					isReadAccess = Boolean.TRUE;
				}
			}
		}
		return isReadAccess;
	}

	public static Map<String, String> getUserAccessMatrix(RequestContext context) {
		Map<String, String> accessMatrix = null;
		IPruUser userVO = (IPruUser) (getAttributeFromSession(context, SessionKeyConstants.USER_SESSION_KEY));
		if (userVO != null && userVO.getAccessMatrix() != null && MapUtils.isNotEmpty(userVO.getAccessMatrix())) {
			accessMatrix = userVO.getAccessMatrix();

		}
		return accessMatrix;
	}

	@SuppressWarnings("unchecked")
	public static boolean isAuthenticationRequired(RequestContext context) {
		// String
		// comingFromWidgetFlag=(String)((HttpServletRequest)context.getExternalContext().getNativeRequest()).getParameter("comingFromWidget");
		Map<String, String> authTypeMaster = getAuthTypeMaster();
		boolean isAuthenticationRequired = false;
		boolean isChecked = true;
		String flowId = null;

		flowId = (String) context.getFlowScope().get("widgetFlowId");
		if (StringUtils.isEmpty(flowId)) {
			flowId = context.getActiveFlow().getId();
		}

		String transitionId = (String) context.getFlowScope().get("otpType");
		String loggedInRole = null;
		String authType = null;
		String authTypeMasterKey = null;
		List<String> selectedAuthTypes = null;
		List<RoleScreenAccessMappingVO> authorizations = null;
		IPruUser userVO = (IPruUser) getAttributeFromSession(context, SessionKeyConstants.USER_SESSION_KEY);
		loggedInRole = userVO.getRoles();
		// authorizations=(List<RoleScreenAccessMappingVO>)
		// CsrSecurityUtil.getAttributeFromSession(context,
		// SessionKeyConstants.ROLE_SCR_ACCESS_MAP);
		authorizations = userVO.getLstRoleScreenAccessMapping();
		if (CollectionUtils.isNotEmpty(authorizations)) {
			for (RoleScreenAccessMappingVO roleScreenAccessMappingVO : authorizations) {
				if (StringUtils.equalsIgnoreCase(loggedInRole, roleScreenAccessMappingVO.getAccessGroup()) && StringUtils.equalsIgnoreCase(flowId, roleScreenAccessMappingVO.getScreenCode())) {
					authType = "OtpOnSubmit";
					// authType=roleScreenAccessMappingVO.getAuthorizationType();
					if (StringUtils.isNotBlank(authType)) {
						if (StringUtils.contains(authType, ",")) {
							selectedAuthTypes = Arrays.asList(authType.split(","));
						}
						else {
							selectedAuthTypes = new ArrayList<String>(1);
							selectedAuthTypes.add(authType);
						}

						if (StringUtils.isBlank(transitionId) || StringUtils.equalsIgnoreCase(transitionId, "isAuthorized")) {
							// On Entry condition
							authTypeMasterKey = "OtpOnEntry";
						}
						else {
							// POST condition provided method is called after
							// POST Transition before POST Request call
							authTypeMasterKey = "OtpOnSubmit";
						}

						for (String selectedAuthType : selectedAuthTypes) {
							if (StringUtils.isNotBlank(selectedAuthType) && StringUtils.equalsIgnoreCase(MapUtils.getString(authTypeMaster, authTypeMasterKey), selectedAuthType))
							// if (StringUtils.isNotBlank(selectedAuthType) &&
							// authTypeMaster.containsValue(selectedAuthType) )
							{
								// 4
								isChecked = false;
								isAuthenticationRequired = true;
								return isAuthenticationRequired;
								// break;
							}
						}
						if (isChecked) {
							isAuthenticationRequired = false;
							return isAuthenticationRequired;
						}
					}
					else {
						// 2
						// Customer case
						// UnsecCustc case
						// AuthType Column null
						isAuthenticationRequired = false;
						break;
					}

				}
				else {
					// 3
					// no screenCode UNKNOWN No Entry in DB
					isAuthenticationRequired = true;

				}
			}
		}
		else {

			isAuthenticationRequired = true;
		}
		// 1
		// list empty case: isAuthorized= false
		return isAuthenticationRequired;

	}

}