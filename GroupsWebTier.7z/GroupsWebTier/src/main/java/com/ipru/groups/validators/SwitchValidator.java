package com.ipru.groups.validators;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.RequestContext;
import com.ipru.groups.enums.RequestTypeEnum;
import com.ipru.groups.enums.SwitchTypeEnum;
import com.ipru.groups.grpswitch.bean.FundDetailsVO;
import com.ipru.groups.grpswitch.bean.SwitchDataLoaderVO;
import com.ipru.groups.grpswitch.bean.SwitchFundDetailsPO;
import com.ipru.groups.grpswitch.bean.SwitchTransactionPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.ProductSwitchAmountVO;
import com.tcs.logger.FLogger;

public class SwitchValidator {
	private final StringBuilder errorMessageBuilder = new StringBuilder(1);
	
	
	 public String validateSwitch(SwitchTransactionPO switchTransactionPO,RequestContext p_ObjContext) throws Exception
	 {
			FLogger.info("SwitchLogger", "SwitchValidator", "validateSwitch", "Validation start");
			
			SwitchDataLoaderVO switchDataLoaderVO = (SwitchDataLoaderVO) p_ObjContext.getFlowScope().get("switchDataLoaderVO"); 
			
			if(switchTransactionPO != null)
			{
				if(!validateSwitchType(switchTransactionPO.getSwitchType())){
					errorMessageBuilder.append("Please select Switch Type");
					return errorMessageBuilder.toString();
				}
				
				if(!ArrayUtils.isEmpty(switchTransactionPO.getSwitchFundDetails()))
				{
					List<SwitchFundDetailsPO> switchTransactionPOList = Arrays.asList(switchTransactionPO.getSwitchFundDetails());
					
					if(CollectionUtils.isNotEmpty(switchTransactionPOList))
					{
						if(switchTransactionPOList.size() > 10)
						{
							errorMessageBuilder.append("Max number of switch should not be greater than 10");
							return errorMessageBuilder.toString();
						}
					}
					
					//Check for duplicate from and to fund -Start
					Boolean checkDuplicateRecord;
					checkDuplicateRecord = hasDuplicateFromFundToFund(switchTransactionPOList);
					
					if(checkDuplicateRecord != null && checkDuplicateRecord){
						errorMessageBuilder.append("Duplicate records of From and To fund !!!");
						return errorMessageBuilder.toString();
					}
					//Check for duplicate from and to fund - End
					
					
					for(SwitchFundDetailsPO switchFundDetailsPO : switchTransactionPO.getSwitchFundDetails()) {
							
							
						/*	if(StringUtils.equalsIgnoreCase(switchFundDetailsPO.getSwitchType(),"Unit")){
								errorMessageBuilder.append("Please select valid To Fund");
								return errorMessageBuilder.toString();
							}
							else if(StringUtils.equalsIgnoreCase(switchFundDetailsPO.getSwitchType(),"Amount")){
								errorMessageBuilder.append("Please select valid To Fund");
								return errorMessageBuilder.toString();
							}*/
							
							if(!validateFundName(switchFundDetailsPO.getFromFundName(),switchDataLoaderVO.getActiveApplicableFromFundList())){
								errorMessageBuilder.append("Please select valid From Fund");
								return errorMessageBuilder.toString();
							}
							
							if(!validateFundName(switchFundDetailsPO.getToFundCode(),switchDataLoaderVO.getActiveApplicableToFundCodeList())){
								errorMessageBuilder.append("Please select valid To Fund");
								return errorMessageBuilder.toString();
							}
							
							if(!validateNAV(switchFundDetailsPO.getFromNAV())){
								errorMessageBuilder.append("From NAV cannot be empty");
								return errorMessageBuilder.toString();
							}
							
							if(StringUtils.isBlank(switchFundDetailsPO.getFromAmount())){
								errorMessageBuilder.append("Amount cannot be empty");
								return errorMessageBuilder.toString();
							}
							
							if(StringUtils.isBlank(switchFundDetailsPO.getFromUnit())){
								errorMessageBuilder.append("Unit cannot be empty");
								return errorMessageBuilder.toString();
							}
							
							if(StringUtils.isBlank(switchFundDetailsPO.getUnitsOrAmount())){
								errorMessageBuilder.append("Amount Or Unit cannot be null");
								return errorMessageBuilder.toString();
							}
							
							if(StringUtils.equalsIgnoreCase(switchTransactionPO.getSwitchType(),"Amount")){
								if(noOfDigitsPostDecimal(switchFundDetailsPO.getUnitsOrAmount()) > 0){
									errorMessageBuilder.append("No digits post decimal point when switch type is Amount");
									return errorMessageBuilder.toString();}
							}
							
							if(StringUtils.equalsIgnoreCase(switchTransactionPO.getSwitchType(),"Units")){
								if(noOfDigitsPostDecimal(switchFundDetailsPO.getUnitsOrAmount()) >= 4){
									errorMessageBuilder.append("Max 3 digits post decimal point when switch type is Unit");
									return errorMessageBuilder.toString();
								}
							}
							
							if(StringUtils.equalsIgnoreCase(switchFundDetailsPO.getFromFundCode(),switchFundDetailsPO.getToFundCode()))
							{
								errorMessageBuilder.append("From and To Fund cannot be same");
								return errorMessageBuilder.toString();
							}
							
							if(!validateFundCodeFundName(switchFundDetailsPO.getFromFundCode(),switchFundDetailsPO.getFromFundName(),switchDataLoaderVO.getFundMasterList()))
							{
								errorMessageBuilder.append("From Fund Code and From Fund Name does not match");
								return errorMessageBuilder.toString();
							}
							
							
							if(!validateFundCodeFundName(switchFundDetailsPO.getToFundCode(),switchFundDetailsPO.getToFundName(),switchDataLoaderVO.getFundMasterList()))
							{
								errorMessageBuilder.append("To Fund Code and To Fund Name does not match");
								return errorMessageBuilder.toString();
							}
							
							if(checkNonCGToCG(switchFundDetailsPO.getFromFundCode(),switchFundDetailsPO.getToFundCode(),switchDataLoaderVO.getFundMasterList()))
							{
								errorMessageBuilder.append("Cannot switch from Non CG Fund to CG Fund");
								return errorMessageBuilder.toString();
							}
					}
				}
				else
				{

					errorMessageBuilder.append("Please make fund allocation");
					return errorMessageBuilder.toString();
				
				}
				
		
				
				//Total Fund Value Product Validation - Start
				if(StringUtils.isBlank(switchTransactionPO.getTotalFundValue())){
					
					if(Long.parseLong(switchTransactionPO.getTotalFundValue()) <= 0)
					{
						errorMessageBuilder.append("Total Fund Value cannot be Zero");
						return errorMessageBuilder.toString();
					}
				}
				//Total Fund Value Product Validation - End
				
				//Total Switch Amount Validation - Start
				if(StringUtils.isBlank(switchTransactionPO.getTotalFundSwitchValue())){
					
					if(Long.parseLong(switchTransactionPO.getTotalFundSwitchValue()) <= 0)
					{
						errorMessageBuilder.append("Total Fund Switch Value cannot be Zero");
						return errorMessageBuilder.toString();
					}
				}
				//Total Switch Amount Validation - End
				
				/****** Total Switch Amount in range - Start *******/
				
				
				if(switchDataLoaderVO != null)
				{
					ProductSwitchAmountVO productSwitchAmountVO = switchDataLoaderVO.getProductSwitchAmount();
					
					if(productSwitchAmountVO != null){
						Double minSwitchAmount = Double.parseDouble(productSwitchAmountVO.getMinSwitchAmount());
						Double maxSwitchAmount = Double.parseDouble(productSwitchAmountVO.getMaxSwitchAmount());
						Double totalFundValue =  Double.parseDouble(switchTransactionPO.getTotalFundSwitchValue());
						
						if(totalFundValue < minSwitchAmount || totalFundValue > maxSwitchAmount)
						{
							errorMessageBuilder.append("Total Switch Amount must be between "+minSwitchAmount + " and "+ maxSwitchAmount);
							return errorMessageBuilder.toString();
						}
					}
					
				}
				/****** Total Switch Amount in range - End *******/
				/*String minMaxSwitchAmount = .getMinSwitchAmount();
				
				//convert json to object
				Gson gson = new Gson();
				ProductSwitchAmountVO productSwitchAmountVO;
				
				if(StringUtils.isNotBlank(minMaxSwitchAmount))
				{
					productSwitchAmountVO = gson.fromJson(minMaxSwitchAmount, ProductSwitchAmountVO.class);
					
					if(productSwitchAmountVO != null)
					{
						Double minSwitchAmount = Double.parseDouble(productSwitchAmountVO.getMinSwitchAmount());
						Double maxSwitchAmount = Double.parseDouble(productSwitchAmountVO.getMaxSwitchAmount());
						Double totalFundValue =  Double.parseDouble(switchTransactionPO.getTotalFundValue());
						
						
						if(totalFundValue < minSwitchAmount || totalFundValue > maxSwitchAmount)
						{
							errorMessageBuilder.append("Total Switch Amount must be between "+minSwitchAmount + " and "+ maxSwitchAmount);
							return errorMessageBuilder.toString();
						}
					}
				}*/
				/****** Total Switch Amount in range - End *******/
				
				/****** Terms and Condition - Start *******/
				/*if(StringUtils.equalsIgnoreCase(switchTransactionPO.getIsAgreedCheck(), "false")){
					
					errorMessageBuilder.append("Please read and accept the terms and conditions.");
					return errorMessageBuilder.toString();
				}*/
				/****** Terms and Condition - End *******/
				
			
			}else
			{
				errorMessageBuilder.append("Transaction Details cannot be empty");
				return errorMessageBuilder.toString();
			}
			return errorMessageBuilder.toString();

	 }
	 
	 private boolean validateFundCodeFundName(String fromCode,String fromName, List<FundMasterVO> fundMasterList) {
		
		for(FundMasterVO fundMasterVO :fundMasterList)
		{
			if(StringUtils.equalsIgnoreCase(fundMasterVO.getFundCode(),fromCode) && StringUtils.equalsIgnoreCase(fundMasterVO.getFundName(),fromName))
			{
				return true;
			}
		}
		return false;
	}

	public boolean validateSwitchType(String switchType)
	{
		FLogger.info("SwitchLogger", "SwitchValidator", "validateSwitchType", "validateSwitchType method start");

		boolean result=false;
		if(switchType!=null && !StringUtils.isEmpty(switchType))
		{
			
			if (CommonValidationUtil.ValidateRequired(switchType) && CommonValidationUtil.ValidateAlpha(switchType) && CommonValidationUtil.ValidateLengths(switchType, 1, 6))
			{
				
				for(SwitchTypeEnum switchTypeEnum:SwitchTypeEnum.values())
				{
					if(switchTypeEnum.toString().equalsIgnoreCase(switchType))
					{
						//if(switchType.trim().equalsIgnoreCase(switchTypeRequest.trim()))
							result=true;
					}	
				}
			}	
				
			
		}
		
		FLogger.info("SwitchLogger", "SwitchValidator", "validateSwitchType", "validateSwitchType method end");

		return result;
	}
	 
	 private boolean checkNonCGToCG(String fromFundCode, String toFundCode, List<FundMasterVO> fundMasterList) {
		 String isCGFromFund = null;
		 String isCGToFund = null;
		 
		for(FundMasterVO fundMasterVO :fundMasterList)
		{
			if(StringUtils.equalsIgnoreCase(fundMasterVO.getFundCode(),fromFundCode))
			{
				 isCGFromFund = fundMasterVO.getIsCapital();
			}
			
			else if(StringUtils.equalsIgnoreCase(fundMasterVO.getFundCode(),toFundCode))
			{
				 isCGToFund = fundMasterVO.getIsCapital();
			}
			
			
			if(StringUtils.equalsIgnoreCase(isCGFromFund,"N") && StringUtils.equalsIgnoreCase(isCGToFund,"Y"))
			{
				return true;
			}	
		}
		
		return false;
		
	}



	/*
	  * Validate Request Type
	  * 
	  */
	public boolean checkRequestTypeEnum(String requestType) {
		for (RequestTypeEnum requestTypeEnum : RequestTypeEnum.values()) {
			if (requestTypeEnum.name().equals(requestType)) {
				return true;
			}
		}
		return false;
	}
	
	/*
	 * returns
	 * true - duplicate records found
	 * false - otherwise
	 */
	
	public static Boolean hasDuplicateFromFundToFund(List<SwitchFundDetailsPO> all) {
	    Set<SwitchFundDetailsPO> set = new HashSet<SwitchFundDetailsPO>();
	    // Set#add returns false if the set does not change, which
	    // indicates that a duplicate element has been added.
	    for (SwitchFundDetailsPO one: all) 
	    	if (!set.add(one)) 
	    		return true;
	    return false;
	}
	
	public boolean validateFundName(String fundName,List<String> fundList)
	{
		
		FLogger.info("SwitchLogger", "SwitchValidator", "validateFundName", "validateFundName Method Start");

		boolean result=false;
		if(fundName!=null && !StringUtils.isEmpty(fundName))
		{
			
			if (CommonValidationUtil.ValidateRequired(fundName)
					&&CommonValidationUtil.ValidateLengths(fundName, 1, 200))
			{
			
				if(fundList.contains(fundName.trim()))
					result=true;
			}	
				
			
		}
		FLogger.info("SwitchLogger", "SwitchValidator", "validateFundName", "validateFundName status "+result);

		
		FLogger.info("SwitchLogger", "SwitchValidator", "validateFundName", "validateFundName Method end");

		return result;
	}
	
	public boolean validateNAV(String nav)
	{
		
		
		FLogger.info("SwitchLogger", "SwitchValidator", "validateNAV", "validateNAV method start");

		boolean result=false;
		if(nav!=null && !StringUtils.isEmpty(nav))
		{
			
			if (CommonValidationUtil.ValidateRequired(nav) && CommonValidationUtil.ValidateLengths(nav, 1, 200))//validation for numeric is remaining
			{
					result=true;
			}	
				
			
		}

		FLogger.info("SwitchLogger", "SwitchValidator", "validateNAV", "validateNAV status"+result);

		FLogger.info("SwitchLogger", "SwitchValidator", "validateNAV", "validateNAV method end");

		return result;
	}
	
	public int noOfDigitsPostDecimal(String unitsOrAmountValue)
	{
		String noOfDigitsPostDecimalString;
		int noOfDigitsPostDecimal = 0;
		String noOfDigitsPostDecimalArray[] = unitsOrAmountValue.split("\\.");
		
		if(noOfDigitsPostDecimalArray.length > 1)
		{
			noOfDigitsPostDecimalString = noOfDigitsPostDecimalArray[1];
			noOfDigitsPostDecimal = noOfDigitsPostDecimalString.length();
		}
		
		return noOfDigitsPostDecimal;
	}
}


