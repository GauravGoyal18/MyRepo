package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ipru.IPruException;
import com.ipru.groups.grpswitch.bean.FundDetailsPO;
import com.ipru.groups.grpswitch.bean.FundDetailsVO;
import com.ipru.groups.po.StofLoadDataPO;
import com.ipru.groups.po.StofSubmitPo;
import com.ipru.groups.po.StofSubmitTransactionPO;
import com.ipru.groups.service.WebserviceInvoke;
import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.groups.utilities.StofGetPojoData;
import com.ipru.groups.validators.StofValidator;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.PolicyValidMasterVO;
import com.ipru.groups.vo.ProductFundMasterDataVO;
import com.ipru.groups.vo.ProductFundMasterVO;
import com.ipru.groups.vo.ProductMasterVO;
import com.ipru.groups.vo.ProductSwitchAmountVO;
import com.ipru.groups.vo.StofLoadDataVO;
import com.ipru.groups.vo.StofSubmitTransactionVO;
import com.ipru.groups.vo.StofSubmitVo;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class StofHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static double totalToBeSubmit = 0;

	public Event getBizRequestforStofLoadDataHandler(RequestContext p_ObjContext) throws Exception {

		FLogger.info("StofLogger", "StofHandler", "getBizRequestforStofLoadDataHandler", "getBizRequestforStofLoadDataHandler Method Start");

		try {

			BizRequest obj_bizReq = new BizRequest();
			String policyNumber = null;
			String clientId = null;
			String role = null;
			IPruUser userVo = null;
			String roleType = null;
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");
				if (userVo != null) {
					policyNumber = userVo.getPolicyNo();
					role = userVo.getRoles();
					clientId = userVo.getClientId();
					// clientId="Q2777";
					roleType = userVo.getRoleType();
					Object paramArray[] = new Object[1];

					List<PolicyValidMasterVO> policyValidMasterList = null;
					boolean isValidPolicy = false;
					policyValidMasterList = (List<PolicyValidMasterVO>) p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.POLICY_VALID_MASTER_LIST);

					if (policyValidMasterList != null) {
						for (PolicyValidMasterVO policyValid : policyValidMasterList) {

							if (StringUtils.equalsIgnoreCase(policyValid.getPolicyNo(), policyNumber)) {
								isValidPolicy = true;
								break;
							}

						}
					}

					if (!isValidPolicy) {
						// ////System.out.println("Not an Valid Policy");
						FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "Switch not applicable for this Policy: " + policyNumber);
						throw new IPruException("Error", "GRPSTF02", "Stof is not applicable for Policy Number " + policyNumber);
					}

					ProductFundMasterDataVO productFundMasterData = new ProductFundMasterDataVO();

					List<ProductMasterVO> productMasterList = (List<ProductMasterVO>) p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.PRODUCT_MASTER_LIST);

					// fetch fund master from context
					List<FundMasterVO> fundMasterList = (List<FundMasterVO>) p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.FUND_MASTER_LIST);

					// fetch product fund master from context/
					List<ProductFundMasterVO> productFundMasterList = (List<ProductFundMasterVO>) p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.PRODUCT_FUND_MASTER_LIST);

					// fetch product fund master from context
					List<ProductSwitchAmountVO> productSwitchAmountMasterList = (List<ProductSwitchAmountVO>) p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.PRODUCT_SWITCH_AMOUNT_MASTER_LIST);

					if (fundMasterList != null && productFundMasterList != null && productMasterList != null && productSwitchAmountMasterList != null) {
						productFundMasterData.setFundMasterList(fundMasterList);
						productFundMasterData.setProductFundMasterList(productFundMasterList);
						productFundMasterData.setProductMasterList(productMasterList);
						productFundMasterData.setProductSwitchAmountMasterList(productSwitchAmountMasterList);
						productFundMasterData.setClientId(clientId);
						productFundMasterData.setPolicyNumber(policyNumber);
						productFundMasterData.setRole(role);
						productFundMasterData.setRoleType(roleType);
						paramArray[0] = productFundMasterData;
						p_ObjContext.getFlowScope().put("fundMasterList", fundMasterList);

						obj_bizReq.addbusinessObjects("service-obj1", paramArray);
					}
					else {
						FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofLoadDataHandler", "getBizRequestforStofLoadDataHandler some exception occure Found Null Data");
						throw new IPruException("Error", "GRPSTF02", "Found Null Data");
					}
				}

				else {
					FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofLoadDataHandler", "getBizRequestforStofLoadDataHandler some exception occure Found Null Session");
					throw new IPruException("Error", "GRPSTF02", "Found Null Session");

				}
			}

			else {
				FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofLoadDataHandler", "getBizRequestforStofLoadDataHandler some exception occure Found Null Session");
				throw new IPruException("Error", "GRPSTF02", "Found Null Session");

			}

			p_ObjContext.getFlowScope().put("stofLoadDataBizReq", obj_bizReq);

		}

		catch (Exception e) {
			FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofLoadDataHandler", "getBizRequestforStofLoadDataHandler some exception occure " , e);
			throwINeoFlowException(e, "GRPSTF02", p_ObjContext);

		}
		FLogger.info("StofLogger", "StofHandler", "getBizRequestforStofLoadDataHandler", "getBizRequestforStofLoadDataHandler method end");
		return success();

	}

	@MethodPost
	public Event getBizResponseforStofLoadDataHandler(RequestContext context) throws Exception {
		try {
			FLogger.info("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "getBizResponseforStofLoadDataHandler method start");
			BizResponse bizRes = new BizResponse();
			Gson gson = new Gson();
			String responseCheck = "";

			bizRes = (BizResponse) context.getFlowScope().get("bizResForLoadStofData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {

					FLogger.error("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "getBizResponseforStofLoadDataHandler found null response");
					throw new IPruException("Error", "GRPSTF02", "Response is null");
				}
				else {

					FLogger.info("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "Fetching load data");
					StofLoadDataVO stofLoadDataVO = (StofLoadDataVO) bizRes.getTransferObjects().get("response1");
					StofLoadDataPO stofLoadDataPO = null;

					if (stofLoadDataVO != null) {

						// put fundNavList and Fundcodes in flow so that it can
						// be use while 2nd webservice
						context.getFlowScope().put("fundNAVList", stofLoadDataVO.getFundDetailsVOList());
						context.getFlowScope().put("fundCodes", stofLoadDataVO.getFundCodes());
						// convert to po from vo
						stofLoadDataPO = dozerBeanMapper.map(stofLoadDataVO, StofLoadDataPO.class);
						if (stofLoadDataPO != null) {
							FLogger.info("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "Putting data in flowscope");
							// put data in flowscope
							context.getFlowScope().put("loadStofData", stofLoadDataPO);
							String resultJson = gson.toJson(stofLoadDataPO);
							context.getFlowScope().put("Response", resultJson);
						}
						else {
							FLogger.error("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "Error occured while converting vo to po");
							throw new IPruException("Error", "GRPSTF02", "Response is null");
						}
					}
					else {
						FLogger.error("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "Response is null");
						throw new IPruException("Error", "GRPSTF02", "Response is null");

					}

				}// else

			}// bizRes

		}// try

		catch (Exception e) {
			FLogger.error("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "getBizResponseforStofLoadDataHandler exception occure" , e);
			throwINeoFlowException(e, "GRPSTF02", context);
		}

		FLogger.info("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "getBizResponseforStofLoadDataHandler method end");
		return success();
	}

	public Event getBizRequestforStofSubmitDataHandler(RequestContext p_ObjContext) throws Exception {

		FLogger.info("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "getBizRequestforStofSubmitDataHandler Method Start");

		try {

			BizRequest obj_bizReq = new BizRequest();
			String policyNumber = null;
			String clientId = null;
			String role = null;
			IPruUser userVo = null;
			totalToBeSubmit = 0;
			StofGetPojoData stofGetPojoData = new StofGetPojoData();
			/*
			 * List<NSEHolidaysVO> nseHolidaysList = new
			 * ArrayList<NSEHolidaysVO>(); //nseHolidaysList =
			 * stofGetPojoData.mockNSEHolidays();
			 * nseHolidaysList=NSEHolidayDetailsClient.fetchNSEHoliday();
			 * if(nseHolidaysList!=null && nseHolidaysList.size()>0) { Date
			 * switchExecutionDate =
			 * stofGetPojoData.getSwitchDate(p_ObjContext,nseHolidaysList);
			 * if(switchExecutionDate!=null) {
			 */

			FunctionalityMasterVO functionality = getFunctionality(p_ObjContext);
			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			Gson gson = new Gson();
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");
				if (userVo != null) {
					policyNumber = userVo.getPolicyNo();
					role = userVo.getRoles();
					clientId = userVo.getClientId();
					// clientId="Q2777";
					Object paramArray[] = new Object[1];

					/*
					 * Type t = new TypeToken<List<StofSubmitPo>>() {
					 * }.getType();
					 */

					List<FundMasterVO> fundMasterList = (List<FundMasterVO>) p_ObjContext.getFlowScope().get("fundMasterList");

					if (fundMasterList != null) {
						StofSubmitTransactionPO stofSubmitTransactionPO = null;
						Set<StofSubmitPo> stofSubmitPoList = null;

						// Convert json to object
						stofSubmitTransactionPO = gson.fromJson(request.getReader(), StofSubmitTransactionPO.class);

						if (stofSubmitTransactionPO != null) {

							stofSubmitPoList = stofSubmitTransactionPO.getStof();

							if (CollectionUtils.isNotEmpty(stofSubmitPoList)) {

								// ////System.out.println("stofSubmitPostofSubmitPostofSubmitPo"+stofSubmitPoList.toString());
								// call validator

								StofValidator stofValidator = new StofValidator();
								String validation = stofValidator.validateStofDetails(stofSubmitTransactionPO, p_ObjContext);

								if (StringUtils.isNotBlank(validation)) {
									FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "validation fails" + validation);
									throwINeoFlowException(new ServiceException("GRPSTF"), "GRPSTF", p_ObjContext);

								}

								StofSubmitTransactionVO stofSubmitTransactionVO = dozerBeanMapper.map(stofSubmitTransactionPO, StofSubmitTransactionVO.class);
								stofSubmitTransactionVO.setFunctionality(functionality);
								StofLoadDataPO stofLoadDataPO = (StofLoadDataPO) p_ObjContext.getFlowScope().get("loadStofData");
								stofSubmitTransactionVO.setProductCode(stofLoadDataPO.getProductCode());
								if (stofSubmitTransactionVO != null) {
									stofSubmitTransactionVO = stofGetPojoData.getStofGetPojoData(stofSubmitTransactionVO, fundMasterList, p_ObjContext);

									/*for (StofSubmitVo stofSubmitVo : stofSubmitTransactionVO.getStof()) {
										stofSubmitVo.setStofSubmitTransactionVO(stofSubmitTransactionVO);
									}*/

									paramArray[0] = stofSubmitTransactionVO;

									obj_bizReq.addbusinessObjects("service-obj1", paramArray);

								}
								else {
									FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "Found null data while converting po to vo");
									throw new IPruException("Error", "GRPSTF", "Found Null data");
								}

							}
							else {
								FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "Found null stof data from json");
								throw new IPruException("Error", "GRPSTF", "Found Null data");
							}

						}
						else {
							FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "Found null data from json");
							throw new IPruException("Error", "GRPSTF", "Found Null data");
						}

					}
					else {
						FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "Found null fundMasterList");
						throw new IPruException("Error", "GRPSTF", "Found Null data");
					}

				}
				else {
					FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "Found null session");
					throw new IPruException("Error", "GRPSTF", "Found Null session");
				}

			}

			else {
				FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "Found null session");
				throw new IPruException("Error", "GRPSTF", "Found Null session");
			}

			p_ObjContext.getFlowScope().put("stofSubmitDataBizReq", obj_bizReq);
			/*
			 * }//date else { FLogger.error("StofLogger", "StofHandler",
			 * "getBizRequestforStofSubmitDataHandler",
			 * "reqExecution date is null"); throw new IPruException("Error",
			 * "GRPSTF", "Found Null Data"); } }//nsc holidays else {
			 * FLogger.error("StofLogger", "StofHandler",
			 * "getBizRequestforStofSubmitDataHandler", "nsc holidays is null");
			 * throw new IPruException("Error", "GRPSTF", "Found Null Data"); }
			 */

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "getBizRequestforStofSubmitDataHandler some exception occure " , e);
			throwINeoFlowException(e, "GRPSTF", p_ObjContext);

		}

		FLogger.info("StofLogger", "StofHandler", "getBizRequestforStofSubmitDataHandler", "getBizRequestforStofSubmitDataHandler method end");
		return success();

	}

	@MethodPost
	public Event getBizResponseforStofSubmitDataHandler(RequestContext context) throws Exception {
		try {
			FLogger.info("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "getBizResponseforStofLoadDataHandler method start");
			BizResponse bizRes = new BizResponse();
			Gson gson = new Gson();
			String responseCheck = "";

			bizRes = (BizResponse) context.getFlowScope().get("bizResForSubmitStofData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {

					FLogger.error("StofLogger", "StofHandler", "getBizResponseforStofSubmitDataHandler", "some error occured");

					throw new IPruException("Error", "GRPSTF", "some error occured");
				}
				else {

					/*
					 * StofLoadDataVO stofLoadDataVo = new StofLoadDataVO();
					 * stofLoadDataVo = (StofLoadDataVO)
					 * bizRes.getTransferObjects().get("response1");
					 */

					StofSubmitTransactionVO stofSubmitTransactionVO = (StofSubmitTransactionVO) bizRes.getTransferObjects().get("response1");
					if (stofSubmitTransactionVO == null) {
						FLogger.error("StofLogger", "StofHandler", "getBizResponseforStofSubmitDataHandler", "some error occured");
						throw new IPruException("Error", "GRPSTF", "some error occured");
					}

					StofSubmitTransactionPO stofSubmitTransactionPO = dozerBeanMapper.map(stofSubmitTransactionVO, StofSubmitTransactionPO.class);
					// DateFormat formatter = new
					// SimpleDateFormat("dd/MMM/yyyy");//Mar 22, 2017 12:00:00
					// AM
					// ////System.out.println("formatter.format(stofSubmitTransactionPO.getReqExecutionDate()"+formatter.format(stofSubmitTransactionPO.getReqExecutionDate()));
					// String
					// formatedDate=formatter.format(stofSubmitTransactionPO.getReqExecutionDate());
					// Date reqExeDate=formatter.parse(formatedDate);
					// ////System.out.println("reqExeDatereqExeDatereqExeDatereqExeDatereqExeDatereqExeDatereqExeDatereqExeDate"+reqExeDate);
					// stofSubmitTransactionPO.setReqExecutionDate(reqExeDate);
					String gsonString = gson.toJson(stofSubmitTransactionPO);
					context.getFlowScope().put("Response", gsonString);

				}

			}// bizRes

		}// try

		catch (Exception e) {
			// e.printStackTrace();
			FLogger.error("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "getBizResponseforStofLoadDataHandler exception occure");
			throwINeoFlowException(e, "GRPNOUP02", context);
		}

		FLogger.info("StofLogger", "StofHandler", "getBizResponseforStofLoadDataHandler", "getBizResponseforStofLoadDataHandler method end");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

	public Event fetchReturnsInception(RequestContext context) throws Exception {
		FLogger.info("StofLogger", "StofHandler", "fetchReturnsInception", "fetchReturnsInception method start");

		List<FundDetailsVO> fundNAVList = (List<FundDetailsVO>) context.getFlowScope().get("fundNAVList");
		String fundCodes = (String) context.getFlowScope().get("fundCodes");
		try {
			String fundPerformanceString = WebserviceInvoke.getInstance().fetchFundDetails(fundCodes,"StofLogger");
			if (fundPerformanceString != null && !fundPerformanceString.equalsIgnoreCase("")) {
				Gson gsonJSON = new Gson();
				Map<String, FundDetailsVO> returnInceptionVOMap = gsonJSON.fromJson(fundPerformanceString, new TypeToken<Map<String, FundDetailsVO>>() {
				}.getType());

				if (!returnInceptionVOMap.isEmpty()) {

					FundDetailsVO returnInception;

					for (FundDetailsVO fundNAV : fundNAVList) {

						if (fundNAV != null) {
							for (Map.Entry<String, FundDetailsVO> entry : returnInceptionVOMap.entrySet()) {

								// ////System.out.println("Key : " + entry.getKey()
								// + " Value : " + entry.getValue());

								String key = entry.getKey();
								returnInception = entry.getValue();
								if (returnInception != null) {

									if (StringUtils.equalsIgnoreCase(returnInception.getFundName().trim(), fundNAV.getFundDesc().trim())) {
										fundNAV.setAssetsInvested(returnInception.getAssetsInvested());
										fundNAV.setAumDebtCategory(returnInception.getAumDebtCategory());
										fundNAV.setAumEquityCategory(returnInception.getAumEquityCategory());
										fundNAV.setAumMoneyMarketCashCategory(returnInception.getAumMoneyMarketCashCategory());
										fundNAV.setBenchMark(returnInception.getBenchMark());
										fundNAV.setBenchmarkFifthYear(returnInception.getBenchmarkFifthYear());
										fundNAV.setBenchmarkFirstYear(returnInception.getBenchmarkFirstYear());
										fundNAV.setBenchmarkInception(returnInception.getBenchmarkInception());
										fundNAV.setBenchmarkThirdYear(returnInception.getBenchmarkThirdYear());
										fundNAV.setFifthYearReturns(returnInception.getFifthYearReturns());
										fundNAV.setFirstYearReturns(returnInception.getFirstYearReturns());
										fundNAV.setFundName(returnInception.getFundName());
										fundNAV.setFundObjective(returnInception.getFundObjective());
										fundNAV.setReturnsSinceInception(returnInception.getReturnsSinceInception());
										fundNAV.setInceptionDate(returnInception.getInceptionDate());
										fundNAV.setPortfolioByMaturityBalAvg(returnInception.getPortfolioByMaturityBalAvg());
										fundNAV.setPortfolioByMaturityDebtAvg(returnInception.getPortfolioByMaturityDebtAvg());
										fundNAV.setThirdYearReturns(returnInception.getThirdYearReturns());

										/*
										 * //System.out.println(fundNAV.getNavValue
										 * ());
										 * //System.out.println(fundNAV.getFundName
										 * ()); //System.out.println(fundNAV.
										 * getReturnsSinceInception());
										 * System.out
										 * .println(fundNAV.getFirstYearReturns
										 * ());
										 */

										break;
									}

								}
								else {

									FLogger.error("StofLogger", "StofHandler", "fetchReturnsInception", "Found null returnInception");
									throw new IPruException("Error", "GRPSTF02", "Response is null");

								}
							}

							List<FundDetailsPO> fundDetailsPOList = new ArrayList<FundDetailsPO>();

							for (FundDetailsVO fundDetailsVO : fundNAVList) {
								FundDetailsPO fundDetailsPO = dozerBeanMapper.map(fundDetailsVO, FundDetailsPO.class);
								fundDetailsPOList.add(fundDetailsPO);

							}

							if (fundNAVList != null) {

								StofLoadDataPO stofLoadDataPO = new StofLoadDataPO();
								stofLoadDataPO.setFundDetailsVOList(fundDetailsPOList);
								String fundDetailJsonString = gsonJSON.toJson(stofLoadDataPO, StofLoadDataPO.class);
								context.getFlowScope().put("Response", fundDetailJsonString);
							}
							else {

								FLogger.error("StofLogger", "StofHandler", "fetchReturnsInception", "Found null fundNAV");
								throw new IPruException("Error", "GRPSTF02", "found null data");

							}

						}
						else {

							FLogger.error("StofLogger", "StofHandler", "fetchReturnsInception", "Found null fundNAV");
							throw new IPruException("Error", "GRPSTF02", "found null data");

						}
					}
				}
				else {

					FLogger.error("StofLogger", "StofHandler", "fetchReturnsInception", "Found null returnInceptionVOMap");
					throw new IPruException("Error", "GRPSTF02", "found null data");
				}
			}
			else {

				FLogger.error("StofLogger", "StofHandler", "fetchReturnsInception", "Found null fundPerformanceString");
				throw new IPruException("Error", "GRPSTF02", "found null data");
			}
		}
		catch (Exception e) {
			FLogger.error("StofLogger", "StofHandler", "fetchReturnsInception", "fetchReturnsInception exception occure" , e);
			throwINeoFlowException(e, "GRPSTF02", context);
			// e.printStackTrace();
		}
		// fundNAVList
		FLogger.info("StofLogger", "StofHandler", "fetchReturnsInception", "fetchReturnsInception method end");

		return success();
	}

}
