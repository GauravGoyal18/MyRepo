package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.generic.po.ResultJsonPO;
import com.ipru.groups.po.ClaimBeneficiaryPO;
import com.ipru.groups.po.ClaimsDropDownData;
import com.ipru.groups.po.ClaimsListPO;
import com.ipru.groups.po.ClaimsLoadRequestDetailsPO;
import com.ipru.groups.po.ClaimsLoadRequestPO;
import com.ipru.groups.po.ClaimsRequestPO;
import com.ipru.groups.po.ClaimsSubmitPO;
import com.ipru.groups.po.FieldAccessMappingPO;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.profile.bean.ProfilePOCPO;
import com.ipru.groups.utilities.ClaimsUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.validators.ClaimsValidator;
import com.ipru.groups.vo.ClaimsBeneficiaryVO;
import com.ipru.groups.vo.ClaimsLoadRequestDetailsVO;
import com.ipru.groups.vo.ClaimsLoadRequestVO;
import com.ipru.groups.vo.ClaimsRequestTransactionVO;
import com.ipru.groups.vo.ClaimsRequestVO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.groups.vo.UploadFileVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ClaimsHandler extends IneoBaseHandler {

	private static final long serialVersionUID = 1L;

	@MethodPost
	public Event getRequestClaimsDetailsAccessMatrix(RequestContext context) throws Exception {// Get
																								// FieldAccess
																								// Mapping

		FLogger.info("ClaimsLogger", "ClaimsHandler", "getRequestClaimsDetailsAccessMatrix", "getRequestClaimsDetailsAccessMatrix Method Start ");

		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;

			fieldAccessMappingVoList = getFieldAccessMappingList(context);
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String screenName = null;
			List<RoleScreenAccessMappingVO> accessMappingList;

			if (httpSession != null) {
				screenName = (String) context.getFlowScope().get("screenName");

				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null && screenName != null && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) { // userVO
																													// null
																													// check

					policyNo = userVo.getPolicyNo();

					FLogger.error("ClaimsLogger", "ClaimsHandler", "getRequestClaimsDetailsAccessMatrix", "When page load Policy No in session : " + policyNo);
					role = userVo.getRoles();

					FLogger.error("ClaimsLogger", "ClaimsHandler", "getRequestClaimsDetailsAccessMatrix", "When page load role in session : " + role);
					accessMappingList = userVo.getLstRoleScreenAccessMapping();

					ClaimsLoadRequestPO claimsLoadRequestPO = new ClaimsLoadRequestPO();
					claimsLoadRequestPO.setPolicyNo(policyNo);
					claimsLoadRequestPO.setRole(role);
					claimsLoadRequestPO.setScreenName(screenName);
					ClaimsLoadRequestVO claimsLoadRequestVO = null;
					if (claimsLoadRequestPO != null) {
						claimsLoadRequestVO = dozerBeanMapper.map(claimsLoadRequestPO, ClaimsLoadRequestVO.class);
					}
					else {
						FLogger.error("ClaimsLogger", "ClaimsHandler", "getRequestClaimsDetailsAccessMatrix", "claimsLoadRequestPO  is null");
						throw new IPruException("Error", "GRPCL03", "No Data Found");
					}

					if (claimsLoadRequestVO != null) {
						if (CollectionUtils.isNotEmpty(accessMappingList) && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {
							claimsLoadRequestVO.setAccessMappingList(accessMappingList);
							claimsLoadRequestVO.setFieldAccessMappingList(fieldAccessMappingVoList);
							Object[] paramArray = new Object[1];
							paramArray[0] = claimsLoadRequestVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("claimsBizReq", obj_bizReq);
						}
						else {
							FLogger.error("ClaimsLogger", "ClaimsHandler", "getRequestClaimsDetailsAccessMatrix", "accessMappingList and  fieldAccessMappingVoList is null");

							throw new IPruException("Error", "GRPCL03", "No Data Found");
						}

					}
					else {
						FLogger.error("ClaimsLogger", "ClaimsHandler", "getRequestClaimsDetailsAccessMatrix", "UserVo  is null");

						throw new IPruException("Error", "GRPCL03", "No Data Found");
					}
				}
				else {
					FLogger.error("ClaimsLogger", "ClaimsHandler", "getRequestClaimsDetailsAccessMatrix", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");

					throw new IPruException("Error", "GRPCL03", "Session Invalid");
				}
			}
			else {
				FLogger.error("ClaimsLogger", "ClaimsHandler", "getRequestClaimsDetailsAccessMatrix", "session is null");

				throw new IPruException("Error", "GRPCL03", "No Data Found");
			}

		}
		catch (Exception e) {
			FLogger.error("ClaimsLogger", "ClaimsHandler", "getRequestClaimsDetailsAccessMatrix", "context should not be null" + e);
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("ClaimsLogger", "ClaimsHandler", "getRequestClaimsDetailsAccessMatrix", "getRequestClaimsDetailsAccessMatrix Method End ");

		return success();
	}

	@MethodPost
	public Event getResponseClaimsDetailsAccessMatrix(RequestContext context) throws Exception {

		FLogger.info("ClaimsLogger", "ClaimsHandler", "getResponseClaimsDetailsAccessMatrix", "getResponseClaimsDetailsAccessMatrix Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ClaimsLoadRequestDetailsVO claimsLoadRequestDetailsVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {
			bizRes = (BizResponse) context.getFlowScope().get("bizResClaimsDetailsAccessMatrix");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {
					claimsLoadRequestDetailsVO = (ClaimsLoadRequestDetailsVO) bizRes.getTransferObjects().get("response1");

					if (claimsLoadRequestDetailsVO != null) {
						ClaimsLoadRequestDetailsPO claimsLoadRequestDetailsPO = dozerBeanMapper.map(claimsLoadRequestDetailsVO, ClaimsLoadRequestDetailsPO.class);
						if (claimsLoadRequestDetailsPO != null) {
							List<ProfilePOCPO> data = new ArrayList<ProfilePOCPO>();

							Map<String, FieldAccessMappingPO> map = claimsLoadRequestDetailsPO.getFieldAccessMappingMap();
							context.getFlowScope().put("claimsRoleAccessMatrix", map);
							if (!map.isEmpty() && map != null && prop != null) {

								ResultJsonPO resultMap = new ResultJsonPO();

								resultMap.setResultMap(map);
								resultJson = gsonJSON.toJson(resultMap);
								context.getFlowScope().put("Response", resultJson);

							}
							else {
								throw new IPruException("Error", "GRPCL03", "No Data Found");
							}

						}
						else {
							FLogger.error("ClaimsLogger", "ClaimsHandler", "getResponseClaimsDetailsAccessMatrix", "map should not be null");
							throw new IPruException("Error", "GRPCL03", "No Data Found");
						}
					}
					else {
						FLogger.error("ClaimsLogger", "ClaimsHandler", "getResponseClaimsDetailsAccessMatrix", "getResponseClaimsDetailsAccessMatrix should not be null");
						throw new IPruException("Error", "GRPCL03", "No Data Found");

					}

				}
			}
			else {
				FLogger.error("ClaimsLogger", "ClaimsHandler", "getResponseClaimsDetailsAccessMatrix", "bizRes should not be null");
				throw new IPruException("Error", "GRPCL03", "No Data Found");
			}

		}
		catch (Exception e) {
			FLogger.error("ClaimsLogger", "ClaimsHandler", "getResponseClaimsDetailsAccessMatrix", "context should not be null");
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("ClaimsLogger", "ClaimsHandler", "getResponseClaimsDetailsAccessMatrix", "getResponseClaimsDetailsAccessMatrix Method End");

		return success();
	}

	@MethodPost
	public Event getRequestDropDownList(RequestContext p_ObjContext) throws Exception {
		FLogger.info("ClaimsLogger", "ClaimsHandler", "getRequestDropDownList", "getRequestDropDownList Method Start");
		try {

			BizRequest obj_bizReq = new BizRequest();

			Object paramArray[] = new Object[0];
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			p_ObjContext.getFlowScope().put("DropDownList", obj_bizReq);

		}

		catch (Exception e) {
			FLogger.error("ClaimsLogger", "ClaimsHandler", "getRequestDropDownList", "Exception came ", e);
			throwINeoFlowException(e, "GRPCL03", p_ObjContext);

		}
		FLogger.info("ClaimsLogger", "ClaimsHandler", "getRequestDropDownList", "getRequestDropDownList Method End");
		return success();
	}

	@MethodPost
	public Event getResponseDropDownList(RequestContext p_ObjContext) throws Exception {
		FLogger.info("ClaimsLogger", "ClaimsHandler", "getResponseDropDownList", "getResponseDropDownList Method Start");

		String responselist = "";
		HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
		try {

			Gson gson = new Gson();
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResDropDownList");
			IPruUser userVo = new IPruUser();
			String productType = null;

			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null) {
					productType = userVo.getProductType();

					if (bizRes != null) {
						long functionalityId = getFunctionalityId(p_ObjContext);
						if (functionalityId != 0) {
							List<ClaimsDropDownData> dropDownObjVO = new ArrayList<ClaimsDropDownData>();
							ClaimsDropDownData claimsDropDownData = new ClaimsDropDownData();

							claimsDropDownData = (ClaimsDropDownData) bizRes.getTransferObjects().get("response1");
							if (claimsDropDownData != null) {
								claimsDropDownData.setFunctionalityId(String.valueOf(functionalityId));
								claimsDropDownData.setProductType(productType);
								dropDownObjVO.add(claimsDropDownData);
								if (dropDownObjVO != null) {
									p_ObjContext.getFlowScope().put("claimsDropDownData", claimsDropDownData);
									httpSession.setAttribute("OnloadStateDetailsData", dropDownObjVO);
									responselist = gson.toJson(dropDownObjVO);
								}
								else {
									FLogger.error("ClaimsLogger", "ClaimsHandler", "getResponseDropDownList", "dropDownObjVO should not be null");
									throw new IPruException("Error", "GRPCL03", "dropDownObjVO should not be null");
								}
							}
							else {
								FLogger.error("ClaimsLogger", "ClaimsHandler", "getResponseDropDownList", "claimsDropDownData should not be null");
								throw new IPruException("Error", "GRPCL03", "claimsDropDownData should not be null");
							}

						}
						else {
							FLogger.error("ClaimsLogger", "ClaimsHandler", "getResponseDropDownList", "functionalityId should not be 0");
							throw new IPruException("Error", "GRPCL03", "functionalityId should not be 0");
						}

					}
					else {
						FLogger.error("ClaimsLogger", "ClaimsHandler", "getResponseDropDownList", "bizRes should not be null");
						throw new IPruException("Error", "GRPCL03", "bizRes should not be null");
					}

					p_ObjContext.getFlowScope().put("Response", responselist);

				}
				else {
					FLogger.error("ClaimsLogger", "ClaimsHandler", "getResponseDropDownList", " userVo not be null");
					throw new IPruException("Error", "GRPCL03", "userVo should not be null");
				}
			}
			else {
				FLogger.error("ClaimsLogger", "ClaimsHandler", "getResponseDropDownList", "Session should not be null");
				throw new IPruException("Error", "GRPCL03", "Session should not be null");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimsLogger", "ClaimsHandler", "getRequestDropDownList", "Exception came ", e);
			throwINeoFlowException(e, "GRPCL03", p_ObjContext);
		}
		FLogger.info("ClaimsLogger", "ClaimsHandler", "getResponseDropDownList", "getResponseDropDownList Method End");
		return success();
	}

	@MethodPost
	public Event getBizRequestforSubmitClaims(RequestContext p_ObjContext) throws Exception {

		FLogger.info("ClaimsLogger", "ClaimsHandler", "getResponseDropDownList", "getBizRequestforSubmitClaims Method start");

		ClaimsUtil claimsUtil = new ClaimsUtil();
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
		IPruUser userVo = new IPruUser();
		String productType = null;
		try {

			userVo = (IPruUser) httpSession.getAttribute("userVO");
			productType = userVo.getProductType();

			Map<String, FieldAccessMappingVO> map = (Map<String, FieldAccessMappingVO>) p_ObjContext.getFlowScope().get("claimsRoleAccessMatrix");
			if (map.isEmpty()) {
				FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizRequestforSubmitClaims", "Map should not be empty");
				throw new IPruException("Error", "GRPCL03", "Map should not be empty");
			}
			FunctionalityMasterVO functionalityId = getFunctionality(p_ObjContext);
			if (functionalityId.equals(null)) {
				FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizRequestforSubmitClaims", "functionalityId should not be empty");
				throw new IPruException("Error", "GRPCL03", "functionalityId should not be empty");
			}

			String screenName = (String) p_ObjContext.getFlowScope().get("screenName");
			if (StringUtils.isBlank(screenName)) {
				FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizRequestforSubmitClaims", "screenName should not be empty");
				throw new IPruException("Error", "GRPCL03", "screenName should not be empty");
			}
			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			StringBuffer jb = new StringBuffer();
			String line = null;

			// Convert json to object
			//List claimsListPOList = gsonJSON.fromJson(request.getReader(), ArrayList.class);
			ClaimsListPO claimsListPO = gsonJSON.fromJson(request.getReader(), ClaimsListPO.class);

			if (claimsListPO == null) {
				FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizRequestforSubmitClaims", "claimsListPO should not be empty");
				throw new IPruException("Error", "GRPCL03", "claimsListPO should not be empty");
			}

			List<ClaimsSubmitPO> claimsSubmitList = claimsListPO.getAddClaims();
			List<ClaimsRequestTransactionVO> claimsRequestTransactionList =new ArrayList<ClaimsRequestTransactionVO>();

			ClaimsValidator claimsValidator = new ClaimsValidator();
			List<UploadFilePO> uploadFilePOList = null;
			int i = 1;
			for (ClaimsSubmitPO claimsSubmitPO : claimsSubmitList) {
				if (i <= 3) {
					List<ClaimsRequestPO> claimsRequestList = new ArrayList<ClaimsRequestPO>();
					claimsRequestList = claimsUtil.getClaimsRequestList(claimsSubmitPO, productType);

					List<ClaimBeneficiaryPO> claimsBeneficiaryList = new ArrayList<ClaimBeneficiaryPO>();
					claimsBeneficiaryList = claimsUtil.getClaimsBeneficiaryList(claimsSubmitPO);

					uploadFilePOList = claimsSubmitPO.getUploadFileList();

					if (CollectionUtils.isEmpty(claimsRequestList) && CollectionUtils.isEmpty(claimsBeneficiaryList)) {
						FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizRequestforSubmitClaims", "claimsRequestList or uploadFilePOList or claimsBeneficiaryList should not be empty");
						throw new IPruException("Error", "GRPCL03", "claimsRequestList or uploadFilePOList or claimsBeneficiaryList should not be empty");
					}

					String errorMsg = claimsValidator.validateClaimSubmit(claimsSubmitPO, p_ObjContext, claimsRequestList, map, uploadFilePOList, claimsBeneficiaryList, productType);

					if (StringUtils.isNotBlank(errorMsg)) {
						this.setValidationErrorMessages(errorMsg);
						FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizRequestforSubmitClaims", "Data from request should not be null");
						throwINeoFlowException(new ServiceException("GRPCL03"), "GRPCL03", p_ObjContext);
					}

					List<ClaimsRequestVO> claimsRequestVOList = new ArrayList();

					for (ClaimsRequestPO claimsRequestPO : claimsRequestList) {
						ClaimsRequestVO claimsRequestVO = dozerBeanMapper.map(claimsRequestPO, ClaimsRequestVO.class);
						claimsRequestVO.setModelName(screenName);						
						claimsRequestVOList.add(claimsRequestVO);
					}

					List<ClaimsBeneficiaryVO> claimsBeneficiaryVOList = new ArrayList<ClaimsBeneficiaryVO>();
					for (ClaimBeneficiaryPO claimBeneficiaryPO : claimsBeneficiaryList) {
						ClaimsBeneficiaryVO claimsBeneficiaryVO = dozerBeanMapper.map(claimBeneficiaryPO, ClaimsBeneficiaryVO.class);
						claimsBeneficiaryVO.setModelName(screenName);						
						claimsBeneficiaryVOList.add(claimsBeneficiaryVO);
					}

					ClaimsRequestTransactionVO claimsRequestTransactionVO = claimsUtil.getclaimsRequestTransactionVO(claimsRequestVOList, claimsBeneficiaryVOList, claimsSubmitPO, map, p_ObjContext);
					claimsRequestTransactionVO.setFunctionality(functionalityId);

					UploadFileVO uploadFileVO = null;
					Set<UploadFileVO> uploadFileVOSet = new HashSet<UploadFileVO>(0);

					for (UploadFilePO uploadFilePO : uploadFilePOList) {
						uploadFileVO = new UploadFileVO();
						dozerBeanMapper.map(uploadFilePO, uploadFileVO);
						uploadFileVOSet.add(uploadFileVO);
					}
					claimsRequestTransactionVO.setUploadFileVOSet(uploadFileVOSet);
					claimsRequestTransactionList.add(claimsRequestTransactionVO);
					i++;
				}
				else {
					FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizRequestforSubmitClaims", "Cannot add more than 3 Claims");
					throw new IPruException("Error", "GRPCL03", "Cannot add more than 3 Claims");
				}
			}


			Object[] paramArray = new Object[1];
			paramArray[0] = claimsRequestTransactionList;

			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			p_ObjContext.getFlowScope().put("saveBizReq", obj_bizReq);

		}
		catch (Exception e) {
			FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizRequestforSubmitClaims", "Exception came ", e);
			throwINeoFlowException(e, "GRPCL03", p_ObjContext);
		}
		FLogger.info("ClaimsLogger", "ClaimsHandler", "getBizRequestforSubmitClaims", "getBizRequestforSubmitClaims Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseforSubmitClaims(RequestContext p_ObjContext) throws Exception {
		FLogger.info("ClaimsLogger", "ClaimsHandler", "getBizResponseforSubmitClaims", "getBizResponseforSubmitClaims Method Start");
		BizResponse bizres = new BizResponse();
		String responseCheck = "";
		//ClaimsRequestTransactionVO claimsRequestTransactionVO = new ClaimsRequestTransactionVO();
		bizres = (BizResponse) p_ObjContext.getFlowScope().get("bizResForSubmitClaims");
		if (bizres != null) {
			responseCheck = (String) bizres.getStatusVO().getStatus();
			if (StringUtils.equalsIgnoreCase(responseCheck, "Error")) {
				FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizResponseforSubmitClaims", "Response is null");
				throw new IPruException("Error", "GRPCL03", "Response is null");
			}
			else {
				List requestIdList = (List) bizres.getTransferObjects().get("response1");
				if (requestIdList != null) {
					//ClaimsRequestTransactionPO claimsRequestTransactionPO = dozerBeanMapper.map(claimsRequestTransactionVO, ClaimsRequestTransactionPO.class);
					/*if (claimsRequestTransactionPO != null) {*/
						String result = gsonJSON.toJson(requestIdList);
						if (StringUtils.isNotBlank(result)) {
							p_ObjContext.getFlashScope().put("Response", result);
						}
						else {
							FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizResponseforSubmitClaims", "result is null");
							throw new IPruException("Error", "GRPCL03", "result is null");
						}
					/*}
					else {
						FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizResponseforSubmitClaims", "claimsRequestTransactionPO is null");
						throw new IPruException("Error", "GRPCL03", "claimsRequestTransactionPO is null");
					}*/

				}
				else {
					FLogger.error("ClaimsLogger", "ClaimsHandler", "getBizResponseforSubmitClaims", "claimsRequestTransactionVO is null");
					throw new IPruException("Error", "GRPCL03", "claimsRequestTransactionVO is null");
				}
			}
		}

		FLogger.info("ClaimsLogger", "ClaimsHandler", "getBizResponseforSubmitClaims", "getBizResponseforSubmitClaims Method End");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {

	}
}