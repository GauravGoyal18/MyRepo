package com.ipru.groups.utilities;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ipru.IPruException;
import com.ipru.groups.po.ServiceTrackerTransformerPO;
import com.ipru.groups.po.TrackerOpenClosePO;
import com.tcs.logger.FLogger;

public class TrackerUtil {

	public TrackerOpenClosePO getOpenCloseData(List<ServiceTrackerTransformerPO> serviceTrackerTransformerPOList) throws IPruException {
		FLogger.info("TRACKERLogger", "TrackerUtil", "getOpenCloseData", "onEntry of getOpenCloseData Method End");

		TrackerOpenClosePO trackerOpenClosePO = new TrackerOpenClosePO();

		if (serviceTrackerTransformerPOList != null) {
			List<ServiceTrackerTransformerPO> openList = new ArrayList<ServiceTrackerTransformerPO>();
			List<ServiceTrackerTransformerPO> closedList = new ArrayList<ServiceTrackerTransformerPO>();
			List<ServiceTrackerTransformerPO> openClosedList = new ArrayList<ServiceTrackerTransformerPO>();
			
			for (ServiceTrackerTransformerPO serviceTrackerTransformerPO : serviceTrackerTransformerPOList) {
				if (serviceTrackerTransformerPO.getStatus().equals("PENDING") || serviceTrackerTransformerPO.getStatus().equals("FAILURE") ) {
					openList.add(serviceTrackerTransformerPO);
				}
				if (serviceTrackerTransformerPO.getStatus().equals("SUCCESS")) {
					closedList.add(serviceTrackerTransformerPO);
				}
				openClosedList.add(serviceTrackerTransformerPO);								
			}
			trackerOpenClosePO.setCloseList(closedList);
			trackerOpenClosePO.setOpenList(openList);
			trackerOpenClosePO.setOpenCloseList(openClosedList);
		}
		else {
			FLogger.error("TRACKERLogger", "TrackerUtil", "getBizRequestTracker", "trackervo should not be null");
			throw new IPruException("Error", "GRPT01", "trackervo should not be null");
		}

		FLogger.info("TRACKERLogger", "TrackerUtil", "getOpenCloseData", "onEntry of getOpenCloseData Method End");
		return trackerOpenClosePO;
	}

	public String getExcelData(TrackerOpenClosePO trackerOpenClosePO, String param) throws ServletException {
		FLogger.info("TRACKERLogger", "TrackerUtil", "getOpenCloseData", "onEntry of getExcelData Method Start");
		
		String filePath = "D://DetailList.xlsx";
		List<ServiceTrackerTransformerPO> result = new ArrayList<ServiceTrackerTransformerPO>();
		try{
		if (StringUtils.isEmpty(param) && trackerOpenClosePO.equals(null)) {
			FLogger.error("TRACKERLogger", "ExcelDownload", "doPost", "param and trackerOpenClosePO should not be null");
			throw new ServletException("param and trackerOpenClosePO should not be null");
		}
		
		if (param.equalsIgnoreCase("open")) {
			result = trackerOpenClosePO.getOpenList();
		}
		if (param.equalsIgnoreCase("close")) {
			result = trackerOpenClosePO.getCloseList();
		}
		if (param.equalsIgnoreCase("openClose")) {
			result = trackerOpenClosePO.getOpenCloseList();
		}
		
		if (result != null) {

			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet spreadsheet = workbook.createSheet("employe db");
			XSSFRow row = spreadsheet.createRow(1);
			XSSFCell cell;
			cell = row.createCell(1);
			cell.setCellValue("REQUESTED ID");
			cell = row.createCell(2);
			cell.setCellValue("REQUESTED DATE");
			cell = row.createCell(3);
			cell.setCellValue("FUNCTIONALITY");
			cell = row.createCell(4);
			cell.setCellValue("STATUS");
			cell = row.createCell(5);
			cell.setCellValue("UPDATED DATE");

			int i = 2;

			for (ServiceTrackerTransformerPO serviceTrackerTransformerPO : result) {					
				row = spreadsheet.createRow(i);
				cell = row.createCell(1);
				cell.setCellValue(serviceTrackerTransformerPO.getRequestId());
				cell = row.createCell(2);
				cell.setCellValue(serviceTrackerTransformerPO.getRequestTime().toString());
				cell = row.createCell(3);
				cell.setCellValue(serviceTrackerTransformerPO.getFunctionalityName().toString());
				cell = row.createCell(4);
				cell.setCellValue(serviceTrackerTransformerPO.getStatus());
				cell = row.createCell(5);
				cell.setCellValue(serviceTrackerTransformerPO.getUpdtTime().toString());
				i++;

			}

			FileOutputStream out = new FileOutputStream(filePath);
			workbook.write(out);
			out.close();

		}
		else {
			FLogger.error("TRACKERLogger", "ExcelDownload", "doPost", "result cannot be null");
			throw new ServletException("result cannot be null");
		}
		}catch(Exception e){
			e.printStackTrace();
			FLogger.error("TRACKERLogger", "ExcelDownload", "doPost", "result cannot be null",e);
			throw new ServletException("result cannot be null");
		}
		
		return filePath;
	}
}
