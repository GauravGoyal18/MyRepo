package com.ipru.groups.validators;

import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.groups.po.DigitalLifeVerificationPO;
import com.tcs.logger.FLogger;

public class DigiLifeVerificationValidator {

	private static DigiLifeVerificationValidator single_instance = null; 
	private static final String INFO_LOGGER_NAME = "DigitalLifeVerificationLogger";
	private static final String CLASS_NAME = "DigitalLifeVerificationHandler";
	
	public String validateDigiLifeVeriForm(DigitalLifeVerificationPO  digitalLifeVerificationPO,RequestContext context) 
	{	Gson gsonJSON = null;
		StringBuilder infoMessageBuilder=new StringBuilder();
		FLogger.info(INFO_LOGGER_NAME,CLASS_NAME,"validateDigiLifeVeriForm","method start");
		String webServiceResponse =(String)context.getFlowScope().get("digiLifeDetails");
		DigitalLifeVerificationPO digiWebServiceRespPO = gsonJSON.fromJson(webServiceResponse,DigitalLifeVerificationPO.class);
		
		if(!digitalLifeVerificationPO.equals(digiWebServiceRespPO))
		{
			FLogger.info(INFO_LOGGER_NAME,CLASS_NAME,"validateDigiLifeVeriForm","Exception Occured,Data Mismatch");
			infoMessageBuilder.append("Found Data Mismatch");
		}
		return infoMessageBuilder.toString();
	}
	
	public static DigiLifeVerificationValidator getSingleton() {
		
		if(single_instance==null)
		{
			single_instance = new DigiLifeVerificationValidator();
		}
		return single_instance;
	}
}
