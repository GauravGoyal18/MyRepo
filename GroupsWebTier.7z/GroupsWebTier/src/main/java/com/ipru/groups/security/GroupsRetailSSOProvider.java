package com.ipru.groups.security;

import org.springframework.security.core.Authentication;

import com.ipru.security.user.IPruUser;
import com.tcs.exception.SecurityException;
import com.tcs.logger.FLogger;
import org.apache.commons.lang3.StringUtils;

public class GroupsRetailSSOProvider {
	
	LoginProcessService1 lps = null;

	

	public IPruUser getRetailSSOProvider(IPruUser userVO, Authentication authentication) throws SSOGroupDefaultException {
		FLogger.info("securityLogger", "GroupsRetailSSOProvider", "getRetailSSOProvider", "ssoLogin Start");
		// TODO Auto-generated method stub
		String username = String.valueOf(((IPruUser) authentication.getPrincipal()).getUsername());
		String websiteSource = String.valueOf(((IPruUser) authentication.getPrincipal()).getWebsiteSource());
		String password = String.valueOf(authentication.getCredentials());
		
		try {
			lps = new LoginProcessService1();
			password = lps.groupLoginWithSingleSignOn(userVO);
			
		if (!StringUtils.isEmpty(password) && !StringUtils.isEmpty(username)) {
			userVO = lps.SSOGrouploginWithEmailMobile(username, password);
			userVO = lps.SSOGroupLoginEmailmobile(userVO);
		}
		else {
			FLogger.info("securityLogger", "GroupsRetailSSOProvider", "getRetailSSOProvider", "password should not be null");

			throw new SSOGroupDefaultException("Email Id and mobile number not registered");
		}

		FLogger.info("securityLogger", "GroupsRetailSSOProvider", "getRetailSSOProvider", "ssoLogin End");
		
		}catch (SSOGroupDefaultException e) {

			throw new SSOGroupDefaultException("Email Id and mobile number not registered");
		}
		return  userVO;
	}

}
