package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.BrokerBIDPO;
import com.ipru.groups.validators.BrokerBidValidator;
import com.ipru.groups.vo.BrokerBIDVO;
import com.ipru.groups.vo.FtlToPdfVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;

public class BrokerBIDHandler extends IneoBaseHandler {

	public Event getOnloadPolicyList(RequestContext context) throws Exception {
		FLogger.info("BrokerBIDLogger", "BrokerBIDHandler", "getOnloadPolicyList", "Method start");

		try {
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			IPruUser userVo = null;
			if (request != null) {

				HttpSession httpSession = request.getSession();

				if (httpSession != null) {
					userVo = (IPruUser) httpSession.getAttribute("userVO");
					if (userVo != null) {

						List<String> policyNoList = new ArrayList<String>();
						
						for(String str:userVo.getFscdetails().getPolicyNoList()){
							policyNoList.add(str);
						}
					
						httpSession.setAttribute("policyNoList", policyNoList);
						context.getFlowScope().put("Response", gsonJSON.toJson(policyNoList));
					}
					else {
						FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getOnloadPolicyList", "userVo Should not be null");
						throw new IPruException("Error", "BIDSTMT01", "Invalid Session");
					}
				}
				else {
					FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getOnloadPolicyList", "Empty Session");
					throw new IPruException("Error", "BIDSTMT01", "Invalid Session");
				}
			}
			else {
				FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getOnloadPolicyList", "Found Null Request");
				throw new IPruException("Error", "BIDSTMT01", "Some Error Occured");
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		FLogger.info("BrokerBIDLogger", "BrokerBIDHandler", "getOnloadPolicyList", "Method end");
		return success();
	}

	public Event getRequestBid(RequestContext context) throws Exception {
		FLogger.info("BrokerBIDLogger", "BrokerBIDHandler", "getRequestBID", "Method end");

		try {
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			IPruUser userVo = null;
			if (request != null) {

				HttpSession httpSession = request.getSession();

				if (httpSession != null) {
					userVo = (IPruUser) httpSession.getAttribute("userVO");
					if (userVo != null) {

						BrokerBIDPO brokerBIDPO = gsonJSON.fromJson(request.getReader(), BrokerBIDPO.class);

						if (brokerBIDPO != null) {
							List policyNoList = (List) httpSession.getAttribute("policyNoList");
							BrokerBidValidator validator = new BrokerBidValidator();
							String errorSuccessMessage = validator.validateBid(brokerBIDPO, policyNoList);
							if (StringUtils.isNotBlank(errorSuccessMessage)) {

								this.setValidationErrorMessages(errorSuccessMessage);
								FLogger.error("BIDStatementLogger", "BIDStatementHandler", "getBizRequestForFetchBIDStatement", "errorSuccessMessage is" + errorSuccessMessage);
								this.setValidationErrorMessages(errorSuccessMessage);
								throw new IPruException("Error", "GRPCOI01", errorSuccessMessage);

							}

							BrokerBIDVO brokerBIDVO = dozerBeanMapper.map(brokerBIDPO, BrokerBIDVO.class);
							// brokerBIDVO.setPolicyKey("9228");
							//brokerBIDVO.setPolicyKey(userVo.getPolicyKey());
							// brokerBIDVO.setClientName("Refreshment Product Service India Private Limited");
							//brokerBIDVO.setClientName(userVo.getClientName());
							// brokerBIDVO.setClientId("92281");
							brokerBIDVO.setClientId(userVo.getFscdetails().getFsc_client_id());
							// brokerBIDVO.setRoleType("TERM");
							brokerBIDVO.setLocation("");
							brokerBIDVO.setUnitCode("1");
							brokerBIDVO.setRoleType(userVo.getFscdetails().getFscChannel());
							/*if (!brokerBIDVO.getRoleType().equalsIgnoreCase("GTRUST")) {
								brokerBIDVO.setUnitCode("");
								//brokerBIDVO.setLocation("1");
								//brokerBIDVO.setLocation(userVo.getUnitCode());
							}*/
							//brokerBIDVO.setRenewalNo("00");
							//brokerBIDVO.setRenewalNo(userVo.getRenewalNo());

							Object[] paramArray = new Object[1];
							paramArray[0] = brokerBIDVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);
							context.getFlowScope().put("submitBrokerBid", obj_bizReq);

						}
						else {
							FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getOnloadPolicyList", "brokerBIDPO Should not be null");
							throw new IPruException("Error", "BIDSTMT01", "brokerBIDPO Should not be null");
						}

					}
					else {
						FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getOnloadPolicyList", "userVo Should not be null");
						throw new IPruException("Error", "BIDSTMT01", "Invalid Session");
					}
				}
				else {
					FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getOnloadPolicyList", "Empty Session");
					throw new IPruException("Error", "BIDSTMT01", "Invalid Session");
				}
			}
			else {
				FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getOnloadPolicyList", "Found Null Request");
				throw new IPruException("Error", "BIDSTMT01", "Some Error Occured");
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getOnloadPolicyList", "Exception came ", e);
			throwINeoFlowException(e, "BIDSTMT01", context);
		}

		FLogger.info("BrokerBIDLogger", "BrokerBIDHandler", "getRequestBID", "Method end");
		return success();
	}

	public Event getResponseBid(RequestContext context) throws Exception {
		FLogger.info("BrokerBIDLogger", "BrokerBIDHandler", "getResponseBid", "Method end");

		try {

			FLogger.info("BrokerBIDLogger", "BrokerBIDHandler", "getResponseBid", "Method start");

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			HttpSession httpSession = request.getSession();

			if (httpSession == null) {
				FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getResponseBid", "httpSession is null");
				throw new IPruException("Error", "BIDSTMT01", "Null Seesion data");

			}
			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) context.getFlowScope().get("bizResForBrokerBid");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throw new IPruException("Error", "BIDSTMT01", "Some Error Occured,Please try again later");
				}
				else {
					FtlToPdfVO ftlToPdfVO = (FtlToPdfVO) bizRes.getTransferObjects().get("response1");

					if (ftlToPdfVO == null) {
						FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getResponseBid", "bidResponseList is null");
						throw new IPruException("Error", "BIDSTMT01", "Some Error Occured");
					}

					httpSession.setAttribute("statementDownloadData", ftlToPdfVO);
					context.getFlowScope().put("Response", "success");
				}
			}
			else {
				FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getResponseBid", "bizRes is null");
				throw new IPruException("Error", "BIDSTMT01", "Some Error Occured");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("BrokerBIDLogger", "BrokerBIDHandler", "getResponseBid", "Exception came", e);
			throwINeoFlowException(e, "GRPPFCC", context);
		}

		FLogger.info("BrokerBIDLogger", "BrokerBIDHandler", "getResponseBid", "Method end");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
