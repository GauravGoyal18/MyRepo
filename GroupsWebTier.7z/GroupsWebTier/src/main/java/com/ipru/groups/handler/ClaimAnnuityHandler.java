package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.ClaimAnnuityOnloadPO;
import com.ipru.groups.po.ClaimAnnuityOptionPO;
import com.ipru.groups.po.ClaimAnnuitySubmitPO;
import com.ipru.groups.po.ClaimAnnuityWegaPO;
import com.ipru.groups.validators.ClaimAnnuityValidator;
import com.ipru.groups.vo.ClaimAnnuityOnloadVO;
import com.ipru.groups.vo.ClaimAnnuityOptionVO;
import com.ipru.groups.vo.ClaimAnnuitySubmitVO;
import com.ipru.groups.vo.ClaimAnnuityWegaVO;
import com.ipru.groups.vo.ClaimReqIBMredirectVO;
import com.ipru.groups.vo.FtlToPdfVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ClaimAnnuityHandler extends IneoBaseHandler {

	public Event getBizRequestOnload(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestOnload", "getBizRequestOnload Method Start");
		Gson gson = new Gson();

		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
				String clientId = null;
				String policyNo = null;
				String memberType = null;
				String empId = null;

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						clientId = userVo.getClientId();
						policyNo = userVo.getPolicyNo();
						memberType = userVo.getRoleType();
						empId = userVo.getEmpId();

						ClaimAnnuityOptionPO claimAnnuityOptionPO = new ClaimAnnuityOptionPO();
						claimAnnuityOptionPO.setPolicyNo(policyNo);
						claimAnnuityOptionPO.setEmpId(empId);
						ClaimAnnuityOptionVO claimAnnuityOptionVO = dozerBeanMapper.map(claimAnnuityOptionPO, ClaimAnnuityOptionVO.class);

						Object[] paramArray = new Object[1];
						paramArray[0] = claimAnnuityOptionVO;
						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);
						context.getFlowScope().put("claimAnnuityBizReqOnLoad", obj_bizReq);

					}
					else {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestOnLoad", "userVo should not be null");
						throw new IPruException("Error", "GRPPFCC", "userVo should not be null");
					}
				}
				else {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestOnLoad", "httpSession should not be null");
					throw new IPruException("Error", "GRPPFCC", "httpSession should not be null");
				}
			}
			else {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestOnLoad", "Context should not be null");
				throw new IPruException("Error", "GRPPFCC", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestOnLoad", "Exception came ", e);
			throwINeoFlowException(e, "GRPPFCC", context);
		}
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestOnLoad", "onEntry of getBizRequestOnLoad Method End ");
		return success();
	}

	@MethodPost
	public Event getBizResponseOnload(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizResponseOnload", "Method Start");

		String responselist = "";
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		try {

			Gson gson = new Gson();
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResClaimAnnuityOnload");
			IPruUser userVo = new IPruUser();
			String clientId = null;
			String policyNo = null;
			String empId = null;
			String role = null;
			/*
			 * Double purchasePrice=null; String purchasePriceStr=null;
			 */
			String claimId = null;
			String flag = null;
			claimId = (String) context.getFlowScope().get("claimId");
			/*
			 * purchasePriceStr=(String)
			 * context.getFlowScope().get("purchasePrice");
			 */
			flag = (String) context.getFlowScope().get("flag");

			/*
			 * if(purchasePriceStr!=null){ purchasePrice =
			 * Double.parseDouble(purchasePriceStr); }else{ purchasePrice=0.0; }
			 */

			if (claimId == null) {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestOnLoad", "You have not submitted the Claim form or purchase price");
				// throw new IPruException("Error", "GRPPFCC",
				// "You have not submitted the Claim form.");
			}

			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null) {
					clientId = userVo.getClientId();
					policyNo = userVo.getPolicyNo();
					empId = userVo.getEmpId();
					role = userVo.getRoleType();

					if (bizRes != null) {
						long functionalityId = getFunctionalityId(context);
						// long functionalityId = 26;
						// if (functionalityId != 0) {
						// List<ClaimAnnuityOptionVO> claimAnnuityOptionVOList =
						// new ArrayList<ClaimAnnuityOptionVO>();

						// claimAnnuityOptionVOList =
						// (List<ClaimAnnuityOptionVO>)
						// bizRes.getTransferObjects().get("response1");
						ClaimAnnuityOnloadVO claimAnnuityOnloadVO = (ClaimAnnuityOnloadVO) bizRes.getTransferObjects().get("response1");
						Map<String, ClaimAnnuityOptionPO> annuityOptMap = new HashMap<String, ClaimAnnuityOptionPO>();

						if (claimAnnuityOnloadVO != null) {

							List<ClaimAnnuityWegaVO> claimAnnuityWegaVOList = claimAnnuityOnloadVO.getClaimAnnuityWegaList();
							List<ClaimAnnuityWegaPO> claimAnnuityWegaPOList;
							if (CollectionUtils.isNotEmpty(claimAnnuityWegaVOList)) {
								claimAnnuityWegaPOList = new ArrayList<ClaimAnnuityWegaPO>();
								ClaimAnnuityWegaVO claimAnnuityWegaVO = claimAnnuityWegaVOList.get(0);
								ClaimAnnuityWegaPO claimAnnuityWegaPO = dozerBeanMapper.map(claimAnnuityWegaVO, ClaimAnnuityWegaPO.class);
								claimAnnuityWegaPO.setEmpId(empId);
								claimAnnuityWegaPO.setPolicyNo(policyNo);
								claimAnnuityWegaPO.setClientId(clientId);
								claimAnnuityWegaPO.setRole(role);
								claimAnnuityWegaPO.setClientId(clientId);
								claimAnnuityWegaPO.setClaimId(claimId);
								claimAnnuityWegaPO.setFunctionalityId(String.valueOf(functionalityId));
								claimAnnuityWegaPOList.add(claimAnnuityWegaPO);

								List<ClaimAnnuityOptionVO> claimAnnuityOptionVOList = claimAnnuityOnloadVO.getClaimAnnuityOptionList();
								List<ClaimAnnuityOptionPO> claimAnnuityOptionPOList = new ArrayList<ClaimAnnuityOptionPO>();
								ClaimReqIBMredirectVO claimReqIBMredirectVO = null;
								if (CollectionUtils.isNotEmpty(claimAnnuityOptionVOList)) {
									for (ClaimAnnuityOptionVO claimAnnuityOptionVO : claimAnnuityOptionVOList) {
										claimReqIBMredirectVO = claimAnnuityOptionVO.getClaimReqIBMredirectVO();
										ClaimAnnuityOptionPO claimAnnuityOptionPO = dozerBeanMapper.map(claimAnnuityOptionVO, ClaimAnnuityOptionPO.class);
										claimReqIBMredirectVO = claimAnnuityOptionVO.getClaimReqIBMredirectVO();
										annuityOptMap.put(claimAnnuityOptionVO.getOptionName(), claimAnnuityOptionPO);
										claimAnnuityOptionPOList.add(claimAnnuityOptionPO);
									}

									ClaimAnnuityOnloadPO claimAnnuityOnloadPO = new ClaimAnnuityOnloadPO();
									claimAnnuityOnloadPO.setClaimAnnuityOptionList(claimAnnuityOptionPOList);
									claimAnnuityOnloadPO.setClaimAnnuityWegaList(claimAnnuityWegaPOList);

									context.getFlowScope().put("claimReqIBMredirectVO", claimReqIBMredirectVO);
									context.getFlowScope().put("claimAnnuityOptionMap", annuityOptMap);
									if (claimReqIBMredirectVO.getIsClaimAnnuityReq() == 1) {
										context.getFlowScope().put("yesNo", true);
									}
									else {
										if (StringUtils.isNotEmpty(flag)) {
											if (flag.equals("true")) {
												context.getFlowScope().put("yesNo", true);
											}
											else {
												context.getFlowScope().put("yesNo", false);
											}
										}
										else {
											context.getFlowScope().put("yesNo", false);
										}
									}

									responselist = gson.toJson(claimAnnuityOnloadPO);
								}
								else {
									FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizResponseOnload", "claimAnnuityOptionVOList should not be null");
									throw new IPruException("Error", "GRPCL03", "No Data Found");
								}
							}
							else {
								FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizResponseOnload", "claimAnnuityWegaVOList should not be null");
								throw new IPruException("Error", "GRPCL03", "No Data Found");
							}

						}
						else {
							FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizResponseOnload", "claimAnnuityOptionVOList should not be null");
							throw new IPruException("Error", "GRPCL03", "No data Found");
						}

					}
					else {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizResponseOnload", "bizRes should not be null");
						throw new IPruException("Error", "GRPCL03", "bizRes should not be null");
					}

					context.getFlowScope().put("Response", responselist);

				}
				else {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizResponseOnload", " userVo not be null");
					throw new IPruException("Error", "GRPCL03", "userVo should not be null");
				}
			}
			else {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizResponseOnload", "Session should not be null");
				throw new IPruException("Error", "GRPCL03", "Session should not be null");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getRequestDropDownList", "Exception came ", e);
			throwINeoFlowException(e, "GRPCL03", context);
		}
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizResponseOnload", "Method End");
		return success();
	}

	@MethodPost
	public Event getBizRequestSubmit(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestSubmit", "Method Start");
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		IPruUser userVo = new IPruUser();
		HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

		String claimId = null;
		String policyNo = null;
		String empId = null;
		String role = null;
		String clientId = null;

		claimId = (String) context.getFlowScope().get("claimId");
		// claimId = "222";
		try {

			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");
				if (userVo != null) {
					policyNo = userVo.getPolicyNo();
					empId = userVo.getEmpId();
					role = userVo.getRoleType();
					clientId = userVo.getClientId();
					if (StringUtils.isNotEmpty(claimId)) {
						Map<String, ClaimAnnuityOptionPO> map = (Map<String, ClaimAnnuityOptionPO>) context.getFlowScope().get("claimAnnuityOptionMap");
						ClaimReqIBMredirectVO claimReqIBMredirectVO = (ClaimReqIBMredirectVO) context.getFlowScope().get("claimReqIBMredirectVO");
						ClaimAnnuitySubmitPO claimAnnuitySubmitPO = gsonJSON.fromJson(request.getReader(), ClaimAnnuitySubmitPO.class);
						claimAnnuitySubmitPO.setClaimId(Long.parseLong(claimId));
						claimAnnuitySubmitPO.setRole(role);
						claimAnnuitySubmitPO.setClientId(clientId);
						ClaimAnnuityValidator claimAnnuityValidator = new ClaimAnnuityValidator();
						String errorMsg = claimAnnuityValidator.getVaidateData(claimAnnuitySubmitPO, map, policyNo, empId);
						if (StringUtils.isNotEmpty(errorMsg)) {
							this.setValidationErrorMessages(errorMsg);
							FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestSubmit", "Data from request should not be null");
							throwINeoFlowException(new ServiceException("GRPCL03"), "GRPCL03", context);
						}
						ClaimAnnuitySubmitVO claimAnnuitySubmitVO = dozerBeanMapper.map(claimAnnuitySubmitPO, ClaimAnnuitySubmitVO.class);
						claimAnnuitySubmitVO.setRequested(new Date());
						claimAnnuitySubmitVO.setClaimReqIBMredirectVO(claimReqIBMredirectVO);
						Object[] paramArray = new Object[1];
						paramArray[0] = claimAnnuitySubmitVO;
						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);
						context.getFlowScope().put("claimAnnuityBizReqSubmit", obj_bizReq);
					}
					else {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestSubmit", "claimId is Empty");
						throw new IPruException("Error", "GRPCL03", "claimId is Empty");
					}
				}
				else {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestSubmit", "userVo is Empty");
					throw new IPruException("Error", "GRPCL03", "userVo is Empty");
				}
			}
			else {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestSubmit", "Empty Session");
				throw new IPruException("Error", "GRPCL03", "Empty Session");
			}

		}
		catch (Exception e) {
			FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestSubmit", "Method End");
		return success();
	}

	public Event getBizResponseSubmit(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizResponseSubmit", "Method Start");
		String responseCheck = "";
		String result = null;
		BizResponse bizres = new BizResponse();
		try {
			bizres = (BizResponse) context.getFlowScope().get("bizResClaimAnnuitySubmit");
			if (bizres != null) {
				responseCheck = (String) bizres.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "Error")) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getResponseSubmit", "Response is null");
					throw new IPruException("Error", "GRPCL03", "Response is null");
				}
				else {
					result = (String) bizres.getTransferObjects().get("response1");
					if (StringUtils.isNotEmpty(result)) {
						context.getFlashScope().put("Response", result);
					}
					else {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getResponseSubmit", "No data Found");
						throw new IPruException("Error", "GRPCL03", "No data Found");
					}

				}
			}
		}
		catch (Exception e) {
			FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getResponseSubmit", "context should not be null" + e);
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizResponseSubmit", "Method End");
		return success();
	}

	public Event getBizRequestDownload(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "Method Start");

		Gson gson = new Gson();

		try {

			if (context != null) {

				String claimId = null;
				claimId = (String) context.getFlowScope().get("claimId");

				if (claimId == null) {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "You have not submitted the Claim form.");
				}

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
				String clientId = null;
				String policyNo = null;
				String memberType = null;
				String empId = null;

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						clientId = userVo.getClientId();
						policyNo = userVo.getPolicyNo();
						memberType = userVo.getRoleType();
						empId = userVo.getEmpId();

						ClaimAnnuitySubmitPO claimAnnuitySubmitPO = new ClaimAnnuitySubmitPO();
						claimAnnuitySubmitPO.setPolicyNo(policyNo);
						claimAnnuitySubmitPO.setEmpId(empId);
						ClaimAnnuitySubmitVO claimAnnuitySubmitVO = dozerBeanMapper.map(claimAnnuitySubmitPO, ClaimAnnuitySubmitVO.class);

						Object[] paramArray = new Object[1];
						paramArray[0] = claimAnnuitySubmitVO;
						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);
						context.getFlowScope().put("claimAnnuityBizReqDownload", obj_bizReq);

					}
					else {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "userVo should not be null");
						throw new IPruException("Error", "GRPPFCC", "userVo should not be null");
					}
				}
				else {
					FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "httpSession should not be null");
					throw new IPruException("Error", "GRPPFCC", "httpSession should not be null");
				}
			}
			else {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "Context should not be null");
				throw new IPruException("Error", "GRPPFCC", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "Exception came ", e);
			throwINeoFlowException(e, "GRPPFCC", context);
		}

		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "Method End");
		return success();
	}

	public Event getBizResponseDownload(RequestContext context) throws Exception {
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "Method Start");
		try {

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			HttpSession httpSession = request.getSession();

			if (httpSession == null) {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "httpSession is null");
				throw new IPruException("Error", "GRPPFCC", "Null Seesion data");

			}
			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) context.getFlowScope().get("bizResClaimAnnuityDownload");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throw new IPruException("Error", "GRPPFCC", "Some Error Occured,Please try again later");
				}
				else {
					FtlToPdfVO ftlToPdfVO = (FtlToPdfVO) bizRes.getTransferObjects().get("response1");

					if (ftlToPdfVO == null) {
						FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "bidResponseList is null");
						throw new IPruException("Error", "GRPPFCC", "Some Error Occured");
					}

					httpSession.setAttribute("statementDownloadData", ftlToPdfVO);
					// String result =
					// gsonJSON.toJson(nomineeUpdateTransactionPo);
					context.getFlowScope().put("Response", "success");
				}
			}
			else {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "bizRes is null");
				throw new IPruException("Error", "GRPPFCC", "Some Error Occured");
			}
		}
		catch (Exception e) {
			FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "Some Error Occured", e);

			throwINeoFlowException(e, "GRPPFCC", context);
		}

		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityHandler", "getBizRequestDownload", "Method End");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
