/*
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 */

package com.ipru.groups.security;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;
import org.springframework.security.core.userdetails.User;

import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;
import com.tcs.security.user.Autherization;

/**
 * @author Heena
 */

public class GroupsAuthenticationProvider implements AuthenticationProvider {
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		FLogger.info("securityLogger", "GroupsAuthenticationProvider", "authenticate", "authenticate method called");

		Authentication auth = null;

		String username = String.valueOf(((IPruUser) authentication.getPrincipal()).getUsername());
		String websiteSource = String.valueOf(((IPruUser) authentication.getPrincipal()).getWebsiteSource());
		String password = String.valueOf(authentication.getCredentials());
		IPruUser userVO = (IPruUser) authentication.getPrincipal();
		String ssoLogin = String.valueOf(((IPruUser) authentication.getPrincipal()).getSsoLogin());
		Properties prop = new Properties();
		try {
			prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;

		}
		catch (Exception e) {
			FLogger.error("securityLoggerError", "GroupsAuthenticationProvider", "authenticate", "Exception found at the time of loading properties file in provider");
			e.printStackTrace();
		}
		LoginProcessService1 lps = null;

		try {
			lps = new LoginProcessService1();
			if (websiteSource != null && websiteSource.equalsIgnoreCase(prop.getProperty("webSitesource"))) {
				FLogger.info("securityLogger", "GroupsAuthenticationProvider", "authenticate", "Logging in through single sign on");
				userVO = (IPruUser) lps.ssoLogin(userVO);
				if (userVO.getRoles() == null) {
					throw new BadCredentialsException("Error occured while single sign on .Role of user " + userVO.getUserId() + " is found null");
				}
				Autherization autherization = new Autherization();
				autherization.setRole(userVO.getRoles());
				userVO.setAutherization(autherization);
			}
			
             else if( ssoLogin != null && ssoLogin.equals(prop.getProperty("GRP_MEMBERSOURCE"))) {
				
				GroupsRetailSSOProvider groupsRetailSSOProvider = new GroupsRetailSSOProvider();
				
				userVO= groupsRetailSSOProvider.getRetailSSOProvider(userVO,authentication);

				
			}
              else if(ssoLogin != null && ssoLogin.equals(prop.getProperty("GRP_BROKERSOURCE"))) {
				
            	  GroupsBorkerSSOProvider groupsBorkerSSOProvider = new GroupsBorkerSSOProvider();
            		
				   userVO= groupsBorkerSSOProvider.getBrokerSSOProvider(userVO,authentication);

				
			}
			else {
				FLogger.info("securityLogger", "GroupsAuthenticationProvider", "authenticate", "Logging in through username " + userVO.getWebClientId());
				String loginWithEmailMobile = userVO.getLoginThroughUserIdEmailMobile();
				if (loginWithEmailMobile.equals(prop.getProperty("LOGIN_USERID"))) {
					userVO = (IPruUser) lps.login(username, password);
					userVO = lps.groupLogin(userVO);

				}
				else if (loginWithEmailMobile.equals(prop.getProperty("LOGIN_EMAIL_MOBILE"))) {
					userVO = lps.loginWithEmailMobile(username, password);
					userVO = lps.groupLoginEmailmobile(userVO);
				}
			}
			GrantedAuthorityImpl[] gautr = new GrantedAuthorityImpl[1];
			userVO.getAuthority().setRole(userVO.getRoles());
			gautr[0] = new GrantedAuthorityImpl(userVO.getAuthority().getRole());
			auth = new UsernamePasswordAuthenticationToken(userVO, password, Arrays.asList(gautr));

		}
		catch (SSOGroupDefaultException e) {

			throw new SSOGroupDefaultException(e.getMessage());
		}

		catch (Exception e) {
		    e.printStackTrace();
			FLogger.error("securityLoggerError", "GroupsAuthenticationProvider", "authenticate", "Exception found in authenticate");
			if (lps.getMessage().equalsIgnoreCase("userLocked")) {
				throw new BadCredentialsException("Your account has been locked now");
			}
			if (lps.getMessage().equalsIgnoreCase("loginWithEmailMobile")) {
				throw new BadCredentialsException("Kindly login with email Id/Mobile number.");
			}
			else {
				e.printStackTrace();
				FLogger.error("securityLoggerError", "GroupsAuthenticationProvider", "authenticate", "The username or password is incorrect.Please try again." + username);
				throw new BadCredentialsException("The username or password is incorrect.Please try again.");
			}
		}

		return auth;  
	}

	public boolean supports(@SuppressWarnings("rawtypes") java.lang.Class authentication) {
		return true;
	}

	private Collection<? extends GrantedAuthority> getAuthorities(boolean isAdmin) {
		List<GrantedAuthority> authList = new ArrayList<GrantedAuthority>(2);
		authList.add(new GrantedAuthorityImpl("ROLE_USER"));
		if (isAdmin) {
			authList.add(new GrantedAuthorityImpl("ROLE_ADMIN"));
		}
		return authList;
	}

	@SuppressWarnings("unused")
	private class UserMapper implements ParameterizedRowMapper<User> {
		@Override
		public User mapRow(ResultSet rs, int arg1) throws SQLException {
			return new User(rs.getString("email"), rs.getString("password"), true, true, true, true, getAuthorities(rs.getBoolean("admin")));
		}
	}

	public Md5PasswordEncoder passwordEncoder = new Md5PasswordEncoder();

	public Md5PasswordEncoder getPasswordEncoder() {
		return passwordEncoder;
	}

	public void setPasswordEncoder(Md5PasswordEncoder passwordEncoder) {
		this.passwordEncoder = passwordEncoder;
	}

}