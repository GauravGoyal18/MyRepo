package com.ipru.groups.handler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ipru.groups.validators.DigiLifeVerificationValidator;
import com.ipru.groups.validators.SAClaimIntimationValidator;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.SAClaimIntimationVO;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.DigitalLifeVerificationPO;
import com.ipru.groups.po.SAClaimIntimationSubmitPO;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.security.encryption.EncryptionAES256;
import com.ipru.groups.utilities.CommonFileUploadUtil;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.vo.DigitalLifeVerificationVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodGet;
import com.tcs.security.annotations.MethodPost;

public class DigitalLifeVerificationHandler extends IneoBaseHandler {

	private static final long serialVersionUID = 1L;

	private static final String INFO_LOGGER_NAME = "DigitalLifeVerificationLogger";
	private static final String CLASS_NAME = "DigitalLifeVerificationHandler";
	
	
	public static final String ErrorMsg = "Something Went Wrong Please Try Again!";


	/*Below method will perform the decryption of contract id and 
	 * basis contract id , get the data from informatica webservice
	 * data will be populated on form.
	 */
	
	@MethodPost
	public Event getReqDigiLifeDetails(RequestContext context) throws Exception {
		final String METHOD_NAME = "getReqDigiLifeDetails";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start");
		Gson gson = new Gson();
		DigitalLifeVerificationPO  digitalLifeVerificationPO= null;
		try
		{
			if (context != null)
			{
				String encryptedContractIdJson = (String) context.getFlowScope().get("enc"); 
				
				if (StringUtils.isEmpty(encryptedContractIdJson))
				{
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "encryptedData is null");
					throw new IPruException("Error", "GRPDLV01", "Getting Null EncryptedData");
				}
				String decryptedContractIdJson = EncryptionAES256.digiLifeVeriEncryptData(encryptedContractIdJson);
				
				digitalLifeVerificationPO = gsonJSON.fromJson(decryptedContractIdJson,DigitalLifeVerificationPO.class);
				
				DigitalLifeVerificationVO  digitalLifeVerificationVO = dozerBeanMapper.map(digitalLifeVerificationPO, DigitalLifeVerificationVO.class);
				
				Object[] paramArray = new Object[1];
				paramArray[0] = digitalLifeVerificationVO;
				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1",paramArray);
				context.getFlowScope().put("digiLifeDetails", obj_bizReq);

			}
			else
			{
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME,
						"Context should not be null");
				throw new IPruException("Error", "GRPDLV01",
						"Context should not be null");
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End ");
		return success();
	}
	

	@MethodPost
	public Event getResDigiLifeVeriDetails(RequestContext context) throws Exception
	{	
		final String METHOD_NAME ="getResDigiLifeVeriDetails";
		DigitalLifeVerificationVO digitalLifeVerification=null;

		try 
		{
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession == null) {

				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Found null session");

				throw new IPruException("Error", "GRPGTCLMSS01", "Session expired");
			}

			String responseCheck = "";
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResDigiLifeVeriDetails");
			if (bizRes != null) {
				digitalLifeVerification = (DigitalLifeVerificationVO) bizRes.getTransferObjects().get("response1");
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, " " + digitalLifeVerification);

				if (digitalLifeVerification==null) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "No Data Found for DigitalLifeVerification");
					throw new IPruException("Error", "GRPGTCLMSS01", "Some Error Occured");
				}
						
			}
			digitalLifeVerification.setPhonemobile(Long.parseLong("7975548662"));
			setOtpDetailsInSession(context,digitalLifeVerification);
			context.getConversationScope().put("digitalLifeVerificationData", digitalLifeVerification);
		
			context.getFlowScope().put("Response","success");

		}
		catch(Exception e)
		{
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSCI01", context);
		}
		return success();
	}
	
	public Event getReqSubmitForDigiLifeSpaarcCall(RequestContext context) throws Exception {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getReqSubmitForDigiLifeSpaarcCall", "getReqSubmitForDigiLifeSpaarcCall Method Start");
		final String METHOD_NAME = "getReqSubmitForDigiLifeSpaarcCall";
		CommonFileUploadUtil commonFileUploadUtil=new CommonFileUploadUtil();
		DigitalLifeVerificationVO digitalLifeVerificationvo=null;
		
		HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
		if(request!=null)
		{
			DigitalLifeVerificationPO digiLifeVeriPO = gsonJSON.fromJson(request.getReader(), DigitalLifeVerificationPO.class);
			if (digiLifeVeriPO == null) {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, " digiLifeVeriPO should not be empty");
				throw new IPruException("Error", "GRPSCI01", "digiLifeVeriPO should not be empty");
			}
			
			DigiLifeVerificationValidator digiLifeVeriValidator = DigiLifeVerificationValidator.getSingleton();
			digitalLifeVerificationvo=(DigitalLifeVerificationVO) context.getConversationScope().get("digitalLifeVerificationData");
			if(digitalLifeVerificationvo==null)
			{
				FLogger.error(INFO_LOGGER_NAME,CLASS_NAME ,METHOD_NAME , "digitalLifeVerificationvo request should not be null");
				throw new IPruException("Error", "GRPSCI01", "Some Error Occured");
			}
			
			
			// digitalLifeVerificationVO.setRequestId(3966);
			digiLifeVeriPO.setContractid(digitalLifeVerificationvo.getContractid());
			//String errorMsg= digiLifeVeriValidator.validateDigiLifeVeriForm(digiLifeVeriPO,context);
			String errorMsg=null;
			
			List<UploadFilePO> uploadFilePOList=(List<UploadFilePO>)digiLifeVeriPO.getUploadFileList();	
			
			if(CollectionUtils.isEmpty(uploadFilePOList)){
				FLogger.error(INFO_LOGGER_NAME,CLASS_NAME ,METHOD_NAME , "FileUpload request should not be null");
				throw new IPruException("Error", "GRPSCI01", "Please Upload File");
				
			}else {
			
				String checkFileUploadStatus=commonFileUploadUtil.checkUploadFileContent(uploadFilePOList, context,INFO_LOGGER_NAME);
				if(!StringUtils.isEmpty(checkFileUploadStatus))
				{
					throw new IPruException("Error", "GRPSWP01", checkFileUploadStatus);
				}
			}
			if (StringUtils.isNotBlank(errorMsg)) {
				this.setValidationErrorMessages(errorMsg);
				FLogger.error(INFO_LOGGER_NAME,CLASS_NAME ,METHOD_NAME , "Data from request should not be null");
				throw new IPruException("Error", "GRPSCI01", errorMsg);
		}
			
			DigitalLifeVerificationVO digiLifeVeriVO  = dozerBeanMapper.map(digiLifeVeriPO,DigitalLifeVerificationVO.class);
			
			 digiLifeVeriVO=getFunctionality(context,digiLifeVeriVO);
			

			Object[] paramArray = new Object[1];
				paramArray[0] = digiLifeVeriVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1",paramArray);
			context.getFlowScope().put("submitDigiLifeSpaarCall", obj_bizReq);
			
		}
		else
		{
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "request should not be null");
			throw new IPruException("Error", "GRPSCI01",
					"context should not be null");
		}
		return success();
		
	}

	@MethodPost
	public Event getResSubmitForDigiLifeSpaarcCall(RequestContext context) throws Exception {
		final String METHOD_NAME = "getResForInitiateSpaarcCall";
		try{
			BizResponse bizRes = new BizResponse();
			HttpSession httpSession=((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			bizRes = (BizResponse) context.getFlowScope().get("bizResSubmitForDigiLifeSpaarcCall");
			if(bizRes!=null)
			{
				DigitalLifeVerificationVO digiLifeVeriResVO = (DigitalLifeVerificationVO) bizRes.getTransferObjects().get("response1");
				httpSession.setAttribute("digiLifeVeriResVO", digiLifeVeriResVO);
			}
			else
			{
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "Context should not be null");
				throw new IPruException("Error", "GRPSCI01",
						"context should not be null");
			}
		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSCI01", context);
		}
		return success();
	}
	
	public void setOtpDetailsInSession(RequestContext context,DigitalLifeVerificationVO digitalLifeVerification) throws Exception {

		if (context != null) {
			 
			IPruUser userVo = (IPruUser) GroupSecurityUtil.getAttributeFromSession(context, "userVO");
			if (userVo != null && digitalLifeVerification != null) {
				
				String phoneMobile = String.valueOf(digitalLifeVerification.getPhonemobile());
				userVo.setMobileNo(phoneMobile);
				userVo.setPolicyNo(digitalLifeVerification.getPolicyid());
				userVo.setClientId(digitalLifeVerification.getContractid());
				GroupSecurityUtil.setAttributeInSession(context, "userVO", userVo);
			}
		}

	
	}
	
	@MethodGet
	public Event getReqprePopulateDetails(RequestContext context) throws Exception {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizDecryptedData", "Method start");

		DigitalLifeVerificationVO response = null;

		response = (DigitalLifeVerificationVO) context.getConversationScope().get("digitalLifeVerificationData");

		context.getFlowScope().put("Response", gsonJSON.toJson(response));

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizDecryptedData", "Method end");

		return success();
	}
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		final String METHOD_NAME = "setOtpCallBacks";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		paramBean.setFunctionality("digitalForm");
		setTransactionalOTPCallback(Boolean.TRUE);
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		// TODO Auto-generated method stub
	}
	
	public DigitalLifeVerificationVO getFunctionality(RequestContext context,DigitalLifeVerificationVO digitalLifeVerificationVo)
	{
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getFunctionality", "Method start");
		FunctionalityMasterVO functionality = getFunctionality(context);
		digitalLifeVerificationVo.setFunctionality(functionality);
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getFunctionality", "Method end");
		
		return digitalLifeVerificationVo;
	}
	
	


}
