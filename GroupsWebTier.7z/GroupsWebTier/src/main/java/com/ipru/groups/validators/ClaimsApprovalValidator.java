package com.ipru.groups.validators;

import java.text.ParseException;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.joda.time.Years;

import com.ipru.IPruException;
import com.ipru.groups.po.ClaimsApprovalPO;
import com.ipru.groups.po.ClaimsRequestTransactionPO;
import com.tcs.logger.FLogger;

public class ClaimsApprovalValidator {

	private final StringBuilder errorMessageBuilder = new StringBuilder(1);
	Years age = null;

	public String validateApproval(List<ClaimsRequestTransactionPO> claimsRequestTransactionPOList, String memberType,String productType) throws IPruException ,ParseException{
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalValidator", "validateApproval", "method start");
		errorMessageBuilder.setLength(0);

		if (claimsRequestTransactionPOList != null && StringUtils.isNotBlank(memberType)) {
			if (!memberType.equals("TRUST") && productType.equals("Gratuity")) {
				FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalValidator", "validateApproval", "Invalid Login");				
				throw new IPruException("Error", "GRPPFCC", "Invalid Login");
			}
			for (ClaimsRequestTransactionPO claimsRequestTransactionPO : claimsRequestTransactionPOList) {
				if (!claimsRequestTransactionPO.getApprovalStatus().equals("PENDING")) {
					FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalValidator", "validateApproval", "Incorrect claims has been selected");					
					throw new IPruException("Error", "GRPPFCC", "Incorrect claims has been selected");
				}
			}

		}
		else {
			FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalValidator", "validateApproval", "claimsApprovalPOList and role should not be null");
			throw new IPruException("Error", "GRPPFCC", "claimsApprovalPOList and role should not be null");
		}

		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalValidator", "validateApproval", "method end");
		return null;
	}

}
