package com.ipru.groups.handler;

import java.io.BufferedReader;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dozer.util.ReflectionUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.generic.po.ResultJsonPO;
import com.ipru.groups.po.AuthoritySignatoryChangePO;
import com.ipru.groups.po.CompanyAddressChangePO;
import com.ipru.groups.po.ContactPersonChangePO;
import com.ipru.groups.po.DropDownObjPO;
import com.ipru.groups.po.FieldAccessMappingPO;
import com.ipru.groups.po.MemberAddTraditionalPO;
import com.ipru.groups.po.ProfileUpdateDetailsPo;
import com.ipru.groups.po.ProfileUpdateLoadRequestDetailsPO;
import com.ipru.groups.po.ProfileUpdateLoadRequestPO;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.po.profileupdate.AuthoritySignatoryPO;
import com.ipru.groups.po.profileupdate.CompanyAddressPO;
import com.ipru.groups.po.profileupdate.ContactPersonPO;
import com.ipru.groups.po.profileupdate.FieldMeta;
import com.ipru.groups.profile.bean.ProfilePOCPO;
import com.ipru.groups.utilities.CommonFileUploadUtil;
import com.ipru.groups.utilities.GroupCommonUtils;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.utilities.ProfileUpdateUtil;
import com.ipru.groups.validators.ProfileUpdateValidator;
import com.ipru.groups.vo.DropDownObjVO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.ProfileUpdateDetailsVo;
import com.ipru.groups.vo.ProfileUpdateLoadRequestDetailsVO;
import com.ipru.groups.vo.ProfileUpdateLoadRequestVO;
import com.ipru.groups.vo.ProfileUpdateTranscationVO;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.groups.vo.UploadFileVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ProfileUpdateHandler extends IneoBaseHandler {

	public static final String ErrorMsg = "Something Went Wrong Please Try Again!";

	private static final long serialVersionUID = 1L;


	@MethodPost
	public Event getBizRequestloadProfileUpdateAccessMatrix(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadProfileUpdateAccessMatrix", "getBizRequestloadProfileUpdateAccessMatrix Method Start ");

		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;

			fieldAccessMappingVoList = getFieldAccessMappingList(context);
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String screenName = null;
			List<RoleScreenAccessMappingVO> accessMappingList;

				screenName = (String) context.getFlowScope().get("screenName3");

				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null && screenName != null && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {  
					policyNo = userVo.getPolicyNo();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadProfileUpdateAccessMatrix", "When page load Policy No in session : " + policyNo);
					role = userVo.getRoles();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadProfileUpdateAccessMatrix", "When page load role in session : " + role);
					accessMappingList = userVo.getLstRoleScreenAccessMapping();

					ProfileUpdateLoadRequestPO profileUpdateLoadRequestPO = new ProfileUpdateLoadRequestPO();
					profileUpdateLoadRequestPO.setPolicyNo(policyNo);
					profileUpdateLoadRequestPO.setRole(role);
					profileUpdateLoadRequestPO.setScreenName(screenName);
					ProfileUpdateLoadRequestVO profileUpdateLoadRequestVO = null;
					if (profileUpdateLoadRequestPO != null) {
						profileUpdateLoadRequestVO = dozerBeanMapper.map(profileUpdateLoadRequestPO, ProfileUpdateLoadRequestVO.class);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadProfileUpdateAccessMatrix", "profileUpdateLoadRequestPO  is null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

					if (profileUpdateLoadRequestVO != null) {
						if (CollectionUtils.isNotEmpty(accessMappingList) && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {
							profileUpdateLoadRequestVO.setAccessMappingList(accessMappingList);
							profileUpdateLoadRequestVO.setFieldAccessMappingList(fieldAccessMappingVoList);
							Object[] paramArray = new Object[1];
							paramArray[0] = profileUpdateLoadRequestVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("loadProfileUpdateMatrixBizReq", obj_bizReq);
						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadProfileUpdateAccessMatrix", "accessMappingList and  fieldAccessMappingVoList is null");

							throw new IPruException("Error", "GPU01", ErrorMsg);
						}

							}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadProfileUpdateAccessMatrix", "UserVo  is null");

						throw new IPruException("Error", "GPU01", ErrorMsg);
					}
				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadProfileUpdateAccessMatrix", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");

					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadProfileUpdateAccessMatrix", "Exception Occured ", e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadProfileUpdateAccessMatrix", "getBizRequestloadProfileUpdateAccessMatrix Method End ");

		return success();
	}

	@MethodPost
	public Event getBizResponseloadProfileUpdateAccessMatrix(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadProfileUpdateAccessMatrix", "getBizResponseloadProfileUpdateAccessMatrix Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateLoadRequestDetailsVO profileUpdateLoadRequestDetailsVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {
			bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadProfileUpdateAccessMatrix");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {
					profileUpdateLoadRequestDetailsVO = (ProfileUpdateLoadRequestDetailsVO) bizRes.getTransferObjects().get("response1");
					if (profileUpdateLoadRequestDetailsVO != null) {
						ProfileUpdateLoadRequestDetailsPO profileUpdateLoadRequestDetailsPO = dozerBeanMapper.map(profileUpdateLoadRequestDetailsVO, ProfileUpdateLoadRequestDetailsPO.class);
						if (profileUpdateLoadRequestDetailsPO != null) {
							List<ProfilePOCPO> data = new ArrayList<ProfilePOCPO>();

							Map<String, FieldAccessMappingPO> map = profileUpdateLoadRequestDetailsPO.getFieldAccessMappingMap();
							if (!map.isEmpty() && map != null && prop != null) {

								ResultJsonPO resultMap = new ResultJsonPO();

								resultMap.setResultMap(map);
								resultJson = gsonJSON.toJson(resultMap);
								context.getFlowScope().put("Response", resultJson);

							}
							else {
								throw new IPruException("Error", "GPU01", ErrorMsg);
							}

						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadProfileUpdateAccessMatrix", "map should not be null");
							throw new IPruException("Error", "GPU01", ErrorMsg);
						}
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadProfileUpdateAccessMatrix", "getBizResponseloadProfileUpdateAccessMatrix should not be null");
						throw new IPruException("Error", "GPU01", ErrorMsg);

					}

				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadProfileUpdateAccessMatrix", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadProfileUpdateAccessMatrix", "Exception Occured ",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadProfileUpdateAccessMatrix", "getBizResponseloadProfileUpdateAccessMatrix Method End");

		return success();
	}

	@MethodPost
	public Event getBizRequestForProfileCompanyAddressDetailsAccessMatrix(RequestContext context) throws Exception {
		
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix Method Start ");

		try {
			
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;

			fieldAccessMappingVoList = getFieldAccessMappingList(context);
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String screenName = null;
			List<RoleScreenAccessMappingVO> accessMappingList;

			if (httpSession != null) {
				screenName = (String) context.getFlowScope().get("screenName");

				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null && screenName != null && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {
					policyNo = userVo.getPolicyNo();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix", "When page load Policy No in session : " + policyNo);
					role = userVo.getRoles();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix", "When page load role in session : " + role);
					accessMappingList = userVo.getLstRoleScreenAccessMapping();

					ProfileUpdateLoadRequestPO profileUpdateLoadRequestPO = new ProfileUpdateLoadRequestPO();
					profileUpdateLoadRequestPO.setPolicyNo(policyNo);
					profileUpdateLoadRequestPO.setRole(role);
					profileUpdateLoadRequestPO.setScreenName(screenName);
					ProfileUpdateLoadRequestVO profileUpdateLoadRequestVO = null;
					if (profileUpdateLoadRequestPO != null) {
						profileUpdateLoadRequestVO = dozerBeanMapper.map(profileUpdateLoadRequestPO, ProfileUpdateLoadRequestVO.class);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix", "profileUpdateLoadRequestPO  is null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

					if (profileUpdateLoadRequestVO != null) {
						if (CollectionUtils.isNotEmpty(accessMappingList) && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {
							profileUpdateLoadRequestVO.setAccessMappingList(accessMappingList);
							profileUpdateLoadRequestVO.setFieldAccessMappingList(fieldAccessMappingVoList);
							Object[] paramArray = new Object[1];
							paramArray[0] = profileUpdateLoadRequestVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("loadCompanyAddressAxcessMatrixBizReq", obj_bizReq);
						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix", "accessMappingList and  fieldAccessMappingVoList is null");

							throw new IPruException("Error", "GPU01", ErrorMsg);
						}

					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix", "UserVo  is null");

						throw new IPruException("Error", "GPU01", ErrorMsg);
					}
				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");

					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix", "session is null");

				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix", "getBizRequestForProfileCompanyAddressDetailsAccessMatrix Method End ");

		return success();
	}

	@MethodPost
	public Event getBizResponseForProfilCompanyAddressDetailsAccessMatrix(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilCompanyAddressDetailsAccessMatrix", "getBizResponseForProfilCompanyAddressDetailsAccessMatrix Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateLoadRequestDetailsVO profileUpdateLoadRequestDetailsVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {
			bizRes = (BizResponse) context.getFlowScope().get("bizResForProfileCompanyAddressDetailsAccessMatrix");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {
					profileUpdateLoadRequestDetailsVO = (ProfileUpdateLoadRequestDetailsVO) bizRes.getTransferObjects().get("response1");
					if (profileUpdateLoadRequestDetailsVO != null) {
						ProfileUpdateLoadRequestDetailsPO profileUpdateLoadRequestDetailsPO = dozerBeanMapper.map(profileUpdateLoadRequestDetailsVO, ProfileUpdateLoadRequestDetailsPO.class);
						if (profileUpdateLoadRequestDetailsPO != null) {
							Map<String, FieldAccessMappingPO> map = profileUpdateLoadRequestDetailsPO.getFieldAccessMappingMap();

							if (!map.isEmpty() && map != null && prop != null) {

								ResultJsonPO resultMap = new ResultJsonPO();
								context.getFlowScope().put("companyAddressRoleAccessMatrix", map);
								resultMap.setResultMap(map);
								resultJson = gsonJSON.toJson(resultMap);
								context.getFlowScope().put("Response", resultJson);

							}
							else {
								throw new IPruException("Error", "GPU01", ErrorMsg);
							}

						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilCompanyAddressDetailsAccessMatrix", "map should not be null");
							throw new IPruException("Error", "GPU01", ErrorMsg);
						}
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilCompanyAddressDetailsAccessMatrix", "profileUpdateLoadRequestDetailsPO should not be null");
						throw new IPruException("Error", "GPU01", ErrorMsg);

					}

				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilCompanyAddressDetailsAccessMatrix", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilCompanyAddressDetailsAccessMatrix", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilCompanyAddressDetailsAccessMatrix", "getBizResponseForProfilCompanyAddressDetailsAccessMatrix Method End");

		return success();
	}

	@MethodPost
	public Event getBizRequestForProfileCompanyAdressAccessDetails(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAdressAccessDetails", "getBizRequestForProfileCompanyAdressAccessDetails Method Start ");

		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;

			fieldAccessMappingVoList = getFieldAccessMappingList(context);
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String screenName = null;
			List<RoleScreenAccessMappingVO> accessMappingList;

			if (httpSession != null) {
				screenName = (String) context.getFlowScope().get("screenName");

				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null && screenName != null && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {
					policyNo = userVo.getPolicyNo();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAdressAccessDetails", "When page load Policy No in session : " + policyNo);
					role = userVo.getRoles();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAdressAccessDetails", "When page load role in session : " + role);
					accessMappingList = userVo.getLstRoleScreenAccessMapping();

					ProfileUpdateLoadRequestPO profileUpdateLoadRequestPO = new ProfileUpdateLoadRequestPO();
					profileUpdateLoadRequestPO.setPolicyNo(policyNo);
					profileUpdateLoadRequestPO.setRole(role);
					profileUpdateLoadRequestPO.setScreenName(screenName);
					ProfileUpdateLoadRequestVO profileUpdateLoadRequestVO = null;
					if (profileUpdateLoadRequestPO != null) {
						profileUpdateLoadRequestVO = dozerBeanMapper.map(profileUpdateLoadRequestPO, ProfileUpdateLoadRequestVO.class);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAdressAccessDetails", "profileUpdateLoadRequestPO  is null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

					if (profileUpdateLoadRequestVO != null) {
						if (CollectionUtils.isNotEmpty(accessMappingList) && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {
							profileUpdateLoadRequestVO.setAccessMappingList(accessMappingList);
							profileUpdateLoadRequestVO.setFieldAccessMappingList(fieldAccessMappingVoList);
							Object[] paramArray = new Object[1];
							paramArray[0] = profileUpdateLoadRequestVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("loadCompanyAddressBizReq", obj_bizReq);
						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAdressAccessDetails", "accessMappingList and  fieldAccessMappingVoList is null");

							throw new IPruException("Error", "GPU01", ErrorMsg);
						}

					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAdressAccessDetails", "UserVo  is null");

						throw new IPruException("Error", "GPU01", ErrorMsg);
					}
				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAdressAccessDetails", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");

					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAdressAccessDetails", "session is null");

				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAdressAccessDetails", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileCompanyAdressAccessDetails", "getBizRequestForProfileCompanyAdressAccessDetails Method End ");

		return success();
	}

	@MethodPost
	public Event getBizResponseForProfilCompanyAdressAccessDetails(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilCompanyAdressAccessDetails", "getBizResponseForProfilCompanyAdressAccessDetails Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;

		long functionalityId = this.getFunctionalityId(context);
		String resultJson = "";

		try {

			Map<String, FieldAccessMappingPO> map = (Map<String, FieldAccessMappingPO>) context.getFlowScope().get("companyAddressRoleAccessMatrix");
			boolean flag = false;
			if (!map.isEmpty() && prop != null) {

				CompanyAddressPO companyAddressPO = new CompanyAddressPO();
				companyAddressPO = (CompanyAddressPO) createProfileUpdatePO(companyAddressPO, null, map, flag);
				companyAddressPO.setFunctionalityId(functionalityId);
				if (companyAddressPO != null) {
					resultJson = gsonJSON.toJson(companyAddressPO);
					context.getFlowScope().put("Response", resultJson);
				}

			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilCompanyAdressAccessDetails", "map should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilCompanyAdressAccessDetails", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilCompanyAdressAccessDetails", "getBizResponseForProfilCompanyAdressAccessDetails Method End");

		return success();
	}

	@MethodPost
	public Event getBizRequestForProfilePrePopulateCompanyAdressDetails(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateCompanyAdressDetails", "getBizRequestForProfilePrePopulateCompanyAdressDetails Method Start");

		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String clientId=null;
			String screenName = null;
			if (httpSession != null) {
				screenName = (String) context.getFlowScope().get("screenName");

				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null && screenName != null) {
					policyNo = userVo.getPolicyNo();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateCompanyAdressDetails", "When page load Policy No in session : " + policyNo);
					clientId = userVo.getClientId();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateCompanyAdressDetails", "When page load role in session : " + role);

					ProfileUpdateLoadRequestPO profileUpdateLoadRequestPO = new ProfileUpdateLoadRequestPO();
					profileUpdateLoadRequestPO.setPolicyNo(policyNo);
					/*profileUpdateLoadRequestPO.setRole(role);*/
					profileUpdateLoadRequestPO.setClientId(clientId);
					profileUpdateLoadRequestPO.setScreenName(screenName);
					ProfileUpdateLoadRequestVO profileUpdateLoadRequestVO = null;
					if (profileUpdateLoadRequestPO != null) {
						profileUpdateLoadRequestVO = dozerBeanMapper.map(profileUpdateLoadRequestPO, ProfileUpdateLoadRequestVO.class);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateCompanyAdressDetails", "profileUpdateLoadRequestPO  is null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

					if (profileUpdateLoadRequestVO != null) {

						Object[] paramArray = new Object[1];
						paramArray[0] = profileUpdateLoadRequestVO;
						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);

						context.getFlowScope().put("prePopulateCompanyAddressBizReq", obj_bizReq);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateCompanyAdressDetails", "accessMappingList and  fieldAccessMappingVoList is null");

						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateCompanyAdressDetails", "UserVo  is null");

					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateCompanyAdressDetails", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");

				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateCompanyAdressDetails", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateCompanyAdressDetails", "getBizRequestForProfilePrePopulateCompanyAdressDetails Method End ");

		return success();
	}

	@MethodPost
	public Event getBizResponseForProfilPrePopulateCompanyAdressDetails(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateCompanyAdressDetails", "getBizResponseForProfilPrePopulateCompanyAdressDetails Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateLoadRequestDetailsVO profileUpdateLoadRequestDetailsVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {

			bizRes = (BizResponse) context.getFlowScope().get("bizResForProfilePrePopulateCompanyAdressDetails");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					Map<String, FieldAccessMappingPO> map = (Map<String, FieldAccessMappingPO>) context.getFlowScope().get("companyAddressRoleAccessMatrix");
					List<CompanyAddressPO> prePoulatecompanyAddressPOList = new LinkedList();
					profileUpdateLoadRequestDetailsVO = (ProfileUpdateLoadRequestDetailsVO) bizRes.getTransferObjects().get("response1");
					if (profileUpdateLoadRequestDetailsVO != null && !map.isEmpty()) {
						ProfileUpdateLoadRequestDetailsPO profileUpdateLoadRequestDetailsPO = dozerBeanMapper.map(profileUpdateLoadRequestDetailsVO, ProfileUpdateLoadRequestDetailsPO.class);
						if (profileUpdateLoadRequestDetailsPO != null) {
							List<CompanyAddressChangePO> CompanyAddressChangePOList = new LinkedList();
							CompanyAddressChangePOList = (List<CompanyAddressChangePO>) profileUpdateLoadRequestDetailsPO.getProfileCompanyAddressVOList();
							context.getFlowScope().put("CompanyAddressChangePOList", CompanyAddressChangePOList);
						//	List containAddressType = new ArrayList();

							boolean flag = true;

							if (CollectionUtils
									.isNotEmpty(CompanyAddressChangePOList)) {
								for (CompanyAddressChangePO companyAddressChangePO : CompanyAddressChangePOList) {
									CompanyAddressPO companyAddressPO = new CompanyAddressPO();
									companyAddressPO = (CompanyAddressPO) createProfileUpdatePO(companyAddressPO, companyAddressChangePO, map, flag);
									companyAddressPO.setPrePopulateList(companyAddressChangePO.getAddressType() + " "+companyAddressChangePO.getCompanyOrBuildingName() + " "+ companyAddressChangePO.getFlatOrUnitNumber() + " " + companyAddressChangePO.getStreetOrArea() + " " + companyAddressChangePO.getLandmark() + " "+companyAddressChangePO.getPincode() + " " +companyAddressChangePO.getCity() +" "+companyAddressChangePO.getState());
									//containAddressType.add(companyAddressChangePO.getAddressType());
									prePoulatecompanyAddressPOList.add(companyAddressPO);
								}

								//context.getFlowScope().put("containAddressType", containAddressType);

								for (int i = 0; i < CompanyAddressChangePOList.size(); i++) {
									CompanyAddressChangePO CompanyAddressChangePO = CompanyAddressChangePOList.get(i);

								}
							}
							if (CollectionUtils.isNotEmpty(prePoulatecompanyAddressPOList)) {
								resultJson = gsonJSON.toJson(prePoulatecompanyAddressPOList);

								context.getFlowScope().put("Response", resultJson);
							}
							else {
								FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateCompanyAdressDetails", "prePoulatecompanyAddressPOList should not be null");
								throw new IPruException("Error", "GPU01", ErrorMsg);
							}
						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateCompanyAdressDetails", "CompanyAddressChangePOList should not be null");
							throw new IPruException("Error", "GPU01", ErrorMsg);
						}

					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateCompanyAdressDetails", "profileUpdateLoadRequestDetailsPO should not be null");
						throw new IPruException("Error", "GPU01", ErrorMsg);

					}
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateCompanyAdressDetails", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateCompanyAdressDetails", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateCompanyAdressDetails", "getBizResponseForProfileAccessDetails Method End");

		return success();
	}

	@MethodPost
	public Event getBizRequestforSubmitCompanyAddressChange(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "getBizRequestforSubmitCompanyAddressChange Method Start");
		CommonFileUploadUtil commonFileUploadUtil=new CommonFileUploadUtil();

		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateUtil utility = new ProfileUpdateUtil();
		String validation = null;
		FunctionalityMasterVO functionality;
	
		// long functionalityId=0;
		List<UploadFilePO> uploadFilePOList = null;

		try {
			functionality = this.getFunctionality(p_ObjContext);
			// functionalityId = this.getFunctionalityId(p_ObjContext);
			if (functionality == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "functionalityId Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			Map<String, FieldAccessMappingVO> map = (Map<String, FieldAccessMappingVO>) p_ObjContext.getFlowScope().get("companyAddressRoleAccessMatrix");
			if (map.isEmpty()) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "map Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

			//ArrayList<String> containAddressTypeFromPrePopulate = ((ArrayList<String>) p_ObjContext.getFlowScope().get("containAddressType"));

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			ProfileUpdateDetailsPo po = null;
			StringBuffer jb = new StringBuffer();
			String line = null;

			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}

			List<ProfileUpdateDetailsPo> poValidateData = new ArrayList<ProfileUpdateDetailsPo>(1);
			CompanyAddressPO companyAddressPO = gsonJSON.fromJson(jb.toString(), CompanyAddressPO.class);

			if (companyAddressPO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "CompanyAddressPO Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			if (CollectionUtils.isEmpty(companyAddressPO.getUploadFiles())) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "companyAddressPO Should not be null");
				throw new IPruException("Error", "GPU01", "Please Upload AtLeast One File !");

			}

			uploadFilePOList = companyAddressPO.getUploadFiles();
			
			String checkFileUploadStatus=commonFileUploadUtil.checkUploadFileContent(uploadFilePOList,p_ObjContext,"PROFILEUPDATELogger");
			
			if(!StringUtils.isEmpty(checkFileUploadStatus))
			{
				throw new IPruException("Error", "GPU01", checkFileUploadStatus);
			}
			
			if (companyAddressPO.getAddressType() == null && companyAddressPO.getCompanyOrBuildingName() == null && companyAddressPO.getFlatOrUnitNumber() == null
					&& companyAddressPO.getStreetOrArea() == null && companyAddressPO.getLandmark() == null && companyAddressPO.getPincode() == null && companyAddressPO.getCity() == null
					&& companyAddressPO.getState() == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "companyAddressPO Fields Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			/*if(CollectionUtils.isNotEmpty(containAddressTypeFromPrePopulate))
			{
			if (containAddressTypeFromPrePopulate.contains(companyAddressPO.getAddressType().getNewValue().toString())) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "Can not add multiple record with same address Tyep");
				throw new IPruException("Error", "GPU01", "Not Allowed Multiple Record With Same Address Type");
			}
			}*/

	
			poValidateData.add(getFieldNewValueList(companyAddressPO.getAddressType().getNewValue(), companyAddressPO.getAddressType().getFieldId()));
			poValidateData.add(getFieldNewValueList(companyAddressPO.getCompanyOrBuildingName().getNewValue(), companyAddressPO.getCompanyOrBuildingName().getFieldId()));
			poValidateData.add(getFieldNewValueList(companyAddressPO.getFlatOrUnitNumber().getNewValue(), companyAddressPO.getFlatOrUnitNumber().getFieldId()));
			poValidateData.add(getFieldNewValueList(companyAddressPO.getStreetOrArea().getNewValue(), companyAddressPO.getStreetOrArea().getFieldId()));
			poValidateData.add(getFieldNewValueList(companyAddressPO.getLandmark().getNewValue(), companyAddressPO.getLandmark().getFieldId()));
			poValidateData.add(getFieldNewValueList(companyAddressPO.getPincode().getNewValue(), companyAddressPO.getPincode().getFieldId()));
			poValidateData.add(getFieldNewValueList(companyAddressPO.getCity().getNewValue(), companyAddressPO.getCity().getFieldId()));
			poValidateData.add(getFieldNewValueList(companyAddressPO.getState().getNewValue(), companyAddressPO.getState().getFieldId()));
			//poValidateData.add(getFieldNewValueList(companyAddressPO.getAddressproof().getNewValue(), companyAddressPO.getAddressproof().getFieldId()));

			if (CollectionUtils.isEmpty(poValidateData)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "companyAddressPO Should not be null");
				throw new IPruException("Error", "GPU01", "Please Filled All Mandatory Fields! ");

			}
			
			String checkMandatoryresult = utility.checkMandatoryFields(poValidateData, map);
			if (StringUtils.isNotEmpty(checkMandatoryresult)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "checkMandatoryresult" + checkMandatoryresult);
				throw new IPruException("Error", "GPU01", checkMandatoryresult);
			}

			ProfileUpdateValidator validator = new ProfileUpdateValidator();
			if (validator == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "validator Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			validation = validator.ValidateProfileCompanyAddressDetails(poValidateData, p_ObjContext, map);

			if (StringUtils.isNotBlank(validation)) {
				// ////System.out.println("Validation "+validation);
				// this.setValidationErrorMessages(validation);
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "Validation Error" + validation);
				// throwINeoFlowException(new
				// ServiceException("GPU01"),"GPU01",p_ObjContext);
				throw new IPruException("Error", "GPU01", validation);
			}

			ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
			List<ProfileUpdateDetailsVo> voList = new ArrayList<ProfileUpdateDetailsVo>();

			for (int i = 0; i < poValidateData.size(); i++) {
				profileUpdateDetailsVo = new ProfileUpdateDetailsVo();

				dozerBeanMapper.map((ProfileUpdateDetailsPo) poValidateData.get(i),
						profileUpdateDetailsVo);

				voList.add(profileUpdateDetailsVo);

			}
			if (CollectionUtils.isEmpty(voList)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "voList Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			if (utility == null && prop == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "map Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			ProfileUpdateTranscationVO profileUpdateTranscationVO = utility.getProfileUpdateData(map, voList, p_ObjContext, functionality);

			if (profileUpdateTranscationVO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "profileUpdateTranscationVO Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

			UploadFileVO uploadFileVO = null;

			List<UploadFileVO> UploadFileDetails = new ArrayList();
			if (CollectionUtils.isNotEmpty(uploadFilePOList)) {
				for (int i = 0; i < uploadFilePOList.size(); i++) {

					UploadFilePO uploadFilePO = uploadFilePOList.get(i);
					String documentName = uploadFilePO.getDocName();
					long docSize = uploadFilePO.getDocSize();
					int dot = documentName.lastIndexOf(".");
					String docType=uploadFilePO.getDocFileType();
					
					String extension = documentName.substring(dot + 1);
					
				/*	if (!((docType.equalsIgnoreCase("PDF") || docType.equalsIgnoreCase("JPEG") || docType.equalsIgnoreCase("TIFF") || docType.equalsIgnoreCase("JPG")))) {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "File Should be JPEG or PDF or TIFF and size should be less than 2MB");
						throw new IPruException("Error", "GPU01", "File Should be JPEG or PDF or TIFF and size should be less than 5 MB");
					}
					*/
					
					if ((extension.equalsIgnoreCase("PDF") || extension.equalsIgnoreCase("JPEG") || extension.equalsIgnoreCase("TIFF") || extension.equalsIgnoreCase("JPG"))
							&& (docSize <= Long.parseLong(prop.getProperty("fiveMb")))) {
						uploadFileVO = new UploadFileVO();
						dozerBeanMapper.map((UploadFilePO) uploadFilePOList.get(i),
								uploadFileVO);
						UploadFileDetails.add(uploadFileVO);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "File Should be JPEG or PDF or TIFF and size should be less than 2MB");
						throw new IPruException("Error", "GPU01", "File Should be JPEG or PDF or TIFF and size should be less than 5 MB");
					}
				}
			}
			else {
				throw new IPruException("Error", "GPU01", "Please Upload File And Size Should Be Less Than 5 MB");

			}

			profileUpdateTranscationVO.setGetUploadFileVOList(UploadFileDetails);

			if (profileUpdateTranscationVO.getGetUploadFileVOList() == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "profileUpdateTranscationVO.getGetUploadFileVOList should not be null");
				throw new IPruException("Error", "GPU01", "Please Upload File");
			}

			if (profileUpdateTranscationVO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "profileUpdateTranscationVO not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			Object[] paramArray = new Object[1];
			paramArray[0] = profileUpdateTranscationVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {

			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", p_ObjContext);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "getBizRequestforSubmitCompanyAddressChange Method End");
		return success();

	}

	@SuppressWarnings({ "unchecked", "unused" })
	private <T extends Serializable> T createPoJO(T frontendPO) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "createPoJO", "createPoJO Method Start");
		Class<T> functChangeClass = null;
		Class<T> frontendClass = (Class<T>) frontendPO.getClass();
		Field[] fields = frontendClass.getDeclaredFields();
		for (Field field : fields) {
			if (field.getType() == FieldMeta.class) {

				String fieldName = field.getName().substring(0, 1).toUpperCase() + field.getName().substring(1);
				Method getterMethod = null;

				try {

					Class<? extends Field> className = field.getClass();
					Field[] fields2 = className.getDeclaredFields();
					for (Field field2 : fields) {
						//System.out.println(fields2);
					}

				}
				catch (Exception e) {
					
					FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "createPoJO", "Exception Came",e);
					// TODO: Flogger
						}
			}
			else
				continue;
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "createPoJO", "createPoJO Method Start");
		return frontendPO;

	}

	@MethodPost
	public Event getBizResponseforSubmitCompanyAddressChange(RequestContext context) throws Exception {
		// ////System.out.println("In handler: getBizResponseforSubmitBankAccountDetailsChange : Response method");
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitCompanyAddressChange", "getBizResponseforSubmitCompanyAddressChange Method Start");
		String responseCheck = "";
		String serviceResponse = null;
		boolean response = false;
		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForProfileCompanyAdress");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					response = (Boolean) bizRes.getTransferObjects().get("response1");
					if (response)
						serviceResponse = "Record Inserted Successfully!";
					else
						serviceResponse = "Error Occured While Inserting Record Please Try Again!";
					context.getFlowScope().put("Response", serviceResponse);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "PrlofileUpdateHandler", "getBizResponseforSubmitCompanyAddressChange", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitCompanyAddressChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforSubmitCompanyAddressChange", "getBizResponseforSubmitCompanyAddressChange Method End");
		return success();

	}

	@MethodPost
	public Event getBizRequestforEditCompanyAddressChangeSubmit(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "getBizRequestforEditCompanyAddressChangeSubmit Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateUtil utility = new ProfileUpdateUtil();
		FunctionalityMasterVO functionality;
		List<ProfileUpdateDetailsPo> poValidateData = new ArrayList<ProfileUpdateDetailsPo>(1);
		List<ProfileUpdateDetailsPo> poData = new ArrayList<ProfileUpdateDetailsPo>();
		List<UploadFilePO> uploadFilePOList = null;

		try {
			Map<String, FieldAccessMappingVO> map = (Map<String, FieldAccessMappingVO>) p_ObjContext.getFlowScope().get("companyAddressRoleAccessMatrix");
			if (map.isEmpty()) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "Edit companyAddressPO should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			functionality = this.getFunctionality(p_ObjContext);

			if (functionality == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "functionalityId should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			StringBuffer jb = new StringBuffer();
			String line = null;
			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}
			CompanyAddressPO companyAddressPO = gsonJSON.fromJson(jb.toString(), CompanyAddressPO.class);

			if (companyAddressPO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "Edit companyAddressPO should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			int index = Integer.parseInt(companyAddressPO.getIndex());

			if (index < 0) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "index  should greater than Zero");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			if (CollectionUtils.isEmpty(companyAddressPO.getUploadFiles())) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "UploadFilePOList  should not be null");
				throw new IPruException("Error", "GPU01", "Please Upload AtLeast One File !");
			}

			uploadFilePOList = companyAddressPO.getUploadFiles();

			List<CompanyAddressChangePO> companyAddressPOListFromSesssion = (List<CompanyAddressChangePO>) p_ObjContext.getFlowScope().get("CompanyAddressChangePOList");

			if (CollectionUtils.isEmpty(companyAddressPOListFromSesssion)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "companyAddressPOListFromSesssion should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}
			if (companyAddressPO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "companyAddressPO should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

			if (companyAddressPO.getAddressType() == null && companyAddressPO.getCompanyOrBuildingName() == null && companyAddressPO.getFlatOrUnitNumber() == null
					&& companyAddressPO.getStreetOrArea() == null && companyAddressPO.getLandmark() == null && companyAddressPO.getPincode() == null && companyAddressPO.getCity() == null
					&& companyAddressPO.getState() == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "companyAddressPO Fields Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			CompanyAddressChangePO companyAddressChangePO = companyAddressPOListFromSesssion.get(index);

			if (companyAddressChangePO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "companyAddressChangePO  should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			poData.add(getEditFieldNewValueList(String.valueOf(companyAddressPO.getAddressType().getNewValue()), String.valueOf(companyAddressPO.getAddressType().getFieldId()), String.valueOf(companyAddressChangePO.getAddressType().toString()), String.valueOf(companyAddressChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(companyAddressPO.getCompanyOrBuildingName().getNewValue()), String.valueOf(companyAddressPO.getCompanyOrBuildingName().getFieldId()), String.valueOf(companyAddressChangePO.getCompanyOrBuildingName()), String.valueOf(companyAddressChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(companyAddressPO.getFlatOrUnitNumber().getNewValue()), String.valueOf(companyAddressPO.getFlatOrUnitNumber().getFieldId()), String.valueOf(companyAddressChangePO.getFlatOrUnitNumber()), String.valueOf(companyAddressChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(companyAddressPO.getStreetOrArea().getNewValue()), String.valueOf(companyAddressPO.getStreetOrArea().getFieldId()), String.valueOf(companyAddressChangePO.getStreetOrArea()), String.valueOf(companyAddressChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(companyAddressPO.getLandmark().getNewValue()), String.valueOf(companyAddressPO.getLandmark().getFieldId()), String.valueOf(companyAddressChangePO.getLandmark()), String.valueOf(companyAddressChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(companyAddressPO.getPincode().getNewValue()), String.valueOf(companyAddressPO.getPincode().getFieldId()), String.valueOf(companyAddressChangePO.getPincode()), String.valueOf(companyAddressChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(companyAddressPO.getCity().getNewValue()), String.valueOf(companyAddressPO.getCity().getFieldId()), String.valueOf(companyAddressChangePO.getCity()), String.valueOf(companyAddressChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(companyAddressPO.getState().getNewValue()), String.valueOf(companyAddressPO.getState().getFieldId()), String.valueOf(companyAddressChangePO.getState()), String.valueOf(companyAddressChangePO.getRequestId())));
			//poData.add(getEditFieldNewValueList(String.valueOf(companyAddressPO.getAddressproof().getNewValue()), String.valueOf(companyAddressPO.getAddressproof().getFieldId()), String.valueOf(companyAddressChangePO.getAddressproof()), String.valueOf(companyAddressChangePO.getRequestId())));

			if (CollectionUtils.isEmpty(poData)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "poData not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			for (ProfileUpdateDetailsPo checkData : poData) {
				if (checkData != null) {
					poValidateData.add(checkData);
				}

			}

			if (poValidateData.isEmpty()) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "getProfileUpdateVo not be null");
				throw new IPruException("Error", "GPU01", "Please Edit Atleast One Value!");
			}

			String checkMandatoryresult = utility.checkMandatoryFields(poValidateData, map);
			if (StringUtils.isNotEmpty(checkMandatoryresult)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "checkMandatoryresult" + checkMandatoryresult);
				throw new IPruException("Error", "GPU01", checkMandatoryresult);
			}

			String validation = null;
			ProfileUpdateValidator validator = new ProfileUpdateValidator();
			if (validator != null && CollectionUtils.isNotEmpty(poValidateData)) {
				validation = validator.ValidateProfileCompanyAddressDetails(poValidateData, p_ObjContext, map);
				if (StringUtils.isNotBlank(validation)) {
					throw new IPruException("Error", "GPU01", validation);
				}

				ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
				List<ProfileUpdateDetailsVo> voList = new ArrayList<ProfileUpdateDetailsVo>();

				if (CollectionUtils.isNotEmpty(poValidateData)) {
					for (int i = 0; i < poValidateData.size(); i++) {
						profileUpdateDetailsVo = new ProfileUpdateDetailsVo();

						dozerBeanMapper.map((ProfileUpdateDetailsPo) poValidateData.get(i),
								profileUpdateDetailsVo);

						voList.add(profileUpdateDetailsVo);

					}
				}
				else {
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}

				if (CollectionUtils.isEmpty(voList) && utility == null) {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "voList should not be null");
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}

				ProfileUpdateTranscationVO profileUpdateTranscationVO = utility.getProfileUpdateDataForEdit(voList, map, p_ObjContext, functionality);

				UploadFileVO uploadFileVO = null;

				List<UploadFileVO> uploadFileDetails = new ArrayList();

				if (CollectionUtils.isNotEmpty(uploadFilePOList)) {
					for (int i = 0; i < uploadFilePOList.size(); i++) {

						UploadFilePO uploadFilePO = uploadFilePOList.get(i);
						String documentName = uploadFilePO.getDocName();
						long docSize = uploadFilePO.getDocSize();
						int dot = documentName.lastIndexOf(".");
						String extension = documentName.substring(dot + 1);
						if ((extension.equalsIgnoreCase("PDF") || extension.equalsIgnoreCase("JPEG") || extension.equalsIgnoreCase("TIFF") || extension.equalsIgnoreCase("JPG"))
								&& (docSize <= Long.parseLong(prop.getProperty("fiveMb")))) {
							uploadFileVO = new UploadFileVO();
							dozerBeanMapper.map((UploadFilePO) uploadFilePOList.get(i),
									uploadFileVO);
							uploadFileDetails.add(uploadFileVO);
						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "File Should be JPEG or PDF or TIFF and size should be less than 2MB");
							throw new IPruException("Error", "GPU01", "File Should be JPEG or PDF or TIFF and size should be less than 5 MB");
						}
					}
				}
				else {
					throw new IPruException("Error", "GPU01", "Please Upload File And Size Should Be Less Than 5 MB");

				}

				if (CollectionUtils.isEmpty(uploadFileDetails)) {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "UploadFileDetails Upload File");
					throw new IPruException("Error", "GPU01", "Please Upload File");
				}

				profileUpdateTranscationVO.setGetUploadFileVOList(uploadFileDetails);

				if (profileUpdateTranscationVO.getGetUploadFileVOList() == null) {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "profileUpdateTranscationVO should not be null");
					throw new IPruException("Error", "GPU01", "Please Upload File");
				}

				if (profileUpdateTranscationVO == null) {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "profileUpdateTranscationVO should not be null");
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
				Object[] paramArray = new Object[1];
				paramArray[0] = profileUpdateTranscationVO;
				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);
				p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);

			}

			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "request should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
		}

		catch (Exception e) {

			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", p_ObjContext);
		}
		FLogger.info("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforEditCompanyAddressChangeSubmit", "getBizRequestforEditCompanyAddressChangeSubmit Method End");
		return success();

	}

	@MethodPost
	public Event getBizResponseforEditCompanyAddressChange(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforEditCompanyAddressChange", "getBizResponseforEditCompanyAddressChange Method Start");
		String responseCheck = "";
		String serviceResponse = null;
		boolean response = false;
		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForProfileEditAuthoritySignatory");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					response = (Boolean) bizRes.getTransferObjects().get("response1");
					if (response)
						serviceResponse = "Record Inserted Successfully!";
					else
						serviceResponse = "Error Occured While Inserting Record Please Try Again!";
					context.getFlowScope().put("Response", serviceResponse);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforEditCompanyAddressChange", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforEditCompanyAddressChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforEditCompanyAddressChange", "getBizResponseforEditCompanyAddressChange Method End");
		return success();

	}

	@MethodPost
	public Event getBizRequestforOnloadgetCityDetails(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforOnloadgetCityDetails", "getBizRequestforOnloadgetCityDetails Method Start ");
		try {
			BizRequest obj_bizReq = new BizRequest();
			context.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforOnloadgetCityDetails", "Exception came", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforOnloadgetCityDetails", "getBizRequestforOnloadgetCityDetails Method End ");
		return success();
	}

	@MethodPost
	public Event getBizResponseforOnloadgetCityDetails(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetCityDetails", "getBizResponseforOnloadgetCityDetails Method Start ");
		String responselist = "";
		String responseCheck = "";

		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadCityDetails");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					Gson gson = new Gson();
					List<DropDownObjVO> response = (List<DropDownObjVO>) bizRes.getTransferObjects().get("response1");
					TreeSet cityDetails = new TreeSet();
					Map<String, String> map = new HashMap<String, String>();
					DropDownObjPO po = null;
					List<DropDownObjPO> cityDetailsPo = new ArrayList();
					if (response != null) {
						for (int i = 0; i < response.size(); i++) {
							po = new DropDownObjPO();
							DropDownObjVO vo = (DropDownObjVO) response.get(i);
							dozerBeanMapper.map(vo, po);
							cityDetails.add(po.getValue());
							cityDetailsPo.add(po);
						}

						if (CollectionUtils.isNotEmpty(cityDetailsPo)) {
							context.getFlowScope().put("OnloadCityDetails", cityDetails);

							responselist = gson.toJson(cityDetailsPo);
							context.getFlowScope().put("Response", responselist);
						}
						else {

							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetCityDetails", "cityDetails and map should not be null");
							throw new IPruException("Error", "GPU01", ErrorMsg);
						}
					}
					else {

						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetCityDetails", "response should not be null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetCityDetails", "bizRes should not be null");

				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetCityDetails", "Exception came", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetCityDetails", "getBizResponseforOnloadgetCityDetails Method End ");
		return success();
	}

	@MethodPost
	public Event getBizRequestforOnloadgetStateDetailsData(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforOnloadgetStateDetailsData", "getBizRequestforOnloadgetStateDetailsData Method Start");
		try {

			BizRequest obj_bizReq = new BizRequest();
			context.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforOnloadgetStateDetailsData", "Exception came", e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforOnloadgetStateDetailsData", "getBizRequestforOnloadgetStateDetailsData Method End");
		return success();

	}

	@MethodPost
	public Event getBizResponseforOnloadStateDetailsData(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadStateDetailsData", "getBizResponseforOnloadStateDetailsData Method Start");
		String responselist = "";
		String responseCheck = "";
		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadStateDetailsData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					Gson gson = new Gson();
					List<DropDownObjVO> response = (List<DropDownObjVO>) bizRes.getTransferObjects().get("response1");
					DropDownObjPO po = null;
					TreeSet<String> data = new TreeSet<String>();
					for (int i = 0; i < response.size(); i++) {
						po = new DropDownObjPO();
						DropDownObjVO vo = (DropDownObjVO) response.get(i);
						dozerBeanMapper.map(vo, po);
						data.add(po.getValue());
					}
					if (CollectionUtils.isNotEmpty(data)) {
						context.getFlowScope().put("OnloadStateDetailsData", data);
						responselist = gson.toJson(data);
						context.getFlowScope().put("Response", responselist);
					}
					else {

						FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizResponseforOnloadStateDetailsData", "response should not be null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

				}
			}
			else {
				FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizResponseforOnloadStateDetailsData", "bizRes should not be null ");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

		}
		catch (Exception e) {
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizResponseforOnloadStateDetailsData", "Exception came", e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadStateDetailsData", "getBizResponseforOnloadStateDetailsData Method End");
		return success();
	}

	@MethodPost
	public Event getBizRequestforOnloadAddressTypeData(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforOnloadAddressTypeData", "getBizRequestforOnloadAddressTypeData Method Start");
		try {
			BizRequest obj_bizReq = new BizRequest();
			context.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforOnloadAddressTypeData", "Exception came", e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforOnloadAddressTypeData", "getBizRequestforOnloadAddressTypeData Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseforOnloadAddressTypeData(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadAddressTypeData", "getBizResponseforOnloadAddressTypeData Method Start");
		String responselist = "";
		String responseCheck = "";

		try {
			if (context != null) {
				BizResponse bizRes = new BizResponse();
				bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadAddressTypeData");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {

						Gson gson = new Gson();
						List<DropDownObjVO> response = (List<DropDownObjVO>) bizRes.getTransferObjects().get("response1");
						DropDownObjPO po = null;
						TreeSet<String> data = new TreeSet<String>();
						for (int i = 0; i < response.size(); i++) {
							po = new DropDownObjPO();
							DropDownObjVO vo = (DropDownObjVO) response.get(i);
							dozerBeanMapper.map(vo, po);
							data.add(po.getValue());
						}

						if (CollectionUtils.isNotEmpty(data)) {
							context.getFlowScope().put("OnloadAddressTypeData", data);
							responselist = gson.toJson(data);
							context.getFlowScope().put("Response", responselist);
						}
						else {

							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadAddressTypeData", "response should not be null");
							throw new IPruException("Error", "GPU01", ErrorMsg);
						}

					}
				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadAddressTypeData", "bizRes should not be null ");
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}

			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadAddressTypeData", "context should not be null ");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
		}
		catch (Exception e) {
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadAddressTypeData", "Exception came", e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadAddressTypeData", "getBizResponseforOnloadAddressTypeData Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseforOnloadgetAddressProof(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadAddressTypeData", "getBizResponseforOnloadgetAddressProof Method Start");
		String responselist = "";

		Gson gson = new Gson();
		try {
			if (context != null) {
				TreeSet<String> addressProof = new TreeSet();
				addressProof.add("Telephone Bill");
				addressProof.add("Electricity Bill");
				addressProof.add("Passport");

				if (CollectionUtils.isNotEmpty(addressProof)) {
					context.getFlowScope().put("OnloadAddressProof", addressProof);
					responselist = gson.toJson(addressProof);
					context.getFlowScope().put("Response", responselist);
				}
				else {

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetAddressProof", "response should not be null");
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}

			}

			else {

			}
		}
		catch (Exception e) {
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetAddressProof", "Exception came", e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetAddressProof", "getBizResponseforOnloadgetAddressProof Method End");
		return success();
	}

	/***************************** Utility Method *********************************/
	private ProfileUpdateDetailsPo getFieldNewValueList(String NewValue, String fieldId) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getFieldNewValueList", "getFieldNewValueList Method Start");
		ProfileUpdateDetailsPo pojo = new ProfileUpdateDetailsPo();
		if (fieldId == null) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getFieldNewValueList", "Field ID  should not be null");
			throw new IPruException("Error", "GPU01", ErrorMsg);
		}
		pojo.setNewValue(NewValue);
		pojo.setFieldName(fieldId);
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getFieldNewValueList", "getFieldNewValueList Method End");
		return pojo;

	}

	private ProfileUpdateDetailsPo getEditFieldNewValueList(String NewValue, String fieldId, String sessionValue, String requestId) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getEditFieldNewValueList", "getFieldNewValueList Method Start");
		ProfileUpdateDetailsPo pojo = null;

		if (fieldId == null) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getEditFieldNewValueList", "Field ID  should not be null");
			throw new IPruException("Error", "GPU01", ErrorMsg);
		}

		if (!NewValue.equals(sessionValue)) {
			pojo = new ProfileUpdateDetailsPo();
			pojo.setFieldName(fieldId);
			pojo.setNewValue(NewValue);
			pojo.setOldValue(sessionValue);
			pojo.setUpdateReqId(requestId);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getEditFieldNewValueList", "getFieldNewValueList Method End");
		return pojo;

	}

	private FieldMeta create(String propertyValue, String oldValueFromVO, String key, Map<String, FieldAccessMappingPO> map, boolean flag) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "create", "create return type IFieldMeta Method Start");
		int fieldGroupCode = 0;
		int fieldCode = 0;
		String index = "";
		String fieldId = null;
		String newValue = "";
		String oldValue = null;
		String showDisabled = null;
		String showEdit = null;
		String show = null;
		if (map.get(key) == null) {
			// Throw Exception

		}
		FieldAccessMappingPO po = dozerBeanMapper.map(map.get(key), FieldAccessMappingPO.class);

		String fieldCanonicalName = propertyValue;

		FieldMeta fieldMeta = (FieldMeta) ReflectionUtils.newInstance(Class.forName(fieldCanonicalName));
		fieldMeta.setFieldGroupCode(Long.valueOf(po.getRdParentComponentId()).intValue());
		fieldMeta.setFieldCode(Long.valueOf(po.getRdComponentPosId()).intValue());
		fieldMeta.setFieldId(po.getRdComponent());
		fieldMeta.setNewValue(flag ? oldValueFromVO : newValue);
		fieldMeta.setOldValue(oldValueFromVO);
		fieldMeta.setIndex(index);
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "create", "create return type IFieldMeta Method End");

		return fieldMeta;
	}

	/* contact person change start */

	@MethodPost
	public Event getBizRequestForProfileContactPersonChangeAccessMatrix(RequestContext context) throws Exception {// here
																													// Get
																													// FieldAccess
																													// Mapping

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeAccessMatrix", "getBizRequestForProfileAccessDetails Method Start ");

		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;

			fieldAccessMappingVoList = getFieldAccessMappingList(context);
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String screenName = null;
			List<RoleScreenAccessMappingVO> accessMappingList;

			if (httpSession != null) {
				screenName = (String) context.getFlowScope().get("screenName2");

				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null && screenName != null && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) { 
					policyNo = userVo.getPolicyNo();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeAccessMatrix", "When page load Policy No in session : " + policyNo);
					role = userVo.getRoles();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeAccessMatrix", "When page load role in session : " + role);
					accessMappingList = userVo.getLstRoleScreenAccessMapping();

					ProfileUpdateLoadRequestPO profileUpdateLoadRequestPO = new ProfileUpdateLoadRequestPO();
					profileUpdateLoadRequestPO.setPolicyNo(policyNo);
					profileUpdateLoadRequestPO.setRole(role);
					profileUpdateLoadRequestPO.setScreenName(screenName);
					ProfileUpdateLoadRequestVO profileUpdateLoadRequestVO = null;
					if (profileUpdateLoadRequestPO != null) {
						profileUpdateLoadRequestVO = dozerBeanMapper.map(profileUpdateLoadRequestPO, ProfileUpdateLoadRequestVO.class);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeAccessMatrix", "profileUpdateLoadRequestPO  is null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

					if (profileUpdateLoadRequestVO != null) {
						if (CollectionUtils.isNotEmpty(accessMappingList) && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {
							profileUpdateLoadRequestVO.setAccessMappingList(accessMappingList);
							profileUpdateLoadRequestVO.setFieldAccessMappingList(fieldAccessMappingVoList);
							Object[] paramArray = new Object[1];
							paramArray[0] = profileUpdateLoadRequestVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("loadContactPersonAxcessMatrixBizReq", obj_bizReq);
						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeAccessMatrix", "accessMappingList and  fieldAccessMappingVoList is null");

							throw new IPruException("Error", "GPU01", ErrorMsg);
						}

					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeAccessMatrix", "UserVo  is null");

						throw new IPruException("Error", "GPU01", ErrorMsg);
					}
				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeAccessMatrix", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");

					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeAccessMatrix", "session is null");

				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeAccessMatrix", "Exception Came" ,e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeAccessMatrix", "getBizRequestForProfileContactPersonChangeAccessMatrix Method End ");

		return success();
	}

	@MethodPost
	public Event getBizResponseForProfilContactPersonAccessMatrix(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonAccessMatrix", "getBizResponseForProfileAccessDetails Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateLoadRequestDetailsVO profileUpdateLoadRequestDetailsVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				if (httpSession != null) {
					bizRes = (BizResponse) context.getFlowScope().get("bizResForProfileContactPersonAccessMatrix");

					if (bizRes != null) {
						responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
							throwINeoFlowException(bizRes.getStatusVO(), context);
						}
						else {
							profileUpdateLoadRequestDetailsVO = (ProfileUpdateLoadRequestDetailsVO) bizRes.getTransferObjects().get("response1");
							if (profileUpdateLoadRequestDetailsVO != null) {
								ProfileUpdateLoadRequestDetailsPO profileUpdateLoadRequestDetailsPO = dozerBeanMapper.map(profileUpdateLoadRequestDetailsVO, ProfileUpdateLoadRequestDetailsPO.class);
								if (profileUpdateLoadRequestDetailsPO != null) {

									Map<String, FieldAccessMappingPO> map = profileUpdateLoadRequestDetailsPO.getFieldAccessMappingMap();

									if (!map.isEmpty() && map != null && prop != null) {

										ResultJsonPO resultMap = new ResultJsonPO();
										context.getFlowScope().put("ContactPersonRoleAccessMatrix", map);
										resultMap.setResultMap(map);
										resultJson = gsonJSON.toJson(resultMap);
										context.getFlowScope().put("Response", resultJson);

									}
									else {
										throw new IPruException("Error", "GPU01", ErrorMsg);
									}

								}
								else {
									FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonAccessMatrix", "map should not be null");
									throw new IPruException("Error", "GPU01", ErrorMsg);
								}
							}
							else {
								FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonAccessMatrix", "getBizResponseForProfilContactPersonAccessMatrix should not be null");
								throw new IPruException("Error", "GPU01", ErrorMsg);

							}

						}
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonAccessMatrix", "bizRes should not be null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

				}

				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonAccessMatrix", "Session is null");
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonAccessMatrix", "Context from session is null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonAccessMatrix", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonAccessMatrix", "getBizResponseForProfilContactPersonAccessMatrix Method End");

		return success();
	}

	@MethodPost
	public Event getBizResponseForProfileLoadContactPersonDetails(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfileLoadContactPersonDetails", "getBizResponseForProfileAccessDetails Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;

		String resultJson = "";

		try {
			if (context != null) {

				Map<String, FieldAccessMappingPO> map = (Map<String, FieldAccessMappingPO>) context.getFlowScope().get("ContactPersonRoleAccessMatrix");
				boolean flag = false;
				if (!map.isEmpty() && prop != null) {

					ContactPersonPO contactPersonPO = new ContactPersonPO();
					contactPersonPO = createProfileUpdatePO(contactPersonPO, null, map, flag);
					if (contactPersonPO != null) {
						resultJson = gsonJSON.toJson(contactPersonPO);
						context.getFlowScope().put("Response", resultJson);
					}

				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfileLoadContactPersonDetails", "map should not be null");
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			}

			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfileLoadContactPersonDetails", "map should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfileLoadContactPersonDetails", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfileLoadContactPersonDetails", "getBizResponseForProfileLoadContactPersonDetails Method End");

		return success();
	}

	@MethodPost
	public Event getBizRequestForProfilePrePopulateContactPersonChange(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateContactPersonChange", "getBizRequestForProfileAccessDetails Method Start ");

		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String clientId=null;
			String screenName = null;
			if (httpSession != null) {
				screenName = (String) context.getFlowScope().get("screenName2");

				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null && screenName != null) {
					policyNo = userVo.getPolicyNo();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateContactPersonChange", "When page load Policy No in session : " + policyNo);
					clientId = userVo.getClientId();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateContactPersonChange", "When page load role in session : " + role);

					ProfileUpdateLoadRequestPO profileUpdateLoadRequestPO = new ProfileUpdateLoadRequestPO();
					profileUpdateLoadRequestPO.setPolicyNo(policyNo);
					profileUpdateLoadRequestPO.setClientId(clientId);
					profileUpdateLoadRequestPO.setScreenName(screenName);
					ProfileUpdateLoadRequestVO profileUpdateLoadRequestVO = null;
					if (profileUpdateLoadRequestPO != null) {
						profileUpdateLoadRequestVO = dozerBeanMapper.map(profileUpdateLoadRequestPO, ProfileUpdateLoadRequestVO.class);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateContactPersonChange", "profileUpdateLoadRequestPO  is null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

					if (profileUpdateLoadRequestVO != null) {

						Object[] paramArray = new Object[1];
						paramArray[0] = profileUpdateLoadRequestVO;
						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);

						context.getFlowScope().put("prePopulateContactPersonBizReq", obj_bizReq);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateContactPersonChange", "accessMappingList and  fieldAccessMappingVoList is null");

						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateContactPersonChange", "UserVo  is null");

					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateContactPersonChange", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");

				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateContactPersonChange", "Exception Came" ,e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateContactPersonChange", "getBizRequestForProfilePrePopulateContactPersonChange Method End ");

		return success();
	}

	@MethodPost
	public Event getBizResponseForProfilPrePopulateContactPersonChange(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateContactPersonChange", "getBizResponseForProfilPrePopulateContactPersonChange Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateLoadRequestDetailsVO profileUpdateLoadRequestDetailsVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {
			bizRes = (BizResponse) context.getFlowScope().get("bizResForProfilePrePopulateContactPersonDetails");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					Map<String, FieldAccessMappingPO> map = (Map<String, FieldAccessMappingPO>) context.getFlowScope().get("ContactPersonRoleAccessMatrix");
					List<ContactPersonPO> prePoulateContactPersonPOList = new LinkedList();
					profileUpdateLoadRequestDetailsVO = (ProfileUpdateLoadRequestDetailsVO) bizRes.getTransferObjects().get("response1");
					if (profileUpdateLoadRequestDetailsVO != null && !map.isEmpty()) {
						ProfileUpdateLoadRequestDetailsPO profileUpdateLoadRequestDetailsPO = dozerBeanMapper.map(profileUpdateLoadRequestDetailsVO, ProfileUpdateLoadRequestDetailsPO.class);
						if (profileUpdateLoadRequestDetailsPO != null) {
							List<ContactPersonChangePO> contactPersonChangePOList = new LinkedList();
							contactPersonChangePOList = (List<ContactPersonChangePO>) profileUpdateLoadRequestDetailsPO.getProfileContactPersonVOList();

							context.getFlowScope().put("ContactPersonChangePOList", contactPersonChangePOList);

							boolean flag = true;

							if (CollectionUtils.isNotEmpty(contactPersonChangePOList)) {
								for (ContactPersonChangePO contactPersonChangePO : contactPersonChangePOList) {
									ContactPersonPO contactPersonPO = new ContactPersonPO();
									contactPersonPO = (ContactPersonPO) createProfileUpdatePO(contactPersonPO, contactPersonChangePO, map, flag);
									contactPersonPO.setPrePopulateList(contactPersonChangePO.getTitle() + " " + contactPersonChangePO.getFirstName() + " "+ contactPersonChangePO.getMiddleName() + " " + contactPersonChangePO.getLastName() + " " + contactPersonChangePO.getEmailId() + " "+ contactPersonChangePO.getMobnumber());
									prePoulateContactPersonPOList.add(contactPersonPO);
								}

								if (CollectionUtils.isNotEmpty(prePoulateContactPersonPOList)) {
									resultJson = gsonJSON.toJson(prePoulateContactPersonPOList);
									context.getFlowScope().put("Response", resultJson);
								}
								else {
									FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateContactPersonChange", "prePoulatecompanyAddressPOList should not be null");
									throw new IPruException("Error", "GPU01", ErrorMsg);
								}
							}
							else {
								FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateContactPersonChange", "CompanyAddressChangePOList should not be null");
								throw new IPruException("Error", "GPU01", ErrorMsg);
							}

						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateContactPersonChange", "profileUpdateLoadRequestDetailsPO should not be null");
							throw new IPruException("Error", "GPU01", ErrorMsg);

						}

					}
				}
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateContactPersonChange", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateContactPersonChange", "getBizResponseForProfilPrePopulateContactPersonChange Method End");

		return success();
	}

	@MethodPost
	public Event getBizRequestForProfileContactPersonChangeSubmit(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "getBizRequestForProfileContactPersonChangeSubmit Method Start");

		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateUtil utility = new ProfileUpdateUtil();
		String validation = null;
		FunctionalityMasterVO functionality;

		try {
			Map<String, FieldAccessMappingVO> map = (Map<String, FieldAccessMappingVO>) p_ObjContext.getFlowScope().get("ContactPersonRoleAccessMatrix");
			if (map.isEmpty()) {
				FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "ContactPersonRoleAccessMatrix Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			StringBuffer jb = new StringBuffer();
			String line = null;

			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}

			functionality = this.getFunctionality(p_ObjContext);

			if (functionality == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "contactPersonPO Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			List<ProfileUpdateDetailsPo> poValidateData = new ArrayList<ProfileUpdateDetailsPo>(1);

			ContactPersonPO contactPersonPO = gsonJSON.fromJson(jb.toString(), ContactPersonPO.class);
			if (contactPersonPO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "contactPersonPO Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			if (contactPersonPO.getTitle() == null && contactPersonPO.getFirstName() == null && contactPersonPO.getMiddleName() == null && contactPersonPO.getLastName() == null
					&& contactPersonPO.getMobnumber() == null && contactPersonPO.getEmailId() == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "contactPersonPO Contain Object Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			poValidateData.add(getFieldNewValueList(GroupCommonUtils.getTitleBasedOnGender(contactPersonPO.getTitle().getNewValue()), contactPersonPO.getTitle().getFieldId()));
			poValidateData.add(getFieldNewValueList(contactPersonPO.getFirstName().getNewValue(), contactPersonPO.getFirstName().getFieldId()));
			poValidateData.add(getFieldNewValueList(contactPersonPO.getMiddleName().getNewValue(), contactPersonPO.getMiddleName().getFieldId()));
			poValidateData.add(getFieldNewValueList(contactPersonPO.getLastName().getNewValue(), contactPersonPO.getLastName().getFieldId()));
			poValidateData.add(getFieldNewValueList(contactPersonPO.getMobnumber().getNewValue(), contactPersonPO.getMobnumber().getFieldId()));
			poValidateData.add(getFieldNewValueList(contactPersonPO.getEmailId().getNewValue(), contactPersonPO.getEmailId().getFieldId()));

			if (CollectionUtils.isEmpty(poValidateData)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "companyAddressPO Should not be null");
				throw new IPruException("Error", "GPU01", "Please Filled All Mandatory Fields! ");

			}

			String checkMandatoryresult = utility.checkMandatoryFields(poValidateData, map);
			if (StringUtils.isNotEmpty(checkMandatoryresult)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "checkMandatoryresult" + checkMandatoryresult);
				throw new IPruException("Error", "GPU01", checkMandatoryresult);
			}
			ProfileUpdateValidator validator = new ProfileUpdateValidator();
			if (validator == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "validator Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			validation = validator.ValidateProfileContactPersonDetails(poValidateData, p_ObjContext, map);
			if (StringUtils.isNotBlank(validation)) {
				////System.out.println("Validation " + validation);
				// this.setValidationErrorMessages(validation);
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "Validation Error" + validation);
				// throwINeoFlowException(new
				// ServiceException("GPU01"),"GPU01",p_ObjContext);
				throw new IPruException("Error", "GPU01", validation);
			}

			ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
			List<ProfileUpdateDetailsVo> voList = new ArrayList<ProfileUpdateDetailsVo>();

			for (int i = 0; i < poValidateData.size(); i++) {
				profileUpdateDetailsVo = new ProfileUpdateDetailsVo();

				dozerBeanMapper.map((ProfileUpdateDetailsPo) poValidateData.get(i), profileUpdateDetailsVo);

				voList.add(profileUpdateDetailsVo);

			}
			if (CollectionUtils.isEmpty(voList)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "voList Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			if (utility == null && prop == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "map Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			ProfileUpdateTranscationVO profileUpdateTranscationVO = utility.getProfileUpdateData(map, voList, p_ObjContext, functionality);

			if (profileUpdateTranscationVO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "getProfileUpdateVo Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

			if (CollectionUtils.isNotEmpty(profileUpdateTranscationVO.getGetUploadFileVOList())) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "profileUpdateTranscationVO Should be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			if (profileUpdateTranscationVO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "getProfileUpdateVo not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			Object[] paramArray = new Object[1];
			paramArray[0] = profileUpdateTranscationVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {

			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", p_ObjContext);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileContactPersonChangeSubmit", "getBizRequestForProfileContactPersonChangeSubmit Method End");
		return success();

	}

	@MethodPost
	public Event getBizResponseForProfilContactPersonChangeSubmit(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonChangeSubmit", "getBizResponseForProfilContactPersonChangeSubmit Method Start");
		String responseCheck = "";
		String serviceResponse = null;
		boolean response = false;
		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForProfileContactPersonChangeSubmit");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					response = (Boolean) bizRes.getTransferObjects().get("response1");
					if (response)
						serviceResponse = "Record Inserted Successfully!";
					else
						serviceResponse = "Error Occured While Inserting Record Please Try Again!";
					context.getFlowScope().put("Response", serviceResponse);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "PrlofileUpdateHandler", "getBizResponseForProfilContactPersonChangeSubmit", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonChangeSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilContactPersonChangeSubmit", "getBizResponseForProfilContactPersonChangeSubmit Method End");
		return success();

	}

	@MethodPost
	public Event getBizRequestForProfileEditContactPersonChangeSubmit(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "getBizRequestForProfileEditContactPersonChangeSubmit Method Start");
		Gson gson = new Gson();
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateUtil utility = new ProfileUpdateUtil();
		FunctionalityMasterVO functionality;
		try {

			Map<String, FieldAccessMappingVO> map = (Map<String, FieldAccessMappingVO>) p_ObjContext.getFlowScope().get("ContactPersonRoleAccessMatrix");
			if (map.isEmpty()) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "ContactPersonRoleAccessMatrix  should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			functionality = this.getFunctionality(p_ObjContext);
			if (functionality == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "functionalityId  should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			List<ProfileUpdateDetailsPo> poValidateData = new ArrayList<ProfileUpdateDetailsPo>(1);
			List<ProfileUpdateDetailsPo> poData = new ArrayList<ProfileUpdateDetailsPo>();
			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			StringBuffer jb = new StringBuffer();
			String line = null;

			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}
			ContactPersonPO contactPersonPO = gsonJSON.fromJson(jb.toString(), ContactPersonPO.class);
			if (contactPersonPO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "contactPersonPO should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			int index = Integer.parseInt(contactPersonPO.getIndex());
			if (index < 0) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "index  should greater than Zero");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			List<ContactPersonChangePO> contactPersonChangePOFromSesssion = (List<ContactPersonChangePO>) p_ObjContext.getFlowScope().get("ContactPersonChangePOList");

			if (CollectionUtils.isEmpty(contactPersonChangePOFromSesssion) && contactPersonPO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "companyAddressPO and  companyAddressPOListFromSesssion should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}
			ContactPersonChangePO contactPersonChangePO = contactPersonChangePOFromSesssion.get(index);

			if (contactPersonChangePO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "companyAddressPO and  contactPersonChangePO should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			poData.add(getEditFieldNewValueList(GroupCommonUtils.getTitleBasedOnGender(String.valueOf(contactPersonPO.getTitle().getNewValue())), String.valueOf(contactPersonPO.getTitle().getFieldId()), String.valueOf(contactPersonChangePO.getTitle().toString()), String.valueOf(contactPersonChangePO.getRequestId().toString())));
			poData.add(getEditFieldNewValueList(String.valueOf(contactPersonPO.getFirstName().getNewValue()), String.valueOf(contactPersonPO.getFirstName().getFieldId()), String.valueOf(contactPersonChangePO.getFirstName()), String.valueOf(contactPersonChangePO.getRequestId().toString())));
			poData.add(getEditFieldNewValueList(String.valueOf(contactPersonPO.getMiddleName().getNewValue()), String.valueOf(contactPersonPO.getMiddleName().getFieldId()), String.valueOf(contactPersonChangePO.getMiddleName()), String.valueOf(contactPersonChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(contactPersonPO.getLastName().getNewValue()), String.valueOf(contactPersonPO.getLastName().getFieldId()), String.valueOf(contactPersonChangePO.getLastName()), String.valueOf(contactPersonChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(contactPersonPO.getEmailId().getNewValue()), String.valueOf(contactPersonPO.getEmailId().getFieldId()), String.valueOf(contactPersonChangePO.getEmailId()), String.valueOf(contactPersonChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(contactPersonPO.getMobnumber().getNewValue()), String.valueOf(contactPersonPO.getMobnumber().getFieldId()), String.valueOf(contactPersonChangePO.getMobnumber()), String.valueOf(contactPersonChangePO.getRequestId())));

			if (CollectionUtils.isEmpty(poData)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "poData should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

			for (ProfileUpdateDetailsPo checkData : poData) {
				if (checkData != null) {
					poValidateData.add(checkData);
				}

			}

			if (poValidateData.isEmpty()) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "getProfileUpdateVo not be null");
				throw new IPruException("Error", "GPU01", "Please Edit Atleast One Value!");
			}

			String checkMandatoryresult = utility.checkMandatoryFields(poValidateData, map);
			if (StringUtils.isNotEmpty(checkMandatoryresult)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "checkMandatoryresult" + checkMandatoryresult);
				throw new IPruException("Error", "GPU01", checkMandatoryresult);
			}

			String validation = null;
			ProfileUpdateValidator validator = new ProfileUpdateValidator();
			if (validator != null && CollectionUtils.isNotEmpty(poValidateData)) {
				validation = validator.ValidateProfileContactPersonDetails(poValidateData, p_ObjContext, map);
				if (StringUtils.isNotBlank(validation)) {

					// this.setValidationErrorMessages(validation);
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "Validation Error" + validation);
					// throwINeoFlowException(new
					// ServiceException("GPU01"),"GPU01",p_ObjContext);
					throw new IPruException("Error", "GPU01", validation);
				}

				ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
				List<ProfileUpdateDetailsVo> voList = new ArrayList<ProfileUpdateDetailsVo>();

				if (CollectionUtils.isNotEmpty(poValidateData)) {
					for (int i = 0; i < poValidateData.size(); i++) {
						profileUpdateDetailsVo = new ProfileUpdateDetailsVo();

						dozerBeanMapper.map((ProfileUpdateDetailsPo) poValidateData.get(i),
								profileUpdateDetailsVo);

						voList.add(profileUpdateDetailsVo);

					}
				}
				else {
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}

				if (utility == null && CollectionUtils.isEmpty(voList)) {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "contect map ContactPersonRoleAccessMatrix not be null");
					throw new IPruException("Error", "GPU01", ErrorMsg);

				}

				ProfileUpdateTranscationVO profileUpdateTranscationVO = utility.getProfileUpdateDataForEdit(voList, map, p_ObjContext, functionality);

				if (profileUpdateTranscationVO == null) {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "profileUpdateTranscationVO should not be null");
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}

				Object[] paramArray = new Object[1];
				paramArray[0] = profileUpdateTranscationVO;
				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);
				p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
			}

			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "context should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

		}

		catch (Exception e) {

			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", p_ObjContext);
		}
		FLogger.info("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestForProfileEditContactPersonChangeSubmit", "getBizRequestForProfileEditContactPersonChangeSubmit Method End");
		return success();

	}

	@MethodPost
	public Event getBizResponseForProfilEditContactPersonChangeSubmit(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilEditContactPersonChangeSubmit", "getBizResponseForProfilEditContactPersonChangeSubmit Method Start");
		String responseCheck = "";
		String serviceResponse = null;
		boolean response = false;
		try {
			if (context != null) {
				BizResponse bizRes = new BizResponse();
				bizRes = (BizResponse) context.getFlowScope().get("bizResForProfileEditContactPersonChange");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {

						response = (Boolean) bizRes.getTransferObjects().get("response1");
						if (response)
							serviceResponse = "Record Inserted Successfully!";
						else
							serviceResponse = "Error Occured While Inserting Record Please Try Again!";
						context.getFlowScope().put("Response", serviceResponse);
					}
				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilEditContactPersonChangeSubmit", "bizRes should not be null");
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			}

			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilEditContactPersonChangeSubmit", "context should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilEditContactPersonChangeSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilEditContactPersonChangeSubmit", "getBizResponseForProfilEditContactPersonChangeSubmit Method End");
		return success();

	}

	@MethodPost
	public Event getBizResponseforOnloadgetTitleDetails(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetTitleDetails", "getBizResponseforOnloadgetTitleDetails Method End");
		String responselist = "";
		try {
			ArrayList data = new ArrayList();
			data.add("Ms");
			data.add("Mr");
			if (CollectionUtils.isNotEmpty(data)) {
				context.getFlowScope().put("OnloadTitleDetails", data);
				responselist = gsonJSON.toJson(data);
				context.getFlowScope().put("Response", responselist);
			}
			else {

				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetTitleDetails", "response should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizResponseforOnloadgetTitleDetails", "Exception came", e);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforOnloadgetTitleDetails", "getBizResponseforOnloadgetTitleDetails Method End");
		return success();
	}

	/*
	 * AuthoritySignatoryChange**************************************************
	 * *************************************
	 */

	@MethodPost
	public Event getBizRequestForProfileAuthoritySignAccessMatrix(RequestContext context) throws Exception {// here
																											// Get
																											// FieldAccess
																											// Mapping

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileAuthoritySignAccessMatrix", "getBizRequestForProfileAuthoritySignAccessMatrix Method Start ");

		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;

			fieldAccessMappingVoList = getFieldAccessMappingList(context);
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String screenName = null;
			List<RoleScreenAccessMappingVO> accessMappingList;

			if (httpSession != null) {
				screenName = (String) context.getFlowScope().get("screenName4");

				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null && screenName != null && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {  // userVO
																													// b
																													// nahi
																													// null
																													// hoga
					policyNo = userVo.getPolicyNo();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileAuthoritySignAccessMatrix", "When page load Policy No in session : " + policyNo);
					role = userVo.getRoles();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileAuthoritySignAccessMatrix", "When page load role in session : " + role);
					accessMappingList = userVo.getLstRoleScreenAccessMapping();

					ProfileUpdateLoadRequestPO profileUpdateLoadRequestPO = new ProfileUpdateLoadRequestPO();
					profileUpdateLoadRequestPO.setPolicyNo(policyNo);
					profileUpdateLoadRequestPO.setRole(role);
					profileUpdateLoadRequestPO.setScreenName(screenName);
					ProfileUpdateLoadRequestVO profileUpdateLoadRequestVO = null;
					if (profileUpdateLoadRequestPO != null) {
						profileUpdateLoadRequestVO = dozerBeanMapper.map(profileUpdateLoadRequestPO, ProfileUpdateLoadRequestVO.class);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileAuthoritySignAccessMatrix", "profileUpdateLoadRequestPO  is null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

					if (profileUpdateLoadRequestVO != null) {
						if (CollectionUtils.isNotEmpty(accessMappingList) && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {
							profileUpdateLoadRequestVO.setAccessMappingList(accessMappingList);
							profileUpdateLoadRequestVO.setFieldAccessMappingList(fieldAccessMappingVoList);
							Object[] paramArray = new Object[1];
							paramArray[0] = profileUpdateLoadRequestVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("loadAuthorizedSigChangeBizReq", obj_bizReq);
						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileAuthoritySignAccessMatrix", "accessMappingList and  fieldAccessMappingVoList is null");

							throw new IPruException("Error", "GPU01", ErrorMsg);
						}

					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileAuthoritySignAccessMatrix", "UserVo  is null");

						throw new IPruException("Error", "GPU01", ErrorMsg);
					}
				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileAuthoritySignAccessMatrix", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");

					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileAuthoritySignAccessMatrix", "session is null");

				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileAuthoritySignAccessMatrix", "Exception Came" + e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfileAuthoritySignAccessMatrix", "getBizRequestForProfileAuthoritySignAccessMatrix Method End ");

		return success();
	}

	@MethodPost
	public Event getBizResponseForProfilAuthoritySignAccessMatrix(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoritySignAccessMatrix", "getBizResponseForProfilAuthoritySignAccessMatrix Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateLoadRequestDetailsVO profileUpdateLoadRequestDetailsVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {
			bizRes = (BizResponse) context.getFlowScope().get("bizResForProfileAuthoritySignAccessMatrix");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {
					profileUpdateLoadRequestDetailsVO = (ProfileUpdateLoadRequestDetailsVO) bizRes.getTransferObjects().get("response1");
					if (profileUpdateLoadRequestDetailsVO != null) {
						ProfileUpdateLoadRequestDetailsPO profileUpdateLoadRequestDetailsPO = dozerBeanMapper.map(profileUpdateLoadRequestDetailsVO, ProfileUpdateLoadRequestDetailsPO.class);
						if (profileUpdateLoadRequestDetailsPO != null) {
							List<ProfilePOCPO> data = new ArrayList<ProfilePOCPO>();

							Map<String, FieldAccessMappingPO> map = profileUpdateLoadRequestDetailsPO.getFieldAccessMappingMap();
							if (!map.isEmpty() && prop != null) {
								context.getFlowScope().put("authoritySignatoryRoleAccessMatrix", map);
								ResultJsonPO resultMap = new ResultJsonPO();

								resultMap.setResultMap(map);
								resultJson = gsonJSON.toJson(resultMap);
								context.getFlowScope().put("Response", resultJson);

							}
							else {
								throw new IPruException("Error", "GPU01", ErrorMsg);
							}

						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoritySignAccessMatrix", "map should not be null");
							throw new IPruException("Error", "GPU01", ErrorMsg);
						}
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoritySignAccessMatrix", "getBizResponseForProfilAuthoritySignAccessMatrix should not be null");
						throw new IPruException("Error", "GPU01", ErrorMsg);

					}

				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoritySignAccessMatrix", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoritySignAccessMatrix", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoritySignAccessMatrix", "getBizResponseForProfilAuthoritySignAccessMatrix Method End");

		return success();
	}

	@MethodPost
	public Event getBizResponseForProfilAuthoriySignatoryDetails(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoriySignatoryDetails", "getBizResponseForProfilAuthoriySignatoryDetails Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateLoadRequestDetailsVO profileUpdateLoadRequestDetailsVO = null;

		String resultJson = "";

		try {
			Map<String, FieldAccessMappingPO> map = (Map<String, FieldAccessMappingPO>) context.getFlowScope().get("authoritySignatoryRoleAccessMatrix");
			long functionalityId = this.getFunctionalityId(context);
			boolean flag = false;
			if (!map.isEmpty() && prop != null) {

				AuthoritySignatoryPO authoritySignatoryPO = new AuthoritySignatoryPO();
				authoritySignatoryPO = (AuthoritySignatoryPO) createProfileUpdatePO(authoritySignatoryPO, null, map, flag);
				authoritySignatoryPO.setFunctionalityId(functionalityId);

				if (authoritySignatoryPO != null) {
					resultJson = gsonJSON.toJson(authoritySignatoryPO);
					context.getFlowScope().put("Response", resultJson);
				}

			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoriySignatoryDetails", "map should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoriySignatoryDetails", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoriySignatoryDetails", "getBizResponseForProfilAuthoriySignatoryDetails Method End");

		return success();
	}

	@MethodPost
	public Event getBizRequestForProfilePrePopulateAuthoritySignatoryChange(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange Method Start");

		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String clientId=null;
			String screenName = null;
			if (httpSession != null) {
				screenName = (String) context.getFlowScope().get("screenName4");

				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null && screenName != null) {
					policyNo = userVo.getPolicyNo();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange", "When page load Policy No in session : " + policyNo);
					clientId = userVo.getClientId();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange", "When page load role in session : " + role);

					ProfileUpdateLoadRequestPO profileUpdateLoadRequestPO = new ProfileUpdateLoadRequestPO();
					profileUpdateLoadRequestPO.setPolicyNo(policyNo);
					profileUpdateLoadRequestPO.setClientId(clientId);
					profileUpdateLoadRequestPO.setScreenName(screenName);
					ProfileUpdateLoadRequestVO profileUpdateLoadRequestVO = null;
					if (profileUpdateLoadRequestPO != null) {
						profileUpdateLoadRequestVO = dozerBeanMapper.map(profileUpdateLoadRequestPO, ProfileUpdateLoadRequestVO.class);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange", "profileUpdateLoadRequestPO  is null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

					if (profileUpdateLoadRequestVO != null) {

						Object[] paramArray = new Object[1];
						paramArray[0] = profileUpdateLoadRequestVO;
						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);

						context.getFlowScope().put("prePopulateAuthoritySignatoryBizReq", obj_bizReq);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange", "accessMappingList and  fieldAccessMappingVoList is null");

						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange", "UserVo  is null");

					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");

				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange", "Exception Occured" + e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange", "getBizRequestForProfilePrePopulateAuthoritySignatoryChange Method End ");

		return success();
	}

	@MethodPost
	public Event getBizResponseForProfilPrePopulateAuthoritySignatoryChange(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateAuthoritySignatoryChange", "getBizResponseForProfilPrePopulateAuthoritySignatoryChange Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateLoadRequestDetailsVO profileUpdateLoadRequestDetailsVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {

			bizRes = (BizResponse) context.getFlowScope().get("bizResForProfilePrePopulateAuthoritySignatoryChange");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					Map<String, FieldAccessMappingPO> map = (Map<String, FieldAccessMappingPO>) context.getFlowScope().get("authoritySignatoryRoleAccessMatrix");
					if (map.isEmpty()) {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateAuthoritySignatoryChange", "companyAddressRoleAccessMatrix should not be null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}
					List<AuthoritySignatoryPO> prePoulateAuthoritySignatoryPOList = new LinkedList();
					profileUpdateLoadRequestDetailsVO = (ProfileUpdateLoadRequestDetailsVO) bizRes.getTransferObjects().get("response1");
					if (profileUpdateLoadRequestDetailsVO != null && !map.isEmpty()) {
						ProfileUpdateLoadRequestDetailsPO profileUpdateLoadRequestDetailsPO = dozerBeanMapper.map(profileUpdateLoadRequestDetailsVO, ProfileUpdateLoadRequestDetailsPO.class);
						if (profileUpdateLoadRequestDetailsPO != null) {
							List<AuthoritySignatoryChangePO> authoritySignatoryPOList = new LinkedList();
							authoritySignatoryPOList = (List<AuthoritySignatoryChangePO>) profileUpdateLoadRequestDetailsPO.getProfileAuthoritySignatoryVOList();
							context.getFlowScope().put("authoritySignatoryPOList", authoritySignatoryPOList);
							boolean flag = true;

							if (CollectionUtils.isNotEmpty(authoritySignatoryPOList)) {
								for (AuthoritySignatoryChangePO authoritySignatoryChangePO : authoritySignatoryPOList) {
									AuthoritySignatoryPO authoritySignatoryPO = new AuthoritySignatoryPO();
									authoritySignatoryPO = (AuthoritySignatoryPO) createProfileUpdatePO(authoritySignatoryPO, authoritySignatoryChangePO, map, flag);
									authoritySignatoryPO.setPrePopulateList(authoritySignatoryChangePO.getTitle() + " " + authoritySignatoryChangePO.getFirstName() + " "+ authoritySignatoryChangePO.getMiddleName() + " " + authoritySignatoryChangePO.getLastName() + " " + authoritySignatoryChangePO.getEmailId() + " "+ authoritySignatoryChangePO.getMobnumber() + " " + authoritySignatoryChangePO.getActive());
									prePoulateAuthoritySignatoryPOList.add(authoritySignatoryPO);
								}

								if (CollectionUtils.isNotEmpty(prePoulateAuthoritySignatoryPOList)) {
									resultJson = gsonJSON.toJson(prePoulateAuthoritySignatoryPOList);
									context.getFlowScope().put("Response", resultJson);
								}
								else {
									FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateAuthoritySignatoryChange", "prePoulatecompanyAddressPOList should not be null");
									throw new IPruException("Error", "GPU01", ErrorMsg);
								}
							}
							else {
								FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateAuthoritySignatoryChange", "CompanyAddressChangePOList should not be null");
								throw new IPruException("Error", "GPU01", ErrorMsg);
							}

						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateAuthoritySignatoryChange", "profileUpdateLoadRequestDetailsPO should not be null");
							throw new IPruException("Error", "GPU01", ErrorMsg);

						}
					}

					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateAuthoritySignatoryChange", "bizRes should not be null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}
				}
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateAuthoritySignatoryChange", "Exception Occured" + e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilPrePopulateAuthoritySignatoryChange", "getBizResponseForProfilPrePopulateAuthoritySignatoryChange Method End");

		return success();
	}

	@MethodPost
	public Event getBizRequestforSubmitAuthoritySignatoryChange(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "getBizRequestforSubmitAuthoritySignatoryChange Method Start");

		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateUtil utility = new ProfileUpdateUtil();
		String validation = null;
		FunctionalityMasterVO functionality;
		List<UploadFilePO> uploadFilePOList = null;

		try {

			functionality = this.getFunctionality(p_ObjContext);
			if (functionality == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "functionalityId Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			Map<String, FieldAccessMappingVO> map = (Map<String, FieldAccessMappingVO>) p_ObjContext.getFlowScope().get("authoritySignatoryRoleAccessMatrix");
			if (map.isEmpty()) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "map Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			StringBuffer jb = new StringBuffer();
			String line = null;

			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}

			List<ProfileUpdateDetailsPo> poValidateData = new ArrayList<ProfileUpdateDetailsPo>(1);
			AuthoritySignatoryPO authoritySignatoryPO = gsonJSON.fromJson(jb.toString(), AuthoritySignatoryPO.class);

			if (authoritySignatoryPO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "authoritySignatoryPO Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			if (CollectionUtils.isEmpty(authoritySignatoryPO.getUploadFiles())) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "authoritySignatoryPO Should not be null");
				throw new IPruException("Error", "GPU01", "Please Upload AtLeast One File !");

			}

			uploadFilePOList = authoritySignatoryPO.getUploadFiles();

			if (authoritySignatoryPO.getTitle() == null && authoritySignatoryPO.getFirstName() == null && authoritySignatoryPO.getMiddleName() == null && authoritySignatoryPO.getLastName() == null
					&& authoritySignatoryPO.getEmailId() == null && authoritySignatoryPO.getMobnumber() == null && authoritySignatoryPO.getActive() == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "authoritySignatoryPO Fields Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			/*
			 * boolean
			 * flag=utility.checkMandatoryFieldForCompanyAddress(companyAddressPO
			 * );
			 */

			/* createPoJO(companyAddressPO); */
			poValidateData.add(getFieldNewValueList(GroupCommonUtils.getTitleBasedOnGender(authoritySignatoryPO.getTitle().getNewValue()), authoritySignatoryPO.getTitle().getFieldId()));
			poValidateData.add(getFieldNewValueList(authoritySignatoryPO.getFirstName().getNewValue(), authoritySignatoryPO.getFirstName().getFieldId()));
			poValidateData.add(getFieldNewValueList(authoritySignatoryPO.getMiddleName().getNewValue(), authoritySignatoryPO.getMiddleName().getFieldId()));
			poValidateData.add(getFieldNewValueList(authoritySignatoryPO.getLastName().getNewValue(), authoritySignatoryPO.getLastName().getFieldId()));
			poValidateData.add(getFieldNewValueList(authoritySignatoryPO.getEmailId().getNewValue(), authoritySignatoryPO.getEmailId().getFieldId()));
			poValidateData.add(getFieldNewValueList(authoritySignatoryPO.getMobnumber().getNewValue(), authoritySignatoryPO.getMobnumber().getFieldId()));
			poValidateData.add(getFieldNewValueList(GroupCommonUtils.getActiveFromFrontEnd(authoritySignatoryPO.getActive().getNewValue()), authoritySignatoryPO.getActive().getFieldId()));

			if (CollectionUtils.isEmpty(poValidateData)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "authoritySignatoryPO Should not be null");
				throw new IPruException("Error", "GPU01", "Please Filled All Mandatory Fields! ");

			}

			String checkMandatoryresult = utility.checkMandatoryFields(poValidateData, map);
			if (StringUtils.isNotEmpty(checkMandatoryresult)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "checkMandatoryresult" + checkMandatoryresult);
				throw new IPruException("Error", "GPU01", checkMandatoryresult);
			}

			ProfileUpdateValidator validator = new ProfileUpdateValidator();

			if (validator == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "validator Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			validation = validator.ValidateProfileAuthoritySignatoryDetails(poValidateData, p_ObjContext);

			if (StringUtils.isNotBlank(validation)) {
				////System.out.println("Validation " + validation);
				this.setValidationErrorMessages(validation);
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "Validation Error" + validation);
				// throwINeoFlowException(new
				// ServiceException("GPU01"),"GPU01",p_ObjContext);
				throw new IPruException("Error", "GPU01", validation);
			}

			ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
			List<ProfileUpdateDetailsVo> voList = new ArrayList<ProfileUpdateDetailsVo>();

			for (int i = 0; i < poValidateData.size(); i++) {
				profileUpdateDetailsVo = new ProfileUpdateDetailsVo();

				dozerBeanMapper.map((ProfileUpdateDetailsPo) poValidateData.get(i), profileUpdateDetailsVo);

				voList.add(profileUpdateDetailsVo);

			}
			if (CollectionUtils.isEmpty(voList)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "voList Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			if (utility == null && prop == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "map Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			ProfileUpdateTranscationVO profileUpdateTranscationVO = utility.getProfileUpdateData(map, voList, p_ObjContext, functionality);

			if (profileUpdateTranscationVO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "profileUpdateTranscationVO Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

			UploadFileVO uploadFileVO = null;

			List<UploadFileVO> UploadFileDetails = new ArrayList();
			if (CollectionUtils.isNotEmpty(uploadFilePOList)) {
				for (int i = 0; i < uploadFilePOList.size(); i++) {

					UploadFilePO uploadFilePO = uploadFilePOList.get(i);
					String documentName = uploadFilePO.getDocName();
					long docSize = uploadFilePO.getDocSize();
					int dot = documentName.lastIndexOf(".");
					String extension = documentName.substring(dot + 1);
					
					String docType=uploadFilePO.getDocFileType();
					
				/*	if (!((docType.equalsIgnoreCase("PDF") || docType.equalsIgnoreCase("JPEG") || docType.equalsIgnoreCase("TIFF") || docType.equalsIgnoreCase("JPG")))) {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "File Should be JPEG or PDF or TIFF and size should be less than 2MB");
						throw new IPruException("Error", "GPU01", "File Should be JPEG or PDF or TIFF and size should be less than 5 MB");
					}
					*/
					if ((extension.equalsIgnoreCase("PDF") || extension.equalsIgnoreCase("JPEG") || extension.equalsIgnoreCase("TIFF") || extension.equalsIgnoreCase("JPG"))
							&& (docSize <= Long.parseLong(prop.getProperty("fiveMb")))) {
						uploadFileVO = new UploadFileVO();
						dozerBeanMapper.map((UploadFilePO) uploadFilePOList.get(i),
								uploadFileVO);
						UploadFileDetails.add(uploadFileVO);
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "File Should be JPEG or PDF or TIFF and size should be less than 2MB");
						throw new IPruException("Error", "GPU01", "File Should be JPEG or PDF or TIFF and size should be less than 5 MB");
					}
				}
			}
			else {
				throw new IPruException("Error", "GPU01", "Please Upload File And Size Should Be Less Than 5 MB");

			}

			profileUpdateTranscationVO.setGetUploadFileVOList(UploadFileDetails);

			if (profileUpdateTranscationVO.getGetUploadFileVOList() == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "profileUpdateTranscationVO.getGetUploadFileVOList should not be null");
				throw new IPruException("Error", "GPU01", "Please Upload File");
			}

			if (profileUpdateTranscationVO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "profileUpdateTranscationVO not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			Object[] paramArray = new Object[1];
			paramArray[0] = profileUpdateTranscationVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {

			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", p_ObjContext);
		}
		FLogger.info("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforSubmitAuthoritySignatoryChange", "getBizRequestforSubmitAuthoritySignatoryChange Method End");
		return success();

	}

	@MethodPost
	public Event getBizResponseForProfilAuthoritySignatoryChange(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoritySignatoryChange", "getBizResponseForProfilAuthoritySignatoryChange Method Start");
		String responseCheck = "";
		String serviceResponse = null;
		boolean response = false;
		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForProfileAuthoritySignatoryChange");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					response = (Boolean) bizRes.getTransferObjects().get("response1");
					if (response)
						serviceResponse = "Record Inserted Successfully!";
					else
						serviceResponse = "Error Occured While Inserting Record Please Try Again!";
					context.getFlowScope().put("Response", serviceResponse);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "PrlofileUpdateHandler", "getBizResponseForProfilAuthoritySignatoryChange", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoritySignatoryChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseForProfilAuthoritySignatoryChange", "getBizResponseForProfilAuthoritySignatoryChange Method End");
		return success();

	}

	@MethodPost
	public Event getBizRequestforEditAuthoritySignatoryChangeSubmit(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "getBizRequestforEditAuthoritySignatoryChangeSubmit Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateUtil utility = new ProfileUpdateUtil();
		FunctionalityMasterVO functionality;
		List<ProfileUpdateDetailsPo> poValidateData = new ArrayList<ProfileUpdateDetailsPo>(1);
		List<ProfileUpdateDetailsPo> poData = new ArrayList<ProfileUpdateDetailsPo>();
		List<UploadFilePO> uploadFilePOList = null;

		try {
			Map<String, FieldAccessMappingVO> map = (Map<String, FieldAccessMappingVO>) p_ObjContext.getFlowScope().get("authoritySignatoryRoleAccessMatrix");
			if (map.isEmpty()) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "authoritySignatoryRoleAccessMatrix should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			functionality = this.getFunctionality(p_ObjContext);

			if (functionality == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "functionalityId should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			StringBuffer jb = new StringBuffer();
			String line = null;
			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}
			AuthoritySignatoryPO authoritySignatoryPO = gsonJSON.fromJson(jb.toString(), AuthoritySignatoryPO.class);

			if (authoritySignatoryPO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "Edit authoritySignatoryPO should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			int index = Integer.parseInt(authoritySignatoryPO.getIndex());

			if (index < 0) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "index  should greater than Zero");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			if (CollectionUtils.isEmpty(authoritySignatoryPO.getUploadFiles())) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "UploadFilePOList  should not be null");
				throw new IPruException("Error", "GPU01", "Please Upload AtLeast One File !");
			}

			uploadFilePOList = authoritySignatoryPO.getUploadFiles();

			List<AuthoritySignatoryChangePO> authoritySignatoryChangePOListFromSesssion = (List<AuthoritySignatoryChangePO>) p_ObjContext.getFlowScope().get("authoritySignatoryPOList");

			if (CollectionUtils.isEmpty(authoritySignatoryChangePOListFromSesssion)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "companyAddressPOListFromSesssion should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}
			if (authoritySignatoryPO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "companyAddressPO should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

			if (authoritySignatoryPO.getTitle() == null && authoritySignatoryPO.getFirstName() == null && authoritySignatoryPO.getMiddleName() == null && authoritySignatoryPO.getLastName() == null
					&& authoritySignatoryPO.getMobnumber() == null && authoritySignatoryPO.getEmailId() == null && authoritySignatoryPO.getActive() == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "companyAddressPO Fields Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			AuthoritySignatoryChangePO authoritySignatoryChangePO = authoritySignatoryChangePOListFromSesssion.get(index);

			if (authoritySignatoryChangePO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "companyAddressChangePO  should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			poData.add(getEditFieldNewValueList(String.valueOf(GroupCommonUtils.getTitleBasedOnGender(authoritySignatoryPO.getTitle().getNewValue())), String.valueOf(authoritySignatoryPO.getTitle().getFieldId()), String.valueOf(authoritySignatoryChangePO.getTitle().toString()), String.valueOf(authoritySignatoryChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(authoritySignatoryPO.getFirstName().getNewValue()), String.valueOf(authoritySignatoryPO.getFirstName().getFieldId()), String.valueOf(authoritySignatoryChangePO.getFirstName()), String.valueOf(authoritySignatoryChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(authoritySignatoryPO.getMiddleName().getNewValue()), String.valueOf(authoritySignatoryPO.getMiddleName().getFieldId()), String.valueOf(authoritySignatoryChangePO.getMiddleName()), String.valueOf(authoritySignatoryChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(authoritySignatoryPO.getLastName().getNewValue()), String.valueOf(authoritySignatoryPO.getLastName().getFieldId()), String.valueOf(authoritySignatoryChangePO.getLastName()), String.valueOf(authoritySignatoryChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(authoritySignatoryPO.getEmailId().getNewValue()), String.valueOf(authoritySignatoryPO.getEmailId().getFieldId()), String.valueOf(authoritySignatoryChangePO.getEmailId()), String.valueOf(authoritySignatoryChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(authoritySignatoryPO.getMobnumber().getNewValue()), String.valueOf(authoritySignatoryPO.getMobnumber().getFieldId()), String.valueOf(authoritySignatoryChangePO.getMobnumber()), String.valueOf(authoritySignatoryChangePO.getRequestId())));
			poData.add(getEditFieldNewValueList(String.valueOf(GroupCommonUtils.getActiveFromFrontEnd(authoritySignatoryPO.getActive().getNewValue())), String.valueOf(authoritySignatoryPO.getActive().getFieldId()), String.valueOf(authoritySignatoryChangePO.getActive()), String.valueOf(authoritySignatoryChangePO.getRequestId())));

			if (CollectionUtils.isEmpty(poData)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "poData not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			for (ProfileUpdateDetailsPo checkData : poData) {
				if (checkData != null) {
					poValidateData.add(checkData);
				}

			}

			if (poValidateData.isEmpty()) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "getProfileUpdateVo not be null");
				throw new IPruException("Error", "GPU01", "Please Edit Atleast One Value!");
			}

			String checkMandatoryresult = utility.checkMandatoryFields(poValidateData, map);
			if (StringUtils.isNotEmpty(checkMandatoryresult)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "checkMandatoryresult" + checkMandatoryresult);
				throw new IPruException("Error", "GPU01", checkMandatoryresult);
			}

			String validation = null;
			ProfileUpdateValidator validator = new ProfileUpdateValidator();
			if (validator != null && CollectionUtils.isNotEmpty(poValidateData)) {
				validation = validator.ValidateProfileAuthoritySignatoryDetails(poValidateData, p_ObjContext);

				if (StringUtils.isNotBlank(validation)) {

					// this.setValidationErrorMessages(validation);
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "Validation Error" + validation);
					// throwINeoFlowException(new
					// ServiceException("GPU01"),"GPU01",p_ObjContext);
					throw new IPruException("Error", "GPU01", validation);
				}

				ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
				List<ProfileUpdateDetailsVo> voList = new ArrayList<ProfileUpdateDetailsVo>();

				if (CollectionUtils.isNotEmpty(poValidateData)) {
					for (int i = 0; i < poValidateData.size(); i++) {
						profileUpdateDetailsVo = new ProfileUpdateDetailsVo();

						dozerBeanMapper.map((ProfileUpdateDetailsPo) poValidateData.get(i),
								profileUpdateDetailsVo);

						voList.add(profileUpdateDetailsVo);

					}
				}
				else {
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}

				if (CollectionUtils.isEmpty(voList) && utility == null) {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "voList should not be null");
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}

				ProfileUpdateTranscationVO profileUpdateTranscationVO = utility.getProfileUpdateDataForEdit(voList, map, p_ObjContext, functionality);

				UploadFileVO uploadFileVO = null;

				List<UploadFileVO> uploadFileDetails = new ArrayList();

				if (CollectionUtils.isNotEmpty(uploadFilePOList)) {
					for (int i = 0; i < uploadFilePOList.size(); i++) {

						UploadFilePO uploadFilePO = uploadFilePOList.get(i);
						String documentName = uploadFilePO.getDocName();
						long docSize = uploadFilePO.getDocSize();
						int dot = documentName.lastIndexOf(".");
						String extension = documentName.substring(dot + 1);
						if ((extension.equalsIgnoreCase("PDF") || extension.equalsIgnoreCase("JPEG") || extension.equalsIgnoreCase("TIFF") || extension.equalsIgnoreCase("JPG"))
								&& (docSize <= Long.parseLong(prop.getProperty("fiveMb")))) {
							uploadFileVO = new UploadFileVO();
							dozerBeanMapper.map((UploadFilePO) uploadFilePOList.get(i),
									uploadFileVO);
							uploadFileDetails.add(uploadFileVO);
						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "File Should be JPEG or PDF or TIFF and size should be less than 2MB");
							throw new IPruException("Error", "GPU01", "File Should be JPEG or PDF or TIFF and size should be less than 5 MB");
						}
					}
				}
				else {
					throw new IPruException("Error", "GPU01", "Please Upload File And Size Should Be Less Than 5 MB");

				}

				if (CollectionUtils.isEmpty(uploadFileDetails)) {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "UploadFileDetails Upload File");
					throw new IPruException("Error", "GPU01", "Please Upload File");
				}

				profileUpdateTranscationVO.setGetUploadFileVOList(uploadFileDetails);

				if (profileUpdateTranscationVO.getGetUploadFileVOList() == null) {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "profileUpdateTranscationVO should not be null");
					throw new IPruException("Error", "GPU01", "Please Upload File");
				}

				if (profileUpdateTranscationVO == null) {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "profileUpdateTranscationVO should not be null");
					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
				Object[] paramArray = new Object[1];
				paramArray[0] = profileUpdateTranscationVO;
				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);
				p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);

			}

			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "request should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
		}

		catch (Exception e) {

			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", p_ObjContext);
		}
		FLogger.info("PROFILEUPDATEError", "ProfileUpdateHandler", "getBizRequestforEditAuthoritySignatoryChangeSubmit", "getBizRequestforEditAuthoritySignatoryChangeSubmit Method End");
		return success();

	}

	@MethodPost
	public Event getBizResponseforEditAuthorizedSignatoryChangeSubmit(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforEditAuthorizedSignatoryChange", "getBizResponseforEditAuthorizedSignatoryChange Method Start");
		String responseCheck = "";
		String serviceResponse = null;
		boolean response = false;
		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForProfileEditAuthoritySignatory");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					response = (Boolean) bizRes.getTransferObjects().get("response1");
					if (response)
						serviceResponse = "Record Inserted Successfully!";
					else
						serviceResponse = "Error Occured While Inserting Record Please Try Again!";
					context.getFlowScope().put("Response", serviceResponse);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforEditAuthorizedSignatoryChange", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforEditAuthorizedSignatoryChange", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseforEditAuthorizedSignatoryChange", "getBizResponseforEditAuthorizedSignatoryChange Method End");
		return success();

	}

	@SuppressWarnings({ "unchecked", "unused" })
	private <T extends Serializable> T createProfileUpdatePO(T frontendPO, T functChangePO, Map<String, FieldAccessMappingPO> map, boolean flag) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "createProfileUpdatePO", "createProfileUpdatePO Method End");
		String index = "";
		String oldValueFromVO = null;
		Class<T> functChangeClass = null;
		Class<T> frontendClass = (Class<T>) frontendPO.getClass();
		if (functChangePO != null) {
			functChangeClass = (Class<T>) functChangePO.getClass();
		}
		else {
			oldValueFromVO = "";
		}
		Field[] fields = frontendClass.getDeclaredFields();
		for (Field field : fields) {
			if (field.getType() == FieldMeta.class) {
				String fieldName = field.getName().substring(0, 1).toUpperCase() + field.getName().substring(1);
				Method getterMethod = null;
				Method setterMethod = null;
				try {
					getterMethod = frontendClass.getDeclaredMethod("get" + fieldName);
					setterMethod = frontendClass.getDeclaredMethod("set" + fieldName, FieldMeta.class);
					if (functChangeClass != null) {
						oldValueFromVO = (String) functChangeClass.getDeclaredMethod("get" + fieldName).invoke(functChangePO);
					}
					oldValueFromVO = StringUtils.isEmpty(oldValueFromVO) ? "" : oldValueFromVO;
					String newValue = flag ? oldValueFromVO : "";
					FieldAccessMappingPO po = dozerBeanMapper.map(map.get(field.getName()), FieldAccessMappingPO.class);
					setterMethod.invoke(frontendPO, createFieldMeta(po.getRdComponentPosId(), po.getRdParentComponentId(), po.getRdComponent(), newValue, oldValueFromVO, index));
				}
				catch (Exception e) {
					FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "createProfileUpdatePO", "createProfileUpdatePO Exception",e);
				}
			}
			else
				continue;
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "createProfileUpdatePO", "createProfileUpdatePO Method End");
		return frontendPO;

	}

	
	
	
	
	private FieldMeta createFieldMeta(long fieldCode, long fieldGroupcode, String fieldId, String newValue, String oldValue, String index) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "createFieldMeta", "createFieldMeta Method End");
		FieldMeta fieldMeta = new FieldMeta();
		fieldMeta.setFieldGroupCode(Long.valueOf(fieldGroupcode).intValue());
		fieldMeta.setFieldCode(Long.valueOf(fieldCode).intValue());
		fieldMeta.setFieldId(fieldId);
		fieldMeta.setNewValue(newValue);
		fieldMeta.setOldValue(oldValue);
		fieldMeta.setIndex(index);
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "createFieldMeta", "createFieldMeta Method End");
		return fieldMeta;
	}
	
	
	
	
	@MethodPost
	public Event getBizRequestloadMemberProfileTraditional(RequestContext context) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadMemberProfileTraditional", "getBizRequestloadMemberProfileTraditional Method Start ");

		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;

			fieldAccessMappingVoList = getFieldAccessMappingList(context);
			IPruUser userVo = new IPruUser();
			String policyNo = null;
			String role = null;
			String screenName = null;
			List<RoleScreenAccessMappingVO> accessMappingList;

				screenName = (String) context.getFlowScope().get("screenName5");

				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null && screenName != null && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {  
					policyNo = userVo.getPolicyNo();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadMemberProfileTraditional", "When page load Policy No in session : " + policyNo);
					role = userVo.getRoles();

					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadMemberProfileTraditional", "When page load role in session : " + role);
					accessMappingList = userVo.getLstRoleScreenAccessMapping();

					ProfileUpdateLoadRequestPO profileUpdateLoadRequestPO = new ProfileUpdateLoadRequestPO();
					profileUpdateLoadRequestPO.setPolicyNo(policyNo);
					profileUpdateLoadRequestPO.setRole(role);
					profileUpdateLoadRequestPO.setScreenName(screenName);
					ProfileUpdateLoadRequestVO profileUpdateLoadRequestVO = null;
					if (profileUpdateLoadRequestPO != null) {
						profileUpdateLoadRequestVO = dozerBeanMapper.map(profileUpdateLoadRequestPO, ProfileUpdateLoadRequestVO.class);
					}
				

					if (profileUpdateLoadRequestVO != null) {
						if (CollectionUtils.isNotEmpty(accessMappingList) && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {
							profileUpdateLoadRequestVO.setAccessMappingList(accessMappingList);
							profileUpdateLoadRequestVO.setFieldAccessMappingList(fieldAccessMappingVoList);
							Object[] paramArray = new Object[1];
							paramArray[0] = profileUpdateLoadRequestVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("loadMemberAddTraditionalMatrixBizReq", obj_bizReq);
						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadMemberProfileTraditional", "accessMappingList and  fieldAccessMappingVoList is null");

							throw new IPruException("Error", "GPU01", ErrorMsg);
						}

	}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadMemberProfileTraditional", "UserVo  is null");

						throw new IPruException("Error", "GPU01", ErrorMsg);
					}
				}
				else {
					FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadMemberProfileTraditional", "UserVo from session is null && screenName is null && fieldAccessMappingVoList is null");

					throw new IPruException("Error", "GPU01", ErrorMsg);
				}
			

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadMemberProfileTraditional", "Exception Occured ", e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestloadMemberProfileTraditional", "getBizRequestloadMemberProfileTraditional Method End ");

		return success();
	}

	
	
	@MethodPost
	public Event getBizResponseloadMemberProfileTraditional(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadMemberProfileTraditional", "getBizResponseloadMemberProfileTraditional Method Start");
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateLoadRequestDetailsVO profileUpdateLoadRequestDetailsVO = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {
			bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadMemberProfileTraditional");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {
					profileUpdateLoadRequestDetailsVO = (ProfileUpdateLoadRequestDetailsVO) bizRes.getTransferObjects().get("response1");
					if (profileUpdateLoadRequestDetailsVO != null) {
						ProfileUpdateLoadRequestDetailsPO profileUpdateLoadRequestDetailsPO = dozerBeanMapper.map(profileUpdateLoadRequestDetailsVO, ProfileUpdateLoadRequestDetailsPO.class);
						if (profileUpdateLoadRequestDetailsPO != null) {
							Map<String, FieldAccessMappingPO> map = profileUpdateLoadRequestDetailsPO.getFieldAccessMappingMap();

							if (!map.isEmpty() && map != null && prop != null) {

								ResultJsonPO resultMap = new ResultJsonPO();
								context.getFlowScope().put("memberAddressTraditional", map);
								resultMap.setResultMap(map);
								resultJson = gsonJSON.toJson(resultMap);
								context.getFlowScope().put("Response", resultJson);

							}
							else {
								throw new IPruException("Error", "GPU01", ErrorMsg);
							}

						}
						else {
							FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadMemberProfileTraditional", "map should not be null");
							throw new IPruException("Error", "GPU01", ErrorMsg);
						}
					}
					else {
						FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadMemberProfileTraditional", "profileUpdateLoadRequestDetailsPO should not be null");
						throw new IPruException("Error", "GPU01", ErrorMsg);

					}

				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadMemberProfileTraditional", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadMemberProfileTraditional", "Exception Came",e);
			throwINeoFlowException(e, "GPU01", context);
		}

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseloadMemberProfileTraditional", "getBizResponseloadMemberProfileTraditional Method End");

		return success();
	}
	
	
	
	@MethodPost
	public Event getBizRequestMemberAddressTraditionalSubmit(RequestContext p_ObjContext) throws Exception {
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "getBizRequestMemberAddressTraditionalSubmit Method Start");
		/*CommonFileUploadUtil commonFileUploadUtil=new CommonFileUploadUtil();*/

		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		ProfileUpdateUtil utility = new ProfileUpdateUtil();
		String validation = null;
		FunctionalityMasterVO functionality;


		try {
			functionality = this.getFunctionality(p_ObjContext);
			// functionalityId = this.getFunctionalityId(p_ObjContext);
			if (functionality == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "functionalityId Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			Map<String, FieldAccessMappingVO> map = (Map<String, FieldAccessMappingVO>) p_ObjContext.getFlowScope().get("memberAddressTraditional");
			if (map.isEmpty()) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "map Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}

			//ArrayList<String> containAddressTypeFromPrePopulate = ((ArrayList<String>) p_ObjContext.getFlowScope().get("containAddressType"));

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			ProfileUpdateDetailsPo po = null;
			StringBuffer jb = new StringBuffer();
			String line = null;

			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}

			List<ProfileUpdateDetailsPo> poValidateData = new ArrayList<ProfileUpdateDetailsPo>(1);
			MemberAddTraditionalPO memberAddTraditionalPO = gsonJSON.fromJson(jb.toString(), MemberAddTraditionalPO.class);

			if (memberAddTraditionalPO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "memberAddTraditionalPO Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

	
			
	
			
			if ((memberAddTraditionalPO.getDob()== null && memberAddTraditionalPO.getDob()=="") && memberAddTraditionalPO.getDoj() == null && memberAddTraditionalPO.getEmailID() == null
					&& memberAddTraditionalPO.getMobileNo() == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "memberAddTraditionalPO Mandatory Fields Should not be null");
				throw new IPruException("Error", "GPU01", "Please Filled All Mandatory Fields!");
			}

			/*if(CollectionUtils.isNotEmpty(containAddressTypeFromPrePopulate))
			{
			if (containAddressTypeFromPrePopulate.contains(companyAddressPO.getAddressType().getNewValue().toString())) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestforSubmitCompanyAddressChange", "Can not add multiple record with same address Tyep");
				throw new IPruException("Error", "GPU01", "Not Allowed Multiple Record With Same Address Type");
			}
			}*/
			
			SimpleDateFormat sdf1=new SimpleDateFormat("dd MMMM,yyyy");
			SimpleDateFormat sdf2=new SimpleDateFormat("dd/MM/yyyy");
			
			

			Date dob1=sdf1.parse(memberAddTraditionalPO.getDob());
			String dob=sdf2.format(dob1);
			
			Date doj1=sdf1.parse(memberAddTraditionalPO.getDoj());
			String doj=sdf2.format(doj1);
			
			if (dob1.after(doj1)) {

				throw new IPruException("Error", "US01",
						"Date of Joining should not be greater than date of birth");

			}
			
			
			if(!StringUtils.isEmpty(dob) && !StringUtils.isEmpty(doj))
			{
			memberAddTraditionalPO.setDob(dob);
			memberAddTraditionalPO.setDoj(doj);
			}
			else
			{
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
	
			poValidateData.add(getFieldNewValueList(memberAddTraditionalPO.getDob(), prop.getProperty("empDOB")));
			poValidateData.add(getFieldNewValueList(memberAddTraditionalPO.getDoj(), prop.getProperty("empDOJ")));
			poValidateData.add(getFieldNewValueList(memberAddTraditionalPO.getEmailID(),prop.getProperty("empEmail")));
			poValidateData.add(getFieldNewValueList(memberAddTraditionalPO.getMobileNo(),prop.getProperty("empMobileNo")));
		


			if (CollectionUtils.isEmpty(poValidateData)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "companyAddressPO Should not be null");
				throw new IPruException("Error", "GPU01", "Please Filled All Mandatory Fields! ");

			}
			
			String checkMandatoryresult = utility.checkMandatoryFields(poValidateData, map);
			if (StringUtils.isNotEmpty(checkMandatoryresult)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "checkMandatoryresult" + checkMandatoryresult);
				throw new IPruException("Error", "GPU01", checkMandatoryresult);
			}

			ProfileUpdateValidator validator = new ProfileUpdateValidator();
			
			validation = validator.ValidateMemberAddressTraditionalDetails(poValidateData, p_ObjContext, map);

			if (StringUtils.isNotBlank(validation)) {
				// ////System.out.println("Validation "+validation);
				// this.setValidationErrorMessages(validation);
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "Validation Error" + validation);
				// throwINeoFlowException(new
				// ServiceException("GPU01"),"GPU01",p_ObjContext);
				throw new IPruException("Error", "GPU01", validation);
			}

			ProfileUpdateDetailsVo profileUpdateDetailsVo = null;
			List<ProfileUpdateDetailsVo> voList = new ArrayList<ProfileUpdateDetailsVo>();

			for (int i = 0; i < poValidateData.size(); i++) {
				profileUpdateDetailsVo = new ProfileUpdateDetailsVo();

				dozerBeanMapper.map((ProfileUpdateDetailsPo) poValidateData.get(i),
						profileUpdateDetailsVo);

				voList.add(profileUpdateDetailsVo);

			}
			if (CollectionUtils.isEmpty(voList)) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "voList Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			if (utility == null && prop == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "map Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

			ProfileUpdateTranscationVO profileUpdateTranscationVO = utility.getProfileUpdateData(map, voList, p_ObjContext, functionality);

			if (profileUpdateTranscationVO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "profileUpdateTranscationVO Should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);

			}


			if (profileUpdateTranscationVO == null) {
				FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "profileUpdateTranscationVO not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}
			Object[] paramArray = new Object[1];
			paramArray[0] = profileUpdateTranscationVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {

			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", p_ObjContext);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizRequestMemberAddressTraditionalSubmit", "getBizRequestMemberAddressTraditionalSubmit Method End");
		return success();

	}
	

	@MethodPost
	public Event getBizResponseMemberAddressTraditionalSubmit(RequestContext context) throws Exception {

		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseMemberAddressTraditionalSubmit", "getBizResponseMemberAddressTraditionalSubmit Method Start");
		String responseCheck = "";
		String serviceResponse = null;
		boolean response = false;
		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadMemberAddressTraditionalSubmit");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					response = (Boolean) bizRes.getTransferObjects().get("response1");
					if (response)
						serviceResponse = "Record Inserted Successfully!";
					else
						serviceResponse = "Error Occured While Inserting Record Please Try Again!";
					context.getFlowScope().put("Response", serviceResponse);
				}
			}
			else {
				FLogger.error("PROFILEUPDATELogger", "PrlofileUpdateHandler", "getBizResponseMemberAddressTraditionalSubmit", "bizRes should not be null");
				throw new IPruException("Error", "GPU01", ErrorMsg);
			}

		}
		catch (Exception e) {
			FLogger.error("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseMemberAddressTraditionalSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GPU01", context);
		}
		FLogger.info("PROFILEUPDATELogger", "ProfileUpdateHandler", "getBizResponseMemberAddressTraditionalSubmit", "getBizResponseMemberAddressTraditionalSubmit Method End");
		return success();

	}
	

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
