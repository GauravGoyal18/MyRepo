package com.ipru.groups.handler;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.groups.bidsummary.BidSummaryResponse;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BIDSummaryHandler  extends IneoBaseHandler{
	private static final long serialVersionUID = 1L;

	public Event getBizRequestForFetchBIDSummary(RequestContext p_ObjContext) throws Exception {
		try{
			FLogger.info("BIDSummaryLogger", "BIDSummaryHandler", "getBizRequestForFetchBIDSummary", "Method start");
			
			
			HttpSession httpSession = null;
			IPruUser userVO = null;
			String policyKey = null;
			String unitCode = "";
			
			
			//Fetch policyKey - Start
			httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			if(httpSession != null) {
				userVO = (IPruUser) httpSession.getAttribute("userVO");
				if (userVO != null) {
					policyKey = userVO.getPolicyKey();
					unitCode = userVO.getUnitCode() != null ? userVO.getUnitCode() : "";
				}
			}
			//Fetch policyKey - End
			
			Object[] paramArray = new Object[2];
			paramArray[0] = policyKey;
			paramArray[1] = unitCode;
			
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
	
			//put values in flow scope
			p_ObjContext.getFlowScope().put("fetchBIDSummary", obj_bizReq);
			
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("BIDSummaryLogger", "BIDSummaryHandler", "getBizRequestForFetchBIDSummary", "Exception Occurred ", e);
			throwINeoFlowException(e, "GRBID01", p_ObjContext);
		}
		
		FLogger.info("BIDSummaryLogger", "DashbordHandler", "getBizRequestForFetchBIDSummary", "Method end");
		return success();
	}
	
	@MethodPost
	public Event getBizResponseForFetchBIDSummary(RequestContext p_ObjContext) throws Exception {
		
		try{
			FLogger.info("BIDSummaryLogger", "BIDSummaryHandler", "getBizResponseForFetchBIDSummary", "Method Start");
			
			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForFetchBIDSummary");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error("BIDSummaryError", "BIDSummaryHandler", "getBizResponseForFetchBIDSummary", "Error while getting response from service");
					throwINeoFlowException(new Exception(),"GRBID02",p_ObjContext);
				}
				else {

					//fetch BID details
					List<BidSummaryResponse> bidSummaryResponseList =  (List<BidSummaryResponse>) bizRes.getTransferObjects().get("response1");

					String resultJson = gsonJSON.toJson(bidSummaryResponseList);

					//set values in flow scope
					p_ObjContext.getFlowScope().put("Response", resultJson);//front end
				}
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
			FLogger.error("BIDSummaryLogger", "BIDSummaryHandler", "getBizResponseForFetchBIDSummary", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRBID01",p_ObjContext);
		}
		
		FLogger.info("BIDSummaryLogger", "BIDSummaryHandler", "getBizResponseForFetchBIDSummary", "Method End");
		return success();
	}
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		
	}
}