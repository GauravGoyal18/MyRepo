package com.ipru.groups.handler;

import java.util.Date;

import javacryption.aes.AesCtr;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.ChangePasswordPO;
import com.ipru.groups.utilities.EncryptionUtil;
import com.ipru.groups.validators.ChangePasswordValidator;
import com.ipru.groups.vo.ChangePasswordVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.encryption.servlet.CryptoServlet;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;

public class ChangePasswordHandler extends IneoBaseHandler {

	public Event getRequestSubmitPwd(RequestContext context) throws Exception {
		FLogger.info("ChangePasswordLogger", "ChangePasswordHandler", "getRequestSubmitPwd", "Method Start");
		HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

		try {
			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();

				CryptoServlet cs = new CryptoServlet();

				if (httpSession != null) {
					userVO = (IPruUser) httpSession.getAttribute("userVO");

					if (userVO != null) {

						ChangePasswordPO changePasswordPO = gsonJSON.fromJson(request.getReader(), ChangePasswordPO.class);
						changePasswordPO.setPolicyNo(userVO.getPolicyNo());
						changePasswordPO.setClientId(userVO.getClientId());
						changePasswordPO.setRole(userVO.getRoleType());
						changePasswordPO.setChangedDate(new Date());
						changePasswordPO.setWebClientId(userVO.getWebClientId());										
						
						String encOldPwd = changePasswordPO.getOldPassword();
						String encNewPwd = changePasswordPO.getNewPassword();
						String encConfPwd = changePasswordPO.getConfirmPassword();

						if (StringUtils.isNotEmpty(encOldPwd) && StringUtils.isNotEmpty(encNewPwd) && StringUtils.isNotEmpty(encConfPwd)) {
							String key = (String) httpSession.getAttribute("jCryptionKey");
							encOldPwd = encOldPwd.replaceAll(" ", "+");
							encNewPwd = encNewPwd.replaceAll(" ", "+");
							encConfPwd = encConfPwd.replaceAll(" ", "+");
							String decOldPwd = AesCtr.decrypt(encOldPwd, key, 256);
							String decNewPwd = AesCtr.decrypt(encNewPwd, key, 256);
							String decConfPwd = AesCtr.decrypt(encConfPwd, key, 256);

							String decryptedPswd = cs.decriptPassword(request, encOldPwd);
							if (userVO.getRoleType().equalsIgnoreCase("MEMBER")) {
								changePasswordPO.setOldPassword(EncryptionUtil.encryptSHA256(decOldPwd, "UTF-8"));
								changePasswordPO.setNewPassword(EncryptionUtil.encryptSHA256(decNewPwd, "UTF-8"));
								changePasswordPO.setConfirmPassword(EncryptionUtil.encryptSHA256(decConfPwd, "UTF-8"));
							}
							else {
								changePasswordPO.setOldPassword(EncryptionUtil.encryptMD5(decOldPwd, "UTF-8"));
								changePasswordPO.setNewPassword(EncryptionUtil.encryptMD5(decNewPwd, "UTF-8"));
								changePasswordPO.setConfirmPassword(EncryptionUtil.encryptMD5(decConfPwd, "UTF-8"));
							}

							ChangePasswordValidator validator=new ChangePasswordValidator();
							String errorMsg=validator.validatePassword(changePasswordPO, userVO);
							if (StringUtils.isNotEmpty(errorMsg)) {
								this.setValidationErrorMessages(errorMsg);
								FLogger.error("ChangePasswordLogger", "ChangePasswordHandler", "getRequestSubmitPwd", "Data from request should not be null");
								throwINeoFlowException(new ServiceException("GRPPFCC"), "GRPPFCC", context);
							}

						}

						ChangePasswordVO changePasswordVO = dozerBeanMapper.map(changePasswordPO, ChangePasswordVO.class);
						changePasswordVO.setFirstName(userVO.getFirstName());
						changePasswordVO.setLastName(userVO.getLastName());
						changePasswordVO.setEmailId(userVO.getEmailId());
						changePasswordVO.setMobNo(userVO.getMobileNo());
						

						Object[] paramArray = new Object[1];
						paramArray[0] = changePasswordVO;
						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);
						context.getFlowScope().put("submitReqPassword", obj_bizReq);

					}
					else {
						FLogger.error("ChangePasswordLogger", "ChangePasswordHandler", "getRequestSubmitPwd", "userVo should not be null");
						throw new IPruException("Error", "GRPPFCC", "userVo should not be null");
					}
				}
				else {
					FLogger.error("ChangePasswordLogger", "ChangePasswordHandler", "getRequestSubmitPwd", "httpSession should not be null");
					throw new IPruException("Error", "GRPPFCC", "httpSession should not be null");
				}
			}
			else {
				FLogger.error("ChangePasswordLogger", "ChangePasswordHandler", "getRequestSubmitPwd", "Context should not be null");
				throw new IPruException("Error", "GRPPFCC", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ChangePasswordLogger", "ChangePasswordHandler", "getRequestSubmitPwd", "Exception came ", e);
			throwINeoFlowException(e, "GRPPFCC", context);
		}

		FLogger.info("ChangePasswordLogger", "ChangePasswordHandler", "getRequestSubmitPwd", "Method End");
		return success();
	}

	public Event getResponseSubmitPwd(RequestContext context) throws Exception {
		FLogger.info("ChangePasswordLogger", "ChangePasswordHandler", "getResponseSubmitPwdPwd", "Method Start");
		BizResponse bizres = new BizResponse();
		String responseCheck = "";
		String result = null;
		try {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			
			if (httpSession != null) {
				IPruUser userVO=new IPruUser();
				userVO = (IPruUser) httpSession.getAttribute("userVO");			
				bizres = (BizResponse) context.getFlowScope().get("bizResChangePassword");
				
				if (bizres != null) {
					responseCheck = (String) bizres.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "Error")) {
						FLogger.error("ChangePasswordLogger", "ChangePasswordHandler", "getResponseSubmitPwd", "Response is null");
						throw new IPruException("Error", "GRPPFCC", "Response is null");
					}
					else {
						result = (String) bizres.getTransferObjects().get("response1");
						if (StringUtils.isNotEmpty(result)) {
							userVO.setPassword(result);
							httpSession.setAttribute("userVO", userVO);
							context.getFlashScope().put("Response", result);

						}
						else {
							FLogger.error("ChangePasswordLogger", "ChangePasswordHandler", "getResponseSubmitPwd", "No data Found");
							throw new IPruException("Error", "GRPPFCC", "No data Found");
						}

					}
				}
				else {
					FLogger.error("ChangePasswordLogger", "ChangePasswordHandler", "getResponseSubmitPwd", "bizres should not be null");
					throw new IPruException("Error", "GRPPFCC", "No data Found");
				}
			}else{
				FLogger.error("ChangePasswordLogger", "ChangePasswordHandler", "getResponseSubmitPwd", "session should not be null");
				throw new IPruException("Error", "GRPPFCC", "Session Expired");
			}

		}
		catch (Exception e) {
			FLogger.error("ChangePasswordLogger", "ChangePasswordHandler", "getResponseSubmitPwdPwd", "context should not be null" + e);
			throwINeoFlowException(e, "GRPPFCC", context);
		}

		FLogger.info("ChangePasswordLogger", "ChangePasswordHandler", "getResponseSubmitPwdPwd", "Method End");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
