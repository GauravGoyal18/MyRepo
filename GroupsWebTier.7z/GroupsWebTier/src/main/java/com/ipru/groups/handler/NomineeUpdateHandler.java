package com.ipru.groups.handler;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ipru.IPruException;
import com.ipru.groups.po.NomineeUpdateLoadDataPo;
import com.ipru.groups.po.NomineeUpdateLoadRequestPO;
import com.ipru.groups.po.NomineeUpdatePo;
import com.ipru.groups.po.NomineeUpdateRelationPo;
import com.ipru.groups.po.NomineeUpdateSubmitPo;
import com.ipru.groups.po.NomineeUpdateTransactionPo;
import com.ipru.groups.utilities.GroupNomineeUpdatePojoData;
import com.ipru.groups.validators.NomineeUpdateValidator;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.NomineeUpdateLoadDataVo;
import com.ipru.groups.vo.NomineeUpdateLoadRequestVO;
import com.ipru.groups.vo.NomineeUpdateRelationVo;
import com.ipru.groups.vo.NomineeUpdateSubmitVo;
import com.ipru.groups.vo.NomineeUpdateTransactionVo;
import com.ipru.groups.vo.NomineeUpdateVo;
import com.ipru.groups.vo.RoleScreenAccessMappingVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class NomineeUpdateHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static int totalSharePercent = 0;

	public static Map<String, String> mandateFields = new HashMap<String, String>();

	String ErrorMsg = "Something went wrong, Please try again later";

	public Event getBizRequestforNomineeUpdateLoadDataHandler(RequestContext p_ObjContext) throws Exception {
		FLogger.info("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateLoadDataHandler", "getBizRequestforLoadNomineeUpdateHandler Method Start");

		try {

			// BizRequest obj_bizReq = new BizRequest();
			String policyNumber = null;
			String clientId = null;
			IPruUser userVo = null;
			String role = null;
			List<FieldAccessMappingVO> fieldAccessMappingVoList = null;
			List<RoleScreenAccessMappingVO> accessMappingList;

			fieldAccessMappingVoList = getFieldAccessMappingList(p_ObjContext);
			String screenName = (String) p_ObjContext.getFlowScope().get("screenName");
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");
				if (userVo != null && screenName != null) {
					policyNumber = userVo.getPolicyNo();
					role = userVo.getRoles();
					clientId = userVo.getClientId();
					// clientId="Q2777";
				
					accessMappingList = userVo.getLstRoleScreenAccessMapping();

					NomineeUpdateLoadRequestPO nomineeUpdateLoadRequestPO = new NomineeUpdateLoadRequestPO();
					nomineeUpdateLoadRequestPO.setPolicyNo(policyNumber);
					nomineeUpdateLoadRequestPO.setRole(role);
					nomineeUpdateLoadRequestPO.setScreenName(screenName);
					NomineeUpdateLoadRequestVO nomineeUpdateLoadRequestVO = null;
					nomineeUpdateLoadRequestPO.setClientId(clientId);
					if (nomineeUpdateLoadRequestPO != null) {
						nomineeUpdateLoadRequestVO = dozerBeanMapper.map(nomineeUpdateLoadRequestPO, NomineeUpdateLoadRequestVO.class);
					}
					else {
						FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateLoadDataHandler", "profileUpdateLoadRequestPO  is null");
						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

					if (nomineeUpdateLoadRequestVO != null) {
						if (CollectionUtils.isNotEmpty(accessMappingList) && CollectionUtils.isNotEmpty(fieldAccessMappingVoList)) {
							nomineeUpdateLoadRequestVO.setAccessMappingList(accessMappingList);
							nomineeUpdateLoadRequestVO.setFieldAccessMappingList(fieldAccessMappingVoList);
							Object[] paramArray = new Object[1];
							paramArray[0] = nomineeUpdateLoadRequestVO;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							p_ObjContext.getFlowScope().put("nomineeUpdateLoadDataBizReq", obj_bizReq);
						}
						else {
							FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateLoadDataHandler", "accessMappingList and  fieldAccessMappingVoList is null");

							throw new IPruException("Error", "GPU01", ErrorMsg);
						}

					}
					else {
						FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateLoadDataHandler", "UserVo  is null");

						throw new IPruException("Error", "GPU01", ErrorMsg);
					}

					/*
					 * Object paramArray[]=new Object[2];
					 * paramArray[0]=policyNumber; paramArray[1]=clientId;
					 * obj_bizReq.addbusinessObjects("service-obj1",
					 * paramArray);
					 */
				}
			}

			else {
				FLogger.info("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateLoadDataHandler", "getBizRequestforLoadNomineeUpdateHandler found null data");
				throw new IPruException("Error", "GRPNOUP", "Found Null Session");

			}

			// /p_ObjContext.getFlowScope().put("nomineeUpdateLoadDataBizReq",
			// obj_bizReq);

		}

		catch (Exception e) {
			FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateLoadDataHandler", "Exception came ", e);
			throwINeoFlowException(e, "GRPNOUP02", p_ObjContext);

		}
		FLogger.info("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateLoadDataHandler", "getBizRequestforLoadNomineeUpdateHandler Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseforNomineeUpdateLoadDataHandler(RequestContext context) throws Exception {
		try {
			FLogger.info("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizResponseforNomineeUpdateLoadDataHandler", "Method start");
			BizResponse bizRes = new BizResponse();
			Gson gson = new Gson();
			String responseCheck = "";

			bizRes = (BizResponse) context.getFlowScope().get("bizResForLoadNomineeUpdateData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {

					FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizResponseforNomineeUpdateLoadDataHandler", "Exception came for null Response");
					throw new IPruException("Error", "GRPNOUP", "Some error Occured, Please again later");
				}
				else {

					NomineeUpdateLoadDataVo nomineeUpdateLoadDataVo = new NomineeUpdateLoadDataVo();
					nomineeUpdateLoadDataVo = (NomineeUpdateLoadDataVo) bizRes.getTransferObjects().get("response1");

					if (nomineeUpdateLoadDataVo != null) {

						// ////System.out.println("nomineeUpdateLoadDataVo.isRequestPerDay()nomineeUpdateLoadDataVo.isRequestPerDay()"+nomineeUpdateLoadDataVo.isRequestPerDay());
						List<NomineeUpdateRelationVo> nomineeUpdateRelationVoList = nomineeUpdateLoadDataVo.getNomineeUpdateRelationVo();
						List<NomineeUpdateVo> nomineeUpdateVoList = nomineeUpdateLoadDataVo.getNomineeUpdateVo();

						List<NomineeUpdateRelationPo> nomineeUpdateRelationPoList = new ArrayList<NomineeUpdateRelationPo>();
						List<NomineeUpdatePo> nomineeUpdatePoList = new ArrayList<NomineeUpdatePo>();

						if (nomineeUpdateRelationVoList != null && nomineeUpdateRelationVoList.size() > 0) {
							for (NomineeUpdateRelationVo nomineeUpdateRelationVo : nomineeUpdateRelationVoList) {
								NomineeUpdateRelationPo nomineeUpdateRelationPo = dozerBeanMapper.map(nomineeUpdateRelationVo, NomineeUpdateRelationPo.class);
								nomineeUpdateRelationPoList.add(nomineeUpdateRelationPo);

							}
						}

						if (nomineeUpdateLoadDataVo.getFieldAccessMappingMap().isEmpty()) {
							FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizResponseforNomineeUpdateLoadDataHandler", "Exception came for null getFieldAccessMappingMap ");
							throw new IPruException("Error", "GRPNOUP", "Found null data");

						}

						/*
						 * Iterator<String> itr =
						 * nomineeUpdateLoadDataVo.getFieldAccessMappingMap
						 * ().keySet().iterator(); while (itr.hasNext()) {
						 * FieldAccessMappingVO fieldAccessMappingVO =
						 * nomineeUpdateLoadDataVo
						 * .getFieldAccessMappingMap().get(itr.next());
						 * FieldAccessMappingPO fieldAccessMappingPO =
						 * dozerBeanMapper.map(fieldAccessMappingVO,
						 * FieldAccessMappingPO.class); }
						 */
						if (nomineeUpdateVoList != null && nomineeUpdateVoList.size() > 0) {
							for (NomineeUpdateVo nomineeUpdateVo : nomineeUpdateVoList) {

								NomineeUpdatePo nomineeUpdatePo = dozerBeanMapper.map(nomineeUpdateVo, NomineeUpdatePo.class);
								nomineeUpdatePoList.add(nomineeUpdatePo);

							}
						}

						NomineeUpdateLoadDataPo nomineeUpdateLoadDataPo = null;
						nomineeUpdateLoadDataPo = dozerBeanMapper.map(nomineeUpdateLoadDataVo, NomineeUpdateLoadDataPo.class);

						nomineeUpdateLoadDataPo.setRequestPerDay(nomineeUpdateLoadDataVo.isRequestPerDay());
						// nomineeUpdateLoadDataPo.setFieldAccessMappingMap(nomineeUpdateLoadDataVo.getFieldAccessMappingMap())
						if (nomineeUpdatePoList != null && nomineeUpdatePoList.size() > 0)
							nomineeUpdateLoadDataPo.setNomineeUpdatePo(nomineeUpdatePoList);

						if (nomineeUpdateRelationPoList != null && nomineeUpdateRelationPoList.size() > 0) {
							nomineeUpdateLoadDataPo.setNomineeUpdateRelationPo(nomineeUpdateRelationPoList);
						}

						else {

							FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizResponseforNomineeUpdateLoadDataHandler", "Exception came for null relation list");
							throw new IPruException("Error", "GRPNOUP", "Found null relations List");
						}

						HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
						httpSession.setAttribute("nomineeUpdateRelation", nomineeUpdateRelationPoList);

						context.getFlowScope().put("loadNomineeUpdateData", nomineeUpdateLoadDataPo);
						String resultJson = gson.toJson(nomineeUpdateLoadDataPo);
						context.getFlowScope().put("Response", resultJson);

					}
					else {

						FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizResponseforNomineeUpdateLoadDataHandler", "Exception came for null List");
						throw new IPruException("Error", "GRPNOUP", "Found null List");
					}
				}

			}// bizRes

		}// try

		catch (Exception e) {
			FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizResponseforNomineeUpdateLoadDataHandler", "Exception came ", e);
			throwINeoFlowException(e, "GRPNOUP02", context);
		}

		FLogger.info("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizResponseforNomineeUpdateLoadDataHandler", "getBizResponseforNomineeUpdateLoadDataHandler Method End");
		return success();
	}

	public Event getBizRequestforNomineeUpdateSubmitHandler(RequestContext p_ObjContext) throws Exception {
		FLogger.info("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateSubmitHandler", "getBizRequestforNomineeUpdateSubmitHandler Method Start");
		totalSharePercent = 0;
		// Gson gson = new Gson();
		FunctionalityMasterVO functionality = getFunctionality(p_ObjContext);
		NomineeUpdateTransactionVo nomineeUpdateTransactionVo = new NomineeUpdateTransactionVo();
		Set<NomineeUpdateSubmitVo> nomineeUpdateSubmitVoSet = new HashSet<NomineeUpdateSubmitVo>(0);
		try {

			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();
			if (request != null) {

				Type t = new TypeToken<List<NomineeUpdateSubmitPo>>() {
				}.getType();

				List<NomineeUpdateSubmitPo> nomineeUpdateSubmitPoList = gsonJSON.fromJson(request.getReader(), t);

				GroupNomineeUpdatePojoData groupNomineeUpdatePojoData = new GroupNomineeUpdatePojoData();

				groupNomineeUpdatePojoData.sortNomineeUpdateSubmitPoList(nomineeUpdateSubmitPoList, p_ObjContext); // check

				// List<NomineeUpdateSubmitVo> nomineeUpdateSubmitVoList = null;

				if (nomineeUpdateSubmitPoList != null && nomineeUpdateSubmitPoList.size() > 0) {
					NomineeUpdateValidator validator = new NomineeUpdateValidator();

					// nomineeUpdateSubmitVoList = new
					// ArrayList<NomineeUpdateSubmitVo>();

					String errorSuccessMessage = validator.validateNomineeUpdateSubmitPo(nomineeUpdateSubmitPoList, p_ObjContext);

					if (StringUtils.isNotBlank(errorSuccessMessage)) {

						this.setValidationErrorMessages(errorSuccessMessage);
						FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateSubmitHandler", "Data from request should not be null");
						/*
						 * throw new
						 * IPruException("Error","GRPNOUP",errorSuccessMessage);
						 */
						throwINeoFlowException(new ServiceException("GRPNOUP"), "GRPNOUP", p_ObjContext);

					}

					if (totalSharePercent != 100) {
						this.setValidationErrorMessages("Total share % should be 100%");
						FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateSubmitHandler", "Total share % should be 100%");
						/*
						 * throw new IPruException("Error","GRPNOUP",
						 * "Total share % should be 100%");
						 */
						throwINeoFlowException(new ServiceException("GRPNOUP"), "GRPNOUP", p_ObjContext);
					}

					for (NomineeUpdateSubmitPo nomineeUpdateSubmitPo : nomineeUpdateSubmitPoList) {
						NomineeUpdateSubmitVo nomineeUpdateSubmitVo = dozerBeanMapper.map(nomineeUpdateSubmitPo, NomineeUpdateSubmitVo.class);
						// nomineeUpdateSubmitVoList.add(nomineeUpdateSubmitVo);
						nomineeUpdateSubmitVoSet.add(nomineeUpdateSubmitVo);
					}
					nomineeUpdateTransactionVo.setFunctionality(functionality);
					nomineeUpdateTransactionVo.setNomineeUpdateSubmitVoSet(nomineeUpdateSubmitVoSet);
					nomineeUpdateTransactionVo = groupNomineeUpdatePojoData.getNomineeUpdateSubmitPojoData(nomineeUpdateTransactionVo, p_ObjContext);
				}
				else {
					FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateSubmitHandler", "nomineeUpdateSubmitPoList should not be null");
					throw new IPruException("Error", "GRPNOUP", "Nominee Details List is null");
				}

				Object[] paramArray = new Object[1];

				if (nomineeUpdateTransactionVo != null) {
					paramArray[0] = nomineeUpdateTransactionVo;
				}

				else {
					paramArray[0] = null;
					FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateSubmitHandler", "found null List");
					throw new IPruException("Error", "GRPNOUP", "Error Occured while Saving data");
				}

				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				p_ObjContext.getFlowScope().put("nomineeUpdateSubmitBizReq", obj_bizReq);

			}
			else {
				FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateSubmitHandler", "request should not be null");
				throw new IPruException("Error", "GRPNOUP", "Request should not be null");
			}

		}

		catch (Exception e) {
			//e.printStackTrace();

			FLogger.error("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateSubmitHandler", "Exception came ", e);
			throwINeoFlowException(e, "GRPNOUP", p_ObjContext);
		}
		FLogger.info("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizRequestforNomineeUpdateSubmitHandler", "getBizRequestforNomineeUpdateSubmitHandler Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseforNomineeUpdateSubmit(RequestContext context) throws Exception {

		FLogger.info("NomineeUpdateLogger", "NomineeUpdateHandler", "getBizResponseforNomineeUpdateSubmit", "Method start");
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		NomineeUpdateTransactionVo nomineeUpdateTransactionVo;
		bizRes = (BizResponse) context.getFlowScope().get("bizResForNomineeUpdateSubmit");
		if (bizRes != null) {
			responseCheck = (String) bizRes.getStatusVO().getStatus();
			if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
				throw new IPruException("Error", "GRPNOUP", "Response is null");
			}
			else {
				nomineeUpdateTransactionVo = (NomineeUpdateTransactionVo) bizRes.getTransferObjects().get("response1");

				if (nomineeUpdateTransactionVo != null) {
					NomineeUpdateTransactionPo nomineeUpdateTransactionPo = dozerBeanMapper.map(nomineeUpdateTransactionVo, NomineeUpdateTransactionPo.class);

					String result = gsonJSON.toJson(nomineeUpdateTransactionPo);
					context.getFlowScope().put("Response", result);

				}
				else {
					throw new IPruException("Error", "GRPNOUP", "Response is null");
				}
			}

		}// bizRes
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
