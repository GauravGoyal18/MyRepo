package com.ipru.groups.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.SessionFactory;
import org.hibernate.stat.Statistics;

import com.tcs.hibernate.HibernateConfigReader;

/**
 * Servlet implementation class SessionMonitoringServlet
 */
public class SessionMonitoringServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionMonitoringServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doCreateSessionfactoryResponse(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doCreateSessionfactoryResponse(request, response);
	}
	/** This is a method which will send the session factory statistics as a JSON
	 *  
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doCreateSessionfactoryResponse(HttpServletRequest request, HttpServletResponse response) throws ServletException
	{
		PrintWriter writer=null;
		try {
		HibernateConfigReader abd = HibernateConfigReader.INSTANCE;
		Map<String, SessionFactory> s_ObjSessionFactoryMap = abd.getSessionFactoryMap();
		Set<String> keySet = s_ObjSessionFactoryMap.keySet();
		Iterator<String> keySetString = keySet.iterator(); 
		StringBuilder json = new StringBuilder();
		json.append("[");
		int counter = 0;
		while(keySetString.hasNext())
		{
			++counter;
			String sessionFactoryKey = keySetString.next();
			SessionFactory sessionFactoryValue  = s_ObjSessionFactoryMap.get(sessionFactoryKey);
			Statistics stats = sessionFactoryValue.getStatistics();
			stats.setStatisticsEnabled(true);
			////System.out.println("########@@@@@@Start of Session statistics for the module:::::::"+sessionFactoryKey+"::::::@@@@@@@@@###########");
			////System.out.println("########@@@@@@Connection count@@@@@=="+stats.getConnectCount()+"==@@@@@@@@@###########");
			////System.out.println("########@@@@@@Session create count of module@@@@@=="+stats.getSessionOpenCount()+"==@@@@@@@@@###########");
			////System.out.println("########@@@@@@Session close count of module@@@@@=="+stats.getSessionCloseCount()+"==@@@@@@@@@###########");
			////System.out.println("########@@@@@@End of Session statistics for the module:::::::"+sessionFactoryKey+"::::::@@@@@@@@@###########");
			json.append("{");
			json.append("\"moduleKey\":").append("\"").append(sessionFactoryKey).append("\",");
			json.append("\"connectionCount\":").append("\"").append(stats.getConnectCount()).append("\",");
			json.append("\"createCount\":").append("\"").append(stats.getSessionOpenCount()).append("\",");
			json.append("\"closeCount\":").append("\"").append(stats.getSessionCloseCount()).append("\"");
			if(counter!=keySet.size())
			{
				json.append("},");
			}
			else
			{
				json.append("}");
			}
		}
		json.append("]");
		
		////System.out.println("JSON : "+json);
		
		
		
		
			writer = response.getWriter();
			writer.print(json.toString());
			writer.flush();
			writer.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			if(writer!=null)
			{
				writer.close();
			    writer=null;		
			
			}
			
			
		}
		
		
	}
}