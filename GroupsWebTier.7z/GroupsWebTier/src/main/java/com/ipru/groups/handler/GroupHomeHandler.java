package com.ipru.groups.handler;

import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.otp.po.OTPNumberParamBean;
import com.tcs.security.annotations.MethodPost;

public class GroupHomeHandler extends IneoBaseHandler {
	
	private static final long serialVersionUID = 1L;

	@MethodPost
	public Event getBizRequestForLoadLoginTypeDetails(RequestContext context) throws Exception {
		
		String selectedLoginType = null;
		
		selectedLoginType = (String) context.getFlowScope().get("selectedLoginType");
		
		context.getFlowScope().put("Response", selectedLoginType);
		
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub
		
	}

}
