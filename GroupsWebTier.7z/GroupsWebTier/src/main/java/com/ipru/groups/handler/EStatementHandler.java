package com.ipru.groups.handler;

import com.tcs.web.handler.BaseHandler;

public class EStatementHandler extends BaseHandler{

}
