package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.enums.SAClaimIntimationEnum;
import com.ipru.groups.po.SAClaimIntimationSubmitPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public class SAClaimIntimationValidator {
	
	
	private static SAClaimIntimationValidator single_instance = null; 
	private static final String INFO_LOGGER_NAME = "SAClaimIntimationLogger";
	private static final String CLASS_NAME="SAClaimIntimationValidator";
	
	
	public String validateSAClaimIntiForm(SAClaimIntimationSubmitPO sAClaimIntimationSubmitPO,RequestContext context) throws IPruException, ParseException
	{	
		 StringBuilder infoMessageBuilder=new StringBuilder();
		FLogger.info(INFO_LOGGER_NAME,CLASS_NAME,"validateSAClaimIntiForm","method start");
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
		StringBuffer empName = new StringBuffer();
		empName.append(userVo.getFirstName());
		empName.append(" "+userVo.getLastName());
		//infoMessageBuilder= new StringBuilder();
		if(sAClaimIntimationSubmitPO!=null)
		{
			if(!userVo.getEmpId().equals(sAClaimIntimationSubmitPO.getEmpId()))
			{	
				FLogger.info(INFO_LOGGER_NAME,CLASS_NAME ,"validateSAClaimIntiForm", "Exception Occured, Invalid Employee Id data");
				infoMessageBuilder.append("Invalid Employee Id data");	
			}
			
			if(!userVo.getSelectedPolicy().getClientName().trim().equals(sAClaimIntimationSubmitPO.getTrustName()))
			{
				FLogger.info(INFO_LOGGER_NAME,CLASS_NAME ,"validateSAClaimIntiForm", "Exception Occured, Invalid Trust Name");
				infoMessageBuilder.append(" Invalid Trust Name");
			}
			if (!empName.toString().equals(sAClaimIntimationSubmitPO.getEmpName().toString())) {
				FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Employee Name data");
				infoMessageBuilder.append("Invalid Employee Name data");
			}
			
			if(!userVo.getPolicyNo().equals(sAClaimIntimationSubmitPO.getPolicyNo()))
			{
				FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Policy No");
				infoMessageBuilder.append("Invalid Policy No");
			}
			
			if (!validatePanField(sAClaimIntimationSubmitPO.getPanNumber(), 10, 10)) {
				FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Pan Card data");
				infoMessageBuilder.append("Invalid Pan Card data");
				
			}

			if(isNotNull(sAClaimIntimationSubmitPO.getTypeOfClaim()))
			{
				if(validateDropDown(sAClaimIntimationSubmitPO.getTypeOfClaim(),SAClaimIntimationEnum.getTypeOfClaimEnumList()))
				{
						if(!validateDob(sAClaimIntimationSubmitPO.getDateType()))
						{
							FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured,Please pass valid Date of Leaving");
							infoMessageBuilder.append("Please pass valid Date of Leaving");
						}
						//Annuitants Information Check
						if (!validateNumericField(sAClaimIntimationSubmitPO.getBeneficiary().getAccountNumber(),16)) {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Bank Account Number data");
							infoMessageBuilder.append("Invalid Bank Account Number data");
						}
						if (!validateAlpField(sAClaimIntimationSubmitPO.getBeneficiary().getBankName(), 100)) {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Bank Name data");
							infoMessageBuilder.append("Invalid Bank Name data");
						}
						if(!validateBankBranch(sAClaimIntimationSubmitPO.getBeneficiary().getBranch(),20))
						{
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Bank Branch");
							infoMessageBuilder.append("Invalid Bank Branch");
						}
						if(!validateDob(sAClaimIntimationSubmitPO.getBeneficiary().getAnnuDOB()))
						{
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Date Of Birth");
							infoMessageBuilder.append("Invalid Date of Birth");
						}
						if(!validateDropDown(sAClaimIntimationSubmitPO.getBeneficiary().getGender(),SAClaimIntimationEnum.getGenderEnumList()))
						{
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Gender");
							infoMessageBuilder.append("Invalid Gender");
						}
						
						if(!validateDropDown(sAClaimIntimationSubmitPO.getAnnuityOptionValue(), SAClaimIntimationEnum.getAnnuityOptionsEnumList()))
						{
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Annuity Options");
							infoMessageBuilder.append("Invalid Annuity Options");
						}
						
						if(isNotNull(sAClaimIntimationSubmitPO.getModeOfPayment()))
						{
							if(!validateDropDown(sAClaimIntimationSubmitPO.getModeOfPayment(), SAClaimIntimationEnum.getModeOfPaymentEnumList()))
							{
								FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Mode of Payment");
								infoMessageBuilder.append("Invalid Mode Of Payment");
							}
							
							if(sAClaimIntimationSubmitPO.getModeOfPayment().equals(SAClaimIntimationEnum.ModeOfPayment.MODE3.getModeOfPayment()))
							{
								if (!validateIfscField(sAClaimIntimationSubmitPO.getIfsc(),11)) {
									FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid IFSC Code");
									infoMessageBuilder.append("Found Invalid IFSC Code");
								}
								if (!validateMICRField(sAClaimIntimationSubmitPO.getMicr(), 9,9)) {
									FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid MICR Code");
									infoMessageBuilder.append("Found Invalid MICR Code ");
									
								}
							}
						}
						else
						{
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Please provide Mode of Payment");
							infoMessageBuilder.append("Please provide Mode of Payment");
						}
						
						if(!validateDropDown(sAClaimIntimationSubmitPO.getFreqOfPayment(), SAClaimIntimationEnum.getPaymentFrequencyEnumList()))
						{
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Payment Frequency");
							infoMessageBuilder.append("Invalid Payment Frequency");
						}
						
						if (!validateMobField(sAClaimIntimationSubmitPO.getMobileNumber(), 10, 10)) {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Mobile Number data");
							infoMessageBuilder.append("Invalid Mobile Number data");
						}
						
						if (!validateAddressField1(sAClaimIntimationSubmitPO.getCompBuildName())) {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Company Or BuildingName data");
							infoMessageBuilder.append("Invalid Company Or BuildingName data");
						}
						if (!validateAddressField2(sAClaimIntimationSubmitPO.getFlatUnitNo())) {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Flat Or UnitNumber data");
							infoMessageBuilder.append("Invalid Flat Or UnitNumber data");
						}
						if (!validateAddressField3(sAClaimIntimationSubmitPO.getStreetArea())) {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Street Or Area data");
							infoMessageBuilder.append("Invalid Street Or Area data");
						}
						if (!validateNumericField(sAClaimIntimationSubmitPO.getPincode(), 6)) {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Pincode data");
							infoMessageBuilder.append("Invalid Pincode data");
						}
						if (!validateNumericField(sAClaimIntimationSubmitPO.getAccountNumber(),16)) {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Bank Account Number data");
							infoMessageBuilder.append("Invalid Bank Account Number data");
						}
						if (!validateAlpField(sAClaimIntimationSubmitPO.getBankName(), 100)) {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Bank Name data");
							infoMessageBuilder.append("Invalid Bank Name data");
						}
						if(!validateBankBranch(sAClaimIntimationSubmitPO.getBranch(), 20))
						{
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Bank Branch data");
							infoMessageBuilder.append("Invalid Bank Branch data");
						}
						
						
						if (!validateEmailField(sAClaimIntimationSubmitPO.getEmailId(), 50, 1)) {
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid EmaildId data");
							infoMessageBuilder.append("Invalid Employee MailID  data");
						}
						
						
						//AnnuityOption Check Spouse Related fields for JLSS Policy
						if(sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions3.getAnnuityOptions())||sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions4.getAnnuityOptions())||sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions14.getAnnuityOptions()))
						{
							if(sAClaimIntimationSubmitPO.getSpouse().getAgeProof()!=null && sAClaimIntimationSubmitPO.getSpouse().getDateOfBirth()!=null && sAClaimIntimationSubmitPO.getSpouse().getFirstName()!=null && sAClaimIntimationSubmitPO.getSpouse().getLastName() !=null && sAClaimIntimationSubmitPO.getSpouse().getSalutation() !=null)
							{
								if (!validateAlpField(sAClaimIntimationSubmitPO.getSpouse().getFirstName(), 20)) {
									FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Spouse First Name");
									infoMessageBuilder.append("Invalid Spouse First Name");
								}
								if (!validateAlpField(sAClaimIntimationSubmitPO.getSpouse().getLastName(), 20)) {
									FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Spouse Last Name");
									infoMessageBuilder.append("Invalid Spouse last Name data");
								}
								if(!validateDob(sAClaimIntimationSubmitPO.getSpouse().getDateOfBirth()))
								{
									FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Date Of Birth");
									infoMessageBuilder.append("Invalid Date of Birth");
								}
							}
							else
							{
								FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured,Please provide Spouse details");
								infoMessageBuilder.append("Please provide Spouse details");
							}
						}
						
						//Annuity Options Check ROP Policy related fields
						if(sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions4.getAnnuityOptions())||sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions8.getAnnuityOptions())||sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions9.getAnnuityOptions())||sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions10.getAnnuityOptions())||sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions12.getAnnuityOptions())||sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions14.getAnnuityOptions()))
						{
							if(sAClaimIntimationSubmitPO.getBeneficiary()!=null)
							{
								if (!validateAlpField(sAClaimIntimationSubmitPO.getBeneficiary().getFirstName(), 20)) {
									FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Employee Name data");
									infoMessageBuilder.append("Invalid Employee Name data");
								}
								if (!validateAlpField(sAClaimIntimationSubmitPO.getBeneficiary().getLastName(), 20)) {
									FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Employee Name data");
									infoMessageBuilder.append("Invalid Employee Name data");
								}
								
								if(!validateDob(sAClaimIntimationSubmitPO.getBeneficiary().getDateOfBirth()))
								{
									FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Date Of Birth");
									infoMessageBuilder.append("Invalid Date of Birth");
								}
								
								if (!validateAddressField1(sAClaimIntimationSubmitPO.getBeneficiary().getCompBuildName())) {
									FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Company Or BuildingName data");
									infoMessageBuilder.append("Invalid Company Or BuildingName data");
									
								}
								if (!validateAddressField2(sAClaimIntimationSubmitPO.getBeneficiary().getFlatUnitNo())) {
									FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Flat Or UnitNumber data");
									infoMessageBuilder.append("Invalid Flat Or UnitNumber data");
									
								}
								if (!validateAddressField3(sAClaimIntimationSubmitPO.getBeneficiary().getStreetArea())) {
									FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Street Or Area data");
									infoMessageBuilder.append("Invalid Street Or Area data");
									
								}
								if (!validateNumericField(sAClaimIntimationSubmitPO.getBeneficiary().getPincode(), 6)) {
									FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Pincode data");
									infoMessageBuilder.append("Invalid Pincode data");
									
								}
								if (!validateEmailField(sAClaimIntimationSubmitPO.getBeneficiary().getEmailId(), 50, 1)) {
									FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Beneficiary EmaildId data");
									infoMessageBuilder.append("Invalid EmployeeMailID 1 data");
								}
									
								if (!validateMobField(sAClaimIntimationSubmitPO.getBeneficiary().getMobileNumber(), 10, 10)) {
										FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Mobile Number data");
										infoMessageBuilder.append("Invalid Mobile Number data");
								}
								if(isNotNull(sAClaimIntimationSubmitPO.getBeneficiary().getCategory())&&sAClaimIntimationSubmitPO.getBeneficiary().getCategory()!=null)
								{
									if(sAClaimIntimationSubmitPO.getBeneficiary().getCategory().toString().equals(SAClaimIntimationEnum.Category.MINOR.getCategory().toString()))
									{

										if (!validateAlpField(sAClaimIntimationSubmitPO.getBeneficiary().getAppointeeFName(), 20)) {
											FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Appointee Name");
											infoMessageBuilder.append("Invalid Appointee First Name");
											
										}
										if (!validateAlpField(sAClaimIntimationSubmitPO.getBeneficiary().getAppointeeLName(), 20)) {
												FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Invalid Appointee Name");
												infoMessageBuilder.append("Invalid Appointee Name");
										}
									}
								}
							}
							else
							{
								FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured, Please provide beneficiary data");
								infoMessageBuilder.append("please provide beneficiary data");
							}
						}
						
						if(sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions4.getAnnuityOptions())||sAClaimIntimationSubmitPO.getAnnuityOptionValue().equals(SAClaimIntimationEnum.AnnuityOptions.annuityOptions14.getAnnuityOptions()))
						{
							if(sAClaimIntimationSubmitPO.getBeneficiary().getFirstName().toLowerCase().equals(sAClaimIntimationSubmitPO.getSpouse().getFirstName().toLowerCase())&&
							sAClaimIntimationSubmitPO.getBeneficiary().getLastName().toLowerCase().equals(sAClaimIntimationSubmitPO.getSpouse().getLastName().toLowerCase())&&
							sAClaimIntimationSubmitPO.getBeneficiary().getDateOfBirth().equals(sAClaimIntimationSubmitPO.getSpouse().getDateOfBirth()))
							{
								FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured,Beneficiary & Spouse cannot be same : Please provide other beneficiary details");
								infoMessageBuilder.append("Beneficiary & Spouse cannot be same : Please provide other beneficiary details");
							}

						}
					
				}
				else
				{
					FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured,Invalid Type of Claim");
					infoMessageBuilder.append("Invalid Type of Claim");
				}
			}
			else
			{
				FLogger.info(INFO_LOGGER_NAME,CLASS_NAME, "validateSAClaimIntiForm", "Exception Occured,Invalid Type of Claim");
				infoMessageBuilder.append("Invalid Type of Claim");
			}
			
			
		}
		return infoMessageBuilder.toString();
	}
	
	
	//validate  employee name, appointee name, beneficiary name , spouse name
	private boolean validateAlpField(String val, Integer num) {

		if (StringUtils.isNotEmpty(val) && StringUtils.isAlphaSpace(val) && CommonValidationUtil.ValidateMaxLength(val, num)) {
			return true;

		}
		else {
			return false;
		}

	}
	
	private boolean validateDob(String dod) throws ParseException {
		if (StringUtils.isNotEmpty(dod)) {
			SimpleDateFormat format1 = new SimpleDateFormat("mm/dd/yyyy",
					Locale.ENGLISH);
			Date date1 = format1.parse(dod);
			Date today = new Date();
			if (date1.before(today)) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	private boolean validateBankBranch(String val,Integer num)
	{
		if (StringUtils.isNotEmpty(val)) {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.BANK_BRANCH_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, num)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	
	//Validate IFSC Field
	private boolean validateIfscField(String val, Integer num) {

		if (StringUtils.isNotEmpty(val)) {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.IFSC_CODE_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(val, num)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}

	}
	
	//Validate Pan Field
	private boolean validatePanField(String val, Integer max, Integer min) {

		if (StringUtils.isNotEmpty(val)) {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.PAN_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, max)
					&& CommonValidationUtil.ValidateMinLength(val, min)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}

	}
	
	//Validate Mob number
	private boolean validateMobField(String val, Integer max, Integer min) {

		if (StringUtils.isNotEmpty(val)) {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(val, max)
					&& CommonValidationUtil.ValidateMinLength(val, min)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}

	}
	
	private boolean validateEmailField(String val, Integer num, Integer min) {
		if (StringUtils.isNotEmpty(val)) {
			if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.EMAILID_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, num)
					&& CommonValidationUtil.ValidateMinLength(val, min)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return true;
		}

	}

	
	private boolean validateNumericField(String val, Integer num) {

		if (StringUtils.isNotEmpty(val) && CommonValidationUtil.ValidateNumeric(val) && CommonValidationUtil.ValidateMaxLength(val, num)) {
			return true;

		}
		else {
			return false;
		}

	}
	
	private boolean validateMICRField(String micr,Integer max,Integer min) {
		if ((CommonValidationUtil.isMatchedPattern(micr, GroupFormValidationConstant.MICR_CODE_VALIDATION_FORGROUP)&& CommonValidationUtil.ValidateMaxLength(micr, max)
				&& CommonValidationUtil.ValidateMinLength(micr, min))) {
			return true;
		}
		else {
			return false;
		}
	}
	
	private boolean validateAddressField1(String address)
	{
		if ((CommonValidationUtil.isMatchedPattern(address, GroupFormValidationConstant.ADDRESS_LINE_ONE_VALIDATION)&&StringUtils.isNotEmpty(address))) {
			return true;
		}
		else {
			return false;
		}
	}

	private boolean validateAddressField2(String address)
	{
		if ((CommonValidationUtil.isMatchedPattern(address, GroupFormValidationConstant.ADDRESS_LINE_TWO_VALIDATION))&&StringUtils.isNotEmpty(address)) {
			return true;
		}
		else {
			return false;
		}
	}
	
	private boolean validateAddressField3(String address)
	{
		if ((CommonValidationUtil.isMatchedPattern(address, GroupFormValidationConstant.ADDRESS_LINE_THREE_VALIDATION))&&StringUtils.isNotEmpty(address)) {
			return true;
		}
		else {
			return false;
		}
	}
	
	private boolean isNotNull(String value)
	{
		if(StringUtils.isEmpty(value)&&StringUtils.isNotBlank(value))
			return false;
		else
			return true;
	
	}
	
	public boolean validateDropDown(String element,ArrayList<String> dropDownList)
	{
		boolean flag=false;
		if(dropDownList.contains(element))
		{
			flag=true;
		}
		return flag;
	}
	
	
	
	public static SAClaimIntimationValidator getSingleton() {
	
		if(single_instance==null)
		{
			single_instance = new SAClaimIntimationValidator();
		}
		return single_instance;
	}
	
}

