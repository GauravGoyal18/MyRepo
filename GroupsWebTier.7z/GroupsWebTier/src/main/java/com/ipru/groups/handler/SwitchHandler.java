package com.ipru.groups.handler;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;
import com.google.gson.reflect.TypeToken;
import com.ipru.generic.po.ResultJsonPO;
import com.ipru.groups.enums.RequestTypeEnum;
import com.ipru.groups.grpswitch.bean.FundDetailsPO;
import com.ipru.groups.grpswitch.bean.FundDetailsVO;
import com.ipru.groups.grpswitch.bean.NSEHolidaysVO;
import com.ipru.groups.grpswitch.bean.SwitchDataLoaderVO;
import com.ipru.groups.grpswitch.bean.SwitchFundDetailsPO;
import com.ipru.groups.grpswitch.bean.SwitchFundDetailsVO;
import com.ipru.groups.grpswitch.bean.SwitchPreFundDetailsPO;
import com.ipru.groups.grpswitch.bean.SwitchPreFundDetailsVO;
import com.ipru.groups.grpswitch.bean.SwitchTransactionPO;
import com.ipru.groups.grpswitch.bean.SwitchTransactionVO;
import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.groups.utilities.DateUtil;
import com.ipru.groups.validators.SwitchValidator;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.PolicyProductFundMasterVO;
import com.ipru.groups.vo.PolicyValidMasterVO;
import com.ipru.groups.vo.ProductDetailsVO;
import com.ipru.groups.vo.ProductFundMasterVO;
import com.ipru.groups.vo.ProductMasterVO;
import com.ipru.groups.vo.ProductSwitchAmountVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class SwitchHandler  extends IneoBaseHandler{
	
	private static final long serialVersionUID = 1L;
	
	
	/**
	 * Fetch Product from policy
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz request for product details from policy
	 *
	 * @author Kashmira
	 */
	public Event getBizRequestForFetchProductDetailsFromPolicy(RequestContext p_ObjContext) throws Exception {
		try{
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForFetchProductDetailsFromPolicy", "Method start");
			
			//Declare Variables
			String clientId = null;
			String policyNo = null;
			String role = null;
			String productType = null;
			String memberType = null;
			String employeeId = null;
			HttpSession httpSession = null;
			IPruUser userVO = null;
			SwitchDataLoaderVO  switchDataLoaderVO = new SwitchDataLoaderVO();
			
			//Fetch client Id, policy Number,employeeId and role - Start
			httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			if(httpSession != null) {
				userVO = (IPruUser) httpSession.getAttribute("userVO");
				if (userVO != null) {
					policyNo = userVO.getPolicyNo();
					clientId = userVO.getClientId();
					role = userVO.getRoles();
					productType = userVO.getProductType();
					memberType = userVO.getRoleType();
					employeeId = userVO.getEmpId();
				}
			}
			//Fetch client Id, policy Number,employeeId and role - End
			
			//comment
		/*	role = "123_Member";
			clientId = "ME11443";
			policyNo =  "00000348";*/
			
			//Set userVO in switchDataLoaderVO
			switchDataLoaderVO.setUserVO(userVO);
			
			
			Object[] paramArray = new Object[1];
			paramArray[0] = policyNo;
	
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
	
			//put value in flowscope
			p_ObjContext.getFlowScope().put("clientId", clientId);
			p_ObjContext.getFlowScope().put("policyNo", policyNo);
			p_ObjContext.getFlowScope().put("role", role);
			p_ObjContext.getFlowScope().put("productType", productType);
			p_ObjContext.getFlowScope().put("memberType", memberType);
			p_ObjContext.getFlowScope().put("employeeId", employeeId);
			p_ObjContext.getFlowScope().put("switchDataLoaderVO", switchDataLoaderVO);
			p_ObjContext.getFlowScope().put("fetchProductDetailsFromPolicy", obj_bizReq);
			
		}
		catch (Exception e) {
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestForFetchProductDetailsFromPolicy", "Exception Occurred ", e);
			throwINeoFlowException(e, "GRSW01", p_ObjContext);
		}
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForFetchProductDetailsFromPolicy", "Method end");
		return success();
	}
	
	/**
	 * 
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz response
	 *
	 * @author Kashmira
	 */
	public Event getBizRequestForLoadSwitchDataOnEntry(RequestContext p_ObjContext) throws Exception {
		try{
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForLoadSwitchDataOnEntry", "Method start");
			
			//Declare Variables
			boolean isActiveProduct = false;
			boolean isValidPolicy = false;
			List<String> applicableFundList = new ArrayList<String>();
			List<String> activeApplicableToFundList = new ArrayList<String>();
			List<String> activeApplicableToFundCodeList = new ArrayList<String>();
			Map<String,FundMasterVO> activeApplicableToFundMap = new HashMap<String,FundMasterVO>();
			String productCode = null;
			String policyNo = null;
			String role = null;
			String memberType = null;
			List<ProductMasterVO> productMasterList = null;
			List<FundMasterVO> fundMasterList = null;
			List<ProductFundMasterVO> productFundMasterList = null; 
			List<ProductSwitchAmountVO> productSwitchAmountMasterList = null;
			List<PolicyValidMasterVO> policyValidMasterList  = null;
			List<PolicyProductFundMasterVO> policyProductFundMasterList = null;
			SwitchDataLoaderVO  switchDataLoaderVO = null;
			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			ProductDetailsVO productDetailsVO;
			
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForFetchProductDetailsFromPolicy");
			
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestForLoadSwitchDataOnEntry", "Error while fetching product details from policy");
					//throwINeoFlowException(bizRes.getStatusVO(), p_ObjContext);
					throwINeoFlowException(new Exception(),"GRSW01",p_ObjContext);
				}
				else {
						//fetch product details from response
						productDetailsVO = (ProductDetailsVO) bizRes.getTransferObjects().get("response1");
								
						//fetch policy
						policyNo = (String)p_ObjContext.getFlowScope().get("policyNo");
						
						//fetch role
						role = (String)p_ObjContext.getFlowScope().get("role");
						
						// fetch memberType
						memberType = (String)p_ObjContext.getFlowScope().get("memberType");
						
						//fetch clientId
						//clientId = (String)p_ObjContext.getFlowScope().get("clientId");
						
						//Fetch product Code
						if(StringUtils.isNotBlank(productDetailsVO.getProductcode())){
							productCode = productDetailsVO.getProductcode().trim();
						}
						
						
							//productCode = "SA1PLUS3DC";
						//role="member";
						//Switch allowed only for member and not for trustee - Start
						if(!(StringUtils.equalsIgnoreCase(memberType, "MEMBER")))
						{
							////System.out.println("Role is not member!!! Only members can perform switch");
							FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForLoadSwitchDataOnEntry", "Role is not member!!! Only members can perform switch");
							//throw new Exception();
							//throw new IPruException("Error","GRSW06");
							throwINeoFlowException(new Exception(),"GRSW06",p_ObjContext);
						  //throwINeoFlowException(new Exception(),"GRSW08",p_ObjContext);
						}
						//Switch allowed only for member and not for trustee - End
						
						//Check if Switch is applicable for the policy - Start
						policyValidMasterList  = (List<PolicyValidMasterVO>)p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.POLICY_VALID_MASTER_LIST);
						isValidPolicy = checkValidPolicy(policyValidMasterList,policyNo);
						
						if(!isValidPolicy)
						{
							FLogger.error("SwitchLogger", "SwitchHandler", "onEntry", "Switch not applicable for this Policy: " +policyNo);
							throwINeoFlowException(new Exception(),"GRSW07",p_ObjContext);
						}
						//Check if Switch is applicable for the policy - End
						
						//Fetch SwitchDataLoaderVO from flowscope
						switchDataLoaderVO = (SwitchDataLoaderVO)p_ObjContext.getFlowScope().get("switchDataLoaderVO");
						 
						//fetch product master from context
						productMasterList = (List<ProductMasterVO>)p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.PRODUCT_MASTER_LIST);
						
						//fetch fund master from context
						fundMasterList = (List<FundMasterVO>)p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.FUND_MASTER_LIST);
						
						//fetch product fund master from context
						productFundMasterList = (List<ProductFundMasterVO>)p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.PRODUCT_FUND_MASTER_LIST);
						
						//fetch min max switch amount from context
						productSwitchAmountMasterList = (List<ProductSwitchAmountVO>)p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.PRODUCT_SWITCH_AMOUNT_MASTER_LIST);
						
						//fetch policy product fund master from context.
						policyProductFundMasterList = this.getPolicyProductFundMasterList(p_ObjContext);
						
						//Minimum Maximum Amount for product in flow scope - Start 
						ProductSwitchAmountVO productSwitchAmount = fetchMinMaxAmountForProduct(productCode,productSwitchAmountMasterList);
						switchDataLoaderVO.setProductSwitchAmount(productSwitchAmount);
						//Minimum Maximum Amount for product in flow scope - End
						
						//Check if product is active - Start
						isActiveProduct = checkActiveProduct(productMasterList,productCode);
						//Check if product is active - End
						
						if(isActiveProduct)
						{
							FLogger.info("SwitchLogger", "SwitchHandler", "onEntry", productCode + " : is Active");
							
							// Check if it is a policy level product
							boolean isPolicyLevelProduct = this.checkPolicyLevelProduct(policyNo,policyProductFundMasterList);
							
							if(isPolicyLevelProduct){
								if(policyProductFundMasterList != null){
									for(PolicyProductFundMasterVO policyProductFundMasterVO : policyProductFundMasterList){
										if(policyProductFundMasterVO != null && StringUtils.equalsIgnoreCase(policyNo,policyProductFundMasterVO.getPpfmPolicyNo()) && StringUtils.equalsIgnoreCase(policyProductFundMasterVO.getIsActive(),"Y") && StringUtils.equalsIgnoreCase(policyProductFundMasterVO.getIsReturnGuarantee(),"N")){
											String fundName = policyProductFundMasterVO.getPpfmFundName();
											activeApplicableToFundList.add(fundName);
											activeApplicableToFundCodeList.add(policyProductFundMasterVO.getPpfmFundCode());
											FundMasterVO fundMasterVO = getFundMaster(policyProductFundMasterVO);											
											activeApplicableToFundMap.put(fundName, fundMasterVO);
										}
									}
								}
							} else {
								//fetch all applicable funds for the product
								if(productFundMasterList != null){
									for(ProductFundMasterVO productFundMaster : productFundMasterList){
										if(StringUtils.equalsIgnoreCase(productFundMaster.getProductCode(), productCode))
										{
											applicableFundList.add(productFundMaster.getFundCode());
										}
									}
								}
								
								//Check if all the applicable funds are active and non return fund and then put/add to map and list - Start
								if(applicableFundList != null && fundMasterList != null)
								{
									for(String applicableFund : applicableFundList){
										
										for(FundMasterVO fundMaster : fundMasterList)
										{
											if(StringUtils.equalsIgnoreCase(fundMaster.getFundCode(), applicableFund))
											{
												if(StringUtils.equalsIgnoreCase(fundMaster.getIsActive(), "Y") && StringUtils.equalsIgnoreCase(fundMaster.getIsReturnGuarantee(), "N")){
													activeApplicableToFundList.add(fundMaster.getFundName());
													activeApplicableToFundCodeList.add(fundMaster.getFundCode());
													activeApplicableToFundMap.put(fundMaster.getFundName(), fundMaster);
												}
											}
										}
										
									}
									
								}
								//Check if all the applicable funds are active and non return fund and then put/add to map and list - End
							}
														
							//Check if to fund list is null - Start
							if(activeApplicableToFundList!=null && activeApplicableToFundList.size() <= 0)
							{
								FLogger.error("SwitchLogger", "SwitchHandler", "onEntry", "activeApplicableToFundList is null i.e No To fund ");
								throwINeoFlowException(new Exception(),"GRSW03",p_ObjContext);
							}
							//Check if to fund list is null - End
							
							switchDataLoaderVO.setActiveApplicableToFundList(activeApplicableToFundList);
							switchDataLoaderVO.setActiveApplicableToFundCodeList(activeApplicableToFundCodeList);
							switchDataLoaderVO.setActiveApplicableToFundMap(activeApplicableToFundMap);
							switchDataLoaderVO.setFundMasterList(fundMasterList);
							
							
							//passing null as no input is required to fetch NSE Details
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", null);
					
							//put values in flow scope
							p_ObjContext.getFlowScope().put("fetchNSEDetails", obj_bizReq);
							p_ObjContext.getFlowScope().put("fundMasterList", fundMasterList);
							p_ObjContext.getFlowScope().put("productCode", productCode);
							p_ObjContext.getFlowScope().put("switchDataLoaderVO", switchDataLoaderVO); 
							
						}else
						{
							FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestForLoadSwitchDataOnEntry", "Not an Active Product");
							//throw new Exception();
							throwINeoFlowException(new Exception(),"GRSW11",p_ObjContext);
						}
						
				}
			}
		}
		
		catch (Exception e) {
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestForLoadSwitchDataOnEntry", "Exception Occurred ", e);
			throwINeoFlowException(e, "GRSW07", p_ObjContext);
		}
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForLoadSwitchDataOnEntry", "Method end");
		return success();
	}
	

	
	
	private FundMasterVO getFundMaster(PolicyProductFundMasterVO policyProductFundMasterVO) {
		FundMasterVO fundMasterVO = null;
		if(policyProductFundMasterVO != null){
			fundMasterVO = new FundMasterVO();
			fundMasterVO.setFundCode(policyProductFundMasterVO.getPpfmFundCode());
			fundMasterVO.setFundName(policyProductFundMasterVO.getPpfmFundName());
			fundMasterVO.setIsActive(policyProductFundMasterVO.getIsActive());
			fundMasterVO.setIsCapital(policyProductFundMasterVO.getIsCapital());
			fundMasterVO.setIsReturnGuarantee(policyProductFundMasterVO.getIsReturnGuarantee());
			fundMasterVO.setIsAssetType(policyProductFundMasterVO.getPpfmAssetType());
		}
		return fundMasterVO;
	}

	private boolean checkPolicyLevelProduct(String policyNo, List<PolicyProductFundMasterVO> policyProductFundMasterList) {
		
		if(policyProductFundMasterList != null && policyNo != null){
			for(PolicyProductFundMasterVO policyProductFundMasterVO : policyProductFundMasterList){
				if(policyProductFundMasterVO != null && policyNo.equalsIgnoreCase(policyProductFundMasterVO.getPpfmPolicyNo())){
					return true;
				}
			}
		}		
		
		return false;
	}

	private boolean checkActiveProduct(List<ProductMasterVO> productMasterList, String productCode) {
		boolean isActiveProduct = false;
		if(productMasterList != null){
			for(ProductMasterVO productMaster : productMasterList){
				if(StringUtils.isNotEmpty(productMaster.getProductCode()) && StringUtils.equalsIgnoreCase(productMaster.getProductCode(), productCode))
				{
					if(StringUtils.equalsIgnoreCase(productMaster.getIsActive(), "Y"))
					{
						isActiveProduct = true;
						break;
					}
				}
			}
		}
		
		return isActiveProduct;
	}

	private ProductSwitchAmountVO fetchMinMaxAmountForProduct(String productCode, List<ProductSwitchAmountVO> productSwitchAmountMasterList) {
		ProductSwitchAmountVO productSwitchAmountVO = null;
		if(productSwitchAmountMasterList != null){
			for(ProductSwitchAmountVO productSwitchAmount : productSwitchAmountMasterList){
				
				if(StringUtils.equalsIgnoreCase(productSwitchAmount.getProductCode(), productCode))
				{
					productSwitchAmountVO = productSwitchAmount;
					break;
				}
				
			}
		}
		return productSwitchAmountVO;
	}

	private boolean checkValidPolicy(List<PolicyValidMasterVO> policyValidMasterList, String policyNo) {
		boolean isValidPolicy = false;
		if(policyValidMasterList != null){
			for(PolicyValidMasterVO policyValid : policyValidMasterList){
				
				if(StringUtils.equalsIgnoreCase(policyValid.getPolicyNo(), policyNo))
				{
					isValidPolicy = true;
					break;
				}
				
			}
		}
		return isValidPolicy;
	}

	/**
	 * the biz response for NSE Details
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz response
	 *
	 * @author Kashmira
	 */
	@MethodPost
	public Event getBizResponseForFetchNSEDetails(RequestContext p_ObjContext) throws Exception {
		
		try{
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForFetchNSEDetails", "Method Start");
			
			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForFetchNSEDetails");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForFetchNSEDetails", "Error while getting response from service");
					throwINeoFlowException(new Exception(),"GRSW12",p_ObjContext);
				}
				else {
					
					SwitchDataLoaderVO  switchDataLoaderVO = (SwitchDataLoaderVO)p_ObjContext.getFlowScope().get("switchDataLoaderVO");

					//fetch NSC holiday details
					List<NSEHolidaysVO> nseHolidaysList =  (List<NSEHolidaysVO>) bizRes.getTransferObjects().get("response1");
					//set in switch data loader
					switchDataLoaderVO.setNseHolidaysList(nseHolidaysList);
					
					String resultJson = gsonJSON.toJson(switchDataLoaderVO);

					//set values in flow scope
					p_ObjContext.getFlowScope().put("Response", resultJson);//front end
					p_ObjContext.getFlowScope().put("nseHolidaysList", nseHolidaysList);


				}
			}
			
		}
		catch(Exception e){
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForFetchNSEDetails", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRSW12",p_ObjContext);
		}
		
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForFetchNSEDetails", "Method End");
		return success();
	}

	
	/**
	 * the biz request for fetching Fund NAV and Unit
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz request
	 *
	 * @author Kashmira
	 */
	public Event getBizRequestForFetchFundNavUnit(RequestContext p_ObjContext) throws Exception {
		try{
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForFetchFundNavUnit", "Method start");
			
			String role = null;
			String policyNo = null;
			String clientId = null;
			String employeeId = null;
					
			//fetch policy
			policyNo = (String)p_ObjContext.getFlowScope().get("policyNo");
			
			//fetch role
			role = (String)p_ObjContext.getFlowScope().get("role");
			
			//fetch clientId
			clientId = (String)p_ObjContext.getFlowScope().get("clientId");
			

			//fetch employee Id
			employeeId = (String)p_ObjContext.getFlowScope().get("employeeId");
			
			//details from fund master table - set in on entry
			//List<FundMasterVO> fundMasterList = (List<FundMasterVO>) p_ObjContext.getFlowScope().get("fundMasterList");
			
			Object[] paramArray = new Object[1];
			Map<String,String> map = new HashMap<String,String>();
			
			if(StringUtils.contains(role, "Member"))
			{
				map.put("policy",policyNo);
				map.put("employeeId",employeeId);
				
			}
			
			else if(StringUtils.contains(role, "TRUST"))
			{
				map.put("policy",policyNo);
			}
			//map.remove("employeeId");map.put("clientId",clientId);
			
			paramArray[0] = map;
	
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
	
			p_ObjContext.getFlowScope().put("fetchFundNAV", obj_bizReq);
			
		}
		catch (Exception e) {
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestForFetchFundNavUnit", "Exception Occurred ", e);
			throwINeoFlowException(e, "GRSW09", p_ObjContext);//Check what error to throw *************************
		}
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForFetchFundNavUnit", "Method End");
		return success();
	}
	
	/**
	 * the biz response for fetching Fund NAV and Unit
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz response for fetching Fund NAV and Unit
	 *
	 * @author Kashmira
	 */
	public Event getBizResponseForFetchFundNavUnit(RequestContext p_ObjContext) throws Exception {
		try{
			
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForFetchFundNavUnit", "Method Start");
			
			List<FundDetailsVO> fundNAVList;
			StringBuilder fundCode = new StringBuilder();
			String fundCodes = null;
			String policyNo = null;
			String fundNAVString = null;

			//Fetch policy from flowscope
			policyNo = (String)p_ObjContext.getFlowScope().get("policyNo");
			
			//details from fund master table
			List<FundMasterVO> fundMasterList = (List<FundMasterVO>) p_ObjContext.getFlowScope().get("fundMasterList");
			
			BizResponse response = new BizResponse();
			String responseCheck = "";
			response = (BizResponse) p_ObjContext.getFlowScope().get("bizResForFetchFundNavUnit");
			
			if (response != null) {
				responseCheck = (String) response.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForFetchFundNavUnit", "Error while getting response from service");
					throwINeoFlowException(new Exception(),"GRSW10",p_ObjContext);
				}
				else {
					
					fundNAVString = (String) response.getTransferObjects().get("response1");
					if(StringUtils.isBlank(fundNAVString))
					{
						FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForFetchFundNavUnit", "Error fetching data from webservice");
						throwINeoFlowException(new Exception(),"GRSW10",p_ObjContext);
					}
					
					//String fundNAVString ="[{\"funddesc\":\"Group Debt Fund\",\"sfin\":\"ULGF 002 03/04/03 GDebt 105\",\"fundcode\":\"DBT\",\"units\":\"37226.039\",\"navValue\":\"30.4453\",\"totalAmount\":1133357.9251666998},{\"funddesc\":\"Group Growth Fund\",\"sfin\":\"ULGF 004 30/10/03 GGrowth 105\",\"fundcode\":\"GTH\",\"units\":\"21262.845\",\"navValue\":\"60.1372\",\"totalAmount\":1278687.962334}]";
					
					//json string to object(List<FundMasterVO>)
					fundNAVList = gsonJSON.fromJson(fundNAVString, new TypeToken<List<FundDetailsVO>>(){}.getType());
					
					//rounding NAV Unit and Amount
					if(fundNAVList != null){
						roundNAVUnitAmount(fundNAVList);
					}
					
					
					List<FundDetailsPO> fundDetailPOList = null;
					if (fundNAVList != null) {
						fundDetailPOList = new ArrayList<FundDetailsPO>();
						for (FundDetailsVO fundDetailVO : fundNAVList) {
							
							//VO to PO
							FundDetailsPO fundDetailPO = dozerBeanMapper.map(fundDetailVO, FundDetailsPO.class);
							fundDetailPOList.add(fundDetailPO);
							
							//Add fund code to list separated by comma
							fundCode.append(fundDetailVO.getFundCode());
							fundCode.append(",");
						}
					}
					SwitchDataLoaderVO  switchDataLoaderVO = (SwitchDataLoaderVO)p_ObjContext.getFlowScope().get("switchDataLoaderVO");
					//remove last comma
					fundCodes = fundCode.substring(0, fundCode.length() - 1);
					List<String> fundCodeList = Arrays.asList(fundCodes.split("\\s*,\\s*"));
					//Check if fund is CG fund
					//From Fund must be Not Return Guarantee
					List<String> activeFromFundList = checkNonReturnGuarantee(fundCodeList,fundMasterList);
					
					if(activeFromFundList!=null && activeFromFundList.size() <= 0)
					{
						FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForFetchFundNavUnit", "From Fund List is null");
						throwINeoFlowException(new Exception(),"GRSW02",p_ObjContext);
					}
					
					switchDataLoaderVO.setActiveApplicableFromFundList(activeFromFundList);
					FundDetailsPO fundDetailsPO = new FundDetailsPO(fundDetailPOList, policyNo,activeFromFundList);
					
					//Convert to json String
					String fundDetailJsonString = gsonJSON.toJson(fundDetailsPO, FundDetailsPO.class);
					
					//set webservice response in flowscope
					p_ObjContext.getFlowScope().put("Response", fundDetailJsonString);
					
					//to combine response
					p_ObjContext.getFlowScope().put("fundNAVList", fundNAVList);
					
					//to hit second webservice
					p_ObjContext.getFlowScope().put("fundCodes", fundCodes);
					
					//used in second webservice
					p_ObjContext.getFlowScope().put("activeFromFundList", activeFromFundList);
					p_ObjContext.getFlowScope().put("switchDataLoaderVO", switchDataLoaderVO);
				}
			}
			
		}
		catch (Exception e) {
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForFetchFundNavUnit", "Exception came ", e);
			throwINeoFlowException(e, "GRSW10", p_ObjContext); // Check what error to throw
		}
		
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForFetchFundNavUnit", "Method End");
		return success();
	}
	

	


/*	@MethodPost
	public Event fetchFromFund(RequestContext p_ObjContext) throws Exception {
		try{
			////System.out.println("In handler: fetchFromFund : called when form is submitted");
			StringBuilder sb = new StringBuilder();
			String fundCodes = null;
			List<FundMasterVO> fundMasterList = (List<FundMasterVO>) p_ObjContext.getFlowScope().get("fundMasterList");
			
			List<FundDetailsVO> fundNAVList = (List<FundDetailsVO>) p_ObjContext.getFlowScope().get("fundNAVList");
			for (FundDetailsVO fundDetailVO : fundNAVList) {
				
				//Add fund code to list separated bu comma
				sb.append(fundDetailVO.getFundCode());
		        sb.append(",");
			}
			
			fundCodes = sb.substring(0, sb.length() - 1);
			List<String> activeFromFundList = checkCGFund(fundCodes,fundMasterList);
			activeFromFundList.add("1");
			String activeApplicableFromFundJsonString = gsonJSON.toJson(activeFromFundList);
			p_ObjContext.getFlowScope().put("activeApplicableFromFundJsonString", activeApplicableFromFundJsonString);
			
		}
		catch(Exception e){
			
		}
		return success();
	}*/
	
	
	/**
	 * the biz request for fetching Returns and Inception
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz request for fetching Returns and Inception
	 *
	 * @author Kashmira
	 */
	public Event getBizRequestForFetchReturnsInception(RequestContext p_ObjContext) throws Exception {
		
		try{
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForFetchReturnsInception", "Method Start");
			
			/*int i = 10;
			if(i==0)
				throwINeoFlowException(new Exception(),"GRSW07",p_ObjContext);*/
			
			String fundCodes = null;
			
			//Fetch Fund Codes from flowscope
			fundCodes =  (String) p_ObjContext.getFlowScope().get("fundCodes");
			
			Object[] paramArray = new Object[1];
			paramArray[0] = fundCodes;
	
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			
			p_ObjContext.getFlowScope().put("fetchReturnsInception", obj_bizReq);
			
		}
		catch(Exception e){
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestForFetchReturnsInception", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRSW09",p_ObjContext);
		}
		
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForFetchReturnsInception", "Method End");
		return success();
	}
	/**
	 * the biz response for fetching Returns and Inception
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz response for fetching Returns and Inception
	 *
	 * @author Kashmira
	 */
	public Event getBizResponseForFetchReturnsInception(RequestContext p_ObjContext) throws Exception {
		
		try{	
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForFetchReturnsInception", "Method Start");
			String fundPerformanceString = null;
			List<FundDetailsVO> fundNAVList = null;
			String policyNo = null;
			List<FundDetailsPO> fundDetailPOList = null;
					
			//fetch policy
			policyNo = (String)p_ObjContext.getFlowScope().get("policyNo");
			
			//Fetch Fund NAV response from flowscope
			fundNAVList = (List<FundDetailsVO>) p_ObjContext.getFlowScope().get("fundNAVList");
			
			BizResponse response = new BizResponse();
			String responseCheck = "";
			
			response = (BizResponse) p_ObjContext.getFlowScope().get("bizResForFetchReturnsInception");
			
			
			if (response != null) {
				responseCheck = (String) response.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForFetchNSEDetails", "Error while getting response from service");
					throwINeoFlowException(new Exception(),"GRSW04",p_ObjContext);
				}
				else {
						
					fundPerformanceString = (String) response.getTransferObjects().get("response1");
					
					//Hit CSR Webservice
					//http://10.50.37.138:9443/digital/FundPerformaceWS?fundCodes=GCGB3
					//String fundPerformanceString = FundPerformanceClient.fetchFundDetails(fundCodes);
					
					Map<String,FundDetailsVO> returnInceptionVOMap = gsonJSON.fromJson(fundPerformanceString, new TypeToken<Map<String,FundDetailsVO>>(){}.getType());
					
					FundDetailsVO returnInception;
				
					//Combine 2 Webservice response
					if(fundNAVList != null && returnInceptionVOMap != null){
						for(FundDetailsVO fundNAV : fundNAVList){
							for (Map.Entry<String, FundDetailsVO> entry : returnInceptionVOMap.entrySet()) {
								
								
								String key = entry.getKey();
								returnInception = entry.getValue();
								
								if(StringUtils.equalsIgnoreCase(key.trim(), fundNAV.getFundCode().trim()))
								{
									fundNAV.setAssetsInvested(returnInception.getAssetsInvested());
									fundNAV.setAumDebtCategory(returnInception.getAumDebtCategory());
									fundNAV.setAumEquityCategory(returnInception.getAumEquityCategory());
									fundNAV.setAumMoneyMarketCashCategory(returnInception.getAumMoneyMarketCashCategory());
									fundNAV.setBenchMark(returnInception.getBenchMark());
									fundNAV.setBenchmarkFifthYear(returnInception.getBenchmarkFifthYear());
									fundNAV.setBenchmarkFirstYear(returnInception.getBenchmarkFirstYear());
									fundNAV.setBenchmarkInception(returnInception.getBenchmarkInception());
									fundNAV.setBenchmarkThirdYear(returnInception.getBenchmarkThirdYear());
									fundNAV.setFifthYearReturns(returnInception.getFifthYearReturns());
									fundNAV.setFirstYearReturns(returnInception.getFirstYearReturns());
									fundNAV.setFundName(returnInception.getFundName());
									fundNAV.setFundObjective(returnInception.getFundObjective());
									fundNAV.setReturnsSinceInception(returnInception.getReturnsSinceInception());
									fundNAV.setInceptionDate(returnInception.getInceptionDate());
									fundNAV.setPortfolioByMaturityBalAvg(returnInception.getPortfolioByMaturityBalAvg());
									fundNAV.setPortfolioByMaturityDebtAvg(returnInception.getPortfolioByMaturityDebtAvg());
									fundNAV.setThirdYearReturns(returnInception.getThirdYearReturns());
														
									break;
								}
							}
						}
					}
					//Combine 2 Webservice response - End
					
					//Convert Response from VO to PO and then put in list
					if (fundNAVList != null) {
						fundDetailPOList = new ArrayList<FundDetailsPO>();
						for (FundDetailsVO fundDetailVO : fundNAVList) {
							//Convert VO to PO
							FundDetailsPO fundDetailPO = dozerBeanMapper.map(fundDetailVO, FundDetailsPO.class);
							fundDetailPOList.add(fundDetailPO);
						}
					}
					
					List<String> activeFromFundList = (List<String>) p_ObjContext.getFlowScope().get("activeFromFundList");
					FundDetailsPO fundDetailsPO = new FundDetailsPO(fundDetailPOList, policyNo,activeFromFundList);
			
					String fundDetailJsonString = gsonJSON.toJson(fundDetailsPO, FundDetailsPO.class);
					
					p_ObjContext.getFlowScope().put("Response", fundDetailJsonString);
				}
			}
			
		}
		catch(Exception e){
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestForFetchReturnsInception", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRSW04",p_ObjContext);
		}
		
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForFetchReturnsInception", "Method End");
		return success();
	}
	
	/**
	 * the biz request for checking if one switch is performed
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz request for checking if one switch is performed
	 *
	 * @author Kashmira
	 */
	
	@MethodPost
	public Event getBizRequestForCheckOneSwitchPerDay(RequestContext p_ObjContext) throws Exception {
		
		try{
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForCheckOneSwitchPerDay", "Method Start");
			
			//Declare Variables
			String clientId = null;
					
			//Fetch policy values from flowscope
			clientId = (String) p_ObjContext.getFlowScope().get("clientId");
			
			Object[] paramArray = new Object[1];
			paramArray[0] = clientId;
	
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
	
			p_ObjContext.getFlowScope().put("checkOneSwitchPerDayBizReq", obj_bizReq); 
		}
		catch(Exception e){
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestForCheckOneSwitchPerDay", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRSW09",p_ObjContext);
		}
		
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestforSaveSwitch", "Method End");
		return success();
	}
	
	/**
	 * the biz response for checking if one switch is performed
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz response for checking if one switch is performed
	 *
	 * @author Kashmira
	 */
	@MethodPost
	public Event getBizResponseForCheckOneSwitchPerDay(RequestContext p_ObjContext) throws Exception {
		
		try{
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForCheckOneSwitchPerDay", "Method Start");
			
			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForCheckOneSwitchPerDay");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForCheckOneSwitchPerDay", "Error while getting response from service");
					throwINeoFlowException(bizRes.getStatusVO(), p_ObjContext);
				}
				else {
					

					boolean checkSwitchAllowed =  (Boolean) bizRes.getTransferObjects().get("response1");
					
					if(checkSwitchAllowed)
					{
						FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForCheckOneSwitchPerDay", "Switch can be performed only once a day!!!");
						throwINeoFlowException(new Exception(),"GRSW08",p_ObjContext);
						
					}


				}
			}
			
		}
		catch(Exception e){
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForCheckOneSwitchPerDay", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRSW08",p_ObjContext);
		}
		
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForCheckOneSwitchPerDay", "Method End");
		return success();
	}
	
	/**
	 * the biz request for fetching pre fund details
	 * 
	 * Getting values from json
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz request for fetching pre fund details
	 *
	 * @author Kashmira
	 */
	
	@MethodPost
	public Event getBizRequestForFetchPreFundAndFundDetails(RequestContext p_ObjContext) throws Exception {
		
		try{
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForFetchPreFundAndFundDetails", "Method Start");
			
			//Declare Variables
			String policyNo = null;
			String clientId = null;
			String productCode = null;
			String employeeId = null;
			String role = null;
			String memberType = null;
			List<NSEHolidaysVO> nseHolidaysList;
			Set<SwitchFundDetailsPO> switchFundDetailsPOSet =new HashSet<SwitchFundDetailsPO>(0);
			Set<String> fromToFundCodeSet =new HashSet<String>(0);
			HttpServletRequest request = null;
			SwitchTransactionPO switchTransactionPO = null;
			Date switchExecutionDate = null;
					
			//Fetch values from flowscope
			policyNo = (String) p_ObjContext.getFlowScope().get("policyNo");
			clientId = (String) p_ObjContext.getFlowScope().get("clientId");
			productCode = (String) p_ObjContext.getFlowScope().get("productCode");
			role = (String) p_ObjContext.getFlowScope().get("role");
			employeeId = (String) p_ObjContext.getFlowScope().get("employeeId");
			nseHolidaysList = (List<NSEHolidaysVO>) p_ObjContext.getFlowScope().get("nseHolidaysList");
			memberType = (String) p_ObjContext.getFlowScope().get("memberType");
			
			
			request = (HttpServletRequest)p_ObjContext.getExternalContext().getNativeRequest();
			
			//Convert json to object
			switchTransactionPO = gsonJSON.fromJson(request.getReader(), SwitchTransactionPO.class);
			
			//to set other field
			switchTransactionPO.setPolicyNo(policyNo);
			switchTransactionPO.setClientId(clientId);
			switchTransactionPO.setRole(role);
			switchTransactionPO.setProductCode(productCode);
			switchTransactionPO.setRequestType(RequestTypeEnum.SWITCHFUND.getRequestType());
			switchTransactionPO.setCreatedBy("App");
			switchTransactionPO.setUpdatedDate(new Date());
			switchTransactionPO.setUpdatedBy("App");
			switchTransactionPO.setMemberType(memberType);
			
			
			//Request Execution Date
			switchExecutionDate = getSwitchDate(p_ObjContext,nseHolidaysList);
			switchTransactionPO.setReqExecutionDate(switchExecutionDate);
			
			if(!ArrayUtils.isEmpty(switchTransactionPO.getSwitchFundDetails()))//array
			{
				for(SwitchFundDetailsPO switchFundDetailsPO : switchTransactionPO.getSwitchFundDetails()) {
					
					
					switchFundDetailsPO.setCreatedBy("App");
					switchFundDetailsPO.setUpdatedDate(new Date());
					switchFundDetailsPO.setUpdatedBy("App");
					
					//Set amount to 0 if request type is Units
					if(StringUtils.equalsIgnoreCase(switchTransactionPO.getSwitchType(),"Units"))
					{
						switchFundDetailsPO.setFromAmount("0");
					}
					//MO
					switchFundDetailsPO.setSwitchTransactionPO(switchTransactionPO);
					switchFundDetailsPOSet.add(switchFundDetailsPO);
					
					//Put from and to fund code in set so as to save in the pre fund table
					fromToFundCodeSet.add(switchFundDetailsPO.getFromFundCode());
					fromToFundCodeSet.add(switchFundDetailsPO.getToFundCode());
					
				}
			}
			//OM
			switchTransactionPO.setSwitchFundDetailsSet(switchFundDetailsPOSet);
			
			p_ObjContext.getFlowScope().put("switchTransactionPO", switchTransactionPO); 
			//set to comma separated String values
			String fromToFundCode =  StringUtils.join(fromToFundCodeSet, ',');
			
			Map<String,String> map = new HashMap<String,String>();
			
			if(StringUtils.contains(role, "Member"))
			{
				map.put("employeeId",employeeId);
				map.put("policy",policyNo);
				
			}
			
			else if(StringUtils.contains(role, "TRUST"))
			{
				map.put("policy",policyNo);
			}
			
			map.put("fromToFundCode",fromToFundCode);
				
			Object[] paramArray = new Object[1];
			paramArray[0] = map;
	
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
	
			p_ObjContext.getFlowScope().put("fetchPreFundAndFundDetails", obj_bizReq); 
		}
		catch(Exception e){
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestForFetchPreFundAndFundDetails", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRSW09",p_ObjContext);
		}
		
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestForFetchPreFundAndFundDetails", "Method End");
		return success();
	}
	
	/**
	 * the biz response for fetching pre fund details
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz response for fetching pre fund details
	 *
	 * @author Kashmira
	 */
	@MethodPost
	public Event getBizResponseForFetchPreFundAndFundDetails(RequestContext p_ObjContext) throws Exception {
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForFetchPreFundDetails", "Method Start");
		try{
			
			BizResponse bizRes = new BizResponse();
			Set<SwitchPreFundDetailsVO> switchPreFundDetailsVOSet =new HashSet<SwitchPreFundDetailsVO>(0);
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForFetchPreFundAndFundDetails");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForFetchPreFundAndFundDetails", "Error while getting response from service");
					throwINeoFlowException(bizRes.getStatusVO(), p_ObjContext);
				}
				else {
					
					SwitchTransactionPO switchTransactionPO = null;
					switchTransactionPO = (SwitchTransactionPO) p_ObjContext.getFlowScope().get("switchTransactionPO");
					
					//PO to VO
					SwitchTransactionVO switchTransactionVO = dozerBeanMapper.map(switchTransactionPO, SwitchTransactionVO.class);

					List<SwitchPreFundDetailsVO> switchPreFundDetailsVOList =  (List<SwitchPreFundDetailsVO>) bizRes.getTransferObjects().get("response1");
					
					if(switchPreFundDetailsVOList == null)
					{
						FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForFetchFundNavUnit", "Error fetching data from webservice");
						throwINeoFlowException(new Exception(),"GRSW13",p_ObjContext);
					}
					
					Set<String> fromToFundCode = new HashSet<String>();
					for(SwitchPreFundDetailsVO switchPreFundDetailsVO : switchPreFundDetailsVOList) {
						
						switchPreFundDetailsVO.setCreatedBy("App");
						switchPreFundDetailsVO.setUpdatedDate(new Date());
						switchPreFundDetailsVO.setUpdatedBy("App");
						//MO
	//					switchPreFundDetailsVO.setSwitchTransactionVO(switchTransactionVO);
						switchPreFundDetailsVOSet.add(switchPreFundDetailsVO);
						
						/*fromToFundCode.add(switchFundDetailsPO.getFromFundCode());
						fromToFundCode.add(switchFundDetailsPO.getToFundCode());*/
					}
					//OM
					switchTransactionVO.setSwitchPreFundDetailsSet(switchPreFundDetailsVOSet);
					//VO to PO
					switchTransactionPO = dozerBeanMapper.map(switchTransactionVO, SwitchTransactionPO.class);
									
					for(SwitchPreFundDetailsPO oneSwitchPreFundDetailsPO: switchTransactionPO.getSwitchPreFundDetailsSet()){
						oneSwitchPreFundDetailsPO.setSwitchTransactionPO(switchTransactionPO);
					}
					
					p_ObjContext.getFlowScope().put("switchTransactionPO", switchTransactionPO);
					
				}
			}
			
		
			
		
		}
		catch(Exception e){
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseForFetchPreFundAndFundDetails", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRSW13",p_ObjContext);
		}
		
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseForFetchPreFundDetails", "Method End");
		return success();
	}
	
	/**
	 * the biz request for saving switch details
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz requset for saving switch details
	 *
	 * @author Kashmira
	 */
	@MethodPost
	public Event getBizRequestforSaveSwitch(RequestContext p_ObjContext) throws Exception {
		String productType = null;
		String memberType = null;
		FunctionalityMasterVO functionality;
		try{
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestforSaveSwitch", "Method Start");
	
			 productType = (String)p_ObjContext.getFlowScope().get("productType");
			
			
			SwitchTransactionPO switchTransactionPO = null;
			switchTransactionPO = (SwitchTransactionPO) p_ObjContext.getFlowScope().get("switchTransactionPO");
			
			//Back end validation - Validate Fields --- Start
			SwitchValidator switchValidator = new SwitchValidator();
			String errorSuccessMessage = switchValidator.validateSwitch(switchTransactionPO, p_ObjContext);
			
			if (StringUtils.isNotBlank(errorSuccessMessage)) {
				this.setValidationErrorMessages(errorSuccessMessage);
				FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestforSaveSwitch", "Data should not be null");
				throwINeoFlowException(new ServiceException("GRSW05", errorSuccessMessage), p_ObjContext);
			}
			//Back end validation - Validate Fields --- End
			
		/*	if(StringUtils.equalsIgnoreCase(switchTransactionPO.getSwitchType(), "Units"))
			{
				switchTransactionPO.set
			}else if(StringUtils.equalsIgnoreCase(switchTransactionPO.getSwitchType(), "Amount"))
			{
				
			}*/
			
			//PO to VO
			SwitchTransactionVO switchTransactionVO = dozerBeanMapper.map(switchTransactionPO, SwitchTransactionVO.class);
			
			/*for(SwitchFundDetailsVO oneSwitchFundDetailsVO: switchTransactionVO.getSwitchFundDetailsSet()){
				oneSwitchFundDetailsVO.setSwitchTransactionVO(switchTransactionVO);
			}*/
			
			/*for(SwitchPreFundDetailsVO oneSwitchPreFundDetailsVO: switchTransactionVO.getSwitchPreFundDetailsSet()){
				oneSwitchPreFundDetailsVO.setSwitchTransactionVO(switchTransactionVO);
			}*/
			
			//Required for Spaarc call log
			functionality = getFunctionality(p_ObjContext);
			switchTransactionVO.setFunctionality(functionality);
			switchTransactionVO.setProductType(productType);
				
			Object[] paramArray = new Object[1];
			paramArray[0] = switchTransactionVO;
	
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
	
			p_ObjContext.getFlowScope().put("saveBizReq", obj_bizReq); 
		}
		catch(Exception e){
			FLogger.error("SwitchLogger", "SwitchHandler", "getBizRequestforSaveSwitch", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRSW02",p_ObjContext);
		}
		
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizRequestforSaveSwitch", "Method End");
		return success();
	}
	
	
	
	/**
	 * the biz response for saving switch details
	 * 
	 * @param p_ObjContext - request Context
	 * @return the biz response for saving switch details
	 *
	 * @author Kashmira
	 */
	
	@ MethodPost
	public Event getBizResponseforSaveSwitch(RequestContext context) throws Exception{
		FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseforSaveSwitch", "Method Start");
		try{
			
			String responseCheck = null;
			BizResponse bizRes = new BizResponse();
			String resultJson="";
			Map<String,String> map = new HashMap<String,String>();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForSaveSwitch");
			
			if (bizRes != null){
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error("SwitchLogger", "SwitchHandler", "getBizResponseforSaveSwitch", "Error came while getting response from service");
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {
					SwitchTransactionVO switchTransactionVO = (SwitchTransactionVO) bizRes.getTransferObjects().get("response1");
					
					
					map.put("switchTransactionId", switchTransactionVO.getSwitchTransactionId().toString());
					map.put("switchExecutionDate", DateUtil.formatDate(switchTransactionVO.getReqExecutionDate(), "dd MMM yyyy"));
					
					ResultJsonPO resultMap = new ResultJsonPO();
					resultMap.setResultMap(map);
					resultJson = gsonJSON.toJson(resultMap);
					
					//set values in flow scope
					context.getFlowScope().put("Response", resultJson);

				}
			}
			
			FLogger.info("SwitchLogger", "SwitchHandler", "getBizResponseforSaveSwitch", "Method End");
			return success();
		}
		catch (Exception e) {
			throwINeoFlowException(e,"GRSW02",context);
		}
		return null;
	
	}
	
	/**
	 * Rounding NAV and Unit
	 * 
	 * Unit - 3 decimal places
	 * Amount - 2 decimal places
	 * @param fundDetailsVOList - Fund Detail VO
	 *
	 * @author Kashmira
	 */
	
	private void roundNAVUnitAmount(List<FundDetailsVO> fundDetailsVOList) {
		
		for(FundDetailsVO fundDetailsVO : fundDetailsVOList){
			fundDetailsVO.setUnits(ConvertToXDecimalPoint(fundDetailsVO.getUnits(),3));
			fundDetailsVO.setTotalAmount(ConvertToXDecimalPoint(fundDetailsVO.getTotalAmount(),2));
		}
	}
	
	/**
	 * Check if fund is active,capital guarantee and not return guarantee
	 * 
	 * @param fundCodes - fundCodes separated by comma
	 * @param fundMasterList - Fund Master List
	 * @return List of from Fund Names
	 *
	 * @author Kashmira
	 */
	
	public static String ConvertToXDecimalPoint(String value, int decimals)
	{
		String convertValue = "0.00";
		BigDecimal bigDecimal = null;
		if(StringUtils.isNotBlank(value))
		{
			bigDecimal = new BigDecimal(value);
			bigDecimal = bigDecimal.setScale(decimals, BigDecimal.ROUND_HALF_UP);
			convertValue = bigDecimal.toString();
		}
		else
		{
			convertValue=value;
		}
		return convertValue;
	}
	
	/**
	 * Check if fund is active and not return guarantee
	 * 
	 * @param fundCodes - fundCodes separated by comma
	 * @param fundMasterList - Fund Master List
	 * @return List of from Fund Names
	 *
	 * @author Kashmira
	 */
	
	public List<String> checkNonReturnGuarantee(List<String> fundCodeList, List<FundMasterVO> fundMasterList)
	{
		List<String> activeFromFundList = new ArrayList<String>();
		
		for(FundMasterVO fundMaster : fundMasterList){
			
			//if(fundCodes.contains(fundMaster.getFundCode()))
			for(String fundCode : fundCodeList)
			{
				if(StringUtils.equalsIgnoreCase(fundMaster.getFundCode(), fundCode)){
					if(StringUtils.equalsIgnoreCase(fundMaster.getIsActive(), "Y") && StringUtils.equalsIgnoreCase(fundMaster.getIsReturnGuarantee(), "N"))
					{
						
						activeFromFundList.add(fundMaster.getFundName());
						break;
					}
				}
			}
			
		}
		
		return activeFromFundList;
	}
	
	
	
	@SuppressWarnings("unchecked")
	private Date getSwitchDate(RequestContext context, List<NSEHolidaysVO> list) {

		Date eSwitchExcutionDate = null;
		
		eSwitchExcutionDate = getExecutionDate("15:00:00", list);
		return eSwitchExcutionDate;
	}
	
	public java.sql.Date getExecutionDate(String cutOffTime,List<NSEHolidaysVO> list) {
		java.sql.Date executionDate = null;
		java.util.Date executionDateCalc = new java.util.Date(System.currentTimeMillis());
		try {
			executionDateCalc = getNewExecutionDate(executionDateCalc,cutOffTime,list);
			executionDate = new java.sql.Date(executionDateCalc.getTime());
		}
		catch (ParseException e) {
			
			FLogger.error("SwitchLogger", "IneoBAseHandler", "getExecutionDate", e.getMessage()+":::::::::executionDateCalc::::::"+executionDateCalc+"::::::::executionDate:::::"+executionDate, e);
		}
		return executionDate;
	}
	
	private java.util.Date getNewExecutionDate(java.util.Date executionDate,String cutoffTime,List<NSEHolidaysVO> nseHolidays) throws ParseException
	{
		//java.util.Date executionDate = new java.util.Date(System.currentTimeMillis());//KK
		Calendar executionCal = null;
		//Execution Date to be changed based on cutofftime
		executionCal = getDateBasedOnCutOffTime(executionDate, cutoffTime);
		//Execution Date to be checked if the day is Weekend
		executionCal = getDateAfterRunningWeekendLogic(executionCal);
		//Execution Date to be checked if the day is Long Weekend
		executionCal = getNSEAndWeekendLogic(executionCal, nseHolidays);
		return executionCal.getTime();
	}
	
	
	private Calendar getDateBasedOnCutOffTime(java.util.Date executionDate, String cutOffTime){//cutOffTime  = 15:00:00//KK
		Calendar executionCal = null;
		Calendar cuttOffTimeCal = null;
		List<String> executionDateParams = null;
		
		if (StringUtils.isNotBlank(cutOffTime) && executionDate!=null){
			executionCal = Calendar.getInstance();
			executionCal.setLenient(false);
			executionCal.setTime(executionDate);
			executionDateParams= Arrays.asList(cutOffTime.split(":"));
			if (CollectionUtils.isNotEmpty(executionDateParams)) {
				cuttOffTimeCal = Calendar.getInstance();
				cuttOffTimeCal.setLenient(false);
				cuttOffTimeCal.setTime(executionDate);
				cuttOffTimeCal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(executionDateParams.get(0)));
				cuttOffTimeCal.set(Calendar.MINUTE, Integer.parseInt(executionDateParams.get(1)));
				cuttOffTimeCal.set(Calendar.SECOND, Integer.parseInt(executionDateParams.get(2)));
			}
			if(executionCal.getTimeInMillis()>=cuttOffTimeCal.getTimeInMillis()){
				executionCal.add(Calendar.DAY_OF_MONTH, 1);
			}
			executionCal.set(Calendar.HOUR_OF_DAY, 0);
			executionCal.set(Calendar.MINUTE, 0);
			executionCal.set(Calendar.SECOND, 0);
			executionCal.set(Calendar.MILLISECOND, 0);
		}
		return executionCal;

	}
	
	private Calendar getDateAfterRunningWeekendLogic(Calendar executionCal){
		if(executionCal!=null){
			if(executionCal.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY){
				//Set Date +2
				executionCal.add(Calendar.DAY_OF_MONTH, 2);
			}
			if(executionCal.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY){
				//Set Date +1
				executionCal.add(Calendar.DAY_OF_MONTH, 1);
			}
		}
		return executionCal;
	}
	

	private Calendar getNSEAndWeekendLogic(Calendar executionCal, List<NSEHolidaysVO> nseHolidayList){
		Calendar holidayCalendar = Calendar.getInstance();
		holidayCalendar.setLenient(false);
		Date holidayDate = null;
		if(CollectionUtils.isNotEmpty(nseHolidayList)){
			for (NSEHolidaysVO nseHolidaysVO : nseHolidayList) {
				if(nseHolidaysVO!=null){
					holidayDate = new Date(nseHolidaysVO.getHolidayDate().getTime());
					holidayCalendar.setTime(holidayDate);
					if(executionCal.get(Calendar.DAY_OF_YEAR) == holidayCalendar.get(Calendar.DAY_OF_YEAR)){
						executionCal.add(Calendar.DAY_OF_MONTH, 1);
					}
					holidayDate=null;
					executionCal = getDateAfterRunningWeekendLogic(executionCal);
				}

			}
		}
		return executionCal;
	}
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,RequestContext ObjContext) {
		
	}

}