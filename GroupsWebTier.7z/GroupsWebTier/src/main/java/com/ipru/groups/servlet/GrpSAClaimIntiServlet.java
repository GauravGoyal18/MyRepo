package com.ipru.groups.servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;

import com.ipru.groups.pdfgen.TemplateCoreServiceImpl;
import com.ipru.groups.utilities.GroupCommonUtils;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.vo.SAClaimIntiBenfVO;
import com.ipru.groups.vo.SAClaimIntiSpouseVO;
import com.ipru.groups.vo.SAClaimIntimationVO;
import com.tcs.logger.FLogger;
import com.tcs.pdfgenerator.core.service.ITemplateCoreService;
import com.tcs.pdfgenerator.service.FTL2PDFGenerator;
import com.tcs.pdfgenerator.util.PDFGeneratorUtils;

public class GrpSAClaimIntiServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		FLogger.info("SAClaimIntimationLogger", "GrpSAClaimIntiServlet", "doPost", "method to Download pdf starts");
		
		HttpSession session = request.getSession();
	  
		try {

			if (session == null) {
				FLogger.info("SAClaimIntimationLogger", "GrpSAClaimIntiServlet", "doPost", "session is null");
				throw new ServletException("session is null");
			}

			String grpSAClaimIntiFtlName = "GrpSAClaimIntiServlet.ftl";
			ITemplateCoreService service = new TemplateCoreServiceImpl();
			String destination = GroupCommonUtils.createDirWithTodaysDate(GroupConstants.CONSTANT_DOCUMENT_UPLOAD_PATH);

			if (destination == null) {
				FLogger.info("SAClaimIntimationLogger", "GrpSAClaimIntiServlet", "doPost", "destination is null");
				throw new ServletException("Null data found");
			}

			SAClaimIntimationVO sAClaimIntimationVO = (SAClaimIntimationVO) session.getAttribute("saClaimIntimationVO");
			
			if(StringUtils.isEmpty(sAClaimIntimationVO.getPolicyNo())) {
				sAClaimIntimationVO.setPolicyNo("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getTrustName())){
				sAClaimIntimationVO.setTrustName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getEmpId())){
				sAClaimIntimationVO.setEmpId("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getEmpName())){
				sAClaimIntimationVO.setEmpName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getPanNumber())){
				sAClaimIntimationVO.setPanNumber("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getTypeOfClaim())){
				sAClaimIntimationVO.setTypeOfClaim("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getDateType())){
				sAClaimIntimationVO.setDateType("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getRulesOfSchemeValue())){
				sAClaimIntimationVO.setRulesOfSchemeValue("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getRulesOfSchemeId()))
			{
				sAClaimIntimationVO.setRulesOfSchemeId("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getPayeeName())){
				sAClaimIntimationVO.setPayeeName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getPurchaseOption())){
				sAClaimIntimationVO.setPurchaseOption("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getNameOfFundComp())){
				sAClaimIntimationVO.setNameOfFundComp("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getFreqOfPayment())){
				sAClaimIntimationVO.setFreqOfPayment("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getAnnuityOptionValue())){
				sAClaimIntimationVO.setAnnuityOptionValue("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getCompBuildName())){
				sAClaimIntimationVO.setCompBuildName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getFlatUnitNo())){
				sAClaimIntimationVO.setFlatUnitNo("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getStreetArea())){
				sAClaimIntimationVO.setStreetArea("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getState())){
				sAClaimIntimationVO.setState("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getCity())){
				sAClaimIntimationVO.setCity("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getPincode())){
				sAClaimIntimationVO.setPincode("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getMobileNumber()))
			{
				sAClaimIntimationVO.setMobileNumber("-");
			}
			
			if(StringUtils.isEmpty(sAClaimIntimationVO.getEmailId())){
				sAClaimIntimationVO.setEmailId("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getBankName())){
				sAClaimIntimationVO.setBankName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getBranch())){
				sAClaimIntimationVO.setBranch("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getAccountNumber())){
				sAClaimIntimationVO.setAccountNumber("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getBankContactNumber())){
				sAClaimIntimationVO.setBankContactNumber("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getModeOfPayment())){
				sAClaimIntimationVO.setModeOfPayment("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getMicr())){
				sAClaimIntimationVO.setMicr("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getIfsc())){
				sAClaimIntimationVO.setIfsc("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getCreatedBy())){
				sAClaimIntimationVO.setCreatedBy("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getAnnuityOptionId()))
			{
				sAClaimIntimationVO.setAnnuityOptionId("-");
			}
			if(StringUtils.isEmpty(sAClaimIntimationVO.getAnnuityOptionValue()))
			{
				sAClaimIntimationVO.setAnnuityOptionValue("-");
			}
			
			//checks for beneficiary data
			SAClaimIntiBenfVO sAClaimIntiBenfVO=null;
			sAClaimIntiBenfVO=new SAClaimIntiBenfVO();
			sAClaimIntiBenfVO=sAClaimIntimationVO.getBeneficiary();
			
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getSalutation()))
			{
				sAClaimIntiBenfVO.setSalutation("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getFirstName()))
			{
				sAClaimIntiBenfVO.setFirstName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getLastName()))
			{
				sAClaimIntiBenfVO.setLastName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getBankName()))
			{
				sAClaimIntiBenfVO.setBankName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getBranch()))
			{
				sAClaimIntiBenfVO.setBranch("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getAccountNumber()))
			{
				sAClaimIntiBenfVO.setAccountNumber("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getDateOfBirth()))
			{
				sAClaimIntiBenfVO.setDateOfBirth("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getGender()))
			{
				sAClaimIntiBenfVO.setGender("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getAgeProof()))
			{
				sAClaimIntiBenfVO.setAgeProof("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getRelationShipWithMember()))
			{
				sAClaimIntiBenfVO.setRelationShipWithMember("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getCategory()))
			{
				sAClaimIntiBenfVO.setCategory("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getCompBuildName()))
			{
				sAClaimIntiBenfVO.setCompBuildName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getStreetArea()))
			{
				sAClaimIntiBenfVO.setStreetArea("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getPincode()))
			{
				sAClaimIntiBenfVO.setPincode("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getCity()))
			{
				sAClaimIntiBenfVO.setCity("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getState()))
			{
				sAClaimIntiBenfVO.setState("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getMobileNumber()))
			{
				sAClaimIntiBenfVO.setMobileNumber("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getEmailId()))
			{
				sAClaimIntiBenfVO.setEmailId("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getAppointeeFName()))
			{
				sAClaimIntiBenfVO.setAppointeeFName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getAppointeeLName()))
			{
				sAClaimIntiBenfVO.setAppointeeLName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getAppointeeRelation()))
			{
				sAClaimIntiBenfVO.setAppointeeRelation("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getAnnuFirstName()))
			{
				sAClaimIntiBenfVO.setAnnuFirstName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getAnnuLastName()))
			{
				sAClaimIntiBenfVO.setAnnuLastName("-");
			}
			
			if(StringUtils.isEmpty(sAClaimIntiBenfVO.getAnnuDOB()))
			{
				sAClaimIntiBenfVO.setAnnuDOB("-");
			}
			
			//Spouse check
			SAClaimIntiSpouseVO sAClaimIntiSpouseVO = null;
			sAClaimIntiSpouseVO =  sAClaimIntimationVO.getSpouse();
			if(sAClaimIntiSpouseVO==null)
			{
				sAClaimIntiSpouseVO= new SAClaimIntiSpouseVO();
			}
			if(StringUtils.isEmpty(sAClaimIntiSpouseVO.getSalutation()))
			{
				sAClaimIntiSpouseVO.setSalutation("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiSpouseVO.getFirstName()))
			{
				sAClaimIntiSpouseVO.setFirstName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiSpouseVO.getLastName()))
			{
				sAClaimIntiSpouseVO.setLastName("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiSpouseVO.getDateOfBirth()))
			{
				sAClaimIntiSpouseVO.setDateOfBirth("-");
			}
			if(StringUtils.isEmpty(sAClaimIntiSpouseVO.getAgeProof()))
			{
				sAClaimIntiSpouseVO.setAgeProof("-");
			}
			byte[] bufferData = FTL2PDFGenerator.getPDFGeneratorInstance.generatePDFTemplate(PDFGeneratorUtils.createTemplateBean(grpSAClaimIntiFtlName, sAClaimIntimationVO), service);
			
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			ServletOutputStream objServletOutputStream = null;
			
			output.write(bufferData);
			response.addHeader("Content-Disposition", "attachment; filename=\"" + "GrpSAClaimIntiServlet.pdf" + "\"");
			response.setContentType("application/pdf");
			output.flush();
			response.setContentLength(output.size());
			objServletOutputStream = response.getOutputStream();
			output.writeTo(objServletOutputStream);
			objServletOutputStream.flush();

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			session.removeAttribute("saClaimIntimationVO");

		}
		FLogger.info("SAClaimIntimationLogger", "GrpSAClaimIntiServlet", "doPost", "method to Download pdf end");
	}

}
