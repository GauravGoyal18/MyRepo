package com.ipru.groups.handler;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.groups.po.YYEmployeeFormPO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.security.annotations.MethodPost;

public class YYEmployeeHandler  extends IneoBaseHandler{
	
	private static final long serialVersionUID = 1L;
	
	public Event onEntry(RequestContext p_ObjContext) throws Exception {
		////System.out.println("In handler: onEntry : called on entry");
		return success();
	}


	@MethodPost
	public Event getBizRequestforSubmitEmployee(RequestContext p_ObjContext) throws Exception {
		try{
			////System.out.println("In handler: getBizRequestforSubmitEmployee : called when form is submitted");
			
			HttpServletRequest request = (HttpServletRequest)p_ObjContext.getExternalContext().getNativeRequest();
			//System.out.println(ToStringBuilder.reflectionToString(request));
			 
			Gson gson = new Gson();
			YYEmployeeFormPO yyEmployeeFormPO = gson.fromJson(request.getReader(), YYEmployeeFormPO.class);
	
			//yyEmployeeFormPO = null;
			
			String employeeId = (String) yyEmployeeFormPO.getEmployeeId();
			String employeeName = (String) yyEmployeeFormPO.getEmployeeName();
			String employeeGender = (String) yyEmployeeFormPO.getEmployeeGender();
			String employeeProfession = (String) yyEmployeeFormPO.getEmployeeProfession();
			String employeeSalary = (String) yyEmployeeFormPO.getEmployeeSalary();
			String employeeDOBString = (String) yyEmployeeFormPO.getEmployeeDOBString();
			String employeeMedicallyFit = (String) yyEmployeeFormPO.getMedical();
			String employeeCity = (String) yyEmployeeFormPO.getAddress().getCity();
			String employeeState = (String) yyEmployeeFormPO.getAddress().getState();
			String employeePincode = (String) yyEmployeeFormPO.getAddress().getPincode();
			Map<String, Object> map = yyEmployeeFormPO.getColoursMap();
			
	
			if(map != null){
				for (Map.Entry<String, Object> entry : map.entrySet())
				{
					//System.out.println(entry.getKey() + ":" + entry.getValue());
				}
			}
			
			
			////System.out.println("employeeId:"+employeeId);
			////System.out.println("employeeName:"+employeeName);
			////System.out.println("employeeGender:"+employeeGender);
			////System.out.println("employeeProfession:"+employeeProfession);
			////System.out.println("employeeSalary:"+employeeSalary);
			////System.out.println("employeeMedicallyFit:"+employeeMedicallyFit);
			////System.out.println("employeeDOB:"+employeeDOBString);
			////System.out.println("employeeCity:"+employeeCity);
			////System.out.println("employeeState:"+employeeState);
			////System.out.println("employeePincode:"+employeePincode);
				
			Object[] paramArray = new Object[1];
			paramArray[0] = yyEmployeeFormPO;
	
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
	
			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq); 
			
			return success();
		}
		catch(Exception e){
			throwINeoFlowException(e,"GRYY01",p_ObjContext);
		}
		return null;
	}
	
	@ MethodPost
	public Event getBizResponseforSubmitEmployee(RequestContext context) throws Exception{
		
		////System.out.println("In handler: getBizResponseforSubmitEmployee : Response method");
		try{
			BizResponse response = new BizResponse();
			
			response = (BizResponse) context.getFlowScope().get("bizResForSubmitEmployee");
			
			YYEmployeeFormPO yyEmployeeFormPO = new YYEmployeeFormPO();
			yyEmployeeFormPO = (YYEmployeeFormPO) response.getTransferObjects().get("response1");
			
			if(yyEmployeeFormPO != null)
			{
				////System.out.println("Success!!!");
				String employeeId = (String) yyEmployeeFormPO.getEmployeeId();
				String employeeName = (String) yyEmployeeFormPO.getEmployeeName();
				String employeeGender = (String) yyEmployeeFormPO.getEmployeeGender();
				String employeeProfession = (String) yyEmployeeFormPO.getEmployeeProfession();
				String employeeSalary = (String) yyEmployeeFormPO.getEmployeeSalary();
				String employeeMedicallyFit = (String) yyEmployeeFormPO.getMedical();
				
				String employeeDOB = (String) yyEmployeeFormPO.getEmployeeDOBString();
				String employeeCity = (String) yyEmployeeFormPO.getAddress().getCity();
				String employeeState = (String) yyEmployeeFormPO.getAddress().getState();
				String employeePincode = (String) yyEmployeeFormPO.getAddress().getPincode();
				
				////System.out.println("employeeId:"+employeeId);
				////System.out.println("employeeName:"+employeeName);
				////System.out.println("employeeGender:"+employeeGender);
				////System.out.println("employeeProfession:"+employeeProfession);
				////System.out.println("employeeSalary:"+employeeSalary);
				////System.out.println("employeeMedicallyFit:"+employeeMedicallyFit);
				////System.out.println("employeeDOB:"+employeeDOB);
				////System.out.println("employeeCity:"+employeeCity);
				////System.out.println("employeeState:"+employeeState);
				////System.out.println("employeePincode:"+employeePincode);
				
				yyEmployeeFormPO.setSuccessFailure("Success");
				
				context.getFlowScope().put("Response", gsonJSON.toJson(yyEmployeeFormPO));
			}
			else
			{	
				yyEmployeeFormPO = new YYEmployeeFormPO();
				////System.out.println("Failure!!!");
				yyEmployeeFormPO.setSuccessFailure("Failure");
				context.getFlowScope().put("Response", gsonJSON.toJson(yyEmployeeFormPO));
			}
			return success();
		}
		catch (Exception e) {
			throwINeoFlowException(e,"GRYY02",context);
		}
		return null;
	
	}
	
	
/*	@MethodPost
	public Event getBizResponseforHideShowEmployeeDetails(RequestContext p_ObjContext) {
		
		YYEmployeeFormPO yyEmployeeFormPO = new YYEmployeeFormPO();
		YYAddress yyAddress = new YYAddress();
		
		yyEmployeeFormPO.setEmployeeIdVisibility(true);
		yyEmployeeFormPO.setEmployeeNameVisibility(false);
		yyEmployeeFormPO.setEmployeeSalaryVisibility(true);
		yyEmployeeFormPO.setAddress(yyAddress);
		
		yyEmployeeFormPO.getAddress().setEmployeeCityVisibility(false);
		yyEmployeeFormPO.getAddress().setEmployeePincodeVisibility(true);
		yyEmployeeFormPO.setSuccessFailure("Success");
		p_ObjContext.getFlowScope().put("Response", gsonJSON.toJson(yyEmployeeFormPO));
		
		return success();
	}*/

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		
	}
	

}