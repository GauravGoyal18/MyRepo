package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.ipru.groups.po.AnnuityCalculatorPO;

import com.ipru.groups.utilities.CommonValidationUtil;
import com.tcs.logger.FLogger;

public class AnnuityCalculatorValidator {

	public String annuityValidate(AnnuityCalculatorPO annuityCalculatorPo)
	{
		
		
		FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorValidator", "annuityValidate", "method start");

		StringBuilder errorMessage=new StringBuilder();
		List<String> annuityOption=new ArrayList<String>();
		List<String> calculatorMode=new ArrayList<String>();
		List<String> channelType=new ArrayList<String>();
		channelType.add("Tied");
		annuityOption.add("JLLS");
		annuityOption.add("JLLSROP");
		annuityOption.add("LA");
		annuityOption.add("LAROP");
		annuityOption.add("PC");
		annuityOption.add("all");
		/* Added by Anurag */
		annuityOption.add("JLLSROPPART");
		annuityOption.add("LA5");
		annuityOption.add("LAROP50");
		annuityOption.add("LAROP75");
		annuityOption.add("LAROPBAL");
		annuityOption.add("LAROPCIPD");
		/* Added by Anurag */
		calculatorMode.add("A");
		
		
		if(!validateAge(annuityCalculatorPo.getAnnuitantAge()))
		{
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorValidator", "annuityValidate", "Age validation fails");

			errorMessage.append("Please Enter Valid Age");
		}
		
		if(annuityCalculatorPo.getSpouseAge()!=0)
		{
		if(!validateAge1(annuityCalculatorPo.getSpouseAge()))
		{
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorValidator", "annuityValidate", "Age validation fails of spouse");

			errorMessage.append("Please Enter Valid Spouse Age");
		}
		}
		if(!validateDropDown(annuityCalculatorPo.getIncomeOption(),annuityOption))
		{
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorValidator", "annuityValidate", "annuityOption validation fails");

			errorMessage.append("Please Enter Valid Annuity Option");
		}
		
		if(!validateDropDown(annuityCalculatorPo.getCalculatorMode(),calculatorMode))
		{		
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorValidator", "annuityValidate", "calculatorMode validation fails");

			errorMessage.append("Please Enter Valid Calculator Mode");
		}
		
		
		if(!validateDropDown(annuityCalculatorPo.getChannelType(),channelType))
		{
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorValidator", "annuityValidate", "channelType validation fails");

			errorMessage.append("Please Enter Valid Channel Mode");
		}

		if(!validatePrice(annuityCalculatorPo.getInputAmt()))
		{
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorValidator", "annuityValidate", "getInputAmt validation fails");

			errorMessage.append("Please Enter Valid Price");
		}
		
		if(!ageDifference(annuityCalculatorPo.getAnnuitantAge(), annuityCalculatorPo.getSpouseAge(), annuityCalculatorPo.getAnnuitantGender(),annuityCalculatorPo.getAgeDiff()))
		{
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorValidator", "annuityValidate", "ageDifference validation fails");

			errorMessage.append("Age difference is not valid");
		}
		FLogger.info("AnnuityCalculatorLogger", "AnnuityCalculatorValidator", "annuityValidate", "method end");

		return errorMessage.toString();
	}
	
	public boolean validateAge(int age)
	{
		boolean flag=false;
		if(CommonValidationUtil.ValidateNumeric(String.valueOf(age), true) && age>=20)
		{
			flag=true;
		}
		return flag;
		
	}
	
	public boolean validateAge1(int age)
	{
		boolean flag=false;
		if(CommonValidationUtil.ValidateNumeric(String.valueOf(age), true))
		{
			flag=true;
		}
		return flag;
		
	}
	
	public boolean validateDob(String dob)
	{
		
		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
		try {
			Date date1 = format1.parse(dob);
			return true;
		} catch (ParseException e) {
			FLogger.error("AnnuityCalculatorLogger", "AnnuityCalculatorValidator", "validateDob", "ParseException occured",e);

			return false;
		}
		
	}
	
	public boolean validateName(String name)
	{
		boolean flag=false;
		if(CommonValidationUtil.ValidateAlpha(name, true))
		{
			flag=true;
		}
		return flag;
	}
	
	public boolean validateDropDown(String element,List<String> dropDownList)
	{
		boolean flag=false;
		if(dropDownList.contains(element))
		{
			flag=true;
		}
		return flag;
	}
	public boolean validatePrice(double d)
	{
		boolean flag=false;
		if(CommonValidationUtil.ValidateNumeric(String.valueOf(d), true))
		{
			flag=true;
		}
		return flag;
	}
	
	public boolean ageDifference(int annAge, int spAge, String gender,int ageDiffFromUser){
        int ageDiff = 0;
      
        if(annAge!=0)
        {
        	if(spAge!=0)
        	{
        	if(gender.equalsIgnoreCase("M")){
                    ageDiff = annAge - spAge;
                } else if(gender.equalsIgnoreCase("F")){
                    ageDiff = spAge - annAge;
                }
        	}
        	else
        	{
        		ageDiff=annAge;
        	}
        }
        else
        {
        	return false;
        }
        
        if(ageDiff==ageDiffFromUser)
        	return true;
        else
        	return false;
    }  
}


