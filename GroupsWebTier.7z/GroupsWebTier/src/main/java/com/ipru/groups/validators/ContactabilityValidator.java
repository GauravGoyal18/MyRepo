package com.ipru.groups.validators;

public class ContactabilityValidator {

}
