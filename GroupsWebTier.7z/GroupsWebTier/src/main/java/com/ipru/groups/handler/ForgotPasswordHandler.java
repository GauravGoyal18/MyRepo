package com.ipru.groups.handler;

import javacryption.aes.AesCtr;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.ForgotPasswordRequestPO;
import com.ipru.groups.utilities.EncryptionUtil;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.SessionKeyConstants;
import com.ipru.groups.validators.ForgotPasswordValidator;
import com.ipru.groups.vo.ForgotPasswordRequestVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.GroupsUserAuthInfoNew;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ForgotPasswordHandler extends IneoBaseHandler {

	private static final String INFO_LOGGER_NAME = "ForgotPasswordLogger";
	private static final String CLASS_NAME = "ForgotPasswordHandler";



	@MethodPost
	public Event getBizRequestForEmailMobileSubmit(RequestContext context) throws Exception {
		String METHOD_NAME = "getBizRequestForEmailMobileSubmit";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
					if (request != null) {
						ForgotPasswordRequestPO forgotPasswordRequestPO = gsonJSON.fromJson(request.getReader(), ForgotPasswordRequestPO.class);

						if (forgotPasswordRequestPO != null) {

							ForgotPasswordValidator validator = new ForgotPasswordValidator();

							String validation = validator.validateEmailMobile(forgotPasswordRequestPO);

							if (StringUtils.isNotBlank(validation)) {
								FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Validation errors : " + validation);
								this.setValidationErrorMessages(validation);
								throw new IPruException("Error", "GRPFP01", validation);
							}

							GroupSecurityUtil.setAttributeInSession(context, "forgotPasswordRequestPO", forgotPasswordRequestPO);

							ForgotPasswordRequestVO forgotPasswordRequestVO = dozerBeanMapper.map(forgotPasswordRequestPO, ForgotPasswordRequestVO.class);

							Object[] paramArray = new Object[1];
							paramArray[0] = forgotPasswordRequestVO;

							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("bizReqForEmailMobileSubmit", obj_bizReq);
						}
						else {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "forgotPasswordRequestPO from request should not be null");
							throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "request should not be null");
						throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Session should not be null");
					throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPFP01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	@MethodPost
	public Event getBizResponseForEmailMobileSubmit(RequestContext context) throws Exception {
		String METHOD_NAME = "getBizResponseForEmailMobileSubmit";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
					if (userVo != null) {
						bizRes = (BizResponse) context.getFlowScope().get("bizResForEmailMobileSubmit");

						if (bizRes != null) {
							responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
							}
							else {
								String outputString = (String) bizRes.getTransferObjects().get("response1");

								if (StringUtils.isBlank(outputString)) {
									FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "outputString is blank.");
									throw new IPruException("Error", "GRPCU01", "Something went wrong. Please try again later.");
								}
								else if (StringUtils.equals(outputString, "NOT_MATCHED")) {
									FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, outputString);
									throw new IPruException("Error", "GRPCU01", "Entered email id and mobile no is not registered with us.");
								}
								else {
									GroupsUserAuthInfoNew groupsUserAuthInfoNew = gsonJSON.fromJson(outputString, GroupsUserAuthInfoNew.class);
									if (groupsUserAuthInfoNew != null) {
										userVo.setPolicyNo(groupsUserAuthInfoNew.getWebClientId());
										userVo.setClientId(groupsUserAuthInfoNew.getWebClientId());
										userVo.setUsername(groupsUserAuthInfoNew.getFirstName());
										userVo.setClientName(groupsUserAuthInfoNew.getFirstName());
										userVo.setEmailId(groupsUserAuthInfoNew.getEmailId());
										userVo.setMobileNo(String.valueOf(groupsUserAuthInfoNew.getMobileNo()));

										GroupSecurityUtil.setAttributeInSession(context, "userVO", userVo);

										GroupSecurityUtil.setAttributeInSession(context, "groupsUserAuthInfoNew", groupsUserAuthInfoNew);

										context.getFlowScope().put("Response", "Success");
									}
									else {
										FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "groupsUserAuthInfoNew from service should not be null");
										throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
									}
								}
							}
						}
						else {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
							throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVO from session should not be null");
						throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "session should not be null");
					throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPFP01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	@MethodPost
	public Event getBizRequestForForgotPasswordSubmit(RequestContext context) throws Exception {
		String METHOD_NAME = "getBizRequestForForgotPasswordSubmit";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		boolean isOTPValidated = false;

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {

					isOTPValidated = (Boolean) GroupSecurityUtil.getAttributeFromSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);

					if (!isOTPValidated) {
						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "OTP is not validated.");
						throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
					}
					else {
						GroupSecurityUtil.removeAttributeInSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);
					}

					HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
					if (request != null) {
						ForgotPasswordRequestPO forgotPasswordRequestPO = gsonJSON.fromJson(request.getReader(), ForgotPasswordRequestPO.class);

						if (forgotPasswordRequestPO != null) {

							ForgotPasswordValidator validator = new ForgotPasswordValidator();

							String encProperty1 = forgotPasswordRequestPO.getNewPassword();

							if (encProperty1 != null) {
								String key = (String) httpSession.getAttribute("jCryptionKey");
								encProperty1 = encProperty1.replaceAll(" ", "+");
								String decProperty = AesCtr.decrypt(encProperty1, key, 256);
								forgotPasswordRequestPO.setNewPassword(EncryptionUtil.encryptSHA256(decProperty, "UTF-8"));
							}

							String encProperty2 = forgotPasswordRequestPO.getConfirmPassword();

							if (encProperty2 != null) {
								String key = (String) httpSession.getAttribute("jCryptionKey");
								encProperty2 = encProperty1.replaceAll(" ", "+");
								String decProperty = AesCtr.decrypt(encProperty2, key, 256);
								forgotPasswordRequestPO.setConfirmPassword(EncryptionUtil.encryptSHA256(decProperty, "UTF-8"));
							}

							String validation = validator.validateForgotPassword(forgotPasswordRequestPO, context);

							if (StringUtils.isNotBlank(validation)) {
								FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Validation errors : " + validation);
								this.setValidationErrorMessages(validation);
								throw new IPruException("Error", "GRPFP01", validation);
							}

							GroupsUserAuthInfoNew groupsUserAuthInfoNew = (GroupsUserAuthInfoNew) GroupSecurityUtil.getAttributeFromSession(context, "groupsUserAuthInfoNew");

							String encProperty = forgotPasswordRequestPO.getNewPassword();

							groupsUserAuthInfoNew.setProperty(encProperty);
							groupsUserAuthInfoNew.setMobileNo(forgotPasswordRequestPO.getMobileNo());

							Object[] paramArray = new Object[1];
							paramArray[0] = groupsUserAuthInfoNew;

							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("bizReqForForgotPasswordSubmit", obj_bizReq);
						}
						else {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "forgotPasswordRequestPO from request should not be null");
							throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Request should not be null");
						throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Session should not be null");
					throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Context should not be null");
				throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPFP01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	@MethodPost
	public Event getBizResponseForForgotPasswordSubmit(RequestContext context) throws Exception {
		String METHOD_NAME = "getBizResponseForForgotPasswordSubmit";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForForgotPasswordSubmit");

				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
					}
					else {
						String outputString = (String) bizRes.getTransferObjects().get("response1");

						if (StringUtils.isBlank(outputString)) {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "outputString is blank.");
							throw new IPruException("Error", "GRPCU01", "Something went wrong. Please try again later.");
						}
						else if (StringUtils.equals(outputString, "SUCCESS")) {

							GroupSecurityUtil.removeAttributeInSession(context, "userVO");
							GroupSecurityUtil.removeAttributeInSession(context, "groupsUserAuthInfoNew");
							context.getFlowScope().put("Response", "Success");
						}
						else {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, outputString);
							throw new IPruException("Error", "GRPCU01", "Something went wrong. Please try again later.");
						}
					}
				}
				else {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
					throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Context should not be null");
				throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPFP01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		String METHOD_NAME = "setOtpCallBacks";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		paramBean.setFunctionality("FORGOT_PWD");
		setTransactionalOTPCallback(Boolean.TRUE);
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
	}

}
