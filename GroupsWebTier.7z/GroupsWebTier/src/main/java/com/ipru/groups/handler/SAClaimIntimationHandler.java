package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;
import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.DropDownObjPO;
import com.ipru.groups.po.SAClaimIntimationPO;
import com.ipru.groups.po.SAClaimIntimationSubmitPO;
import com.ipru.groups.validators.SAClaimIntimationValidator;
import com.ipru.groups.vo.DropDownObjVO;
import com.ipru.groups.vo.SAClaimIntimationVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class SAClaimIntimationHandler extends IneoBaseHandler {

	private static final long serialVersionUID = 1L;
	
	private static final String INFO_LOGGER_NAME = "SAClaimIntimationLogger";
	private static final String CLASS_NAME = "SAClaimIntimationHandler";
	
	
	public static final String ErrorMsg = "Something Went Wrong Please Try Again!";

	/*
	 * Check for details in database on load
	 * if data exist that return the user with form pdf
	 * if user not found than show first time on load details
	 */
	
	@MethodPost
	public Event getReqClaimIntiDetails(RequestContext context) throws Exception {
		final String METHOD_NAME = "getReqClaimIntiDetails";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start");
		

		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				
				
				if (httpSession != null) 
				{
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
					if (userVo != null)
					{

						HttpServletRequest request = (HttpServletRequest) context
								.getExternalContext().getNativeRequest();

						if (request != null)
						{ 
							SAClaimIntimationVO sAClaimIntiVo = new SAClaimIntimationVO();
							sAClaimIntiVo.setPolicyNo(userVo.getPolicyNo()); 
							sAClaimIntiVo.setEmpId(userVo.getEmpId()); 
							 
							
							Object[] paramArray = new Object[1];
							paramArray[0] = sAClaimIntiVo;
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1",paramArray);
							context.getFlowScope().put("sAClaimDetails", obj_bizReq);

						} else {

							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,
									METHOD_NAME, "request should not be null");
							throw new IPruException("Error", "GRPSCI01",
									"request should not be null");
						}
					} else {
						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,
								METHOD_NAME, "userVo should not be null");
						throw new IPruException("Error", "GRPSCI01",
								"userVo should not be null");
					}
				} else {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME,
							"httpSession should not be null");
					throw new IPruException("Error", "GRPSCI01",
							"httpSession should not be null");
				}
			} else {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME,
						"Context should not be null");
				throw new IPruException("Error", "GRPSCI01",
						"Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End ");
		return success();
	}
	
	@MethodPost
	public Event getResClaimIntiDetails(RequestContext context) throws Exception
	{	final String METHOD_NAME ="getResClaimIntiDetails";
		BizResponse bizRes = new BizResponse();
		SAClaimIntimationPO sAClaimIntimationPO = new SAClaimIntimationPO();
		Gson  gsonJSON = new Gson();
		boolean firstTime = false;
		StringBuffer strb=new StringBuffer();
		try 
		{
			if (context != null)
			{
				bizRes = (BizResponse) context.getFlowScope().get("bizResSAClaimIntiDetails");
				HttpSession httpSession=((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if(httpSession!=null)
				{
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
					if(userVo!=null)
					{
						if(bizRes!=null)
						{
							SAClaimIntimationVO saClaimIntimationVO = (SAClaimIntimationVO) bizRes.getTransferObjects().get("response1");
							
								if(saClaimIntimationVO==null)
								{
									firstTime= true;
									sAClaimIntimationPO.setEmpId(userVo.getEmpId());
									sAClaimIntimationPO.setTrustName(userVo.getSelectedPolicy().getClientName());
									sAClaimIntimationPO.setPolicyNo(userVo.getPolicyNo());
									sAClaimIntimationPO.setFirstTime(firstTime);
									strb.append(userVo.getFirstName());
									strb.append(" "+userVo.getLastName());
									sAClaimIntimationPO.setEmpName(strb.toString());
								}
								else
								{
									httpSession.setAttribute("saClaimIntimationVO",saClaimIntimationVO);
								}
								context.getFlowScope().put("Response",gsonJSON.toJson(sAClaimIntimationPO));
						}
						else
						{
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,
									"getResClaimIntiDetails", "Biz response should not be null");
							throw new IPruException("Error", "GRPSCI01",
									"Biz response should not be null");
						}
						
					}
					else
					{
						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,
								"getResClaimIntiDetails", "useVo should not be null");
						throw new IPruException("Error", "GRPSCI01",
								"useVo should not be null");
					}
				}
				else
				{
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,
							"getResClaimIntiDetails", "request should not be null");
					throw new IPruException("Error", "GRPSCI01",
							"session should not be null");
				}
				
			}
			
			else 
			{	FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,
					"getResClaimIntiDetails", "Context should not be null");
			throw new IPruException("Error", "GRPSCI01",
					"context should not be null");
			}
		}
		catch(Exception e)
		{
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSCI01", context);
		}
		return success();
		
	}
	
	/*Req method to get State details on form load*/
	
	@MethodPost
	public Event getReqSateList(RequestContext context) throws Exception {
		final String METHOD_NAME="getReqSateList";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		try {
			BizRequest obj_bizReq = new BizRequest();
			context.getFlowScope().put("stateList", obj_bizReq);
		} catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSCI01", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End ");
		return success();
	}

	/*Res method to get State details on form load*/
	
	@MethodPost
	public Event getResStateList(RequestContext context) throws Exception {
		final String METHOD_NAME = "getResStateList";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		String responselist = "";
		String responseCheck = "";
		try {
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResStateList");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				} else {

					Gson gson = new Gson();
					List<DropDownObjVO> response = (List<DropDownObjVO>) bizRes.getTransferObjects().get("response1");
					DropDownObjPO po = null;
					TreeSet<String> data = new TreeSet<String>();
					for (int i = 0; i < response.size(); i++) {
						po = new DropDownObjPO();
						DropDownObjVO vo = (DropDownObjVO) response.get(i);
						dozerBeanMapper.map(vo, po);
						data.add(po.getValue());
					}
					if (CollectionUtils.isNotEmpty(data)) {
						context.getFlowScope().put("OnloadStateDetailsData",data);
						responselist = gson.toJson(data);
						context.getFlowScope().put("Response", responselist);
					} else {

						throw new IPruException("Error", "GRPSCI01", ErrorMsg);
					}

				}
			} else {

				throw new IPruException("Error", "GRPSCI01", ErrorMsg);

			}

		} catch (Exception e) {
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came", e);
			throwINeoFlowException(e, "GRPSCI01", context);

		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End ");
		return success();

	}

	/*Request method to get city details on form load*/
	
	@MethodPost
	public Event getReqCityList(RequestContext context) throws Exception {
		final String METHOD_NAME = "getReqCityList";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start");
		try {
			BizRequest obj_bizReq = new BizRequest();
			context.getFlowScope().put("cityList", obj_bizReq);
		}
		catch (Exception e) {
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start",e);
			throwINeoFlowException(e, "GRPSCI01", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return success();
	}

	/*Response method to get city details on form load*/
	
	@MethodPost
	public Event getResCityList(RequestContext context) throws Exception {
		final String METHOD_NAME = "getResCityList";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start");
		String responselist = "";
		String responseCheck = "";

		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResCityList");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					Gson gson = new Gson();
					List<DropDownObjVO> response = (List<DropDownObjVO>) bizRes.getTransferObjects().get("response1");
					TreeSet cityDetails = new TreeSet();
					DropDownObjPO po = null;
					List<DropDownObjPO> cityDetailsPo = new ArrayList();
					if (response != null) {
						for (int i = 0; i < response.size(); i++) {
							po = new DropDownObjPO();
							DropDownObjVO vo = (DropDownObjVO) response.get(i);
							dozerBeanMapper.map(vo, po);
							cityDetails.add(po.getValue());
							cityDetailsPo.add(po);
						}

						if (CollectionUtils.isNotEmpty(cityDetailsPo)) {
							context.getFlowScope().put("OnloadCityDetails", cityDetails);

							responselist = gson.toJson(cityDetailsPo);
							context.getFlowScope().put("Response", responselist);
						}
						else {

							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "cityDetails and map should not be null");
							throw new IPruException("Error", "GRPSCI01", ErrorMsg);
						}
					}
					else {

						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "response should not be null");
						throw new IPruException("Error", "GRPSCI01", ErrorMsg);
					}

				}
			}
			else {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
				throw new IPruException("Error", "GRPSCI01", ErrorMsg);
			}
		}
		catch (Exception e) {
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came", e);
			throwINeoFlowException(e, "GRPSCI01", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End");
		return success();
	}
	
	/*Request  method will take req convert PO to VO and call service for saving data : GRP SA Claim Form */
	@MethodPost
	public Event getReqSubmitSAClaimIntiForm(RequestContext context) throws Exception
	{
		
		final String METHOD_NAME = "getReqSubmitSAClaimIntiForm";
		try
		{
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) 
				{	IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
					HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
					SAClaimIntimationSubmitPO sAClaimIntimationSubmitPO = gsonJSON.fromJson(request.getReader(), SAClaimIntimationSubmitPO.class);
					
					if (sAClaimIntimationSubmitPO == null) {
						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "sAClaimIntiamtionSubmitPO should not be empty");
						throw new IPruException("Error", "GRPSCI01", "sAClaimIntiamtionSubmitPO should not be empty");
					}
					sAClaimIntimationSubmitPO.setCreatedBy(userVo.getClientId());
					SAClaimIntimationValidator sAClaimIntimationValidator = SAClaimIntimationValidator.getSingleton();
					String errorMsg= sAClaimIntimationValidator.validateSAClaimIntiForm(sAClaimIntimationSubmitPO,context);
					if (StringUtils.isNotBlank(errorMsg)) {
						this.setValidationErrorMessages(errorMsg);
						FLogger.error(INFO_LOGGER_NAME,CLASS_NAME , "getReqSubmitSAClaimIntiForm", "Data from request should not be null");
						throw new IPruException("Error", "GRPSCI01", errorMsg);
				}
					
					SAClaimIntimationVO sAClaimIntimationVO  = dozerBeanMapper.map(sAClaimIntimationSubmitPO,SAClaimIntimationVO.class);

					Object[] paramArray = new Object[1];
 					paramArray[0] = sAClaimIntimationVO;
					BizRequest obj_bizReq = new BizRequest();
					obj_bizReq.addbusinessObjects("service-obj1",paramArray);
					context.getFlowScope().put("subReqSAClaimIntiForm", obj_bizReq);
					
				}
			}
			else
			{
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,
						"getResClaimIntiDetails", "Context should not be null");
				throw new IPruException("Error", "GRPSCI01",
						"context should not be null");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSCI01", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End ");
		return success();
		
	}
	
	/*Response method will return VO data saved and PDF will get downloaded : GRP SA Claim Form */
	
	@MethodPost
	public Event getResSubmitSAClaimIntiForm(RequestContext context) throws Exception
	{
		final String METHOD_NAME = "getResSubmitSAClaimIntiForm";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start");
		try{
			BizResponse bizRes = new BizResponse();
			HttpSession httpSession=((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			bizRes = (BizResponse) context.getFlowScope().get("bizResSAClaimIntiForm");
			if(bizRes!=null)
			{
				SAClaimIntimationVO saClaimIntimationVO = (SAClaimIntimationVO) bizRes.getTransferObjects().get("response1");
				httpSession.setAttribute("saClaimIntimationVO", saClaimIntimationVO);
			}
			else
			{
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "Context should not be null");
				throw new IPruException("Error", "GRPSCI01",
						"context should not be null");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPSCI01", context);
		}
	
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End ");
		return success();
		
	}
	
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
	}

}
