package com.ipru.groups.excels;

import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ipru.groups.po.TrackerResponsePO;
import com.tcs.logger.FLogger;

public class TrackerExcel {
	public String createExcel(List result) throws Exception{
		FLogger.info("TRACKERLogger", "TrackerExcel", "createExcel", "createExcel Starts");
		if(result!=null){
			String filePath="D://DetailList.xlsx";
			  XSSFWorkbook workbook = new XSSFWorkbook(); 
		      XSSFSheet spreadsheet = workbook
		      .createSheet("employe db");
			XSSFRow row = spreadsheet.createRow(0);
		      XSSFCell cell;
		      cell=row.createCell(1);
		      cell.setCellValue("REQUESTID");
		      cell=row.createCell(2);
		      cell.setCellValue("SPAARC_ID");
		      cell=row.createCell(3);
		      cell.setCellValue("REQUEST DATE");
		      cell=row.createCell(4);
		      cell.setCellValue("STATUS");
		      cell=row.createCell(5);
		      cell.setCellValue("FUNCTIONALITY");
		      
		      
		      int i=1;
			Iterator iterator = result.iterator();
			while (iterator.hasNext()) {								
			    TrackerResponsePO value = (TrackerResponsePO) iterator.next();				    
			    if(value!=null){
			    	row=spreadsheet.createRow(i);
			    	
			    	cell=row.createCell(1);
			    	cell.setCellValue((value.getRequestId()!=null)?value.getRequestId().toString():"");
		         
			    	cell=row.createCell(2);
			    	cell.setCellValue((value.getSpaarcId()!=null)?value.getSpaarcId().toString():"");
		         
			    	cell=row.createCell(3);		         
			    	cell.setCellValue((value.getRequestedDate()!=null)?value.getRequestedDate().toString():"");
		         
			    	cell=row.createCell(4);		         
			    	cell.setCellValue((value.getStatus()!=null)?value.getStatus().toString():"");
		         
			    	cell=row.createCell(5);		         
			    	cell.setCellValue((value.getFunctionality()!=null)?value.getFunctionality().toString():"");
		         i++;
			    }else{
			    	FLogger.error("TRACKERLoggerError", "TrackerExcel", "createExcel", "value cannot be null");
					 throw new ServletException("value cannot be null");
			    }
			}				
							
			FileOutputStream out = new FileOutputStream(filePath);				
          workbook.write(out);
				      out.close();	
				      return filePath;
		}else{
			FLogger.info("TRACKERLogger", "TrackerExcel", "createExcel", "result cannot be null");
			return null;
		}	
		
	}
}
