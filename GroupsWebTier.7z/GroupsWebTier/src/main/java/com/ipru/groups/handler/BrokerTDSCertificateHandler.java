package com.ipru.groups.handler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.BrokerTDSCertificateVO;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BrokerTDSCertificateHandler extends IneoBaseHandler {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String ErrorMsg = "Something went wrong please try again!";

	public static final String CLASSNAME = BrokerTDSCertificateHandler.class.getCanonicalName();
	public static final String LOGGERNAME = "BrokerTDSCertificateLogger";
	private static final String ERRORLOGGERNAME = "BrokerPaidCommissionLogger";

	@MethodPost
	public Event getBizRequestforgetTDSCertificateOnLoad(RequestContext p_ObjContext) throws Exception {
		final String METHODNAME = "getBizRequestforgetTDSCertificateOnLoad";
		try {
			Properties prop = new Properties();
			prop = MasterPropertiesFileLoader.CONSTANT_BROKER_PROPERTIES;

			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();

			String getProprtyValue = prop.getProperty("startDate");

			String brokerCode = null;

			if (httpSession != null) {
				IPruUser userVO = (IPruUser) httpSession.getAttribute("userVO");

				if (userVO == null) {
					FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME, "userVO should not be null");
					throw new IPruException("Error", "TDC01", "userVO should not be null");
				}

				FscDetailsVO fscDetailVo = userVO.getFscdetails();
				if (fscDetailVo == null) {
					FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME, "fscDetailVo should not be null");
					throw new IPruException("Error", "TDC01", "fscDetailVo should not be null");
				}

				brokerCode = fscDetailVo.getBranchCode() != null ? fscDetailVo.getBranchCode() : fscDetailVo.getNationalCode();

				if (StringUtils.isEmpty(brokerCode)) {
					FLogger.error(ERRORLOGGERNAME, CLASSNAME, METHODNAME, "brokerCode should not be null");
					throw new IPruException("Error", "TDC01", "fscDetailVo should not be null");
				}

				SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MMM-yyyy");
				Date getProprtyDate = sdf2.parse(getProprtyValue);
				String startDate = sdf2.format(getProprtyDate);
				String endDate = sdf2.format(new Date());

				BrokerTDSCertificateVO brokerTDSCertificateVO = new BrokerTDSCertificateVO();
				brokerTDSCertificateVO.setStartDate(startDate);
				brokerTDSCertificateVO.setEndDate(endDate);
				brokerTDSCertificateVO.setBrokerCode(brokerCode);

				Object[] paramArray = new Object[1];

				if (brokerTDSCertificateVO != null) {
					paramArray[0] = brokerTDSCertificateVO;
					BizRequest obj_bizReq = new BizRequest();
					obj_bizReq.addbusinessObjects("service-obj1", paramArray);
					p_ObjContext.getFlowScope().put("requestOnLoadBrokerTdsCertificate", obj_bizReq);
				}

			}

			else {
				FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME, "userVo should not be null");
				throw new IPruException("Error", "GRPPCB01", "userVo should not be null");
			}

		}

		catch (Exception e) {
			e.printStackTrace();
			FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Exception came", e);
			throwINeoFlowException(e, "TDC01", p_ObjContext);
		}
		FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Method End ");
		return success();
	}

	/*
	 * @MethodPost public Event
	 * getBizRequestforgetTDSCertificatePolicyList(RequestContext p_ObjContext)
	 * throws Exception { final String METHODNAME =
	 * "getBizRequestforgetTDSCertificatePolicyList"; try {
	 * FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, " Method Start");
	 * HttpServletRequest request = (HttpServletRequest)
	 * p_ObjContext.getExternalContext().getNativeRequest(); HttpSession
	 * httpSession = request.getSession(); String responseCheck = ""; IPruUser
	 * userVo = (IPruUser) httpSession.getAttribute("userVO"); if (userVo ==
	 * null) { FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME,
	 * "userVo Should not be null"); throw new IPruException("Error", "TDC01",
	 * ErrorMsg); } // List<String> policyNoList = new ArrayList<String>();
	 * Set<String> policyNoSet = new HashSet<String>(); for (String str :
	 * userVo.getFscdetails().getPolicyNoList()) { policyNoSet.add(str); } if
	 * (CollectionUtils.isEmpty(policyNoSet)) { throw new IPruException("Error",
	 * "TDC01", ErrorMsg); }
	 * p_ObjContext.getFlowScope().put("TDSCertificatepolicyList", policyNoSet);
	 * responseCheck = gsonJSON.toJson(policyNoSet);
	 * p_ObjContext.getFlowScope().put("Response", responseCheck); } catch
	 * (Exception e) { FLogger.info("BrokerBrokerTDSCertificateLogger",
	 * CLASSNAME, METHODNAME, "Exception came", e); throwINeoFlowException(e,
	 * "TDC01", p_ObjContext); } FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME,
	 * " Method end"); return success(); }
	 */

	/*
	 * @MethodPost public Event
	 * getBizRequestforSubmitTDSCertificate(RequestContext p_ObjContext) throws
	 * Exception { final String METHODNAME =
	 * "getBizRequestforSubmitTDSCertificate"; FLogger.info(LOGGERNAME,
	 * CLASSNAME, METHODNAME, " Method Start"); Properties prop = new
	 * Properties(); prop =
	 * MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
	 * FunctionalityMasterVO functionality; try { HttpServletRequest request =
	 * (HttpServletRequest)
	 * p_ObjContext.getExternalContext().getNativeRequest(); HttpSession
	 * httpSession = ((HttpServletRequest)
	 * p_ObjContext.getExternalContext().getNativeRequest()).getSession();
	 * StringBuffer jb = new StringBuffer(); String line = null; BufferedReader
	 * reader = request.getReader(); while ((line = reader.readLine()) != null)
	 * { jb.append(line); } functionality = this.getFunctionality(p_ObjContext);
	 * if (functionality == null) { FLogger.error("UnitStatementLogger",
	 * "UnitStatementHandler", "getBizRequestforUnitStatementSubmit",
	 * "functionality Should not be null"); throw new IPruException("Error",
	 * "US01", ErrorMsg); } IPruUser userVo = (IPruUser)
	 * httpSession.getAttribute("userVO"); if (userVo == null) {
	 * FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME,
	 * "userVo Should not be null"); throw new IPruException("Error",
	 * "GRPBTC01", ErrorMsg); } BrokerTDSCertificatePO tDSCertificatePO =
	 * gsonJSON.fromJson(jb.toString(), BrokerTDSCertificatePO.class); if
	 * (tDSCertificatePO == null) { FLogger.error(LOGGERNAME, CLASSNAME,
	 * METHODNAME, "tDSCertificatePO Should not be null"); throw new
	 * IPruException("Error", "GRPBTC01", ErrorMsg); } //
	 * tDSCertificatePO.setPolicyNo(userVo.getPolicyNo()); //
	 * tDSCertificatePO.setPolicyNo("00002285"); Set tdsCertificatepolicyList =
	 * (Set) p_ObjContext.getFlowScope().get("TDSCertificatepolicyList"); if
	 * (CollectionUtils.isEmpty(tdsCertificatepolicyList)) {
	 * FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME,
	 * "tdsCertificatepolicyList Should not be null"); throw new
	 * IPruException("Error", "GRPBTC01", ErrorMsg); } if
	 * (!tdsCertificatepolicyList.contains(tDSCertificatePO.getPolicyNo())) {
	 * FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME,
	 * "policyNumber not match"); throw new IPruException("Error", "GRPPCB01",
	 * ErrorMsg); } SimpleDateFormat sdf1 = new
	 * SimpleDateFormat("dd MMMM,yyyy"); SimpleDateFormat sdf2 = new
	 * SimpleDateFormat("dd-MMM-yyyy"); Date startDate1 =
	 * sdf1.parse(tDSCertificatePO.getStartDate()); String startDate =
	 * sdf2.format(startDate1); Date endDate1 =
	 * sdf1.parse(tDSCertificatePO.getEndDate()); String endDate =
	 * sdf2.format(endDate1); if (startDate1.after(endDate1)) { throw new
	 * IPruException("Error", "GRPBTC01",
	 * "Todate date should not be greater than From date"); }
	 * tDSCertificatePO.setStartDate(startDate);
	 * tDSCertificatePO.setEndDate(endDate); BrokerTDSCertificateVO
	 * tDSCertificateVO = dozerBeanMapper.map(tDSCertificatePO,
	 * BrokerTDSCertificateVO.class); if (tDSCertificateVO == null) {
	 * FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME,
	 * "tDSCertificateVO should not be null"); throw new IPruException("Error",
	 * "GRPBTC01", ErrorMsg); } Object[] paramArray = new Object[1];
	 * paramArray[0] = tDSCertificateVO; BizRequest obj_bizReq = new
	 * BizRequest(); obj_bizReq.addbusinessObjects("service-obj1", paramArray);
	 * p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq); } catch
	 * (Exception e) { FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME,
	 * "Exception came ", e); throwINeoFlowException(e, "GRPBTC01",
	 * p_ObjContext); } FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME,
	 * " Method End"); return success(); }
	 */

	@MethodPost
	public Event getBizResponseforOnLoadTDSCertificate(RequestContext p_ObjContext) throws Exception {
		final String METHODNAME = "getBizResponseforOnLoadTDSCertificate";
		try {

			FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, " Method Start");

			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForTDSCertificate");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "responseCheck null");
					throw new IPruException("Error", "GRPBTC01", "No fund data found Please try again!");
				}
				else {
					String url = (String) bizRes.getTransferObjects().get("response1");

					if (StringUtils.isEmpty(url)) {
						FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "responseCheck null");
						throw new IPruException("Error", "GRPBTC01", "Some Error Occured");
					}
					responseCheck = gsonJSON.toJson(url);
					p_ObjContext.getFlowScope().put("Response", responseCheck);

				}
			}
			else {

				FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "url null");

				throw new IPruException("Error", "GRPBTC01", "Some Error Occured");
			}
		}
		catch (Exception e) {

			FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Exception came", e);
			throwINeoFlowException(e, "GRPPCB01", p_ObjContext);
		}

		FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, " Method end");
		return success();
	}

	/*
	 * @MethodPost public Event
	 * getBizResponseforSubmitTDSCertificate(RequestContext p_ObjContext) throws
	 * Exception { final String METHODNAME =
	 * "getBizResponseforSubmitTDSCertificate"; try { FLogger.info(LOGGERNAME,
	 * CLASSNAME, METHODNAME, " Method Start"); HttpServletRequest request =
	 * (HttpServletRequest)
	 * p_ObjContext.getExternalContext().getNativeRequest(); HttpSession
	 * httpSession = request.getSession(); BizResponse bizRes = new
	 * BizResponse(); String responseCheck = ""; bizRes = (BizResponse)
	 * p_ObjContext.getFlowScope().get("bizResForTDSCertificate"); if (bizRes !=
	 * null) { responseCheck = (String) bizRes.getStatusVO().getStatus(); if
	 * (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
	 * FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "responseCheck null");
	 * throw new IPruException("Error", "GRPBTC01",
	 * "No fund data found Please Try Again"); } else { String url = (String)
	 * bizRes.getTransferObjects().get("response1"); if
	 * (StringUtils.isEmpty(url)) { FLogger.info(LOGGERNAME, CLASSNAME,
	 * METHODNAME, "responseCheck null"); throw new IPruException("Error",
	 * "GRPBTC01", "Some Error Occured"); } responseCheck =
	 * gsonJSON.toJson(url); p_ObjContext.getFlowScope().put("Response",
	 * responseCheck); } } else { FLogger.info(LOGGERNAME, CLASSNAME,
	 * METHODNAME, "url null"); throw new IPruException("Error", "GRPBTC01",
	 * "Some Error Occured"); } } catch (Exception e) { FLogger.info(LOGGERNAME,
	 * CLASSNAME, METHODNAME, "Exception came", e); throwINeoFlowException(e,
	 * "GRPBTC01", p_ObjContext); } FLogger.info(LOGGERNAME, CLASSNAME,
	 * METHODNAME, " Method end"); return success(); }
	 */

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
