package com.ipru.groups.validators;

import java.util.Set;

import com.ipru.IPruException;
import com.ipru.groups.po.GroupsBasePo;
import com.tcs.logger.FLogger;

public class BrokerBidSummaryValidator {

	public static final String CLASSNAME = BrokerBidSummaryValidator.class.getCanonicalName();
	public static final String LOGGERNAME = "BrokerBidSummaryLogger";
	private static final String ERROR_LOGGER_NAME = "BrokerBidSummaryLogger";

	public String validateBrokerBidSummary(GroupsBasePo brokerBidSummaryPO, Set<String> policyNoSet) throws Exception {
		final String METHODNAME = "validateBrokerBidSummary";
		FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Method Start");

		if (brokerBidSummaryPO != null && policyNoSet != null) {

			// if(!brokerBidSummaryPO.getPolicyNumber().equals(policyNoSet))
			if (!policyNoSet.contains(brokerBidSummaryPO.getPolicyNo())) {
				FLogger.error(LOGGERNAME, CLASSNAME, METHODNAME, "Policy Number is Not Valid");
				throw new IPruException("Error", "GRPBBS01", "Policy Number is Not Valid");
			}

		}
		else {
			FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Blank Data");
			throw new IPruException("Error", "GRPBBS01", "No data found");
		}

		FLogger.info(LOGGERNAME, CLASSNAME, METHODNAME, "Method End");
		return null;
	}

}
