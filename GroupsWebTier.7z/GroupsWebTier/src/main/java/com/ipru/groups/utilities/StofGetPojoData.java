package com.ipru.groups.utilities;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.enums.RequestTypeEnum;
import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.StofSubmitTransactionVO;
import com.ipru.groups.vo.StofSubmitVo;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public class StofGetPojoData {

	public StofSubmitTransactionVO getStofGetPojoData(StofSubmitTransactionVO stofSubmitTransactionVO, List<FundMasterVO> fundMasterList, RequestContext p_ObjContext) throws IPruException {
		FLogger.info("StofLogger", "StofGetPojoData", "getStofGetPojoData", "getStofGetPojoData Method Start");

		// String productCode = "SA1PLUS3DC";
		String requestType = RequestTypeEnum.STOF.getRequestType();
		String policyNumber = null;
		String clientId = null;
		String role = null;
		String memberType=null;
		String productType = null;
		IPruUser userVo = null;

		if (stofSubmitTransactionVO != null && fundMasterList != null) {

			Set<StofSubmitVo> stofSubmitVoList = stofSubmitTransactionVO.getStof();
			HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");
				if (userVo != null) {
					policyNumber = userVo.getPolicyNo();
					role = userVo.getRoles();
					clientId = userVo.getClientId();
					productType = userVo.getProductType();
					memberType = userVo.getRoleType();

					// clientId = "Q2777";

				}
				// set fund details value
				if (stofSubmitVoList == null) {
					FLogger.error("StofLogger", "StofGetPojoData", "getStofGetPojoData", "found null data");
					throw new IPruException("Error", "GRPSTF02", "found null data");
				}
				for (StofSubmitVo stofSubmitVo : stofSubmitVoList) {

					for (FundMasterVO fundMasterVO : fundMasterList) {
						if (stofSubmitVo.getFundFromName().trim().equalsIgnoreCase(fundMasterVO.getFundName().trim())) {
							stofSubmitVo.setFromFundCode(fundMasterVO.getFundCode());
						}
						if (stofSubmitVo.getFundToName().trim().equalsIgnoreCase(fundMasterVO.getFundName().trim())) {
							stofSubmitVo.setToFundCode(fundMasterVO.getFundCode());
						}
					}

					stofSubmitVo.setSwitchType(stofSubmitTransactionVO.getSwitchType());
					stofSubmitVo.setCreatedBy("app");
					stofSubmitVo.setCreatedDate(new Date());

				}

				stofSubmitTransactionVO.setClientId(clientId);
				stofSubmitTransactionVO.setCreatedBy("App");
				stofSubmitTransactionVO.setCreatedDate(new Date());
				stofSubmitTransactionVO.setPolicyNo(policyNumber);
				// stofSubmitTransactionVO.setProductCode(productCode);
				stofSubmitTransactionVO.setRequestType(requestType);
				stofSubmitTransactionVO.setRole(role);
				stofSubmitTransactionVO.setRequestType(requestType);
				stofSubmitTransactionVO.setMemberType(memberType);
				// DateFormat formatter = new
				// SimpleDateFormat("MMM dd, yyyy HH:mm:ss Z");//Mar 22, 2017
				// 12:00:00 AM
				// stofSubmitTransactionVO.setReqExecutionDate(switchExecutionDate);
				stofSubmitTransactionVO.setStof(stofSubmitVoList);
				stofSubmitTransactionVO.setProductType(productType);
			}
			else {
				// throw
				FLogger.error("StofLogger", "StofGetPojoData", "getStofGetPojoData", "found null session");

				throw new IPruException("Error", "GRPSTF02", "found null session");

			}

		}
		else {
			FLogger.error("StofLogger", "StofGetPojoData", "getStofGetPojoData", "found null data");
			throw new IPruException("Error", "GRPSTF02", "found null data");
		}
		return stofSubmitTransactionVO;
	}


	

	public String getMemberType(String role) throws IPruException {

		if (role != null) {

			role = role.toUpperCase();

			if (role.contains("MEMBER")) {

				return "Member";

			}
			else {

				return "Trust";

			}

		}
		FLogger.error("StofLogger", "StofService", "getStofLoadData", "Invalid Role");
		throw new IPruException("Error", "GRPSTF02", "Some error occured");

	}


}
