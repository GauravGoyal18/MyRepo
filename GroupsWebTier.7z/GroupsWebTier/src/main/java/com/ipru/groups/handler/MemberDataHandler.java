package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.MemberDataListPO;
import com.ipru.groups.po.MemberDataRequestPO;
import com.ipru.groups.po.MemberDataTermPO;
import com.ipru.groups.po.MemberDataTrustPO;
import com.ipru.groups.po.MemberFundDataListPO;
import com.ipru.groups.po.MemberFundDataPO;
import com.ipru.groups.po.MemberFundDataRequestPO;
import com.ipru.groups.vo.MemberDataRequestVO;
import com.ipru.groups.vo.MemberDataTermVO;
import com.ipru.groups.vo.MemberDataTrustVO;
import com.ipru.groups.vo.MemberFundDataRequestVO;
import com.ipru.groups.vo.MemberFundDataVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class MemberDataHandler extends IneoBaseHandler {

	private static final long serialVersionUID = 1L;

	@MethodPost
	public Event getBizRequestForLoadTrustMemberData(RequestContext context) throws Exception {
		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadMemberData", "Method start");
		Gson gson = new Gson();
		IPruUser userVo = new IPruUser();
		String policyNo = null;
		String role = null;
		String unitCode = null;
		String memberType = null;
		String productType = null;

		try {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null) {
					policyNo = userVo.getPolicyNo();
				
					role = userVo.getRoles();
					unitCode = userVo.getUnitCode();
					memberType = userVo.getRoleType();
					productType = userVo.getProductType();
					// role = "GTRUST";
					// unitCode = "1"; // Get from session.
					FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadMemberData", "Policy No in session : " + policyNo);
					FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadMemberData", "Role in session : " + role);

					HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
				
					MemberDataRequestPO memberDataRequestPO = gsonJSON.fromJson(request.getReader() , MemberDataRequestPO.class);
					if(memberDataRequestPO==null)
					{
						throw new IPruException("Something went wrong please try again");
					}
					if(StringUtils.isEmpty(memberDataRequestPO.getMax()) && StringUtils.isEmpty(memberDataRequestPO.getOffset()))
					{
						throw new IPruException("Something went wrong please try again");
					}
					//System.out.println(memberDataRequestPO.toString());
					if (StringUtils.isNotBlank(policyNo) && StringUtils.isNotBlank(role)) {

					

						memberDataRequestPO.setPolicyNo(policyNo);
						memberDataRequestPO.setRole(role);
						memberDataRequestPO.setUnitCode(unitCode);
						memberDataRequestPO.setMemberType(memberType);
						memberDataRequestPO.setProductType(productType);

						MemberDataRequestVO memberDataRequestVO = dozerBeanMapper.map(memberDataRequestPO, MemberDataRequestVO.class);

						Object[] paramArray = new Object[1];
						paramArray[0] = memberDataRequestVO;

						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);

						context.getFlowScope().put("loadMemberDataBizReq", obj_bizReq);
					}
					else {
						FLogger.error("MemberDataError", "MemberDataHandler", "getBizRequestForLoadMemberData", "Policy Number is null");
						throw new IPruException("Policy Number is null");
					}
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("MemberDataError", "MemberDataHandler", "getBizRequestForLoadMemberData", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}

		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadMemberData", "Method end");
		return success();
	}

	@MethodPost
	public Event getBizResponseForLoadTrustMemberData(RequestContext context) throws Exception {
		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizResponseForLoadMemberData", "Method start");

		List<MemberDataTrustVO> memberDataTrustVOList = null;
		List<MemberDataTermVO> memberDataTermVOList = null;
		List<MemberDataTrustPO> memberDataTrustPOList = null;
		List<MemberDataTermPO> memberDataTermPOList = null;
		IPruUser userVo = new IPruUser();
		String policyNo = null;
		String role = null;
		String memberType = null;
		String productType = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			
			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");
				// ////System.out.println("UserVo in session : " + userVo);

				if (userVo != null) {
					policyNo = userVo.getPolicyNo();
					// policyNo = "00002001";
					role = userVo.getRoles();
					// role = "GTRUST";
					memberType = userVo.getRoleType();
					productType = userVo.getProductType();
					if(productType != null)
						productType = productType.toUpperCase();

					bizRes = (BizResponse) context.getFlowScope().get("bizResForLoadMemberData");
					if (bizRes != null) {
						responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
							FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForLoadMemberData", "Error came while getting response from service");
							throw new IPruException("Error", "GRYY01", "Some error Occured, Please try again later");
						}
						else {
							String memberListJsonString = null;
							
							if(role != null)
								role = role.toUpperCase();

							if (memberType.equalsIgnoreCase("TRUST")) {

								memberDataTrustVOList = (List<MemberDataTrustVO>) bizRes.getTransferObjects().get("response1");
								if (memberDataTrustVOList != null) {
									memberDataTrustPOList = new ArrayList<MemberDataTrustPO>();
									for (MemberDataTrustVO memberDataTrustVO : memberDataTrustVOList) {
										MemberDataTrustPO memberDataTrustPO = dozerBeanMapper.map(memberDataTrustVO, MemberDataTrustPO.class);
										memberDataTrustPOList.add(memberDataTrustPO);
										
									}
								}
								httpSession.setAttribute("memberDataTrustPOList", memberDataTrustPOList);
								MemberDataListPO memberDataListPO = new MemberDataListPO(memberDataTrustPOList, policyNo, role, memberType, productType);

								memberListJsonString = gsonJSON.toJson(memberDataListPO, MemberDataListPO.class);
							}
							else if (memberType.equalsIgnoreCase("TERM") || memberType.equalsIgnoreCase("GTRUST")) {

								memberDataTermVOList = (List<MemberDataTermVO>) bizRes.getTransferObjects().get("response1");
								if (memberDataTermVOList != null) {
									memberDataTermPOList = new ArrayList<MemberDataTermPO>();
									for (MemberDataTermVO memberDataTermVO : memberDataTermVOList) {
										MemberDataTermPO memberDataTermPO = dozerBeanMapper.map(memberDataTermVO, MemberDataTermPO.class);
										memberDataTermPOList.add(memberDataTermPO);
									}
								}
								httpSession.setAttribute("memberDataTermPOList", memberDataTermPOList);
								MemberDataListPO memberDataTermListPO = new MemberDataListPO(memberDataTermPOList, policyNo, role,memberType, productType);

								memberListJsonString = gsonJSON.toJson(memberDataTermListPO, MemberDataListPO.class);
							}

							context.getFlowScope().put("Response", memberListJsonString);
						}
					}
					else {
						FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForLoadMemberData", "bizRes is null");
						throw new IPruException("Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForLoadMemberData", "userVO is null");
					throw new IPruException("Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForLoadMemberData", "session is null");
				throw new IPruException("Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			//e.printStackTrace();
			FLogger.error("MemberDataError", "MemberDataHandler", "getBizRequestForLoadMemberData", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}
		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizResponseForLoadMemberData", "Method end");
		return success();
	}

	@MethodPost
	public Event getBizRequestForLoadTrustMemberFundData(RequestContext context) throws Exception {
		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadTrustMemberFundData", "Method start");

		IPruUser userVo = new IPruUser();
		String policyNo = null;
		String role = null;

		try {
			if (context != null) {
				HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
				MemberFundDataRequestPO memberFundDataRequestPO = gsonJSON.fromJson(request.getReader(), MemberFundDataRequestPO.class);

				////System.out.println("memberFundDataRequestPO : "+memberFundDataRequestPO);
				
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {
						policyNo = userVo.getPolicyNo();
						// policyNo = "00002001";
						role = userVo.getRoles();
						// role = "GTRUST";
						// unitCode = "1"; // Get from session.
						FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadTrustMemberFundData", "Policy No in session : " + policyNo);
						FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadTrustMemberFundData", "Role in session : " + role);
						
						if (memberFundDataRequestPO != null) {

							// Validate data with validator

							MemberFundDataRequestVO memberFundDataRequestVO = dozerBeanMapper.map(memberFundDataRequestPO, MemberFundDataRequestVO.class);

							Object[] paramArray = new Object[1];
							paramArray[0] = memberFundDataRequestVO;

							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("loadMemberFundDataBizReq", obj_bizReq);
						}
						else {
							FLogger.error("MemberDataError", "MemberDataHandler", "getBizRequestForLoadTrustMemberFundData", "Policy Number is null");
							throw new IPruException("Request Data is null");
						}
					}
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("MemberDataError", "MemberDataHandler", "getBizRequestForLoadTrustMemberFundData", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}

		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadTrustMemberFundData", "Method end");
		return success();
	}

	@MethodPost
	public Event getBizResponseForLoadTrustMemberFundData(RequestContext context) throws Exception {
		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizResponseForLoadTrustMemberFundData", "Method start");

		List<MemberFundDataVO> memberFundDataList = null;
		List<MemberFundDataPO> memberFundDataPOList = null;
		IPruUser userVo = new IPruUser();
		String policyNo = null;
		String role = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");
				// ////System.out.println("UserVo in session : " + userVo);

				if (userVo != null) {
					policyNo = userVo.getPolicyNo();
					// policyNo = "00002001";
					role = userVo.getRoles();
					// role = "GTRUST";

					bizRes = (BizResponse) context.getFlowScope().get("bizResForLoadMemberFundData");
					if (bizRes != null) {
						responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
							FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForLoadTrustMemberFundData", "Error came while getting response from service");
							throwINeoFlowException(bizRes.getStatusVO(), context);
						}
						else {
							String memberFundListJsonString = null;

							memberFundDataList = (List<MemberFundDataVO>) bizRes.getTransferObjects().get("response1");
							if(!CollectionUtils.isEmpty(memberFundDataList)){
							
							if (memberFundDataList != null) {
								memberFundDataPOList = new ArrayList<MemberFundDataPO>();
								for (MemberFundDataVO memberFundDataVO : memberFundDataList) {
									MemberFundDataPO memberFundDataPO = dozerBeanMapper.map(memberFundDataVO, MemberFundDataPO.class);
									memberFundDataPOList.add(memberFundDataPO);
								}
							}

							MemberFundDataListPO MemberFundDataListPO = new MemberFundDataListPO(memberFundDataPOList, policyNo, role);

							memberFundListJsonString = gsonJSON.toJson(MemberFundDataListPO, MemberFundDataListPO.class);
							}
							else
							{
								memberFundListJsonString = null;
							}
							
							context.getFlowScope().put("Response", memberFundListJsonString);
						}

					}
					else {
						FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForLoadTrustMemberFundData", "bizRes is null");
						throw new IPruException("Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForLoadTrustMemberFundData", "userVO is null");
					throw new IPruException("Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForLoadTrustMemberFundData", "session is null");
				throw new IPruException("Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForLoadTrustMemberFundData", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}
		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizResponseForLoadTrustMemberFundData", "Method end");
		return success();
	}

	
	
	
	
	@MethodPost
	public Event getBizRequestForMemberDataCount(RequestContext context) throws Exception {
		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadMemberData", "Method start");
		/*Gson gson = new Gson();*/
		IPruUser userVo = new IPruUser();
		String policyNo = null;
		String role = null;
		String unitCode = null;
		String memberType = null;
		String productType = null;

		try {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null) {
					policyNo = userVo.getPolicyNo();
					// policyNo = "00002001";
					role = userVo.getRoles();
					unitCode = userVo.getUnitCode();
					memberType = userVo.getRoleType();
					productType = userVo.getProductType();
					// role = "GTRUST";
					// unitCode = "1"; // Get from session.
					FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadMemberData", "Policy No in session : " + policyNo);
					FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadMemberData", "Role in session : " + role);

					//HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
				
					//MemberDataRequestPO memberDataRequestPO = gsonJSON.fromJson(request.getReader() , MemberDataRequestPO.class);
					//if(memberDataRequestPO==null)
					//{
					//	throw new IPruException("Something went wrong please try again");
					//}
					
					////System.out.println(memberDataRequestPO.toString());
				/*	if (StringUtils.isNotBlank(policyNo) && StringUtils.isNotBlank(role)) {
*/
					MemberDataRequestPO memberDataRequestPO=new MemberDataRequestPO();
					
						memberDataRequestPO.setPolicyNo(policyNo);
						memberDataRequestPO.setRole(role);
						memberDataRequestPO.setUnitCode(unitCode);
						memberDataRequestPO.setMemberType(memberType);
						memberDataRequestPO.setProductType(productType);

						MemberDataRequestVO memberDataRequestVO = dozerBeanMapper.map(memberDataRequestPO, MemberDataRequestVO.class);

						Object[] paramArray = new Object[1];
						paramArray[0] = memberDataRequestVO;

						BizRequest obj_bizReq = new BizRequest();
						obj_bizReq.addbusinessObjects("service-obj1", paramArray);

						context.getFlowScope().put("loadMemberDataBizReq", obj_bizReq);
					}
					
				
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("MemberDataError", "MemberDataHandler", "getBizRequestForLoadMemberData", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}

		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizRequestForLoadMemberData", "Method end");
		return success();
	}
	@MethodPost
	public Event getBizResponseForMembercount(RequestContext context) throws Exception {
		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizResponseForMembercount", "Method start");
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		Long count=0L;

		try {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession != null) {
			

					bizRes = (BizResponse) context.getFlowScope().get("bizResForLoadMemberDataCount");
					if (bizRes != null) {
						responseCheck = (String) bizRes.getStatusVO().getStatus();
						if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
							FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForMembercount", "Error came while getting response from service");
							throwINeoFlowException(bizRes.getStatusVO(), context);
						}
						else {
							try{
							count = (Long) bizRes.getTransferObjects().get("response1");
							////System.out.println("****************"+count);
							if(count == 0){
								
								FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForMembercount", "count is null");
							/*	throw new IPruException("Something went wrong. Please try again later.");*/
								
							}
							}
							catch(Exception e)
							{
								FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForMembercount", "count is null",e);
								throw new IPruException("Something went wrong. Please try again later.");
							}

							context.getFlowScope().put("Response",count);
						}
					}
					
				}
				
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("MemberDataError", "MemberDataHandler", "getBizResponseForMembercount", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}
		FLogger.info("MemberDataLogger", "MemberDataHandler", "getBizResponseForMembercount", "Method end");
		return success();
	}
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}
}
