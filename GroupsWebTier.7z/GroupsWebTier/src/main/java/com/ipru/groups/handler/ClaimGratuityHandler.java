package com.ipru.groups.handler;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ipru.IPruException;
import com.ipru.groups.po.ClaimGratuityPO;
import com.ipru.groups.po.DropDownObjPO;
import com.ipru.groups.validators.ClaimGratuityValidator;
import com.ipru.groups.vo.ClaimGratuityVO;
import com.ipru.groups.vo.DropDownObjVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ClaimGratuityHandler extends IneoBaseHandler {

	private static final String INFO_LOGGER_NAME = "ClaimGratuityLogger";
	private static final String CLASS_NAME = "ClaimGratuityHandler";
	private static final String ERROR_LOGGER_NAME = "ClaimGratuityLogger";
	



	
	
	//Onload Response Method
	@MethodPost
	public Event getBizResponseOnLoadClaimGratuity(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseOnLoadClaimGratuity";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		ClaimGratuityPO claimGratuityUi=null;

		BizResponse bizRes = new BizResponse();
		//String responseCheck = "";
		boolean firstTime= false;

		try {
			if (context != null)
			{
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				
			
				if (httpSession != null) 
				{
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
				
					if (userVo != null) {
						
						bizRes = (BizResponse) context.getFlowScope().get("bizResForClaimGratuity");
						
						if(bizRes != null)
							{
								
							ClaimGratuityVO claimGratuityResponseVo = (ClaimGratuityVO) bizRes.getTransferObjects().get("response1");
							
							if(claimGratuityResponseVo==null)
							{
								firstTime=true;	
								claimGratuityUi=new ClaimGratuityPO();
								
								
								claimGratuityUi.setPolicyNumber(userVo.getPolicyNo());
								claimGratuityUi.setTrustieeName(userVo.getClientName());
								claimGratuityUi.setFirstTimeUser(firstTime);
								claimGratuityUi.setEmployeeName(userVo.getFirstName());
							}
							
							else
							{
								HttpSession session=((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
								session.setAttribute("claimGratuityVoData",claimGratuityResponseVo);
								
								claimGratuityUi=new ClaimGratuityPO();
								
								
								claimGratuityUi.setPolicyNumber(userVo.getPolicyNo());
								claimGratuityUi.setTrustieeName(userVo.getClientName());
								claimGratuityUi.setFirstTimeUser(firstTime);
							}
							
								
								
								
							}
						else {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
							throw new IPruException("Error","GRPGTCLMSS01","Something went wrong. Please try again later.");
						}
						
						
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
						throw new IPruException("Error", "GRPBTC", "userVo should not be null");
					}
					
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
					throw new IPruException("Error", "GRPGTCLMSS01", "httpSession should not be null");
				}
				
				String JsonResponse=gsonJSON.toJson(claimGratuityUi);
				
				context.getFlowScope().put("Response",JsonResponse);
				
					

			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPGTCLMSS01", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");

		return success();

	}
	
	// Request Submit Method
	
	@MethodPost
	public Event getBizRequestForclaimsGratuitySubmit(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestForclaimsGratuitySubmit";
		ClaimGratuityPO claimGratuityPO=null;
		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "Method start");

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
		
			if (request != null) {
				
			
				

				Type t = new TypeToken<ClaimGratuityPO>() {
				}.getType();
				
				
				claimGratuityPO=new ClaimGratuityPO();
				
				
				claimGratuityPO = gsonJSON.fromJson(request.getReader(), ClaimGratuityPO.class);
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "got claimGratuityPO object");

				if (claimGratuityPO == null) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Found null data from UI");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}
				
				String polNumber=(String)context.getFlowScope().get("policyNumber");
				if(!(polNumber.equalsIgnoreCase(claimGratuityPO.getPolicyNumber())))
				{
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Policy Number Does Not Match");
					throw new IPruException("Error", "GRPBTC", "Policy Number Not Match");
				}
				String memberId=(String)context.getFlowScope().get("memberId");
				if(!(memberId.equalsIgnoreCase(claimGratuityPO.getMemberId())))
				{
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Member Id(Emp Id) Does Not Match");
					throw new IPruException("Error", "GRPBTC", "Member Id Not Match");
				}
				String empName=(String)context.getFlowScope().get("empName");
				if(!(empName.equalsIgnoreCase(claimGratuityPO.getEmployeeName())))
				{
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Employee Name Does Not Match");
					throw new IPruException("Error", "GRPBTC", "Employee Name Does Not Match");
				}
				String trustName=(String)context.getFlowScope().get("trustName");
				if(!(trustName.equalsIgnoreCase(claimGratuityPO.getTrustieeName())))
				{
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Trust Name Does Not Match");
					throw new IPruException("Error", "GRPBTC", "Trust Name Does Not Match");
				}
				String errorSuccessMessage = ClaimGratuityValidator.getInstance().validateClaimGratuity(claimGratuityPO);

				if (StringUtils.isNotBlank(errorSuccessMessage)) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "errorSuccessMessage is" + errorSuccessMessage);

					this.setValidationErrorMessages(errorSuccessMessage);

					throw new IPruException("Error", "GRPGTCLMSS01", errorSuccessMessage);

				}

				ClaimGratuityVO claimGratuityVO = dozerBeanMapper.map(claimGratuityPO, ClaimGratuityVO.class);
				if (claimGratuityVO == null) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Got null data after dozer bean mapping");

					throw new IPruException("Error", "GRPGTCLMSS01", "Somethig went wrong");
				}

				Object[] paramArray = new Object[1];
				paramArray[0] = claimGratuityVO;

				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				context.getFlowScope().put("claimsGratuityDataBizReq", obj_bizReq);

			}

		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "No Data Found.", e);

			throwINeoFlowException(e, "GRPGTCLMSS01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "Method end");

		return success();

	}
	
	// On Submit Response Method
	
	@MethodPost
	public Event getBizResponseForclaimsGratuitySubmit(RequestContext context) throws Exception {

		final String METHOD_NAME = "getBizResponseForclaimsGratuitySubmit";
		ClaimGratuityPO claimGratuityPO= new ClaimGratuityPO();
		try {
			ClaimGratuityVO claimGratuityResponseVO=new ClaimGratuityVO();

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "Method start");

			String policyNumber = null;
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession == null) {

				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "FOund null session");

				throw new IPruException("Error", "GRPGTCLMSS01", "Session expired");
			}

			String responseCheck = "";
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForclaimsGratuitySave");
			if (bizRes != null)
			{		
				claimGratuityResponseVO = (ClaimGratuityVO) bizRes.getTransferObjects().get("response1");
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "claimGratuityResponseVO object from database" + claimGratuityResponseVO);
				
				if(claimGratuityResponseVO == null)
				{
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "claimGratuityResponseVO should not be null");
					throw new IPruException("Error", "GRPGTCLMSS01", "No Data From WebService");
				}
				
				
				
				HttpSession session=((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				session.setAttribute("claimGratuityVoData",claimGratuityResponseVO);

			
			}
			
			context.getFlowScope().put("Response", "success");

		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "Some error occured", e);

			throwINeoFlowException(e, "GRPGTCLMSS01", context);
		}
		return success();

	}
	
	
	@MethodPost
	public Event getBizRequestforOnloadgetStateDetailsData(RequestContext context) throws Exception {
		  final String METHOD_NAME="getBizRequestforOnloadgetStateDetailsData";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "getBizRequestforOnloadgetStateDetailsData Method Start");
		try {

			BizRequest obj_bizReq = new BizRequest();
			context.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came", e);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "getBizRequestforOnloadgetStateDetailsData Method End");
		return success();

	}
	
	@MethodPost
	public Event getBizResponseforOnloadStateDetailsData(RequestContext context) throws Exception {
		
		final String METHOD_NAME="getBizResponseforOnloadStateDetailsData";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "getBizResponseforOnloadStateDetailsData Method Start");
		String responselist = "";
		String responseCheck = "";
		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadStateDetailsData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					Gson gson = new Gson();
					List<DropDownObjVO> response = (List<DropDownObjVO>) bizRes.getTransferObjects().get("response1");
					DropDownObjPO po = null;
					TreeSet<String> data = new TreeSet<String>();
					for (int i = 0; i < response.size(); i++) {
						po = new DropDownObjPO();
						DropDownObjVO vo = (DropDownObjVO) response.get(i);
						dozerBeanMapper.map(vo, po);
						data.add(po.getValue());
					}
					if (CollectionUtils.isNotEmpty(data)) {
						context.getFlowScope().put("OnloadStateDetailsData", data);
						responselist = gson.toJson(data);
						context.getFlowScope().put("Response", responselist);
					}
					else {

						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "response should not be null");
						throw new IPruException("Error", "GRPGTCLMSS01", "Some Error Occured");
					}

				}
			}
			else {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null ");
				throw new IPruException("Error", "GRPGTCLMSS01", "Some Error Occured");

			}

		}
		catch (Exception e) {
			throwINeoFlowException(e, "GPU01", context);
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came", e);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "getBizResponseforOnloadStateDetailsData Method End");
		return success();
	}
	
	
	@MethodPost
	public Event getBizRequestforOnloadgetCityDetails(RequestContext context) throws Exception {
		final String METHOD_NAME="getBizRequestforOnloadgetCityDetails";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "getBizRequestforOnloadgetCityDetails Method Start ");
		try {
			BizRequest obj_bizReq = new BizRequest();
			context.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came", e);
			throwINeoFlowException(e, "GRPGTCLMSS01", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "getBizRequestforOnloadgetCityDetails Method End ");
		return success();
	}
	
	
	@MethodPost
	public Event getBizResponseforOnloadgetCityDetails(RequestContext context) throws Exception {
		final String METHOD_NAME="getBizResponseforOnloadgetCityDetails";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "getBizResponseforOnloadgetCityDetails Method Start ");
		String responselist = "";
		String responseCheck = "";

		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResOnloadCityDetails");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					Gson gson = new Gson();
					List<DropDownObjVO> response = (List<DropDownObjVO>) bizRes.getTransferObjects().get("response1");
					TreeSet cityDetails = new TreeSet();
					Map<String, String> map = new HashMap<String, String>();
					DropDownObjPO po = null;
					List<DropDownObjPO> cityDetailsPo = new ArrayList();
					if (response != null) {
						for (int i = 0; i < response.size(); i++) {
							po = new DropDownObjPO();
							DropDownObjVO vo = (DropDownObjVO) response.get(i);
							dozerBeanMapper.map(vo, po);
							cityDetails.add(po.getValue());
							cityDetailsPo.add(po);
						}

						if (CollectionUtils.isNotEmpty(cityDetailsPo)) {
							context.getFlowScope().put("OnloadCityDetails", cityDetails);

							responselist = gson.toJson(cityDetailsPo);
							context.getFlowScope().put("Response", responselist);
						}
						else {

							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "cityDetails and map should not be null");
							throw new IPruException("Error", "GRPGTCLMSS01", "Some Error Occured");
						}
					}
					else {

						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "response should not be null");
						throw new IPruException("Error", "GRPGTCLMSS01", "Some Error Occured");
					}

				}
			}
			else {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");

				throw new IPruException("Error", "GRPGTCLMSS01", "Some Error Occured");
			}
		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came", e);
			throwINeoFlowException(e, "GRPGTCLMSS01", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "getBizResponseforOnloadgetCityDetails Method End ");
		return success();
	}
	
	
	//Extra Code For Policy Emp Flow
	
	@MethodPost
	public Event getBizRequestForPolEmpId(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestForclaimsGratuitySubmit";
		ClaimGratuityPO claimGratuityPO=null;
		String policyNumber=null;
		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "Method start");

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
		
			if (request != null) {
				
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
				if(httpSession==null)
				{
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
					throw new IPruException("Error", "GRPGTCLMSS01", "httpSession should not be null");
				}
				IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
				if(userVo==null)
				{
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
					throw new IPruException("Error", "GRPBTC", "userVo should not be null");
				}
				
				policyNumber=userVo.getPolicyNo();

				Type t = new TypeToken<ClaimGratuityPO>() {
				}.getType();
				
				
				claimGratuityPO=new ClaimGratuityPO();
				
				
				claimGratuityPO = gsonJSON.fromJson(request.getReader(), ClaimGratuityPO.class);
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "got claimGratuityPO object");

				if (claimGratuityPO == null) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Found null data from UI");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}
				
				if(!(policyNumber.equalsIgnoreCase(claimGratuityPO.getPolicyNumber())))
				{
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Policy Number Does Not Match");
					throw new IPruException("Error", "GRPBTC", "Policy Number Not Match");
				}
				
				String errorSuccessMessage = ClaimGratuityValidator.getInstance().validatePolicyEmpId(claimGratuityPO);

				if (StringUtils.isNotBlank(errorSuccessMessage)) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "errorSuccessMessage is" + errorSuccessMessage);

					this.setValidationErrorMessages(errorSuccessMessage);

					throw new IPruException("Error", "GRPGTCLMSS01", errorSuccessMessage);

				}

				
				ClaimGratuityVO claimGratuityVO = dozerBeanMapper.map(claimGratuityPO, ClaimGratuityVO.class);
				
				if (claimGratuityVO == null) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Got null data after dozer bean mapping");

					throw new IPruException("Error", "GRPGTCLMSS01", "Somethig went wrong");
				}
				
				context.getFlowScope().put("memberId",claimGratuityVO.getMemberId());
				context.getFlowScope().put("empName",userVo.getFirstName());
				context.getFlowScope().put("trustName",userVo.getClientName());
				context.getFlowScope().put("policyNumber",userVo.getPolicyNo());
				
				Object[] paramArray = new Object[1];
				paramArray[0] = claimGratuityVO;

				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				context.getFlowScope().put("panNoEmpIdClaimsGratuityDataBizReq", obj_bizReq);

			}

		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "No Data Found.", e);

			throwINeoFlowException(e, "GRPGTCLMSS01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME,METHOD_NAME, "Method end");

		return success();

	}
	
	//Response method On PolicyNumber and Emp Id
	@MethodPost
	public Event getBizResponseOnPolEmpId(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseOnLoadClaimGratuity";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		ClaimGratuityPO claimGratuityUi=null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		boolean firstTime= false;
		

		try {
			if (context != null)
			{
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				
				IPruUser userVO = new IPruUser();
				if (httpSession != null) 
				{
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
				
					if (userVo != null) {
						
						bizRes = (BizResponse) context.getFlowScope().get("bizResForPolEmpIdClaimGratuity");
						
						if(bizRes != null)
							{
								
							ClaimGratuityVO claimGratuityResponseVo = (ClaimGratuityVO) bizRes.getTransferObjects().get("response1");
							
							if(claimGratuityResponseVo==null)
							{
								firstTime=true;	
								claimGratuityUi=new ClaimGratuityPO();
								
								/*claimGratuityUi.setPolicyNumber("123434");
								claimGratuityUi.setTrustieeName("IBM");
								claimGratuityUi.setFirstTimeUser(firstTime);
								claimGratuityUi.setEmployeeName("Nagaraj");*/
								
								claimGratuityUi.setPolicyNumber(userVo.getPolicyNo());
								claimGratuityUi.setTrustieeName(userVo.getClientName());
								claimGratuityUi.setFirstTimeUser(firstTime);
								claimGratuityUi.setEmployeeName(userVo.getFirstName());
								String memberId=(String)context.getFlowScope().get("memberId");
								
								claimGratuityUi.setMemberId(memberId);
								
							}
							
							else
							{
								HttpSession session=((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
								session.setAttribute("claimGratuityVoData",claimGratuityResponseVo);
								
								claimGratuityUi=new ClaimGratuityPO();
								
								/*claimGratuityUi.setPolicyNumber(claimGratuityResponseVo.getPolicyNumber());
								claimGratuityUi.setTrustieeName(claimGratuityResponseVo.getTrustieeName());
								claimGratuityUi.setFirstTimeUser(firstTime);*/
								claimGratuityUi.setPolicyNumber(userVo.getPolicyNo());
								claimGratuityUi.setTrustieeName(userVo.getClientName());
								claimGratuityUi.setFirstTimeUser(firstTime);
							}
							
								
								
								
							}
						else {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
							throw new IPruException("Error","GRPGTCLMSS01","Something went wrong. Please try again later.");
						}
						
						
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
						throw new IPruException("Error", "GRPBTC", "userVo should not be null");
					}
					
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
					throw new IPruException("Error", "GRPGTCLMSS01", "httpSession should not be null");
				}
				
				String JsonResponse=gsonJSON.toJson(claimGratuityUi);
				
				context.getFlowScope().put("Response",JsonResponse);
				
					

			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPGTCLMSS01", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");

		return success();

	}
	
	
	@MethodPost
	public Event getBizRequestPolicyNumberOnload(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestPolicyNumberOnload";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		String policyNumber=null;
		try {
			if (context != null)
			{
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				
				IPruUser userVO = new IPruUser();
				if (httpSession != null) 
				{
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
				
					if (userVo != null) {
						
						policyNumber=userVo.getPolicyNo();
						
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
						throw new IPruException("Error", "GRPBTC", "userVo should not be null");
					}
					
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
					throw new IPruException("Error", "GRPGTCLMSS01", "httpSession should not be null");
				}
				
				
				
				context.getFlowScope().put("Response",policyNumber);
				
					

			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPGTCLMSS01", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");

		return success();
	}
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub
		
	}



}
