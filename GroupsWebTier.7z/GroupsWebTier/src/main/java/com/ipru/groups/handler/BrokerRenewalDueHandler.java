package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;

import com.ipru.groups.po.BrokerRenewalDueResponsePO;
import com.ipru.groups.po.BrokerTopCustomerResponsePO;

import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.BrokerRenewalDueRequestVO;
import com.ipru.groups.vo.BrokerRenewalDueResponseVO;
import com.ipru.groups.vo.FscDetailsVO;

import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BrokerRenewalDueHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = BrokerRenewalDueHandler.class.getCanonicalName();
	private static final String INFO_LOGGER_NAME = "BrokerRenewalDueLogger";
	private static final String ERROR_LOGGER_NAME = "BrokerRenewalDueLogger";

	@MethodPost
	public Event getBizRequestOnLoadRenewalDue(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestOnLoadRenewalDue";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start");
		Gson gson = new Gson();

		try {
                                                                                                                                                                                                                                   
			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
	/*			String clientName = null;
				String policyNo = null;*/
				String branchCode = null;
				String loginType = null;
				String nationalCode = null;
				String brokerType=null;
				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {
						FscDetailsVO fscDetailVo = userVo.getFscdetails();
						if(fscDetailVo != null){
							branchCode = fscDetailVo.getBranchCode();// Will get from session
							loginType = fscDetailVo.getLogin_type();// Will get from session
							nationalCode = fscDetailVo.getNationalCode(); // Will get from session
							brokerType=fscDetailVo.getFscChannel();
						}
						
						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

						if (request != null) {
							BrokerRenewalDueRequestVO brokerRenewalDueRequestVO = new BrokerRenewalDueRequestVO();
			/*				brokerRenewalDueRequestVO.setPolicyNo(policyNo);
							brokerRenewalDueRequestVO.setClientName(clientName);*/
							brokerRenewalDueRequestVO.setBranchCode(branchCode);
							brokerRenewalDueRequestVO.setLoginType(loginType);
							brokerRenewalDueRequestVO.setNationalCode(nationalCode);
							brokerRenewalDueRequestVO.setBrokerType(brokerType);

							Object[] paramArray = new Object[1];

							if (brokerRenewalDueRequestVO != null) {
								paramArray[0] = brokerRenewalDueRequestVO;
								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);
								context.getFlowScope().put("BrokerRenewalDueBizReqOnLoad", obj_bizReq);
							}

						}
						else {

							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "request should not be null");
							throw new IPruException("Error", "GRPBRD", "request should not be null");
						}
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
						throw new IPruException("Error", "GRPBRD", "userVo should not be null");
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
					throw new IPruException("Error", "GRPBRD", "httpSession should not be null");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Context should not be null");
				throw new IPruException("Error", "GRPBRD", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBRD", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End ");
		return success();
	}

	@MethodPost
	public Event getBizResponseOnLoadRenewalDue(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseOnLoadRenewalDue";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

		// List<FundMasterVO> fundMasterList = null;

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForSubmitRenewalDue");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {

						List<BrokerRenewalDueResponseVO> brokerRenewalDueResponseVOList = (List<BrokerRenewalDueResponseVO>) bizRes.getTransferObjects().get("response1");

						List<BrokerRenewalDueResponsePO> brokerRenewalDueResponsePOList = null;
						if (brokerRenewalDueResponseVOList != null) {
							brokerRenewalDueResponsePOList = new ArrayList<BrokerRenewalDueResponsePO>();

							for (BrokerRenewalDueResponseVO brokerRenewalDueResponseVO : brokerRenewalDueResponseVOList) {

								BrokerRenewalDueResponsePO brokerRenewalDueResponsePO = dozerBeanMapper.map(brokerRenewalDueResponseVO, BrokerRenewalDueResponsePO.class);

								brokerRenewalDueResponsePOList.add(brokerRenewalDueResponsePO);
							}

						}
						String callJsonString = gsonJSON.toJson(brokerRenewalDueResponsePOList);
						FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "callJsonString::" + callJsonString);
						context.getFlowScope().put("Response", callJsonString);
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBRD", context);
		}
		FLogger.info(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");

		return success();

	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
