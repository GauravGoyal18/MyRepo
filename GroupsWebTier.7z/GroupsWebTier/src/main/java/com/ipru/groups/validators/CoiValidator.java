package com.ipru.groups.validators;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;

import com.ipru.groups.po.CoiPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.tcs.logger.FLogger;

public class CoiValidator {

	public String validateCoi(CoiPO coi) throws Exception {

		FLogger.info("COIStatementLogger", "CoiValidator", "validateCoi", "Method start");

		StringBuilder errorMessage = new StringBuilder();
		if (!validatePolicy(coi.getPolicyNumber())) {
			errorMessage.append("Please Enter valid PolicyNumber");
		}
		if (!validateDob(coi.getDob())) {
			errorMessage.append("Please Enter valid Dob");
		}

		if ((coi.getPanNo() == null || coi.getPanNo().equalsIgnoreCase("")) && (coi.getMemLoanAcc() == null || coi.getMemLoanAcc().equalsIgnoreCase(""))) {
			errorMessage.append("Please Enter Atleast one field");

		}
		if (coi.getPanNo() != null && !coi.getPanNo().equalsIgnoreCase("")) {
			if (!validatePan(coi.getPanNo())) {
				errorMessage.append("Please Enter valid Pan Number");
			}
		}
		if (coi.getMemLoanAcc() != null && !coi.getMemLoanAcc().equalsIgnoreCase("") && (!coi.getMemLoanAcc().matches("^([a-zA-Z0-9]([a-zA-Z0-9 ']*))+$"))) {
			if (!validateMemLoanAcc(coi.getMemLoanAcc())) {
				errorMessage.append("Please Enter valid Account Number/Loan Id/Employee Id");
			}
		}

		FLogger.info("COIStatementLogger", "CoiValidator", "validateCoi", "Method end with message" + errorMessage.toString());

		return errorMessage.toString();
	}

	public String validateCoiKnowYourPolicy(CoiPO coi) throws Exception {

		FLogger.info("COIStatementLogger", "CoiValidator", "validateCoiKnowYourPolicy", "Method start");

		StringBuilder errorMessage = new StringBuilder();

		if (!validateCompanyName(coi.getCompanyName())) {
			errorMessage.append("Please Enter Valid Company Name");
		}

		if ((coi.getPanNo() == null || coi.getPanNo().equalsIgnoreCase("")) && (coi.getMemLoanAcc() == null || coi.getMemLoanAcc().equalsIgnoreCase(""))) {
			errorMessage.append("Please Enter Atleast one field");

		}
		if (coi.getPanNo() != null && !coi.getPanNo().equalsIgnoreCase("")) {
			if (!validatePan(coi.getPanNo())) {
				errorMessage.append("Please Enter valid Pan Number");
			}
		}
		if (coi.getMemLoanAcc() != null && !coi.getMemLoanAcc().equalsIgnoreCase("")) {
			if (!validateMemLoanAcc(coi.getMemLoanAcc())) {
				errorMessage.append("Please Enter valid Account Number/Loan Id/Employee Id");
			}
		}

		FLogger.info("COIStatementLogger", "CoiValidator", "validateCoiKnowYourPolicy", "Method end with message" + errorMessage.toString());

		return errorMessage.toString();
	}

	public String validateCoiPanNo(CoiPO coi) {
		StringBuilder errorMessage = new StringBuilder();

		// TODO Auto-generated method stub
		
		if( (coi.getEmailId()==null && (coi.getEmailId()!=null && coi.getEmailId().equalsIgnoreCase(""))) && coi.getMobileNo() == 0)
		{
			errorMessage.append("Please enter atleast one Mobile No OR Email Id");
		}
		
		if((coi.getMobileNo() != 0) && (!validateMobileNo(String.valueOf(coi.getMobileNo())))){
			errorMessage.append("Please Enter valid Mobile Number");
		}
		
		if((coi.getEmailId() != null) && (!validateEmail(coi.getEmailId()))){
			errorMessage.append("Please Enter valid Email Id");
		}
		if (!validatePan(coi.getPanNo())) {
			errorMessage.append("Please Enter valid Pan Number");
		}

		return errorMessage.toString();
	}

	private boolean validatePolicy(String policyNumber) {

		if (CommonValidationUtil.ValidateRequired(policyNumber) && CommonValidationUtil.ValidateNumeric(policyNumber) && CommonValidationUtil.ValidateMaxLength(policyNumber, 10)) {
			return true;

		}
		else {
			return false;
		}
	}

	private boolean validateDob(String dob) throws Exception {
		try {
			SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
			Date date1 = format1.parse(dob);
			Date today = new Date();

			if (date1.before(today)) {
				return true;

			}
			else {
				return false;
			}

		}
		catch (Exception e) {

			FLogger.error("COIStatementLogger", "CoiValidator", "validateCoi", "Some error occured while converting date");
			throw e;

		}

	}

	private boolean validatePan(String pan) {

		if (CommonValidationUtil.ValidatePAN(pan, false) && CommonValidationUtil.ValidateMaxLength(pan, 10)) {
			return true;

		}
		else {
			return false;
		}
	}

	private boolean validateMemLoanAcc(String memLoanAcc) {

		if (CommonValidationUtil.ValidateRequired(memLoanAcc) && CommonValidationUtil.findPattern(memLoanAcc, "^[a-zA-Z0-9]*$") && CommonValidationUtil.ValidateMaxLength(memLoanAcc, 20)) {
			return true;

		}
		else {
			return false;
		}
	}

	private boolean validateCompanyName(String companyName) {

		if (CommonValidationUtil.ValidateRequired(companyName) && CommonValidationUtil.ValidateAddress(companyName) && CommonValidationUtil.ValidateMaxLength(companyName, 200)) {
			return true;

		}
		else {
			return false;
		}
	}
	
	private boolean validateMobileNo(String mobileNo) {		
		if ((CommonValidationUtil.isMatchedPattern(mobileNo, GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP)
				&& StringUtils.isNotBlank(mobileNo)) || mobileNo.equals("-")) {
			return true;
		}
		else {
			return false;
		}
	}
	
	private boolean validateEmail(String emailId) {	
		if ((CommonValidationUtil.isMatchedPattern(emailId, GroupFormValidationConstant.EMAILID_VALIDATION)
				&& StringUtils.isNotBlank(emailId)) || emailId.equals("-")) {
			return true;
		}
		else {
			return false;
		}
	}

}
