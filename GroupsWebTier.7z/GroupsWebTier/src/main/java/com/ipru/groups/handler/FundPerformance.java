package com.ipru.groups.handler;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.ipru.groups.po.FundPerformancePO;
import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.groups.utilities.GroupsJsonUtils;
import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.ProductDetailsVO;
import com.ipru.groups.vo.ProductFundMasterVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class FundPerformance extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Event getBizRequestForfundPerformanceProdCode(RequestContext p_ObjContext) throws Exception {
		try {
			FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizRequestForfundPerformanceProdCode", "Method start");			

			// Declare Variables
			String policyNo = null;
			HttpSession httpSession = null;
			IPruUser userVO = null;

			// Fetch client Id, policy Number and role
			httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
			if (httpSession != null) {
				userVO = (IPruUser) httpSession.getAttribute("userVO");
				if (userVO != null) {
					policyNo = userVO.getPolicyNo();
				}
			}

			Object[] paramArray = new Object[1];
			paramArray[0] = policyNo;

			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			p_ObjContext.getFlowScope().put("fetchProductDetailsFromPolicy", obj_bizReq);

		}
		catch (Exception e) {
			FLogger.error("FundPerformanceLogger", "FundPerformance", "getBizRequestForfundPerformanceProdCode", "Exception Occurred ", e);
			throwINeoFlowException(e, "GRSW07", p_ObjContext);
		}
		FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizRequestForfundPerformanceProdCode", "Method End");
		return success();
	}

	@MethodPost
	public Event getBizRequestForfundPerformance(RequestContext p_ObjContext) throws Exception {
		try {		
			FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizRequestForfundPerformance", "Method Start");
			BizResponse response = new BizResponse();
			response = (BizResponse) p_ObjContext.getFlowScope().get("bizres");
			if (response.getStatusVO() != null) {
				if (isERROR(response.getStatusVO().getStatus())) {
					FLogger.error("FundPerformanceLogger", "FundPerformance", "getBizRequestForfundPerformance", "Exception Occurred from service ");
					throwINeoFlowException(response.getStatusVO(), p_ObjContext);
				}
			}
			ProductDetailsVO productCode = (ProductDetailsVO) response.getTransferObjects().get("response1");

			// Loading fund data from context
			List<FundMasterVO> fundMasterList = (List<FundMasterVO>) p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.FUND_MASTER_LIST);
			List<ProductFundMasterVO> productFundMasterList = (List<ProductFundMasterVO>) p_ObjContext.getExternalContext().getApplicationMap().get(ContextKeyConstants.PRODUCT_FUND_MASTER_LIST);
			// Iteration for Fund code
			List<String> fundCodes = new ArrayList<String>();
			for (ProductFundMasterVO prodGetCode : productFundMasterList) {
				if (prodGetCode.getProductCode().toString().equals(productCode.getProductcode())) {
					fundCodes.add(prodGetCode.getFundCode().toString());
				}
			}

			// Iteration for Active funds
			List<String> activeFundList = new ArrayList<String>();
			for (FundMasterVO activeFund : fundMasterList) {
				if (activeFund.getIsActive().equals("Y") && fundCodes.contains(activeFund.getFundCode())) {
					activeFundList.add(activeFund.getFundCode());
				}
			}
			Object[] paramArray = new Object[1];
			paramArray[0] = activeFundList;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("saveBizReq", obj_bizReq);
			return success();
		}
		catch (Exception e) {
			FLogger.error("FundPerformanceLogger", "FundPerformance", "getBizRequestForfundPerformance", "Exception Occurred ", e);
			throwINeoFlowException(e, "GRYY01", p_ObjContext);
		}
		FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizRequestForfundPerformance", "Method Ends");
		return success();
	}

	@MethodPost
	public Event getBizRequestForfundPerformancechart(RequestContext p_ObjContext) throws Exception {
		try {
			
			FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizRequestForfundPerformancechart", "Method Start");
			HttpServletRequest request = (HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest();

			// Convert json to object
			JsonObject fundcodejson = (JsonObject)GroupsJsonUtils.getInstance().getSingletonParser().parse(request.getReader());
//			JSONObject fundcodejson = gsonJSON.fromJson(request.getReader(), JSONObject.class);
			String fundcode = (String) fundcodejson.get("fundcodeData").getAsString();
			Object[] paramArray = new Object[1];
			paramArray[0] = fundcode;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			p_ObjContext.getFlowScope().put("saveBizReq", obj_bizReq);

		}
		catch (Exception e) {
			FLogger.error("FundPerformanceLogger", "FundPerformance", "getBizRequestForfundPerformancechart", "Exception Occurred ", e);
			throwINeoFlowException(e, "GRYY01", p_ObjContext);
		}
		FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizRequestForfundPerformancechart", "Method End");
		return success();
	}

	@SuppressWarnings("unchecked")
	public Event getBizResponseFundPerformance(RequestContext p_ObjContext) throws Exception {
		FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizResponseFundPerformance", "Method Start");
		
		try {
			BizResponse response = new BizResponse();
			response = (BizResponse) p_ObjContext.getFlowScope().get("bizres");
			if (response.getStatusVO() != null) {
				if (isERROR(response.getStatusVO().getStatus())) {
					FLogger.error("FundPerformanceLogger", "FundPerformance", "getBizResponseFundPerformance", "Exception Occurred from service ");
					throwINeoFlowException(response.getStatusVO(), p_ObjContext);
				}

				String fundPerformanceJsonStr = (String) response.getTransferObjects().get("response1");
				if (fundPerformanceJsonStr != null) {

					p_ObjContext.getFlowScope().put("Response", fundPerformanceJsonStr);
				}
				else {					
					throwINeoFlowException(new Exception(), "GRPFP02", p_ObjContext);
				}
			}
		}
		catch (Exception e) {
			FLogger.error("FundPerformanceLogger", "FundPerformance", "getBizResponseFundPerformance", "Exception Occurred ", e);
			throwINeoFlowException(e, "GRPFP02", p_ObjContext);
		}
		FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizResponseFundPerformance", "Method End");
		return success();

	}

	public Event getBizResponseFundPerformanceChart(RequestContext p_ObjContext) throws ParseException, Exception {
		FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizResponseFundPerformanceChart", "Method Start");
		
		try {
			BizResponse response = new BizResponse();

			response = (BizResponse) p_ObjContext.getFlowScope().get("bizres");
			if (response.getStatusVO() != null) {
				if (isERROR(response.getStatusVO().getStatus())) {
					FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizResponseFundPerformanceChart", "Exception Occurred from service ");

					throwINeoFlowException(response.getStatusVO(), p_ObjContext);
				}
				String fundPerformanceJsonStr = (String) response.getTransferObjects().get("response1");
				if (fundPerformanceJsonStr != null) {
//					JSONObject json = (JSONObject) JSONSerializer.toJSON(fundPerformanceJsonStr);
					JsonObject json = GroupsJsonUtils.getInstance().getJsonObject(fundPerformanceJsonStr);
//					JSONArray jsonArray = (JSONArray) json.get("fundNavGraph");
					JsonArray jsonArray = GroupsJsonUtils.getInstance().getJsonArray("fundNavGraph", json);
//					JSONArray jsonArrayForBenchMark = (JSONArray) json.get("benchMarkGraph");
					JsonArray jsonArrayForBenchMark = GroupsJsonUtils.getInstance().getJsonArray("benchMarkGraph", json);
//					JSONArray jsonArrayForBenchMarkSNIF = (JSONArray) json.get("fundSummary");
					JsonArray jsonArrayForBenchMarkSNIF = GroupsJsonUtils.getInstance().getJsonArray("fundSummary", json);
//					Gson obj = new Gson();
					List<String> xlist = new ArrayList<String>(1);
					List<Double> ylist = new ArrayList<Double>(1);
					List<Double> yylist = new ArrayList<Double>(1);
					String benchMarkSNIF = null;

					for (int i = 0; i < jsonArray.size(); i++) {
//						JSONObject rec = (JSONObject) JSONSerializer.toJSON(jsonArray.get(i));
						JsonObject rec = (JsonObject)jsonArray.get(i);
						xlist.add((rec.get("x").getAsString()));
						ylist.add(Double.parseDouble(rec.get("y").getAsString()));
					}
					for (int i = 0; i < jsonArrayForBenchMark.size(); i++) {
//						JSONObject rec = (JSONObject) JSONSerializer.toJSON(jsonArrayForBenchMark.get(i));
						JsonObject rec = (JsonObject)jsonArrayForBenchMark.get(i);
						xlist.add((rec.get("x").getAsString()));
//						yylist.add(Double.parseDouble((String) rec.get("y")));
					}

					for (int i = 0; i < jsonArrayForBenchMarkSNIF.size(); i++) {
//						JSONObject rec = (JSONObject) JSONSerializer.toJSON(jsonArrayForBenchMarkSNIF.get(i));
						JsonObject rec = (JsonObject)jsonArrayForBenchMarkSNIF.get(i);
						if (rec.get("Fund").toString().equals("Benchmark Return")) {
							benchMarkSNIF = rec.get("SFIN").toString();
							break;
						}
					}

					FundPerformancePO fpPo = new FundPerformancePO();
					fpPo.setX(xlist);
					fpPo.setY(ylist);
					fpPo.setYy(yylist);
					fpPo.setBenchMarkSNIF(benchMarkSNIF);

					p_ObjContext.getFlowScope().put("Response", gsonJSON.toJson(fpPo));
				}
				else {
					

					throwINeoFlowException(new Exception(), "GRPFP03", p_ObjContext);
				}
			}
		}
		catch (Exception e) {
			FLogger.error("FundPerformanceLogger", "FundPerformance", "getBizResponseFundPerformanceChart", "Exception Occurred", e);
			throwINeoFlowException(e, "GRPFP03", p_ObjContext);
		}
		FLogger.info("FundPerformanceLogger", "FundPerformance", "getBizResponseFundPerformanceChart", "Method End");
		return success();

	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
