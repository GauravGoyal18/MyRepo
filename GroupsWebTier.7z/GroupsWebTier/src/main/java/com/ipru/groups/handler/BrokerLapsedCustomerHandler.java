package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import com.google.gson.Gson;
import com.ipru.IPruException;

import com.ipru.groups.po.BrokerLapsedCustomerResponsePO;
import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.groups.utilities.TrackerUtil;

import com.ipru.groups.vo.BrokerLapsedCustomeResponseVO;
import com.ipru.groups.vo.BrokerLapsedCustomerRequestVO;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.groups.vo.FundMasterVO;

import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BrokerLapsedCustomerHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final String CLASS_NAME = BrokerLapsedCustomerHandler.class.getCanonicalName();
	private static final String INFO_LOGGER_NAME = "LapsedCustomerBaseBeanLogger";
	private static final String ERROR_LOGGER_NAME = "LapsedCustomerBaseBeanLogger";

	@MethodPost
	public Event getBizRequestLapsedCustomerBaseBean(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestLapsedCustomerBaseBean";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, " Method Start");
		Gson gson = new Gson();
		 
		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
				String nationalCode = null;
				String branchCode = null;
				String loginType = null;
				String brokerType=null;

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						FscDetailsVO fscDetailVo = userVo.getFscdetails();
						if(fscDetailVo != null){
							branchCode = fscDetailVo.getBranchCode();// Will get from session
							loginType = fscDetailVo.getLogin_type();// Will get from session
							nationalCode = fscDetailVo.getNationalCode(); // Will get from session
							brokerType=fscDetailVo.getFscChannel();
						}						
						
						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

						if (request != null) {
							BrokerLapsedCustomerRequestVO brokerLapsedCustomerRequestVO = new BrokerLapsedCustomerRequestVO();
							brokerLapsedCustomerRequestVO.setNationalCode(nationalCode);
							brokerLapsedCustomerRequestVO.setBranchCode(branchCode);
							brokerLapsedCustomerRequestVO.setLoginType(loginType);
							brokerLapsedCustomerRequestVO.setBrokerType(brokerType);

							Object[] paramArray = new Object[1];

							if (brokerLapsedCustomerRequestVO != null) {
								paramArray[0] = brokerLapsedCustomerRequestVO;
								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);
								context.getFlowScope().put("BizRequestLapsedCustomerOnLoad", obj_bizReq);
							}
						}
						else {

							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "request should not be null");
							throw new IPruException("Error", "GRPLC", "request should not be null");
						}
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
						throw new IPruException("Error", "GRPLC", "userVo should not be null");
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
					throw new IPruException("Error", "GRPLC", "httpSession should not be null");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Context should not be null");
				throw new IPruException("Error", "GRPLC", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPLC", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "onEntry of getBizRequestLapsedCustomerBaseBean Method End ");
		return success();
	}

	@MethodPost
	public Event getBizResponseLapsedCustomer(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestLapsedCustomerBaseBean";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

		
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		
		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForLapsedCustomerRequestOnLoad");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {

						List<BrokerLapsedCustomeResponseVO> brokerLapsedCustomeResponseVOList = (List<BrokerLapsedCustomeResponseVO>) bizRes.getTransferObjects().get("response1");

						List<BrokerLapsedCustomerResponsePO> brokerLapsedCustomeResponsePOList = null;
						if (brokerLapsedCustomeResponseVOList != null) {
							brokerLapsedCustomeResponsePOList = new ArrayList<BrokerLapsedCustomerResponsePO>();

							for (BrokerLapsedCustomeResponseVO brokerLapsedCustomeResponseVO : brokerLapsedCustomeResponseVOList) {

								BrokerLapsedCustomerResponsePO brokerLapsedCustomerResponsePO = dozerBeanMapper.map(brokerLapsedCustomeResponseVO, BrokerLapsedCustomerResponsePO.class);

								brokerLapsedCustomeResponsePOList.add(brokerLapsedCustomerResponsePO);
							}

						}
						String callJsonString = gsonJSON.toJson(brokerLapsedCustomeResponsePOList);
						FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "callJsonString::" + callJsonString);
						context.getFlowScope().put("Response", callJsonString);
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPLC", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");

		return success();

	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}
}
