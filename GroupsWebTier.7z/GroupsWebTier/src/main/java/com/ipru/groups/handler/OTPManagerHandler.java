package com.ipru.groups.handler;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javacryption.aes.AesCtr;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.utilities.SessionKeyConstants;
import com.ipru.groups.vo.OTPMasterBean;
import com.ipru.groups.vo.OTPNumberAuditTrailBean;
import com.ipru.groups.vo.OTPNumberBean;
import com.ipru.groups.vo.OTPNumberFunctionality;
import com.ipru.otp.po.OTPNumberParamBean;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.businessdelegation.StatusVO;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class OTPManagerHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Properties otpProperties = new Properties();
	private static final String CLASS_NAME = OTPManagerHandler.class.getName();

	public OTPManagerHandler() {
		FileInputStream fis = null;
		if (MasterPropertiesFileLoader.CONSTANT_OTP_MANAGER_PROPERTIES != null) {
			otpProperties = MasterPropertiesFileLoader.CONSTANT_OTP_MANAGER_PROPERTIES;
		}
		else {
			try { 
				fis = new FileInputStream(GroupConstants.CONSTANT_OTP_MANAGER_MAPPING);
				otpProperties.load(fis);
			}
			catch (FileNotFoundException e) {
				FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, e.getMessage(), e);
			}
			catch (IOException e) {
				FLogger.error("OTPError", CLASS_NAME, CLASS_NAME, e.getMessage(), e);
			}
			finally
			{
				try {
					if(fis!=null)
						fis.close();
				}
				catch (Exception e) {
					FLogger.error("GROUPLoggerError", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
							"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
					e.printStackTrace();
				} finally {
					fis=null;
				}
			
			}
		}
	}

	public Event isAuthorized(RequestContext context) {
		FLogger.info("OTPLogger", CLASS_NAME, "isAuthorized", "method start");
		try {
			String pasaFlag = (String) GroupSecurityUtil.getAttributeFromSession(context, "csr_pasaFlag");
			Map<String, String> map_result = new HashMap<String, String>();
			String isAuthentcnReqd = "TRUE";
			boolean isAuthenticationRequired = false;
			Gson gson = new Gson();
			// String ex = req.getQueryString();
			// String key=req.getParameter("execution");

			// String otpType = (String) ((HttpServletRequest)
			// context.getExternalContext().getNativeRequest()).getParameter("otpType");
			String otpType = (String) context.getFlowScope().get("otpType");
			if (StringUtils.isNotBlank(otpType) && StringUtils.equalsIgnoreCase(otpProperties.getProperty("TRANSACTIONAL_OTP"), otpType)) {
				pasaFlag = "true";
			}

			isAuthenticationRequired = GroupSecurityUtil.isAuthenticationRequired(context);
			if (isAuthenticationRequired) {
				if (StringUtils.equalsIgnoreCase(pasaFlag, "false")) {
					// is redundant condition
					isAuthentcnReqd = "FALSE";
				}
				else {
					if (!StringUtils.equalsIgnoreCase("validOtp", pasaFlag)) {
						isAuthentcnReqd = "TRUE";
					}
					else {
						isAuthentcnReqd = "FALSE";
					}
				}
			}
			else {
				isAuthentcnReqd = "FALSE";
			}

			map_result.put("isAuthentcnReqd", isAuthentcnReqd);
			String resultJson = gson.toJson(map_result);
			context.getFlowScope().put("searchResultJson", resultJson);
			context.getFlowScope().put("isAuthentcnReqd", isAuthentcnReqd);
		}
		catch (Exception e) {
			FLogger.error("OTPError", CLASS_NAME, "isAuthorized", e.getMessage(), e);
		}
		FLogger.info("OTPLogger", CLASS_NAME, "isAuthorized", "method end");
		return success();
	}

	@MethodPost
	public Event getBizRequestForGenerateOTP(RequestContext context) throws Exception {
		FLogger.info("OTPLogger", CLASS_NAME, "getBizRequestForGenerateOTP", "method start");

		try {
			OTPNumberParamBean paramBean = (OTPNumberParamBean) GroupSecurityUtil.getAttributeFromSession(context, "otpParamBean");
			if (paramBean != null) {
				context.getFlowScope().put("otpParamBean", paramBean);
//				GroupSecurityUtil.removeAttributeInSession(context, "otpParamBean");
			}

			String personalEmailId = null;  // Get from request
			paramBean.setPersonalEmailId(personalEmailId);

			OTPMasterBean masterBean = this.generateBean(paramBean);
			BizRequest bizReq = new BizRequest();
			Object[] obj = { masterBean };
			bizReq.addbusinessObjects("service-obj1", obj);
			context.getFlowScope().put("bizreq", bizReq);

		}
		catch (Exception e) {
			FLogger.error("OTPError", CLASS_NAME, "getBizRequestForGenerateOTP", e.getMessage(), e);
			throwINeoFlowException(e, "GRYY01", context);
		}
		FLogger.info("OTPLogger", CLASS_NAME, "getBizRequestForGenerateOTP", "method end");

		return success();
	}

	@MethodPost
	public Event getBizResponseForGenerateOTP(RequestContext context) throws Exception {
		FLogger.info("OTPLogger", CLASS_NAME, "getBizResponseForGenerateOTP", "method start");
		try {
			OTPNumberParamBean paramBean = (OTPNumberParamBean) context.getFlowScope().get("otpParamBean");
			BizResponse bizRes = (BizResponse) context.getFlowScope().get("bizres");
			boolean isGenerated = (Boolean) bizRes.getTransferObjects().get("response1");
			Map<String, String> mapForOTP = new HashMap<String, String>();
			mapForOTP.put("msg", this.getMsgForGenerateOTP(paramBean, isGenerated));
			// mapForOTP.put("csrf",
			// CsrfImplementation.genrateCsrfToken(context));
			Gson gson = new Gson();
			String otpMapJson = gson.toJson(mapForOTP);
			context.getFlowScope().put("Response", otpMapJson);
			// context.getFlowScope().put("reportDetailsJson", otpMapJson);
		}
		catch (Exception e) {
			FLogger.error("OTPError", CLASS_NAME, "getBizRequestForGenerateOTP", e.getMessage(), e);
			throwINeoFlowException(e, "GRYY02", context);
		}
		FLogger.info("OTPLogger", CLASS_NAME, "getBizResponseForGenerateOTP", "method end");
		return success();
	}

	private String getMsgForGenerateOTP(OTPNumberParamBean paramBean, boolean isGenerated) throws Exception {
		StringBuffer generateOTPMsg = new StringBuffer("");
		FLogger.info("OTPLogger", CLASS_NAME, "getMsgForGenerateOTP", "isOTPGenerated : " + isGenerated);
		try {
			if (isGenerated) {
				if (StringUtils.isNotBlank(paramBean.getFunctionality()) && paramBean.getFunctionality().equalsIgnoreCase("AgentForgotPassword")) {
					generateOTPMsg.append(otpProperties.getProperty("GENERATE_OTP_SUCCESS_AGENT"));
				}
				else {
					generateOTPMsg.append(otpProperties.getProperty("GENERATE_OTP_SUCCESS"));
				}
				// generateOTPMsg.append(otpProperties.getProperty("GENERATE_OTP_SUCCESS"));
				FLogger.info("OTPLogger", CLASS_NAME, "getMsgForGenerateOTP", "Email1 : " + paramBean.getEmail1());
				FLogger.info("OTPLogger", CLASS_NAME, "getMsgForGenerateOTP", "Email2 : " + paramBean.getEmail2());
				FLogger.info("OTPLogger", CLASS_NAME, "getMsgForGenerateOTP", "Mobile : " + paramBean.getMobile());
				if (paramBean.isEmail1Valid() || paramBean.isEmail2Valid()) {
					generateOTPMsg.append(otpProperties.getProperty("GENERATE_OTP_EMAIL"));
					if (paramBean.isEmail1Valid() && paramBean.isEmail2Valid()) {
						generateOTPMsg.append("xxxxxx" + paramBean.getEmail1().substring(paramBean.getEmail1().indexOf('@')));
						generateOTPMsg.append(",");
						generateOTPMsg.append("xxxxxx" + paramBean.getEmail2().substring(paramBean.getEmail2().indexOf('@')));
					}
					else if (paramBean.isEmail1Valid() && !paramBean.isEmail2Valid())
						generateOTPMsg.append("xxxxxx" + paramBean.getEmail1().substring(paramBean.getEmail1().indexOf('@')));
					else if (paramBean.isEmail2Valid() && !paramBean.isEmail1Valid())
						generateOTPMsg.append("xxxxxx" + paramBean.getEmail2().substring(paramBean.getEmail2().indexOf('@')));
				}
				if ((paramBean.isEmail1Valid() || paramBean.isEmail2Valid()) && paramBean.isMobileValid())
					generateOTPMsg.append(" and ");
				if (paramBean.isMobileValid()) {
					generateOTPMsg.append(otpProperties.getProperty("GENERATE_OTP_MOBILE"));
					generateOTPMsg.append("xxxxxx" + paramBean.getMobile().substring(5));
				}
			}
			else
				generateOTPMsg.append(otpProperties.getProperty("GENERATE_OTP_FAILURE"));
		}
		catch (Exception e) {
			FLogger.error("OTPError", CLASS_NAME, "getMsgForGenerateOTP", e.getMessage(), e);
			throw new Exception(e);
		}
		FLogger.info("OTPLogger", CLASS_NAME, "getMsgForGenerateOTP", "Method Ends");
		return generateOTPMsg.toString();
	}

	private OTPMasterBean generateBean(OTPNumberParamBean paramBean) {
		FLogger.info("OTPLogger", CLASS_NAME, "generateBean", "method start");
		OTPMasterBean masterBean = new OTPMasterBean();
		OTPNumberBean otpBean = new OTPNumberBean();
		OTPNumberFunctionality otpFunc = new OTPNumberFunctionality();
		FLogger.info("OTPLogger", CLASS_NAME, "generateBean", "Advisor Code : " + paramBean.getAdvisorCode());
		otpBean.setAdvisorCode(paramBean.getAdvisorCode());
		FLogger.info("OTPLogger", CLASS_NAME, "generateBean", "Advisor Name : " + paramBean.getAdvisorName());
		otpBean.setAdvisorName(paramBean.getAdvisorName());
		FLogger.info("OTPLogger", CLASS_NAME, "generateBean", "custID : " + paramBean.getCustId());
		otpBean.setCustId(paramBean.getCustId());
		FLogger.info("OTPLogger", CLASS_NAME, "generateBean", "Email1 : " + paramBean.getEmail1());
		otpBean.setEmail1(paramBean.getEmail1());
		FLogger.info("OTPLogger", CLASS_NAME, "generateBean", "Email2 : " + paramBean.getEmail2());
		otpBean.setEmail2(paramBean.getEmail2());
		FLogger.info("OTPLogger", CLASS_NAME, "generateBean", "Mobile : " + paramBean.getMobile());
		otpBean.setPersonalEmail(paramBean.getEmail1());
		otpBean.setMobile(paramBean.getMobile());
		otpBean.setCustomerName(paramBean.getCustFirstName());
		// otpBean.setLastName(paramBean.getCustLastName());
		otpBean.setLoginRole(paramBean.getLoginRole());
		otpFunc.setFunctionality(StringUtils.isNotEmpty(paramBean.getFunctionality()) ? paramBean.getFunctionality() : otpProperties.getProperty("GENERIC_FUNCTIONALITY_PASA"));
		// Adding Policy No by Sudha Suman
		FLogger.info("OTPLogger", CLASS_NAME, "generateBean", "Policy No : " + paramBean.getIdentifierCode());
		otpFunc.setIdentifierCode(paramBean.getIdentifierCode());
		otpFunc.setIdentifierType(paramBean.getIdentifierType());
		otpFunc.setPolicyNo(paramBean.getPolicyNo());
		OTPNumberAuditTrailBean auditBean = new OTPNumberAuditTrailBean();
		auditBean.setOtpEnteredDate(new Timestamp(System.currentTimeMillis()));
		auditBean.setOtpNumberEntered(paramBean.getOtpNumber());
		auditBean.setSourceFunctionality(paramBean.getFunctionality());
		masterBean.setOtpBean(otpBean);
		masterBean.setAuditBean(auditBean);
		masterBean.setOtpFunc(otpFunc);
		FLogger.info("OTPLogger", CLASS_NAME, "generateBean", "method end");
		return masterBean;
	}

	@MethodPost
	public Event getBizRequestForValidateOTP(RequestContext context) throws Exception {
		FLogger.info("OTPLogger", CLASS_NAME, "getBizRequestForValidateOTP", "method start");
		try {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession != null) {	
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			if (request != null) {
				OTPNumberParamBean paramBeanFromScreen = gsonJSON.fromJson(request.getReader(), OTPNumberParamBean.class);
				String encProperty1 = paramBeanFromScreen.getOtpNumber();
				
				if (encProperty1 == null) {
					FLogger.error("OTPError", CLASS_NAME,"getBizRequestForValidateOTP", "otp Number from request should not be null");
					throw new IPruException("Error", "GRPRP01", "Something went wrong. Please try again later.");
				}
				String key1 = (String) httpSession.getAttribute("jCryptionKey");
				encProperty1 = encProperty1.replaceAll(" ", "+");
				String decProperty1 = AesCtr.decrypt(encProperty1, key1, 256);
				paramBeanFromScreen.setOtpNumber(decProperty1);
	
				this.isOTPRequestValidated(paramBeanFromScreen);
				OTPNumberParamBean paramBean = (OTPNumberParamBean) context.getFlowScope().get("otpParamBean");
				// CsrfImplementation.checkCsrfTokens(context,
				// paramBeanFromScreen.getCsrfToken());
				paramBean.setOtpNumber(paramBeanFromScreen.getOtpNumber());
				OTPMasterBean masterBean = this.generateBean(paramBean);
				BizRequest bizReq = new BizRequest();
				Object[] obj = { masterBean };
				bizReq.addbusinessObjects("service-obj1", obj);
				context.getFlowScope().put("bizreq", bizReq);
				}
			}
			else {
				FLogger.error("OTPError", CLASS_NAME, "getBizRequestForValidateOTP", "Session should not be null");
				throw new IPruException("Error", "GRPRP01", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			FLogger.error("OTPError", CLASS_NAME, "getMsgForGenerateOTP", e.getMessage(), e);
			throwINeoFlowException(e, "GRPCOI01", context);
		}
		/*
		 * catch (Exception e) { FLogger.error("CSR.OTP", CLASS_NAME,
		 * "getMsgForGenerateOTP", e.getMessage(),e); }
		 */
		FLogger.info("OTPLogger", CLASS_NAME, "getBizRequestForValidateOTP", "method end");
		return success();
	}

	private boolean isOTPRequestValidated(OTPNumberParamBean paramBean) throws Exception {
		boolean isOTPRequestValidated = Boolean.TRUE;
		FLogger.info("OTPLogger", CLASS_NAME, "isOTPRequestValidated", "method start");
		if (paramBean.getOtpNumber() == null || paramBean.getOtpNumber().length() != Integer.parseInt(otpProperties.getProperty("OTP_LENGTH"))) {
			isOTPRequestValidated = Boolean.FALSE;
			FLogger.info("OTPLogger", CLASS_NAME, "isOTPRequestValidated", "Invalid OTP : " + paramBean.getOtpNumber());
			throw new IPruException("Error", "GRPCOI01", "Confirmation Code Does not match with our record");
		}
		FLogger.info("OTPLogger", CLASS_NAME, "isOTPRequestValidated", "method end");
		return isOTPRequestValidated;
	}

	@MethodPost
	public Event getBizResponseForValidateOTP(RequestContext context) throws Exception {
		FLogger.info("OTPLogger", CLASS_NAME, "getBizResponseForValidateOTP", "method start");

		try {
			BizResponse bizRes = (BizResponse) context.getFlowScope().get("bizres");

			StatusVO vo = bizRes.getStatusVO();
			if (!StringUtils.equalsIgnoreCase(vo.getStatus(), "error")) {
				@SuppressWarnings("unchecked")
				Map<String, String> responseParams = (Map<String, String>) bizRes.getTransferObjects().get("response1");
				String otpVerfcnStatus = (String) responseParams.get("VERFCN_STATUS");
				GroupSecurityUtil.setAttributeInSession(context, SessionKeyConstants.CSR_OTP_VERFCN_STATUS, otpVerfcnStatus);
				// responseParams.put("VERFCN_STATUS", encryptedOtpStatus);
				responseParams.put("VERFCN_STATUS", otpVerfcnStatus);
				if (Boolean.parseBoolean(otpVerfcnStatus)) {

					if (getTransactionalOTPCallback() != null) {
						// Map<String, String> map = new HashMap<String,
						// String>(1);
						responseParams.put("transactionalOTPCallback", String.valueOf(getTransactionalOTPCallback()));
						// context.getFlowScope().put("searchResultJson", new
						// Gson().toJson(map));
						GroupSecurityUtil.setAttributeInSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED, Boolean.TRUE);
						// context.getFlowScope().put(SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED,
						// true);
						setTransactionalOTPCallback(null);

					}
					else {
						GroupSecurityUtil.setAttributeInSession(context, "csr_pasaFlag", "validOtp");
					}
				}
				else {
					FLogger.info("OTPLogger", CLASS_NAME, "getBizResponseForValidateOTP", "Invalid OTP ");
					throwINeoFlowException(new ServiceException(responseParams.get("STATUS_MSG")), context);

					/*
					 * FLogger.error("securityerror", "CsrHandler",
					 * "getBizReqForOtpVerification",
					 * "Security Exception::Forgery for OTP::UserDetails::" +
					 * ToStringBuilder.reflectionToString((IPruUser)
					 * CsrSecurityUtil.getAttributeFromSession(context,
					 * SessionKeyConstants.USER_SESSION_KEY))); throw new
					 * CsrSecurityException("Request forgery for OTP");
					 */
				}
				// responseParams.put("csrf",csrfToken);
				FLogger.info("OTPLogger", CLASS_NAME, "getBizResponseForValidateOTP", "validate OTP responseParams : " + responseParams);
				Gson gson = new Gson();
				String responseJson = gson.toJson(responseParams);
				context.getFlowScope().put("Response", responseJson);
				FLogger.info("OTPLogger", CLASS_NAME, "getBizResponseForValidateOTP", "method end");
			}
			else {
				throwINeoFlowException(new ServiceException("CSGTCC06"), context);
			}
		}
		catch (Exception e) {
			FLogger.error("OTPError", CLASS_NAME, "getBizResponseForValidateOTP", e.getMessage(), e);
			throwINeoFlowException(e, context);
		}
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
