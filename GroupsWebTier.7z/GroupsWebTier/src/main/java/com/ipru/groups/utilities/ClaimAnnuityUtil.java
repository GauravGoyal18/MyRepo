package com.ipru.groups.utilities;

import java.util.ArrayList;
import java.util.List;

import com.ipru.groups.po.ClaimAnnuityDropDownPO;
import com.tcs.logger.FLogger;

public class ClaimAnnuityUtil {

	
	public ClaimAnnuityDropDownPO dropDownList(){
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityUtil", "ClaimAnnuityDropDownPO", "Method Start");
		
		List salutationList=new ArrayList();
		salutationList.add("Capt");
		salutationList.add("Dr");
		salutationList.add("Mr");
		salutationList.add("Mrs");
		salutationList.add("Ms");		
		
		List penPayList=new ArrayList();
		penPayList.add("Monthly");
		penPayList.add("Quartely");
		penPayList.add("HalfYearly");
		penPayList.add("Yearly");
		
		List paymentModeList=new ArrayList();
		paymentModeList.add("ECS");
		
		
		List maritalStatusList=new ArrayList();
		maritalStatusList.add("Married");
		maritalStatusList.add("Single");
		maritalStatusList.add("Widow");
		maritalStatusList.add("Widower");
		
		List genderList=new ArrayList();
		genderList.add("male");
		genderList.add("female");
		
		
		ClaimAnnuityDropDownPO claimAnnuityDropDownPO=new ClaimAnnuityDropDownPO();
		claimAnnuityDropDownPO.setMaritalStatusList(maritalStatusList);
		claimAnnuityDropDownPO.setPaymentModeList(paymentModeList);
		claimAnnuityDropDownPO.setPenPayList(penPayList);
		claimAnnuityDropDownPO.setSalutationList(salutationList);
		claimAnnuityDropDownPO.setGenderList(genderList);
		
		FLogger.info("ClaimAnnuityLogger", "ClaimAnnuityUtil", "ClaimAnnuityDropDownPO", "Method End");
		return claimAnnuityDropDownPO;
	}
}
