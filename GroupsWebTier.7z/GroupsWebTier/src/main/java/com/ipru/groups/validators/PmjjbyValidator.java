package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;

import com.ipru.IPruException;
import com.ipru.groups.po.PmjjbyPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.tcs.logger.FLogger;

public class PmjjbyValidator {

	public String validateData(PmjjbyPO pmjjbyPO) throws IPruException, ParseException {
		FLogger.info("PmjjbyLogger", "PmjjbyValidator", "validateData", "method start");
		
		
		if (!validateNumericField(pmjjbyPO.getBankAccNo(), 20)) {
			FLogger.error("PmjjbyLogger", "PmjjbyValidator", "validateData", "Exception Occured, Invalid Bank Account Number ");
			throw new IPruException("Error", "GRPPFCC", "Invalid Bank Account Number");
		}
		
		if(StringUtils.isNotBlank(pmjjbyPO.getDobOfAssured())){			
			if (!validateDob(pmjjbyPO.getDobOfAssured())) {
				FLogger.error("PmjjbyLogger", "PmjjbyValidator", "validateData", "Exception Occured, Invalid Date of birth ");
				throw new IPruException("Error", "GRPPFCC", "Invalid Date of birth");
			}
		}else if(StringUtils.isNotBlank(pmjjbyPO.getNominee())){	
			if (!validateAlpField(pmjjbyPO.getNominee(), 100) ) {
				FLogger.error("PmjjbyLogger", "PmjjbyValidator", "validateData", "Exception Occured, Invalid Nominee Name ");
				throw new IPruException("Error", "GRPPFCC", "Invalid Nominee Name");
			}	
		}else{
			FLogger.error("PmjjbyLogger", "PmjjbyValidator", "validateData", "Exception Occured, Nominee Name and Dob should not be null");
			throw new IPruException("Error", "GRPPFCC", "Please Enter valid Nominee or Date of birth ");
		}
		
		
		
		
		FLogger.info("PmjjbyLogger", "PmjjbyValidator", "validateData", "method start");
		return null;
	}

	private boolean validateNumericField(String val, Integer num) {

		if (CommonValidationUtil.ValidateNumeric(val) && CommonValidationUtil.ValidateMaxLength(val, num)) {
			return true;

		}
		else {
			return false;
		}

	}
	
	private boolean validateAlpField(String val, Integer num) {

		if (StringUtils.isAlphaSpace(val) && CommonValidationUtil.ValidateMaxLength(val, num)) {
			return true;

		}
		else {
			return false;
		}

	}
	
	private boolean validateDob(String dob) throws ParseException {
		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);

		Date date1 = format1.parse(dob);

		Date today = new Date();

		if (date1.before(today)) {

			if (CommonValidationUtil.ValidateRequired(dob)) {

				return true;
			}
			else {

				return false;
			}
		}
		else {
			return false;
		}
	}

}
