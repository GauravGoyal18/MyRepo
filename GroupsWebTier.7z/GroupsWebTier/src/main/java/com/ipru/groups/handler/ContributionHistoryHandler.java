package com.ipru.groups.handler;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.ContributionHistoryRequestPO;
import com.ipru.groups.po.ContributionHistoryResponsePO;
import com.ipru.groups.vo.ContributionHistoryRequestVO;
import com.ipru.groups.vo.ContributionHistoryResponseVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ContributionHistoryHandler extends IneoBaseHandler {

	String ErrorMsg = "SomeThing went wrong please try again!";

	@MethodPost
	public Event getBizRequestForContributionHistoryData(RequestContext context)
			throws Exception {
		FLogger.info("ContributionHistoryLogger", "ContributionHistoryHandler",
				"getBizRequestForContributionHistoryData",
				"getBizRequestForContributionHistoryData Method Start ");

		try {

			HttpSession httpSession = ((HttpServletRequest) context
					.getExternalContext().getNativeRequest()).getSession();

			IPruUser userVo = new IPruUser();

			String policyNo = null;
			String clientId = null;
			String memberEmpId = null;
			String order = null;
			String role = null;

			userVo = (IPruUser) httpSession.getAttribute("userVO");

			if (userVo == null) {
				FLogger.error("ContributionHistoryLogger",
						"ContributionHistoryHandler",
						"getBizRequestForContributionHistoryData",
						"userVo is null ");
				throw new IPruException("Error", "CH01", ErrorMsg);
			}

			policyNo = userVo.getPolicyNo();
			clientId = userVo.getClientId();
			memberEmpId = userVo.getEmpId();
			role = userVo.getRoleType();

			if (StringUtils.isEmpty(policyNo) && StringUtils.isEmpty(role)) {
				FLogger.error("ContributionHistoryLogger",
						"ContributionHistoryHandler",
						"getBizRequestForContributionHistoryData",
						"policyNo or role is null ");
				throw new IPruException("Error", "CH01", ErrorMsg);
			}

			ContributionHistoryRequestPO contributionHistoryRequestPO = new ContributionHistoryRequestPO();
			contributionHistoryRequestPO.setPolicyNumber(policyNo);
			contributionHistoryRequestPO.setClientId(clientId);
			contributionHistoryRequestPO.setMemberEmpId(memberEmpId);
			contributionHistoryRequestPO.setRole(role);

			if (contributionHistoryRequestPO == null) {
				FLogger.error("ContributionHistoryLogger",
						"ContributionHistoryHandler",
						"getBizRequestForContributionHistoryData",
						"contributionHistoryRequestPO is null ");
				throw new IPruException("Error", "CH01", ErrorMsg);
			}

			ContributionHistoryRequestVO contributionHistoryRequestVO = new ContributionHistoryRequestVO();

			if (contributionHistoryRequestPO != null) {
				contributionHistoryRequestVO = dozerBeanMapper.map(
						contributionHistoryRequestPO,
						ContributionHistoryRequestVO.class);
			}

			if (contributionHistoryRequestVO == null) {
				FLogger.error("ContributionHistoryLogger",
						"ContributionHistoryHandler",
						"getBizRequestForContributionHistoryData",
						"contributionHistoryRequestVO is null ");
				throw new IPruException("Error", "CH01", ErrorMsg);
			}

			Object[] paramArray = new Object[1];
			paramArray[0] = contributionHistoryRequestVO;
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			context.getFlowScope().put("loadBizRequest", obj_bizReq);

		} catch (Exception e) {
			FLogger.error("ContributionHistoryLogger",
					"ContributionHistoryHandler",
					"getBizRequestForContributionHistoryData",
					"Exception Occured ", e);
			throwINeoFlowException(e, "CH01", context);
		}

		FLogger.info("ContributionHistoryLogger", "ContributionHistoryHandler",
				"ContributionHistoryHandler",
				"ContributionHistoryHandler Method End ");

		return success();

	}

	@MethodPost
	public Event getBizResponseForContributionHistoryData(RequestContext context)
			throws IPruException,Exception {
		FLogger.info("ContributionHistoryLogger", "ContributionHistoryHandler",
				"getBizResponseForContributionHistoryData",
				"getBizResponseForContributionHistoryData Method Start");
		String responseCheck = "";
		String resultJson = "";
		// boolean response = false;
		List<ContributionHistoryResponseVO> contributionHistoryVOList = new ArrayList();
		/*
		 * List<ContributionHistoryResponsePO> contributionHistoryPOList = new
		 * ArrayList();
		 */
		try {

			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get(
					"bizResForContributionHistoryData");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				} else {

					contributionHistoryVOList = (List<ContributionHistoryResponseVO>) bizRes
							.getTransferObjects().get("response1");

					if (CollectionUtils.isEmpty(contributionHistoryVOList)) {
						FLogger.error("ContributionHistoryLogger",
								"ContributionHistoryHandler",
								"getBizResponseForContributionHistoryData",
								"contributionHistoryVOList should not be null");
						throw new IPruException("Error", "CH01",
								"No data found");

					}
					ContributionHistoryResponsePO contributionHistoryResponsePO = null;
					List<ContributionHistoryResponsePO> ContributionHistoryResponsePOList = new ArrayList();
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					for (ContributionHistoryResponseVO contributionHistoryResponseVO : contributionHistoryVOList) {
						contributionHistoryResponsePO = new ContributionHistoryResponsePO();

						contributionHistoryResponsePO = dozerBeanMapper.map(
								contributionHistoryResponseVO,
								ContributionHistoryResponsePO.class);

						ContributionHistoryResponsePOList
								.add(contributionHistoryResponsePO);
					}

					if (CollectionUtils
							.isEmpty(ContributionHistoryResponsePOList)) {
						FLogger.error("ContributionHistoryLogger",
								"ContributionHistoryHandler",
								"getBizResponseForContributionHistoryData",
								"ContributionHistoryResponsePOList should not be null");
						throw new IPruException("Error", "CH01", ErrorMsg);

					}

					resultJson = gsonJSON
							.toJson(ContributionHistoryResponsePOList);
					context.getFlowScope().put("Response", resultJson);

				}
			}
		} catch (Exception e) {
			FLogger.error("ContributionHistoryLogger",
					"ContributionHistoryHandler",
					"getBizResponseForContributionHistoryData",
					"Exception came ", e);
			throwINeoFlowException(e, "CH01", context);
		}
		FLogger.info("ContributionHistoryLogger", "ContributionHistoryHandler",
				"getBizResponseForContributionHistoryData",
				"getBizResponseForContributionHistoryData Method End");
		return success();

	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
