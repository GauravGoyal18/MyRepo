package com.ipru.groups.handler;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.BrokerDashboardDetailsPO;
import com.ipru.groups.po.BrokerDashboardLoadRequestPO;

import com.ipru.groups.vo.BrokerDashboardDetailsVO;
import com.ipru.groups.vo.BrokerDashboardLoadRequestVO;

import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.ipru.security.user.PolicyDetails;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class BrokerDashboardHandler extends IneoBaseHandler {

	private static final long serialVersionUID = 1L;

	private static final String CLASS_NAME = BrokerDashboardHandler.class.getCanonicalName();
	private static final String INFO_LOGGER_NAME = "BrokerDashboardLogger";
	private static final String ERROR_LOGGER_NAME = "BrokerDashboardLogger";

	@MethodPost
	public Event getBizRequestForLoadBrokerDashboardDetails(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestForLoadBrokerDashboardDetails";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start");

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				IPruUser userVo = new IPruUser();
				String screenName = null;
				String branchCode = null;
				String loginType = null;
				String nationalCode = null;

				if (httpSession != null) {
					screenName = (String) context.getFlowScope().get("screenName");

					userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {
						branchCode = userVo.getFscdetails().getReferral_code(); 
						loginType = userVo.getSsoLogin();
						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

						if (request != null) {
							BrokerDashboardLoadRequestVO brokerDashboardLoadRequestVO = new BrokerDashboardLoadRequestVO();
							brokerDashboardLoadRequestVO.setScreenName(screenName);
							brokerDashboardLoadRequestVO.setUserVO(userVo);

							Object[] paramArray = new Object[1];
							paramArray[0] = brokerDashboardLoadRequestVO;

							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("loadBrokerDashboardBizReq", obj_bizReq);

						}
						else {

							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "request should not be null");
							throw new IPruException("Error", "GRPBD01", "request should not be null");
						}
					}
					else {
						FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
						throw new IPruException("Error", "GRPBD01", "userVo should not be null");
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
					throw new IPruException("Error", "GRPBD01", "httpSession should not be null");

				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Context should not be null");
				throw new IPruException("Error", "GRPBD01", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBD01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method End ");

		return success();
	}

	@SuppressWarnings("unchecked")
	@MethodPost
	public Event getBizResponseForLoadBrokerDashboardDetails(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseForLoadBrokerDashboardDetails";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method Start");

		BrokerDashboardDetailsVO brokerDashboardDetailsVO = null;
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		IPruUser userVo = null;
		PolicyDetails selectedPolicy = null;

		try {
			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					userVo = (IPruUser) httpSession.getAttribute("userVO");

				}
				bizRes = (BizResponse) context.getFlowScope().get("bizResForBrokerDashboardDetails");

				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {
						brokerDashboardDetailsVO = (BrokerDashboardDetailsVO) bizRes.getTransferObjects().get("response1");
						if (brokerDashboardDetailsVO != null) {
							BrokerDashboardDetailsPO brokerDashboardDetailsPO = dozerBeanMapper.map(brokerDashboardDetailsVO, BrokerDashboardDetailsPO.class);

							String dashboardDetailsPOJsonString = gsonJSON.toJson(brokerDashboardDetailsPO, BrokerDashboardDetailsPO.class);

							context.getFlowScope().put("Response", dashboardDetailsPOJsonString);
						}
						else {
							FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Data from service should not be null");
							throw new IPruException("Data from Service should not be null");
						}
					}
				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
					throw new IPruException("bizRes should not be null");
				}

			}

			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBD01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");

		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {

	}

	/*
	 * private boolean isEmailMobileCheckEnabled(List<RoleScreenAccessMappingVO>
	 * accessMappingList) { ////System.out.println("accessMappingList : "+
	 * accessMappingList); if(accessMappingList != null){
	 * for(RoleScreenAccessMappingVO roleScreenAccessMappingVO :
	 * accessMappingList){ if(roleScreenAccessMappingVO != null &&
	 * StringUtils.isNotEmpty(roleScreenAccessMappingVO.getScreenCode()) &&
	 * StringUtils.equals("otpEmailMobile",
	 * roleScreenAccessMappingVO.getScreenCode())){ return true; } } } return
	 * false; }
	 */

}
