/*    */ package com.ipru.groups.security;
/*    */ 
/*    */ import com.tcs.security.auth.IAuthStore;
import com.tcs.security.config.SecurityConfig;
/*    */ 
/*    */ public class SecurityManager
/*    */ {
/*    */   public static IAuthStore getAdaptor(String adaptorType)
/*    */     throws Exception
/*    */   {
/* 20 */     if (adaptorType.equals("DBHIBERNATE"))
/*    */     {
/* 22 */       String clas = SecurityConfig.INSTANCE.getDBHibernateAdaptorClass();
/* 23 */       //////System.out.println("Object of hte class " + clas);
/* 24 */       return (IAuthStore)Class.forName(clas).newInstance();
/*    */     }
/* 26 */     if (adaptorType.equals("DBJDBC"))
/*    */     {
/* 28 */       String clas = SecurityConfig.INSTANCE.getDBHibernateAdaptorClass();
/* 29 */       //////System.out.println("Object of hte class " + clas);
/* 30 */       return (IAuthStore)Class.forName(clas).newInstance();
/*    */     }
/* 32 */     if (adaptorType.equals("LDAP"))
/*    */     {
/* 34 */       String clas = SecurityConfig.INSTANCE.getLDAPAdaptorClass();
/* 35 */       //////System.out.println("Object of hte class " + clas);
/* 36 */       return (IAuthStore)Class.forName(clas).newInstance();
/*    */     }
/*    */ 
/* 39 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\ipru20276\Desktop\middle tier backup\
 * Qualified Name:     com.tcs.security.SecurityManager
 * JD-Core Version:    0.6.0
 */