package com.ipru.groups.handler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.webflow.action.AbstractAction;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.generic.po.FileUploadResultPo;
import com.ipru.groups.utilities.EncodingUtility;
import com.ipru.groups.utilities.EncryptionPBEMD5DES;
import com.ipru.groups.utilities.GroupCommonUtils;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.GroupMasterPropertiesFileLoader;

import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.security.user.IPruUser;
import com.tcs.logger.FLogger;

public class GroupMultipleFileUploadAction extends AbstractAction {

	private String uploadFolder = null;
	FileOutputStream fos=null;
	private Properties profileUpdateProperty=new Properties();
	 Gson gson=new Gson();
		FileUploadResultPo fileUploadResultPo1=new FileUploadResultPo();
	int fileSize;
	String allowExtension;

	public String getUploadFolder() {
		return uploadFolder;
	}

	public void setUploadFolder(String uploadFolder) {
		this.uploadFolder = uploadFolder;
	}
	public String getFunctionality(RequestContext context,int id) {

		String flowId = null;
		
		
		List<FunctionalityMasterVO> functionalityVoList = this.getFunctionalityVOList(context);
		
		if(functionalityVoList != null){
			for(FunctionalityMasterVO functionalityMasterVO : functionalityVoList){
				if(id==functionalityMasterVO.getFunctionalityId()){
					return functionalityMasterVO.getFunctionalityName();
				}
			}
		}
		
		return flowId;
	}
	public List<FunctionalityMasterVO> getFunctionalityVOList(RequestContext context) {
		List<FunctionalityMasterVO> functionalityVoList = null;

		functionalityVoList = (List<FunctionalityMasterVO>) context.getExternalContext().getApplicationMap().get("functionalityVOList");

		return functionalityVoList;
	}
	@Override
	protected Event doExecute(RequestContext context) throws Exception {
		
		FLogger.info("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Start Method");
		HttpServletResponse response=(HttpServletResponse) context.getExternalContext().getNativeResponse();
		 Map<String,FileUploadResultPo> fileUploadResultMap=null;
		 FileInputStream fis = null;
		if(GroupMasterPropertiesFileLoader.CONSTANT_FILE_UPLOAD_PROPERTIES!=null)
		{
			profileUpdateProperty=GroupMasterPropertiesFileLoader.CONSTANT_FILE_UPLOAD_PROPERTIES;
		}
		else
		{
			try {
				fis= new FileInputStream(GroupConstants.CONSTANT_FILE_UPLOAD);
				profileUpdateProperty.load(fis);
				if(profileUpdateProperty!=null)
				{
					
					if(StringUtils.isNotEmpty(profileUpdateProperty.getProperty("fileLength")))		
					fileSize=Integer.parseInt(profileUpdateProperty.getProperty("fileLength"));
					else
					{
						FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Found null file");
						 fileUploadResultPo1.setErrorCode("1");
							fileUploadResultPo1.setUploadMsg("Something Went Wrong");
							String gsonString=gson.toJson(fileUploadResultPo1);
							context.getFlowScope().put("Response",gsonString);
							return success();
					}
					
					if(StringUtils.isNotEmpty(profileUpdateProperty.getProperty("fileExtension")))	
					allowExtension=(String)profileUpdateProperty.getProperty("fileExtension");
					else
					{
						FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Found null file");
						 fileUploadResultPo1.setErrorCode("1");
							fileUploadResultPo1.setUploadMsg("Something Went Wrong");
							String gsonString=gson.toJson(fileUploadResultPo1);
							context.getFlowScope().put("Response",gsonString);
							return success();
					}
					
					
				}
				else
				{
					FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Found null file");
					 fileUploadResultPo1.setErrorCode("1");
						fileUploadResultPo1.setUploadMsg("Something Went Wrong");
						String gsonString=gson.toJson(fileUploadResultPo1);
						context.getFlowScope().put("Response",gsonString);
						return success();
				}
			} catch (FileNotFoundException e) {
				
				FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "FileNotFoundException",e);
				 fileUploadResultPo1.setErrorCode("1");
					fileUploadResultPo1.setUploadMsg("Something Went Wrong");
					String gsonString=gson.toJson(fileUploadResultPo1);
					context.getFlowScope().put("Response",gsonString);
					return success();
			} catch (IOException e) {
				
				FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "IOException",e);
				 fileUploadResultPo1.setErrorCode("1");
					fileUploadResultPo1.setUploadMsg("Something Went Wrong");
					String gsonString=gson.toJson(fileUploadResultPo1);
					context.getFlowScope().put("Response",gsonString);
					return success();
			}catch (Exception e) {
				
				FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Exception",e);
				 fileUploadResultPo1.setErrorCode("1");
					fileUploadResultPo1.setUploadMsg("Something Went Wrong");
					String gsonString=gson.toJson(fileUploadResultPo1);
					context.getFlowScope().put("Response",gsonString);
					return success();
			}
			finally {
				try {
					if(fis!=null)
						fis.close();
				}
				catch (Exception e) {
					FLogger.error("GROUPLoggerError", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
							"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
					e.printStackTrace();
				} finally {
					fis=null;
				}
			}
		}
		
		try
		{
		
	
		 int numberOfFiles = Integer.parseInt((String)context.getFlowScope().get("numberOfFiles"));
		 String jsonFileUploadReturn[]=new String[numberOfFiles];
		 if(numberOfFiles>0)
		 {	 
		 
		

		 String storeFileName="";
		 String uploadFolder="";
		 String docSavePath="";
		 String encryptpath="";
		 String functionality = (String)context.getFlowScope().get("functionality");
		 String docType = (String)context.getFlowScope().get("docType");
		 String custId=null;
		 String policyNo = null;
		 String role = null;
		 IPruUser userVo = null;
		 String functionalityName=getFunctionality(context,Integer.parseInt(functionality));
			//////System.out.println("functionalityName**********************************"+functionalityName);
		 if(functionalityName==null)
		 {
			 FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Not valid functionality");
			 fileUploadResultPo1.setErrorCode("3");
				fileUploadResultPo1.setUploadMsg("Not valid functionality");
				String gsonString=gson.toJson(fileUploadResultPo1);
				context.getFlowScope().put("Response",gsonString);
				return success();
		 }
		 HttpSession httpSession = ((HttpServletRequest) context
					.getExternalContext().getNativeRequest()).getSession();
		 
		 if (httpSession != null) {
				userVo = (IPruUser) httpSession.getAttribute("userVO");
				if (userVo != null) {
					policyNo = userVo.getPolicyNo();
					role = userVo.getRoles();
					custId = userVo.getClientId();
					//custId="00002285";
				}
		 }
		 fileUploadResultMap= (Map<String,FileUploadResultPo>) httpSession.getAttribute("fileUploadResultMap");
		
		 if(fileUploadResultMap==null)
		 {
			 fileUploadResultMap=new HashMap<String,FileUploadResultPo>();
		 }
		 
		 
		// custId="123";
		 if(role.equalsIgnoreCase("NON_LOGGED_IN_CUSTOMER"))
		 {
			 if(StringUtils.isEmpty(policyNo))
			 policyNo="NON_LOGGED_IN_POLICY";
			 if(StringUtils.isEmpty(custId))
			 custId="NON_LOGGED_IN_CUSTOMER";
		 }
		 
		 if(StringUtils.isNotEmpty(custId) && StringUtils.isNotEmpty(policyNo) && StringUtils.isNotEmpty(role))
		 {

		for(int j=0;j<numberOfFiles;j++)
		{
		MultipartFile multipartFile = context.getRequestParameters().getRequiredMultipartFile("files"+j);
		FileUploadResultPo fileUploadResultPo=new FileUploadResultPo();

			//getting parameters of the file
		if(multipartFile!=null)
		{
		 
		 	String filename=multipartFile.getOriginalFilename();//name
			String extension = null;
			String fileNameWithoutExt = null;
			int i = filename.lastIndexOf('.');
			if(StringUtils.isNotEmpty(filename))
			{
			fileNameWithoutExt = filename.substring(0,i);
			int p = Math.max(filename.lastIndexOf('/'), filename.lastIndexOf('\\'));
			FLogger.info("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "P value "+p+" i value "+i);

			if (i > p) {
				
				extension = filename.substring(i+1);//extension
			}
		
			}
			if(StringUtils.isNotEmpty(extension) && StringUtils.isNotEmpty(fileNameWithoutExt) )
			{
			
				int mb = 1048576;
                int currentFileSize = Math.round((multipartFile.getSize()) / mb);
   
                if(StringUtils.isNotEmpty(allowExtension))
                {
   
                	
                if(multipartFile.getSize()>0 && currentFileSize <fileSize){
				if((isPng(multipartFile))){
					if (allowExtension.contains(extension)) {
						//saving file in location
						String uploadPath = GroupConstants.CONSTANT_ENV_DOC_PATH+"/"+functionalityName+"/"+custId+"/"+GroupConstants.CONSTANT_DOCUMENT_UPLOADDOC_PATH;
						String destination = GroupCommonUtils.createDirWithTodaysDate(uploadPath);//profileUpdateProperty.getProperty("DOCUMENT_UPLOAD_PATH");
					   if(StringUtils.isNotEmpty(destination))
					   {
						
						File file = new File(destination);
						if (!file.isDirectory()) {
							//create the directory
								 file.mkdirs();
						
							
							}
					 
					    	String todaysDate = new SimpleDateFormat("ddMMyyyyHHmmss").format(Calendar.getInstance().getTime());
							
							storeFileName = custId + "_" + docType + "_" +fileNameWithoutExt+ "_" + todaysDate  + "." + extension;
					    	uploadFolder = file.getAbsolutePath().replace("\\", "/")+"/";
					    	docSavePath = uploadFolder + storeFileName;
					    	
					    	if(StringUtils.isNotEmpty(docSavePath))
					    	{
					    	
							FLogger.info("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Doc Save Path"+docSavePath);

					    	
					    	encryptpath=EncodingUtility.encodeBase64(EncryptionPBEMD5DES.encrypt(docSavePath,EncodingUtility.CONSTANT_DOCUMENT_PATH_ENCRYPTION_KEY,1));	
					    	if(StringUtils.isNotEmpty(encryptpath))
					    	{
					    	
					    	
					    	
					    //	String dycryptPath="M1MyclpTVWxDSExPVzBDdGw1LzFtc3RZK0RFdDUrTjdteWhWM0sxVitvdU84Y3pLOVFQREtqeHk0dW14UklDVGt2M1hzRGJ5aWp2aQpQTmRGS3YvTnRRejVIOHk1VXBGc3NHZHUxR1VKRlY2YWREL0FhWmJSNGVNRGlyUStMa0FaR042Um5EQVh1K2srNW9Oc2dOMW05RGR1Ckw5RDU3WUpvTk5uQldSTkRkTGM1Y2UvVC9Gd3dWaTJNUTJRS1hnNCtSYUh5MG1TNGc0anpJTUkvSVR6Z0NiY0pDazZ5UkIxYi9OMVQKRWY2K2NpZXdxYkJUVnZKMS9UUHU1eWlwQjdQUnNkQnhwaHYrbFpFPQo=";
					    	File  upLoadedfile = new File(docSavePath);
							 upLoadedfile.createNewFile(); 
							fos = new FileOutputStream(upLoadedfile); 
							fos.write(multipartFile.getBytes());
							fos.close(); // setting the value of fileUploaded
											// variable
							fileUploadResultPo.setDocName(storeFileName);
							fileUploadResultPo.setDocSize(multipartFile.getSize());
							fileUploadResultPo.setErrorCode("0");
							fileUploadResultPo.setUploadMsg("File uploaded successfully");
							fileUploadResultPo.setDocType(docType);
							fileUploadResultPo.setFunctionality(functionality);
							fileUploadResultPo.setPolicyNo(policyNo);
							fileUploadResultPo.setClientId(custId);
							fileUploadResultPo.setRole(role);
							fileUploadResultPo.setContentType(multipartFile.getContentType());
							fileUploadResultPo.setDocFileType(extension);
							fileUploadResultPo.setDocPath(encryptpath);
							fileUploadResultPo.setDocumentName(fileNameWithoutExt);
						
							jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
							/*if(fileUploadResultMap.containsKey(fileUploadResultPo.getDocumentName())){
								
								FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "fileNameWithoutEXt duplicate please select another file");
								fileUploadResultPo.setErrorCode("2");
								fileUploadResultPo.setUploadMsg("Duplicate please file name");
								jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
							}*/
							fileUploadResultMap.put(fileUploadResultPo.getDocumentName(), fileUploadResultPo);
							httpSession.setAttribute("fileUploadResultMap", fileUploadResultMap);
							//jsonFileUploadReturn[j] = "{\"docName\":\"" + storeFileName + "\",\"docSize\":\"" + multipartFile.getSize() + "\",\"errorMsg\":\"0\",\"docType\":\""  + "\",\"moduleType\":\"" + docType + "\",\"clientId\":\"" + custId + "\",\"contentType\":\"" + multipartFile.getContentType() + "\",\"docPath\":\"" + encryptpath + "\",\"policyNo\":\"" + policyNo + "\",\"role\":\"" + role + "\",\"docFileType\":\"" + extension + "\"}";
							FLogger.info("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "File uploaded successfully");

					    	}
					    	else
					    	{
								FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "encryptpath is null");
								fileUploadResultPo.setErrorCode("1");
								fileUploadResultPo.setUploadMsg("Something Went Wrong");
								jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
								
								//jsonFileUploadReturn[j] = "{\"docName\":\"" + storeFileName + "\",\"docSize\":\"" + multipartFile.getSize() + "\",\"errorMsg\":\"2\",\"docType\":\"" + proofType + "\",\"moduleType\":\"" + docType + "\",\"clientId\":\"" + custId + "\",\"contentType\":\"" + multipartFile.getContentType() + "\",\"docPath\":\"" + encryptpath + "\",\"policyNo\":\"" + policyNo+ "\",\"role\":\"" + role + "\",\"docFileType\":\"" + extension + "\"}";

					    	}
							
					    	}
					    	else
					    	{
								FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "docSavePath is null");
								fileUploadResultPo.setErrorCode("1");
								fileUploadResultPo.setUploadMsg("Something Went Wrong");
								jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
								
								
								//jsonFileUploadReturn[j] = "{\"docName\":\"" + storeFileName + "\",\"docSize\":\"" + multipartFile.getSize() + "\",\"errorMsg\":\"2\",\"docType\":\"" + proofType + "\",\"moduleType\":\"" + docType + "\",\"clientId\":\"" + custId + "\",\"contentType\":\"" + multipartFile.getContentType() + "\",\"docPath\":\"" + encryptpath + "\",\"policyNo\":\"" + policyNo+ "\",\"role\":\"" + role + "\",\"docFileType\":\"" + extension + "\"}";

					    	}
					    	
					    }
					else
					{
						FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "destination is null");
						fileUploadResultPo.setErrorCode("1");
						fileUploadResultPo.setUploadMsg("Something Went Wrong");
						jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
						
						
						//jsonFileUploadReturn[j] = "{\"docName\":\"" + storeFileName + "\",\"docSize\":\"" + multipartFile.getSize() + "\",\"errorMsg\":\"2\",\"docType\":\"" + proofType + "\",\"moduleType\":\"" + docType + "\",\"clientId\":\"" + custId + "\",\"contentType\":\"" + multipartFile.getContentType() + "\",\"docPath\":\"" + encryptpath + "\",\"policyNo\":\"" + policyNo+ "\",\"role\":\"" + role + "\",\"docFileType\":\"" + extension + "\"}";

					}
							
							
					}
					else {
						
						FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Incorrect Extension");
						fileUploadResultPo.setErrorCode("2");
						fileUploadResultPo.setUploadMsg("Invalid Document fromat");
						jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
						
						
						//jsonFileUploadReturn[j] = "{\"docName\":\"" + storeFileName + "\",\"docSize\":\"" + multipartFile.getSize() + "\",\"errorMsg\":\"2\",\"docType\":\"" + proofType + "\",\"moduleType\":\"" + docType + "\",\"clientId\":\"" + custId + "\",\"contentType\":\"" + multipartFile.getContentType() + "\",\"docPath\":\"" + encryptpath + "\",\"policyNo\":\"" + policyNo+ "\",\"role\":\"" + role + "\",\"docFileType\":\"" + extension + "\"}";
																																																		// =
																																												// format
																																																		// error
					}
					
				}
				else {
				
					
					FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Incorrect format");

					fileUploadResultPo.setErrorCode("2");
					fileUploadResultPo.setUploadMsg("Invalid Document fromat");
					jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
					
					
					
					//jsonFileUploadReturn[j] = "{\"docName\":\"" + storeFileName + "\",\"docSize\":\"" + multipartFile.getSize() + "\",\"errorMsg\":\"2\",\"docType\":\"" + proofType + "\",\"moduleType\":\"" + docType + "\",\"clientId\":\"" + custId + "\",\"contentType\":\"" + multipartFile.getContentType() + "\",\"docPath\":\"" + encryptpath + "\",\"policyNo\":\"" + policyNo+ "\",\"role\":\"" + role + "\",\"docFileType\":\"" + extension + "\"}";
																																																	// 2
																																													// error
				}
				
			}
			else {
			
				
				fileUploadResultPo.setErrorCode("1");
				fileUploadResultPo.setUploadMsg("Something Went Wrong");
				jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
		
				FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "multipartFile is null");
				//jsonFileUploadReturn[j] = "{\"docName\":\"" + storeFileName + "\",\"docSize\":\"" + multipartFile.getSize() + "\",\"errorMsg\":\"1\",\"docType\":\"" + proofType + "\",\"moduleType\":\"" + docType + "\",\"clientId\":\"" + custId + "\",\"contentType\":\"" + multipartFile.getContentType() + "\",\"docPath\":\"" + encryptpath + "\",\"policyNo\":\"" + policyNo+ "\",\"role\":\"" + role + "\",\"docFileType\":\"" + extension + "\"}";
																																														// error
			}
			
                }//extenion array check
                
                else
                {
            		FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "allowExtension is null");
            		fileUploadResultPo.setErrorCode("1");
					fileUploadResultPo.setUploadMsg("Something Went Wrong");
					jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
					
            		
            		//jsonFileUploadReturn[j] = "{\"docName\":\"" + storeFileName + "\",\"docSize\":\"" + multipartFile.getSize() + "\",\"errorMsg\":\"Invalid File Name\",\"docType\":\"" + proofType + "\",\"moduleType\":\"" + docType + "\",\"clientId\":\"" + custId + "\",\"contentType\":\"" + multipartFile.getContentType() + "\",\"docPath\":\"" + encryptpath + "\",\"policyNo\":\"" + policyNo+ "\",\"role\":\"" + role + "\",\"docFileType\":\"" + extension + "\"}";
                }
		
			//Handle file content - multipartFile.getInputStream()
			//return null;
			
		}//end of extension if
			
			
	else
	{
		FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "extension or fileNameWithoutExt is null");
		fileUploadResultPo.setErrorCode("2");
		fileUploadResultPo.setUploadMsg("Invalid file format");
		jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
		
		
		//jsonFileUploadReturn[j] = "{\"docName\":\"" + storeFileName + "\",\"docSize\":\"" + multipartFile.getSize() + "\",\"errorMsg\":\"Invalid File Name\",\"docType\":\"" + proofType + "\",\"moduleType\":\"" + docType + "\",\"clientId\":\"" + custId + "\",\"contentType\":\"" + multipartFile.getContentType() + "\",\"docPath\":\"" + encryptpath + "\",\"policyNo\":\"" + policyNo+ "\",\"role\":\"" + role + "\",\"docFileType\":\"" + extension + "\"}";

	}
		
		
}
		else
		{
			FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Null Multipart file");
			fileUploadResultPo.setErrorCode("2");
			fileUploadResultPo.setUploadMsg("Invalid file format");
			jsonFileUploadReturn[j]=gson.toJson(fileUploadResultPo);
		}
		
		
		
		}
		
		 }
		 
		 else
		 {
			 FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Null session parameter");
			// throw new IPruException("Error","GRYY01","SomeThing went Wrong");
			 
			 fileUploadResultPo1.setErrorCode("1");
			fileUploadResultPo1.setUploadMsg("Something Went Wrong");
			String gsonString=gson.toJson(fileUploadResultPo1);
			context.getFlowScope().put("Response",gsonString);
			return success();

		 }
		 String json=gson.toJson((jsonFileUploadReturn));
		context.getFlowScope().put("Response",json);
		
		FLogger.info("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "doExecute end");

		    
		}//
		 else
		 {

			FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Number of files is less than 0");
			fileUploadResultPo1.setErrorCode("1");
			fileUploadResultPo1.setUploadMsg("Something Went Wrong");
			String gsonString=gson.toJson(fileUploadResultPo1);
			context.getFlowScope().put("Response",gsonString);
			return success();
		 }
		 
		 
		}
		catch(Exception e)
		{
			

			 FLogger.error("GROUPLogger", "GroupMultipleFileUploadAction", "doExecute", "Some Exception occure",e);
			 fileUploadResultPo1.setErrorCode("1");
			fileUploadResultPo1.setUploadMsg("Something Went Wrong");
			String gsonString=gson.toJson(fileUploadResultPo1);
			context.getFlowScope().put("Response",gsonString);
			return success();
			
			
			
		}
		finally
		{
			if(fos!=null)
			fos.close(); 
		}
		return success();
		}
	
	public static final int MAGIC[][] = new int[][] { { 0xFF, 0xD8 },
		{ 0x4A, 0x46, 0x49, 0x46 }, { 0x45, 0x78, 0x69, 0x66 },
		{ 0xff, 0xd8, 0xff, 0xe0 }, { 0x42, 0x4d },
		{ 0x47, 0x49, 0x46, 0x38, 0x39, 0x61 },
		{ 0x47, 0x49, 0x46, 0x38, 0x37, 0x61 } ,
		{ 0x25, 0x50, 0x44, 0x46},
		{ 0x49, 0x49, 0x2A ,0x00},
		{ 0x4D, 0x4D, 0x00, 0x2A},{0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1},{0x50, 0x4B, 0x03, 0x04}
	};
private static boolean isPng(MultipartFile filename) throws Exception {
	InputStream ins = filename.getInputStream();
	boolean isValidFile = false;
		int fileByte[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

	try {
		for (int i = 0; i < MAGIC.length; ++i) {
			isValidFile = true;
			for (int j = 0; j < MAGIC[i].length; ++j) {
				if (fileByte[j] == 0) {
					fileByte[j] = ins.read();
				}
				//////System.out.println("Code::" + fileByte[j]);
				if (fileByte[j] != MAGIC[i][j]) {
					isValidFile = false;
					break;
				}
			}
			if (isValidFile)
				break;
		}
		return isValidFile;
		}
		finally {
		ins.close();
	}
}




}

