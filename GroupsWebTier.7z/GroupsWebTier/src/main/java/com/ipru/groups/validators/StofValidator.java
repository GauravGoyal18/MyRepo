package com.ipru.groups.validators;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.util.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.enums.FrequencyOfTransEnum;
import com.ipru.groups.enums.SwitchTypeEnum;
import com.ipru.groups.grpswitch.bean.FundDetailsPO;
import com.ipru.groups.grpswitch.bean.ProductSwitchAmountPO;
import com.ipru.groups.handler.StofHandler;
import com.ipru.groups.po.DropDownObjPO;
import com.ipru.groups.po.FundMasterPO;
import com.ipru.groups.po.StofLoadDataPO;
import com.ipru.groups.po.StofSubmitPo;
import com.ipru.groups.po.StofSubmitTransactionPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.tcs.logger.FLogger;

public class StofValidator {
	private final StringBuilder errorMessageBuilder = new StringBuilder(1);
	public String switchTypeRequest = null;
	boolean result = false;
	Map<String, Double> switchAountFundMap = new HashMap<String, Double>();

	public String validateStofDetails(StofSubmitTransactionPO stofSubmitTransactionPO, RequestContext p_ObjContext) throws IPruException {

		FLogger.info("StofLogger", "StofValidator", "validateStofDetails", "validateStofDetails Method Start");

		Set<StofSubmitPo> stofSubmitPo = stofSubmitTransactionPO.getStof();
		StofLoadDataPO stofLoadDataPO = (StofLoadDataPO) p_ObjContext.getFlowScope().get("loadStofData");

		// //System.out.println(stofLoadDataPO.toString());
		// StofLoadDataPO
		// stofLoadDataPO=(StofLoadDataPO)httpSession.getAttribute("stofLoadSessionData");
		if (stofLoadDataPO == null) {
			throw new IPruException("Error", "GRPSTF02", "found null session");// malitious
																				// request
		}

		if (stofLoadDataPO.isRequestPerDayExist()) {
			throw new IPruException("Error", "GRPSTF02", "Only one request per day is allow");
		}
		switchTypeRequest = stofSubmitTransactionPO.getSwitchType();
		for (StofSubmitPo stofSubmit : stofSubmitPo) {
			result = validateStofDetailsBean(stofSubmit, stofLoadDataPO, stofSubmitTransactionPO);
		}

		if (!result) {
			errorMessageBuilder.append("Some error occured");
		}
		else {
			if (((Double.parseDouble(stofLoadDataPO.getProductSwitchAmount().getMinSwitchAmount()) < StofHandler.totalToBeSubmit) && (Double.parseDouble(stofLoadDataPO.getProductSwitchAmount().getMaxSwitchAmount()) > StofHandler.totalToBeSubmit))) {
				if (StofHandler.totalToBeSubmit == Double.parseDouble(stofSubmitTransactionPO.getTotalStofAmount())) {
					if (stofSubmitTransactionPO.getiAgreeTnC() == "true") {
						FLogger.info("StofLogger", "StofValidator", "validateStofDetails", "validateStofDetails Method end");
						return errorMessageBuilder.toString();
					}
					else {
						FLogger.info("StofLogger", "StofValidator", "validateStofDetails", "Please check I accept Terms and Conditions");
						errorMessageBuilder.append("Please check I accept Terms and Conditions");
					}
				}
				else {
					FLogger.info("StofLogger", "StofValidator", "validateStofDetails", "Total amount are not matching");
					errorMessageBuilder.append("Total amount are not matching");

				}
			}
			else {
				FLogger.info("StofLogger", "StofValidator", "validateStofDetails", "Total Switch amount must be between " + stofLoadDataPO.getProductSwitchAmount().getMinSwitchAmount() + " & "
						+ stofLoadDataPO.getProductSwitchAmount().getMaxSwitchAmount());
				errorMessageBuilder.append("Total Switch amount must be between " + stofLoadDataPO.getProductSwitchAmount().getMinSwitchAmount() + " & "
						+ stofLoadDataPO.getProductSwitchAmount().getMaxSwitchAmount());

			}
		}

		FLogger.info("StofLogger", "StofValidator", "validateStofDetails", "validateStofDetails Method end");

		return errorMessageBuilder.toString();
	}

	public boolean validateStofDetailsBean(StofSubmitPo stofSubmitPo, StofLoadDataPO stofLoadDataPO, StofSubmitTransactionPO stofSubmitTransactionPO) {
		boolean result = false;
		/*
		 * ArrayList<FrequencyOfTransEnum> frequency=new
		 * ArrayList<FrequencyOfTransEnum>(); FrequencyOfTransEnum
		 * frequencyOfTransEnum[]=FrequencyOfTransEnum.values(); for(int
		 * i=0;i<frequencyOfTransEnum.length;i++) {
		 * frequency.add(frequencyOfTransEnum[i]); }
		 */

		/*
		 * switchTypeList.add("amount"); switchTypeList.add("unit");
		 */

		if (validateFrequency(stofSubmitPo.getFrequency(), stofLoadDataPO.getFreqOfTrans())) {
			if (validateFundName(stofSubmitPo.getFundFromName(), stofLoadDataPO.getActiveFromFundList())) {
				if (validateFundToName(stofSubmitPo.getFundToName(), stofLoadDataPO.getActiveApplicableToFundList(), stofSubmitPo.getFundFromName(), stofLoadDataPO.getFundMasterList())) {
					if (validateNAV(stofSubmitPo.getNav(), stofLoadDataPO.getFundDetailsVOList(), stofSubmitPo.getFundFromName())) {
						if (validateNumberOfTransfer(stofSubmitPo.getNumberOfTransfer())) {
							if (validateSwitchType(stofSubmitTransactionPO.getSwitchType())) {
								if (validateUnitOrAmount(stofSubmitPo.getUnitOrAmount(), stofLoadDataPO.getFundDetailsVOList(), stofSubmitPo.getFundFromName())) {
									if (validateTotalAmount(stofSubmitPo.getTotalValue(), stofSubmitPo.getUnitOrAmount(), stofSubmitTransactionPO.getSwitchType(), stofSubmitPo.getNav(), stofLoadDataPO.getProductSwitchAmount(), stofSubmitPo.getFundToName(), stofSubmitPo.getFundFromName(), stofLoadDataPO.getFundDetailsVOList())) {

										result = true;
										return result;

									}
								}

							}
						}
					}
				}
			}
		}

		return result;
	}

	public boolean validateFrequency(String freq, List<DropDownObjPO> frequencyOfTrans) {

		FLogger.info("StofLogger", "StofValidator", "validateFrequency", "validateFrequency Method Start");
		boolean result = false;
		if (freq != null && !StringUtils.isEmpty(freq)) {

			if (CommonValidationUtil.ValidateRequired(freq) && CommonValidationUtil.ValidateAlpha(freq) && CommonValidationUtil.ValidateLengths(freq, 1, 200)) {

				for (DropDownObjPO dropDownObjPO : frequencyOfTrans) {

					if (dropDownObjPO.getValue().trim().equalsIgnoreCase(freq.trim())) {
						result = true;
						break;
					}
				}

			}

		}

		FLogger.info("StofLogger", "StofValidator", "validateFrequency", "validateFrequency status" + result);

		FLogger.info("StofLogger", "StofValidator", "validateFrequency", "validateFrequency Method end");

		return result;
	}

	public boolean validateFundName(String fundName, List<String> fundList) {

		FLogger.info("StofLogger", "StofValidator", "validateFundName", "validateFundName Method Start");

		boolean result = false;
		if (fundName != null && !StringUtils.isEmpty(fundName)) {

			if (CommonValidationUtil.ValidateRequired(fundName) && CommonValidationUtil.ValidateLengths(fundName, 1, 200)) {

				if (fundList.contains(fundName.trim()))
					result = true;
			}

		}
		FLogger.info("StofLogger", "StofValidator", "validateFundName", "validateFundName status " + result);

		FLogger.info("StofLogger", "StofValidator", "validateFundName", "validateFundName Method end");

		return result;
	}

	public boolean validateFundToName(String fundName, List<String> fundList, String fundFromName, List<FundMasterPO> fundMasterList) {

		FLogger.info("StofLogger", "StofValidator", "validateFundToName", "validateFundToName Method Start");

		boolean result = false;
		if (fundName != null && !StringUtils.isEmpty(fundName)) {
			if (fundFromName.equalsIgnoreCase(fundName)) {
				errorMessageBuilder.append("Stoff can not be perform between same funds");
				return false;
			}
			if (switchAountFundMap.containsKey(fundFromName + "&" + fundName)) {
				errorMessageBuilder.append("Stoff can not be perform between same funds twice");
				return false;
			}
			if (CommonValidationUtil.ValidateRequired(fundName) && CommonValidationUtil.ValidateLengths(fundName, 1, 200)) {

				if (fundList.contains(fundName.trim())) {
					result = validateCgToNonCG(fundMasterList, fundFromName, fundName);
					result = true;
				}
			}

		}

		FLogger.info("StofLogger", "StofValidator", "validateFundToName", "validateFundToName status" + result);

		FLogger.info("StofLogger", "StofValidator", "validateFundToName", "validateFundToName Method end");

		return result;
	}

	public boolean validateCgToNonCG(List<FundMasterPO> fundMasterList, String fundFromName, String fundToName) {
		String isCGFromFund = null;
		String isCGToFund = null;
		for (int i = 0; i < fundMasterList.size(); i++) {
			if (fundMasterList.get(i).getFundName().trim().equalsIgnoreCase(fundFromName.trim())) {
				isCGFromFund = fundMasterList.get(i).getIsCapital();
			}

			else if (fundMasterList.get(i).getFundName().trim().equalsIgnoreCase(fundToName.trim())) {
				isCGToFund = fundMasterList.get(i).getIsCapital();
			}

		}
		if (isCGFromFund == "N" && isCGToFund == "Y") {
			// errorMessage = "Cannot switch from Non CG Fund to CG Fund";
			return false;
		}

		return true;
	}

	public boolean validateNAV(String nav, List<FundDetailsPO> fundDetailsVOList, String fundFromName) {

		FLogger.info("StofLogger", "StofValidator", "validateNAV", "validateNAV method start");

		boolean result = false;
		if (nav != null && !StringUtils.isEmpty(nav)) {

			if (CommonValidationUtil.ValidateRequired(nav) && CommonValidationUtil.ValidateLengths(nav, 1, 200))// validation
																												// for
																												// numeric
																												// is
																												// remaining
			{
				FundDetailsPO fundDetailsVo = getFundDetailsFromFundName(fundFromName, fundDetailsVOList);
				if (fundDetailsVo.getNavValue().trim().equalsIgnoreCase(nav.trim()))
					result = true;
			}

		}

		FLogger.info("StofLogger", "StofValidator", "validateNAV", "validateNAV status" + result);

		FLogger.info("StofLogger", "StofValidator", "validateNAV", "validateNAV method end");

		return result;
	}

	public boolean validateNumberOfTransfer(String numberOfTransfer) {

		FLogger.info("StofLogger", "StofValidator", "validateNumberOfTransfer", "validateNumberOfTransfer method start");

		boolean result = false;
		if (numberOfTransfer != null && !StringUtils.isEmpty(numberOfTransfer)) {

			if (CommonValidationUtil.ValidateRequired(numberOfTransfer) && CommonValidationUtil.ValidateLengths(numberOfTransfer, 1, 3))// validation
																																		// for
																																		// numeric
																																		// is
																																		// remaining
			{
				if (Double.parseDouble(numberOfTransfer) <= 100)
					result = true;
			}

		}

		FLogger.info("StofLogger", "StofValidator", "validateNumberOfTransfer", "validateNumberOfTransfer " + result);

		FLogger.info("StofLogger", "StofValidator", "validateNumberOfTransfer", "validateNumberOfTransfer method end");

		return result;
	}

	public boolean validateSwitchType(String switchType) {
		FLogger.info("StofLogger", "StofValidator", "validateSwitchType", "validateSwitchType method start");

		boolean result = false;
		if (switchType != null && !StringUtils.isEmpty(switchType)) {

			if (CommonValidationUtil.ValidateRequired(switchType) && CommonValidationUtil.ValidateAlpha(switchType) && CommonValidationUtil.ValidateLengths(switchType, 1, 200)) {

				for (SwitchTypeEnum switchTypeEnum : SwitchTypeEnum.values()) {
					if (switchTypeEnum.toString().equalsIgnoreCase(switchType)) {
						if (switchType.trim().equalsIgnoreCase(switchTypeRequest.trim()))
							result = true;
					}
				}
			}

		}

		FLogger.info("StofLogger", "StofValidator", "validateSwitchType", "validateSwitchType status" + result);

		FLogger.info("StofLogger", "StofValidator", "validateSwitchType", "validateSwitchType method end");

		return result;
	}

	public boolean validateUnitOrAmount(String unitOrAmount, List<FundDetailsPO> fundDetailsVOList, String fundFromName)// validation
																														// for
																														// numeric
																														// is
																														// remaining
	{

		FLogger.info("StofLogger", "StofValidator", "validateUnitOrAmount", "validateUnitOrAmount method start");

		boolean result = false;
		String actualTotalAmount = null;
		if (unitOrAmount != null && !StringUtils.isEmpty(unitOrAmount)) {

			if (CommonValidationUtil.ValidateRequired(unitOrAmount) && CommonValidationUtil.ValidateLengths(unitOrAmount, 1, 11)) {

				if (unitOrAmount != "0") {

					for (FundDetailsPO fundDetailsVo : fundDetailsVOList) {
						if (fundDetailsVo.getFundDesc().trim().equalsIgnoreCase(fundFromName.trim())) {
							actualTotalAmount = fundDetailsVo.getTotalAmount();
							break;
						}
					}
					if (Double.parseDouble(String.valueOf(actualTotalAmount)) > Double.parseDouble(unitOrAmount))
						result = true;

				}
			}

		}

		FLogger.info("StofLogger", "StofValidator", "validateUnitOrAmount", "validateUnitOrAmount method status" + result);

		FLogger.info("StofLogger", "StofValidator", "validateUnitOrAmount", "validateUnitOrAmount method end");

		return result;
	}

	public boolean validateTotalAmount(String totalAmount, String unitOrAmount, String switchType, String NAV, ProductSwitchAmountPO productSwitchAmountVO, String fundToName, String fundFromName, List<FundDetailsPO> fundDetailsVOList)// validation
																																																											// for
																																																											// numeric
																																																											// is
																																																											// remaining
	{

		FLogger.info("StofLogger", "StofValidator", "validateTotalAmount", "validateTotalAmount method start");

		boolean result = false;
		double actualTotalAmountOfSelectedFund = 0;
		if (totalAmount != null && !StringUtils.isEmpty(totalAmount)) {

			if (CommonValidationUtil.ValidateRequired(totalAmount) && CommonValidationUtil.ValidateLengths(totalAmount, 1, 100)) {

				double acctualTotalAmount = validateSwitchTypeDropDown(switchType, unitOrAmount, NAV);
				double totalAmountInvestedToThatFund = 0;
				acctualTotalAmount = roundUpToRequiredDecimal(acctualTotalAmount);
				if (acctualTotalAmount == Double.parseDouble(totalAmount)) {
					result = true;
					for (Map.Entry<String, Double> entry : switchAountFundMap.entrySet()) {
						String key = entry.getKey();
						if (key.contains(fundFromName)) {
							totalAmountInvestedToThatFund = totalAmountInvestedToThatFund + entry.getValue();
							totalAmountInvestedToThatFund = roundUpToRequiredDecimal(totalAmountInvestedToThatFund);
						}
						// //System.out.println(entry.getKey() + "/" +
						// entry.getValue());
					}

					for (FundDetailsPO fundDetailsVo : fundDetailsVOList) {
						if (fundDetailsVo.getFundDesc().trim().equalsIgnoreCase(fundFromName.trim())) {
							actualTotalAmountOfSelectedFund = Double.parseDouble(fundDetailsVo.getTotalAmount());
							actualTotalAmountOfSelectedFund = roundUpToRequiredDecimal(actualTotalAmountOfSelectedFund);

							break;
						}
					}
					// compare above two values
					if (actualTotalAmountOfSelectedFund > (totalAmountInvestedToThatFund + acctualTotalAmount)) {
						switchAountFundMap.put(fundFromName + "&" + fundToName, acctualTotalAmount);
						StofHandler.totalToBeSubmit = StofHandler.totalToBeSubmit + acctualTotalAmount;
						StofHandler.totalToBeSubmit = roundUpToRequiredDecimal(StofHandler.totalToBeSubmit);

					}
					else {
						return false;
					}
				}
			}

		}

		FLogger.info("StofLogger", "StofValidator", "validateTotalAmount", "validateTotalAmount method status " + result);

		FLogger.info("StofLogger", "StofValidator", "validateTotalAmount", "validateTotalAmount method end");

		return result;
	}

	/*
	 * public boolean validateRemainingAmount(String
	 * totalValue,List<FundDetailsVO> fundDetailsVOList,String fundName,String
	 * remainingFromAmount)//validation for numeric is remaining {
	 * FLogger.info("StofLogger", "StofValidator", "validateRemainingAmount",
	 * "validateRemainingAmount method start"); boolean result=false;
	 * FundDetailsVO fundDetailsVO
	 * =getFundDetailsFromFundName(fundName,fundDetailsVOList);
	 * System.out.println
	 * (fundDetailsVO.toString()+"fundDetailsVOfundDetailsVO");
	 * if(fundDetailsVO!=null) { double
	 * accualRemainingAmount=roundUpToRequiredDecimal
	 * (Double.parseDouble(fundDetailsVO
	 * .getTotalAmount()))-roundUpToRequiredDecimal
	 * (Double.parseDouble(totalValue));
	 * accualRemainingAmount=roundUpToRequiredDecimal(accualRemainingAmount);
	 * if(accualRemainingAmount==roundUpToRequiredDecimal(Double.parseDouble(
	 * remainingFromAmount))) {
	 * ////System.out.println("accualRemainingAmount"+accualRemainingAmount
	 * +",remainingFromAmount"+remainingFromAmount);
	 * fundDetailsVO.setTotalAmount(String.valueOf(accualRemainingAmount));
	 * result=true; } else {
	 * ////System.out.println("falseeeeeeeeaccualRemainingAmount"
	 * +accualRemainingAmount+",remainingFromAmount"+remainingFromAmount);
	 * result=false; } } else { result=false; } FLogger.info("StofLogger",
	 * "StofValidator", "validateRemainingAmount",
	 * "validateRemainingAmount method status "+result);
	 * FLogger.info("StofLogger", "StofValidator", "validateRemainingAmount",
	 * "validateRemainingAmount method end"); return result; } public boolean
	 * validateRemainingUnit(String unit,List<FundDetailsVO>
	 * fundDetailsVOList,String fundName,String remainingUnit)//validation for
	 * numeric is remaining { FLogger.info("StofLogger", "StofValidator",
	 * "validateRemainingUnit", "validateRemainingUnit method start"); boolean
	 * result=false; FundDetailsVO fundDetailsVO=
	 * getFundDetailsFromFundName(fundName,fundDetailsVOList);
	 * System.out.println
	 * (fundDetailsVO.toString()+"fundDetailsVOfundDetailsVO");
	 * if(fundDetailsVO!=null) { double
	 * accualRemainingUnits=roundUpTo3RequiredDecimal
	 * (Double.parseDouble(fundDetailsVO
	 * .getUnits()))-roundUpTo3RequiredDecimal(Double.parseDouble(unit));
	 * accualRemainingUnits=roundUpTo3RequiredDecimal(accualRemainingUnits);
	 * if(accualRemainingUnits==roundUpTo3RequiredDecimal(Double.parseDouble(
	 * remainingUnit))) {
	 * ////System.out.println("accualRemainingAmount"+accualRemainingUnits
	 * +",remainingFromAmount"+remainingUnit);
	 * fundDetailsVO.setUnits(String.valueOf(accualRemainingUnits));
	 * result=true; } else {
	 * ////System.out.println("falseeeeeeeeaccualRemainingAmount"
	 * +accualRemainingUnits+",remainingFromAmount"+remainingUnit);
	 * result=false; } } else { result=false; } FLogger.info("StofLogger",
	 * "StofValidator", "validateRemainingUnit",
	 * "validateRemainingUnit method status "+result);
	 * FLogger.info("StofLogger", "StofValidator", "validateRemainingUnit",
	 * "validateRemainingUnit method end"); return result; }
	 */

	public FundDetailsPO getFundDetailsFromFundName(String fundName, List<FundDetailsPO> fundDetailsVOList) {
		FLogger.info("StofLogger", "StofValidator", "getFundDetailsFromFundName", "getFundDetailsFromFundName method start");

		for (FundDetailsPO fundDetailsVo : fundDetailsVOList) {
			if (fundDetailsVo.getFundDesc().trim().equalsIgnoreCase(fundName.trim())) {
				FLogger.info("StofLogger", "StofValidator", "getFundDetailsFromFundName", "getFundDetailsFromFundName method end");

				return fundDetailsVo;

			}
		}

		FLogger.info("StofLogger", "StofValidator", "getFundDetailsFromFundName", "getFundDetailsFromFundName method end with null response");

		return null;
	}

	public double validateSwitchTypeDropDown(String type, String unitOrAmount, String NAV) {

		FLogger.info("StofLogger", "StofValidator", "validateSwitchTypeDropDown", "validateSwitchTypeDropDown method start");

		double result = 0;
		SwitchTypeEnum switchTypeEnum = SwitchTypeEnum.valueOf(type.trim());

		switch (switchTypeEnum) {
			case Units:
				result = Double.parseDouble(NAV) * Double.parseDouble(unitOrAmount);
				break;

			case amount:
				result = Double.parseDouble(unitOrAmount);
				break;
		}

		FLogger.info("StofLogger", "StofValidator", "validateSwitchTypeDropDown", "validateSwitchTypeDropDown method end");

		return result;

	}

	public double roundUpToRequiredDecimal(double amount) {
		return (double) Math.round(amount * 100) / 100;

	}

	public double roundUpTo3RequiredDecimal(double amount) {
		return (double) Math.round(amount * 1000) / 1000;

	}

}
