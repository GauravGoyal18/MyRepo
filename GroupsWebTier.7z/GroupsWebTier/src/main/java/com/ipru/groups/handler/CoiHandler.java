package com.ipru.groups.handler;

import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ipru.IPruException;
import com.ipru.groups.po.CoiPO;
import com.ipru.groups.po.CoiPanListTotalSAPO;
import com.ipru.groups.po.CoiPannoPO;
import com.ipru.groups.po.NewTabCoiPO;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.utilities.SessionKeyConstants;
import com.ipru.groups.validators.CoiValidator;
import com.ipru.groups.vo.CoiPannoVO;
import com.ipru.groups.vo.CoiResponseDataVO;
import com.ipru.groups.vo.CoiSumAssuredVO;
import com.ipru.groups.vo.CoiVO;
import com.ipru.groups.vo.FtlToPdfVO;
import com.ipru.groups.vo.NewTabCoiVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class CoiHandler extends IneoBaseHandler {

	private static final String INFO_LOGGER_NAME = "COIStatementLogger";
	private static final String CLASS_NAME = "CoiHandler";
	private static final String ERROR_LOGGER_NAME = "COIStatementLogger";
	//Gson gson = new GsonBuilder().serializeNulls();
	//Gson gson = new GsonBuilder().enableComplexMapKeySerialization().create();

	@MethodPost
	public Event getBizRequestForCoiOnLoad(RequestContext context) throws Exception {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiKnowYourPolicy", "Method start");

		String selectedOption = null;

		selectedOption = (String) context.getFlowScope().get("selectedOption");

		context.getFlowScope().put("Response", selectedOption);

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiKnowYourPolicy", "Method end");

		return success();
	}

	@MethodPost
	public Event getBizRequestForCoiKnowYourPolicy(RequestContext context) throws Exception {
		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiKnowYourPolicy", "Method start");

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			if (request != null) {

				Type t = new TypeToken<CoiPO>() {
				}.getType();

				CoiPO coi = gsonJSON.fromJson(request.getReader(), t);
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiKnowYourPolicy", "got coi object");

				if (coi == null) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiKnowYourPolicy", "Found null data from UI");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}
				CoiValidator validator = new CoiValidator();
				String errorSuccessMessage = validator.validateCoiKnowYourPolicy(coi);

				if (StringUtils.isNotBlank(errorSuccessMessage)) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiKnowYourPolicy", "errorSuccessMessage is" + errorSuccessMessage);

					this.setValidationErrorMessages(errorSuccessMessage);

					throw new IPruException("Error", "GRPCOI01", errorSuccessMessage);

				}

				CoiVO coiVo = dozerBeanMapper.map(coi, CoiVO.class);
				if (coiVo == null) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiKnowYourPolicy", "Got null data after dozer bean mapping");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}

				Object[] paramArray = new Object[1];
				paramArray[0] = coiVo;

				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				context.getFlowScope().put("coiKnowYourPolDataBizReq", obj_bizReq);

			}

		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiKnowYourPolicy", "No Data Found.", e);

			throwINeoFlowException(e, "GRPCOI01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiKnowYourPolicy", "Method end");

		return success();

	}

	@MethodPost
	public Event getBizResponseForCoiKnowYourPolicy(RequestContext context) throws Exception {

		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiKnowYourPolicy", "Method start");

			String policyNumber = null;
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession == null) {

				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiKnowYourPolicy", "FOund null session");

				throw new IPruException("Error", "GRPCOI01", "Session expired");
			}

			String responseCheck = "";
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForCoiKnowYourPol");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiKnowYourPolicy", "FOund null or error responseCheck");
					throw new IPruException("Error", "GRPCOI01", "No Data Found.");
				}
				policyNumber = (String) bizRes.getTransferObjects().get("response1");
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiKnowYourPolicy", "policyNumber from database" + policyNumber);

			}
			context.getFlowScope().put("Response", policyNumber);

		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiKnowYourPolicy", "Some error occured", e);

			throwINeoFlowException(e, "GRPCOI01", context);
		}
		return success();

	}

	@MethodPost
	public Event getBizRequestForCoiSubmit(RequestContext context) throws Exception {

		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiSubmit", "Method start");

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			if (request != null) {

				Type t = new TypeToken<CoiPO>() {
				}.getType();

				CoiPO coi = gsonJSON.fromJson(request.getReader(), t);
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiSubmit", "got coi object");

				if (coi == null) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiSubmit", "Found null data from UI");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}
				CoiValidator validator = new CoiValidator();
				String errorSuccessMessage = validator.validateCoi(coi);

				if (StringUtils.isNotBlank(errorSuccessMessage)) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiSubmit", "errorSuccessMessage is" + errorSuccessMessage);

					this.setValidationErrorMessages(errorSuccessMessage);

					throw new IPruException("Error", "GRPCOI01", errorSuccessMessage);

				}

				CoiVO coiVo = dozerBeanMapper.map(coi, CoiVO.class);
				if (coiVo == null) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiSubmit", "Got null data after dozer bean mapping");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}

				SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
				Date date1 = format1.parse(coiVo.getDob());

				DateFormat targetFormat = new SimpleDateFormat("dd MMM yyyy");
				String formattedDate = targetFormat.format(date1);

				coiVo.setDob(formattedDate);

				Object[] paramArray = new Object[1];
				paramArray[0] = coiVo;

				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				context.getFlowScope().put("coiDataBizReq", obj_bizReq);

			}

		}
		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiSubmit", "Some error occured", e);

			throwINeoFlowException(e, "GRPCOI01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiSubmit", "Method end");

		return success();
	}

	@MethodPost
	public Event getBizResponseForCoiSubmit(RequestContext context) throws Exception {

		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiSubmit", "Method start");

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession == null) {

				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiSubmit", "FOund null session");

				throw new IPruException("Error", "GRPCOI01", "Session expired");

			}

			CoiResponseDataVO coi;
			String responseCheck = "";
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForCoi");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiSubmit", "FOund null or error responseCheck");
					throw new IPruException("Error", "GRPCOI01", "No Data Found.");
				}
				FtlToPdfVO ftlToPdf = (FtlToPdfVO) bizRes.getTransferObjects().get("response1");
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiSubmit", "coi from database" + ftlToPdf.getObjectData().toString());

				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiSubmit", "Putting in session");
				httpSession.setAttribute("statementDownloadData", ftlToPdf);
			}

			context.getFlowScope().put("Response", "success");

		}
		catch (Exception e) {

			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiSubmit", "Some error occured", e);

			throwINeoFlowException(e, "GRPCOI01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiSubmit", "Method end");

		return success();
	}

	@MethodPost
	public Event getBizRequestForCoiPanNoSubmit(RequestContext context) throws Exception {
		try {
				//String emailId=null;
			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSubmit", "Method start");

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			if (request != null) {

				Type t = new TypeToken<CoiPO>() {
				}.getType();

				CoiPO coi = gsonJSON.fromJson(request.getReader(), t);
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSubmit", "got coi object");

				if (coi == null) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSubmit", "Found null data from UI");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}
				//emailId=coi.getEmailId().toLowerCase();
				//coi.setEmailId(emailId);
				CoiValidator validator = new CoiValidator();
				String errorSuccessMessage = validator.validateCoiPanNo(coi);

				if (StringUtils.isNotBlank(errorSuccessMessage)) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSubmit", "errorSuccessMessage is" + errorSuccessMessage);

					this.setValidationErrorMessages(errorSuccessMessage);

					throw new IPruException("Error", "GRPCOI01", errorSuccessMessage);

				}

				CoiVO coiVo = dozerBeanMapper.map(coi, CoiVO.class);
				if (coiVo == null) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSubmit", "Got null data after dozer bean mapping");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}

				context.getFlowScope().put("coiVo", coiVo);

				Object[] paramArray = new Object[1];
				paramArray[0] = coiVo;

				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				context.getFlowScope().put("coiPanNoDataBizReq", obj_bizReq);

			}

		}

		catch (Exception e) {

			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSubmit", "Some error occured", e);

			throwINeoFlowException(e, "GRPCOI01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSubmit", "Method end");

		return success();

	}

	@MethodPost
	public Event getBizResponseForPanNoCoiSubmit(RequestContext context) throws Exception {
		String METHOD_NAME = "getBizResponseForEmailMobileSubmit";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						bizRes = (BizResponse) context.getFlowScope().get("bizResForPanNoCoiSubmit");

						if (bizRes != null) {
							responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throw new IPruException("Error", "GRPCOI01", "No Data Found.");

								//throwINeoFlowException(bizRes.getStatusVO(), context);
							}
							else {
								String isEmailMobileExistString = (String) bizRes.getTransferObjects().get("response1");

								if (StringUtils.isBlank(isEmailMobileExistString)){
									FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "isEmailMobileExistString is blank.");
									throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
								} else if(StringUtils.startsWith(isEmailMobileExistString, "ERROR")){
									FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, isEmailMobileExistString);
									throw new IPruException("Error","GRPCU01",isEmailMobileExistString);									
								}else {
									
									List<CoiResponseDataVO> coiList = null;
									Type listType = new TypeToken<ArrayList<CoiResponseDataVO>>() {}.getType();
									
									coiList = new Gson().fromJson(isEmailMobileExistString, listType);
									
									if(coiList != null){
										CoiResponseDataVO coiResponseDataVO = coiList.get(0);
										if(coiResponseDataVO != null){
											userVo.setPolicyNo(coiResponseDataVO.getPolicynumber());
											userVo.setClientId(coiResponseDataVO.getPolicynumber());
											userVo.setUsername(coiResponseDataVO.getNameLa());
											userVo.setClientName(coiResponseDataVO.getNameLa());
										}
									}
									
									CoiVO coiVO = (CoiVO) context.getFlowScope().get("coiVo");
									
									if (coiVO != null) {
										
										String emailId = coiVO.getEmailId();
										long mobileNo = coiVO.getMobileNo();

										userVo.setEmailId(emailId);
										userVo.setMobileNo(String.valueOf(mobileNo));

										GroupSecurityUtil.setAttributeInSession(context, "userVO", userVo);

										context.getFlowScope().put("Response", "Success");
									}
									else{
										FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "coiVo from context is null");
										throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
									}									
								}
							}
						} else {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
							throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
						}
					} else {
						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UserVO in session should not be null");
						throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
					}
				} else {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "session should not be null");
					throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
				}
			} else {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error","GRPCU01","Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPCU01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	@MethodPost
	public Event getBizRequestForCoiPanNoSave(RequestContext context) throws Exception {

		boolean isOTPValidated = false;
		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSave", "Method start");

			isOTPValidated = (Boolean) GroupSecurityUtil.getAttributeFromSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);

			if (!isOTPValidated) {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSave", "OTP is not validated.");
				throw new IPruException("Error", "GRPFP01", "Something went wrong. Please try again later.");
			}
			else {
				GroupSecurityUtil.removeAttributeInSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);
			}

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			if (request != null) {

				Type t = new TypeToken<CoiPO>() {
				}.getType();

				CoiPO coi = gsonJSON.fromJson(request.getReader(), t);
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSave", "got coi object");

				if (coi == null) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSave", "Found null data from UI");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}
				CoiValidator validator = new CoiValidator();
				String errorSuccessMessage = validator.validateCoiPanNo(coi);

				if (StringUtils.isNotBlank(errorSuccessMessage)) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSave", "errorSuccessMessage is" + errorSuccessMessage);

					this.setValidationErrorMessages(errorSuccessMessage);

					throw new IPruException("Error", "GRPCOI01", errorSuccessMessage);

				}

				CoiVO coiVo = dozerBeanMapper.map(coi, CoiVO.class);
				if (coiVo == null) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSave", "Got null data after dozer bean mapping");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}

				Object[] paramArray = new Object[1];
				paramArray[0] = coiVo;

				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);

				context.getFlowScope().put("coiPanNoDataBizReq", obj_bizReq);

			}

		}

		catch (Exception e) {

			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSave", "Some error occured", e);

			throwINeoFlowException(e, "GRPCOI01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoSave", "Method end");

		return success();

	}

	@MethodPost
	public Event getBizResponseForPanNoCoiSave(RequestContext context) throws Exception {

		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForPanNoCoiSave", "Method start");

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession == null) {

				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForPanNoCoiSave", "FOund null session");

				throw new IPruException("Error", "GRPCOI01", "Session expired");

			}

			CoiResponseDataVO coi;
			String responseCheck = "";
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForPanNoCoi");
			Gson gsonJSON = new GsonBuilder().serializeNulls().create();
			if (bizRes != null) {

				@SuppressWarnings("unchecked")
				List<CoiResponseDataVO> responseList = (List<CoiResponseDataVO>) bizRes.getTransferObjects().get("response1");
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForPanNoCoiSave", "coi from database");

				if (CollectionUtils.isNotEmpty(responseList)) {
					List<CoiPannoPO> coiPOList = new ArrayList<CoiPannoPO>();
					CoiPannoPO coiDataPO = null;

					for (CoiResponseDataVO coiResponseDataVO : responseList) {

						coiDataPO = dozerBeanMapper.map(coiResponseDataVO, CoiPannoPO.class);

						coiPOList.add(coiDataPO);

					}
					/*String totalSumAssured = (String) context.getFlowScope().get("totalSumAssured");
					CoiPanListTotalSAPO coiPanListTotalSAPO = new CoiPanListTotalSAPO();
					coiPanListTotalSAPO.setCoiPOList(coiPOList);
					coiPanListTotalSAPO.setTotalSumAssured(totalSumAssured);*/

					if (CollectionUtils.isEmpty(coiPOList)) {
						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForPanNoCoiSave", "coiPOList should not be null");
						throw new IPruException("Error", "GRPCOI01", "No data found for given Pan Number!");
					}

					context.getFlowScope().put("Response", gsonJSON.toJson(coiPOList));

				}
				else {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForPanNoCoiSave", "response should not be null");
					throw new IPruException("Error", "GRPCOI01", "No data found for given Pan Number!");
				}

				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForPanNoCoiSave", "Putting in session");
			}

		}
		catch (Exception e) {

			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForPanNoCoiSave", "Some error occured", e);

			throwINeoFlowException(e, "GRPCOI01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForPanNoCoiSave", "Method end");

		return success();
	}

	@MethodPost
	public Event getBizRequestForCoiPDFDownload(RequestContext context) throws Exception {
		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoPDFDownload", "Method start");

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			if (request != null) {

				Type t = new TypeToken<CoiPannoPO>() {
				}.getType();

				CoiPannoPO coipanpo = gsonJSON.fromJson(request.getReader(), t);
				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoPDFDownload", "got coi object");

				if (coipanpo == null) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoPDFDownload", "Found null data from UI");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}
				// CoiValidator validator=new CoiValidator();
				/*
				 * String errorSuccessMessage=validator.validateCoiPanNo(coi);
				 * if (StringUtils.isNotBlank(errorSuccessMessage)) {
				 * FLogger.error("COIStatementLogger", "CoiHandler",
				 * "getBizRequestForCoiPanNoPDFDownload",
				 * "errorSuccessMessage is"+errorSuccessMessage);
				 * this.setValidationErrorMessages(errorSuccessMessage); throw
				 * new IPruException("Error", "GRPCOI01", errorSuccessMessage);
				 * }
				 */

				CoiPannoVO coipanVo = dozerBeanMapper.map(coipanpo, CoiPannoVO.class);
				if (coipanVo == null) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForCoiPanNoPDFDownload", "Got null data after dozer bean mapping");

					throw new IPruException("Error", "GRPCOI01", "Somethig went wrong");
				}

				Object[] paramArray = new Object[1];
				paramArray[0] = coipanVo;

				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);
				context.getFlowScope().put("coiPDFDOwnloadBizReq", obj_bizReq);

			}

		}

		catch (Exception e) {

			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiSubmit", "Some error occured", e);

			throwINeoFlowException(e, "GRPCOI01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiSubmit", "Method end");

		return success();

	}

	@MethodPost
	public Event getBizResponseForCoiPDFDownload(RequestContext context) throws Exception {

		try {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiPDFDownload", "Method start");

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			if (httpSession == null) {

				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiPDFDownload", "FOund null session");

				throw new IPruException("Error", "GRPCOI01", "Session expired");

			}

			CoiResponseDataVO coi;
			String responseCheck = "";
			BizResponse bizRes = new BizResponse();
			bizRes = (BizResponse) context.getFlowScope().get("bizResForCoiPDFDownload");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {

					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiPDFDownload", "FOund null or error responseCheck");
					throw new IPruException("Error", "GRPCOI01", "No data found!");
				}
				FtlToPdfVO ftlToPdf = (FtlToPdfVO) bizRes.getTransferObjects().get("response1");

				if (ftlToPdf == null) {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiPDFDownload", "ftlToPdf should not be null");
					throw new IPruException("Error", "CRAI01", "No data found!");
				}

				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiPDFDownload", "coi from database" + ftlToPdf.getObjectData().toString());

				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiPDFDownload", "Putting in session");
				httpSession.setAttribute("statementDownloadData", ftlToPdf);

				context.getFlowScope().put("Response", "success");
			}

		}
		catch (Exception e) {

			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiPDFDownload", "Some error occured", e);

			throwINeoFlowException(e, "GRPCOI01", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForCoiPDFDownload", "Method end");

		return success();
	}

	@MethodPost
	public Event getBizRequestForCoiDownloadDocFlagPdf(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizRequestForCoiDownloadDocFlagPdf";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");
		/* Gson gson = new Gson(); */

		NewTabCoiPO newTabCoiPO = null;
		String templateId = null;
		String policynumber = null;
		String loanAcNO=null;
		
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES ;
		
		try {

			/* if (context != null) { */
			
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			if (httpSession != null) {
				IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
				
				
				if (userVo != null) {
					/*Type t = new TypeToken<NewTabCoiPO>() {
					}.getType();

					newTabCoiPO = gsonJSON.fromJson(request.getReader(), t);*/
					// policyNo = userVo.getPolicyNo();
					//policynumber = "21144665";
					// clientId = userVo.getClientId();
					//templateId = "GT5";
					templateId =prop.getProperty("templateId");
					//loanAcNO="LPBNG00037202810";

					newTabCoiPO = gsonJSON.fromJson(request.getReader(), NewTabCoiPO.class);// handle
																							// null
																							// //
																							// newTabCoiPO

					if (newTabCoiPO == null) {
						throw new Exception();
					}

					//newTabCoiPO.setpolicynumber(policynumber);
					newTabCoiPO.setLoanAcNO(newTabCoiPO.getEmployeeId());
					newTabCoiPO.setTemplateId(templateId);

					NewTabCoiVO newTabCoiVO = dozerBeanMapper.map(newTabCoiPO, NewTabCoiVO.class);// handle
																									// null
																									// newTabCoiVO

					if (newTabCoiVO == null) {
						throw new Exception();
					}
					Object[] paramArray = new Object[1];
					paramArray[0] = newTabCoiVO;
					BizRequest obj_bizReq = new BizRequest();
					obj_bizReq.addbusinessObjects("service-obj1", paramArray);
					context.getFlowScope().put("coiDownloadDocFlagPdfBizReq", obj_bizReq);

				}
				else {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "userVo should not be null");
					throw new IPruException("Error", "GRPBTC", "userVo should not be null");
				}
			}
			else {
				FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "httpSession should not be null");
				throw new IPruException("Error", "GRPBTC", "httpSession should not be null");
			}
			/*
			 * } else { FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME,
			 * METHOD_NAME, "Context should not be null"); throw new
			 * IPruException("Error", "GRPBTC", "Context should not be null"); }
			 */
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPBTC", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return success();
	}

	@MethodPost
	public Event getBizResponseForCoiDownloadDocFlagPdf(RequestContext context) throws Exception {
		final String METHOD_NAME = "getBizResponseForCoiDownloadDocFlagPdf";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {

			bizRes = (BizResponse) context.getFlowScope().get("bizResForCoiDownloadDocFlagPdf");
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error(ERROR_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Error came while getting response from service");

					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {

					String strDataJson = (String) bizRes.getTransferObjects().get("response1");
					//String strDataJson="http://10.51.0.72:8080/ClickCRM_GT5L/TokenAuthenticateServlet?tokenId=3FC3964551F04B5A9817BD59441885E4";
					if (StringUtils.isEmpty(strDataJson)) {
						FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "responseCheck null");
						throw new IPruException("Error", "GRPBTC", "Some Error Occured");
					}
					responseCheck = gsonJSON.toJson(strDataJson);

					// CHECK NULL responseCheck
					if (responseCheck == null) {
						throw new Exception();
					}
					context.getFlowScope().put("Response", responseCheck);

				}
			}
			else {

				FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "url null");

				throw new IPruException("Error", "GRPBTC", "Some Error Occured");
			}

		}
		catch (Exception e) {

			FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came", e);
			throwINeoFlowException(e, "GRPBTC", context);
		}

		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, " Method end");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		String METHOD_NAME = "setOtpCallBacks";
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		paramBean.setFunctionality("COI_PAN");
		setTransactionalOTPCallback(Boolean.TRUE);
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
	}

}
