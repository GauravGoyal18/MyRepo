package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;

import com.ipru.IPruException;
import com.ipru.groups.po.GstDropDownPO;
import com.ipru.groups.po.GstSaveRequestPO;
import com.ipru.groups.po.GstSubmitPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.utilities.GstUtil;
import com.tcs.logger.FLogger;

public class GstValidator {

	public String validateGstSubmit(GstSaveRequestPO gstSaveRequestPO, List<String> policyList) throws IPruException, ParseException {
		FLogger.info("GstLogger", "GstValidator", "validateGstSubmit", "validateGstSubmit Method Started");

		GstSubmitPO gstSubmitPO = gstSaveRequestPO.getGstFormJson();

		String status = gstSubmitPO.getIsRegisteredUser();

		if (!validateAlpSpaceField(gstSubmitPO.getCustomerName(), 100, 1)) {
			FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Customer Name data");
			throw new IPruException("Error", "GRPT01", "Invalid Customer Name data");
		}
		if (!validateAlpNumField(gstSubmitPO.getPolicyNumber(), 100, 1) && !(policyList.contains(gstSubmitPO.getPolicyNumber()))) {
			FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Policy Number");
			throw new IPruException("Error", "GRPT01", "Invalid Policy Number");
		}

		if (!dropDownCheck(gstSubmitPO.getCob())) {
			FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Constitution of business");
			throw new IPruException("Error", "GRPT01", "Invalid Constitution of business");
		}
		if (gstSubmitPO.getCob().equalsIgnoreCase("others")) {
			if (!validateAlpNumSpaceField(gstSubmitPO.getOtherCOB(), 100, 1)) {
				FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Constitution of business");
				throw new IPruException("Error", "GRPT01", "Invalid Constitution of business");
			}
		}

		if (!validatePanField(gstSubmitPO.getPanNumber(), 20, 1)) {
			FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid PAN Number");
			throw new IPruException("Error", "GRPT01", "Invalid PAN Number");
		}
		if (!dropDownCheck(gstSubmitPO.getCustomerType())) {
			FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Customer type");
			throw new IPruException("Error", "GRPT01", "Invalid Customer type");
		}
		if (gstSubmitPO.getCustomerType().equalsIgnoreCase("others1")) {
			if (!validateAlpNumSpaceField(gstSubmitPO.getOtherCustomerType(), 100, 1)) {
				FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Customer type");
				throw new IPruException("Error", "GRPT01", "Invalid Customer type");
			}
		}

		/*
		 * if (!validateNumericField(gstSubmitPO.getGstExemptionNo(),100,1)) {
		 * FLogger.error("GstLogger", "GstValidator", "validateGstSubmit",
		 * "Exception Occured,Invalid GST Exemption Notification Number"); throw
		 * new IPruException("Error", "GRPT01",
		 * "Invalid GST Exemption Notification Number"); }
		 */
		/*
		 * if (!validateAlpNumSpaceField(gstSubmitPO.getTotalNoGst(),100,1)) {
		 * FLogger.error("GstLogger", "GstValidator", "validateGstSubmit",
		 * "Exception Occured,Invalid Total GST Number data"); throw new
		 * IPruException("Error", "GRPT01", "Invalid Total GST Number data"); }
		 */

		if (!validateAlpSpaceField(gstSubmitPO.getDeclarationName(), 100, 1)) {
			FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Declaration Name");
			throw new IPruException("Error", "GRPT01", "Invalid Declaration Name");
		}
		if (!validateAlpSpaceField(gstSubmitPO.getDeclarationDesignation(), 100, 1)) {
			FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Declaration Designation");
			throw new IPruException("Error", "GRPT01", "Invalid Declaration Designation");
		}
		if (!validateDate(gstSubmitPO.getDeclarationDate())) {
			FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Declaration Designation");
			throw new IPruException("Error", "GRPT01", "Invalid Declaration Designation");
		}

		if (status != null && status.equalsIgnoreCase("YES")) {
			if (!validateGstinOrUinField(gstSubmitPO.getGstinOrUin(), gstSubmitPO.getStateCode(), gstSubmitPO.getPanNumber(), 15, 1)) {
				FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid GSTIN or UIN data");
				throw new IPruException("Error", "GRPT01", "Invalid GSTIN or UIN data");
			}
			if (!validateAddressField(gstSubmitPO.getAddress(), 100, 1)) {
				FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Address");
				throw new IPruException("Error", "GRPT01", "Invalid Address");
			}
			if (!validateAlpNumField(gstSubmitPO.getPinCode(), 6, 1)) {
				FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Pin Number");
				throw new IPruException("Error", "GRPT01", "Invalid Pin Number");
			}
			if (!dropDownCheck(gstSubmitPO.getRegistrationStatus())) {
				FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid Registration migration status (GST)");
				throw new IPruException("Error", "GRPT01", "Invalid Registration migration status (GST)");
			}
			if (!dropDownCheck(gstSubmitPO.getState())) {
				FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid State");
				throw new IPruException("Error", "GRPT01", "Invalid State");
			}
			if (!stateCodeCheck(gstSubmitPO.getStateCode(), gstSubmitPO.getState())) {
				FLogger.error("GstLogger", "GstValidator", "validateGstSubmit", "Exception Occured,Invalid State Code");
				throw new IPruException("Error", "GRPT01", "Invalid State Code");
			}
		}

		FLogger.info("GstLogger", "GstValidator", "validateGstSubmit", "validateGstSubmit Method Started");
		return null;
	}

	private boolean validateAlpSpaceField(String val, Integer num, Integer min) {

		if (StringUtils.isAlphaSpace(val) && CommonValidationUtil.ValidateMaxLength(val, num) && CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		}
		else {
			return false;
		}

	}

	private boolean validateAlpNumField(String val, Integer max, Integer min) {

		if (StringUtils.isAlphanumeric(val) && CommonValidationUtil.ValidateMaxLength(val, max) && CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		}
		else {
			return false;
		}

	}

	private boolean validatePanField(String val, Integer max, Integer min) {

		if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.COMPANYPAN_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, max)
				&& CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;
		}
		else {
			return false;
		}

	}
	
	private boolean validateAddressField(String val, Integer max, Integer min) {

		if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.ADDRESS_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, max)
				&& CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;
		}
		else {
			return false;
		}

	}

	private boolean validateGstinOrUinField(String val, String stateCode, String pan, Integer max, Integer min) {

		if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.GSTIN_OR_UIN) && CommonValidationUtil.ValidateMaxLength(val, max)
				&& CommonValidationUtil.ValidateMinLength(val, min)) {
			String sc = val.substring(0, 2);
			String pn = val.substring(2, val.length() - 3);
			String last = val.substring(val.length() - 2, val.length() - 1);

			if (sc.equalsIgnoreCase(stateCode) && pn.equalsIgnoreCase(pan) && last.equalsIgnoreCase("Z")) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}

	}

	private boolean validateNumericField(String val, Integer num, Integer min) {

		if (CommonValidationUtil.ValidateNumeric(val) && CommonValidationUtil.ValidateMaxLength(val, num) && CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		}
		else {
			return false;
		}

	}

	private boolean validateAlpNumSpaceField(String val, Integer num, Integer min) {

		if (StringUtils.isAlphanumericSpace(val) && CommonValidationUtil.ValidateMaxLength(val, num) && CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		}
		else {
			return false;
		}

	}

	private boolean validateDate(String date) throws ParseException {
		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);

		Date date1 = format1.parse(date);

		Date today = new Date();

		if (date1.before(today)) {

			if (CommonValidationUtil.ValidateRequired(date)) {

				return true;
			}
			else {

				return false;
			}
		}
		else {
			return false;
		}
	}

	private boolean dropDownCheck(String dropDown) {

		GstDropDownPO gstDropDownPO = new GstDropDownPO();
		GstUtil util = new GstUtil();
		gstDropDownPO = util.dropDownList();

		if (gstDropDownPO.getCob().contains(dropDown)) {
			return true;
		}
		else if (gstDropDownPO.getCustType().contains(dropDown)) {
			return true;
		}
		else if (gstDropDownPO.getState().contains(dropDown)) {
			return true;
		}
		else if (gstDropDownPO.getRegistrationStatusList().contains(dropDown)) {
			return true;
		}
		else {
			return false;
		}

	}

	private boolean stateCodeCheck(String stateCode, String state) {

		GstDropDownPO gstDropDownPO = new GstDropDownPO();
		GstUtil util = new GstUtil();
		gstDropDownPO = util.dropDownList();

		String sCode = (String) gstDropDownPO.getStateAndStateCode().get(state);

		if (sCode.equalsIgnoreCase(stateCode)) {
			return true;
		}
		else {
			return false;
		}

	}

}
