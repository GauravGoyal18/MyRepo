package com.ipru.groups.handler;

import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.ServiceExpressPO;
import com.ipru.groups.validators.ServiceExpressValidator;
import com.ipru.groups.vo.ServiceExpressVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class serviceExpressHandler extends IneoBaseHandler {


	private static final long serialVersionUID = 1L;
	//private static final Object ServiceExpressVO = null;

	@MethodPost
	public Event getBizRequestServiceExpress(RequestContext context) throws Exception {
		FLogger.info("ServiceExpressLogger", "serviceExpressHandler", "getBizRequestServiceExpress", "Method start ");
		
			Gson gson = new Gson();
			
			Calendar cal = Calendar.getInstance();
			Date todaysDate  = (Date) cal.getTime();
			
			try {
				if (context != null) {
			
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			String userID=null;
			String userRole=null;
			String policyNumber=null;
			String clientID=null;
			
			if (httpSession != null) {	
			
				IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null) {
					clientID = userVo.getClientId();
					policyNumber = userVo.getPolicyNo();
					userRole = userVo.getRoles();
					userID=userVo.getUserId();
					
					HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
					if (request != null) {
						ServiceExpressPO serviceExpressPO = gson.fromJson(request.getReader(), ServiceExpressPO.class);
						ServiceExpressValidator serviceExpressValidator = new ServiceExpressValidator();

						String validation = serviceExpressValidator.validateServiceExpressPageSubmitRequestPO(context, serviceExpressPO);
						if (StringUtils.isNotBlank(validation)) {
							//FLogger.error("ServiceExpressError", "serviceExpressHandler", "getBizRequestServiceExpress", "Validation errors : "+validation);
							/*this.setValidationErrorMessages(validation);
							throwINeoFlowException(new ServiceException("GRPPFCC"), context); */
							FLogger.error("ServiceExpressLogger", "serviceExpressHandler", "getBizRequestServiceExpress", "validation fails"+validation);
							throwINeoFlowException(new ServiceException("GRPSTF"),"GRPSTF", context);
						
					
					}
						
							ServiceExpressVO serviceExpressVO = dozerBeanMapper.map(serviceExpressPO, ServiceExpressVO.class);
							
							serviceExpressVO.setUserID(userID);
							serviceExpressVO.setUser_role(userRole);
							serviceExpressVO.setPolicy_number(policyNumber);
							serviceExpressVO.setCreated_date(todaysDate);
							serviceExpressVO.setClient_ID(clientID);
							
							Object[] paramArray = new Object[1];
							
							if (serviceExpressVO != null) {
							
								paramArray[0] = serviceExpressVO;
							
							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);
					
							context.getFlowScope().put("saveBizReq", obj_bizReq);
							}
							else {
								FLogger.error("ServiceExpressError", "serviceExpressHandler", "getBizRequestServiceExpress", "serviceExpressVO should not be null");
								throw new IPruException("Error", "GRPT01", "serviceExpressVO should not be null");
							}

						}
						else {

							FLogger.error("ServiceExpressError", "serviceExpressHandler", "getBizRequestServiceExpress", "request should not be null");
							throw new IPruException("Error", "GRPT01", "request should not be null");
						}
					}
					else {
						FLogger.error("ServiceExpressError", "serviceExpressHandler", "getBizRequestServiceExpress", "userVo should not be null");
						throw new IPruException("Error", "GRPT01", "userVo should not be null");
					}
				}
				else {
					FLogger.error("ServiceExpressError", "serviceExpressHandler", "getBizRequestServiceExpress", "httpSession should not be null");
					throw new IPruException("Error", "GRPT01", "httpSession should not be null");
				}
			}
			else {
				FLogger.error("ServiceExpressError", "serviceExpressHandler", "getBizRequestServiceExpress", "Context should not be null");
				throw new IPruException("Error", "GRPT01", "Context should not be null");
			}
		}
			
			catch(Exception e){
				e.printStackTrace();
				FLogger.error("ServiceExpressError", "serviceExpressHandler", "getBizRequestServiceExpress", "Exception came ", e);
				throwINeoFlowException(e, "GRPT01", context);
			}
			FLogger.info("ServiceExpressLogger", "serviceExpressHandler", "getBizRequestServiceExpress", " Method End ");
			return success();
					
			}
				
			
	
	public Event getBizResponseForServiceExpressSubmit(RequestContext context) throws Exception {
		
		FLogger.info("ServiceExpressLogger", "ServiceExpressHandler", "getBizResponseForServiceExpressSubmit", "Method start");
		ServiceExpressVO serviceExpressVO = new ServiceExpressVO();
		ServiceExpressPO serviceExpressPO = new ServiceExpressPO();

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		
		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForSubmitExpress");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error("ServiceExpressError", "ServiceExpressHandler", "getBizResponseForServiceExpressSubmit", "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {
						serviceExpressVO = (ServiceExpressVO) bizRes.getTransferObjects().get("response1");
						if (serviceExpressVO != null) {
							dozerBeanMapper.map(serviceExpressVO, serviceExpressPO);
						}
						String callJsonString = gsonJSON.toJson(serviceExpressPO, ServiceExpressPO.class);
						FLogger.info("ServiceExpressLogger", "ServiceExpressHandler", "getBizResponseForServiceExpressSubmit", "callJsonString::" + callJsonString);
						context.getFlowScope().put("Response", callJsonString);
					}
				}
				else {
					FLogger.error("ServiceExpressError", "ServiceExpressHandler", "getBizResponseForServiceExpressSubmit", "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error("ServiceExpressError", "ServiceExpressHandler", "getBizResponseForServiceExpressSubmit", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ServiceExpressError", "ServiceExpressHandler", "getBizResponseForServiceExpressSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GRYY02", context);
		}
		FLogger.info("ServiceExpressLogger", "ServiceExpressHandler", "getBizResponseForServiceExpressSubmit", "Method end");
				
		return success();
		
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub
	}
}
