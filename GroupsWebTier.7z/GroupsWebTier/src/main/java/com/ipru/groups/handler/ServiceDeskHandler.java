package com.ipru.groups.handler;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.NomineePMJJBYPO;
import com.ipru.groups.po.ServiceDeskPO;
import com.ipru.groups.vo.NomineePMJJBYVO;
import com.ipru.groups.vo.ServiceDeskVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ServiceDeskHandler extends IneoBaseHandler {

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,
			RequestContext ObjContext) {
		// TODO Auto-generated method stub
		
	}
	
	@MethodPost
	public Event getRequestServiceDeskData(RequestContext context) throws Exception {
		FLogger.info("ServiceDeskLogger", "ServiceDeskHandler", "getRequestServiceDeskData", " Method Start ");
     
		try {

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
	
			IPruUser userVo = new IPruUser();
			String policyNo = null;
		
			if (httpSession != null) {
				   userVo = (IPruUser) httpSession.getAttribute("userVO");
			       policyNo=  userVo.getPolicyNo();
				
			}
			else {
				FLogger.error("ServiceDeskLogger", "ServiceDeskHandler", "getRequestServiceDeskData", "session is null");
				throw new IPruException("Error", "GRPCL03", "No Data Found");
			}	
					
					
					
					Object[] paramArray = new Object[1];
					paramArray[0] = policyNo;
					BizRequest obj_bizReq = new BizRequest();
					obj_bizReq.addbusinessObjects("service-obj1", paramArray);
                    context.getFlowScope().put("ServiceDeskBizReqOnLoad", obj_bizReq);
				
		

		}
		catch (Exception e) {
			FLogger.error("ServiceDeskLogger", "ServiceDeskHandler", "getRequestServiceDeskData", "context should not be null" + e);
			throwINeoFlowException(e, "GRPCL03", context);
		}
		
		FLogger.info("ServiceDeskLogger", "ServiceDeskHandler", "getRequestServiceDeskData", " Method End ");
		return success();
	}
	
	@MethodPost
	public Event getBizResponServiceDeskOnLoad(RequestContext context) throws Exception {
		
		FLogger.info("ServiceDeskLogger", "ServiceDeskHandler", "getResponsePrePopulateNomineePMJJBY", " Method Start ");
		
		Gson gson = new Gson();
		ServiceDeskVO serviceVO  =null;
		ServiceDeskPO serviceDeskPO=null;
    
	try{
		BizResponse response = new BizResponse();
		response = (BizResponse) context.getFlowScope().get("bizResForServiceDeskOnLoad");
					
		 serviceVO =  (ServiceDeskVO) response.getTransferObjects().get("response1");
		
		if(serviceVO!=null){			
			
			serviceDeskPO=dozerBeanMapper.map(serviceVO, ServiceDeskPO.class);
		

		}else{
			FLogger.info("ServiceDeskLogger", "ServiceDeskHandler", "getBizResponServiceDeskOnLoad", "ServiceDesk Data  is null");
			//context.getFlowScope().put("Response", gsonJSON.toJson(serviceDeskPO));
			/*throw new IPruException("Error", "GRPCL03", "No data found");*/
		}
		
		context.getFlowScope().put("Response", gsonJSON.toJson(serviceDeskPO));
     }
     catch(Exception e ){
    	 FLogger.info("ServiceDeskLogger", "ServiceDeskHandler", "getBizResponServiceDeskOnLoad", "context should not be null" + e);
			throwINeoFlowException(e, "GRPCL03", context);
    	 
     }
		FLogger.info("ServiceDeskLogger", "ServiceDeskHandler", "getBizResponServiceDeskOnLoad", " Method End ");
		return success();
	}
	
	
}
