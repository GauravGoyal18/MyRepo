package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.grpswitch.bean.SwitchTransactionPO;
import com.ipru.groups.grpswitch.bean.SwitchTransactionVO;
import com.ipru.groups.po.ServiceTrackerTransformerPO;
import com.ipru.groups.po.SwitchTrackerPO;
import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.SwitchTrackerVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class SwitchTrackerHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@MethodPost
	public Event getBizRequestOnLoad(RequestContext context) throws Exception {

		FLogger.info("switchTrackerlogger", "switchTrackerHandler", "getBizRequestOnLoad", "getBizRequestOnLoad Method Start");
		Gson gson = new Gson();

		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
				String clientId = null;
				String policyNo = null;

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						 policyNo = userVo.getPolicyNo();
						 clientId = userVo.getClientId();
						

						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

						if (request != null) {
							SwitchTransactionVO switchTransactionVO = new SwitchTransactionVO();
							switchTransactionVO.setClientId(clientId);
							switchTransactionVO.setPolicyNo(policyNo);

							Object[] paramArray = new Object[1];

							if (switchTransactionVO != null) {
								paramArray[0] = switchTransactionVO;
								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);
								context.getFlowScope().put("switchtrackerBizReqOnLoad", obj_bizReq);
							}
							else {
								FLogger.error("switchTrackerlogger", "switchTrackerHandler", "getBizRequestOnLoad", "switchTrackerVO should not be null");
								throw new IPruException("Error", "GRPT01", "trackervo should not be null");
							}

						}
						else {

							FLogger.error("switchTrackerlogger", "switchTrackerHandler", "getBizRequestOnLoad", "request should not be null");
							throw new IPruException("Error", "GRPT01", "request should not be null");
						}
					}
					else {
						FLogger.error("switchTrackerlogger", "switchTrackerHandler", "getBizRequestOnLoad", "userVo should not be null");
						throw new IPruException("Error", "GRPT01", "userVo should not be null");
					}
				}
				else {
					FLogger.error("switchTrackerlogger", "switchTrackerHandler", "getBizRequestOnLoad", "httpSession should not be null");
					throw new IPruException("Error", "GRPT01", "httpSession should not be null");
				}
			}
			else {
				FLogger.error("switchTrackerlogger", "switchTrackerHandler", "getBizRequestOnLoad", "Context should not be null");
				throw new IPruException("Error", "GRPT01", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("switchTrackerlogger", "switchTrackerHandler", "getBizRequestOnLoad", "Exception came ", e);
			throwINeoFlowException(e, "GRPT01", context);
		}
		FLogger.info("switchTrackerlogger", "switchTrackerHandler", "getBizRequestOnLoad", "onEntry of getBizRequestOnLoad Method End ");
		return success();
	}

	@MethodPost
	public Event getBizResponsetOnLoad(RequestContext context) throws Exception {

		FLogger.info("switchTrackerlogger", "switchTrackerHandler", "getBizResponsetOnLoad", "Method start");

		List<FundMasterVO> fundMasterList = null;
		
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		
		
		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForSubmitswitchTrackerOnLoad");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error("switchTrackerlogger", "switchTrackerHandler", "getBizResponsetOnLoad", "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {
						
						List<SwitchTrackerVO> switchTrackerVOList = (List<SwitchTrackerVO>) bizRes.getTransferObjects().get("response1");
						
						List<SwitchTrackerPO> switchTrackerPOList = new ArrayList<SwitchTrackerPO>();
						if (switchTrackerVOList != null) {
							fundMasterList = (List<FundMasterVO>)context.getExternalContext().getApplicationMap().get(ContextKeyConstants.FUND_MASTER_LIST);
							Map<String,FundMasterVO> fundCodeNameMap = this.getFundCodeNameMap(fundMasterList);
							
							for (SwitchTrackerVO switchTrackerVO : switchTrackerVOList) {
								
								SwitchTrackerPO switchTrackerPO = new SwitchTrackerPO();
								
								switchTrackerPO = dozerBeanMapper.map(switchTrackerVO, SwitchTrackerPO.class);
								
								String toFundCode = switchTrackerPO.getToFundCode();
								String fromFundCode = switchTrackerPO.getFromFundCode();
								
								switchTrackerPO.setToFundCode(fundCodeNameMap.get(toFundCode).getFundName());
								switchTrackerPO.setFromFundCode(fundCodeNameMap.get(fromFundCode).getFundName());
								
								switchTrackerPOList.add(switchTrackerPO);
							}

						}
						String callJsonString = gsonJSON.toJson(switchTrackerPOList);
						FLogger.info("switchTrackerlogger", "switchTrackerHandler", "getBizResponsetOnLoad", "callJsonString::" + callJsonString);
						context.getFlowScope().put("Response", callJsonString);
					}
				}
				else {
					FLogger.error("switchTrackerlogger", "switchTrackerHandler", "getBizResponsetOnLoad", "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error("switchTrackerlogger", "switchTrackerHandler", "getBizResponsetOnLoad", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("switchTrackerlogger", "switchTrackerHandler", "getBizResponsetOnLoad", "Exception came ", e);
			throwINeoFlowException(e, "GRYY02", context);
		}
		FLogger.info("switchTrackerlogger", "switchTrackerHandler", "getBizResponsetOnLoad", "Method end");

		return success();

	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}
	
	public Map<String,FundMasterVO> getFundCodeNameMap(List<FundMasterVO> fundMasterList)  {
		
		Map<String,FundMasterVO> map = new HashMap<String,FundMasterVO>();
		for(FundMasterVO fundMaster : fundMasterList){
			map.put(fundMaster.getFundCode(), fundMaster);
		}
		
		return map;
		
	}
}
