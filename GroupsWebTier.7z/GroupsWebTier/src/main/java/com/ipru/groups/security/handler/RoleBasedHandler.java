package com.ipru.groups.security.handler;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.groups.exception.GroupSecurityException;
import com.ipru.groups.handler.IneoBaseHandler;

import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.ipru.security.user.PolicyDetails;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class RoleBasedHandler extends IneoBaseHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Session session = null;
	private static Properties constantsProp = null;

	static {
		constantsProp = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
		if (constantsProp == null) {
			constantsProp = new Properties();
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
				constantsProp.load(fis);
			}
			catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			catch (IOException e) {
				e.printStackTrace();
			}
			finally {
				if (fis != null) {
					try {
						fis.close();
					}
					catch (IOException e) {
						e.printStackTrace();
					}
					finally {
						fis = null;
					}
				}
			}
		}
	}

	@MethodPost
	public Event getBizRequestForRole(RequestContext context) {
		FLogger.info("securityLogger", "RoleBasedHandler", "getBizRequestForRole(RequestContext context)", "##### Entering method getBizRequestForRole #####");

		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		HttpServletRequest request = ((HttpServletRequest) context.getExternalContext().getNativeRequest());
		IPruUser userVO = (IPruUser) httpSession.getAttribute("userVO");
		IPruUser user = new IPruUser();
		user = userVO;
		String roles = userVO.getRoles();
		FLogger.info("securityLogger", "RoleBasedHandler", "getBizRequestForRole(RequestContext context)", "User Roles ::" + roles);

		String browserDetails = (String) request.getHeader("User-Agent");
		user.setLoginTime(new Date());
		user.setBrowserDetails(browserDetails);
		Object[] paramArray = new Object[1];
		paramArray[0] = user;

		BizRequest obj_bizReq = new BizRequest();
		obj_bizReq.addbusinessObjects("service-obj1", paramArray);

		context.getFlowScope().put("roleBizRequest", obj_bizReq);
		FLogger.info("securityLogger", "RoleBasedHandler", "getBizRequestForRole(RequestContext context)", "##### Leaving method getBizRequestForRole #####");

		return success();
	}

	@MethodPost
	public Event getBizResponseForRole(RequestContext context) {
		BizResponse bizRes = new BizResponse();
		BizResponse bizResForFieldAccess = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVo = new IPruUser();
				List<FieldAccessMappingVO> fieldAccessMappingList = null;
				if (httpSession != null) {
					userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						bizRes = (BizResponse) context.getFlowScope().get("bizResForRole");
						if (bizRes != null) {
							responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
							}
							else {
								userVo = (IPruUser) bizRes.getTransferObjects().get("response1");
								if (userVo != null) {
									String loginWithEmailMobile = userVo.getLoginThroughUserIdEmailMobile();
									String cons=constantsProp.getProperty("LOGIN_EMAIL_MOBILE");
									
									if (loginWithEmailMobile.equals(constantsProp.getProperty("LOGIN_EMAIL_MOBILE"))) {
										userVo = setUserVO(userVo);
									}   
									

									fieldAccessMappingList = userVo.getFieldAccessMappingVoList();

									httpSession.setAttribute("fieldAccessMappingVoList", fieldAccessMappingList);

									httpSession.setAttribute("userVO", userVo);
								}
								else {
									    FLogger.error("securityLoggerError", "RoleBasedHandler", "getBizResponseForRole", "userVo should not be null");
								     }

							}
						}
						else {
							FLogger.error("securityLoggerError", "RoleBasedHandler", "getBizResponseForRole", "bizRes should not be null");
						}

						/*
						 * bizResForFieldAccess = (BizResponse)
						 * context.getFlowScope().get("bizResForFieldAccess");
						 * if(bizResForFieldAccess != null){ responseCheck =
						 * (String) bizRes.getStatusVO().getStatus(); if
						 * (StringUtils.equalsIgnoreCase(responseCheck,
						 * "ERROR")) {
						 * throwINeoFlowException(bizRes.getStatusVO(),
						 * context); } else { fieldAccessMappingList =
						 * (List<FieldAccessMappingVO>)
						 * bizResForFieldAccess.getTransferObjects
						 * ().get("response1");
						 * httpSession.setAttribute("fieldAccessMappingVoList",
						 * fieldAccessMappingList); } } else {
						 * FLogger.error("securityLoggerError",
						 * "RoleBasedHandler", "getBizResponseForRole",
						 * "bizResForFieldAccess should not be null"); }
						 */

					}
					else {
						FLogger.error("securityLoggerError", "RoleBasedHandler", "getBizResponseForRole", "UserVo from session is null");
					}
				}
				else {
					FLogger.error("securityLoggerError", "RoleBasedHandler", "getBizResponseForRole", "Session is null");
				}
			}
			else {
				FLogger.error("securityLoggerError", "RoleBasedHandler", "RoleBasedHandler", "context should not be null");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
		}

		FLogger.info("securityLogger", "RoleBasedHandler", "RoleBasedHandler", "Method end");
		return success();
	}

	private IPruUser setBrokerUserVO(IPruUser userVo) {
		// TODO Auto-generated method stub
		return userVo;
	}

	public IPruUser setUserVO(IPruUser userVO) {
		FLogger.info("securityLogger", "RoleBasedHandler", "setUserVO", "Method start");
		Map<String, PolicyDetails> policyDetailMap = null;
		List<FieldAccessMappingVO> fieldAccessMappingList = null;

		if (userVO != null) {
			policyDetailMap = userVO.getPolicyDetailMap();

			Iterator it = policyDetailMap.entrySet().iterator();
			if (it.hasNext()) {
				Map.Entry pair = (Map.Entry) it.next();
				PolicyDetails policyDetails = (PolicyDetails) pair.getValue();

				userVO.setPolicyNo(policyDetails.getPolicyNo());
				userVO.setClientId(policyDetails.getClientId());
				userVO.setRoles(policyDetails.getRole());
				userVO.setRoleType(policyDetails.getRoleType());
				userVO.setEmpId(policyDetails.getEmpId());
				userVO.setTitle(policyDetails.getTitle());
				userVO.setDateOfJoiningScheme(policyDetails.getDateOfJoiningScheme());
				userVO.setDob(policyDetails.getDob());
				userVO.setClientName(policyDetails.getClientName());
				userVO.setPanNo(policyDetails.getPanNumber());
				userVO.setWorkPhone(policyDetails.getWorkPhone());
				userVO.setHomePhone(policyDetails.getHomePhone());
				userVO.setWorkEmailId(policyDetails.getWorkEmailId());
				userVO.setHomeEmailId(policyDetails.getHomeEmailId());
				userVO.setProductType(policyDetails.getProductType());

				userVO.setAccessMatrix(policyDetails.getAccessMatrix());
				userVO.setLstRoleScreenAccessMapping(policyDetails.getLstRoleScreenAccessMapping());
				userVO.setScreenDisplayed(policyDetails.getScreensDisplayed());
				userVO.setScreenAccessDeniedList(policyDetails.getScreenAccessDeniedList());
				userVO.setLandingPage(policyDetails.getLandingPage());
				fieldAccessMappingList = policyDetails.getFieldAccessMappingVoList();
				userVO.setFieldAccessMappingVoList(fieldAccessMappingList);
				userVO.setSelectedPolicy(policyDetails);
			}
		}

		FLogger.info("securityLogger", "RoleBasedHandler", "setUserVO", "Method end");
		return userVO;
	}

	public static void main(String arg[]) {
		int randomNumber = (int) (Math.random() * 99999999);
		String application_No = "OD" + randomNumber;
		// System.out.println(application_No);
	}

	@Override
	@MethodPost
	public Event isAuthorized(RequestContext context) throws GroupSecurityException {
		return null;
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
