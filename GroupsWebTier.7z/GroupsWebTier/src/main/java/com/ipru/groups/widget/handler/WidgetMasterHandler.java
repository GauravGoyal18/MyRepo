package com.ipru.groups.widget.handler;

import java.util.List;

import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ipru.groups.widget.service.WidgetMasterService;
import com.ipru.groups.widget.vo.Page;
import com.ipru.groups.widget.vo.wdgtMasterJson;
import com.tcs.web.handler.BaseHandler;



public class WidgetMasterHandler extends BaseHandler{

	public Event defaultRoleBasedScreenOverviewWdgtMap(RequestContext p_ObjContext) throws Exception
	{
		WidgetMasterService service=new WidgetMasterService();
		
		List<Page> page=service.getScreen();
		////System.out.println("Inside Handler");
		////System.out.println("result is"+page.toString());
		wdgtMasterJson wdgtMasterJson=new wdgtMasterJson();
		wdgtMasterJson.setPage(page);
		Gson gson=new GsonBuilder().serializeNulls().create();
		String dfltRoleBasedScreenWdgtString=gson.toJson(wdgtMasterJson);
		p_ObjContext.getFlowScope().put("dfltScreenWdgtList", dfltRoleBasedScreenWdgtString);
		return success();
		
	}
	

}

