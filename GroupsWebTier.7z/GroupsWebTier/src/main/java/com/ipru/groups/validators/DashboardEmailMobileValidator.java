package com.ipru.groups.validators;

import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import net.sf.ehcache.search.expression.IsNull;

import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.groups.po.ContactabilityRequestPO;
import com.ipru.groups.po.EmailMobileRequestPO;
import com.ipru.groups.po.ForgotPasswordRequestPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.logger.FLogger;

public class DashboardEmailMobileValidator {

	private final StringBuilder errorMessageBuilder = new StringBuilder(1);
	private Properties prop = new Properties();

	public String validateEmailMobileRequestPO(RequestContext context, EmailMobileRequestPO emailMobileRequestPO) throws Exception {

		if (context != null) {
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

			if (emailMobileRequestPO != null) {

				prop = MasterPropertiesFileLoader.CONSTANT_EMAILMOBILE_LENGTH_PROPERTIES;

				if (!validateEmail(emailMobileRequestPO.getEmailId())) {
					errorMessageBuilder.append("Please Enter Valid Email Address.\n");
				}
				if (!validateMobile(String.valueOf(emailMobileRequestPO.getMobileNo()))) {
					errorMessageBuilder.append("Please Enter Valid Mobile Number.\n");
				}
			}
			else {
				errorMessageBuilder.append("Please Enter Valid Details.\n");
			}

		}

		return errorMessageBuilder.toString();
	}
	
	public String validateEmailMobileRequestPO(RequestContext context, ContactabilityRequestPO contactabilityRequestPO) throws Exception {

		if (context != null) {

			ContactabilityRequestPO contactPoFromSession = (ContactabilityRequestPO) GroupSecurityUtil.getAttributeFromSession(context, "contactabilityRequestPO");
			
			if (contactabilityRequestPO != null) {

				prop = MasterPropertiesFileLoader.CONSTANT_EMAILMOBILE_LENGTH_PROPERTIES;

				if (!validateEmail(contactabilityRequestPO.getEmailId())) {
					errorMessageBuilder.append("Please Enter Valid Email Address.\n");
				}
				if (!validateMobileNRI(contactabilityRequestPO)) {
					errorMessageBuilder.append("Please Enter Valid Mobile Number.\n");
				}
				if (!validatePassword(contactabilityRequestPO.getProperty())) {
					errorMessageBuilder.append("Please Enter Valid Password.\n");
				}
				
			}
			else {
				errorMessageBuilder.append("Please Enter Valid Details.\n");
			}

		}

		return errorMessageBuilder.toString();
	}

	private boolean validateEmail(String emailId) {

		Integer length = 0;
		if (prop.getProperty("Email") != null)
			length = Integer.valueOf(prop.getProperty("Email"));

		if (CommonValidationUtil.ValidateRequired(emailId) && CommonValidationUtil.ValidateEmail(emailId, true, length)) {
			return true;
		}
		else {
			return false;
		}
	}

	private boolean validateMobileNRI(ContactabilityRequestPO contactabilityRequestPO) {
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES ;
		if((contactabilityRequestPO.getCountryName().equals(prop.getProperty("INDIA")))||(contactabilityRequestPO.getCountryName().equals("")))
		{
		if ((StringUtils.isNotBlank(String.valueOf(contactabilityRequestPO.getMobileNo())) && CommonValidationUtil.isMatchedPattern(String.valueOf(contactabilityRequestPO.getMobileNo()), GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) || (String.valueOf(contactabilityRequestPO.getMobileNo())).equals("-"))) {
			return true;
		}
		}
		if(!(contactabilityRequestPO.getCountryName().equals(prop.getProperty("INDIA"))))
		{
			if ((StringUtils.isNotBlank(String.valueOf(contactabilityRequestPO.getMobileNo())) && CommonValidationUtil.isMatchedPattern(String.valueOf(contactabilityRequestPO.getMobileNo()), GroupFormValidationConstant.NRI_REGEX) || (String.valueOf(contactabilityRequestPO.getMobileNo())).equals("-"))) {
			return true;
		}
			else {
				return false;
			
		}
		}
		return false;
	
		
	}
	
	private boolean validateMobile(String mobile) {
		Integer length = 0;
		if (prop.getProperty("MobileNo") != null)
			length = Integer.valueOf(prop.getProperty("MobileNo"));

		if (CommonValidationUtil.ValidateRequired(mobile) && CommonValidationUtil.isMatchedPattern(mobile, GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP)
				&& CommonValidationUtil.ValidateMaxLength(mobile, 10)) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	private boolean validatePassword(String password) {
	
		if (CommonValidationUtil.ValidateRequired(password)){
			return true;
		}
		return false;
	}
}
