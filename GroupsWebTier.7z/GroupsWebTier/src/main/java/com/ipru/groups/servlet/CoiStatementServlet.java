package com.ipru.groups.servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

import com.ipru.groups.pdfgen.TemplateCoreServiceImpl;
import com.ipru.groups.utilities.GroupCommonUtils;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.vo.CoiResponseDataVO;
import com.tcs.logger.FLogger;
import com.tcs.pdfgenerator.core.service.ITemplateCoreService;
import com.tcs.pdfgenerator.exception.PDFGeneratorException;
import com.tcs.pdfgenerator.service.FTL2PDFGenerator;
import com.tcs.pdfgenerator.util.PDFGeneratorUtils;

public class CoiStatementServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		
		
		FLogger.info("COIStatementLogger", "CoiStatementServlet", "doPost", "Method start");

		
		try {
		
		if(session==null)
		{
			//throw
			
			FLogger.info("COIStatementLogger", "CoiStatementServlet", "doPost", "session is null");
			throw new ServletException("session is null");
		
		}
		CoiResponseDataVO coiResponseDataList=(CoiResponseDataVO)session.getAttribute("coiResponseDataList");

		
		////System.out.println(bidResponseList.toString());
		//createFTLConfigInstance();
		
		String coiStatementFtlPath="";

		coiStatementFtlPath="CoiGT3.ftl";
		
		
		//ITemplateCoreService templateCoreService = new TemplateServiceImpl();
		long TimeStamp=new Date().getTime();
		//////System.out.println("TimeStamp"+TimeStamp);
		
		ITemplateCoreService service= new TemplateCoreServiceImpl();
		String destination = GroupCommonUtils.createDirWithTodaysDate(GroupConstants.CONSTANT_DOCUMENT_UPLOAD_PATH+"/coiStatementDownload");
		if(destination==null)
		{
			FLogger.info("COIStatementLogger", "CoiStatementServlet", "doPost", "destination is null");

			throw new ServletException("Null data found");
		}
		String fileUploadPath=destination+"/coiStatement_"+TimeStamp+".pdf";
		
		
		FTL2PDFGenerator.getPDFGeneratorInstance.generatePDFTemplate(PDFGeneratorUtils.createTemplateBean(coiStatementFtlPath, coiResponseDataList, fileUploadPath), service);

		File file=null;
		InputStream fis=null;
		try {
			file = new File(fileUploadPath);
			 fis = new FileInputStream(file);
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(!file.exists())
		{
			FLogger.info("COIStatementLogger", "CoiStatementServlet", "doPost", "File does not exist");
			throw new ServletException("File does not exist");
		}
		
		
		
		
		
	      ByteArrayOutputStream output = new ByteArrayOutputStream();
	      ServletOutputStream objServletOutputStream = null;
	      byte[] bufferData = new byte[65536];
	      int read=0;
	      while((read = fis.read(bufferData))!= -1){
	        	output.write(bufferData, 0, read);
	       }
	       
	      try {
				if(fis!=null)
					fis.close();
			}
			catch (Exception e) {
				FLogger.error("COIStatementLogger", "CoiStatementServlet","doPost",e.getMessage());
				e.printStackTrace();
			} finally {
				fis=null;
			}
	      response.addHeader("Content-Disposition",  "attachment; filename=\"" + "bidStatement.pdf" + "\"");
	      response.setContentType("application/pdf");
	      output.flush();
	      response.setContentLength(output.size());
	      objServletOutputStream = response.getOutputStream();
	      output.writeTo(objServletOutputStream);
	      objServletOutputStream.flush();
	      
		
		
		
		
		
		
		
			FLogger.info("COIStatementLogger", "CoiStatementServlet", "doPost", "Method end");

		
		
		}
		catch (PDFGeneratorException e) {
			// TODO Auto-generated catch block
			
			FLogger.error("COIStatementLogger", "CoiStatementServlet", "doPost", "Error occured while generating pdf");

			e.printStackTrace();
			  ServletOutputStream objServletOutputStream = response.getOutputStream();
			  objServletOutputStream.flush();
		}
		catch(Exception e)
		{
			
			FLogger.error("COIStatementLogger", "CoiStatementServlet", "doPost", "Error occured",e);

			e.printStackTrace();
			  ServletOutputStream objServletOutputStream = response.getOutputStream();
			  objServletOutputStream.flush();

		}
		
		finally
		{
			session.removeAttribute("coiResponseDataList");
			
			//in.close();
			//out.close();
			
		}
		
		
	}
	

}
