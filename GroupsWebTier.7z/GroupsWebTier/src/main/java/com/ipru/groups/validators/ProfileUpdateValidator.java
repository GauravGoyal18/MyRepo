package com.ipru.groups.validators;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.groups.po.ProfileUpdateDetailsPo;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.utilities.ProfileUpdateUtil;
import com.ipru.groups.vo.FieldAccessMappingVO;

public class ProfileUpdateValidator {
	private static final String CLASS_NAME = ProfileUpdateValidator.class.getName();
	ProfileUpdateUtil utility=new ProfileUpdateUtil();
	   String str="Something Went Wrong Please Try Again!";
	   
	  
	   public String ValidateProfileCompanyAddressDetails(List<ProfileUpdateDetailsPo> profileUpdateDetailsPo,RequestContext p_ObjContext, Map<String, FieldAccessMappingVO> map) throws Exception{
		   Properties prop=new Properties();
		    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		    
			final StringBuilder errorMessageBuilder = new StringBuilder(1);
		
			Set OnloadAddressTypeData = (Set) p_ObjContext.getFlowScope().get("OnloadAddressTypeData");
			Set OnloadCityeData = (Set) p_ObjContext.getFlowScope().get("OnloadCityDetails");
			Set OnloadStateData = (Set) p_ObjContext.getFlowScope().get("OnloadStateDetailsData");
			Set OnloadAddressProofData = (Set) p_ObjContext.getFlowScope().get("OnloadAddressProof");
	
			ProfileUpdateDetailsPo poValidate=null;
		
			 errorMessageBuilder.setLength(0);
			for(int i=0;i<profileUpdateDetailsPo.size();i++)
			{
				 poValidate=profileUpdateDetailsPo.get(i);
		
			
			if (poValidate.getFieldName().equals(prop.getProperty("companyAddressaddressType"))) {
			
			
			
				if(!validateCompanyAddressaddressType(poValidate.getNewValue(),OnloadAddressTypeData)) 
						{
					errorMessageBuilder.append("Please Select Address Type. ");
						}
				
								
			}
		
			
			
			if (poValidate.getFieldName().equals(prop.getProperty("companyAddressCompany"))) {
				
				
				if(!validateCompanyOrBuildingName(poValidate.getNewValue())) 
						{
					errorMessageBuilder.append("Please Enter Company / Building Name. ");
						}
				
			}
			
			
	if (poValidate.getFieldName().equals(prop.getProperty("companyAddressFlat"))) {
	
				
				if(!validateFlatOrUnitNumber(poValidate.getNewValue())) 
						{
					errorMessageBuilder.append("Please Enter Flat / Unit Number. ");
						}
				
			}
			
	
	if (poValidate.getFieldName().equals(prop.getProperty("companyAddressStreet"))) {
		
		if(!validateFlatOrUnitNumber(poValidate.getNewValue())) 
				{
			errorMessageBuilder.append("Please Enter Street / Area. ");
				}
		
	}
	

	if (poValidate.getFieldName().equals(prop.getProperty("companyAddressLandmark"))) {
	
		if(!validateLandmark(poValidate.getNewValue())) 
				{
			errorMessageBuilder.append("Please Enter Landmark. ");
				}
		
	}
	

	if (poValidate.getFieldName().equals(prop.getProperty("companyAddressPincode"))) {

		if(!validateLandmark(poValidate.getNewValue())) 
				{
			errorMessageBuilder.append("Please Enter Pincode. ");
				}
		
	}
		
	
if (poValidate.getFieldName().equals(prop.getProperty("companyAddressCity"))) {

		if(!validateCity(poValidate.getNewValue(),OnloadCityeData))
				{
			errorMessageBuilder.append("Please Enter City. ");
				}
		
	}

if (poValidate.getFieldName().equals(prop.getProperty("companyAddressState"))) {
	
	if(!validateState(poValidate.getNewValue(),OnloadStateData))
			{
		errorMessageBuilder.append("Please Enter State. ");
			}
	
}
	

if (poValidate.getFieldName().equals(prop.getProperty("companyAddressaddressproof"))) {

	if(!validateAddressProof(poValidate.getNewValue(),OnloadAddressProofData)) 
			{
		errorMessageBuilder.append("Please Enter Select Address Proof. ");
			}
	
			}
	
		
			}
			return errorMessageBuilder.toString();
	   }
			
	   
	   
	   private boolean validateCompanyAddressaddressType(String b,Set data) {
		
			if(CollectionUtils.isNotEmpty(data)){
				if(StringUtils.isNotEmpty(b)){
			if(data.contains(b)){
				return true;
			}
			else{
				return false;
			}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		   
		}

	   private boolean validateCompanyOrBuildingName(String b) {
		
			if(StringUtils.isNotEmpty(b)){
			if (CommonValidationUtil.ValidateAddress(b) && CommonValidationUtil.ValidateMaxLength(b, 30)) {
				return true;

			}
			else {
				return false;
			}
			}
			else{
				return false;
			}
		 
		}
	   
	   
	   
	   private boolean validateFlatOrUnitNumber(String b) {
	
			if(StringUtils.isNotEmpty(b)){
			if (CommonValidationUtil.ValidateAddress(b) && CommonValidationUtil.ValidateMaxLength(b, 30)) {
				return true;

			}
			else {
				return false;
			}
			}
			else{
				return false;
			}
		  
		}
	   
	   private boolean validateLandmark(String b) {
		  
			if(StringUtils.isNotEmpty(b)){
			if (CommonValidationUtil.ValidateAddress(b) && CommonValidationUtil.ValidateMaxLength(b, 30)) {
				return true;

			}
			else {
				return false;
			}
			}
			else{
				return false;
			}
		  
		}

	  private boolean validateCity(String b,Set data) {
	
			if(CollectionUtils.isNotEmpty(data)){
				if(StringUtils.isNotEmpty(b)){
			if(data.contains(b)){
				return true;
			}
			else{
				return false;
			}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		
		}
	   
	  

	  private boolean validateState(String b,Set data) {
		 
			if(CollectionUtils.isNotEmpty(data)){
				if(StringUtils.isNotEmpty(b)){
			if(data.contains(b)){
		
				return true;
			}
			else{
				return false;
			}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		 
		}
	   

	  private boolean validateAddressProof(String b,Set data) {
		
		  if(CollectionUtils.isNotEmpty(data)){
				if(StringUtils.isNotEmpty(b)){
			if(data.contains(b)){
			
				return true;
			}
			else{
				return false;
			}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		 
		}
   
	   public String ValidateProfileContactPersonDetails(List<ProfileUpdateDetailsPo> profileUpdateDetailsPo,RequestContext p_ObjContext,Map<String, FieldAccessMappingVO> map) throws Exception{
		   Properties prop=new Properties();
		    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
		    
			final StringBuilder errorMessageBuilder = new StringBuilder(1);
			
			List OnloadTitleDetails = (List) p_ObjContext.getFlowScope().get("OnloadTitleDetails");
			 ProfileUpdateDetailsPo poValidate=null;
			for(int i=0;i<profileUpdateDetailsPo.size();i++)
			{
				 poValidate=profileUpdateDetailsPo.get(i);
		
			
			if (poValidate.getFieldName().equals(prop.getProperty("contactpersontilte"))) {
				if(!validateContactPersontitle(poValidate.getNewValue(),OnloadTitleDetails)) 
						{
					errorMessageBuilder.append("Please Select  Title. ");
						}
				
				}
			
			if (poValidate.getFieldName().equals(prop.getProperty("contactpersonfirstName"))) {
				
				if(!validateContactPersonfirstName(poValidate.getNewValue())) 
						{
					errorMessageBuilder.append("Please Enter First Name. ");
						}
				
				}
			
			
			if (poValidate.getFieldName().equals(prop.getProperty("contactpersonmiddleName"))) {
			
				if(!validateContactPersonMiddleName(poValidate.getNewValue())) 
						{
					errorMessageBuilder.append("Please Enter Middle Name. ");
						}
				
				}
			
		if (poValidate.getFieldName().equals(prop.getProperty("contactpersonlastName"))) {
		
				if(!validateContactPersonlastName(poValidate.getNewValue())) 
						{
					errorMessageBuilder.append("Please Enter Last Name. ");
						}
				
				}
			
		

	if (poValidate.getFieldName().equals(prop.getProperty("contactpersonemailId"))) {
		
			if(!validateContactPersonemailId(poValidate.getNewValue())) 
					{
				errorMessageBuilder.append("Please Enter EmailId. ");
					}
			
			}



	if (poValidate.getFieldName().equals(prop.getProperty("contactpersonmobnumber"))) {
		
		if(!validateContactPersonnumber(poValidate.getNewValue())) 
				{
			errorMessageBuilder.append("Please Enter Phone Number. ");
				}
		
		}



			}
			
			return errorMessageBuilder.toString();
		}
		
		
	   
	   

		
		private boolean validateContactPersonnumber(String b) {
		
			if(StringUtils.isNotBlank(b)){
		if (CommonValidationUtil.isMatchedPattern(b,GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) 
				&& CommonValidationUtil.ValidateMaxLength(b,10)) {
				return true;

			}
			else {
				return false;
			}
			}
			else
			{
				return false;
			}
			
		}


		private boolean validateContactPersonemailId(String b) {
			
			if(StringUtils.isNotEmpty(b)){
			if (CommonValidationUtil.ValidateEmail(b, false, 50)) {
				return true;

			}
			else {
				return false;
			}
			}
			else{
				return false;
			}
			
		}
		
		private boolean validateContactPersonlastName(String b) {
			
			if(StringUtils.isNotEmpty(b)){
			if (CommonValidationUtil.ValidateAlphaWithSpace((b)) && CommonValidationUtil.ValidateMaxLength(b, 30)) {
				return true;

			}
			else {
				return false;
			}
			}
			else
			{
				return false;
			}
			
		}
		private boolean validateContactPersonMiddleName(String b) {
			if(StringUtils.isNotEmpty(b)){
			if (CommonValidationUtil.ValidateAlphaWithSpace((b)) && CommonValidationUtil.ValidateMaxLength(b, 30)) {
				return true;

			}
			else {
				return false;
			}
			}
			else
			{
				return true;
			}
		}
		
		private boolean validateContactPersonfirstName(String b) {
			
			if(StringUtils.isNotEmpty(b)){
			if (CommonValidationUtil.ValidateAlphaWithSpace((b)) && CommonValidationUtil.ValidateMaxLength(b, 30)) {
				return true;

			}
			else {
				return false;
			}
			}
			else
			{
				return false;
			}
			
		}
		private boolean validateContactPersontitle(String b,List data) {
			
			if(CollectionUtils.isNotEmpty(data)){
			if(StringUtils.isNotEmpty(b)){
			if(data.contains(b)){
		
				return true;

			}
			else {
				return false;
			}
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
			
			
		}

  public String ValidateProfileAuthoritySignatoryDetails(List<ProfileUpdateDetailsPo> profileUpdateDetailsPo,RequestContext p_ObjContext) throws Exception{
			   Properties prop=new Properties();
			    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
			    
				final StringBuilder errorMessageBuilder = new StringBuilder(1);
				
				List OnloadTitleDetails = (List) p_ObjContext.getFlowScope().get("OnloadTitleDetails");
			
				 ProfileUpdateDetailsPo poValidate=null;
				for(int i=0;i<profileUpdateDetailsPo.size();i++)
				{
					 poValidate=profileUpdateDetailsPo.get(i);
						
						
						if (poValidate.getFieldName().equals(prop.getProperty("authoritytitle"))) {
							
							if(!validateAuthorizedtitle(poValidate.getNewValue(),OnloadTitleDetails)) 
									{
								errorMessageBuilder.append("Please Select Title. ");
									}
							
							}
						
						if (poValidate.getFieldName().equals(prop.getProperty("authorityfirstName"))) {
							
							if(!validateAuthorizedfirstName(poValidate.getNewValue())) 
									{
								errorMessageBuilder.append("Please Enter First Name. ");
									}
							
							}
						
						
						if (poValidate.getFieldName().equals(prop.getProperty("authoritymiddleName"))) {
							
							if(!validateAuthorizedmiddleName(poValidate.getNewValue())) 
									{
								errorMessageBuilder.append("Please Enter Middle Name. ");
									}
							
							}
						
					if (poValidate.getFieldName().equals(prop.getProperty("authoritylastName"))) {
							
							if(!validateAuthorizedlastName(poValidate.getNewValue())) 
									{
								errorMessageBuilder.append("Please Enter Last Name. ");
									}
							
							}
						
					
					if (poValidate.getFieldName().equals(prop.getProperty("authorityactive"))) {
						
						if(!validateAuthorizedactive(poValidate.getNewValue())) 
								{
							errorMessageBuilder.append("Please Select Active Yes Or No. ");
								}
						
						}
					
					

				if (poValidate.getFieldName().equals(prop.getProperty("authorityemailId"))) {
						
						if(!validateAuthorizedemailId(poValidate.getNewValue())) 
								{
							errorMessageBuilder.append("Please Enter EmailId. ");
								}
						
						}



				if (poValidate.getFieldName().equals(prop.getProperty("authoritymobNumber"))) {
					
					if(!validateAuthorizednumber(poValidate.getNewValue())) 
							{
						errorMessageBuilder.append("Please Enter Mobile Number. ");
							}
					
					}




						}
				
				return errorMessageBuilder.toString();
			}
			
		   
		   
		   private boolean validateAuthorizednumber(String b) {
				if(StringUtils.isNotEmpty(b)){
					
					if (CommonValidationUtil.isMatchedPattern(b,GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) 
							&& CommonValidationUtil.ValidateMaxLength(b,10)) {
						
						return true;

					}
					else {
						return false;
					}
				}
				else
				{
					return false;
				}
				
				}

			private boolean validateAuthorizedemailId(String b) {
				if(StringUtils.isNotEmpty(b)){
					if (CommonValidationUtil.ValidateEmail(b, false, 50)) {
						return true;

					}
					else {
						return false;
					}
				}
				else
					
				{
					return false;
				}
				}

				private boolean validateAuthorizedactive(String b) {
					if(StringUtils.isNotEmpty(b)){
					if (CommonValidationUtil.ValidateAlpha(b) && CommonValidationUtil.ValidateMaxLength(b, 30)) {
						return true;

					}
					else {
						return false;
					}
					}
					else
					{
						return false;
					}
				}
				private boolean validateAuthorizedlastName(String b) {
					if(StringUtils.isNotEmpty(b)){
					if (CommonValidationUtil.ValidateAlphaWithSpace(b)  && CommonValidationUtil.ValidateMaxLength(b, 30)) {
						return true;

					}
					else {
						return false;
					}
					}
					else
					{
						return false;
					}
				}
				
				private boolean validateAuthorizedtitle(String b,List data) {
					if(CollectionUtils.isNotEmpty(data)){
					if(StringUtils.isNotEmpty(b)){
					if(data.contains(b)){
						return true;
					}
					else
					{
						return false;
					}
						}
						else
						{
							return false;
						}
					}
					else
					{
						return false;
					}
					
				}
				
				
				private boolean validateAuthorizedfirstName(String b) { 
					if(StringUtils.isNotEmpty(b)){
					if (CommonValidationUtil.ValidateAlphaWithSpace(b)  && CommonValidationUtil.ValidateMaxLength(b, 30)) {
						return true;

					}
					else {
						return false;
					}
					}
					else
					{
						return false;
					}
				}
				
				private boolean validateAuthorizedmiddleName(String b) { 
					if(StringUtils.isNotEmpty(b)){
						if (CommonValidationUtil.ValidateAlphaWithSpace(b) && CommonValidationUtil.ValidateMaxLength(b, 30)) {
						return true;

					}
					else {
						return false;
					}
					}
					else
					{
						return true;
					}
					
				}
			
	/* public String ValidateProfileBankDetailsChangeDetails(List<ProfileUpdateDetailsPo> profileUpdateDetailsPo,RequestContext p_ObjContext,Map<String, FieldAccessMappingVO> map) throws Exception{
					   Properties prop=new Properties();
					    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
					    
						final StringBuilder errorMessageBuilder = new StringBuilder(1);
						
						HttpSession httpSession = ((HttpServletRequest) p_ObjContext.getExternalContext().getNativeRequest()).getSession();
						
						List OnloadTitleDetails=(List) httpSession.getAttribute("OnloadTitleDetails");
						
					
						 ProfileUpdateDetailsPo poValidate=null;
						for(int i=0;i<profileUpdateDetailsPo.size();i++)
						{
							 poValidate=profileUpdateDetailsPo.get(i);


							 if (poValidate.getFieldName().equals(prop.getProperty("bankAccountbankName_new"))) {//
							 	//TODO:Validate Bank Name
							 	if(!validateBankAccountbankName(poValidate.getNewValue())) 
							 			{
							 		errorMessageBuilder.append("Please Enter Bank Name.\n");
							 			}
							 	
							 	}

							 if (poValidate.getFieldName().equals(prop.getProperty("bankAccountaccountNumber_new"))) {//
							 	//TODO:Validate Account Number no Validation Till Now
							 	if(!validateBankAccountaccountNumber(poValidate.getNewValue())) 
							 			{
							 		errorMessageBuilder.append("Please Enter Bank Account Number.\n");
							 			}
							 	
							 	}



							 if (poValidate.getFieldName().equals(prop.getProperty("bankAccountIFSCCode_new"))) {//
							 	//TODO:Validate Account Number no Validation Till Now
							 	if(!validateBankAccountIFSCCode(poValidate.getNewValue())) 
							 			{
							 		errorMessageBuilder.append("Please Enter IFSC Code.\n");
							 			}
							 	
							 	}

							
							}
						
						return errorMessageBuilder.toString();
					}
					
				
				
				
				
				
				
	 private boolean validateBankAccountIFSCCode(String b) {

			if(CommonValidationUtil.ValidateRequired(b) && CommonValidationUtil.isMatchedPattern(b, GroupFormValidationConstant.IFSC_CODE_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(b, 11)){
			
				return true;

			}
			else {
				return false;
			}
		}


		private boolean validateBankAccountaccountNumber(String b) {
			
			if (CommonValidationUtil.ValidateNumeric(b) && CommonValidationUtil.isMatchedPattern(b,GroupFormValidationConstant.ACCOUNTNUMBER_VALIDATION_FORGROUP)  && CommonValidationUtil.ValidateMaxLength(b, 11)) {
				
				//TODO:Check All Bank Account Details Page Validation Properly ok
				return true;

			}
			else {
				return false;
			}
		}
		private boolean validateBankAccountbankName(String b) {
			
			if (CommonValidationUtil.ValidateAlphaWithSpace(b) && CommonValidationUtil.ValidateRequired(b)  && CommonValidationUtil.ValidateMaxLength(b, 100)) {
				return true;

			}
			else {
				return false;
			}
		}
				
*/
				
				public String ValidateMemberAddressTraditionalDetails(List<ProfileUpdateDetailsPo> profileUpdateDetailsPo,RequestContext p_ObjContext,Map<String, FieldAccessMappingVO> map) throws Exception{
					   Properties prop=new Properties();
					    prop=MasterPropertiesFileLoader.CONSTANT_PROFILEUPDATE_PROPERTIES;
					    
						final StringBuilder errorMessageBuilder = new StringBuilder(1);
						 ProfileUpdateDetailsPo poValidate=null;
						for(int i=0;i<profileUpdateDetailsPo.size();i++)
						{
							 poValidate=profileUpdateDetailsPo.get(i);
					
						
						if (poValidate.getFieldName().equals(prop.getProperty("empDOJ"))) {
							if(!validateDateOfJoning(poValidate.getNewValue())) 
									{
								errorMessageBuilder.append("Please Enter Date Of Joining. ");
									}
							
							}
						
						
						if (poValidate.getFieldName().equals(prop.getProperty("empDOB"))) {
							if(!validateDateOfBirth(poValidate.getNewValue())) 
									{
								errorMessageBuilder.append("Please Enter Date Of Birth. ");
									}
							
							}
						

						if (poValidate.getFieldName().equals(prop.getProperty("empEmail"))) {
							if(!validateEmailID(poValidate.getNewValue())) 
									{
								errorMessageBuilder.append("Please Enter Email ID. ");
									}
							
							}
						

						if (poValidate.getFieldName().equals(prop.getProperty("empMobileNo"))) {
							if(!validateMobileNo(poValidate.getNewValue())) 
									{
								errorMessageBuilder.append("Please Enter Mobile Number. ");
									}
							
							}
						
						
					

						}
						
						return errorMessageBuilder.toString();
					}
					
				
				
				
				
				 private boolean validateDateOfJoning(String b) {
					 
					 if(!StringUtils.isEmpty(b)){
						if(CommonValidationUtil.ValidateRequired(b) && CommonValidationUtil.isMatchedPattern(b, GroupFormValidationConstant.DATEVALIDATION)){
						
							return true;

						}
						else {
							return false;
						}
					 }
					 else{
						 return false;
					 }
					}
				 
					
				 private boolean validateDateOfBirth(String b) {
					 	if(!StringUtils.isEmpty(b)){
						if(CommonValidationUtil.ValidateRequired(b) && CommonValidationUtil.isMatchedPattern(b, GroupFormValidationConstant.DATEVALIDATION)){
						
							return true;

						}
						else {
							return false;
						}
					 	}
					 	else
					 	{
					 		return false;
					 	}
					}
				
				 
				 private boolean validateEmailID(String b) {
					 if(!StringUtils.isEmpty(b)){
						if(CommonValidationUtil.ValidateEmail(b, false, 50)){
						
							return true;

						}
						else {
							return false;
						}
					 }
					 else
					 {
						 return false;
					 }
					}
				 private boolean validateMobileNo(String b) {
					 	if(!StringUtils.isEmpty(b)){
						if(CommonValidationUtil.isMatchedPattern(b,GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) 
								&& CommonValidationUtil.ValidateMaxLength(b,10)){
						
							return true;

						}
						else {
							return false;
						}
					 	}
					 	else
					 	{
					 		return false;
					 	}
					}
				 
				 
				 
				 
					

}
