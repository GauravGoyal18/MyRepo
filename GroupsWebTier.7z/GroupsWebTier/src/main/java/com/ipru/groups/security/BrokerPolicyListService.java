package com.ipru.groups.security;


import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ipru.groups.service.WebserviceInvoke;
import com.ipru.groups.vo.BrokerDashboardDetailsVO;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.groups.vo.FundNameBO;

public class BrokerPolicyListService {

	static String functionality = null;
	static String output = null;

	public static FscDetailsVO getPolicyListBranch(FscDetailsVO fscdetails) throws Exception {
		// TODO Auto-generated method stub
		//List<String> policyNoList= null;
		List paramList = new ArrayList();
		List<FscDetailsVO> fscList = new ArrayList<FscDetailsVO>();

		List<String> policyNoList = new ArrayList<String>();
		
		functionality = "BrokerBranchPolicyList";
		paramList.add(fscdetails.getBranchCode());
		
		output = WebserviceInvoke.getInstance().fetchBrokerBranchPolicyList(functionality, paramList);
		
		Type listType = new TypeToken<ArrayList<FscDetailsVO>>() {
		}.getType();

		fscList = new Gson().fromJson(output, listType);  
		
		for (FscDetailsVO fscobj:fscList){
			policyNoList.add(fscobj.getPolicyno());
			
		} 
		
		
		/*policyNoList =new Gson().fromJson(output.toString(), new TypeToken<A<String>>() {
		}.getType());*/
		
		fscdetails.setPolicyNoList(policyNoList);
		return fscdetails;
	}

	public static FscDetailsVO getPolicyListNational(FscDetailsVO fscdetails) throws Exception {
		// TODO Auto-generated method stub
		List paramList = new ArrayList();

		List<FscDetailsVO> fscList = new ArrayList<FscDetailsVO>();
		List<String> policyNoList = new ArrayList<String>();

		String natinalcode =fscdetails.getNationalCode();  
		functionality = "BrokerNationalPolicyList";
		paramList.add(natinalcode);    
		
		output = WebserviceInvoke.getInstance().fetchBrokerBranchPolicyList(functionality, paramList);
		
		Type listType = new TypeToken<ArrayList<FscDetailsVO>>() {
		}.getType();

		fscList = new Gson().fromJson(output, listType);  
		
		for (FscDetailsVO fscobj:fscList){
			policyNoList.add(fscobj.getPolicyno());
			
		}
		
		/*policyNoList =new Gson().fromJson(output.toString(), new TypeToken<List<String>>() {
		}.getType());
		*/
		fscdetails.setPolicyNoList(policyNoList);
		return fscdetails;
	}

}
