package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.groups.po.PmjjbyPO;
import com.ipru.groups.po.ServiceTrackerTransformerPO;
import com.ipru.groups.validators.PmjjbyValidator;
import com.ipru.groups.vo.PmjjbyVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class PmjjbyHandler extends IneoBaseHandler {

	private static final long serialVersionUID = 1L;

	@MethodPost
	public Event getBizRequestSubmit(RequestContext context) throws Exception {
		FLogger.info("PmjjbyLogger", "PmjjbyHandler", "getBizRequestSubmit", "getBizRequestSubmit Method End");
		try {

			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			PmjjbyPO pmjjbyPO = gsonJSON.fromJson(request.getReader(), PmjjbyPO.class);
			
			PmjjbyValidator pmjjbyValidator=new PmjjbyValidator();
			String errormsg =pmjjbyValidator.validateData(pmjjbyPO);
			
			if (StringUtils.isNotBlank(errormsg)) {
				this.setValidationErrorMessages(errormsg);
				FLogger.error("PmjjbyLogger", "PmjjbyHandler", "getBizRequestSubmit", "No Data Found");
				throwINeoFlowException(new ServiceException("GRPCL03"), "GRPCL03", context);
			}
			PmjjbyVO pmjjbyVO=new PmjjbyVO();
			
			pmjjbyVO=dozerBeanMapper.map(pmjjbyPO, PmjjbyVO.class);
			//pmjjbyVO.setMemberIdNo("234601501155");
			Object[] paramArray = new Object[1];
			paramArray[0] = pmjjbyVO;

			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			context.getFlowScope().put("submitBizReq", obj_bizReq);
			
		}
		catch (Exception e) {
			FLogger.error("PmjjbyLogger", "PmjjbyHandler", "getBizRequestSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("PmjjbyLogger", "PmjjbyHandler", "getBizRequestSubmit", "getBizRequestSubmit Method End");
		return success();

	}
	
	
	@MethodPost
	public Event getBizResponseSubmit(RequestContext context) throws Exception {
		FLogger.info("PmjjbyLogger", "PmjjbyHandler", "getBizResponseSubmit", "getBizResponseSubmit Method End");
		try {
			Gson gson = new Gson();

			BizResponse response = new BizResponse();
			response = (BizResponse) context.getFlowScope().get("bizResForSubmitPmjjby");
			List<PmjjbyVO> pmjjbyVOList = (List<PmjjbyVO>) response.getTransferObjects().get("response1");
			List<PmjjbyPO> pmjjbyPOList = new ArrayList<PmjjbyPO>();
			
			if(pmjjbyVOList== null){
				FLogger.error("PmjjbyLogger", "PmjjbyHandler", "getBizResponseSubmit", "pmjjbyVOList should not be null");
				throw new IPruException("Error", "GRPNOUP","No Data Found");
			}
			
			/*PmjjbyPO pmjjbyPO=new PmjjbyPO();
			for(PmjjbyVO pmjjbyVO:pmjjbyVOList){
				pmjjbyPO=dozerBeanMapper.map(pmjjbyVOList, PmjjbyPO.class);
				pmjjbyPOList.add(pmjjbyPO);
			}*/
			HttpSession session=((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			session.setAttribute("pmjjbyVO", pmjjbyVOList.get(0));
			
			context.getFlowScope().put("Response", "success");
			
		}
		catch (Exception e) {
			FLogger.error("PmjjbyLogger", "PmjjbyHandler", "getBizResponseSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("PmjjbyLogger", "PmjjbyHandler", "getBizResponseSubmit", "getBizResponseSubmit Method End");
		return success();

	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

}
