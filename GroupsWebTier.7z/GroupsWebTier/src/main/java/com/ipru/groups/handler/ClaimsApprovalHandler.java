package com.ipru.groups.handler;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ipru.IPruException;
import com.ipru.groups.grpswitch.bean.SwitchTransactionVO;
import com.ipru.groups.po.ClaimsDeathNonDeathPO;
import com.ipru.groups.po.ClaimsExcelResponsePO;
import com.ipru.groups.po.ClaimsExcelValidationPO;
import com.ipru.groups.po.ClaimsRequestTransactionPO;
import com.ipru.groups.po.ClaimsSubmitPO;
import com.ipru.groups.po.DownloadFileRequestPO;
import com.ipru.groups.po.NomineePMJJBYSubmitPO;
import com.ipru.groups.po.SwitchTrackerPO;
import com.ipru.groups.utilities.ClaimsUtil;
import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.groups.validators.ClaimsApprovalValidator;
import com.ipru.groups.vo.ClaimApprovalRequestVO;
import com.ipru.groups.vo.ClaimsExcelValidationVO;
import com.ipru.groups.vo.ClaimsRequestTransactionVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.FundMasterVO;
import com.ipru.groups.vo.NomineePMJJBYSubmitVO;
import com.ipru.groups.vo.SwitchTrackerVO;
import com.ipru.groups.vo.UnitStatementGratuityFundDetailsVO;
import com.ipru.groups.vo.UnitStatementGratuityResponseFundVO;
import com.ipru.groups.vo.UploadFileVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class ClaimsApprovalHandler extends IneoBaseHandler {

	@MethodPost
	public Event getBizRequestOnLoad(RequestContext context) throws Exception {
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestOnLoad", "getBizRequestOnLoad Method Start");
		Gson gson = new Gson();

		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
				String clientId = null;
				String policyNo = null;
				String memberType = null;

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						clientId = userVo.getClientId();
						policyNo = userVo.getPolicyNo();
						memberType = userVo.getRoleType();
						/* clientId = "00002285"; */
						/* policyNo = "00002285"; */

						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

						if (request != null) {
							ClaimsRequestTransactionVO claimsRequestTransactionVO = new ClaimsRequestTransactionVO();
							claimsRequestTransactionVO.setClientId(clientId);
							claimsRequestTransactionVO.setPolicyNo(policyNo);
							claimsRequestTransactionVO.setRole(memberType);

							Object[] paramArray = new Object[1];

							if (claimsRequestTransactionVO != null) {
								paramArray[0] = claimsRequestTransactionVO;
								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);
								context.getFlowScope().put("approvalBizReqOnLoad", obj_bizReq);
							}
							else {
								FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestOnLoad", "trackervo should not be null");
								throw new IPruException("Error", "GRPPFCC", "trackervo should not be null");
							}

						}
						else {

							FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestOnLoad", "request should not be null");
							throw new IPruException("Error", "GRPPFCC", "request should not be null");
						}
					}
					else {
						FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestOnLoad", "userVo should not be null");
						throw new IPruException("Error", "GRPPFCC", "userVo should not be null");
					}
				}
				else {
					FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestOnLoad", "httpSession should not be null");
					throw new IPruException("Error", "GRPPFCC", "httpSession should not be null");
				}
			}
			else {
				FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestOnLoad", "Context should not be null");
				throw new IPruException("Error", "GRPPFCC", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestOnLoad", "Exception came ", e);
			throwINeoFlowException(e, "GRPPFCC", context);
		}
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestOnLoad", "onEntry of getBizRequestOnLoad Method End ");
		return success();
	}

	@MethodPost
	public Event getBizResponseOnLoad(RequestContext context) throws Exception {

		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseOnLoad", "getBizResponseOnLoad Method start");
		try {

			Gson gson = new Gson();

			BizResponse response = new BizResponse();
			response = (BizResponse) context.getFlowScope().get("bizResForClaimsApprovalOnLoad");
			String memberType = null;
			String productType = null;
			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			IPruUser userVO = new IPruUser();
			if (httpSession != null) {
				IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

				if (userVo != null) {
					// policyNo=userVo.getPolicyNo();
					memberType = userVo.getRoleType();
					productType= userVo.getProductType();
					// memberType = "UPLOADER";
				}
			}

			List<ClaimsRequestTransactionVO> ClaimsRequestTransactionVOList = (List<ClaimsRequestTransactionVO>) response.getTransferObjects().get("response1");

			// context.getFlowScope().put("ClaimsRequestTransactionVOList",
			// gsonJSON.toJson(result));
			HashMap<String, ClaimsRequestTransactionVO> menuMap = new HashMap<String, ClaimsRequestTransactionVO>();

			List<ClaimsRequestTransactionPO> ClaimsRequestTransactionPOList = new ArrayList<ClaimsRequestTransactionPO>();

			if (ClaimsRequestTransactionVOList != null) {
				for (ClaimsRequestTransactionVO claimsRequestTransactionVO : ClaimsRequestTransactionVOList) {
					menuMap.put(String.valueOf(claimsRequestTransactionVO.getCustomerTrxnId()), claimsRequestTransactionVO);
					claimsRequestTransactionVO.setRole(memberType);
					claimsRequestTransactionVO.setProductType(productType);
					ClaimsRequestTransactionPO claimsRequestTransactionPO = dozerBeanMapper.map(claimsRequestTransactionVO, ClaimsRequestTransactionPO.class);
					ClaimsRequestTransactionPOList.add(claimsRequestTransactionPO);
				}
				
				context.getFlowScope().put("ClaimsRequestTransactionVOMap", menuMap);

				ClaimsUtil util = new ClaimsUtil();
				ClaimsDeathNonDeathPO claimsDeathNonDeathPO = util.getClaimsDeathNonDeathList(ClaimsRequestTransactionPOList);
				claimsDeathNonDeathPO.setRole(memberType);
				claimsDeathNonDeathPO.setProductType(productType);
				context.getFlowScope().put("Response", gsonJSON.toJson(claimsDeathNonDeathPO));

			}
			else {
				FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponsetOnLoad", "ClaimsRequestTransactionVOList should not be null");
				context.getFlowScope().put("Response", null);
				throw new IPruException("Error", "GRPPFCC", "No Data Found");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponsetOnLoad", "Exception came", e);
			throwINeoFlowException(e, "GRPPFCC", context);
		}
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseOnLoad", "getBizResponseOnLoad Method End");
		return success();

	}

	@MethodPost
	public Event getBizRequestApproved(RequestContext context) throws Exception {

		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestApproved", "getBizRequestApproved Method Start");
		Gson gson = new Gson();

		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
				String clientId = null;
				String policyNo = null;
				String role = null;
				String status = null;
				String productType = null;

				String memberType = null;
				
				FunctionalityMasterVO functionality = getFunctionality(context);

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
					status = (String) context.getFlowScope().get("AppovalStatus");
					if (userVo != null) {

						clientId = userVo.getClientId();
						policyNo = userVo.getPolicyNo();
						role = userVo.getRoles();
						productType = userVo.getProductType();
						memberType = userVo.getRoleType();
						// memberType="UPLOADER";

						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
						Type t = new TypeToken<List<ClaimsRequestTransactionPO>>() {
						}.getType();
						// Convert json to object
						if (request != null) {
							List<ClaimsRequestTransactionPO> claimsRequestTransactionPOList = gsonJSON.fromJson(request.getReader(), t);

							if (!CollectionUtils.isEmpty(claimsRequestTransactionPOList)) {
								ClaimsApprovalValidator claimsApprovalValidation = new ClaimsApprovalValidator();

								String errorMsg = claimsApprovalValidation.validateApproval(claimsRequestTransactionPOList, memberType, productType);

								if (StringUtils.isNotBlank(errorMsg)) {
									this.setValidationErrorMessages(errorMsg);
									FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestApproved", "Data from request should not be null");
									throwINeoFlowException(new ServiceException("GRPPFCC"), "GRPPFCC", context);
								}

								Map<String, ClaimsRequestTransactionVO> claimsRequestTransactionVOMap = (Map<String, ClaimsRequestTransactionVO>) context.getFlowScope().get("ClaimsRequestTransactionVOMap");

								ClaimsUtil util = new ClaimsUtil();
								List<ClaimsRequestTransactionVO> claimsRequestTransactionVOList = util.getClaimsRequestTransactionVOList(claimsRequestTransactionVOMap, claimsRequestTransactionPOList);
								
								for(ClaimsRequestTransactionVO claimsRequestTransactionVO : claimsRequestTransactionVOList){
									claimsRequestTransactionVO.setFunctionality(functionality);
									claimsRequestTransactionVO.setPolicyNo(policyNo);
									claimsRequestTransactionVO.setClientId(clientId);
									claimsRequestTransactionVO.setRole(role);
									claimsRequestTransactionVO.setMemberType(memberType);
									claimsRequestTransactionVO.setProductType(productType);
								}

								ClaimApprovalRequestVO claimApprovalRequestVO = new ClaimApprovalRequestVO();
								claimApprovalRequestVO.setStatus(status);
								claimApprovalRequestVO.setClaimsRequestTransactionVOList(claimsRequestTransactionVOList);

								Object[] paramArray = new Object[1];
								paramArray[0] = claimApprovalRequestVO;
								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);
								context.getFlowScope().put("approvalBizReqApproved", obj_bizReq);
							}
							else {
								FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestApproved", "claimsApprovalPOList should not be null");
								throw new IPruException("Error", "GRPPFCC", "claimsApprovalPOList should not be null");
							}

						}
						else {

							FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestApproved", "request should not be null");
							throw new IPruException("Error", "GRPPFCC", "request should not be null");
						}
					}
					else {
						FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestApproved", "userVo should not be null");
						throw new IPruException("Error", "GRPPFCC", "userVo should not be null");
					}
				}
				else {
					FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestApproved", "httpSession should not be null");
					throw new IPruException("Error", "GRPPFCC", "httpSession should not be null");
				}
			}
			else {
				FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestApproved", "Context should not be null");
				throw new IPruException("Error", "GRPPFCC", "Context should not be null");
			}
		}
		catch (Exception e) {
			FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestApproved", "Exception came ", e);
			throwINeoFlowException(e, "GRPPFCC", context);
		}
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestApproved", "onEntry of getBizRequestApproved Method End ");
		return success();

	}

	@MethodPost
	public Event getBizResponseApproved(RequestContext context) throws Exception {
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseApproved", "onEntry of getBizResponseApproved Method Start ");

		try {

			Gson gson = new Gson();

			BizResponse response = new BizResponse();
			response = (BizResponse) context.getFlowScope().get("bizResForClaimsApprovalApproved");
			List<ClaimsRequestTransactionVO> result = (List<ClaimsRequestTransactionVO>) response.getTransferObjects().get("response1");
			List<ClaimsRequestTransactionPO> result1 = new ArrayList<ClaimsRequestTransactionPO>();

			if (result.isEmpty()) {
				FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseApproved", "result is Empty");
				throw new IPruException("Error", "GRPPFCC", "result is Empty");
			}
			else if (result != null) {
				for (ClaimsRequestTransactionVO claimsRequestTransactionVO : result) {
					ClaimsRequestTransactionPO claimsRequestTransactionPO = new ClaimsRequestTransactionPO();
					claimsRequestTransactionPO = dozerBeanMapper.map(claimsRequestTransactionVO, ClaimsRequestTransactionPO.class);
					result1.add(claimsRequestTransactionPO);
				}
				context.getFlowScope().put("Response", gsonJSON.toJson(result1));

			}
			else {
				FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseApproved", "result should not be null");
				context.getFlowScope().put("Response", null);
				throw new IPruException("Error", "GRPPFCC", "result should not be null");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseApproved", "Exception came", e);
			throwINeoFlowException(e, "GRPPFCC", context);
		}

		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseApproved", "onEntry of getBizResponseApproved Method End ");
		return success();
	}

	public Event getBizRequestModalData(RequestContext context) throws Exception {
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestModalData", "onEntry of getBizRequestModalData Method Start ");
		Gson gson = new Gson();
		IPruUser userVo = new IPruUser();

		try {
			if (context != null) {

				HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

				ClaimsRequestTransactionPO claimsRequestTransactionPO = gsonJSON.fromJson(request.getReader(), ClaimsRequestTransactionPO.class);
				List<ClaimsRequestTransactionPO> claimsRequestTransactionPOList = new ArrayList<ClaimsRequestTransactionPO>();
				
				if (claimsRequestTransactionPO.equals(null)) {
					FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestModalData", "claimsDeathNonDeathPO is null");
					throw new IPruException("claimsDeathNonDeathPO is null");
				}
				
				ClaimsRequestTransactionVO claimsRequestTransactionVO = dozerBeanMapper.map(claimsRequestTransactionPO, ClaimsRequestTransactionVO.class);
				Map<String, ClaimsRequestTransactionVO> claimsRequestTransactionVOMap = (Map<String, ClaimsRequestTransactionVO>) context.getFlowScope().get("ClaimsRequestTransactionVOMap");
				claimsRequestTransactionVO = (ClaimsRequestTransactionVO) claimsRequestTransactionVOMap.get(String.valueOf(claimsRequestTransactionVO.getCustomerTrxnId()));
				claimsRequestTransactionPO = dozerBeanMapper.map(claimsRequestTransactionVO, ClaimsRequestTransactionPO.class);
				 claimsRequestTransactionPOList.add(claimsRequestTransactionPO);
				 
				 ClaimsUtil util = new ClaimsUtil();
					ClaimsSubmitPO claimsSubmitPO = util.getClaimsSubmitData(claimsRequestTransactionPOList);
					if(claimsSubmitPO.getEmployeeEmailId_2()==null){
						claimsSubmitPO.setEmployeeEmailId_2("");
					}
					context.getFlowScope().put("Response", gsonJSON.toJson(claimsSubmitPO));
			}
			else {
				FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestModalData", "Session is null");
				throw new IPruException("Session is null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestModalData", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}

		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestModalData", "onEntry of getBizRequestModalData Method End ");
		return success();
	}


	public Event getBizRequestDownloadData(RequestContext context) throws Exception {
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestDownloadData", "onEntry of getBizRequestDownloadData Method Start ");

		try {
			if (context != null) {

				HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
				

				ClaimsRequestTransactionPO claimsRequestTransactionPO = gsonJSON.fromJson(request.getReader(), ClaimsRequestTransactionPO.class);
				if (claimsRequestTransactionPO.equals(null)) {
					FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestModalData", "claimsDeathNonDeathPO is null");
					throw new IPruException("claimsDeathNonDeathPO is null");
				}
				
				Map<String, ClaimsRequestTransactionVO> claimsRequestTransactionVOMap = (Map<String, ClaimsRequestTransactionVO>) context.getFlowScope().get("ClaimsRequestTransactionVOMap");
				ClaimsRequestTransactionVO claimsRequestTransactionVO = claimsRequestTransactionVOMap.get(String.valueOf(claimsRequestTransactionPO.getCustomerTrxnId()));
				
				if(claimsRequestTransactionVO == null){
					FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestDownloadData", "claimsRequestTransactionVO is null");
					throw new IPruException("claimsRequestTransactionVO is null");								
				}
				
				Object[] paramArray = new Object[1];
				paramArray[0] = claimsRequestTransactionVO;
				BizRequest obj_bizReq = new BizRequest();
				obj_bizReq.addbusinessObjects("service-obj1", paramArray);
				context.getFlowScope().put("bizReqDownloadData", obj_bizReq);

			}
			else {
				FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestDownloadData", "context is null");
				throw new IPruException("context is null");
			}

		}
		catch (Exception e) {
			//e.printStackTrace();
			FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestModalData", "Exception came ", e);
			throwINeoFlowException(e, "GRPCL03", context);
		}

		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestDownloadData", "onEntry of getBizRequestDownloadData Method End ");
		return success();
	}

	
	public Event getBizResponseDownloadData(RequestContext context) throws Exception {
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseDownloadData", "Method Start ");
		
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		
		try {
			bizRes = (BizResponse) context.getFlowScope().get("bizResDownloadData");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {
					UploadFileVO uploadFileVO = (UploadFileVO) bizRes.getTransferObjects().get("response1");
					
					if(uploadFileVO != null){
						DownloadFileRequestPO downloadFileRequestPO = new DownloadFileRequestPO();
						downloadFileRequestPO.setFileId(String.valueOf(uploadFileVO.getDocId()));
						downloadFileRequestPO.setFileName("Claim_Data");
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(new Date());
						downloadFileRequestPO.setTimeToken(calendar.getTimeInMillis());
						
						
						HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
						if (httpSession == null) {
							FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseDownloadData", "Found null session");
							String gsonString = "ERROR";
							context.getFlowScope().put("Response", gsonString);
							return error();
						}
											
						httpSession.setAttribute("downloadFileRequestPOSession", downloadFileRequestPO);

						context.getFlowScope().put("Response", gsonJSON.toJson("Success"));
					} else {
						FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestModalData", "uploadFileVO is null");
						throw new IPruException("File Not Found");
					}					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseDownloadData", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}
		
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseDownloadData", "Method End ");		
		return success();
	}
	
	
	public Event getBizRequestExcelValidation(RequestContext context) throws Exception {

		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestExcelValidation", "getBizRequestExcelValidation Method Start");
		Gson gson = new Gson();
		ClaimsRequestTransactionPO claimsRequestTransactionPO=null;
		ClaimsExcelValidationPO claimsExcelValidationPO=null;
		try {

			if (context != null) {

				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				IPruUser userVO = new IPruUser();
				String clientId = null;
				String policyNo = null;
				long customerTrxnId=0L;
				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						 policyNo = userVo.getPolicyNo();
						 clientId = userVo.getClientId();
						

						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
						
						if (request != null) {
							claimsExcelValidationPO = gsonJSON.fromJson(request.getReader(), ClaimsExcelValidationPO.class);
							
							System.out.println(claimsExcelValidationPO);

							ClaimsExcelValidationVO claimsExcelValidationVO = dozerBeanMapper.map(claimsExcelValidationPO, ClaimsExcelValidationVO.class);
							
							//ClaimsRequestTransactionVO claimsRequestTransactionVO = new ClaimsRequestTransactionVO();
							//claimsExcelValidationVO.setCustomerTrxnId(customerTrxnId);
							//customerTrxnId=193;

							Object[] paramArray = new Object[1];

							if (claimsExcelValidationVO != null) {
								paramArray[0] = claimsExcelValidationVO;
								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);
								context.getFlowScope().put("bizReqExcelValidation", obj_bizReq);
							}
							else {
								FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestExcelValidation", "claimsExcelValidationVO should not be null");
								throw new IPruException("Error", "GRPT01", "trackervo should not be null");
							}

						}
						else {

							FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestExcelValidation", "request should not be null");
							throw new IPruException("Error", "GRPT01", "request should not be null");
						}
					}
					else {
						FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestExcelValidation", "userVo should not be null");
						throw new IPruException("Error", "GRPT01", "userVo should not be null");
					}
				}
				else {
					FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestExcelValidation", "httpSession should not be null");
					throw new IPruException("Error", "GRPT01", "httpSession should not be null");
				}
			}
			else {
				FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestExcelValidation", "Context should not be null");
				throw new IPruException("Error", "GRPT01", "Context should not be null");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestExcelValidation", "Exception came ", e);
			throwINeoFlowException(e, "GRPT01", context);
		}
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizRequestExcelValidation", "onEntry of getBizRequestExcelValidation Method End ");
		return success();
	}
	
	@MethodPost
	public Event getBizResponseExcelValidation(RequestContext context) throws Exception {

		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseExcelValidation", "getBizResponseExcelValidation Method start");

		
		
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		
		
		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResExcelValidation");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseExcelValidation", "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {
						List<ClaimsExcelResponsePO> claimsExcelResponsePOList=new ArrayList();
						List<ClaimsExcelValidationVO> claimsExcelValidationVOList = (List<ClaimsExcelValidationVO>) bizRes.getTransferObjects().get("response1");
						
						List<ClaimsExcelValidationPO> claimsExcelValidationPOList = new ArrayList<ClaimsExcelValidationPO>();
						if (claimsExcelValidationVOList != null) {
							
							
							for (ClaimsExcelValidationVO claimsExcelValidationVO : claimsExcelValidationVOList) {
								
								ClaimsExcelValidationPO claimsExcelValidationPO = new ClaimsExcelValidationPO();
								dozerBeanMapper.map(claimsExcelValidationVO, claimsExcelValidationPO);
								//claimsExcelValidationPO = dozerBeanMapper.map(claimsExcelValidationVO, ClaimsExcelValidationPO.class);
								
								
								
								claimsExcelValidationPOList.add(claimsExcelValidationPO);
								
								
						
							}
							
							/*if(CollectionUtils.isEmpty(claimsExcelValidationPOList))
							{
								throw new IPruException("Error", "GRPCL03", "No Data Found");
							}*/
							
							Map<String,ArrayList<String>> errorArray=new HashMap();
							
							ArrayList<String> error=new ArrayList();
							for(ClaimsExcelValidationPO claimsExcelValidationPO:claimsExcelValidationPOList)
							{
								
								String msg=claimsExcelValidationPO.getErrormessage();
								String[] parts = msg.split("#");
								
								
								if(errorArray.containsKey(String.valueOf(parts[0])))
										{
									
									error.add(String.valueOf(parts[1]));
									errorArray.put(String.valueOf(parts[0]),error);
										}
								else
								{
									error=new ArrayList();
									error.add(String.valueOf(parts[1]));
									errorArray.put(String.valueOf(parts[0]),error);
									//System.out.println(errorArray);
								}
								
								
							}
							
							ClaimsExcelResponsePO claimsExcelResponsePO= null;
							
							Iterator<Entry<String, ArrayList<String>>> entries = errorArray.entrySet().iterator();
							while (entries.hasNext()) {
								claimsExcelResponsePO=new ClaimsExcelResponsePO();
							    Entry<String, ArrayList<String>> entry = entries.next();
							    claimsExcelResponsePO.setKey(entry.getKey());
							    claimsExcelResponsePO.setValue(entry.getValue());
							    claimsExcelResponsePOList.add(claimsExcelResponsePO);
							}
						
						}
						String callJsonString = gsonJSON.toJson(claimsExcelResponsePOList);
						FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseExcelValidation", "callJsonString::" + callJsonString);
						context.getFlowScope().put("Response", callJsonString);
					}
				}
				else {
					FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseExcelValidation", "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseExcelValidation", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseExcelValidation", "Exception came ", e);
			throwINeoFlowException(e, "GRYY02", context);
		}
		FLogger.info("ClaimsApprovalLogger", "ClaimsApprovalHandler", "getBizResponseExcelValidation", "getBizResponseExcelValidation Method end");

		return success();

	}
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}
}
