package com.ipru.groups.handler;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dozer.DozerBeanMapper;
import org.dozer.util.ReflectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.webflow.core.collection.MutableAttributeMap;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.google.gson.Gson;
import com.ipru.IPruException;
import com.ipru.generic.po.GroupsErrorsPO;
import com.ipru.groups.customer.Customer;
import com.ipru.groups.exception.GroupSecurityException;
import com.ipru.groups.po.GroupsBasePo;
import com.ipru.groups.security.encryption.Encryption3DES;
import com.ipru.groups.security.handler.CsrfImplementation;
import com.ipru.groups.utilities.ContextKeyConstants;
import com.ipru.groups.utilities.EncodingUtility;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.groups.utilities.SessionKeyConstants;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.FunctionalityMasterVO;
import com.ipru.groups.vo.PolicyProductFundMasterVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.exception.ExceptionDelegate;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.businessdelegation.StatusVO;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodGet;
import com.tcs.security.annotations.MethodPost;
import com.tcs.web.handler.BaseHandler;

public abstract class IneoBaseHandler extends BaseHandler {

	@Autowired
	public transient DozerBeanMapper dozerBeanMapper;

	@Autowired
	public transient Gson gsonJSON;

	private static final long serialVersionUID = 1L;

	private static Properties constantsProp = null;
	private static Boolean transactionalOTPCallback;

	static {
		FileInputStream fis = null;
		constantsProp = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
		if (constantsProp == null) {
			constantsProp = new Properties();
			try {
				fis= new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
				constantsProp.load(fis);

			}
			catch (FileNotFoundException e) {
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				FLogger.error("GROUPLoggerError", "IneoBaseHandler", "IneoBaseHandler", errors.toString());
			}
			catch (IOException e) {
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				FLogger.error("GROUPLoggerError", "IneoBaseHandler", "IneoBaseHandler", errors.toString());
			}
			finally {
				try {
					if(fis!=null)
						fis.close();
				}
				catch (Exception e) {
					FLogger.error("GROUPLoggerError", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
							"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
					e.printStackTrace();
				} finally {
					fis=null;
				}
			}
		}

	}

	private String validationErrorMessages = null;

	public boolean isNotEmpty(String view) {
		return StringUtils.isNotEmpty(view);
	}

	@MethodPost
	public Event handleValidationException(RequestContext context) {

		GroupsErrorsPO errorsObj = new GroupsErrorsPO();
		errorsObj.setErrorMsg(getValidationErrorMessages());
		Gson gson2Json = new Gson();
		context.getFlowScope().put("handleCsrAppException", gson2Json.toJson(errorsObj));
		setValidationErrorMessages(null);
		return success();

	}

	public String getValidationErrorMessages() {
		return validationErrorMessages;
	}

	@MethodPost
	public void setValidationErrorMessages(String validationErrorMessages) {
		this.validationErrorMessages = validationErrorMessages;
	}

	public Event setCsrfTokenInFlow(RequestContext context) {
		FLogger.info("GROUPLogger", "CsrBaseHandler", "setCsrfTokenInFlow", "method start");
		context.getRequestScope().put("csrfToken", CsrfImplementation.genrateCsrfToken(context));
		FLogger.info("GROUPLogger", "CsrBaseHandler", "setCsrfTokenInFlow", "method end");
		return success();
	}

	protected Customer getCustomerBeanFromSession(RequestContext context) {
		FLogger.info("GROUPLogger", "CsrBaseHandler", "getCustomerBeanFromSession", "method start");
		Object paramObj = GroupSecurityUtil.getAttributeFromSession(context, SessionKeyConstants.CUSTOMER_SESSION_KEY);
		Customer paramBean = null;
		if (paramObj != null && paramObj instanceof Customer) {
			paramBean = (Customer) paramObj;
		}
		FLogger.info("GROUPLogger", "CsrBaseHandler", "getCustomerBeanFromSession", "method end");
		return paramBean;
	}
	protected String getLoggedInUserRole(RequestContext context) {
		IPruUser loggedInUser = (IPruUser) GroupSecurityUtil.getAttributeFromSession(context, SessionKeyConstants.USER_SESSION_KEY);
		return loggedInUser.getRoles();
	}

	public Event setCsrfToken(RequestContext context) {
		FLogger.info("GROUPLogger", "CsrBaseHandler", "setCsrfToken", "method start");
		CsrfImplementation.genrateCsrfToken(context);
		FLogger.info("GROUPLogger", "CsrBaseHandler", "setCsrfToken", "method end");
		return success();
	}

	protected String getClientIdFromSession(RequestContext context) {
		FLogger.info("GROUPLogger", "CsrBaseHandler", "getClientIdFromSession", "method start");
		Object paramObj = GroupSecurityUtil.getAttributeFromSession(context, SessionKeyConstants.CSR_CLIENT_ID_KEY);
		String clientIdFromSession = null;
		if (paramObj != null && paramObj instanceof String) {
			clientIdFromSession = (String) paramObj;
		}
		FLogger.info("GROUPLogger", "CsrBaseHandler", "getClientIdFromSession", "method end");
		return clientIdFromSession;
	}

	protected String getCsrfTokenFromSession(RequestContext context) {
		String csrfToken = null;
		csrfToken = (String) GroupSecurityUtil.getAttributeFromSession(context, "csrfToken");
		return csrfToken;
	}

	/**
	 * Method to check if OTP is required on Edit Buttons
	 * 
	 * @author Sudha Suman 736523(TCS)
	 * @param ObjContext
	 * @return
	 */
	@MethodPost
	public Event isOtpVerfcnReqd(RequestContext ObjContext) {
		FLogger.info("GROUPLogger", "CsrBaseHandler", "isOtpVerfcnReqd", "Method Starts");
		String loginRole = null;
		String isVerfcnReqd = "TRUE";
		String initialSearchedPolicy = null;
		// String pasaFlag = "";
		String otpVerfcnStatus = null;
		// String csrfToken = null;
		Gson gson = new Gson();
		String json = null;
		String encryptedJson = null;
		Map<String, String> map_result = new HashMap<String, String>();
		// pasaFlag = (String)
		// GroupSecurityUtil.getAttributeFromSession(ObjContext, "csr_pasaFlag");
		Customer custSummaryObj = (Customer) GroupSecurityUtil.getAttributeFromSession(ObjContext, SessionKeyConstants.CUSTOMER_SESSION_KEY);
		// ContractUpdateParamBean
		// contractBean=(ContractUpdateParamBean)ObjContext.getFlowScope().get("contractUpdateParamBean");
		// ProfileUpdateParamBean
		// profileBean=(ProfileUpdateParamBean)ObjContext.getFlowScope().get("profileParamBean");
		OTPNumberParamBean paramBean = new OTPNumberParamBean();
		IPruUser userdata = (IPruUser) GroupSecurityUtil.getAttributeFromSession(ObjContext, SessionKeyConstants.USER_SESSION_KEY);
		IPruUser userDtls = (IPruUser) GroupSecurityUtil.getAttributeFromSession(ObjContext, "userVO");
		if (userDtls != null) {
			loginRole = userDtls.getRoles();
		}

		// if(
		// (!StringUtils.equalsIgnoreCase(constantsProp.getProperty("customerRole"),
		// loginRole) &&
		// !StringUtils.equalsIgnoreCase(constantsProp.getProperty("AGENT"),
		// loginRole)) ||
		// (StringUtils.equalsIgnoreCase(constantsProp.getProperty("AGENT"),
		// loginRole) && !StringUtils.equalsIgnoreCase("validOtp", pasaFlag)))
		// if(
		// (!StringUtils.equalsIgnoreCase(constantsProp.getProperty("customerRole"),
		// loginRole) &&
		// !StringUtils.equalsIgnoreCase(constantsProp.getProperty("AGENT"),
		// loginRole)) ||
		// (StringUtils.equalsIgnoreCase(constantsProp.getProperty("AGENT"),
		// loginRole) && StringUtils.equalsIgnoreCase("validOtp", pasaFlag)))
		if (!StringUtils.equalsIgnoreCase(constantsProp.getProperty("customerRole"), loginRole)) {/*
																								 * /
																								 * /
																								 * Please
																								 * do
																								 * not
																								 * un
																								 * -
																								 * comment
																								 * the
																								 * below
																								 * line
																								 * .
																								 * This
																								 * is
																								 * to
																								 * skip
																								 * otp
																								 * /
																								 * /
																								 * verification
																								 * for
																								 * edits
																								 * .
																								 * isVerfcnReqd
																								 * =
																								 * "TRUE"
																								 * ;
																								 * isVerfcnReqd
																								 * =
																								 * "FALSE"
																								 * ;
																								 * paramBean
																								 * .
																								 * setCustId
																								 * (
																								 * custSummaryObj
																								 * .
																								 * getCustId
																								 * (
																								 * )
																								 * )
																								 * ;
																								 * paramBean
																								 * .
																								 * setEmail1
																								 * (
																								 * custSummaryObj
																								 * .
																								 * getPersonalEmail
																								 * (
																								 * )
																								 * )
																								 * ;
																								 * paramBean
																								 * .
																								 * setEmail2
																								 * (
																								 * custSummaryObj
																								 * .
																								 * getOfficialEmail
																								 * (
																								 * )
																								 * )
																								 * ;
																								 * paramBean
																								 * .
																								 * setMobile
																								 * (
																								 * custSummaryObj
																								 * .
																								 * getMobileNoOrgnl
																								 * (
																								 * )
																								 * )
																								 * ;
																								 * if
																								 * (
																								 * userdata
																								 * !=
																								 * null
																								 * )
																								 * {
																								 * if
																								 * (
																								 * CsrSecurityUtil
																								 * .
																								 * isReadAccess
																								 * (
																								 * ObjContext
																								 * ,
																								 * PriviledgeFunctionalityConstants
																								 * .
																								 * ISCUSTTYPELOGIN
																								 * .
																								 * toString
																								 * (
																								 * )
																								 * )
																								 * )
																								 * {
																								 * paramBean
																								 * .
																								 * setAdvisorCode
																								 * (
																								 * custSummaryObj
																								 * .
																								 * getCustId
																								 * (
																								 * )
																								 * )
																								 * ;
																								 * }
																								 * else
																								 * {
																								 * paramBean
																								 * .
																								 * setAdvisorCode
																								 * (
																								 * userdata
																								 * .
																								 * getUserName
																								 * (
																								 * )
																								 * )
																								 * ;
																								 * }
																								 * paramBean
																								 * .
																								 * setAdvisorName
																								 * (
																								 * userdata
																								 * .
																								 * getHashMapInfoByKey
																								 * (
																								 * RoleConstants
																								 * .
																								 * CONSTANT_LOGGEDIN_USER_NAME
																								 * )
																								 * )
																								 * ;
																								 * }
																								 * paramBean
																								 * .
																								 * setLoginRole
																								 * (
																								 * loginRole
																								 * )
																								 * ;
																								 * /
																								 * /
																								 * adding
																								 * Policy
																								 * No
																								 * by
																								 * Sudha
																								 * Suman
																								 * initialSearchedPolicy
																								 * =
																								 * (
																								 * String
																								 * )
																								 * CsrSecurityUtil
																								 * .
																								 * getAttributeFromSession
																								 * (
																								 * ObjContext
																								 * ,
																								 * "initialSearchedPolicy"
																								 * )
																								 * ;
																								 * paramBean
																								 * .
																								 * setIdentifierCode
																								 * (
																								 * initialSearchedPolicy
																								 * )
																								 * ;
																								 * paramBean
																								 * .
																								 * setIdentifierType
																								 * (
																								 * CsrOTPConstant
																								 * .
																								 * POLICYNO
																								 * .
																								 * getOtpConstant
																								 * (
																								 * )
																								 * )
																								 * ;
																								 * paramBean
																								 * .
																								 * setCustFirstName
																								 * (
																								 * custSummaryObj
																								 * .
																								 * getFirstName
																								 * (
																								 * )
																								 * )
																								 * ;
																								 * paramBean
																								 * .
																								 * setCustLastName
																								 * (
																								 * custSummaryObj
																								 * .
																								 * getLastName
																								 * (
																								 * )
																								 * )
																								 * ;
																								 * setOtpCallBacks
																								 * (
																								 * paramBean
																								 * ,
																								 * ObjContext
																								 * )
																								 * ;
																								 * paramBean
																								 * .
																								 * setHandleClickCallBack
																								 * (
																								 * "verifyOtp"
																								 * )
																								 * ;
																								 * paramBean
																								 * .
																								 * setVerfcnStatusElemId
																								 * (
																								 * "otpVerificationStatusId"
																								 * )
																								 * ;
																								 * json
																								 * =
																								 * gson
																								 * .
																								 * toJson
																								 * (
																								 * paramBean
																								 * )
																								 * ;
																								 * try
																								 * {
																								 * encryptedJson
																								 * =
																								 * CsrSecurityUtil
																								 * .
																								 * encodeBase64
																								 * (
																								 * Encryption3DES
																								 * .
																								 * encrypt
																								 * (
																								 * json
																								 * ,
																								 * "TSICDSI4CKENDVGCNPS1Z9PB"
																								 * )
																								 * )
																								 * ;
																								 * }
																								 * catch
																								 * (
																								 * Exception
																								 * e
																								 * )
																								 * {
																								 * StringWriter
																								 * errors
																								 * =
																								 * new
																								 * StringWriter
																								 * (
																								 * )
																								 * ;
																								 * e
																								 * .
																								 * printStackTrace
																								 * (
																								 * new
																								 * PrintWriter
																								 * (
																								 * errors
																								 * )
																								 * )
																								 * ;
																								 * }
																								 * map_result
																								 * .
																								 * put
																								 * (
																								 * "otpParamJson"
																								 * ,
																								 * encryptedJson
																								 * )
																								 * ;
																								 */
		}
		else {
			isVerfcnReqd = "FALSE";
			// csrfToken=getCsrfTokenFromSession(ObjContext);
			// otpVerfcnStatus=csrfToken+"#true";
			otpVerfcnStatus = "true";
			map_result.put("otpVerfcnStatus", otpVerfcnStatus);
			/*
			 * try { otpVerfcnStatus=Encryption3DES.encrypt(otpVerfcnStatus);
			 * map_result.put("otpVerfcnStatus",otpVerfcnStatus); } catch
			 * (Exception e) { otpVerfcnStatus=null; e.printStackTrace(); }
			 */
		}

		map_result.put("isVerfcnReqd", isVerfcnReqd);

		String resultJson = gson.toJson(map_result);
		ObjContext.getFlowScope().put("mapForPGI", resultJson);
		FLogger.info("GROUPLogger", "CsrBaseHandler", "isOtpVerfcnReqd", "Method Ends");
		return success();
	}

	public abstract void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext);

	public DozerBeanMapper getDozerBeanMapper() {
		return dozerBeanMapper;
	}

	public void setDozerBeanMapper(DozerBeanMapper dozerBeanMapper) {
		this.dozerBeanMapper = dozerBeanMapper;
	}

	/**
	 * Method to handle security breach on direct flow hit without verifying OTP
	 * 
	 * @author Sudha Suman(736523)TCS
	 * @param context
	 * @return
	 * @throws GroupSecurityException
	 */
	/*
	 * @MethodGet public Event isAuthorizedOnEntry(RequestContext context)
	 * throws GroupSecurityException { boolean isAuthenticationRequired =
	 * GroupSecurityUtil.isAuthenticationRequired(context); String csr_pasaFlag =
	 * (String) GroupSecurityUtil.getAttributeFromSession(context,
	 * "csr_pasaFlag"); IPruUser userVO = (IPruUser)
	 * GroupSecurityUtil.getAttributeFromSession(context, "userVO"); if
	 * (isAuthenticationRequired) { if
	 * (((StringUtils.equalsIgnoreCase(csr_pasaFlag, "false") ||
	 * StringUtils.equalsIgnoreCase(csr_pasaFlag, "validOtp")) ||
	 * StringUtils.equalsIgnoreCase(constantsProp.getProperty("unsecCustRole"),
	 * userVO.getRoles()) ||
	 * StringUtils.equalsIgnoreCase(constantsProp.getProperty("WEBSITEYRole"),
	 * userVO.getRoles()) ||
	 * StringUtils.equalsIgnoreCase(constantsProp.getProperty("WEBSITERole"),
	 * userVO.getRoles()) ||
	 * StringUtils.equalsIgnoreCase(constantsProp.getProperty("SURRENDERRole"),
	 * userVO.getRoles())) && isAuthenticationRequired) { return success(); }
	 * else { FLogger.error("securityerror", "CsrBaseHandler", "isAuthorized",
	 * "User is not authorized to view the page as per custom authorization.");
	 * throw new GroupSecurityException("User is not authorized exception"); } }
	 * return success(); }
	 */
	/**
	 * This method is used to decide whether to show OTP popup or not on widget
	 * click.
	 * 
	 * @author Sudha Suman(736523)TCS
	 * @param context
	 * @return
	 * @throws GroupSecurityException
	 */
	@MethodPost
	public Event isAuthorized(RequestContext context) throws GroupSecurityException {
		try {
			String pasaFlag = (String) GroupSecurityUtil.getAttributeFromSession(context, "csr_pasaFlag");
			String widgetId = (String) ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getParameter("otpAuthWidgetId");

			Map<String, String> map_result = new HashMap<String, String>();
			String initialSearchedPolicy = null;
			String loginRole = null;
			String isAuthentcnReqd = "TRUE";
			boolean isAuthenticationRequired = false;
			Gson gson = new Gson();
			String json = null;
			IPruUser userDtls = (IPruUser) GroupSecurityUtil.getAttributeFromSession(context, "userVO");

			// Set pasaFlag to true if otpType is transactionalOTP
			String otpType = (String) ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getParameter("otpType");
			if (StringUtils.isNotBlank(otpType) && StringUtils.equalsIgnoreCase(constantsProp.getProperty("TRANSACTIONAL_OTP"), otpType)) {
				pasaFlag = "true";
			}
			if (userDtls != null) {
				loginRole = userDtls.getRoles();
			}

			isAuthenticationRequired = GroupSecurityUtil.isAuthenticationRequired(context);
			if (isAuthenticationRequired) {
				if (StringUtils.equalsIgnoreCase(pasaFlag, "false")) {
					// is redundant condition
					isAuthentcnReqd = "FALSE";
				}
				else {
					if (!StringUtils.equalsIgnoreCase("validOtp", pasaFlag)) {
						isAuthentcnReqd = "TRUE";
					}
					else {
						isAuthentcnReqd = "FALSE";
					}
				}
			}
			else {
				isAuthentcnReqd = "FALSE";
			}

			OTPNumberParamBean paramBean = new OTPNumberParamBean();
			if (StringUtils.equalsIgnoreCase("TRUE", isAuthentcnReqd)) {
				Customer custObj = (Customer) GroupSecurityUtil.getAttributeFromSession(context, SessionKeyConstants.CUSTOMER_SESSION_KEY);
				IPruUser userdata = (IPruUser) GroupSecurityUtil.getAttributeFromSession(context, "userVO");
				paramBean.setCustId(custObj.getCustId());
				paramBean.setEmail1(custObj.getPersonalEmail());
				paramBean.setEmail2(custObj.getOfficialEmail());
				paramBean.setMobile(custObj.getMobileNoOrgnl());
				/*
				 * if (userdata != null) { if
				 * (GroupSecurityUtil.isReadAccess(context,
				 * PriviledgeFunctionalityConstants.ISCUSTTYPELOGIN.toString()))
				 * { paramBean.setAdvisorCode(custObj.getCustId()); } else {
				 * paramBean.setAdvisorCode(userdata.getUserName()); }
				 * paramBean.
				 * setAdvisorName(userdata.getHashMapInfoByKey(RoleConstants
				 * .CONSTANT_LOGGEDIN_USER_NAME)); }
				 */
				paramBean.setLoginRole(loginRole);
				initialSearchedPolicy = (String) GroupSecurityUtil.getAttributeFromSession(context, "initialSearchedPolicy");
				paramBean.setIdentifierCode(initialSearchedPolicy);
				// paramBean.setIdentifierType(CsrOTPConstant.POLICYNO.getOtpConstant());
				paramBean.setCustFirstName(custObj.getFirstName());
				paramBean.setCustLastName(custObj.getLastName());
				paramBean.setHandleClickCallBack("verifyOtp");
				setOtpCallBacks(paramBean, context);
				paramBean.setVerfcnStatusElemId("pasaOtpVerfcnStatus");
				json = gson.toJson(paramBean);
				String encryptedJson = null;
				try {
					encryptedJson = EncodingUtility.encodeBase64(Encryption3DES.encrypt(json, "TSICDSI4CKENDVGCNPS1Z9PB"));
				}
				catch (Exception e) {
					StringWriter errors = new StringWriter();
					e.printStackTrace(new PrintWriter(errors));
					FLogger.error("GROUPLoggerError", "IneoBaseHandler", "isAuthorized", errors.toString());
				}
				map_result.put("otpParamJson", encryptedJson);
			}
			else if (StringUtils.isNotBlank(otpType) && StringUtils.equalsIgnoreCase(constantsProp.getProperty("TRANSACTIONAL_OTP"), otpType)) {
				setOtpCallBacks(paramBean, context);
				map_result.put("otpOnSubmitCallBack", String.valueOf(getTransactionalOTPCallback()));
			}
			map_result.put("isAuthentcnReqd", isAuthentcnReqd);
			map_result.put("onWidgetId", widgetId);

			String resultJson = gson.toJson(map_result);
			context.getFlowScope().put("searchResultJson", resultJson);
		}
		catch (Exception e) {
			throw new GroupSecurityException();
		}
		return success();
	}

	/**
	 * This method is used to set the OTPNumberParamBean which was commented
	 * from OTPManagerHandler
	 * 
	 * @author Nishant Jethwa
	 * @param context
	 * @return
	 * @throws
	 */

	@MethodGet
	public Event setParamBean(RequestContext context) throws Exception {
		try {
			IPruUser userVo = (IPruUser) GroupSecurityUtil.getAttributeFromSession(context, "userVO");
			OTPNumberParamBean paramBean = new OTPNumberParamBean();
			String loginRole = null;
			String initialSearchedPolicy = null;
			// String json = null;
			if (userVo != null) {
				paramBean.setCustId(userVo.getClientId());
				paramBean.setEmail1(userVo.getEmailId());
				// paramBean.setEmail2(custObj.getOfficialEmail());
				paramBean.setMobile(userVo.getMobileNo());
				// if (GroupSecurityUtil.isReadAccess(context,
				// PriviledgeFunctionalityConstants.ISCUSTTYPELOGIN.toString()))
				// {
				paramBean.setAdvisorCode(userVo.getClientId());
				/*
				 * } else { paramBean.setAdvisorCode(userVo.getUsername()); }
				 */
				paramBean.setAdvisorName(userVo.getUsername());
				loginRole = userVo.getRoles();
				paramBean.setLoginRole(loginRole);
				paramBean.setPolicyNo(userVo.getPolicyNo());
			}

			// initialSearchedPolicy = (String)
			// GroupSecurityUtil.getAttributeFromSession(context,
			// "initialSearchedPolicy"); // check with ameya sir
			paramBean.setIdentifierCode(userVo.getClientId());
			paramBean.setIdentifierType("CLIENTID");
			paramBean.setCustFirstName(userVo.getClientName());
			// paramBean.setCustLastName(custObj.getLastName());
			// String jsCallBackFunction = (String) ((HttpServletRequest)
			// context.getExternalContext().getNativeRequest()).getParameter("jsCallBackFunction");
			// context.getFlowScope().put("jsCallBackFunction",
			// jsCallBackFunction);
			paramBean.setHandleClickCallBack("verifyOtp");
			setOtpCallBacks(paramBean, context);
			paramBean.setVerfcnStatusElemId("pasaOtpVerfcnStatus");
			// json = gson.toJson(paramBean);
			context.getFlowScope().put("Response", paramBean);
			GroupSecurityUtil.setAttributeInSession(context, "otpParamBean", paramBean);
		}
		catch (Exception e) {
			throwINeoFlowException(e, context);
		}

		return success();
	}

	// ====================Added by Hiren
	// Sonawala=======================================//
	/*
	 * public Event checkValueForFlow(RequestContext p_ObjContext) throws
	 * GroupSecurityException { isPOSTRequest(p_ObjContext); // HttpSession
	 * httpSession = ((HttpServletRequest) //
	 * p_ObjContext.getExternalContext().getNativeRequest()).getSession();
	 * HttpServletRequest request = (HttpServletRequest)
	 * p_ObjContext.getExternalContext().getNativeRequest(); if
	 * (StringUtils.isNotBlank((String) request.getParameter("dashboard"))) {
	 * String custIdInSession = (String)
	 * GroupSecurityUtil.getAttributeFromSession(p_ObjContext,
	 * SessionKeyConstants.CSR_CLIENT_ID_KEY); //@SuppressWarnings("unchecked")
	 * //List<CsrPolicyDetailsVO> policyDetailList =
	 * (ArrayList<CsrPolicyDetailsVO>)
	 * GroupSecurityUtil.getAttributeFromSession(p_ObjContext,
	 * SessionKeyConstants.POLICY_LIST_SESSION_KEY); Customer custObj =
	 * (Customer) GroupSecurityUtil.getAttributeFromSession(p_ObjContext,
	 * SessionKeyConstants.CUSTOMER_SESSION_KEY); if
	 * (StringUtils.isBlank(custIdInSession) || custObj == null ||
	 * StringUtils.isBlank(custObj.getCustId()) ||
	 * CollectionUtils.isEmpty(policyDetailList)) {
	 * p_ObjContext.getFlowScope().put("searchHome", "searchHome"); return
	 * success(); } } return success(); }
	 *//*
		 * public void isPOSTRequest(RequestContext p_ObjContext) throws
		 * GroupSecurityException { HttpServletRequest requestObj =
		 * (HttpServletRequest)
		 * p_ObjContext.getExternalContext().getNativeRequest(); if
		 * (!"POST".equalsIgnoreCase(requestObj.getMethod())) { IPruUser usrVO =
		 * (IPruUser) GroupSecurityUtil.getAttributeFromSession(p_ObjContext,
		 * "userVO"); List<String> dataList =
		 * Arrays.asList(requestObj.getRequestURI().split("/")); String pageName
		 * = null; if (CollectionUtils.isNotEmpty(dataList)) { pageName =
		 * dataList.get(2); } FLogger.error("securityerror", "CsrBaseHandler",
		 * "isPOSTRequest", "Forged Request expecting POST::AccessedPageName::"
		 * + pageName + "::LoggedinUserDetails::" + usrVO.getUserId()); throw
		 * new GroupSecurityException("Forged Request expecting POST"); }
		 * return; }
		 */

	/*
	 * @MethodGet public Event checkPOSTRequest(RequestContext p_ObjContext)
	 * throws GroupSecurityException { isPOSTRequest(p_ObjContext); return
	 * success(); }
	 */// ====================Endeded by Hiren
		// Sonawala=======================================//

	/*
	 * protected Customer updateAndGetCustomerDetails(Customer custSummaryObj,
	 * List<BusinessParametersList> finalBigList) throws Exception {
	 * custSummaryObj.setEmailIdOrgnl(custSummaryObj.getEmail());
	 * custSummaryObj.setPersonalEmail(custSummaryObj.getPersonalEmail());
	 * custSummaryObj.setMobileNoOrgnl(custSummaryObj.getMobileNo());
	 * custSummaryObj.setNationalityCode(custSummaryObj.getNationality());
	 * return custSummaryObj; }
	 */

	/**
	 * @author Sneha Pawar(736680)Tcs method to get index value for business
	 *         param
	 * @param indexValue
	 * @return
	 * @throws Exception
	 */

	public int getDropdownIndexforbusinessParam(String indexValue) throws Exception {

		int businessParamName = Integer.parseInt(getBusinessParameterProperties().getProperty(indexValue));

		return businessParamName;

	}

	/**
	 * Method to retrive the param value from businessParamLa value
	 * 
	 * @author Sneha Pawar(736680)TCS
	 * @param custSummaryObj
	 * @param finalBigList
	 * @return
	 * @throws Exception
	 */
	/*
	 * @SuppressWarnings("unchecked") public String
	 * getParamName(List<BusinessParametersList> finalBigList, int i, String
	 * laValue) { String ParamName = null; if (finalBigList != null) {
	 * List<BusinessParametersList> businessParams =
	 * (List<BusinessParametersList>) finalBigList.get(i); if (businessParams !=
	 * null) { for (BusinessParametersList paramList : businessParams) { if
	 * (paramList != null) { if
	 * (paramList.getBusinessParamLA().equalsIgnoreCase(laValue)) { ParamName =
	 * paramList.getParamName(); break; } } } } } return ParamName; }
	 */

	/**
	 * @author Sneha Pawar(736680)Tcs
	 * @return
	 * @throws Exception
	 */
	private Properties getBusinessParameterProperties() throws Exception {
		Properties getBusinessParameterProperties = new Properties();
		if (MasterPropertiesFileLoader.CONSTANT_APPLICATION_FORM_BSNS_PRM_ARRAY_MAPPING != null) {
			getBusinessParameterProperties = MasterPropertiesFileLoader.CONSTANT_APPLICATION_FORM_BSNS_PRM_ARRAY_MAPPING;
		}
		else {
			/*
			 * try { getBusinessParameterProperties.load(new
			 * FileInputStream(GroupCommonConstants
			 * .CONSTANT_APPLICATION_FORM_BSNS_PRM_ARRAY_MAPPING)); } catch
			 * (FileNotFoundException e) { StringWriter errors = new
			 * StringWriter(); e.printStackTrace(new PrintWriter(errors));
			 * FLogger.error("GROUPLoggerError", "CsrBaseHandler",
			 * "getBusinessParameterProperties", errors.toString()); throw new
			 * Exception(e); // e.printStackTrace(); } catch (IOException e) {
			 * StringWriter errors = new StringWriter(); e.printStackTrace(new
			 * PrintWriter(errors)); FLogger.error("GROUPLoggerError",
			 * "CsrBaseHandler", "getBusinessParameterProperties",
			 * errors.toString()); throw new Exception(e); //
			 * e.printStackTrace(); }
			 */
		}
		return getBusinessParameterProperties;
	}

	@Override
	protected Event doPreExecute(RequestContext context) throws Exception {
		String methodcalled = getMethodResolver().resolveMethod(context);
		// Class clazz=getMethodResolver().getClass();
		String classname = this.getClass().toString();
		StringBuffer uniqueKeyMethodName = new StringBuffer();
		uniqueKeyMethodName.append(methodcalled);
		uniqueKeyMethodName.append(classname);
		String uniqueMethodName = uniqueKeyMethodName.toString();
		////System.out.println("METHOD NAME::::" + methodcalled);
		Method methodtocheck = ReflectionUtils.getMethod(this.getClass(), methodcalled);
		HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

		/*
		 * if (ServiceCacheManager.getFromCache(uniqueMethodName) != null) { if
		 * (StringUtils.equalsIgnoreCase(methodcalled, (String)
		 * ServiceCacheManager.getFromCache(uniqueMethodName))) { if
		 * (!org.apache
		 * .commons.lang.StringUtils.equalsIgnoreCase(request.getMethod(),
		 * "POST")) { throw new SecurityException("Bad Request", new
		 * Exception()); } } } else if
		 * (ServiceCacheManager.getFromCache(uniqueMethodName + "_GETMETHOD") !=
		 * null) { } else if
		 * (methodtocheck.isAnnotationPresent(com.tcs.security.
		 * annotations.MethodPost.class)) {
		 * ServiceCacheManager.storeCache(uniqueMethodName, methodcalled); if
		 * (!org
		 * .apache.commons.lang.StringUtils.equalsIgnoreCase(request.getMethod
		 * (), "POST")) { throw new SecurityException("Bad Request", new
		 * Exception()); } } else if
		 * (org.apache.commons.lang3.StringUtils.equalsIgnoreCase
		 * (request.getMethod(), "GET")) {
		 * ServiceCacheManager.storeCache(uniqueMethodName + "_GETMETHOD",
		 * methodcalled); } else if
		 * (org.apache.commons.lang3.StringUtils.equalsIgnoreCase
		 * (request.getMethod(), "POST") &&
		 * !methodtocheck.isAnnotationPresent(com
		 * .tcs.security.annotations.MethodGet.class)) {
		 * ////System.out.println("Please Annotate " + methodcalled + " method of "
		 * + this.getClass() + " with @ MethodPost annotation"); throw new
		 * SecurityException("Security Validation Failed", new Exception()); }
		 */

		/*
		 * BizResponse bizRes = getBizResponse(context); if (bizRes != null) {
		 * String responseCheck = (String) bizRes.getStatusVO().getStatus(); if
		 * (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
		 * throwINeoFlowException(bizRes.getStatusVO(), context); } }
		 */
		return null;
	}

	public BizResponse getBizResponse(RequestContext context) {
		BizResponse bizRes = (BizResponse) context.getFlowScope().get(ContextKeyConstants.CONTEXT_KEY_BIZRESPONSE);
		return bizRes;
	}

	@SuppressWarnings("rawtypes")
	protected void doPostExecute(RequestContext context) throws Exception {
		MutableAttributeMap<Object> flowKeyMap = context.getFlowScope();
		Map<String, Object> mapObj = flowKeyMap.asMap();
		Iterator it = mapObj.entrySet().iterator();
		String contextReq = "";
		HttpServletRequest request = ((HttpServletRequest) (context.getExternalContext().getNativeRequest()));
		if (request != null) {
			String reqUrl = request.getRequestURL() != null ? String.valueOf(request.getRequestURL()) : "";
			contextReq = reqUrl.replace(request.getServletPath(), "");
		}
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			Object obj = pair.getValue();
			if (obj instanceof GroupsBasePo) {
				((GroupsBasePo) obj).setSubFlowExecutionUrl(context.getFlowExecutionUrl());
				context.getFlowScope().put(pair.getKey().toString(), obj);
			}
		}
		context.getExternalContext().getSessionMap().put("subFlowExecutionUrl", context.getFlowExecutionUrl());
		context.getFlowScope().put("reqContext", contextReq);
	}

	// Added by Hiren Sonawala for Jcryption --- Secured Post Flag(Maintain
	// Jcryption by Flag)
	@MethodGet
	public Event securedPostFlag(RequestContext context) {
		FileInputStream fis = null;
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		if (httpSession.getAttribute(SessionKeyConstants.CSR_PAYMENT_SECURED_POST_FLAG) == null || httpSession.getAttribute(SessionKeyConstants.CSR_PAYMENT_SECURED_POST_FLAG) == "") {
			Properties constantsProperites = new Properties();
			try {
				fis=new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
				constantsProperites.load(fis);
			}
			catch (Exception e) {
				// e.printStackTrace();
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				FLogger.error("GROUPLoggerError", "IneoBaseHandler", "securedPostFlag", errors.toString());
				FLogger.info("GROUPLogger", "IneoBaseHandler", "securedPostFlag", "Load constantProperties file for Secured Post flag :::" + constantsProperites);
			}
			
			finally {
				try {
					if(fis!=null)
						fis.close();
				}
				catch (Exception e) {
					FLogger.error("GROUPLoggerError", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
							"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
					e.printStackTrace();
				} finally {
					fis=null;
				}
			}
			if (constantsProperites != null) {
				httpSession.setAttribute(SessionKeyConstants.CSR_PAYMENT_SECURED_POST_FLAG, constantsProperites.getProperty("SECURE_POST_FLAG"));
				
				
			}
			
			
		}
		return success();
	}

	/*
	 * public static List<PriviledgeFunctionalitySubTypeConstants>
	 * retrieveReadAccessPriviledge(RequestContext context,
	 * List<PriviledgeFunctionalitySubTypeConstants> priviledgeList) { boolean
	 * checkReadAccess = false; List<PriviledgeFunctionalitySubTypeConstants>
	 * eligiblePriviledges = new
	 * ArrayList<PriviledgeFunctionalitySubTypeConstants>(1); if (priviledgeList
	 * != null) { for (PriviledgeFunctionalitySubTypeConstants priviledge :
	 * priviledgeList) { checkReadAccess = GroupSecurityUtil.isReadAccess(context,
	 * priviledge.toString()); if (checkReadAccess) {
	 * eligiblePriviledges.add(priviledge); } } return eligiblePriviledges; }
	 * return null; } public static PriviledgeFunctionalitySubTypeConstantsNew
	 * retrieveReadAccessPriviledgeNew(RequestContext
	 * context,PriviledgeFunctionalityConstants mainFunctionality,
	 * List<PriviledgeFunctionalitySubTypeConstantsNew> priviledgeList,String
	 * subFunctionality) { boolean checkReadAccess = false;
	 * PriviledgeFunctionalitySubTypeConstantsNew eligiblePriviledges = null;
	 * subFunctionality += mainFunctionality.getPriviledgeValue(); if
	 * (priviledgeList != null) { for
	 * (PriviledgeFunctionalitySubTypeConstantsNew priviledge : priviledgeList)
	 * { if(subFunctionality.equalsIgnoreCase(priviledge.
	 * getfunctionalityPriviledgeValue())) { checkReadAccess =
	 * GroupSecurityUtil.isReadAccess(context, priviledge.toString()); if
	 * (checkReadAccess) { eligiblePriviledges = priviledge; } } } return
	 * eligiblePriviledges; } return null; } public static
	 * List<PriviledgeFunctionalitySubTypeConstants>
	 * getPreviledgeValueBasedOnFunctionality(PriviledgeFunctionalityConstants
	 * priviledgeFunctionality) { List<PriviledgeFunctionalitySubTypeConstants>
	 * functionalityPreviledge = new
	 * ArrayList<PriviledgeFunctionalitySubTypeConstants>(1); for
	 * (PriviledgeFunctionalitySubTypeConstants functionalityPreviledgeValue :
	 * PriviledgeFunctionalitySubTypeConstants.values()) { if
	 * (StringUtils.equalsIgnoreCase
	 * (functionalityPreviledgeValue.getPriviledgeValue(),
	 * priviledgeFunctionality.getPriviledgeValue())) {
	 * functionalityPreviledge.add(functionalityPreviledgeValue); } } return
	 * functionalityPreviledge; } public static
	 * List<PriviledgeFunctionalitySubTypeConstantsNew>
	 * getPreviledgeValueBasedOnFunctionalityNew
	 * (PriviledgeFunctionalityConstants priviledgeFunctionality) {
	 * List<PriviledgeFunctionalitySubTypeConstantsNew> functionalityPreviledge
	 * = new ArrayList<PriviledgeFunctionalitySubTypeConstantsNew>(1); for
	 * (PriviledgeFunctionalitySubTypeConstantsNew functionalityPreviledgeValue
	 * : PriviledgeFunctionalitySubTypeConstantsNew.values()) { if
	 * (StringUtils.equalsIgnoreCase
	 * (functionalityPreviledgeValue.getPriviledgeValue(),
	 * priviledgeFunctionality.getPriviledgeValue())) {
	 * functionalityPreviledge.add(functionalityPreviledgeValue); } } return
	 * functionalityPreviledge; }
	 */
	/**
	 * Method to be added on all submit transitions where OTP Verification is
	 * needed for back-end validation. The idea is to not hit the flow
	 * transition without OTP verification of course which will be controlled
	 * using the AUTHORIZATION_TYPE flag in TBL_ROLESCREEN... As it would be
	 * form submit which would be a POST request hence the annotation is also
	 * added.
	 * 
	 * @author Ameya Nerurkar
	 * @param context
	 * @return
	 */
	@MethodPost
	public Event isAuthorizedOnSubmit(RequestContext context) throws GroupSecurityException {
		boolean isAuthenticationRequired = GroupSecurityUtil.isAuthenticationRequired(context);
		Boolean isOtpValidated = null;
		if (isAuthenticationRequired) {
			// isOtpValidated =
			// context.getFlowScope().getBoolean(SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);//
			// For Backend validation
			isOtpValidated = (Boolean) GroupSecurityUtil.getAttributeFromSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);
			if (Boolean.TRUE.equals(isOtpValidated)) {
				GroupSecurityUtil.removeAttributeInSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);
				return success();
			}
			else {
				throw new GroupSecurityException("User is not authorized exception");
			}

		}

		return success();
	}

	/*
	 * @MethodPost public Event getBizReqForOtpVerification(RequestContext
	 * context) throws GroupSecurityException { String pasaFlag = "true"; String
	 * encryptedOtpStatus = null; boolean otpVerfcnStatus = Boolean.FALSE;
	 * HttpSession httpSession = ((HttpServletRequest)
	 * context.getExternalContext().getNativeRequest()).getSession();
	 * encryptedOtpStatus = ((HttpServletRequest)
	 * (context.getExternalContext().getNativeRequest
	 * ())).getParameter("pasaOtpVerfcnStatus"); String
	 * encryptedOtpStatusFromSession = (String)
	 * GroupSecurityUtil.getAttributeFromSession(context,
	 * SessionKeyConstants.CSR_OTP_VERFCN_STATUS); if
	 * (StringUtils.isBlank(getTransactionalOTPCallback())) { if
	 * (httpSession.getAttribute(SessionKeyConstants.CSR_OTP_VERFCN_STATUS) !=
	 * null) {
	 * httpSession.removeAttribute(SessionKeyConstants.CSR_OTP_VERFCN_STATUS); }
	 * } if (!StringUtils.equalsIgnoreCase(encryptedOtpStatusFromSession,
	 * encryptedOtpStatus)) { FLogger.error("securityerror", "CsrHandler",
	 * "getBizReqForOtpVerification",
	 * "Security Exception::Forgery for OTP::UserDetails::" +
	 * ToStringBuilder.reflectionToString((IPruUser)
	 * GroupSecurityUtil.getAttributeFromSession(context,
	 * SessionKeyConstants.USER_SESSION_KEY))); throw new
	 * GroupSecurityException("Request forgery for OTP"); } if
	 * (StringUtils.equalsIgnoreCase("true", encryptedOtpStatus)) {
	 * otpVerfcnStatus = true; } if (otpVerfcnStatus) { if
	 * (StringUtils.isNotBlank(getTransactionalOTPCallback())) { Map<String,
	 * String> map = new HashMap<String, String>(1);
	 * map.put("transactionalOTPCallback", getTransactionalOTPCallback());
	 * context.getFlowScope().put("searchResultJson", new Gson().toJson(map));
	 * context.getFlowScope().put(SessionKeyConstants.
	 * CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED, true);
	 * setTransactionalOTPCallback(null); } else { pasaFlag = "validOtp";
	 * GroupSecurityUtil.setAttributeInSession(context, "csr_pasaFlag", pasaFlag);
	 * } } return success(); }
	 */public Boolean getTransactionalOTPCallback() {
		return transactionalOTPCallback;
	}

	public void setTransactionalOTPCallback(Boolean transactionalOTPCallback) {
		this.transactionalOTPCallback = transactionalOTPCallback;
	}

	/*
	 * public java.sql.Date getExecutionDate(String
	 * cutOffTime,List<NSEHolidaysVO> list) { java.sql.Date executionDate =
	 * null; java.util.Date executionDateCalc = new
	 * java.util.Date(System.currentTimeMillis()); try { executionDateCalc =
	 * getNewExecutionDate(executionDateCalc,cutOffTime,list); executionDate =
	 * new java.sql.Date(executionDateCalc.getTime()); } catch (ParseException
	 * e) { return executionDate; } }
	 */

	private Calendar getDateBasedOnCutOffTime(java.util.Date executionDate, String cutOffTime) {
		Calendar executionCal = null;
		Calendar cuttOffTimeCal = null;
		List<String> executionDateParams = null;
		if (StringUtils.isNotBlank(cutOffTime) && executionDate != null) {
			executionCal = Calendar.getInstance();
			executionCal.setLenient(false);
			executionCal.setTime(executionDate);
			executionDateParams = Arrays.asList(cutOffTime.split(":"));
			if (CollectionUtils.isNotEmpty(executionDateParams)) {
				cuttOffTimeCal = Calendar.getInstance();
				cuttOffTimeCal.setLenient(false);
				cuttOffTimeCal.setTime(executionDate);
				cuttOffTimeCal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(executionDateParams.get(0)));
				cuttOffTimeCal.set(Calendar.MINUTE, Integer.parseInt(executionDateParams.get(1)));
				cuttOffTimeCal.set(Calendar.SECOND, Integer.parseInt(executionDateParams.get(2)));
			}
			if (executionCal.getTimeInMillis() >= cuttOffTimeCal.getTimeInMillis()) {
				executionCal.add(Calendar.DAY_OF_MONTH, 1);
			}
			executionCal.set(Calendar.HOUR_OF_DAY, 0);
			executionCal.set(Calendar.MINUTE, 0);
			executionCal.set(Calendar.SECOND, 0);
			executionCal.set(Calendar.MILLISECOND, 0);
		}
		return executionCal;

	}

	/*
	 * private Calendar getNSEAndWeekendLogic(Calendar executionCal,
	 * List<NSEHolidaysVO> nseHolidayList){ Calendar holidayCalendar =
	 * Calendar.getInstance(); holidayCalendar.setLenient(false); Date
	 * holidayDate = null; if(CollectionUtils.isNotEmpty(nseHolidayList)){ for
	 * (NSEHolidaysVO nseHolidaysVO : nseHolidayList) { if(nseHolidaysVO!=null){
	 * holidayDate = new Date(nseHolidaysVO.getHolidayDate().getTime());
	 * holidayCalendar.setTime(holidayDate);
	 * if(executionCal.get(Calendar.DAY_OF_YEAR) ==
	 * holidayCalendar.get(Calendar.DAY_OF_YEAR)){
	 * executionCal.add(Calendar.DAY_OF_MONTH, 1); } holidayDate=null;
	 * executionCal = getDateAfterRunningWeekendLogic(executionCal); } } }
	 * return executionCal; }
	 */

	/*
	 * private java.util.Date getNewExecutionDate(java.util.Date
	 * executionDate,String cutoffTime,List<NSEHolidaysVO> nseHolidays) throws
	 * ParseException { Calendar executionCal = null; //Execution Date to be
	 * changed based on cutofftime executionCal =
	 * getDateBasedOnCutOffTime(executionDate, cutoffTime); //Execution Date to
	 * be checked if the day is Weekend executionCal =
	 * getDateAfterRunningWeekendLogic(executionCal); //Execution Date to be
	 * checked if the day is Long Weekend executionCal =
	 * getNSEAndWeekendLogic(executionCal, nseHolidays); return
	 * executionCal.getTime(); }
	 */

	private Calendar getDateAfterRunningWeekendLogic(Calendar executionCal) {
		if (executionCal != null) {
			if (executionCal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
				// Set Date +2
				executionCal.add(Calendar.DAY_OF_MONTH, 2);
			}
			if (executionCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
				// Set Date +1
				executionCal.add(Calendar.DAY_OF_MONTH, 1);
			}
		}
		return executionCal;
	}

	@MethodGet
	public Event getFlowId(RequestContext context) {
		FLogger.info("GROUPLogger", "IneoBaseHandler", "getFlowId(RequestContext context)", "Inside get flowId");
		String flowId = null;
		flowId = context.getActiveFlow().getId();
		context.getFlowScope().put("pageName", flowId);
		return success();
	}

	public static final boolean isERROR(String str) {
		return StringUtils.equalsIgnoreCase(str, "ERROR");
	}

	public static final boolean isINFO(String str) {
		return StringUtils.equalsIgnoreCase(str, "INFO");
	}

	public static final boolean isWARN(String str) {
		return StringUtils.equalsIgnoreCase(str, "WARN");
	}

	public static final boolean isSUCCESS(String str) {
		return StringUtils.equalsIgnoreCase(str, "SUCCESS");
	}

	@MethodGet
	public final void throwINeoFlowException(Exception exception, RequestContext context) throws Exception {
		Exception e = null;
		IPruUser ipruUser = null;
		if (exception instanceof ServiceException)
			e = new IPruException((ServiceException) exception);
		else if (exception instanceof IPruException)
			e = exception;
		else
			e = new IPruException(new ServiceException(exception));

		/*
		 * if(SOLHandlerUtil.getAttributeFromSession(context,
		 * SessionKeyConstants.USER_SESSION_KEY) != null){ ipruUser =
		 * (IPruUser)SOLHandlerUtil.getAttributeFromSession(context,
		 * SessionKeyConstants.USER_SESSION_KEY); if(ipruUser!=null &&
		 * ipruUser.getPartnerJsonObj()!=null &&
		 * StringUtils.isNotBlank(ipruUser.
		 * getPartnerJsonObj().getPartnerRedirectUrl())){
		 * ((IPruException)e).setRedirectUrl
		 * (ipruUser.getPartnerJsonObj().getPartnerRedirectUrl()); } }
		 */
		context.getFlowScope().put("ipruFlowException", e);
		throw e;
	}

	@MethodGet
	public final void throwINeoFlowException(StatusVO statusVO, RequestContext context) throws Exception {
		throwINeoFlowException(new IPruException(new ServiceException(statusVO.getStatusCode())), context);
	}

	@MethodGet
	public final Event handleIPruException(RequestContext context) {
		Object exceptionObject = context.getFlowScope().get("ipruFlowException");
		IPruException exception = null;
		if (exceptionObject instanceof IPruException)
			exception = (IPruException) exceptionObject;
		else
			exception = new IPruException(new ServiceException("N001"));
		setExceptionDataInFlowScope(exception, context);
		return success();
	}

	@MethodGet
	public final void throwINeoFlowException(Exception e, String code, RequestContext p_ObjContext) throws Exception {
		if (StringUtils.isNotBlank(code) && !(e instanceof IPruException) && !(e instanceof ServiceException))
			throwINeoFlowException(ExceptionDelegate.getServiceException(code), p_ObjContext);
		else
			throwINeoFlowException(e, p_ObjContext);
	}

	public void setExceptionDataInFlowScope(Exception exception, RequestContext context) {
		context.getFlowScope().put("handleIPruException", exception.toString());
	}

	public List<FieldAccessMappingVO> getFieldAccessMappingList(RequestContext context) {
		List<FieldAccessMappingVO> fieldAccessMappingVoList = null;
		
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

		IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
		
		if(userVo != null){
			fieldAccessMappingVoList = userVo.getFieldAccessMappingVoList();
		}

		return fieldAccessMappingVoList;
	}

	public List<FunctionalityMasterVO> getFunctionalityVOList(RequestContext context) {
		List<FunctionalityMasterVO> functionalityVoList = null;

		functionalityVoList = (List<FunctionalityMasterVO>) context.getExternalContext().getApplicationMap().get("functionalityVOList");

		return functionalityVoList;
	}

	public long getFunctionalityId(RequestContext context) {

		String flowId = null;
		flowId = context.getActiveFlow().getId();
		
		List<FunctionalityMasterVO> functionalityVoList = this.getFunctionalityVOList(context);
		
		if(functionalityVoList != null){
			for(FunctionalityMasterVO functionalityMasterVO : functionalityVoList){
				if(flowId.equals(functionalityMasterVO.getScreenCode())){
					return functionalityMasterVO.getFunctionalityId();
				}
			}
		}
		
		return 0;
	}
	
	public FunctionalityMasterVO getFunctionality(RequestContext context) {

		String flowId = null;
		flowId = context.getActiveFlow().getId();
		
		List<FunctionalityMasterVO> functionalityVoList = this.getFunctionalityVOList(context);
		
		if(functionalityVoList != null){
			for(FunctionalityMasterVO functionalityMasterVO : functionalityVoList){
				if(flowId.equals(functionalityMasterVO.getScreenCode())){
					return functionalityMasterVO;
				}
			}
		}
		
		return null;
	}
	
	public List<String> getGstPolicyList(RequestContext context) {
		List<String> gstPolicyList = null;

		gstPolicyList = (List<String>) context.getExternalContext().getApplicationMap().get(ContextKeyConstants.GST_POLICY_LIST);

		return gstPolicyList;
	}
	
	public List<PolicyProductFundMasterVO> getPolicyProductFundMasterList(RequestContext context) {
		List<PolicyProductFundMasterVO> policyProductFundMasterList = null;

		policyProductFundMasterList = (List<PolicyProductFundMasterVO>) context.getExternalContext().getApplicationMap().get(ContextKeyConstants.POLICY_PRODUCT_FUND_MASTER_LIST);

		return policyProductFundMasterList;
	}
	
	/*@MethodGet
	public Event securedLoginPostFlag(RequestContext context) {
		FileInputStream fis = null;
		HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
		if (httpSession.getAttribute(SessionKeyConstants.LOGIN_SECURED_POST_FLAG) == null || httpSession.getAttribute(SessionKeyConstants.LOGIN_SECURED_POST_FLAG) == "") {
			Properties constantsProperites = new Properties();
			try {
				fis=new FileInputStream(GroupConstants.CONSTANT_IPRUCONFIG_CONSTANTS);
				constantsProperites.load(fis);
			}
			catch (Exception e) {
				// e.printStackTrace();
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				FLogger.error("GROUPLoggerError", "IneoBaseHandler", "securedLoginPostFlag", errors.toString());
				FLogger.info("GROUPLogger", "IneoBaseHandler", "securedLoginPostFlag", "Load constantProperties file for Secured Post flag :::" + constantsProperites);
			}
			finally {
				try {
					if(fis!=null)
						fis.close();
				}
				catch (Exception e) {
					FLogger.error("GROUPLoggerError", "MasterPropertiesFileLoader", "propertyFileLoader(String fileName)",
							"Exception Ocurred in finally of propertyFileLoader: "+e.getMessage());
					e.printStackTrace();
				} finally {
					fis=null;
				}
			}

			if (constantsProperites != null) {
				httpSession.setAttribute(SessionKeyConstants.LOGIN_SECURED_POST_FLAG, constantsProperites.getProperty("LOGIN_SECURE_POST_FLAG"));
				
			}
		}
		return success();
	}*/
}
