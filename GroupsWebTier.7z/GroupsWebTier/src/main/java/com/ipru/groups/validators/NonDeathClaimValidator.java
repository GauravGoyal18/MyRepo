package com.ipru.groups.validators;

import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.poifs.eventfilesystem.POIFSReader;
import org.apache.poi.poifs.eventfilesystem.POIFSReaderEvent;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.groups.po.NonDeathClaimSubmitRequestPO;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.utilities.EncodingUtility;
import com.ipru.groups.utilities.EncryptionPBEMD5DES;
import com.tcs.excelValidation.ExcelReader;
import com.tcs.groups.listener.MacroListener;

public class NonDeathClaimValidator {

	public String validateNonDeathClaimSubmitRequestPO(RequestContext context, NonDeathClaimSubmitRequestPO nonDeathClaimSubmitRequestPO) throws Exception {

		StringBuilder errorMessageBuilder = new StringBuilder(1);
		ExcelReader excelReader = new ExcelReader();
		Sheet sheet = null;
		

		ArrayList<String> checkedFormula = new ArrayList<String>();
		boolean checkedMacrosFlag;

		if (nonDeathClaimSubmitRequestPO != null) {
			List<UploadFilePO> uploadFileList = nonDeathClaimSubmitRequestPO.getUploadFileList();

			if (uploadFileList != null && uploadFileList.size() == 1) {
				for (UploadFilePO uploadFile : uploadFileList) {
					String fileType = uploadFile.getDocFileType();
					String actualPath = EncryptionPBEMD5DES.decrypt(EncodingUtility.decodeBase64(uploadFile.getDocPath()), EncodingUtility.CONSTANT_DOCUMENT_PATH_ENCRYPTION_KEY, 1);
					if ((fileType.equalsIgnoreCase("xls") || fileType.equalsIgnoreCase("xlsx"))) {

						try {
							sheet = excelReader.getExcelSheet(actualPath);
							checkedFormula = this.checkFormula(sheet);
							if (fileType.equalsIgnoreCase("xls")) {
								checkedMacrosFlag = this.checkMacros(actualPath);
								if (!checkedMacrosFlag) {
									errorMessageBuilder.append("Excel contain macro, Please remove Macro from excel.");
								}
							}
							if (CollectionUtils.isNotEmpty(checkedFormula)) {
								errorMessageBuilder.append("Excel contain Formula, Please remove Formula from excel.");
							}
						}
						catch (Exception e) {
							errorMessageBuilder.append("xls works on below 2007 version ,Convert xls to xlsx.");
						}

					}
					else {
						errorMessageBuilder.append("Upload file should be of only XLS/XLSX type.");
					}
				}
			}
			else {
				errorMessageBuilder.append("Please Upload file. ");
			}
		}
		else {
			errorMessageBuilder.append("No Data");
		}

		return errorMessageBuilder.toString();
	}

	public ArrayList<String> checkFormula(Sheet sheet) {
		ArrayList<String> checkFormula = new ArrayList<String>();
		int lastcol = sheet.getRow(0).getLastCellNum();
		int i;

		Row rowHeader = sheet.getRow(0);
		boolean flag = false;
		for (i = 0; i < lastcol; i++) {
			Cell cell = rowHeader.getCell(i);
			switch (cell.getCellType()) {
				case Cell.CELL_TYPE_FORMULA:
					checkFormula.add("asdsd");
					flag = true;
					break;
			}
			if (flag) {
				System.out.println("i**********" + i);
				break;
			}
		}
		return checkFormula;
	}

	public boolean checkMacros(String path) throws Exception {
		boolean flag;

		POIFSReader r = new POIFSReader();
		MacroListener ml = new MacroListener();
		r.registerListener(ml);
		FileInputStream fis = new FileInputStream(path);
		r.read(fis);
		flag = ml.isMacroDetected();
		if (fis != null) {
		       fis.close();
		       fis = null;
		}

		return flag;
	}

}
