package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.ipru.IPruException;
import com.ipru.groups.po.BrokerBIDPO;
import com.tcs.logger.FLogger;

public class BrokerBidValidator {

	public String validateBid(BrokerBIDPO brokerBIDPO,List policyNoList) throws IPruException
	{
		try
		{
			
		FLogger.info("BrokerBIDLogger", "BrokerBidValidator", "validateBid", "Method start");

		StringBuilder errorMessage=new StringBuilder();
		
		String fromDateString=brokerBIDPO.getFromDate();
		String toDateString=brokerBIDPO.getToDate();

		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
		Date fromDate=format1.parse(fromDateString);
		Date toDate=format1.parse(toDateString);
		if ((toDate.compareTo(new Date())>0) && (fromDate.compareTo(new Date())>0) ) {
           // ////System.out.println("Date1 is after Date2");
			FLogger.error("BrokerBIDLogger", "BrokerBidValidator", "validateBid", "Invalid Date");
            errorMessage.append("Enter valid date");
        } 
		if((toDate.compareTo(fromDate) < 0))
		{
			FLogger.error("BrokerBIDLogger", "BrokerBidValidator", "validateBid", "Date1 is after Date2");
            errorMessage.append("To Date must be Greater than From date");
		}
		if(!policyNoList.contains(brokerBIDPO.getPolicyNo()))
		{
			FLogger.error("BrokerBIDLogger", "BrokerBidValidator", "validateBid", "Policy number is invalid");
            errorMessage.append("Incorrect Policy Number");
		}
		
		FLogger.info("BrokerBIDLogger", "BrokerBidValidator", "validateBid", "Method end");
		return errorMessage.toString();
		}
		catch(ParseException e)
		{
			FLogger.error("BrokerBIDLogger", "BrokerBidValidator", "validateBid", "Date Format is not valid" ,e);

			throw new IPruException("Error","BIDSTMT01","Some Error Occured");
		}
	}
}
