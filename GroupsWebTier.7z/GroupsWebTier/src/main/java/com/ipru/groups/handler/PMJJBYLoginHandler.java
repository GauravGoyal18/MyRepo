package com.ipru.groups.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.generic.po.ResultJsonPO;
import com.ipru.groups.pmjjbylogin.LDAPUserDetail;
import com.ipru.groups.pmjjbylogin.PMJJBYLoginPO;
import com.ipru.groups.pmjjbylogin.PMJJBYLoginVO;
import com.ipru.groups.security.LoginProcessService1;
import com.ipru.security.encryption.servlet.CryptoServlet;

import com.ipru.otp.po.OTPNumberParamBean;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class PMJJBYLoginHandler  extends IneoBaseHandler{
	
	private static final long serialVersionUID = 1L;
	
	
	@MethodPost
	public Event getBizRequestForPMJJBYLoginSubmit(RequestContext p_ObjContext) throws Exception {
		
		try{
			FLogger.info("PMJJBYLoginLogger", "PMJJBYLoginHandler", "getBizRequestForPMJJBYLoginSubmit", "Method Start");
			
			//Declare Variables
			HttpServletRequest request = null;
			String password = null;
			PMJJBYLoginPO pmjjbyLoginPO = null;
			
			request = (HttpServletRequest)p_ObjContext.getExternalContext().getNativeRequest();
			
			//Convert json to object
			pmjjbyLoginPO = gsonJSON.fromJson(request.getReader(), PMJJBYLoginPO.class);
			
			//decrypt password
			 password = obtainPassword(request,pmjjbyLoginPO.getPassword());//before :  ,after: d396f749a74638b276b4e98799e9abd1
			 pmjjbyLoginPO.setPassword(password);
			//PO to VO
			PMJJBYLoginVO pmjjbyLoginVO = dozerBeanMapper.map(pmjjbyLoginPO, PMJJBYLoginVO.class);
			
			Object[] paramArray = new Object[1];
			paramArray[0] = pmjjbyLoginVO;
	
			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);
	
			p_ObjContext.getFlowScope().put("submitBizReq", obj_bizReq); 

			FLogger.info("PMJJBYLoginLogger", "PMJJBYLoginHandler", "getBizRequestForPMJJBYLoginSubmit", "Method Start");
		}
		catch(Exception e){
			FLogger.error("PMJJBYLoginLogger", "PMJJBYLoginHandler", "getBizRequestForPMJJBYLoginSubmit", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRPML01",p_ObjContext);
		}
		
		FLogger.info("PMJJBYLoginLogger", "PMJJBYLoginHandler", "getBizRequestForPMJJBYLoginSubmit", "Method End");
		return success();
	}
	
	protected String obtainPassword(HttpServletRequest request,String encryptedPassword) {
		FLogger.info("PMJJBYLoginLogger", "PMJJBYLoginHandler", "obtainPassword", "Method Start");
		CryptoServlet cs = new CryptoServlet();
		LoginProcessService1 loginService = new LoginProcessService1();
		String password = "";		
		String decryptedPswd = cs.decriptPassword(request, encryptedPassword);
//		password = loginService.getHashedPassword(decryptedPswd);
			
		FLogger.info("PMJJBYLoginLogger", "PMJJBYLoginHandler", "obtainPassword", "Method End");
		return decryptedPswd;
	}
	
	
	@MethodPost
	public Event getBizResponseForPMJJBYLoginSubmit(RequestContext p_ObjContext) throws Exception {
		
		try{
			FLogger.info("PMJJBYLoginLogger", "PMJJBYLoginHandler", "getBizResponseForPMJJBYLoginSubmit", "Method Start");
			
//			System.out.println("In response method");
			
			//Declare Variables
			Map<String,LDAPUserDetail> map = new HashMap<String,LDAPUserDetail>();
			BizResponse bizRes = new BizResponse();
			String responseCheck = "";
			String resultJson="";

			//Fetch response from service
			bizRes = (BizResponse) p_ObjContext.getFlowScope().get("bizResForSubmitPmjjby");
			
			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					FLogger.error("PMJJBYLoginLogger", "PMJJBYLoginHandler", "getBizResponseForPMJJBYLoginSubmit", "Error while getting response from service");
					throwINeoFlowException(bizRes.getStatusVO(), p_ObjContext);
				}
				else {

					LDAPUserDetail ldapUserDetail =  (LDAPUserDetail) bizRes.getTransferObjects().get("response1");
					
					map.put("authenticatedUser", ldapUserDetail);
					ResultJsonPO resultMap = new ResultJsonPO();
					resultMap.setResultMap(map);
					resultJson = gsonJSON.toJson(resultMap);
					
					//set values in flow scope
					p_ObjContext.getFlowScope().put("Response", resultJson);
					
					FLogger.info("PMJJBYLoginLogger", "PMJJBYLoginHandler", "getBizResponseForPMJJBYLoginSubmit", "authenticatedUser:::"+ldapUserDetail.isValidUser());
				}
			}

		}
		catch(Exception e){
			FLogger.error("PMJJBYLoginLogger", "PMJJBYLoginHandler", "getBizResponseForPMJJBYLoginSubmit", "Exception Occurred ", e);
			throwINeoFlowException(e,"GRPML02",p_ObjContext);
		}
		
		FLogger.info("PMJJBYLoginLogger", "PMJJBYLoginHandler", "getBizResponseForPMJJBYLoginSubmit", "Method End");
		return success();
	}
	
	
	
	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean,RequestContext ObjContext) {
		
	}

}