package com.ipru.groups.validators;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.groups.po.ForgotPasswordRequestPO;
import com.ipru.groups.po.SignUpPolicyDetailsPO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.ipru.security.user.GroupsUserAuthInfoNew;
import com.tcs.logger.FLogger;

public class SignUpValidator {
	private static final String CLASS_NAME = SignUpValidator.class.getCanonicalName();
	private static final String LOGGER_NAME = "SignUpLogger";
	private String METHOD_NAME = null;
	private Properties prop = null;

	public SignUpValidator() {
		METHOD_NAME = "SignUpValidator";

		prop = new Properties();

		try {
			if (MasterPropertiesFileLoader.SIGNUP_PROPERTIES != null) {
				prop = MasterPropertiesFileLoader.SIGNUP_PROPERTIES;
			}
			else {
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(GroupConstants.CONSTANT_SIGNUP);
					prop.load(fis);
				}
				catch (Exception e) {
					FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception occured while loading SIGNUP_PROPERTIES file");
				}
				finally {
					if (fis != null) {
						fis.close();
						fis = null;
					}
				}

			}
		}
		catch (FileNotFoundException e) {
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "File not found exception found at the time of loading properties");
			e.printStackTrace();
		}
		catch (IOException e) {
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "IOException found at the time of loading properties");
			e.printStackTrace();
		}
	}

	public String validatePolicyDetails(SignUpPolicyDetailsPO signUpPolicyDetailsPO) throws Exception {
		METHOD_NAME = "validatePolicyDetails";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		StringBuilder errorMessage = new StringBuilder();

		if (signUpPolicyDetailsPO == null) {
			errorMessage.append("Please enter your policy details.");
		}
		else {

			if (!validatePolicyNo(String.valueOf(signUpPolicyDetailsPO.getPolicyNo()))) {
				errorMessage.append("Please enter valid Policy Number");
			}

			if (!validateDob(signUpPolicyDetailsPO.getDob())) {
				errorMessage.append("Please enter valid Date of Birth");
			}

			if (!validateEmpId(signUpPolicyDetailsPO.getEmpId())) {
				errorMessage.append("Please enter valid Employee Id");
			}
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return errorMessage.toString();
	}

	public String validateContactDetails(SignUpPolicyDetailsPO signUpPolicyDetailsPO, RequestContext context) throws Exception {
		METHOD_NAME = "validateContactDetails";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		StringBuilder errorMessage = new StringBuilder();

		if (signUpPolicyDetailsPO != null) {

			if (!validateEmail(signUpPolicyDetailsPO.getEmailId())) {
				errorMessage.append("Please Enter Valid Email Address.\n");
			}
			if (!validateMobileNo(signUpPolicyDetailsPO)) {
				errorMessage.append("Please Enter Valid Mobile Number.\n");
			}

			SignUpPolicyDetailsPO signUpPolicyDetailsPOInSession = (SignUpPolicyDetailsPO) GroupSecurityUtil.getAttributeFromSession(context, "signUpPolicyDetailsPO");
			if (signUpPolicyDetailsPOInSession != null) {
				if (!(signUpPolicyDetailsPO.getPolicyNo().equals(signUpPolicyDetailsPOInSession.getPolicyNo()))
						|| !(signUpPolicyDetailsPO.getEmpId().equals(signUpPolicyDetailsPOInSession.getEmpId())) || !(signUpPolicyDetailsPO.getDob().equals(signUpPolicyDetailsPOInSession.getDob()))) {
					errorMessage.append("Entered data is not valid.");
				}
			}

		}
		else {
			errorMessage.append("Please enter your email id and mobile no.");
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return errorMessage.toString();
	}

	public String validatePasswordDetails(SignUpPolicyDetailsPO signUpPolicyDetailsPO, RequestContext context) {
		METHOD_NAME = "validatePasswordDetails";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		StringBuilder errorMessage = new StringBuilder();

		if (signUpPolicyDetailsPO != null) {
			SignUpPolicyDetailsPO signUpPolicyDetailsPOInSession = (SignUpPolicyDetailsPO) GroupSecurityUtil.getAttributeFromSession(context, "signUpPolicyDetailsPO");
			if (signUpPolicyDetailsPOInSession != null) {
				if (!(signUpPolicyDetailsPO.getPolicyNo().equals(signUpPolicyDetailsPOInSession.getPolicyNo()))
						|| !(signUpPolicyDetailsPO.getEmpId().equals(signUpPolicyDetailsPOInSession.getEmpId())) || !(signUpPolicyDetailsPO.getDob().equals(signUpPolicyDetailsPOInSession.getDob()))
						|| !(signUpPolicyDetailsPO.getEmailId().equalsIgnoreCase(signUpPolicyDetailsPOInSession.getEmailId()))
						|| !(signUpPolicyDetailsPO.getMobileNo().equals(signUpPolicyDetailsPOInSession.getMobileNo()))) {
					errorMessage.append("Entered data is not valid.");
				}
				else {
					if (StringUtils.isNotEmpty(signUpPolicyDetailsPO.getNewPassword())) {
						if (StringUtils.isNotEmpty(signUpPolicyDetailsPO.getConfirmPassword())) {
							if (!(signUpPolicyDetailsPO.getNewPassword().equals(signUpPolicyDetailsPO.getConfirmPassword()))) {
								FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Old password and new password should be same");
								errorMessage.append("New Password and confirm password should be same");
							}
							else {
								GroupsUserAuthInfoNew groupsUserAuthInfoNew = (GroupsUserAuthInfoNew) GroupSecurityUtil.getAttributeFromSession(context, "groupsUserAuthInfoNewDetailsForSignUp");
								if (groupsUserAuthInfoNew != null) {
									if (!(signUpPolicyDetailsPO.getEmailId().equalsIgnoreCase(groupsUserAuthInfoNew.getEmailId()))
											|| !(signUpPolicyDetailsPO.getMobileNo().equals(groupsUserAuthInfoNew.getMobileNo()))
											|| !(signUpPolicyDetailsPO.getNewPassword().equals(groupsUserAuthInfoNew.getProperty()))) {
										errorMessage.append("This email id and mobile number already linked with different Password. Please enter the old password.");
									}
								}
							}

						}
						else {
							errorMessage.append("New Password should not be empty.");
						}
					}
					else {
						errorMessage.append("confirm Password should not be empty.");
					}

				}
			}

		}
		else {
			errorMessage.append("Please enter your email id and mobile no.");
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return errorMessage.toString();
	}

	private boolean validateDob(String dob) throws ParseException {
		METHOD_NAME = "validateDob";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		if (StringUtils.isNotEmpty(dob)) {
			SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);
			Date date1 = format1.parse(dob);
			Date today = new Date();
			if (date1.before(today)) {
				FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
				return true;
			}
			else {
				FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
				return false;
			}
		}
		else {
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
			return false;
		}

	}

	private boolean validatePolicyNo(String policyNo) {
		METHOD_NAME = "validatePolicyNo";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		long length = Long.valueOf(prop.getProperty("PolicyNo_Length_Validation"));
		if (CommonValidationUtil.ValidateRequired(policyNo) && policyNo.length() == length) {
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
			return true;
		}
		else {
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
			return false;
		}
	}

	private boolean validateEmpId(String empId) {
		METHOD_NAME = "validateEmpId";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		if (CommonValidationUtil.ValidateRequired(empId)) {
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
			return true;

		}
		else {
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
			return false;
		}
	}

	private boolean validateEmail(String emailId) {
		METHOD_NAME = "validateEmail";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		Integer length = 0;
		if (prop.getProperty("Email_Length_Validation") != null)
			length = Integer.valueOf(prop.getProperty("Email_Length_Validation"));

		if (CommonValidationUtil.ValidateRequired(emailId) && CommonValidationUtil.ValidateEmail(emailId, true, length)) {
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
			return true;
		}
		else {
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
			return false;
		}
	}

/*	private boolean validateMobile(String mobile) {
		METHOD_NAME = "validateMobile";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		Integer length = 0;
		if (prop.getProperty("MobileNo_Length_Validation") != null)
			length = Integer.valueOf(prop.getProperty("MobileNo_Length_Validation"));

		if (CommonValidationUtil.ValidateRequired(mobile) && CommonValidationUtil.isMatchedPattern(mobile, GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP)
				&& CommonValidationUtil.ValidateMaxLength(mobile, length)) {
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
			return true;
		}
		else {
			FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
			return false;
		}
	}*/
	
	private boolean validateMobileNo(SignUpPolicyDetailsPO signUpPolicyDetailsPO) {
		Properties prop = new Properties();
		prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES ;
		if((signUpPolicyDetailsPO.getCountryName().equals(prop.getProperty("INDIA")))||(signUpPolicyDetailsPO.getCountryName().equals("")))
		{
		if ((StringUtils.isNotBlank(String.valueOf(signUpPolicyDetailsPO.getMobileNo())) && CommonValidationUtil.isMatchedPattern(String.valueOf(signUpPolicyDetailsPO.getMobileNo()), GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) || (String.valueOf(signUpPolicyDetailsPO.getMobileNo())).equals("-"))) {
			return true;
		}
		}
		if(!(signUpPolicyDetailsPO.getCountryName().equals(prop.getProperty("INDIA"))))
		{
			if ((StringUtils.isNotBlank(String.valueOf(signUpPolicyDetailsPO.getMobileNo())) && CommonValidationUtil.isMatchedPattern(String.valueOf(signUpPolicyDetailsPO.getMobileNo()), GroupFormValidationConstant.NRI_REGEX) || (String.valueOf(signUpPolicyDetailsPO.getMobileNo())).equals("-"))) {
			return true;
		}
			else {
				return false;
			
		}
		}
		return false;
	
		
	}

}
