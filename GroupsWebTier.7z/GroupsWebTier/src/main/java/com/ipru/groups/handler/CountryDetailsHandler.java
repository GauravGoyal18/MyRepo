package com.ipru.groups.handler;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.CountryDetailsData;
import com.ipru.otp.po.OTPNumberParamBean;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class CountryDetailsHandler extends IneoBaseHandler {

	private static final String INFO_LOGGER_NAME = "ForgotPasswordLogger";
	private static final String CLASS_NAME = "ForgotPasswordHandler";

	@MethodPost
	public Event getBizRequestForGettingCountryNames(RequestContext context) throws Exception {
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForGettingCountryNames", "Method start ");
		try {

			BizRequest obj_bizReq = new BizRequest();

			Object paramArray[] = new Object[0];
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			context.getFlowScope().put("bizReqForGettingCountryNames", obj_bizReq);

		}

		catch (Exception e) {
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForGettingCountryNames", "Exception came ", e);
			throwINeoFlowException(e, "GRPCL03", context);

		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizRequestForGettingCountryNames", "getRequestDropDownList Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseForGettingCountryNames(RequestContext context) throws Exception {
		String responseCheck = "";
		BizResponse bizRes = new BizResponse();
		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizResForGettingCountryNames");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForGettingCountryNames", "Error came while getting response from service");
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {

						List<CountryDetailsData> countryDetailsList = (List<CountryDetailsData>) bizRes.getTransferObjects().get("response1");

						if (CollectionUtils.isEmpty(countryDetailsList)) {
							FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForGettingCountryNames", "countryDetailsList is null");
							throw new IPruException("Something went wrong. Please try again later.");
						}
						else {

							String callJsonString = gsonJSON.toJson(countryDetailsList);
							FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForGettingCountryNames", "callJsonString::");
							context.getFlowScope().put("Response", callJsonString);
						}
					}
				}
				else {
					FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForGettingCountryNames", "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}

			}
			else {
				FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForGettingCountryNames", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForGettingCountryNames", "Exception came ", e);
			throwINeoFlowException(e, "GRPBO", context);
		}
		FLogger.info(INFO_LOGGER_NAME, CLASS_NAME, "getBizResponseForGettingCountryNames", "Method end");

		return success();

	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub
		
	}



}
