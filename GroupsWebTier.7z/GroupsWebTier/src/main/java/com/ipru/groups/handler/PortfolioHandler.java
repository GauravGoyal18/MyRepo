package com.ipru.groups.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.PortfolioDataPO;
import com.ipru.groups.po.PortfolioLoadRequestPO;
import com.ipru.groups.po.ServiceWebPageMenuListPO;
import com.ipru.groups.po.ServiceWebPageMenuPO;
import com.ipru.groups.vo.FieldAccessMappingVO;
import com.ipru.groups.vo.PortfolioDataVO;
import com.ipru.groups.vo.PortfolioLoadRequestVO;
import com.ipru.groups.vo.ServiceWebPageMenuVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class PortfolioHandler extends IneoBaseHandler {

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		// TODO Auto-generated method stub

	}

	@SuppressWarnings("unchecked")
	@MethodPost
	public Event getBizRequestForLoadPortfolio(RequestContext context) throws Exception {
		FLogger.info("PortfolioLogger", "PortfolioHandler", "getBizRequestForLoadPortfolio", "Method start");

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				if (httpSession != null) {
					IPruUser userVo = new IPruUser();
					String policyNo = null;
					String role = null;
					String clientId = null;
					String webClientId = null;
					String screenName = null;
					String empId = null;
					String productType = null;

					screenName = (String) context.getFlowScope().get("screenName");

					List<FieldAccessMappingVO> fieldAccessMappingList = null;

					fieldAccessMappingList = getFieldAccessMappingList(context);
					
					if(fieldAccessMappingList == null) {
						FLogger.error("PortfolioLogger", "PortfolioHandler", "getBizRequestForLoadPortfolio", "fieldAccessMappingVoList is null");

						throwINeoFlowException(new Exception(),"GRPF01",context);
					}

					userVo = (IPruUser) httpSession.getAttribute("userVO");
					////System.out.println("UserVo in session : " + userVo);

					if (userVo != null) {  // userVO b nahi null hoga
						policyNo = userVo.getPolicyNo();
						FLogger.info("PortfolioLogger", "PortfolioHandler", "getBizRequestForLoadPortfolio", "Policy No in session : " + policyNo);

						role = userVo.getRoles();
						FLogger.info("PortfolioLogger", "PortfolioHandler", "getBizRequestForLoadPortfolio", "role in session : " + role);

						clientId = userVo.getClientId();
						FLogger.info("PortfolioLogger", "PortfolioHandler", "getBizRequestForLoadPortfolio", "clientId in session : " + clientId);

						webClientId = userVo.getWebClientId();
						FLogger.info("PortfolioLogger", "PortfolioHandler", "getBizRequestForLoadPortfolio", "webClientId in session : " + webClientId);
						
						empId = userVo.getEmpId();
						FLogger.info("PortfolioLogger", "PortfolioHandler", "getBizRequestForLoadPortfolio", "empId in session : " + empId);

						productType = userVo.getProductType();
						FLogger.info("PortfolioLogger", "PortfolioHandler", "getBizRequestForLoadPortfolio", "productType in session : " + productType);
						
						PortfolioLoadRequestPO portfolioLoadRequestPO = new PortfolioLoadRequestPO();
						portfolioLoadRequestPO.setPolicyNo(policyNo);
						portfolioLoadRequestPO.setRole(role);
						portfolioLoadRequestPO.setClientId(clientId);
						portfolioLoadRequestPO.setWebClientId(webClientId);
						portfolioLoadRequestPO.setScreenName(screenName);
						portfolioLoadRequestPO.setEmpId(empId);
						portfolioLoadRequestPO.setProductType(productType);

						PortfolioLoadRequestVO portfolioLoadRequestVO = dozerBeanMapper.map(portfolioLoadRequestPO, PortfolioLoadRequestVO.class);

						if (portfolioLoadRequestVO != null) {

							portfolioLoadRequestVO.setFieldAccessMappingList(fieldAccessMappingList);

							Object[] paramArray = new Object[1];
							paramArray[0] = portfolioLoadRequestVO;

							BizRequest obj_bizReq = new BizRequest();
							obj_bizReq.addbusinessObjects("service-obj1", paramArray);

							context.getFlowScope().put("bizReq", obj_bizReq);

						}
						else {
							FLogger.error("PortfolioLogger", "PortfolioHandler", "getBizRequestforLoadServiceWebPage", "Policy Number is null");
							throw new IPruException("Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error("PortfolioLogger", "PortfolioHandler", "getBizRequestforLoadServiceWebPage", "UserVo from session is null");
						throw new IPruException("Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error("PortfolioLogger", "PortfolioHandler", "getBizRequestforLoadServiceWebPage", "Session is null");
					throw new IPruException("Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error("PortfolioLogger", "PortfolioHandler", "getBizRequestforLoadServiceWebPage", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("PortfolioLogger", "PortfolioHandler", "getBizRequestforLoadServiceWebPage", "Exception came ", e);
			throwINeoFlowException(e, "GRYY01", context);
		}

		FLogger.info("PortfolioLogger", "PortfolioHandler", "getBizRequestforLoadServiceWebPage", "Method end.");

		return success();
	}

	@SuppressWarnings("unchecked")
	@MethodPost
	public Event getBizResponseForLoadPortfolio(RequestContext context) throws Exception {

		FLogger.info("PortfolioLogger", "PortfolioHandler", "getBizResponseForLoadPortfolio", "Method start");

		PortfolioDataVO portfolioDataVO = null;
		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				bizRes = (BizResponse) context.getFlowScope().get("bizRes");
				if (bizRes != null) {
					responseCheck = (String) bizRes.getStatusVO().getStatus();
					if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
						throwINeoFlowException(bizRes.getStatusVO(), context);
					}
					else {
						portfolioDataVO = (PortfolioDataVO) bizRes.getTransferObjects().get("response1");

						if (portfolioDataVO != null) {
							PortfolioDataPO portfolioDataPO = dozerBeanMapper.map(portfolioDataVO, PortfolioDataPO.class);

							String portfolioDataJsonString = gsonJSON.toJson(portfolioDataPO, PortfolioDataPO.class);

							context.getFlowScope().put("Response", portfolioDataJsonString);
						}
					}
				}
				else {
					FLogger.error("PortfolioLogger", "PortfolioHandler", "getBizResponseForLoadPortfolio", "bizRes should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}
			}

			else {
				FLogger.error("PortfolioLogger", "PortfolioHandler", "getBizResponseForLoadPortfolio", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("PortfolioLogger", "PortfolioHandler", "getBizResponseForLoadPortfolio", "Exception came ", e);
			throwINeoFlowException(e, "GRYY02", context);
		}

		FLogger.info("PortfolioLogger", "PortfolioHandler", "getBizResponseForLoadPortfolio", "Method end");

		return success();
	}

}
