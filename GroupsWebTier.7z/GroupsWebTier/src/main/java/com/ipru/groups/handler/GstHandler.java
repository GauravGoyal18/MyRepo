package com.ipru.groups.handler;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.EmailMobileRequestPO;
import com.ipru.groups.po.GstDropDownPO;
import com.ipru.groups.po.GstSaveRequestPO;
import com.ipru.groups.po.GstSubmitPO;
import com.ipru.groups.utilities.EncodingUtility;
import com.ipru.groups.utilities.EncryptionPBEMD5DES;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.GstUtil;
import com.ipru.groups.validators.DashboardEmailMobileValidator;
import com.ipru.groups.validators.GstValidator;
import com.ipru.groups.vo.GstRequestJson;
import com.ipru.groups.vo.GstSaveRequestVO;
import com.ipru.groups.vo.GstSubmitVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class GstHandler extends IneoBaseHandler {

	@MethodPost
	public Event getBizRequestOnload(RequestContext context) throws Exception {
		FLogger.info("GstLogger", "GstHandler", "getBizRequestOnload", "Method Started");
		try {
			String requestJsonString = null;

			requestJsonString = (String) context.getFlowScope().get("rqstjsn");

			String decryptcontent = EncryptionPBEMD5DES.decrypt(EncodingUtility.decodeBase64(requestJsonString), "WEBSITE123", 1);

			GstRequestJson requestJson = gsonJSON.fromJson(decryptcontent, GstRequestJson.class);

			if (requestJson != null) {
				String policyNo = requestJson.getPolicyNo();

				List<String> gstPolicyList = getGstPolicyList(context);

				if (gstPolicyList != null && gstPolicyList.contains(policyNo)) {
					Object[] paramArray = new Object[1];
					paramArray[0] = requestJson;

					BizRequest obj_bizReq = new BizRequest();
					obj_bizReq.addbusinessObjects("service-obj1", paramArray);

					context.getFlowScope().put("loadBizReq", obj_bizReq);
				}
				else {
					throw new IPruException("Error", "GRPGST01", "Link is not valid");
				}
			}
			else {
				throw new IPruException("Error", "GRPGST01", "Link is not valid");
			}
		}
		catch (Exception e) {
			FLogger.error("GstLogger", "GstHandler", "getBizRequestOnload", "Exception came ", e);
			throwINeoFlowException(e, "GRPGST02", context);
		}

		FLogger.info("GstLogger", "GstHandler", "getBizRequestOnload", "Method Ended");

		return success();
	}

	@MethodPost
	public Event getBizResponseOnload(RequestContext context) throws Exception {
		FLogger.info("GstLogger", "GstHandler", "getBizResponseOnload", "getBizResponseOnload Method Started");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			bizRes = (BizResponse) context.getFlowScope().get("loadBizRes");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {
					String data = (String) bizRes.getTransferObjects().get("response1");
					if (data.equalsIgnoreCase("INVALID")) {
						throw new IPruException("Error", "GRPGST01", "Link is not valid");
					}
					else {
						String requestJsonString = null;

						requestJsonString = (String) context.getFlowScope().get("rqstjsn");

						String decryptcontent = EncryptionPBEMD5DES.decrypt(EncodingUtility.decodeBase64(requestJsonString), "WEBSITE123", 1);

						GstRequestJson requestJson = gsonJSON.fromJson(decryptcontent, GstRequestJson.class);

						GstUtil util = new GstUtil();
						GstDropDownPO gstDropDownPO = new GstDropDownPO();
						String policyNo = requestJson.getPolicyNo();
						gstDropDownPO = util.dropDownList();
						gstDropDownPO.setPolicyNo(policyNo);

						String responseJsonString = gsonJSON.toJson(gstDropDownPO, GstDropDownPO.class);

						context.getFlowScope().put("Response", responseJsonString);
					}
				}
			}

		}

		catch (Exception e) {
			FLogger.error("GstLogger", "GstHandler", "getBizResponseOnload", "Exception came ", e);
			throwINeoFlowException(e, "GRPGST02", context);
		}

		FLogger.info("GstLogger", "GstHandler", "getBizResponseOnload", "getBizResponseOnload Method End");
		return success();
	}

	@MethodPost
	public Event getBizRequestGstFormSubmit(RequestContext context) throws Exception {
		FLogger.info("GstLogger", "GstHandler", "getBizRequestGstFormSubmit", "getBizRequestSubmit Method End");

		try {
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();

			GstSubmitPO gstSubmitPO = gsonJSON.fromJson(request.getReader(), GstSubmitPO.class);

			GstSaveRequestPO gstSaveRequestPO = new GstSaveRequestPO();
			gstSaveRequestPO.setGstFormJson(gstSubmitPO);

			List<String> gstPolicyList = getGstPolicyList(context);

			GstValidator gstValidator = new GstValidator();
			String errorMsg = gstValidator.validateGstSubmit(gstSaveRequestPO, gstPolicyList);

			if (StringUtils.isNotBlank(errorMsg)) {
				this.setValidationErrorMessages(errorMsg);
				FLogger.error("GstLogger", "GstHandler", "getBizRequestGstFormSave", "Data from request should not be null");
				throwINeoFlowException(new ServiceException("GRPT01"), "GRPT01", context);
			}

			GstSubmitVO gstSubmitVO = new GstSubmitVO();
			gstSubmitVO = dozerBeanMapper.map(gstSubmitPO, GstSubmitVO.class);

			HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
			IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
			if (userVo == null) {
				userVo = new IPruUser();
			}

			userVo.setPolicyNo(gstSubmitVO.getPolicyNumber());
			userVo.setClientId(gstSubmitVO.getPolicyNumber());
			userVo.setUsername(gstSubmitVO.getCustomerName());
			userVo.setClientName(gstSubmitVO.getCustomerName());

			GroupSecurityUtil.setAttributeInSession(context, "userVO", userVo);

			/*
			 * Object[] paramArray = new Object[1]; paramArray[0] = gstSubmitVO;
			 * BizRequest obj_bizReq = new BizRequest();
			 * obj_bizReq.addbusinessObjects("service-obj1", paramArray);
			 */

			String gstJsonString = gsonJSON.toJson(gstSubmitPO, GstSubmitPO.class);

			context.getFlowScope().put("Response", gstJsonString);
		}
		catch (Exception e) {
			FLogger.error("GstLogger", "GstHandler", "getBizRequestGstFormSubmit", "Exception came :", e);
			throwINeoFlowException(e, "GRPGST02", context);
		}

		FLogger.info("GstLogger", "GstHandler", "getBizRequestGstFormSubmit", "getBizRequestSubmit Method End");
		return success();
	}

	@MethodPost
	public Event getBizRequestGstFormSave(RequestContext context) throws Exception {
		FLogger.info("GstLogger", "GstHandler", "getBizRequestGstFormSave", "Method Start");

		try {
			HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
			GstSaveRequestPO gstSaveRequestPO = gsonJSON.fromJson(request.getReader(), GstSaveRequestPO.class);

			GstValidator gstValidator = new GstValidator();

			List<String> gstPolicyList = getGstPolicyList(context);

			String errorMsg = gstValidator.validateGstSubmit(gstSaveRequestPO, gstPolicyList);

			if (StringUtils.isNotBlank(errorMsg)) {
				this.setValidationErrorMessages(errorMsg);
				FLogger.error("GstLogger", "GstHandler", "getBizRequestGstFormSave", "Data from request should not be null");
				throwINeoFlowException(new ServiceException("GRPT01"), "GRPT01", context);
			}

			GstSaveRequestVO gstSaveRequestVO = new GstSaveRequestVO();
			gstSaveRequestVO = dozerBeanMapper.map(gstSaveRequestPO, GstSaveRequestVO.class);

			Object[] paramArray = new Object[1];
			paramArray[0] = gstSaveRequestVO;

			BizRequest obj_bizReq = new BizRequest();
			obj_bizReq.addbusinessObjects("service-obj1", paramArray);

			context.getFlowScope().put("submitBizReq", obj_bizReq);
		}
		catch (Exception e) {
			FLogger.error("GstLogger", "GstHandler", "getBizRequestGstFormSave", "Exception came :", e);
			throwINeoFlowException(e, "GRPGST02", context);
		}

		FLogger.info("GstLogger", "GstHandler", "getBizRequestGstFormSave", "Method End");
		return success();
	}

	@MethodPost
	public Event getBizResponseGstFormSave(RequestContext context) throws Exception {
		FLogger.info("GstLogger", "GstHandler", "getBizResponseGstFormSave", "Method Started");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String resultJson = "";

		try {

			bizRes = (BizResponse) context.getFlowScope().get("bizResSubmitGst");

			if (bizRes != null) {
				responseCheck = (String) bizRes.getStatusVO().getStatus();
				if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
					throwINeoFlowException(bizRes.getStatusVO(), context);
				}
				else {
					String data = (String) bizRes.getTransferObjects().get("response1");
					if (data.equalsIgnoreCase("success")) {
						context.getFlowScope().put("Response", gsonJSON.toJson("Success"));
					}
					else {
						FLogger.error("GstLogger", "GstHandler", "getBizResponseGstFormSave", "Something went wrong,Please try again");
						throw new IPruException("Error", "GRPT01", "Something went wrong,Please try again");
					}

				}
			}
			else {
				FLogger.error("GstLogger", "GstHandler", "getBizResponseGstFormSave", "bizRes should not be null");
				throw new IPruException("Error", "GRPT01", "No Data Found");

			}
		}
		catch (Exception e) {
			FLogger.error("GstLogger", "GstHandler", "getBizRequestGstFormSave", "Exception came :", e);
			throwINeoFlowException(e, "GRPGST02", context);
		}

		FLogger.info("GstLogger", "GstHandler", "getBizResponseGstFormSave", "getBizResponseGstFormSave Method End");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		FLogger.info("GstLogger", "GstHandler", "setOtpCallBacks", "Method start ");
		paramBean.setFunctionality("GST_FORM");
		setTransactionalOTPCallback(Boolean.TRUE);
		FLogger.info("GstLogger", "GstHandler", "setOtpCallBacks", "Method end ");

	}

	@MethodPost
	public Event getBizRequestForEmailMobileSubmit(RequestContext context) throws Exception {
		FLogger.info("GstLogger", "GstHandler", "getBizRequestForEmailMobileSubmit", "Method start ");

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
					// //System.out.println("userVo : " + userVo);

					if (userVo != null) {
						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
						if (request != null) {
							EmailMobileRequestPO emailMobileRequestPO = gsonJSON.fromJson(request.getReader(), EmailMobileRequestPO.class);

							DashboardEmailMobileValidator dashboardEmailMobileValidator = new DashboardEmailMobileValidator();

							String validation = dashboardEmailMobileValidator.validateEmailMobileRequestPO(context, emailMobileRequestPO);

							if (StringUtils.isNotBlank(validation)) {
								FLogger.error("GstLogger", "GstHandler", "getBizRequestForEmailMobileSubmit", "Validation errors : " + validation);
								this.setValidationErrorMessages(validation);
								throwINeoFlowException(new ServiceException("GRPPFCC"), context);
							}

							if (emailMobileRequestPO != null) {

								// //System.out.println("emailMobileRequestPO :"
								// + emailMobileRequestPO);

								String emailId = emailMobileRequestPO.getEmailId();
								long mobileNo = emailMobileRequestPO.getMobileNo();

								userVo.setEmailId(emailId);
								userVo.setMobileNo(String.valueOf(mobileNo));

								GroupSecurityUtil.setAttributeInSession(context, "userVO", userVo);

							}
							else {
								FLogger.error("GstLogger", "GstHandler", "getBizRequestForEmailMobileSubmit", "emailMobileRequestVO from request should not be null");
								throw new IPruException("Something went wrong. Please try again later.");
							}
						}
						else {
							FLogger.error("GstLogger", "GstHandler", "getBizRequestForEmailMobileSubmit", "Http Request should not be null");
							throw new IPruException("Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error("GstLogger", "GstHandler", "getBizRequestForEmailMobileSubmit", "UserVO in session should not be null");
						throw new IPruException("Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error("GstLogger", "GstHandler", "getBizRequestForEmailMobileSubmit", "session should not be null");
					throw new IPruException("Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error("GstLogger", "GstHandler", "getBizRequestForEmailMobileSubmit", "context should not be null");
				throw new IPruException("Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error("GstLogger", "GstHandler", "getBizRequestForEmailMobileSubmit", "Exception came ", e);
			throwINeoFlowException(e, "GRPGST02", context);
		}

		FLogger.info("GstLogger", "GstHandler", "getBizRequestForEmailMobileSubmit", "Method end ");
		return success();
	}

}
