package com.ipru.groups.validators;

import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.ipru.groups.po.UpdateEmailMobilePO;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.logger.FLogger;

public class UpdateEmailMobileValidator {

	private final String LOGGER_NAME = "ForgotPasswordLogger";
	private final String CLASS_NAME = "ForgotPasswordValidator";
	private String METHOD_NAME = null;
	Properties prop = new Properties();
	
	
	public String validateEmailMobile(UpdateEmailMobilePO updateEmailMobilePO) throws Exception {
		METHOD_NAME = "validateEmailMobile";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		StringBuilder errorMessage = new StringBuilder();

		if (MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES != null) {
			prop = MasterPropertiesFileLoader.CONSTANT_IPRUCONFIG_CONSTANTS_PROPERTIES;
		}
		if (updateEmailMobilePO == null) {
			errorMessage.append("Please Enter your registered email id and mobile no.");
		}
		else {

			if (!validateMobileNo(updateEmailMobilePO)) {
				errorMessage.append("Please Enter valid Mobile Number");
			}

			if (!validateEmail(updateEmailMobilePO.getEmailId())) {
				errorMessage.append("Please Enter valid Email Id");
			}
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return errorMessage.toString();
	}



	private boolean validateMobileNo(UpdateEmailMobilePO updateEmailMobilePO) {
		if((updateEmailMobilePO.getCountryName().equals(prop.getProperty("INDIA")))||(updateEmailMobilePO.getCountryName().equals("")))
		{
		if ((StringUtils.isNotBlank(String.valueOf(updateEmailMobilePO.getMobileNo())) && CommonValidationUtil.isMatchedPattern(String.valueOf(updateEmailMobilePO.getMobileNo()), GroupFormValidationConstant.MOBILENUMBER_VALIDATION_FORGROUP) || (String.valueOf(updateEmailMobilePO.getMobileNo())).equals("-"))) {
			return true;
		}
		}
		if(!(updateEmailMobilePO.getCountryName().equals(prop.getProperty("INDIA"))))
		{
			if ((StringUtils.isNotBlank(String.valueOf(updateEmailMobilePO.getMobileNo())) && CommonValidationUtil.isMatchedPattern(String.valueOf(updateEmailMobilePO.getMobileNo()), GroupFormValidationConstant.NRI_REGEX) || (String.valueOf(updateEmailMobilePO.getMobileNo())).equals("-"))) {
			return true;
		}
			else {
				return false;
			
		}
		}
		return false;
	
		
	}

	private boolean validateEmail(String emailId) {
		if ((CommonValidationUtil.isMatchedPattern(emailId, GroupFormValidationConstant.EMAILID_VALIDATION) && StringUtils.isNotBlank(emailId)) || emailId.equals("-")) {
			return true;
		}
		else {
			return false;
		}
	}

}
