package com.ipru.groups.validators;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.joda.time.Years;

import com.ipru.IPruException;
import com.ipru.groups.po.ClaimsBenPMJJBYSubmitPO;
import com.ipru.groups.po.ClaimsPMJJBYDropDownPO;
import com.ipru.groups.po.ClaimsPMJJBYSubmitPO;
import com.ipru.groups.po.UploadFilePO;
import com.ipru.groups.utilities.ClaimsPMJJBYUtil;
import com.ipru.groups.utilities.CommonValidationUtil;
import com.ipru.groups.utilities.GroupFormValidationConstant;
import com.ipru.groups.utilities.MasterPropertiesFileLoader;
import com.tcs.logger.FLogger;

public class ClaimsPMJJBYValidator {

	Years age = null;

	public String validateSubmit(ClaimsPMJJBYSubmitPO claimsPMJJBYSubmitPO) throws IPruException, ParseException {
		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", " Method Start ");
		if (claimsPMJJBYSubmitPO != null) {

			if (!validateAlpNumField(claimsPMJJBYSubmitPO.getPolicyNo(), 100, 1)) {
				FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Master Policy Number");
				throw new IPruException("Error", "GRPPFCC", "Invalid Master Policy Number");
			}
			if (!validateAlpSpaceField(claimsPMJJBYSubmitPO.getSchemeName(), 100, 1)) {
				FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Scheme Name");
				throw new IPruException("Error", "GRPPFCC", "Invalid Scheme Name");
			}
			if (!validateNumericField(claimsPMJJBYSubmitPO.getAccountNumber(), 100, 1)) {
				FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Account Number");
				throw new IPruException("Error", "GRPPFCC", "Invalid Account Number");
			}
			/*
			 * if(!validateAlpSpaceField(claimsPMJJBYSubmitPO.getPolHolderName(),
			 * 100,1)){ FLogger.error("ClaimsPMJJBYLogger",
			 * "ClaimsPMJJBYValidator", "validateSubmit",
			 * "Exception Occured, Invalid Policy Holder Name"); throw new
			 * IPruException("Error", "GRPPFCC", "Invalid Policy Holder Name");
			 * }
			 */
			if (StringUtils.isEmpty(claimsPMJJBYSubmitPO.getPolHolderName())) {
				FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Policy Holder Name");
				throw new IPruException("Error", "GRPPFCC", "Invalid Policy Holder Name");
			}

			if (!validateDate(claimsPMJJBYSubmitPO.getClaimDate())) {
				FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Claims Intimation Date");
				throw new IPruException("Error", "GRPPFCC", "Invalid Claims Intimation Date");
			}
			if (!validateDate(claimsPMJJBYSubmitPO.getDeathDate())) {
				FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Death Date");
				throw new IPruException("Error", "GRPPFCC", "Invalid Death Date");
			}
			if (!validateDropDown(claimsPMJJBYSubmitPO.getDeathReason())) {
				FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Death Reason");
				throw new IPruException("Error", "GRPPFCC", "Invalid Death Reason");
			}

			int i = 1;
			Set<ClaimsBenPMJJBYSubmitPO> claimsBenPMJJBYSubmitPOSet = claimsPMJJBYSubmitPO.getBeneficiary();
			for (ClaimsBenPMJJBYSubmitPO claimsBenPMJJBYSubmitPO : claimsBenPMJJBYSubmitPOSet) {
				if (i <= 3) {

					if (!validateAlpSpaceField(claimsBenPMJJBYSubmitPO.getBeneficiaryName(), 100, 1)) {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Beneficiary Name");
						throw new IPruException("Error", "GRPPFCC", "Invalid Beneficiary Name");
					}

					if (!validateAlpSpaceField(claimsBenPMJJBYSubmitPO.getRelation(), 100, 1)) {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Relation");
						throw new IPruException("Error", "GRPPFCC", "Invalid Relation");
					}
					if (!validateNumericField(claimsBenPMJJBYSubmitPO.getSharePercentage(), 3, 1)) {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Share Percentage");
						throw new IPruException("Error", "GRPPFCC", "Invalid Share Percentage");
					}
					if (!validateDate(claimsBenPMJJBYSubmitPO.getBeneficiaryDOB())) {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Beneficiary Date Of Birth");
						throw new IPruException("Error", "GRPPFCC", "Invalid Beneficiary Date Of Birth");
					}
					if (!validateDropDown(claimsBenPMJJBYSubmitPO.getGender())) {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Gender");
						throw new IPruException("Error", "GRPPFCC", "Invalid Gender");
					}
					if (!validateNumericField(claimsBenPMJJBYSubmitPO.getMobileNumber(), 10, 1)) {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Mobile Number");
						throw new IPruException("Error", "GRPPFCC", "Invalid Mobile Number");
					}
					if (!validateAddressField(claimsBenPMJJBYSubmitPO.getBenAddress(), 400, 1)) {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Address");
						throw new IPruException("Error", "GRPPFCC", "Invalid Address");
					}
					if (!validateAlpSpaceField(claimsBenPMJJBYSubmitPO.getCity(), 20, 1)) {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid City");
						throw new IPruException("Error", "GRPPFCC", "Invalid City");
					}
					if (!validateNumericField(claimsBenPMJJBYSubmitPO.getPincode(), 6, 1)) {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Pin Code");
						throw new IPruException("Error", "GRPPFCC", "Invalid Pin Code");
					}
					if (!validateDropDown(claimsBenPMJJBYSubmitPO.getTypeOfPayment())) {
						FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Type of Payment");
						throw new IPruException("Error", "GRPPFCC", "Invalid Type of Payment");
					}
					if (claimsBenPMJJBYSubmitPO.getTypeOfPayment().equals("credit")) {

						if (!validateNumericField(claimsBenPMJJBYSubmitPO.getMicrCode(), 9, 9)) {
							FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid MICR Code");
							throw new IPruException("Error", "GRPPFCC", "Invalid MICR Code");
						}
						if (!validateIfscField(claimsBenPMJJBYSubmitPO.getIfscCode(), 20, 1)) {
							FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid IFSC Code");
							throw new IPruException("Error", "GRPPFCC", "Invalid IFSC Code");
						}
						if (!validateAlpSpaceField(claimsBenPMJJBYSubmitPO.getBankName(), 20, 1)) {
							FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Bank Name");
							throw new IPruException("Error", "GRPPFCC", "Invalid Bank Name");
						}
						if (!validateNumericField(claimsBenPMJJBYSubmitPO.getBankAcc(), 20, 1)) {
							FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Bank Account number");
							throw new IPruException("Error", "GRPPFCC", "Invalid Bank Account number");
						}
						if (!validateAddressField(claimsBenPMJJBYSubmitPO.getBankAddress(), 400, 1)) {
							FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, Invalid Bank Address");
							throw new IPruException("Error", "GRPPFCC", "Invalid Bank Address");
						}
					}

					claimsBenPMJJBYSubmitPO.setBeneficiaryPos(String.valueOf(i));
					i++;
				}
				else {
					FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "Exception Occured, You can add only 3 Beneficiary");
					throw new IPruException("Error", "GRPPFCC", "You can add only 3 Beneficiary");
				}
			}

			if (claimsPMJJBYSubmitPO.getClaimForm().size() != 2 && claimsPMJJBYSubmitPO.getClaimForm().size() == 0) {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid claim form submited");
				throw new IPruException("Error", "GRPPFCC", "Invalid claim form submited");
			}
			if (claimsPMJJBYSubmitPO.getDeathCertificate().size() > 1 && claimsPMJJBYSubmitPO.getDeathCertificate().size() == 0) {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Death Certificate submited");
				throw new IPruException("Error", "GRPPFCC", "Invalid Death Certificate form submited");
			}
			if (claimsPMJJBYSubmitPO.getCancelledCheque().size() > 1 && claimsPMJJBYSubmitPO.getCancelledCheque().size() == 0) {
				FLogger.error("ClaimAnnuityLogger", "ClaimAnnuityValidator", "validateSubmit", "Exception Occured, Invalid Cancelled Cheque submited");
				throw new IPruException("Error", "GRPPFCC", "Invalid Cancelled Cheque submited");
			}
			

		}
		else {
			FLogger.error("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", "claimsPMJJBYSubmitPO is null");
			throw new IPruException("Error", "GRPPFCC", "claimsPMJJBYSubmitPO is null");
		}

		FLogger.info("ClaimsPMJJBYLogger", "ClaimsPMJJBYValidator", "validateSubmit", " Method End ");
		return null;
	}

	private boolean validateNumericField(String val, Integer num, Integer min) {

		if (CommonValidationUtil.ValidateNumeric(val) && CommonValidationUtil.ValidateMaxLength(val, num) && CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		}
		else {
			return false;
		}

	}

	private boolean validateAlpSpaceField(String val, Integer num, Integer min) {

		if (StringUtils.isAlphaSpace(val) && CommonValidationUtil.ValidateMaxLength(val, num) && CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		}
		else {
			return false;
		}

	}

	private boolean validateAlpNumField(String val, Integer num, Integer min) {

		if (StringUtils.isAlphanumeric(val) && CommonValidationUtil.ValidateMaxLength(val, num) && CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;

		}
		else {
			return false;
		}

	}

	private boolean validateDate(String date) throws ParseException {
		SimpleDateFormat format1 = new SimpleDateFormat("dd MMMM, yyyy", Locale.ENGLISH);

		Date date1 = format1.parse(date);

		Date today = new Date();

		if (date1.before(today)) {

			if (CommonValidationUtil.ValidateRequired(date)) {

				return true;
			}
			else {

				return false;
			}
		}
		else {
			return false;
		}
	}

	private boolean validateDropDown(String val) {

		ClaimsPMJJBYUtil claimsPMJJBYUtil = new ClaimsPMJJBYUtil();
		ClaimsPMJJBYDropDownPO claimsPMJJBYDropDownPO = claimsPMJJBYUtil.getDropDownList();
		if (claimsPMJJBYDropDownPO.getGenderList().contains(val)) {
			return true;
		}
		else if (claimsPMJJBYDropDownPO.getReason().contains(val)) {
			return true;
		}
		else if (claimsPMJJBYDropDownPO.getTypeOfPaymentList().contains(val)) {
			return true;
		}
		else {
			return false;
		}

	}

	private boolean validateAddressField(String val, Integer max, Integer min) {

		if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.ADDRESS_VALIDATION) && CommonValidationUtil.ValidateMaxLength(val, max)
				&& CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;
		}
		else {
			return false;
		}

	}

	private boolean validateIfscField(String val, Integer num, Integer min) {

		if (CommonValidationUtil.isMatchedPattern(val, GroupFormValidationConstant.IFSC_CODE_VALIDATION_FORGROUP) && CommonValidationUtil.ValidateMaxLength(val, num)
				&& CommonValidationUtil.ValidateMinLength(val, min)) {
			return true;
		}
		else {
			return false;
		}

	}

}
