package com.ipru.groups.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

import com.ipru.IPruException;
import com.ipru.groups.po.UpdateEmailMobilePO;
import com.ipru.groups.utilities.GroupSecurityUtil;
import com.ipru.groups.utilities.SessionKeyConstants;
import com.ipru.groups.validators.UpdateEmailMobileValidator;
import com.ipru.groups.vo.UpdateEmailMobileVO;
import com.ipru.otp.po.OTPNumberParamBean;
import com.ipru.security.user.IPruUser;
import com.tcs.businessdelegation.BizRequest;
import com.tcs.businessdelegation.BizResponse;
import com.tcs.exception.ServiceException;
import com.tcs.logger.FLogger;
import com.tcs.security.annotations.MethodPost;

public class UpdateEmailMobileHandler extends IneoBaseHandler {

	private static final long serialVersionUID = 1L;
	private final String LOGGER_NAME = "UpdateEmailMobileLogger";
	private final String CLASS_NAME = "UpdateEmailMobileHandler";
	private String METHOD_NAME = null;

	@SuppressWarnings("unused")
	@MethodPost
	public Event getBizRequestForEmailMobileSubmit(RequestContext context) throws Exception {
		METHOD_NAME = "getBizRequestForEmailMobileSubmit";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		String webClientId = null;

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
						if (request != null) {
							UpdateEmailMobilePO updateEmailMobilePO = gsonJSON.fromJson(request.getReader(), UpdateEmailMobilePO.class);
							webClientId = userVo.getWebClientId();
							if (webClientId != null) {
								updateEmailMobilePO.setWebClientId(webClientId);

								UpdateEmailMobileValidator updateEmailMobileValidator = new UpdateEmailMobileValidator();

								String validation = updateEmailMobileValidator.validateEmailMobile(updateEmailMobilePO);

								if (StringUtils.isNotBlank(validation)) {
									FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Validation errors : " + validation);
									this.setValidationErrorMessages(validation);
									throwINeoFlowException(new ServiceException("GRPUEM"), context);
								}

								if (updateEmailMobilePO != null) {
									context.getFlowScope().put("updateEmailMobilePO", updateEmailMobilePO);

									UpdateEmailMobileVO updateEmailMobileVO = dozerBeanMapper.map(updateEmailMobilePO, UpdateEmailMobileVO.class);

									Object[] paramArray = new Object[1];
									paramArray[0] = updateEmailMobileVO;

									BizRequest obj_bizReq = new BizRequest();
									obj_bizReq.addbusinessObjects("service-obj1", paramArray);

									context.getFlowScope().put("bizReqForEmailMobileSubmit", obj_bizReq);

								}

								else {
									FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UpdateEmailMobilePO  from request should not be null");
									throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
								}
							}

							else {
								FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, " webClientId  should not be null");
								throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
							}
						}

						else {
							FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Http Request should not be null");
							throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
						}
					}

					else {
						FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UserVO in session should not be null");
						throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
					}
				}

				else {
					FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "session should not be null");
					throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
				}
			}

			else {
				FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPUEM", context);
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end");
		return success();
	}

	@MethodPost
	public Event getBizResponseForEmailMobileSubmit(RequestContext context) throws Exception {
		METHOD_NAME = "getBizResponseForEmailMobileSubmit";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";
		String isEmailMobileExistString = null;

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						bizRes = (BizResponse) context.getFlowScope().get("bizResForEmailMobileSubmit");

						if (bizRes != null) {
							responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
							}
							else {
								UpdateEmailMobilePO updateEmailMobilePO = (UpdateEmailMobilePO) context.getFlowScope().get("updateEmailMobilePO");

								if (updateEmailMobilePO != null) {

									String emailId = updateEmailMobilePO.getEmailId();
									String mobileNo = updateEmailMobilePO.getMobileNo();

									if (emailId != null && mobileNo != null) {
										userVo.setEmailId(emailId);
										userVo.setMobileNo(String.valueOf(mobileNo));
									}
									GroupSecurityUtil.setAttributeInSession(context, "userVO", userVo);
								}
								isEmailMobileExistString = (String) bizRes.getTransferObjects().get("response1");

								if (StringUtils.isBlank(isEmailMobileExistString)) {
									FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "isEmailMobileExistString is blank.");
									throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
								}
								else if (StringUtils.startsWith(isEmailMobileExistString, "ERROR")) {
									FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, isEmailMobileExistString);
									throw new IPruException("Error", "GRPUEM", isEmailMobileExistString);
								}

								else {

									String callJsonString = isEmailMobileExistString;
									FLogger.info(LOGGER_NAME, CLASS_NAME, "getBizResponseForGettingCountryNames", "callJsonString::");
									context.getFlowScope().put("Response", callJsonString);
								}

							}
						}
						else {
							FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
							throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UserVO in session should not be null");
						throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "session should not be null");
					throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPUEM", context);
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	@MethodPost
	public Event getBizRequestForEmailMobileSave(RequestContext context) throws Exception {
		METHOD_NAME = "getBizRequestForEmailMobileSave";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		String webClientId = null;

		Boolean isOTPValidated = false;

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();
				if (httpSession != null) {
					// Check whether OTP is verified or not.
					isOTPValidated = (Boolean) GroupSecurityUtil.getAttributeFromSession(context, SessionKeyConstants.CONSTANT_FLOWSCOPE_IS_TRANSACTION_OTP_VERIFIED);

					if (!isOTPValidated) {
						throwINeoFlowException(new ServiceException("PFPAY31"), context);
					}

					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");
					if (userVo != null) {

						webClientId = userVo.getWebClientId();

						HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getNativeRequest();
						if (request != null) {

							UpdateEmailMobilePO updateEmailMobilePO = (UpdateEmailMobilePO) context.getFlowScope().get("updateEmailMobilePO");

							if (updateEmailMobilePO != null) {

								UpdateEmailMobileVO updateEmailMobileVO = dozerBeanMapper.map(updateEmailMobilePO, UpdateEmailMobileVO.class);
								updateEmailMobileVO.setWebClientId(webClientId);

								Object[] paramArray = new Object[1];
								paramArray[0] = updateEmailMobileVO;

								BizRequest obj_bizReq = new BizRequest();
								obj_bizReq.addbusinessObjects("service-obj1", paramArray);

								context.getFlowScope().put("bizReqForEmailMobileSave", obj_bizReq);
							}
							else {
								FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UpdateEmailMobilePO from request should not be null");
								throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
							}
						}
						else {
							FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Http Request should not be null");
							throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UserVO in session should not be null");
						throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "session should not be null");
					throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPUEM", context);
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	@MethodPost
	public Event getBizResponseForEmailMobileSave(RequestContext context) throws Exception {
		METHOD_NAME = "getBizResponseForEmailMobileSave";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");

		BizResponse bizRes = new BizResponse();
		String responseCheck = "";

		try {
			if (context != null) {
				HttpSession httpSession = ((HttpServletRequest) context.getExternalContext().getNativeRequest()).getSession();

				if (httpSession != null) {
					IPruUser userVo = (IPruUser) httpSession.getAttribute("userVO");

					if (userVo != null) {

						bizRes = (BizResponse) context.getFlowScope().get("bizResForEmailMobileSave");

						if (bizRes != null) {
							responseCheck = (String) bizRes.getStatusVO().getStatus();
							if (StringUtils.equalsIgnoreCase(responseCheck, "ERROR")) {
								throwINeoFlowException(bizRes.getStatusVO(), context);
							}
							else {
								String isEmailMobileUpdatedString = (String) bizRes.getTransferObjects().get("response1");

								if (StringUtils.isNotBlank(isEmailMobileUpdatedString) && StringUtils.equalsIgnoreCase(isEmailMobileUpdatedString, "true")) {

									context.getFlowScope().put("Response", "Success");
								}
								else {
									FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "isEmailMobileUpdatedString is empty or false");
									throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
								}
							}
						}
						else {
							FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "bizRes should not be null");
							throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
						}
					}
					else {
						FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "UserVO in session should not be null");
						throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
					}
				}
				else {
					FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "session should not be null");
					throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
				}
			}
			else {
				FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "context should not be null");
				throw new IPruException("Error", "GRPUEM", "Something went wrong. Please try again later.");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			FLogger.error(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Exception came ", e);
			throwINeoFlowException(e, "GRPUEM", context);
		}

		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
		return success();
	}

	@Override
	public void setOtpCallBacks(OTPNumberParamBean paramBean, RequestContext ObjContext) {
		METHOD_NAME = "setOtpCallBacks";
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method start ");
		paramBean.setFunctionality("UPDATE_EMAIL_MOBILE");
		setTransactionalOTPCallback(Boolean.TRUE);
		FLogger.info(LOGGER_NAME, CLASS_NAME, METHOD_NAME, "Method end ");
	}

}
