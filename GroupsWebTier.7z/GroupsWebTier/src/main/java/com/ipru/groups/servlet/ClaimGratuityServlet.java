package com.ipru.groups.servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.ipru.groups.pdfgen.TemplateCoreServiceImpl;
import com.ipru.groups.po.ClaimGratuityWithDrawalUnitPO;
import com.ipru.groups.utilities.GroupCommonUtils;
import com.ipru.groups.utilities.GroupConstants;
import com.ipru.groups.vo.ClaimGratuityLeaveVO;
import com.ipru.groups.vo.ClaimGratuityVO;
import com.ipru.groups.vo.ClaimGratuityWithDrawalUnitVO;
import com.ipru.groups.vo.PmjjbyVO;
import com.tcs.logger.FLogger;
import com.tcs.pdfgenerator.core.service.ITemplateCoreService;
import com.tcs.pdfgenerator.exception.PDFGeneratorException;
import com.tcs.pdfgenerator.service.FTL2PDFGenerator;
import com.tcs.pdfgenerator.util.PDFGeneratorUtils;

/**
 * Servlet implementation class ExcelDownload
 */

public class ClaimGratuityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		FLogger.info("ClaimGratuityLogger", "ClaimGratuityServlet", "doPost", "method to Download pdf starts");
		String filePath = null;
		
		HttpSession session = request.getSession();
		ClaimGratuityVO claimGratuityVO = null;
		Set<ClaimGratuityWithDrawalUnitVO> withDrawalUnitSet=null;
		Set<ClaimGratuityLeaveVO> leaveSet=null;
		Date todayDate=new Date();
		

		SimpleDateFormat targetFormat = new SimpleDateFormat("dd MM yyyy");
		String todayDate1 = targetFormat.format(todayDate);
		try {

			if (session == null) {
				FLogger.info("ClaimGratuityLogger", "ClaimGratuityServlet", "doPost", "session is null");
				throw new ServletException("session is null");
			}

			String claimGratuityFtlPath = "ClaimGratuity.ftl";
			long TimeStamp = new Date().getTime();
			ITemplateCoreService service = new TemplateCoreServiceImpl();
			String destination = GroupCommonUtils.createDirWithTodaysDate(GroupConstants.CONSTANT_DOCUMENT_UPLOAD_PATH);

			if (destination == null) {
				FLogger.info("ClaimGratuityLogger", "ClaimGratuityServlet", "doPost", "destination is null");
				throw new ServletException("Null data found");
			}

			

			 claimGratuityVO = (ClaimGratuityVO) session.getAttribute("claimGratuityVoData");
			 
			 claimGratuityVO.setTodayDate(todayDate1);
			
			if (StringUtils.isEmpty(claimGratuityVO.getPolicyNumber())) {
				claimGratuityVO.setPolicyNumber("-");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getTrustieeName())){
				claimGratuityVO.setTrustieeName("-");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getClaimType()))
			{
				claimGratuityVO.setClaimType("-");
			}
			if (StringUtils.isEmpty(claimGratuityVO.getEmployeeName())) {
				claimGratuityVO.setEmployeeName("-");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getMemberId())){
				claimGratuityVO.setMemberId("-");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getDob()))
			{
				claimGratuityVO.setDob("-");
			}
			
			if (StringUtils.isEmpty(claimGratuityVO.getDoj())) {
				claimGratuityVO.setDoj("-");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getDor())){
				claimGratuityVO.setDor("-");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getLwd()))
			{
				claimGratuityVO.setLwd("-");
			}
			if (StringUtils.isEmpty(Long.toString(claimGratuityVO.getLastDrawnSalary()))) {
				claimGratuityVO.setLastDrawnSalary(Long.parseLong("-"));
			}
			if(StringUtils.isEmpty(claimGratuityVO.getDisability())){
				claimGratuityVO.setDisability("NA");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getMonthOfService()))
			{
				claimGratuityVO.setMonthOfService("-");
			}
			if (StringUtils.isEmpty(claimGratuityVO.getDateOfDeath())) {
				claimGratuityVO.setDateOfDeath("NA");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getCauseOfClaim())){
				claimGratuityVO.setCauseOfClaim("NA");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getAddressLine1()))
			{
				claimGratuityVO.setAddressLine1("NA");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getAddressLine2()))
			{
				claimGratuityVO.setAddressLine2("");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getAddressLine3()))
			{
				claimGratuityVO.setAddressLine3("");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getState()))
			{
				claimGratuityVO.setState("");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getCity()))
			{
				claimGratuityVO.setCity("");
			}
			if (StringUtils.isEmpty(claimGratuityVO.getBeneficiaryFirstName())) {
				claimGratuityVO.setBeneficiaryFirstName("NA");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getBeneficiaryMiddleName())){
				claimGratuityVO.setBeneficiaryMiddleName("");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getBeneficiarySurName()))
			{
				claimGratuityVO.setBeneficiarySurName("");
			}
			
			if (StringUtils.isEmpty(claimGratuityVO.getBeneficiaryRelation())) {
				claimGratuityVO.setBeneficiaryRelation("NA");
			}
			if (StringUtils.isEmpty(claimGratuityVO.getAppointeeFirstName())) {
				claimGratuityVO.setAppointeeFirstName("NA");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getAppointeeMiddleName())){
				claimGratuityVO.setAppointeeMiddleName("");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getAppointeeSurName()))
			{
				claimGratuityVO.setAppointeeSurName("");
			}
			
			if (StringUtils.isEmpty(claimGratuityVO.getAppointeeRelation())) {
				claimGratuityVO.setAppointeeRelation("NA");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getMajorMinor())){
				claimGratuityVO.setMajorMinor("-");
			}
			
			
			if(StringUtils.isEmpty(claimGratuityVO.getClaimCause())){
				claimGratuityVO.setClaimCause("-");
			}
			if(StringUtils.isEmpty(String.valueOf(claimGratuityVO.getAmountPaid())))
			{
				claimGratuityVO.setAmountPaid(Integer.parseInt("-"));
			}
			if(StringUtils.isEmpty(claimGratuityVO.getPayeeName()))
			{
				claimGratuityVO.setPayeeName("-");
			}
			if(StringUtils.isEmpty(claimGratuityVO.getTodayDate()))
			{
				claimGratuityVO.setTodayDate("-");
			}
			
			
			withDrawalUnitSet=new HashSet<ClaimGratuityWithDrawalUnitVO>();
			withDrawalUnitSet=claimGratuityVO.getWithdrawalUnit();
			
			if(!CollectionUtils.isEmpty(withDrawalUnitSet))
			{
				for(ClaimGratuityWithDrawalUnitVO claimGratuityWithDrawalSet:withDrawalUnitSet)
				{
					if(StringUtils.isEmpty(claimGratuityWithDrawalSet.getPlanName()))
					{
						claimGratuityWithDrawalSet.setPlanName("-");
					}
					if(StringUtils.isEmpty(Integer.toString(claimGratuityWithDrawalSet.getWithdrawalPercent())))
					{
						claimGratuityWithDrawalSet.setWithdrawalPercent(Integer.parseInt("-"));
					}
					
				}
			}
			
			leaveSet=new HashSet<ClaimGratuityLeaveVO>();
			leaveSet=claimGratuityVO.getLeaveArray();
			if(!CollectionUtils.isEmpty(leaveSet))
			{
				for(ClaimGratuityLeaveVO claimGratuityLeaveSet:leaveSet)
				{
					if(StringUtils.isEmpty(claimGratuityLeaveSet.getToDate()))
					{
						claimGratuityLeaveSet.setToDate("-");
					}
					if(StringUtils.isEmpty(claimGratuityLeaveSet.getFromDate()))
					{
						claimGratuityLeaveSet.setFromDate("-");
					}
					if(StringUtils.isEmpty(claimGratuityLeaveSet.getIllnessType()))
					{
						claimGratuityLeaveSet.setIllnessType("-");
					}
					if(StringUtils.isEmpty(claimGratuityLeaveSet.getReasonForLeave()))
					{
						claimGratuityLeaveSet.setReasonForLeave("-");
					}
				}
			}
			
 
			byte[] bufferData = FTL2PDFGenerator.getPDFGeneratorInstance.generatePDFTemplate(PDFGeneratorUtils.createTemplateBean(claimGratuityFtlPath, claimGratuityVO), service);

			
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			ServletOutputStream objServletOutputStream = null;
			
			output.write(bufferData);
			response.addHeader("Content-Disposition", "attachment; filename=\"" + "pmjjby.pdf" + "\"");
			response.setContentType("application/pdf");
			output.flush();
			response.setContentLength(output.size());
			objServletOutputStream = response.getOutputStream();
			output.writeTo(objServletOutputStream);
			objServletOutputStream.flush();

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			session.removeAttribute("claimGratuityVoData");

		}
		FLogger.info("ClaimGratuityLogger", "ClaimGratuityServlet", "doPost", "method to Download pdf end");
	}
}
