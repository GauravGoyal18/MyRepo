package com.ipru.ws.util;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:com/tcs/root/properties/configdirectory.properties")
public class SpringConfig {

}