package com.ipru.ws.groups.authentication.service;

import java.io.IOException;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.ipru.ws.groups.properties.PropertyLoaderServiceImpl;

public class AuthenticationServiceImpl implements AuthenticationService {
	@Autowired
	private ApplicationContext applicationContext;
	@Autowired
	private PropertyLoaderServiceImpl propertyLoaderService;

	@Override
	public boolean authenticate(String authCredentials) {
		try {
			// ////System.out.println("authenticate called");
			if (null == authCredentials)
				return false;
			// header value format will be "Basic encodedstring" for Basic
			// authentication. Example "Basic YWRtaW46YWRtaW4="
			final String encodedUserPassword = authCredentials.replaceFirst("Basic" + " ", "");
			String usernameAndPassword = null;
			try {
				byte[] decodedBytes = Base64.decodeBase64(encodedUserPassword);
				usernameAndPassword = new String(decodedBytes, "UTF-8");
			}
			catch (IOException e) {
				e.printStackTrace();
			}
			final StringTokenizer tokenizer = new StringTokenizer(usernameAndPassword, ":");
			final String username = tokenizer.nextToken();
			final String password = tokenizer.nextToken();
			// we have fixed the userid and password as admin
			// call some UserService/LDAP here

			// Properties prop=new Properties();
			Properties prop = propertyLoaderService.CONSTANT_AUTHENTICATION_PROPERTIES;
			// applicationContext.getBean("authentication", Properties.class);
			// prop=propertiesFileLoader.CONSTANT_AUTHENTICATION_PROPERTIES;

			String authUserName = prop.getProperty("authUserName");
			String authPass = prop.getProperty("authPassword");
			boolean authenticationStatus = authUserName.equals(username) && authPass.equals(password);
			// //System.out.println(authenticationStatus+" authenticationStatus");
			return authenticationStatus;
		}
		catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public void test() {
		// ////System.out.println("Method called");
	}

	public Properties propertyFileLoader(String fileName) throws Exception {
		Properties prop = new Properties();
		try {
			prop.load(this.getClass().getResourceAsStream(fileName));
			// ////System.out.println("fileName**************"+fileName);
		}
		catch (Exception e) {

			throw e;
		}
		return prop;
	}
}
