package com.ipru.ws.groups.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.NoDataFoundException;
import com.ipru.ws.groups.beans.GroupUser;
import com.ipru.ws.groups.beans.UserDetailsVO;
import com.ipru.ws.groups.dao.UserDetailDAOImpl;

public class UserDetailServiceImpl implements UserDetailService {
	private static final Logger LOGGER = LogManager.getLogger(UserDetailServiceImpl.class);

	private UserDetailDAOImpl userDetailDAO;

	public UserDetailDAOImpl getUserDetailDAO() {
		return userDetailDAO;
	}

	public void setUserDetailDAO(UserDetailDAOImpl userDetailDAO) {
		this.userDetailDAO = userDetailDAO;
	}

	public List<UserDetailsVO> getUserDetailsService(GroupUser groupUser) throws ApplicationException, DatabaseException, BadDataException,NoDataFoundException {
		
		
		LOGGER.info("getUserDetailsService method Called");
		
		List<UserDetailsVO> userDetailsList = null;
		String emailId = "";
		Long mobileNo = null;
	
		if (groupUser != null) {
			emailId = groupUser.getEmailId();
			
			mobileNo = groupUser.getMobileNo();
			
			userDetailsList = userDetailDAO.getUserDetailsDao(emailId, String.valueOf(mobileNo));
			
			return userDetailsList;
		} else {
			LOGGER.error("Found null request data");
			
			throw new BadDataException("Found null request data");
		}
	}
}
