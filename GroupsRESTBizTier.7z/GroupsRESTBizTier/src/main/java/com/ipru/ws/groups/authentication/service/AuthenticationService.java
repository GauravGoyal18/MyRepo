package com.ipru.ws.groups.authentication.service;

public interface AuthenticationService {

	public boolean authenticate(String authCredentials);

	void test();
}
