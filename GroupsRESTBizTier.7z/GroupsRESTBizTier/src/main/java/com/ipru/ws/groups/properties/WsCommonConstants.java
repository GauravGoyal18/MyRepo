package com.ipru.ws.groups.properties;

public class WsCommonConstants {

	public static final String CONSTANT_AUTHENTICATION = "authentication";
	public static final String CONSTANT_PREPOPULATE = "prePopulate";
	public static final String CONSTANT_DROPDOWN = "dropDown";
	public static final String CONSTANT_JAVACLASSLIST = "javaClassList";
	public static final String CONSTANT_CONFIGDIR_PATH = "/com/tcs/root/properties/configdirectory.properties";
	public static final String CONSTANT_CONFIG_DIRECTORY = "CONFIG_DIRECTORY";
	public static final String CONSTANT_GRP_REST_CONFIG_DIRECTORY = "GRP_REST_CONFIG_DIRECTORY";
	public static final String CONSTANT_GRP_REST_LOG_DIRECTORY = "GRP_REST_LOG_DIRECTORY";

}
