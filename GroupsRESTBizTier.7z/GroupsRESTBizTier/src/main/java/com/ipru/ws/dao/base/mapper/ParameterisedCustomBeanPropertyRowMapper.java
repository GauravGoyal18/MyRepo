package com.ipru.ws.dao.base.mapper;

import java.beans.PropertyDescriptor;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.NotReadablePropertyException;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.beans.TypeMismatchException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.util.Assert;

/**
 * This class populates the property values of the mapped class along with the
 * associated object values in their defined object hierarchy
 * 
 * @author snishad
 */
public class ParameterisedCustomBeanPropertyRowMapper<T> extends BeanPropertyRowMapper<T> implements RowMapper<T> {

	/** Logger available to subclasses */
	protected final Log logger = LogFactory.getLog(getClass());

	/** The class we are mapping to */
	private Class<T> mappedClass;

	/** Map of the fields we provide mapping for */
	private Map<String, PropertyDescriptor> mappedFields;

	/** Constant to hold the alias name separator */
	private static final String ALIAS_NAME_SEPARATOR = "$";

	/**
	 * Create a new ParameterisedCustomBeanPropertyRowMapper for bean-style
	 * configuration.
	 * 
	 * @see #setMappedClass
	 */
	public ParameterisedCustomBeanPropertyRowMapper() {
	}

	/**
	 * Create a new ParameterisedCustomBeanPropertyRowMapper, accepting
	 * unpopulated properties in the target bean.
	 * 
	 * @param mappedClass
	 *            the class that each row should be mapped to
	 */
	public ParameterisedCustomBeanPropertyRowMapper(Class<T> mappedClass) {
		initialize(mappedClass);
	}

	/**
	 * Static factory method to create a new
	 * ParameterisedCustomBeanPropertyRowMapper (with the mapped class specified
	 * only once).
	 * 
	 * @param mappedClass
	 *            the class that each row should be mapped to
	 */
	public static <T> ParameterisedCustomBeanPropertyRowMapper<T> newInstance(Class<T> mappedClass) {
		ParameterisedCustomBeanPropertyRowMapper<T> newInstance = new ParameterisedCustomBeanPropertyRowMapper<T>();
		newInstance.setMappedClass(mappedClass);
		return newInstance;
	}

	/**
	 * Set the class that each row should be mapped to.
	 */
	public void setMappedClass(Class<T> mappedClass) {
		if (this.mappedClass == null) {
			initialize(mappedClass);
		}
		else if (!this.mappedClass.equals(mappedClass)) {
			throw new InvalidDataAccessApiUsageException("The mapped class can not be reassigned to map to " + mappedClass + " since it is already providing mapping for " + this.mappedClass);
		}
	}

	/**
	 * Initialize the mapping metadata for the given class.
	 * 
	 * @param mappedClass
	 *            the mapped class.
	 */
	protected void initialize(Class<T> mappedClass) {
		this.mappedClass = mappedClass;
		this.mappedFields = new HashMap<String, PropertyDescriptor>();
		PropertyDescriptor[] mappedClassPropDescriptors = BeanUtils.getPropertyDescriptors(mappedClass);
		for (PropertyDescriptor propertyDescriptor : mappedClassPropDescriptors) {
			if (propertyDescriptor.getWriteMethod() != null) {
				String propDescrName = propertyDescriptor.getName();
				this.mappedFields.put(propDescrName.toLowerCase(), propertyDescriptor);
				String underscoredPropName = getUnderscoredName(propDescrName);
				if (!propDescrName.toLowerCase().equals(underscoredPropName)) {
					this.mappedFields.put(underscoredPropName, propertyDescriptor);
				}
			}
		}
	}

	/**
	 * Convert property name in camelCase to an underscored name in lower case.
	 * Any upper case letters are converted to lower case with a preceding
	 * underscore.
	 * 
	 * @param name
	 *            the string containing original name
	 * @return the converted name
	 */
	private String getUnderscoredName(String name) {
		StringBuilder result = new StringBuilder();
		if (name != null && name.length() > 0) {
			result.append(name.substring(0, 1).toLowerCase());
			for (int i = 1; i < name.length(); i++) {
				String s = name.substring(i, i + 1);
				if (s.equals(s.toUpperCase())) {
					result.append("_");
					result.append(s.toLowerCase());
				}
				else {
					result.append(s);
				}
			}
		}
		return result.toString();
	}

	/**
	 * Extract the values for all columns in the current row and sets the values
	 * to the matching property names in the current object and the associated
	 * objects which are not basically Strings, Integers etc types i.e, this
	 * will dynamically sets the value in the object hierarchy.
	 * <p>
	 * Utilizes public setters and result set metadata.
	 * 
	 * @see java.sql.ResultSetMetaData
	 */
	@SuppressWarnings("unchecked")
	@Override
	public T mapRow(ResultSet rs, int rowNumber) throws SQLException {
		Assert.state(this.mappedClass != null, "Mapped class was not specified");
		T mappedObject = (T) BeanUtils.instantiateClass(this.mappedClass);
		BeanWrapper mappedClassBeanWrapper = PropertyAccessorFactory.forBeanPropertyAccess(mappedObject);

		ResultSetMetaData rsmd = rs.getMetaData();
		Map<String, BeanWrapper> beanWrapperMap = new HashMap<String, BeanWrapper>();

		for (int index = 1; index <= rsmd.getColumnCount(); index++) {

			String column = JdbcUtils.lookupColumnName(rsmd, index);
			PropertyDescriptor crntObjsPropDescr = null;
			BeanWrapper crntObjsBeanWrapper = mappedClassBeanWrapper;

			if (column != null && column.contains(ALIAS_NAME_SEPARATOR)) {
				String[] propHierarchy = StringUtils.split(column, ALIAS_NAME_SEPARATOR);
				crntObjsBeanWrapper = getTargetObjectByAliasName(propHierarchy, crntObjsBeanWrapper, beanWrapperMap);
				crntObjsPropDescr = crntObjsBeanWrapper.getPropertyDescriptor(getMatchingPropertyName(crntObjsBeanWrapper, propHierarchy[propHierarchy.length - 1]));
			}
			else {

				crntObjsPropDescr = this.mappedFields.get(column.replaceAll(" ", StringUtils.EMPTY).toLowerCase());
			}

			if (crntObjsPropDescr != null) {
				Object value = JdbcUtils.getResultSetValue(rs, index, crntObjsPropDescr.getPropertyType());

				StringBuilder strBuilder = new StringBuilder("Mapping column '");
				strBuilder.append(column).append("' to property '").append(crntObjsPropDescr.getName()).append("' of type ").append(crntObjsPropDescr.getPropertyType());
				logger.debug(strBuilder.toString());

				try {
					crntObjsBeanWrapper.setPropertyValue(crntObjsPropDescr.getName(), value);
				}
				catch (TypeMismatchException typMisExce) {
					if (value == null) {
						StringBuilder builder = new StringBuilder("Intercepted TypeMismatchException for row ");
						builder.append(rowNumber).append(" and column '").append(column).append("' with value ").append(value).append(" when setting property '").append(crntObjsPropDescr.getName()).append("' of type ").append(crntObjsPropDescr.getPropertyType()).append(" on object: ").append(mappedObject);
						logger.error(builder.toString());
					}
					else {
						throw typMisExce;
					}
				}
			}
		}
		return mappedObject;
	}

	/**
	 * Gets/Generates the respective BeanWrapper object for the property
	 * hierarchy.
	 * 
	 * @param propHierarchy
	 *            Contains an array of property names associated in the object
	 *            hierarchy.
	 * @param mappedClassBeanWrapper
	 *            Reference to the mappedClass BeanWrapper object
	 * @param beanWrapperMap
	 *            The bean wrapper map that holds all the property names as per
	 *            the matching alias names and their BeanWrapper instances.
	 * @return BeanWrapper Associated BeanWrapper object
	 */
	private BeanWrapper getTargetObjectByAliasName(String[] propHierarchy, BeanWrapper mappedClassBeanWrapper, Map<String, BeanWrapper> beanWrapperMap) {
		BeanWrapper crntObjsBeanWrapper = mappedClassBeanWrapper;

		if (beanWrapperMap.get(getBeanWrapperKey(propHierarchy, propHierarchy.length - 2)) != null) {
			crntObjsBeanWrapper = beanWrapperMap.get(getBeanWrapperKey(propHierarchy, propHierarchy.length - 2));
		}
		else {
			crntObjsBeanWrapper = getAssociatedTargetObjectWrapper(beanWrapperMap, crntObjsBeanWrapper, propHierarchy);
		}
		return crntObjsBeanWrapper;
	}

	/**
	 * This class gets the associated bean wrapper for the target object whose
	 * property value needs to be set. This will be identified by the alias name
	 * (which will be separated by a '$' symbol) given for the column name in
	 * the query.
	 * 
	 * @param beanWrapperMap
	 *            The bean wrapper map that holds all the property names as per
	 *            the matching alias names and their BeanWrapper instances.
	 * @param mappedClassBeanWrapper
	 *            Reference to the mappedClass BeanWrapper object.
	 * @param propHierarchy
	 *            Contains the array of property names associated in the
	 *            hierarchy.
	 * @return BeanWrapper object.
	 * @throws NotReadablePropertyException
	 */
	private BeanWrapper getAssociatedTargetObjectWrapper(Map<String, BeanWrapper> beanWrapperMap, final BeanWrapper mappedClassBeanWrapper, String... propHierarchy) throws NotReadablePropertyException {
		BeanWrapper parentBeanWrapper = mappedClassBeanWrapper;
		for (int hierarchyCnt = 0; hierarchyCnt < propHierarchy.length - 1; hierarchyCnt++) {
			propHierarchy[hierarchyCnt] = getMatchingPropertyName(parentBeanWrapper, propHierarchy[hierarchyCnt]);
			Object associatedObject = parentBeanWrapper.getPropertyValue(propHierarchy[hierarchyCnt]);
			if (associatedObject == null) {
				associatedObject = BeanUtils.instantiateClass(parentBeanWrapper.getPropertyType(propHierarchy[hierarchyCnt]));
			}
			if (beanWrapperMap.get(getBeanWrapperKey(propHierarchy, hierarchyCnt)) == null) {
				beanWrapperMap.put(getBeanWrapperKey(propHierarchy, hierarchyCnt), PropertyAccessorFactory.forBeanPropertyAccess(associatedObject));
			}
			parentBeanWrapper.setPropertyValue(propHierarchy[hierarchyCnt], associatedObject);
			parentBeanWrapper = beanWrapperMap.get(getBeanWrapperKey(propHierarchy, hierarchyCnt).toUpperCase());
		}
		if (propHierarchy.length > 0) {
			propHierarchy[propHierarchy.length - 1] = getMatchingPropertyName(parentBeanWrapper, propHierarchy[propHierarchy.length - 1]);
		}
		else {
			throw new NotReadablePropertyException(parentBeanWrapper.getClass(), "Blank/Space", "Spaces are not allowed as property names");
		}
		return parentBeanWrapper;
	}

	/**
	 * This method generates a unique key in order to identify the object in any
	 * level of object hierarchy
	 * 
	 * @param strings
	 *            String array representation of all associated objects in the
	 *            current object hierarchy
	 * @param level
	 *            The hierarchy level of the object key to be generated For ex.
	 *            Student.Stream.Subject object hierarchy can be represented in
	 *            the bean wrapper map as Student$Stream$Subject
	 * @return returns a string object
	 */
	public String getBeanWrapperKey(String[] strings, int level) {
		StringBuilder builder = new StringBuilder();
		for (int count = 0; count <= level; count++) {
			builder.append(strings[count]);
			if (count != level) {
				builder.append(ALIAS_NAME_SEPARATOR);
			}
		}
		return builder.toString().toUpperCase();
	}

	/**
	 * This method returns the matching property name of the bean for a given
	 * property alias name.
	 * 
	 * @param beanWrapper
	 *            Current bean wrapper object.
	 * @param aliasName
	 *            Alias name for one of the current class's property.
	 * @return Matching property name
	 */
	private String getMatchingPropertyName(final BeanWrapper beanWrapper, final String aliasName) {
		String propertyName = null;
		for (PropertyDescriptor propertyDescriptor : beanWrapper.getPropertyDescriptors()) {
			if (propertyDescriptor.getDisplayName().equalsIgnoreCase(aliasName)) {
				propertyName = propertyDescriptor.getDisplayName();
				break;
			}
		}
		if (StringUtils.isEmpty(propertyName)) {
			throw new NotReadablePropertyException(beanWrapper.getClass(), aliasName, "Not able to set the value due to invalid property name");
		}
		return propertyName;
	}
}