package com.ipru.ws.groups.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.ws.dao.base.BaseDAO;
import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.NoDataFoundException;
import com.ipru.ws.groups.beans.UserDetailsVO;
import com.ipru.ws.groups.properties.PropertyLoaderServiceImpl;
import com.ipru.ws.groups.service.GroupsServiceImpl;

public class FscDetailsDAOImpl extends BaseDAO   implements FscDetailsDAO 
{
	
	@Autowired
	private PropertyLoaderServiceImpl propertyLoaderService;
	private static final Logger LOGGER = LogManager
			.getLogger(GroupsServiceImpl.class);

	@Override
	public List<FscDetailsVO> getFscDetailsDao(String fsc_client_id) throws ApplicationException, DatabaseException, BadDataException, NoDataFoundException {
		// TODO Auto-generated method stub
         List<FscDetailsVO> fscDetailsList = null;
         String getFscDetailsQuerry = null;

		if(StringUtils.isBlank(fsc_client_id)){
			//TODO: Log and throw exception
			LOGGER.error("fsc_client id parameter is null");
			throw new BadDataException("Found null request data");
		}
		
		Map<String,Object> params = new HashMap<String,Object>(0);
		params.put("fsc_client_id", fsc_client_id);
		
		Properties prop = new Properties();

		prop = propertyLoaderService.CONSTANT_PREPOPULATE_PROPERTIES;      
		if (prop != null) {

			getFscDetailsQuerry = prop.getProperty("getFscDetailsQuerry");
		}
		else {
			LOGGER.error("Error occured while loading property file");
			throw new ApplicationException("100", "Error occured while loading property file");
		}
		
		
		fscDetailsList = getDomainObjsListFromTemplate3(getFscDetailsQuerry, params, FscDetailsVO.class);   
		if(fscDetailsList == null ){
			LOGGER.error("No data found for given request");
			throw new NoDataFoundException("No data found for given request");
		}
		
		   
		return fscDetailsList;
	}

}
