package com.ipru.ws.groups.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ipru.groups.to.CountTO;
import com.ipru.groups.to.DropDownTO;
import com.ipru.groups.to.LatestNavTO;
import com.ipru.groups.to.SwitchTo;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.NoDataFoundException;
import com.ipru.ws.exception.ResourceNotFoundException;
import com.ipru.ws.groups.beans.DropDownRequest;
import com.ipru.ws.groups.beans.GroupPolicyDetail;
import com.ipru.ws.groups.beans.GroupUser;
import com.ipru.ws.groups.beans.PrePopulateBean;
import com.ipru.ws.groups.beans.SwitchToRequest;
import com.ipru.ws.groups.beans.UserDetailsVO;
import com.ipru.ws.groups.dao.FscDetailsDAO;
import com.ipru.ws.groups.dao.GroupsDAO;

public class GroupsServiceImpl implements GroupsService {
	private static final Logger LOGGER = LogManager.getLogger(GroupsServiceImpl.class);
	private GroupsDAO groupsDAO;
	private UserDetailService userDetailService;
	private PolicyDetailService policyDetailService;
	
	private FscDetailsDAO  fscDetailsDAO;

	public UserDetailService getUserDetailService() {
		return userDetailService;
	}

	public void setUserDetailService(UserDetailService userDetailService) {
		this.userDetailService = userDetailService;
	}

	public FscDetailsDAO getFscDetailsDAO() {
		return fscDetailsDAO;
	}

	public void setFscDetailsDAO(FscDetailsDAO fscDetailsDAO) {
		this.fscDetailsDAO = fscDetailsDAO;
	}

	public PolicyDetailService getPolicyDetailService() {
		return policyDetailService;
	}

	public void setPolicyDetailService(PolicyDetailService policyDetailService) {
		this.policyDetailService = policyDetailService;
	}

	public GroupsDAO getGroupsDAO() {
		return groupsDAO;
	}

	public void setGroupsDAO(GroupsDAO groupsDAO) {
		this.groupsDAO = groupsDAO;
	}
	
	

	@Override
	public void test() {

	}

	@Override
	public List<DropDownTO> getDropDownList(DropDownRequest dropDownRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException {

		// FLogger.info("GroupWebServiceLogger", "GroupsServiceImpl",
		// "getDropDownList", "getDropDownList Method try");

		LOGGER.info("getDropDownList method Called");
		if (dropDownRequest != null) {

			List<DropDownTO> dropDownList = groupsDAO.getDropDownList(dropDownRequest);
			return dropDownList;
		}
		else {

			LOGGER.error("found null dropDownRequest");
			throw new BadDataException("Found null request body");

		}
	}

	@Override
	public <T> List<T> getPrePopulate(PrePopulateBean prePopulateBean) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException {
		// TODO Auto-generated method stub

		LOGGER.info("getPrePopulate method Called");
		if (prePopulateBean != null) {
			List<T> dropDownList = groupsDAO.getPrePopulate(prePopulateBean);
			return dropDownList;
		}
		else {
			LOGGER.error("found null prePopulateBean");
			throw new BadDataException("Found null request");
		}
	}

	@Override
	public List<SwitchTo> getSwitchDataList(SwitchToRequest switchToRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException {
		// TODO Auto-generated method stub
		LOGGER.info("getSwitchDataList method Called");
		if (switchToRequest != null) {

			List<SwitchTo> switchTo = groupsDAO.getSwitchDataList(switchToRequest);
			return switchTo;
		}
		else {
			LOGGER.error("found null switchToRequest");
			throw new BadDataException("Found null request body");
		}
	}

	@Override
	public List<LatestNavTO> getSwitchFundDataList(SwitchToRequest switchToRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException {
		// TODO Auto-generated method stub
		LOGGER.info("getSwitchFundDataList method Called");
		if (switchToRequest != null) {

			List<LatestNavTO> fundToList = groupsDAO.getSwitchFundDataList(switchToRequest);
			return fundToList;
		}
		else {

			LOGGER.error("found null switchToRequest");

			throw new BadDataException("Found null request body");
		}
	}
	
	@Override
	public CountTO getPrePopulateCount(PrePopulateBean prePopulateBean) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException {
		LOGGER.info("getPrePopulate method Called");
		CountTO countTO =new CountTO();
		if (prePopulateBean != null) {
			countTO = groupsDAO.getPrePopulateCount(prePopulateBean);
			return countTO;
		}
		else {
			LOGGER.error("found null prePopulateBean");
			throw new BadDataException("Found null request");
		}
	}
	
	@Override
	public  GroupUser getUserDetails(GroupUser groupUser) throws ApplicationException, DatabaseException, BadDataException, NoDataFoundException {

		LOGGER.info("getUserDetails method Called");
		 if(groupUser!=null)
		 {
			
			List<UserDetailsVO> userDetailsList =userDetailService.getUserDetailsService(groupUser);
			
			if(userDetailsList != null ){
				
				UserDetailsVO userDetailVo = userDetailsList.get(0);
				groupUser.setWebClientId(userDetailVo.getWebClientId());
				
				List<GroupPolicyDetail> policyDetails =policyDetailService.getPolicyDetails(userDetailsList);
				
				groupUser.setPolicyDetailList(policyDetails);
			}
			else
			{
				//TODO: Log and create new Exception class NoDataFoundException and return HttpStatusCode 204
				LOGGER.error("userDetailsList is null");
				throw new NoDataFoundException("No data found for given request");
			}
			return groupUser;
		}
		else {
			LOGGER.error("Found null request");
			throw new BadDataException("Found null request");
		}
	}

	@Override
	public FscDetailsVO getFscDetails(FscDetailsVO fscdetails)
			throws ApplicationException, DatabaseException, BadDataException,
			NoDataFoundException {
		
		
       LOGGER.info("getFscDetails method Called");
		
		List<FscDetailsVO> fscdetailsList = null;
		FscDetailsVO fscDetailsVO = new FscDetailsVO();
		String fsc_clientId = "";
		
		
	
		if (fscdetails != null) {
			fsc_clientId = fscdetails.getFsc_client_id();
			fscdetailsList = fscDetailsDAO.getFscDetailsDao(fsc_clientId );
			
			
		} else {
			LOGGER.error("Found null request data");
			
			throw new BadDataException("Found null request data");
		}
		
		if(fscdetailsList!=null && fscdetailsList.size()>0){
			fscDetailsVO =fscdetailsList.get(0);
		}
		
			
			return  fscDetailsVO;
		
	}


}
