package com.ipru.ws.exception;

public class SystemException2 extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private String errorCode = null;

	/**
	 * Default constructor
	 */
	private SystemException2() {
		super();
	}

	/**
	 * Param Constructor
	 * 
	 * @param cause
	 */
	private SystemException2(Throwable cause) {
		super(cause.getMessage(), cause);
	}

	/**
	 * Param Constructor
	 * 
	 * @param message
	 * @param cause
	 */
	private SystemException2(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Param Constructor
	 * 
	 * @param errorCode
	 * @param message
	 */
	private SystemException2(String errorCode, String message) {
		super(message);
		setErrorCode(errorCode);
	}

	/**
	 * Param Constructor
	 * 
	 * @param errorCode
	 * @param message
	 * @param cause
	 */
	private SystemException2(String errorCode, String message, Throwable cause) {
		super(message, cause);
		setErrorCode(errorCode);
	}

	/**
	 * @param <E>
	 * @param exceptionCode
	 * @param messageArr
	 * @return
	 */

	public static SystemException2 create(String msg, Throwable cause) {
		return new SystemException2(msg, cause);
	}

	/**
	 * @return
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
