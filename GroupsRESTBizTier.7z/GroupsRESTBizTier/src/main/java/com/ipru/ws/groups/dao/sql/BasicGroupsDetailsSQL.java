//@formatter:off
package com.ipru.ws.groups.dao.sql;

public class BasicGroupsDetailsSQL {

	final String SELECT_CLAUSE = new StringBuilder(" SELECT chdrnum AS contractNumber ").toString();
	
	final String FROM_CLAUSE	= " FROM chdrlnb ";
	
	final String FILTER_BY_CONTRACT_WHERE_CLAUSE= " WHERE chdrnum = ? ";
	
	final String JOIN_CLAUSE="";
	
	final String BASIC_CONTRACT_DETAILS_FILTER_BY_CONTRACT_SQL=  new StringBuilder(" SELECT CONTRACTMASTER.chdrnum AS contractNumber, ")
																			 	  .append(" CONTRACTMASTER.agntnum AS agentId, ")
																			 	  .append(" CONTRACTMASTER.cownnum AS clientId, ")
																			 	  .append(" ADWCLIENTDIARY.application_no AS appNumber ")
																			 	  .append(" FROM chdrlnb CONTRACTMASTER ")
																			 	  .append(" LEFT OUTER JOIN adw_client_diary ADWCLIENTDIARY ON ADWCLIENTDIARY.POLICY_NO=CONTRACTMASTER.chdrnum ")
																			 	  .append(" WHERE CONTRACTMASTER.chdrnum=:contractNumber ")
																			 	  .append(" AND CONTRACTMASTER.validflag='1' ").toString();
	
	final String CLAIM_RELATION = "SELECT r.BENIFICIARYRELATIONCODE as key,r.DESCRIPTION as value FROM TERMPLAN_BEN_RELATION r";
	
	final String NOMINEE_RELATION = "SELECT r.relation as key,r.relation as value FROM GROUP_RELATION_MASTER r";	
}
