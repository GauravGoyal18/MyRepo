package com.ipru.ws.groups.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.ipru.groups.to.CountTO;
import com.ipru.groups.to.DropDownTO;
import com.ipru.groups.to.LatestNavTO;
import com.ipru.groups.to.SwitchTo;
import com.ipru.ws.dao.base.BaseDAO;
import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.ResourceNotFoundException;
import com.ipru.ws.groups.beans.DropDownRequest;
import com.ipru.ws.groups.beans.PrePopulateBean;
import com.ipru.ws.groups.beans.SwitchToRequest;
import com.ipru.ws.groups.properties.PropertyLoaderServiceImpl;
import com.ipru.ws.groups.service.GroupsServiceImpl;

public class GroupsDAOImpl extends BaseDAO implements GroupsDAO {

	private static final Logger LOGGER = LogManager.getLogger(GroupsServiceImpl.class);
	private static final String String = null;
	private static final Long Long = null;
	@Autowired
	private PropertyLoaderServiceImpl propertyLoaderService;
	@Autowired
	private ApplicationContext applicationContext;

	Properties prop = new Properties();

	@Override
	public List<DropDownTO> getDropDownList(DropDownRequest dropDownRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException {
		List<DropDownTO> dropDownList = new ArrayList<DropDownTO>();
		// try {

		LOGGER.info("getDropDownList of Dao method Called");
		prop = propertyLoaderService.CONSTANT_DROPDOWN_PROPERTIES;

		if (dropDownRequest != null) {

			if (prop != null) {

				String sqlQuerry = prop.getProperty(dropDownRequest.getFunctionality() + "&" + dropDownRequest.getDropDownType());
				if (sqlQuerry == null) {
					LOGGER.error("Please Enter valid data");
					throw new BadDataException("101", "Please Enter valid data");
				}
				Object[] objectArr = null;
				if (dropDownRequest.getParamObj() != null) {

					if (dropDownRequest.getParamObj().getParam() != null) {
						if (dropDownRequest.getParamObj().getParam().size() > 0) {
							objectArr = new Object[dropDownRequest.getParamObj().getParam().size()];
							for (int i = 0; i < dropDownRequest.getParamObj().getParam().size(); i++) {
								String paramObj = dropDownRequest.getParamObj().getParam().get(i);
								objectArr[i] = paramObj;

								LOGGER.info("sqlQuerry" + sqlQuerry + " , " + objectArr.toString());

							}
						}
						else {

							LOGGER.error("found null list");
							throw new BadDataException("101", "Found null list");
						}
					}
					else {

						LOGGER.error("found null param");
						throw new BadDataException("101", "Found null param");
					}

					LOGGER.info("Found Parameters");
					dropDownList = getParameterizedDomainObjectsList(sqlQuerry, objectArr, DropDownTO.class);
				}
				else {
					LOGGER.info("parameters");
					dropDownList = getParameterizedDomainObjectsList(sqlQuerry, null, DropDownTO.class);
				}
			}
			else {
				LOGGER.error("Error occure while loading property file");
				throw new ApplicationException("100", "Error occure while loading property file");
			}
		}
		else {

			LOGGER.error("found null dropDownRequest");
			throw new BadDataException("101", "found null dropDownRequest");

		}

		/*
		 * } catch (Exception e) { LOGGER.error("Exception occured",e); throw e;
		 * }
		 */

		if (dropDownList != null && dropDownList.size() > 0) {
			return dropDownList;
		}
		else {
			LOGGER.error("Found null data from databse");
			throw new ResourceNotFoundException("103", "Found null data from database");
		}

	}

	public PropertyLoaderServiceImpl getPropertyLoaderService() {
		return propertyLoaderService;
	}

	public void setPropertyLoaderService(PropertyLoaderServiceImpl propertyLoaderService) {
		this.propertyLoaderService = propertyLoaderService;
	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	public Properties propertyFileLoader(String fileName) throws Exception {
		Properties prop = new Properties();
		try {
			prop.load(this.getClass().getResourceAsStream(fileName));
		}
		catch (Exception e) {

			throw e;
		}
		return prop;
	}

	@Override
	public <T> List<T> getPrePopulate(PrePopulateBean prePopulateBean) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException {
		// TODO Auto-generated method stub

		LOGGER.info("getPrePopulate of Dao method Called");
		List<T> prePopulateList = new ArrayList<T>();
		// try {
		if (prePopulateBean != null) {
			// String className=prePopulateBean.getClassName();
			String functionality = prePopulateBean.getFunctionality();
			if (functionality != null && !functionality.equalsIgnoreCase("")) {
				Class<?> classInst = null;
				// try {
				// classInst = Class.forName("com.ipru.groups.vo."+className);
				classInst = (Class<T>) applicationContext.getBean(functionality).getClass();
				/*
				 * } catch (ClassNotFoundException e) { // TODO Auto-generated
				 * catch block throw new
				 * ApplicationException("100",e.getMessage()); }
				 */
				if (classInst != null) {

					LOGGER.info("Found insatnce of " + functionality);
					prop = propertyLoaderService.CONSTANT_PREPOPULATE_PROPERTIES;

					if (prop != null) {

						String sqlQuerry = prop.getProperty(functionality);
						System.out.println("sqlQuery" + sqlQuerry);
						if (sqlQuerry != null) {
							// ////System.out.println("sqlQuery" + sqlQuerry);
							Object[] objectArr = null;

							if (prePopulateBean.getParamObj() != null) {

								if (prePopulateBean.getParamObj().getParam() != null) {

									if (prePopulateBean.getParamObj().getParam().size() > 0) {
										objectArr = new Object[prePopulateBean.getParamObj().getParam().size()];
										for (int i = 0; i < prePopulateBean.getParamObj().getParam().size(); i++) {
											System.out.println(prePopulateBean.getParamObj().getParam().get(i));
											objectArr[i] = prePopulateBean.getParamObj().getParam().get(i);
										}
										if (prePopulateBean.getMax() != null && prePopulateBean.getMax() != 0)
											prePopulateList = getParameterizedDomainObjsListWithMaxResult(sqlQuerry, objectArr, (Class<T>) classInst, prePopulateBean.getMax());
										else
											prePopulateList = getParameterizedDomainObjectsList(sqlQuerry, objectArr, (Class<T>) classInst);
										// FLogger.info("GroupWebServiceLogger",
										// "GroupsDAOImpl", "getPrePopulate",
										// "end method getPrePopulate");
										LOGGER.info("getPrePopulate method end");
										if (prePopulateList == null || prePopulateList.size() <= 0) {
											throw new ResourceNotFoundException("103", "Found null data from database");
										}

										return prePopulateList;

									}
									else {

										LOGGER.error("Found null data");
										// throw new
										// ApplicationException("Found null data");
										throw new BadDataException("101", "Found null request");
									}

								}
								else if (prePopulateBean.getParamObj().getParamMap() != null) {

									if (prePopulateBean.getParamObj().getParamMap().size() > 0) {
										
										prePopulateList = getDomainObjsList(sqlQuerry, prePopulateBean.getParamObj().getParamMap(), (Class<T>) classInst);
										
										LOGGER.info("getPrePopulate method end");
									}
									else{
										if(prePopulateList == null || prePopulateList.size() <= 0) {
										throw new ResourceNotFoundException("103", "Found null data from database");
									}
									}

									return prePopulateList;
								}
									
								else {
									prePopulateList = getParameterizedDomainObjectsList(sqlQuerry, null, (Class<T>) classInst);
									if (prePopulateList == null || prePopulateList.size() <= 0) {
										throw new ResourceNotFoundException("103", "Found null data from database");
									}
									return prePopulateList;
								}

							}
							else {
								prePopulateList = getParameterizedDomainObjectsList(sqlQuerry, null, (Class<T>) classInst);
								if (prePopulateList == null || prePopulateList.size() <= 0) {
									throw new ResourceNotFoundException("103", "Found null data from database");
								}
								return prePopulateList;
							}

						}

						else {

							LOGGER.error("Error occure while reading property file. Found null sql query.");
							// throw new
							// ApplicationException("Error occure while reading property file. Found null sql query.");
							throw new BadDataException("101", "Please Enter valid functionality");
						}
					}
					else {

						LOGGER.error("Error occure while reading property file. Found null sql query.");
						throw new ApplicationException("100", "Some Error occured.");
					}

				}
				else {

					LOGGER.error("found null class instance.");
					throw new ApplicationException("100", "found null class instance.");
				}
			}
			else {

				LOGGER.error("found null className or functionality name.");
				throw new BadDataException("101", "Please Enter valid functionality");
			}

		}
		else {

			LOGGER.error("found null prePopulateBean");
			throw new BadDataException("101", "Found null data");
		}

		/*
		 * } catch (Exception e) { //FLogger.error("GroupWebServiceErrorLogger",
		 * "GroupsDAOImpl", "getPrePopulate", "Exception ",e);
		 * LOGGER.error("Exception occured ",e); throw e; }
		 */

	}

	@Override
	public List<SwitchTo> getSwitchDataList(SwitchToRequest switchToRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException {
		// TODO Auto-generated method stub
		List<SwitchTo> switchList = new ArrayList<SwitchTo>();
		List<SwitchTo> switchList1 = new ArrayList<SwitchTo>();
		List<SwitchTo> switchListResult = new ArrayList<SwitchTo>();
		// try {

		LOGGER.info("getSwitchDataList of Dao method Called");
		prop = propertyLoaderService.CONSTANT_PREPOPULATE_PROPERTIES;
		String sqlQuerry = null;
		if (switchToRequest != null) {

			if (prop != null) {

				String dateQuery = prop.getProperty("dateQuery");
				LOGGER.info("getSwitchDataList of Dao dateQuery " + dateQuery);
				if (dateQuery != null && !dateQuery.equalsIgnoreCase("")) {

					StringBuilder builder = new StringBuilder(dateQuery);
					builder.append("(");
					Object[] objectArr = null;
					if (switchToRequest.getParamObj() == null) {
						throw new BadDataException("101", "Invalid parameters");
					}
					if (switchToRequest.getParamObj().getParam().size() > 0) {
						objectArr = new Object[switchToRequest.getParamObj().getParam().size()];
						if (switchToRequest.getParamObj().getParam().size() == 1) {
							sqlQuerry = prop.getProperty("switchRequest");
							LOGGER.info("getSwitchDataList of Dao sqlQuerry " + sqlQuerry);

						}
						else if (switchToRequest.getParamObj().getParam().size() == 2) {

							sqlQuerry = prop.getProperty("switchRequestMember");
							LOGGER.info("getSwitchDataList of Dao sqlQuerry " + sqlQuerry);
						}
						else {

							LOGGER.error("Invalid parameters");
							throw new BadDataException("101", "Invalid parameters");
							// throw new
							// ApplicationException("Invalid parameters");

						}

						for (int i = 0; i < switchToRequest.getParamObj().getParam().size(); i++) {

							objectArr[i] = switchToRequest.getParamObj().getParam().get(i);
						}

						if (objectArr.length > 0) {
							switchList = getParameterizedDomainObjectsList(sqlQuerry, objectArr, SwitchTo.class);
							if (switchList == null) {
								throw new ResourceNotFoundException("103", "Found null data from databse");
							}
							Object[] objectArr2 = new Object[switchList.size()];

							String param = "(";
							HashMap<String, SwitchTo> hashMap = new HashMap<String, SwitchTo>();
							for (int i = 0; i < switchList.size(); i++) {
								SwitchTo to = switchList.get(i);

								if (to != null) {
									hashMap.put(to.getFundcode(), to);
								}
								else {
									LOGGER.error("Null result found");
									throw new ResourceNotFoundException("103", "Found null data from databse");
								}

								if (i != (switchList.size() - 1)) {

									builder.append("?,");

								}
								else {
									builder.append("?");
								}
								objectArr2[i] = to.getFundcode();

							}

							builder.append("))");

							LOGGER.info("getSwitchDataList of Dao sqlQuerry1 " + builder.toString());
							switchList1 = getParameterizedDomainObjectsList(builder.toString(), objectArr2, SwitchTo.class);

							if (switchList1 != null) {
								for (int i = 0; i < switchList1.size(); i++) {
									SwitchTo to = switchList1.get(i);
									SwitchTo to1 = hashMap.get(to.getFundcode());
									if (to1 != null && to != null) {
										to1.setNavValue(to.getNavValue());
										BigDecimal nav = new BigDecimal(to.getNavValue());
										BigDecimal units = new BigDecimal(to1.getUnits());
										to1.setTotalAmount(nav.multiply(units));
										switchListResult.add(to1);
									}
									else {
										LOGGER.error("Found null data");
										throw new BadDataException("101", "Found null parameters");
									}

								}

								if (switchListResult == null || switchListResult.size() <= 0) {
									throw new ResourceNotFoundException("103", "Found null data from databse");
								}
								return switchListResult;
							}
							else {
								LOGGER.error("Found null data switchList1");
								throw new BadDataException("101", "Found null parameters");
							}

						}
						else {
							LOGGER.error("Null parameters found");
							throw new BadDataException("101", "Found null parameters");
						}

					}
					else {

						LOGGER.error("Null parameters found");
						throw new BadDataException("101", "Found null parameters");

					}

				}
				else {
					LOGGER.error("Error while reading data from property file");
					throw new ApplicationException("100", "Error while reading data from property file");
				}

			}
			else {

				LOGGER.error("Error while load property file");
				throw new ApplicationException("100", "Error while load property file");

			}

		}
		else {

			LOGGER.error("Null request found");
			throw new BadDataException("101", "Null request found");
			// throw new ApplicationException("Null request found");
		}

		/*
		 * } catch (Exception e) { LOGGER.error("Exception e",e); throw e; }
		 */

	}

	@Override
	public List<LatestNavTO> getSwitchFundDataList(SwitchToRequest switchToRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException {
		Properties prop = new Properties();

		List<LatestNavTO> fundDetailsLits = new ArrayList<LatestNavTO>();
		// try {

		LOGGER.info("getDropDownList  of Dao method start");
		int count = 0;
		prop = propertyLoaderService.CONSTANT_PREPOPULATE_PROPERTIES;

		if (switchToRequest != null) {

			if (prop != null) {
				String sqlQuerry = null;// fundDetailsQueryForClient
				StringBuilder builder = null;
				Object[] objectArr = null;
				int size = 0;

				// size=switchToRequest.getParamObj().getParam().size()+switchToRequest.getFundCodes().size();
				if (switchToRequest.getParamObj() != null) {

					if (switchToRequest.getParamObj().getParam() != null) {
						if (switchToRequest.getParamObj().getParam().size() > 0) {

							if (switchToRequest.getParamObj().getParam().size() == 1)// from
																						// constant
							{

								sqlQuerry = prop.getProperty("fundDetailsQuery");
								LOGGER.info("getDropDownList  of Dao sqlQuerry " + sqlQuerry);
							}
							else if (switchToRequest.getParamObj().getParam().size() == 2)// from
																							// constant
							{
								sqlQuerry = prop.getProperty("fundDetailsQueryForClient");
								LOGGER.info("getDropDownList  of Dao sqlQuerry " + sqlQuerry);
							}
							else {
								LOGGER.error("found wrong number of param");
								// throw new
								// ApplicationException("Wrong number of parameters");
								throw new BadDataException("101", "Wrong number of parameters");
							}

							if (switchToRequest.getFundCodes() == null) {
								throw new BadDataException("101", "Wrong number of parameters");
							}
							if (switchToRequest.getFundCodes().size() <= 0) {
								throw new BadDataException("101", "Wrong number of parameters");
							}

							size = switchToRequest.getParamObj().getParam().size() + switchToRequest.getFundCodes().size();
							objectArr = new Object[size];
							builder = new StringBuilder(sqlQuerry);
							builder.append("(");
							for (int i = 0; i < switchToRequest.getParamObj().getParam().size(); i++) {

								String paramObj = switchToRequest.getParamObj().getParam().get(i);
								objectArr[i] = paramObj;
								count = i;

							}

							for (int i = 0; i < switchToRequest.getFundCodes().size(); i++) {

								if (i != (switchToRequest.getFundCodes().size() - 1)) {

									builder.append("?,");

								}
								else {

									builder.append("?");
								}

							}

							for (String fundCode : switchToRequest.getFundCodes()) {

								objectArr[count + 1] = fundCode;
								count++;
							}

							builder.append(") ");
							sqlQuerry = prop.getProperty("fundDetailsQuery2");
							builder.append(sqlQuerry);

						}

					}
					else {

						LOGGER.error("found null param");
						// throw new ApplicationException("Found null param");
						throw new BadDataException("101", "Found null param");

					}

					LOGGER.info("getDropDownList  of Dao builder " + builder.toString());
					fundDetailsLits = getParameterizedDomainObjectsList(builder.toString(), objectArr, LatestNavTO.class);

				}
				else {

					LOGGER.error("found null param");
					throw new BadDataException("101", "Found null param");
				}
			}
			else {

				LOGGER.error("Error occure while loading property file");
				throw new ApplicationException("100", "Error occure while loading property file");
			}
		}
		else {

			LOGGER.error("Found null switchToRequest");
			throw new BadDataException("101", "Found null request data");

		}

		/*
		 * }catch (Exception e) { LOGGER.error("Exception occured"); throw e; }
		 */
		if (fundDetailsLits == null || fundDetailsLits.size() <= 0) {
			throw new ResourceNotFoundException("103", "Found null data from databse");
		}
		return fundDetailsLits;
	}

	@Override
	public CountTO getPrePopulateCount(PrePopulateBean prePopulateBean) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException {
		LOGGER.info("getPrePopulate of Dao method Called");
		CountTO countTO = new CountTO();
		// try {
		if (prePopulateBean != null) {
			// String className=prePopulateBean.getClassName();
			String functionality = prePopulateBean.getFunctionality();
			if (functionality != null && !functionality.equalsIgnoreCase("")) {

				LOGGER.info("Found insatnce of " + functionality);
				prop = propertyLoaderService.CONSTANT_PREPOPULATE_PROPERTIES;

				if (prop != null) {

					String sqlQuerry = prop.getProperty(functionality);
					// ////System.out.println("sqlQuery" + sqlQuerry);
					if (sqlQuerry != null) {
						// ////System.out.println("sqlQuery" + sqlQuerry);
						Object[] objectArr = null;
						if (prePopulateBean.getParamObj() != null) {

							if (prePopulateBean.getParamObj().getParam() != null) {

								if (prePopulateBean.getParamObj().getParam().size() > 0) {
									objectArr = new Object[prePopulateBean.getParamObj().getParam().size()];
									for (int i = 0; i < prePopulateBean.getParamObj().getParam().size(); i++) {
										// ////System.out.println("dfnffgjnfgfgfgfg "+prePopulateBean.getParamObj().getParam().get(i));
										objectArr[i] = prePopulateBean.getParamObj().getParam().get(i);
									}
									// ////System.out.println(" max max max max max "+prePopulateBean.getMax());

									Long count = getCount(sqlQuerry, objectArr);

									LOGGER.info("getPrePopulate method end");
									countTO.setCount(count);

									return countTO;

								}
								else {

									LOGGER.error("Found null data");
									// throw new
									// ApplicationException("Found null data");
									throw new BadDataException("101", "Found null request");
								}

							}
							else {
								LOGGER.error("Found null data");
								throw new BadDataException("101", "Found null request");
							}

						}
						else {
							Long count = getCount(sqlQuerry, null);
							countTO.setCount(count);

							return countTO;
						}

					}

					else {

						LOGGER.error("Error occure while reading property file. Found null sql query.");
						// throw new
						// ApplicationException("Error occure while reading property file. Found null sql query.");
						throw new BadDataException("101", "Please Enter valid functionality");
					}
				}
				else {

					LOGGER.error("Error occure while reading property file. Found null sql query.");
					throw new ApplicationException("100", "Some Error occured.");
				}

			}
			else {

				LOGGER.error("found null className or functionality name.");
				throw new BadDataException("101", "Please Enter valid functionality");
			}

		}
		else {

			LOGGER.error("found null prePopulateBean");
			throw new BadDataException("101", "Found null data");
		}

		/*
		 * } catch (Exception e) { //FLogger.error("GroupWebServiceErrorLogger",
		 * "GroupsDAOImpl", "getPrePopulate", "Exception ",e);
		 * LOGGER.error("Exception occured ",e); throw e; }
		 */
	}

	
}
