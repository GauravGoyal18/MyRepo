package com.ipru.ws.groups.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.ipru.ws.dao.base.BaseDAO;
import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.NoDataFoundException;
import com.ipru.ws.groups.beans.GroupPolicyDetail;
import com.ipru.ws.groups.beans.UserDetailsVO;
import com.ipru.ws.groups.properties.PropertyLoaderServiceImpl;

public class PolicyDetailDAOImpl extends BaseDAO implements PolicyDetailsDAO {

	private static final Logger LOGGER = LogManager.getLogger(PolicyDetailDAOImpl.class);
	@Autowired
	private PropertyLoaderServiceImpl propertyLoaderService;
	public List<GroupPolicyDetail> getpolicyDetailsDAO(List<UserDetailsVO> userDetailsList) throws ApplicationException,DatabaseException, BadDataException, NoDataFoundException {
		//TODO: Add Loggers
		LOGGER.info("getpolicyDetailsDAO method Called");
			List<GroupPolicyDetail> policyDetailList = null;
			List<String> clientList = null;
			String policydetails=null;
			
			if(userDetailsList == null || CollectionUtils.isEmpty(userDetailsList)) {
				LOGGER.error("Found null data from userDetailsList");
				throw new NoDataFoundException("No data found in userDetailsList");
			}

			for (UserDetailsVO userDetailsVO : userDetailsList) {
					if(userDetailsVO != null && StringUtils.isNotBlank(userDetailsVO.getClientId())) {
						if(clientList == null) {
							clientList = new ArrayList<String>(1);
						}
						clientList.add(userDetailsVO.getClientId());
					}
			}
			
			if(clientList == null || CollectionUtils.isEmpty(clientList)) {
				LOGGER.error("No client Ids found in UserDetails");
				throw new ApplicationException("No client Ids found in UserDetails");
			}

			Map<String, Object> params = new HashMap<String, Object>(0);
			params.put("clientList", clientList);
			//TODO: Get sql from Property File

			
			Properties prop = new Properties();
			prop = propertyLoaderService.CONSTANT_PREPOPULATE_PROPERTIES;
			
			if (prop != null) {
				
					policydetails = prop.getProperty("policydetails");
			}
			else {
				LOGGER.error("Error occure while loading property file");
				throw new ApplicationException("100", "Error occure while loading property file");
			}
			
			policyDetailList = getDomainObjsList(policydetails, params, GroupPolicyDetail.class);
			 if(policyDetailList==null || CollectionUtils.isEmpty(policyDetailList))
			 {
				 throw new NoDataFoundException("No data found in policyDetailList"); 
			 }
			return policyDetailList;

	}
}
