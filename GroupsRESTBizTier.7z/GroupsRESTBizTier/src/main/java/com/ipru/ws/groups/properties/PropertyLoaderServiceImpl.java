package com.ipru.ws.groups.properties;

import java.util.Properties;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

public class PropertyLoaderServiceImpl {
	@Autowired
	private ApplicationContext applicationContext;
	public Properties CONSTANT_AUTHENTICATION_PROPERTIES;
	public Properties CONSTANT_PREPOPULATE_PROPERTIES;
	public Properties CONSTANT_DROPDOWN_PROPERTIES;
	public Properties CONSTANT_JAVACLASSLIST_PROPERTIES;

	public Properties propertyFileLoader(String beanName) throws Exception {
		Properties prop = applicationContext.getBean(beanName, Properties.class);
		return prop;
	}

	@PostConstruct
	public void init() {
		//////System.out.println("Loading properties files");
		CONSTANT_AUTHENTICATION_PROPERTIES = applicationContext.getBean(WsCommonConstants.CONSTANT_AUTHENTICATION, Properties.class);
		CONSTANT_PREPOPULATE_PROPERTIES = applicationContext.getBean(WsCommonConstants.CONSTANT_PREPOPULATE, Properties.class);
		CONSTANT_DROPDOWN_PROPERTIES = applicationContext.getBean(WsCommonConstants.CONSTANT_DROPDOWN, Properties.class);
		CONSTANT_JAVACLASSLIST_PROPERTIES = applicationContext.getBean(WsCommonConstants.CONSTANT_JAVACLASSLIST, Properties.class);
	}

}
