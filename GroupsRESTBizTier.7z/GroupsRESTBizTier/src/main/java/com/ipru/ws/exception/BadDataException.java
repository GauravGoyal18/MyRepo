package com.ipru.ws.exception;

// 400
// 101
public class BadDataException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message;
	private String errorCode;

	public BadDataException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BadDataException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public BadDataException(String message) {
		setMessage(message);
		// TODO Auto-generated constructor stub
	}

	public BadDataException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "BadDataException [message=" + message + ", errorCode=" + errorCode + "]";
	}

	public BadDataException(String errorCode, String message) {
		super();
		this.message = message;
		this.errorCode = errorCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
