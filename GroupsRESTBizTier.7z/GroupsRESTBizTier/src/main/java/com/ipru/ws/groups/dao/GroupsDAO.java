package com.ipru.ws.groups.dao;

import java.util.List;

import com.ipru.groups.to.CountTO;
import com.ipru.groups.to.DropDownTO;
import com.ipru.groups.to.LatestNavTO;
import com.ipru.groups.to.SwitchTo;
import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.ResourceNotFoundException;
import com.ipru.ws.groups.beans.DropDownRequest;
import com.ipru.ws.groups.beans.GroupUser;
import com.ipru.ws.groups.beans.PrePopulateBean;
import com.ipru.ws.groups.beans.ProductCodeBean;
import com.ipru.ws.groups.beans.SwitchToRequest;

public interface GroupsDAO {

	List<DropDownTO> getDropDownList(DropDownRequest dropDownRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException;

	<T> List<T> getPrePopulate(PrePopulateBean prePopulateBean) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException;

	List<SwitchTo> getSwitchDataList(SwitchToRequest switchToRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException;

	List<LatestNavTO> getSwitchFundDataList(SwitchToRequest switchToRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException;
	
	<T> CountTO getPrePopulateCount(PrePopulateBean prePopulateBean) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException;

}
