package com.ipru.ws.groups.dao;

import java.util.List;

import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.NoDataFoundException;

public interface FscDetailsDAO {

	List<FscDetailsVO> getFscDetailsDao(String fsc_clientId) throws ApplicationException, DatabaseException, BadDataException, NoDataFoundException;

}
