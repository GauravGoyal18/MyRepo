package com.ipru.ws.exception;

// 500
// 102
public class DatabaseException extends Exception {
	private String message;
	private String errorCode;

	public DatabaseException(String errorCode, String message) {
		super();
		this.message = message;
		this.errorCode = errorCode;
	}

	public DatabaseException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DatabaseException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DatabaseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DatabaseException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "DatabaseException [message=" + message + ", errorCode=" + errorCode + "]";
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/*
	 * public static DatabaseException create(String msg, Throwable cause) {
	 * return new DatabaseException(msg, cause); }
	 */
}
