package com.ipru.ws.groups.properties;

import java.util.Properties;

public interface PropertyLoaderService {
	public Properties propertyFileLoader(String beanName) throws Exception;
}
