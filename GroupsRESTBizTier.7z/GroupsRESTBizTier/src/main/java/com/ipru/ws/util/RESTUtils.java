package com.ipru.ws.util;

public final class RESTUtils {

	private static RESTUtils utility = null;

	private RESTUtils() {

	}

	public static final RESTUtils getInstance() {
		if (utility == null) {
			utility = new RESTUtils();
		}
		return utility;
	}

	public void handleRESTException(Exception e) {

	}
}
