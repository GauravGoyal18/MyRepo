package com.ipru.ws.groups.service;

import java.util.List;

import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.NoDataFoundException;
import com.ipru.ws.exception.ResourceNotFoundException;
import com.ipru.ws.groups.beans.GroupUser;
import com.ipru.ws.groups.beans.UserDetailsVO;

public interface UserDetailService {

	public List<UserDetailsVO> getUserDetailsService(GroupUser groupUser) throws ApplicationException, DatabaseException, BadDataException,NoDataFoundException;
}
