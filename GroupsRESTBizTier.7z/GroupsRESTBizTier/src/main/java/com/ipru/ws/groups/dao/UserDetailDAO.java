package com.ipru.ws.groups.dao;

import java.util.List;

import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.NoDataFoundException;
import com.ipru.ws.exception.ResourceNotFoundException;
import com.ipru.ws.groups.beans.UserDetailsVO;

public interface UserDetailDAO {

	public List<UserDetailsVO> getUserDetailsDao(String emailId, String mobileNo) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException, NoDataFoundException;

}
