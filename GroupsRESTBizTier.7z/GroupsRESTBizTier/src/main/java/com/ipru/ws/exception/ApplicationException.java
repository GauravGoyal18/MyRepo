package com.ipru.ws.exception;

import com.ipru.ws.beans.base.ErrorTO;
// 500
// 100

public class ApplicationException extends Exception {
	private static final long serialVersionUID = 1L;
	private String message;
	private String errorCode;

	public ApplicationException() {
		super();
	}

	public ApplicationException(String msg) {
		super(msg);
		setMessage(msg);
	}

	public ApplicationException(Throwable cause) {
		super(cause.getMessage(), cause);

	}

	public ApplicationException(String errorCode, String message) {
		this.errorCode = errorCode;
		this.message = message;
	}

	/**
	 * Param Constructor
	 * 
	 * @param msg
	 * @param cause
	 */
	public ApplicationException(String msg, final Throwable cause) {
		super(msg, cause);
		setMessage(msg);
	}

	/**
	 * @return
	 */
	@Override
	public String getMessage() {
		return this.message;
	}

	/**
	 * @param message
	 */
	public void setMessage(final String message) {
		this.message = message;
	}

	public synchronized String getErrorCode() {
		return errorCode;
	}

	public synchronized void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
