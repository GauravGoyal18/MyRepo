package com.ipru.ws.groups.service;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.NoDataFoundException;
import com.ipru.ws.groups.beans.GroupPolicyDetail;
import com.ipru.ws.groups.beans.UserDetailsVO;
import com.ipru.ws.groups.dao.PolicyDetailDAOImpl;

public class PolicyDetailServiceImpl implements PolicyDetailService {
	private static final Logger LOGGER = LogManager
			.getLogger(PolicyDetailServiceImpl.class);

	private PolicyDetailDAOImpl policyDetailDAO;

	public PolicyDetailDAOImpl getPolicyDetailDAO() {
		return policyDetailDAO;
	}

	public void setPolicyDetailDAO(PolicyDetailDAOImpl policyDetailDAO) {
		this.policyDetailDAO = policyDetailDAO;
	}

	public List<GroupPolicyDetail> getPolicyDetails(List<UserDetailsVO> UserDetailsList) throws ApplicationException,DatabaseException, BadDataException,NoDataFoundException {
		
		LOGGER.info("getPolicyDetails method Called");
		
		List<GroupPolicyDetail> policyDetailList = null;

		policyDetailList = policyDetailDAO.getpolicyDetailsDAO(UserDetailsList);

		if (policyDetailList != null && CollectionUtils.isNotEmpty(policyDetailList)) {
			
			for (GroupPolicyDetail policyDetails : policyDetailList) {
				if (policyDetails != null) {

			policyDetails.setMiddleName(policyDetails.getMiddleName() != null ? policyDetails.getMiddleName() : "-");
			
			policyDetails.setLastName(policyDetails.getLastName() != null ? policyDetails.getLastName() : "-");
					
			policyDetails.setClientId(policyDetails.getClientId() != null ? policyDetails.getClientId() : "-");
					
			policyDetails.setClientName(policyDetails.getClientName() != null ? policyDetails.getClientName() : "-");
			
			policyDetails.setDateOfJoiningScheme(policyDetails.getDateOfJoiningScheme() != null ? policyDetails.getDateOfJoiningScheme() : "-");
			
			policyDetails.setEmpId(policyDetails.getEmpId() != null ? policyDetails.getEmpId() : "-");
			
			policyDetails.setEmpName(policyDetails.getEmpName() != null ? policyDetails.getEmpName() : "-");
			
			policyDetails.setFund((Double) (policyDetails.getFund() != null ? policyDetails.getFund() : 0));
			
			policyDetails.setPolicyCommencementDate(policyDetails	.getPolicyCommencementDate() != null ? policyDetails.getPolicyCommencementDate() : "-");
			
			policyDetails.setPolicyKey(policyDetails.getPolicyKey() != null ? policyDetails.getPolicyKey() : "-");
			
			policyDetails.setPolicyNo(policyDetails.getPolicyNo() != null ? policyDetails.getPolicyNo() : "-");
			
			policyDetails.setPolicyType(policyDetails.getPolicyType() != null ? policyDetails.getPolicyType() : "-");
			
			policyDetails.setProductCode(policyDetails.getProductCode() != null ? policyDetails.getProductCode() : "-");
			
			policyDetails.setProductName(policyDetails.getProductName() != null ? policyDetails.getProductName() : "-");
			
			policyDetails.setStatusSysKey(policyDetails.getStatusSysKey() != null ? policyDetails.getStatusSysKey() : "-");
			
			policyDetails.setTypeOfScheme(policyDetails.getTypeOfScheme() != null ? policyDetails.getTypeOfScheme() : "-");

				}
			}
		} 
		else {
			LOGGER.error("Found null data in policy details list");
			throw new NoDataFoundException("No policy data found for given request");
		}

		return policyDetailList;
	}
}
