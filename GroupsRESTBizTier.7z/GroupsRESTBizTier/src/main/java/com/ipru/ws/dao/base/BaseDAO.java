package com.ipru.ws.dao.base;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.ipru.ws.beans.base.BaseObject;
import com.ipru.ws.dao.base.mapper.ParameterisedCustomBeanPropertyRowMapper;
import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.DatabaseException;

/**
 * Parent for all DAO beans. Contains spring jdbc utility methods.
 * 
 * @author Ameya Nerurkar
 */
public class BaseDAO {
	// private static final Logger LOGGER = LogManager.getLogger(BaseDAO.class);

	private static final String SEQUENCE_QUERY = "SELECT %S.NEXTVAL FROM DUAL";

	private JdbcTemplate jdbcTemplate1;
	private JdbcTemplate jdbcTemplate2;
	private JdbcTemplate jdbcTemplate3;
	private JdbcTemplate jdbcTemplate4;

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate1;
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate2;
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate3;



	public JdbcTemplate getJdbcTemplate2() {
		return jdbcTemplate2;
	}

	public void setJdbcTemplate2(JdbcTemplate jdbcTemplate2) {
		this.jdbcTemplate2 = jdbcTemplate2;
	}

	public JdbcTemplate getJdbcTemplate1() {
		return jdbcTemplate1;
	}

	public void setJdbcTemplate1(JdbcTemplate jdbcTemplate1) {
		this.jdbcTemplate1 = jdbcTemplate1;
	}
	
	public JdbcTemplate getJdbcTemplate4() {
		return jdbcTemplate4;
	}

	public void setJdbcTemplate4(JdbcTemplate jdbcTemplate4) {
		this.jdbcTemplate4 = jdbcTemplate4;
	}

	public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate1() {
		return namedParameterJdbcTemplate1;
	}

	public void setNamedParameterJdbcTemplate1(NamedParameterJdbcTemplate namedParameterJdbcTemplate1) {
		this.namedParameterJdbcTemplate1 = namedParameterJdbcTemplate1;
	}

	public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate2() {
		return namedParameterJdbcTemplate2;
	}

	public void setNamedParameterJdbcTemplate2(NamedParameterJdbcTemplate namedParameterJdbcTemplate2) {
		this.namedParameterJdbcTemplate2 = namedParameterJdbcTemplate2;
	}
	
	public JdbcTemplate getJdbcTemplate3() {
		return jdbcTemplate3;
	}

	public void setJdbcTemplate3(JdbcTemplate jdbcTemplate3) {
		this.jdbcTemplate3 = jdbcTemplate3;
	}
	
	

	public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate3() {
		return namedParameterJdbcTemplate3;
	}

	public void setNamedParameterJdbcTemplate3(
			NamedParameterJdbcTemplate namedParameterJdbcTemplate3) {
		this.namedParameterJdbcTemplate3 = namedParameterJdbcTemplate3;
	}

	/**
	 * Utility method to Query given SQL to create a prepared statement from SQL
	 * and a list of arguments to bind to the query,reading the ResultSet with a
	 * ResultSetExtractor.
	 * 
	 * @param sql
	 * @param paramMap
	 * @param rse
	 * @return
	 * @throws ApplicationException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Object getDomainObj(String sql, Map<String, Object> paramMap, ResultSetExtractor rse) throws ApplicationException, DatabaseException {
		Object domainObj = null;
		try {
			domainObj = this.namedParameterJdbcTemplate1.query(sql, paramMap, rse);
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.error("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObj;
	}

	@SuppressWarnings("unchecked")
	public <T extends BaseObject> T getDomainObj(String sql, Map<String, Object> paramMap, Class<?> type) throws ApplicationException, DatabaseException {
		T domainObj = null;
		try {
			domainObj = (T) this.namedParameterJdbcTemplate1.queryForObject(sql, paramMap, ParameterisedCustomBeanPropertyRowMapper.newInstance(type));
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.error("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObj;
	}

	/**
	 * Utility method to Query given SQL to get domain object especially a
	 * string value.
	 * 
	 * @param sql
	 * @param paramMap
	 * @param rse
	 * @return
	 * @throws ApplicationException
	 */
	public Object getDomainObj(String sql, Class<?> requiredType) throws ApplicationException, DatabaseException {
		Object domainObj = null;
		try {
			domainObj = this.jdbcTemplate1.queryForObject(sql, requiredType);
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.error("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObj;
	}

	/**
	 * Utility method to Query given SQL to get domain object especially a Map.
	 * 
	 * @param sql
	 * @param paramMap
	 * @param rse
	 * @return
	 * @throws ApplicationException
	 */
	public Map<String, Object> getResultSetMap(String sql, Map<String, Object> paramMap) throws ApplicationException, DatabaseException {
		Map<String, Object> domainObj = null;
		try {
			domainObj = this.namedParameterJdbcTemplate1.queryForMap(sql, paramMap);
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.error("No result returned for query. ");
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObj;
	}

	/**
	 * Utility method to get sequence value when Oracle Sequence Name is passed
	 * as a parameter
	 * 
	 * @param squenceName
	 * @return
	 * @throws ApplicationException
	 */
	public Long getSequenceValue(String squenceName) throws ApplicationException, DatabaseException {
		return getSeqId(String.format(SEQUENCE_QUERY, squenceName), null);
	}

	/**
	 * Fetches the details and constructs a List of the passed Domain
	 * Customized(Contains Inner Object) object.
	 * 
	 * @param sql
	 * @param objectMap
	 * @param type
	 * @return
	 * @throws ApplicationException
	 */
	public <T> List<T> getParameterizedDomainObjsList(String sql, Object[] objectMap, Class<T> type) throws ApplicationException, DatabaseException {
		List<T> domainObjsLst = null;
		try {
			domainObjsLst = this.jdbcTemplate1.query(sql, objectMap, ParameterisedCustomBeanPropertyRowMapper.newInstance(type));

		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.error("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObjsLst;
	}

	public <T> List<T> getParameterizedDomainObjectsList(String sql, Object[] objectMap, Class<T> type) throws ApplicationException, DatabaseException {
		List<T> domainObjsLst = null;
		try {
			domainObjsLst = this.jdbcTemplate1.query(sql, objectMap, new BeanPropertyRowMapper<T>(type));
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.error("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObjsLst;
	}

	public <T> List<T> getParameterizedDomainObjsListWithMaxResult(String sql, Object[] objectMap, Class<T> type, Integer max) throws ApplicationException, DatabaseException {
		List<T> domainObjsLst = null;
		try {
			// DataSource dataSource = getDataSource();
			JdbcTemplate jdbcTemplate = this.jdbcTemplate4;
			if (max != null && max != 0)
				jdbcTemplate.setMaxRows(max);
			domainObjsLst = jdbcTemplate.query(sql, objectMap, ParameterisedCustomBeanPropertyRowMapper.newInstance(type));

		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.error("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObjsLst;
	}

	/**
	 * Fetches the details and constructs a List of the passed Domain object
	 * 
	 * @param sql
	 * @param type
	 * @return
	 */
	public <T extends BaseObject> List<T> getDomainObjsList(String sql, Class<T> type) throws ApplicationException, DatabaseException {
		List<T> domainObjsLst = null;
		try {
			domainObjsLst = this.jdbcTemplate1.query(sql, BeanPropertyRowMapper.newInstance(type));
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.error("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObjsLst;
	}

	public <T> List<T> getDomainObjsList(String sql, Map<String, Object> paramMap, Class<T> type) throws ApplicationException, DatabaseException {
		List<T> domainObjsLst = null;
		try {
			domainObjsLst = this.namedParameterJdbcTemplate1.query(sql, paramMap, ParameterisedCustomBeanPropertyRowMapper.newInstance(type));
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.info("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObjsLst;
	}

	protected Long getSeqId(String sql, Object[] objectMap) throws ApplicationException, DatabaseException {
		Long idVal = null;
		try {
			List<Long> idLst = this.jdbcTemplate1.queryForList(sql, objectMap, Long.class);
			if (idLst != null && idLst.size() > 0) {
				idVal = idLst.get(0) != null ? idLst.get(0).longValue() : null;
			}
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.info("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return idVal;
	}

	/**
	 * This method is to save the data using named parameterized SQL.
	 * 
	 * @param sql
	 * @param dataObject
	 * @throws DatabaseException
	 */
	public int saveOrUpdateNamedObject(final String sql, final Object dataObject) throws ApplicationException, DatabaseException {
		try {
			return this.namedParameterJdbcTemplate1.update(sql, new BeanPropertySqlParameterSource(dataObject));
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (Exception e) {
			handleException(e);
		}
		return 0;
	}

	/**
	 * Insert or update a list of domainObj in DB
	 * 
	 * @param entityList
	 * @param sql
	 * @return
	 */
	protected <T> int[] batchUpdate(List<T> entityList, String sql) {
		if (CollectionUtils.isEmpty(entityList)) {
			return null;
		}
		SqlParameterSource[] sqlParameterSources = new SqlParameterSource[entityList.size()];
		int i = 0;
		for (T entity : entityList) {
			// LOGGER.info(ToStringBuilder.reflectionToString(entity));
			sqlParameterSources[i] = new BeanPropertySqlParameterSource(entity);
			i++;
		}
		return this.namedParameterJdbcTemplate1.batchUpdate(sql, sqlParameterSources);
	}

	public <T> int[] batchDelete(List<T> entityList, String deleteSql) {
		return batchUpdate(entityList, deleteSql);
	}

	public Long getCount(String sql, Object[] objectMap) throws DatabaseException {
		Long count = 0L;
		try {
			List<Long> countList = this.jdbcTemplate1.queryForList(sql, objectMap, Long.class);
			if (countList != null && countList.size() > 0) {
				count = countList.get(0) != null ? countList.get(0).longValue() : null;
			}
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.error("No result returned for query: " + sql);
			return null;
		}
		return count;
	}

	public int saveOrUpdateDomainObj(String sql, Object[] ObjectMap) throws DatabaseException {
		try {
			return this.jdbcTemplate1.update(sql, ObjectMap);
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		return 0;
	}

	public int deleteDomainObject(String sql, Object[] parameters) throws DatabaseException {
		try {
			return this.jdbcTemplate1.update(sql, parameters);
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
			// LOGGER.error("Illegal state exception for query: " + sql);
		}
		catch (EmptyResultDataAccessException e) {
			handleException(e);
			// LOGGER.error("No rows deleted for query: " + sql);
		}
		return 0;
	}

	public int deleteDomainObject(String sql, Map<String, Object> parameters) throws DatabaseException {
		try {
			return this.namedParameterJdbcTemplate1.update(sql, parameters);
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
			// LOGGER.error("Illegal state exception for query: " + sql);
		}
		catch (EmptyResultDataAccessException e) {
			handleException(e);
			// LOGGER.error("No rows deleted for query: " + sql);
		}
		return 0;
	}

	public <T> List<T> getParameterizedDomainObjectsListFromSecondDataSource(String sql, Object[] objectMap, Class<T> type) throws ApplicationException, DatabaseException {

		List<T> domainObjsLst = null;
		try {
			/*
			 * DataSource dataSource = (DataSource)
			 * applicationContext.getBean("dataSource1"); //TODO: Create Spring
			 * Singleton for JDBCTemplate JdbcTemplate jdbcTemplate = new
			 * JdbcTemplate(dataSource);
			 */
			// JdbcTemplate jdbcTemplate = getJdbcTemplate().
			domainObjsLst = jdbcTemplate2.query(sql, objectMap, new BeanPropertyRowMapper<T>(type));
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.error("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObjsLst;
	}

	public <T> List<T> getDomainObjsListFromTemplate2(String sql, Map<String, Object> paramMap, Class<T> type) throws ApplicationException, DatabaseException {
		List<T> domainObjsLst = null;
		try {
			domainObjsLst = this.namedParameterJdbcTemplate2.query(sql, paramMap, ParameterisedCustomBeanPropertyRowMapper.newInstance(type));
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.info("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObjsLst;
	}
	
	
	public <T> List<T> getDomainObjsListFromTemplate3(String sql, Map<String, Object> paramMap, Class<T> type) throws ApplicationException, DatabaseException {
		List<T> domainObjsLst = null;
		try {
			domainObjsLst = this.namedParameterJdbcTemplate3.query(sql, paramMap, ParameterisedCustomBeanPropertyRowMapper.newInstance(type));
		}
		catch (DataAccessResourceFailureException e) {
			handleException(e);
		}
		catch (IllegalStateException e) {
			handleException(e);
		}
		catch (EmptyResultDataAccessException e) {
			// LOGGER.info("No result returned for query: " + sql);
			return null;
		}
		catch (Exception e) {
			handleException(e);
		}
		return domainObjsLst;
	}

	protected final void handleException(DataAccessException ex) throws DatabaseException {
		// LOGGER.error("DataAccessException : " + ex.getMessage(), ex);
		ex.printStackTrace();
		throw new DatabaseException("101", ex.getMessage());
	}

	protected final void handleException(Exception ex) throws ApplicationException, DatabaseException {
		// LOGGER.error("Jdbc Exception :" + ex.getMessage(), ex);
		ex.printStackTrace();
		throw new DatabaseException("101", ex.getMessage());
	}

	protected final void handleException(IllegalStateException ex) throws DatabaseException {
		// LOGGER.error("IllegalStateException :" + ex.getMessage(), ex);
		ex.printStackTrace();
		throw new DatabaseException("101", ex.getMessage());
	}
}
