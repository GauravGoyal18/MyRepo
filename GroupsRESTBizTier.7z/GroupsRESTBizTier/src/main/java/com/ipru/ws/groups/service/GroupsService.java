package com.ipru.ws.groups.service;

import java.util.List;

import com.ipru.groups.to.CountTO;
import com.ipru.groups.to.DropDownTO;
import com.ipru.groups.to.LatestNavTO;
import com.ipru.groups.to.SwitchTo;
import com.ipru.groups.vo.FscDetailsVO;
import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.NoDataFoundException;
import com.ipru.ws.exception.ResourceNotFoundException;
import com.ipru.ws.groups.beans.DropDownRequest;
import com.ipru.ws.groups.beans.GroupUser;
import com.ipru.ws.groups.beans.PrePopulateBean;
import com.ipru.ws.groups.beans.ProductCodeBean;
import com.ipru.ws.groups.beans.SwitchToRequest;

public interface GroupsService {
	public void test();

	public List<DropDownTO> getDropDownList(DropDownRequest dropDownRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException;

	public <T> List<T> getPrePopulate(PrePopulateBean prePopulateBean) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException;

	public List<SwitchTo> getSwitchDataList(SwitchToRequest switchToRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException;

	public List<LatestNavTO> getSwitchFundDataList(SwitchToRequest switchToRequest) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException;

	public CountTO getPrePopulateCount(PrePopulateBean prePopulateBean) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException;

	public GroupUser getUserDetails(GroupUser groupUser)throws ApplicationException, DatabaseException, BadDataException, NoDataFoundException;

	public FscDetailsVO getFscDetails(FscDetailsVO fscdetails)throws ApplicationException, DatabaseException, BadDataException, NoDataFoundException;;
	
}
