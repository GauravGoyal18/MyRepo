package com.ipru.ws.groups.dao;

import java.util.List;

import com.ipru.ws.exception.ApplicationException;
import com.ipru.ws.exception.BadDataException;
import com.ipru.ws.exception.DatabaseException;
import com.ipru.ws.exception.NoDataFoundException;
import com.ipru.ws.exception.ResourceNotFoundException;
import com.ipru.ws.groups.beans.GroupPolicyDetail;
import com.ipru.ws.groups.beans.UserDetailsVO;

public interface PolicyDetailsDAO  {
	
	public List<GroupPolicyDetail> getpolicyDetailsDAO(
			List<UserDetailsVO> UserDetailsList) throws ApplicationException, DatabaseException, BadDataException, ResourceNotFoundException, NoDataFoundException;
	}