var app = angular.module('groupApp', ['ajaxUtil','uiValidations','ui.materialize','groupCommonUtil']);

app.controller('bidStatementController',['$scope','$location','ajaxHttpFactory','$rootScope','$window','csrDocUploadFactory','$http', function($scope,$location,ajaxHttpFactory,$rootScope,$window,csrDocUploadFactory,$http){
	
	$rootScope.preloaderCheck=false;
	$scope.errorArray=[];
	$scope.bid={};
	$scope.submitBID=function()
	{
		if($scope.checkBasicFieldValidations())
		{	
		if(new Date($scope.bid.fromDate)<=new Date($scope.bid.toDate)){
		$rootScope.preloaderCheck=true;
		var bidSubmit=angular.toJson($scope.bid);
		var ajaxurl=$location.absUrl();
		ajaxHttpFactory.postJsonDataSuccessFailure(bidSubmit,"POST",ajaxurl,"bidStatement",$scope.successMethod,$scope.failureMethod);

		
		}
		
		else if(new Date($scope.bid.fromDate)>new Date($scope.bid.toDate))
		{
			$rootScope.preloaderCheck=false;
		ajaxHttpFactory.showErrorSuccessMessagePopup("End Date should be greater than start date","errorMessage-popup", "bidAlert");
		}
		else{
			$rootScope.preloaderCheck=false;
			}
		
	}
	};

	$scope.failureMethod=function(){
		
		$rootScope.preloaderCheck=false;
		
		$rootScope.openAlertID = true;
		$scope.action="failure";
		$scope.message = "Some Error Occured.";
	};
	
	$scope.successMethod=function(response){
		$rootScope.preloaderCheck=true;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
		
		if(response=="success")
			{
		 	$scope.methodType = 'POST';
			
			$http({
                url: 'PDFStatementServlet.do',
                method: $scope.methodType,
                responseType: 'arraybuffer',
                data: undefined,
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/pdf'
                }
            }).success(function(data) {
            	$rootScope.preloaderCheck=true;
            	if(data.byteLength>0)
            	{
                var blob = new Blob([data], {
                    type: 'application/pdf'
                });
                saveAs(blob, 'bidStatement' + '.pdf');
               // $rootScope.preloaderCheck=false;
				ajaxHttpFactory.showErrorSuccessMessagePopup("File downloaded successfully. ","errorMessage-popup", "bidAlert");
				$rootScope.preloaderCheck=false;
            	}
            	else
            	{
            		$rootScope.preloaderCheck=false;
					ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "bidAlert");

            	}
                
                
            }).error(
                function() {
                 	$rootScope.preloaderCheck=false;
					ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "bidAlert");

                });
			
			
			
			}
		else
			{
			$rootScope.preloaderCheck=false;
			ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ","errorMessage-popup", "bidAlert");

			}
		}
		$rootScope.preloaderCheck=false;
	};
	
	
	var currentTime = new Date();
	$scope.currentTime = currentTime;
	$scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	$scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	$scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
	$scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

	$scope.today = '';
	$scope.clear = 'Clear';
	$scope.close = 'Done';
	var days = 100;
	$scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
	$scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
	$scope.onStart = function () {
	   
	};
	$scope.onRender = function () {
	   
	};
	$scope.onOpen = function () {
	 
	    
	   

	    
	};
	$scope.onClose = function () {
		 
	  
	    
	    
	};


	$scope.onSet = function () {
		 
	  
	  

	  
	  
	};


	$scope.onStop = function () {
	  
	};
	
	$rootScope.$on('isOkClicked', function(event, args) {
		 if (args == 'exceptionAlert') {
			alert("Exception came") ;
		 } if (args == 'submitSuccessAlert') {
			
		 }		 
	});
	
	$scope.okAlert= function (){
		$rootScope.openAlertID = false;

		 if($scope.action=="success")
			{
			 $rootScope.openAlertID = false;
			
			}
		else if($scope.action=="failure")
			{
			$rootScope.openAlertID = false;
			}
		
	};
	
	$scope.cancelAlert= function (){
	
		$rootScope.openAlertID = false;
	};
	
$scope.checkBasicFieldValidations = function() {
		

	    if ($scope.errorArray.length > 0) {
	        for (var i = 0; i < $scope.errorArray.length; i++) {
	            var lengthBfr = $scope.errorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = $scope.errorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	        if ($scope.errorArray.length > 0) {
	            $("#" + $scope.errorArray[0]).focus();
	            return false;
	        } else {
	            return true;
	        }
	    } else {
	        return true;
	    }
	};
	
	$scope.checkDate= function(currentElement,errorMsgElement){
		if(angular.element(document.getElementById(currentElement)).val()=="")
			{
			angular.element(document.getElementById(currentElement)).addClass('invalid1');
			angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
			return false;
			}
		else
			{
			angular.element(document.getElementById(currentElement)).removeClass('invalid1');
			angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
			}
		return true;
		}
		 	
	
}]);