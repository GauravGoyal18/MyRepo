var app = angular.module('groupApp', [ 'ajaxUtil', 'ui.materialize','uiValidations','groupCommonUtil','validationService']);
app.controller('claimsController',['$rootScope','$scope','$location','ajaxHttpFactory','csrDocUploadFactory','$window','validateFieldService','$filter',function($rootScope, $scope, $location, ajaxHttpFactory,csrDocUploadFactory,$window,validateFieldService,$filter) {

	
	$rootScope.preloaderCheck=true;	
							$scope.claim = {};							
							$scope.cities={};							
							$scope.cities.key=[];
							$scope.cities.value=[];
							$scope.cause=[];
							$scope.relation=[];
							$scope.hideSubmitNreset = true;
							$scope.uploadArray = {};
						//	$scope.claim.mainFile = "";
							//$scope.uploadArray.addClaims={};
							//$scope.uploadArray.addClaims[0].mainFile=[];
							$scope.appointeeShow = [];
							$scope.beneficiaryNameShow = [];
							$scope.claim.addClaims = [];
							$scope.claimCountArr=[];
							$scope.deleteId='';
							$scope.parentDeleteId='';
							$scope.actions="";	
						$scope.tempBeneficiary=[];
							$scope.claimsAccessMatrix={};
							$scope.Beneficiary = [];
							$scope.benCount=[];
							$scope.claimCount=0;
							$scope.states =  [];
							$scope.gratuityApplicables = [ "YES", "NO" ];							
							$scope.errorArray = [];
							$scope.functionalityId="";
							$scope.productType="";
							$scope.claim.addClaims[0]={};
							$scope.claim.addClaims[0].beneficiary =[];
							$scope.claim.addClaims[0].beneficiary[0] ={};
							$scope.claim.addClaims[0].uploadFileList=[];
							//claim.addClaims[0].beneficiary=[];
				
							var parentIndexForUploadFile='';
								
				
							
							
							var getClaimsDetailsAccessMatrix = function () { //display purpose only field should be blank
								
								return ajaxHttpFactory.getJsonData("getClaimsDetailsAccessMatrix",$location.absUrl())
								.then(function(response) {
									if(ajaxHttpFactory.handleIPruException(response.data, "", "exceptionAlert")){
										$rootScope.openAlertID2 = true;	
										$scope.message = "No Data Found";
									}
								
									if (response != null && response != "null") {
										var responseData = response.data;
										$scope.claimsAccessMatrix = responseData.resultMap;
										$scope.claimCountArr.push('claim_0');
										$scope.Beneficiary[0]=[];
										$scope.Beneficiary[0].push('ben_0');
										$scope.benCount[0]=0;
										$scope.appointeeShow[0]=[];
										$scope.beneficiaryNameShow[0]=[];										
										$scope.beneficiaryNameShow[0][0]=false;
										$scope.appointeeShow[0][0]=false;										
									}
								},
								function(errResponse) {
								
									console.error('Error while fetching profile details.');

								});

							};
							
							//onload functions
							getClaimsDetailsAccessMatrix();	
								
						
							
							
							$scope.validateFields = function(name,action)  
							{
							  
								$scope.id=name;
								$scope.action=action;
								$scope.result = validateFieldService.fieldValidate($scope.id,$scope.action,$scope.claimsAccessMatrix);
								return $scope.result;
								
								
								};
								
							
							
							$scope.getStates = function() {	
								$scope.preloaderCheck=true;
				             var ajaxurl = $location.absUrl();
								ajaxHttpFactory.getJsonData('States',ajaxurl,'','GET').then(
				                        function successCallback(response) {
				                        	$scope.productType=response.data[0].productType;
				                        	$scope.functionalityId = response.data[0].functionalityId;
				                        	
				                        	for(var i = 0;i<response.data[0].state.length;i++){
				                        		 $scope.states.push(response.data[0].state[i].value);
				                        		 
				                        	}
				                        	$scope.functionalityiD = response.data.functionalityID;
				                        	for(var i = 0;i<response.data[0].cause.length;i++){				                        		
				                        		 $scope.cause.push(response.data[0].cause[i].value);
				                        	}
				                        	
				                        	for(var i = 0;i<response.data[0].city.length;i++){
				                        		 $scope.cities.key.push(response.data[0].city[i].key);
				                        		 $scope.cities.value.push(response.data[0].city[i].value);
				                        	}
				                        	for(var i = 0;i<response.data[0].relation.length;i++){
				                        		 $scope.relation.push(response.data[0].relation[i].value);
				                        	}
				                        	
				                        	$rootScope.preloaderCheck=false;
				                        	}
				                       );
								
								};
								//onload functions
								$scope.getStates();
							
							
							 $scope.getCityList = function(stateDetails,parentIndex,index) {		
								 $scope.preloaderCheck=true;
								 $scope.claim.addClaims[parentIndex].beneficiary[index].cityyyyy=[];
									 if(stateDetails!=null){
										var data1=$scope.cities;
										for(var i=0;i<data1.key.length;i++)
									 {
											if(data1.key[i]==stateDetails){
												$scope.claim.addClaims[parentIndex].beneficiary[index].cityyyyy.push(data1.value[i]);								
											}
											}
									 }
								 };
								 $scope.checkBasicFieldValidations = function() {

										if ($scope.errorArray.length > 0) {
											
											
											
											
											for ( var i = 0; i < $scope.errorArray.length; i++) {
												var lengthBfr = $scope.errorArray.length;
												var errorElement = angular.element(document
														.querySelector('#' + $scope.errorArray[i]));
												if (errorElement.prop('type') == "text"
														|| errorElement.prop('type') == "textarea"
														|| errorElement.prop('tagName') == 'DIV'
														|| errorElement.prop('tagName') == "SELECT") {
													errorElement.triggerHandler("blur");
												}
												var lengthAftr = $scope.errorArray.length;
												if (lengthAftr < lengthBfr) {
													i--;
												}
											}
											if ($scope.errorArray.length > 0) {
												$("#" + $scope.errorArray[0]).focus();
												return false;
											} else {
												return true;
											}
										} else {
											return true;
										}
									};
								 
								 $scope.removeErrors = function() {
										var deleteDetails=false;
										//$scope.claim.addClaims[parentIndex]=[];
										var parentIndex=$scope.claimCount;
                                        var index=$scope.benCount[parentIndex]
										$scope.removeTermError();
									    if ($scope.errorArray.length > 0) {
									    	
									    	var arrlength=$scope.errorArray.length;
									    	
									    	
									    	for(var j=0;j<$scope.errorArray.length;j++)
									    	{
									    		
									    		if(deleteDetails)
									    		{
									    			j=0;
									    		} 
									   
									    		
									    		if($scope.errorArray[j].indexOf("appointee")==0 && $scope.claim.addClaims[parentIndex]!=undefined)
									    		{
									    	 		
									    			var parentIndex=$scope.claimCount;
                                                    var index=$scope.benCount[parentIndex]
									    			if($scope.claim.addClaims[parentIndex].beneficiary[index]==undefined)
									    			{
									    				$scope.errorArray.splice(j, 1);
									    				deleteDetails=true;
									    				j--;
									    			}
										    		else
								    				{
								    				deleteDetails=false;
								    				
									    			
									    		
									    			var age=$scope.calculateAge(new Date($scope.claim.addClaims[parentIndex].beneficiary[index].beneficiaryDOB));
									    			if(age>18)
									    			{
									    				$scope.errorArray.splice(j, 1);
									    			}
								    				}
									    			
									    		}
									    		
									    		else if($scope.errorArray[j].indexOf("beneficiary")==0 && $scope.claim.addClaims[parentIndex]!=undefined)
									    		{
									    			var parentIndex=$scope.claimCount;
                                                   var index=$scope.benCount[parentIndex]
									    			//var parentIndex=tempIndex.charAt(0);
									    			
									    		if($scope.claim.addClaims[parentIndex].beneficiary[index]==undefined)
								    			{
								    				$scope.errorArray.splice(j, 1);
								    				deleteDetails=true;
								    				j--;
								    			}
									    		else
							    				{
							    				deleteDetails=false;
							    				}
									    			}
									    		else
									    			{
									    			var parentIndex=$scope.claimCount;
                                                    var index=$scope.benCount[parentIndex]
									    			if($scope.claim.addClaims[parentIndex]==undefined)
									    			{
									    				
									    				$scope.errorArray.splice(j, 1);
									    				deleteDetails=true;
									    				j--;
									    				
										    				
										    			
									    			}
										    		else
								    				{
								    				deleteDetails=false;
								    				
									    			
								    				}
									    			}
									    	}
									    	
									    
									        
									        
									        
									        
									        
									    } 
									 
									 
									};
								 
								 
								 $scope.okAlert= function (){
								
										$rootScope.openAlertID = false;
										if($scope.actions=="delete")
											{
											 if($scope.checkFlag=="beneficiary"){
										if($scope.benCount[$scope.parentDeleteId]==0)
										{
												
											ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 beneficiary should be there. ","errorMessage-popup", "claimsAlert");
										}
											
										else
											{
											 $scope.appointeeShow[$scope.parentDeleteId].splice($scope.deleteId,1);
											 $scope.beneficiaryNameShow[$scope.parentDeleteId].splice($scope.deleteId,1);
											  $scope.Beneficiary[$scope.parentDeleteId].splice($scope.deleteId,1);
											//  $scope.claim.addClaims[$scope.parentDeleteId]={};
											  //$scope.claim.addClaims[$scope.parentDeleteId].beneficiary=[];
											  $scope.claim.addClaims[$scope.parentDeleteId].beneficiary.splice($scope.deleteId,1);
												 
											
											  $scope.removeErrors();
											 
											 
										$scope.benCount[$scope.parentDeleteId]= $scope.benCount[$scope.parentDeleteId]-1;
										 
										
										  $scope.Beneficiary[$scope.parentDeleteId]=[];
										  for(var i=0;i<=$scope.benCount[$scope.parentDeleteId];i++)
											  {			
											 //$scope.appointeeShow[scope.benCount[$scope.parentDeleteId]].push(i);
											$scope.Beneficiary[$scope.parentDeleteId].push('ben_'+i);
											  }
										 
											  }
											 }
											 else if($scope.checkFlag=="claim"){
												 if($scope.claimCount==0)
													{
															
														ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 claim should be there. ","errorMessage-popup", "claimsAlert");
													}
												 else{
												 
													 for ( var i = 0; i < $scope.claim.addClaims.length; i++) {
														 if(i>$scope.deleteId)
															{
															var upload_Msg = angular.element(document
														  .querySelector('#' +'file-upload-main'+i+'_errMsg'));
															
															var upload_Msg1 = angular.element(document
																	  .querySelector('#' +'file-upload-main'+(parseInt(i)-1)+'_errMsg'));
															
															
															var up_Msg = angular.element(document
																	  .querySelector('#' +'file-upload-main'+i+'_upText'));
																		
															var up_Msg1 = angular.element(document
																				  .querySelector('#' +'file-upload-main'+(parseInt(i)-1)+'_upText'));
																		
															
															 upload_Msg1[0].innerHTML=upload_Msg[0].innerHTML;
															 up_Msg1[0].innerHTML=up_Msg[0].innerHTML;
															 }
														}
													
													/*for(var i=0;i<=$scope.claim.addClaims.length;i++)
													{
														
														if(i==1)
														{
															//$scope.addBeneficiary(0);	
														
															$scope.benCount[0]	= $scope.benCount[0]+1;
															$scope.Beneficiary[0].push('ben_'+$scope.benCount[0]);
															$scope.claim.addClaims[0].beneficiary[$scope.benCount[0]] ={};
															$scope.appointeeShow[0][$scope.benCount[0]]=true;
															$scope.beneficiaryNameShow[0][$scope.benCount[0]]=false;
															$scope.claim.addClaims[0].beneficiary[$scope.benCount[0]].sharePercentage='100';
														}
													}*/
													
													
													
													delete $scope.claim.addClaims[$scope.deleteId];
													delete $scope.Beneficiary[$scope.deleteId];
													delete $scope.claimCountArr[$scope.deleteId];
													delete $scope.benCount[$scope.deleteId];
													
													for(var i=0;i<=$scope.claim.addClaims.length;i++ ){
													
														//Beneficiary[outerIndex][]={}
														
													if($scope.claim.addClaims[i]== undefined){
														$scope.claim.addClaims.splice(i,1);
													}														
													}
													for(var i=0;i<=$scope.Beneficiary.length;i++ ){
														if($scope.Beneficiary[i]== undefined){
															$scope.Beneficiary.splice(i,1);
														}														
													}
													for(var i=0;i<=$scope.claimCountArr.length;i++ ){
														if($scope.claimCountArr[i]== undefined){
															$scope.claimCountArr.splice(i,1);
														}	
													}
													for(var i=0;i<=$scope.benCount.length;i++ ){
														if($scope.benCount[i]== undefined){
															$scope.benCount.splice(i,1);
														}
													}
													
													 $scope.appointeeShow.splice($scope.deleteId,1);
													 $scope.beneficiaryNameShow.splice($scope.deleteId,1);
													 
													 
												/*	if($scope.claim.addClaims[$scope.deleteId].beneficiary[$scope.innerId].appointeeName!="" && $scope.claim.addClaims[$scope.deleteId].beneficiary[$scope.innerId].appointeeName!=undefined) {
														 $scope.appointeeShow[$scope.deleteId].splice($scope.innerId,1);
														}
														if($scope.claim.addClaims[$scope.deleteId].beneficiary[$scope.innerId].beneficiaryName!=""  && $scope.claim.addClaims[$scope.deleteId].beneficiary[$scope.innerId].beneficiaryName!=undefined)
															{
														 $scope.beneficiaryNameShow[$scope.deleteId].splice($scope.innerId,1);
														 
															}*/
													
												/*	for(var i=0;i<=$scope.claim.addClaims.length;i++ )
													{
														for(var j=0;j<$scope.benCount[i];j++)
															{
														$scope.benTemp=$scope.claim.addClaims[i].beneficiary[j];
														$scope.claim.addClaims[i].beneficiary[j]={};
														$scope.claim.addClaims[i].beneficiary[j]=$scope.benTemp;
															}
													}*/
													
													//$scope.claimCountArr=[];
													
													  //$scope.benCount=[];
													/*  for(var i=1;i<$scope.claim.addClaims.length;i++){
														//  $scope.benCount[i]=[];
														  $scope.claimCountArr[i]='claim_'+i;
															
														$scope.benCount[i]=$scope.claim.addClaims[i].beneficiary.length-1;
															
														  
													  }*/
													 $scope.removeErrors();
													 
														$scope.claimCount= $scope.claimCount-1;
														
															
														
														 
														
														
														 
												 }
											 }
											}
										else if($scope.action=="success")
											{
											$window.location.href = "dashboard.htm";
											}
										else if($scope.action=="failure")
											{
											$window.location.href = "onlogout.htm";
											}
										
									};
									$scope.cancelAlert= function (){
										$rootScope.openAlertID = false;
										$rootScope.openAlertID1 = false;
									};
									
									$scope.claimAdded= function (){
										$rootScope.openAlertID = false;
										$rootScope.openAlertID1 = false;
										$window.location.href = "claims.htm";
									};
									$scope.dataAlert= function (){
										$rootScope.openAlertID2 = false;											
										$window.location.href = "dashboard.htm";
									};
									
							$scope.deleteBeneficary = function(parentId,deletID) {
								
								if($scope.benCount[parentId]==0){		
									/*$rootScope.openAlertID1 = true;	
									$scope.message = "At least 1 Beneficiary should be there.";	*/	
									ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 Beneficiary should be there. ","errorMessage-popup", "claimsAlert");									
								}else{
									$scope.checkFlag="beneficiary";
									$rootScope.openAlertID = true;	
									$scope.actions="delete";
									$scope.message = "Are you sure want to delete";
									$scope.deleteId=deletID;
									$scope.parentDeleteId=parentId;
									}														
							};
							
							
							$scope.removeTermError=function(){
								for(var i=0;i<=$scope.claimCount;i++){
									if($scope.productType=="TERM"){
										
										index = $scope.errorArray.indexOf("mobileNumber"+i);
										if(index!=-1)
										$scope.errorArray.splice(index,1);
										index = $scope.errorArray.indexOf("commutationPercentage"+i);
										if(index!=-1)
										$scope.errorArray.splice(index,1);
										index = $scope.errorArray.indexOf("annuityPercentage"+i);
										if(index!=-1)
										$scope.errorArray.splice(index,1);
										index = $scope.errorArray.indexOf("gratuityApplicable"+i);
										if(index!=-1)
										$scope.errorArray.splice(index,1);
										index = $scope.errorArray.indexOf("employeeEmailId_1"+i);
										if(index!=-1)
										$scope.errorArray.splice(index,1);
										
									}								
							}
							};
							
							$scope.addingclaims = function() {
								$scope.parentIndex=$scope.claimCount;
								 var claimlength=0;
								$scope.index=$scope.benCount[$scope.parentIndex];
								var fileCount=$scope.claim.addClaims.length;
								
								$scope.removeTermError();
								
								if ($scope.checkBasicFieldValidations() & $scope.addError($scope.parentIndex,$scope.index) )
								{
									
									
									for ( var k = 0; k<fileCount; k++) {
										if ($scope.claim.addClaims[k].uploadFileList.length > 0)
											{
										  
									/*if($scope.uploadArray.addClaims[$scope.parentIndex].mainFile.length<0)
				            		{*/
				            	
									if($scope.productType != "TERM"){
										for(var i=0;i<=$scope.parentIndex;i++){
										if(parseInt($scope.claim.addClaims[i].annuity) + parseInt($scope.claim.addClaims[i].commutation)!=100){											
											ajaxHttpFactory.showErrorSuccessMessagePopup("Commutation and annuity should be 100% . ","errorMessage-popup", "claimsAlert");	
											return false;
										}
										}
											}
									$scope.totalSharePer=0;

									for(var i=0;i<=$scope.index;i++)
									{	
										if($scope.claim.addClaims[$scope.parentIndex].beneficiary[i].sharePercentage=='')
											{
											[$scope.parentIndex].beneficiary[i].sharePercentage=0;
											}
									$scope.totalSharePer=parseInt($scope.totalSharePer)+parseInt($scope.claim.addClaims[$scope.parentIndex].beneficiary[i].sharePercentage);
									}
									
								if($scope.totalSharePer==100)
								{
									if($scope.claimCount<2)
									{
																			
										claimlength= claimlength+1;
										//$scope.claimCount	= $scope.claimCount+1;
										if(claimlength == fileCount){	
										$scope.claimCount	= $scope.claimCount+1;
										$scope.claimCountArr.push('claim_'+$scope.claimCount);
										//$scope.removeTermError();
										$scope.parentIndex=$scope.claimCount;
										$scope.Beneficiary[$scope.parentIndex]=[];
										$scope.claim.addClaims[$scope.parentIndex]={};
										$scope.claim.addClaims[$scope.parentIndex].beneficiary =[];
										$scope.claim.addClaims[$scope.parentIndex].uploadFileList=[];
										$scope.Beneficiary[$scope.parentIndex].push('ben_0');
										$scope.benCount[$scope.parentIndex]=0;
										$scope.appointeeShow[$scope.parentIndex]=[];
										$scope.beneficiaryNameShow[$scope.parentIndex]=[];	
										$scope.beneficiaryNameShow[$scope.parentIndex][0]=false;
										$scope.appointeeShow[$scope.parentIndex][0]=false;
										$scope.gobottom();
										}
										
									}
									else
										ajaxHttpFactory.showErrorSuccessMessagePopup("You cannot add more claims . ","errorMessage-popup", "claimsAlert");	
									
								}	else
									
									ajaxHttpFactory.showErrorSuccessMessagePopup("You cannot add claim, Share% should be 100 . ","errorMessage-popup", "claimsAlert");									
									
								}
									  else
										{										 
										 
										ajaxHttpFactory.showErrorSuccessMessagePopup("Please Upload File ","errorMessage-popup", "claimsAlert");	
										}
									}
									 
								}
								 else
										ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details ","errorMessage-popup", "claimsAlert");	
								
								};
								/*else{
									$scope.upload_Msg[0].innerHTML="";
			                        $scope.desc_Id[0].innerHTML="";
			                        $scope.upload_Msg[0].innerHTML="<span class=red-text>Please Upload File</span>";
				            	}	*/
							
							
							$scope.deleteClaims= function(parentIndex) {
								if($scope.claimCount==0){		
									/*$rootScope.openAlertID1 = true;	
									$scope.message = "At least 1 Beneficiary should be there.";	*/	
									ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 claim should be there. ","errorMessage-popup", "claimsAlert");									
								}else{
									
								$scope.checkFlag="claim";
								$rootScope.openAlertID = true;	
								$scope.actions="delete";
								$scope.message = "Are you sure want to delete";
								$scope.deleteId=parentIndex;
								$scope.innerId=$scope.benCount[parentIndex];
								}	
								
							};
							
							$scope.gobottom=function(){
								 var documentHeight=document.documentElement.offsetHeight;
								 var viewportHeight=window.innerHeight;
								 window.scrollTo(0,documentHeight-viewportHeight);
								 }
							
							
						
							var total = 0;							
							$scope.addBeneficiary = function(parentIndex) {
								  $scope.index=$scope.benCount[parentIndex];
								  
								  $scope.removeTermError();
								if ($scope.checkBasicFieldValidations() & $scope.addError(parentIndex,$scope.index))
								{
									if($scope.productType != "TERM"){
										for(var i=0;i<=parentIndex;i++){
										if(parseInt($scope.claim.addClaims[i].annuity) + parseInt($scope.claim.addClaims[i].commutation)!=100){											
											ajaxHttpFactory.showErrorSuccessMessagePopup("Commutation and annuity should be 100% . ","errorMessage-popup", "claimsAlert");	
											return false;
										}
										}
											}
									$scope.totalSharePer=0;
                                   
									for(var i=0;i<=$scope.index;i++)
									{	
										if($scope.claim.addClaims[parentIndex].beneficiary[i].sharePercentage=='')
											{
											$scope.claim.addClaims[parentIndex].beneficiary[i].sharePercentage=0;
											}
									$scope.totalSharePer=parseInt($scope.totalSharePer)+parseInt($scope.claim.addClaims[parentIndex].beneficiary[i].sharePercentage);
									}
									
								if($scope.totalSharePer<100)
								{
								if($scope.benCount[parentIndex]<9)
								{
									$scope.benCount[parentIndex]	= $scope.benCount[parentIndex]+1;
									$scope.Beneficiary[parentIndex].push('ben_'+$scope.benCount[parentIndex]);
									$scope.claim.addClaims[parentIndex].beneficiary[$scope.benCount[parentIndex]] ={};
									//$scope.claim.addClaims[parentIndex].uploadFileList=[];
									//$scope.appointeeShow[parentIndex]=[];
									$scope.appointeeShow[parentIndex][$scope.benCount[parentIndex]]=false;
									$scope.beneficiaryNameShow[parentIndex][$scope.benCount[parentIndex]]=false;
									
									
								}
								else
									ajaxHttpFactory.showErrorSuccessMessagePopup("You cannot add more Beneficiary . ","errorMessage-popup", "claimsAlert");	
								}	
								else
									ajaxHttpFactory.showErrorSuccessMessagePopup("You cannot add more Beneficiary, Share% should be  100% . ","errorMessage-popup", "claimsAlert");									
								}
								else
									ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details for Beneficiary ","errorMessage-popup", "claimsAlert");																	
								};
							
								
								$scope.calculateAge = function(birthday) { 
									

								    var ageDifMs = Date.now() - birthday.getTime();
								    var ageDate = new Date(ageDifMs); 
								    
								    return Math.abs(ageDate.getUTCFullYear() - 1970);
								};

								var currentTime = new Date();
								$scope.currentTime = currentTime;
								$scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
								$scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
								$scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
								$scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

								$scope.today = '';
								$scope.clear = 'Clear';
								$scope.close = 'Done';
								var days = 100;
								$scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
								$scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
								
								$scope.onStart = function () {
								    
								};
								$scope.onRender = function () {
								   
								};
								$scope.onOpen = function () {
								   							    
								};
								$scope.onClose = function () {
									 
								    
								};
								$scope.onSet = function () {
									 
								 
								};

								$scope.onSet = function (parentIndex,index) {
								   if(angular.isDefined(parentIndex)){
									if($scope.claim.addClaims[parentIndex].beneficiary[index]!='' && $scope.claim.addClaims[parentIndex].beneficiary[index]!=undefined)
									{
								    $scope.birthday= new Date($scope.claim.addClaims[parentIndex].beneficiary[index].beneficiaryDOB);
								    $scope.age= $scope.calculateAge($scope.birthday);
								  if(!isNaN($scope.age)){
								    if($scope.age<18)
								    {
								    	
								    	
								    	 $scope.appointeeShow[parentIndex][index]=false;
								    	 $scope.beneficiaryNameShow[parentIndex][index]=true;
								    	 /*if(angular.isDefined($scope.claim.addClaims[parentIndex])){
						    	    			if(angular.isDefined($scope.claim.addClaims[parentIndex].beneficiary[index]) && $scope.actions!="delete"){						    	    				
							    	    			$scope.claim.addClaims[parentIndex].beneficiary[index].appointeeName="";							    	    			
						    	    			}
						    	    		}*/
								  
								    	
									    	
								    }
								    else	
								    {
								    	
								    	 $scope.appointeeShow[parentIndex][index]=true;
								    	 $scope.beneficiaryNameShow[parentIndex][index]=false;
								    	/* if(angular.isDefined($scope.claim.addClaims[parentIndex])){
						    	    			if(angular.isDefined($scope.claim.addClaims[parentIndex].beneficiary[index]) && $scope.actions!="delete"){
						    	    				
							    	    			$scope.claim.addClaims[parentIndex].beneficiary[index].beneficiaryName="";
					    	    					
							    	    			}	
						    	    		}*/
											
								    	 
									    	
								    }
								 }
									}
								   }
								 
								};
								$scope.addError= function (parentIndex,index) {
									 if(angular.isDefined(parentIndex)){
											if($scope.claim.addClaims[parentIndex].beneficiary[index]!='' && $scope.claim.addClaims[parentIndex].beneficiary[index]!=undefined)
											{
										    $scope.birthday= new Date($scope.claim.addClaims[parentIndex].beneficiary[index].beneficiaryDOB);
										    $scope.age= $scope.calculateAge($scope.birthday);
										  if($scope.age!=NaN){
										    if($scope.age<18)
										    {
										    	if($scope.claim.addClaims[parentIndex].beneficiary[index].appointeeName=="" || $scope.claim.addClaims[parentIndex].beneficiary[index].appointeeName==undefined){
													var currentElement = angular.element(document.querySelector("#appointeeName"+parentIndex+index));
													currentElement.addClass('invalid1');
													$("#appointeeName"+parentIndex+index+"_errMsg").css("visibility","visible");
													return false;
													}else if($scope.claim.addClaims[parentIndex].beneficiary[index].appointeeName.match(/^(?!(?:\S*\s){4})(?!.*([A-Za-z])\1{2})([A-Za-z]*)([A-Za-z]+((\s){0,1}))*([A-Za-z])+$/)){
														var currentElement =angular.element(document.querySelector("#appointeeName"+parentIndex+index));
												          currentElement.removeClass('invalid1');
															$("#appointeeName"+parentIndex+index+"_errMsg").css("visibility","");
															
															return true;
													}
									    }
									    else	
									    {
									    
									    	if($scope.claim.addClaims[parentIndex].beneficiary[index].beneficiaryName=="" || $scope.claim.addClaims[parentIndex].beneficiary[index].beneficiaryName==undefined){
												var currentElement = angular.element(document.querySelector("#beneficiaryName"+parentIndex+index));
												currentElement.addClass('invalid1');
												$("#beneficiaryName"+parentIndex+index+"_errMsg").css("visibility","visible");
												return false;
												}else if($scope.claim.addClaims[parentIndex].beneficiary[index].beneficiaryName.match(/^(?!(?:\S*\s){4})(?!.*([A-Za-z])\1{2})([A-Za-z]*)([A-Za-z]+((\s){0,1}))*([A-Za-z])+$/)){
													var currentElement =angular.element(document.querySelector("#beneficiaryName"+parentIndex+index));
											          currentElement.removeClass('invalid1');
														$("#beneficiaryName"+parentIndex+index+"_errMsg").css("visibility","");
														
														return true;
												}
												
									    }
										    
										  }
											}
									 }
								};
											
									  
								
								
								$scope.onStop = function () {
								  
								};
								
								$scope.resetClaim = function(){
									$rootScope.openAlertID = false;	
							
					    			   $window.location.href = "claims.htm";	
					    		
								};
								$scope.submitClaim = function() {
									var fileCount=$scope.claim.addClaims.length;
									$scope.parentIndex=$scope.claimCount;
									var claimlength=0;
									$scope.index=$scope.benCount[$scope.parentIndex];
									
									$scope.removeTermError();
									
									if ($scope.checkBasicFieldValidations() & $scope.addError($scope.parentIndex,$scope.index) )
									{										
										
										for ( var k = 0; k < fileCount; k++) {
											if ($scope.claim.addClaims[k].uploadFileList.length > 0)
												{
											
											if($scope.checkAnnuityValidation()){
												
											
											
										$scope.totalSharePer=0;

										
										for(var i=0;i<=$scope.claimCount;i++)
										{	
										 $scope.totalSharePer=0;
											for(var j=0;j<=$scope.benCount[i];j++)
										{		
										//	$scope.Data=$scope.claim.beneficiary[i];
											
										$scope.totalSharePer=parseInt($scope.totalSharePer)+parseInt($scope.claim.addClaims[i].beneficiary[j].sharePercentage);									
										
										if($scope.beneficiaryNameShow[i][j]==true){
											$scope.claim.addClaims[i].beneficiary[j].beneficiaryName="";
										}
											if($scope.appointeeShow[i][j]==true){
												$scope.claim.addClaims[i].beneficiary[j].appointeeName="";	
										}
										
										}
										
											if(parseInt($scope.totalSharePer)!=100)
											{		
												ajaxHttpFactory.showErrorSuccessMessagePopup("Beneficiary Share% should be 100% . ","errorMessage-popup", "claimsAlert");	
												return false;
											}																			
									
											
										}
										claimlength= claimlength+1;
										if(claimlength == fileCount){	
										var finalJson=angular.toJson($scope.claim);
										var ajaxurl = $location.absUrl();
									ajaxHttpFactory.postJsonDataSuccessFailure(finalJson, "POST", ajaxurl,"Submit", $scope.successMethod,$scope.failureMethod);
											}
										}
										
									
										 else{
											ajaxHttpFactory.showErrorSuccessMessagePopup("Commutation and annuity should be 100% . ","errorMessage-popup", "claimsAlert");
										}
									}
									
									else{
										ajaxHttpFactory.showErrorSuccessMessagePopup("Please upload file ","errorMessage-popup", "claimsAlert");
										return false;
									}
										
									}
									}
									else
										ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill all mandatory details","errorMessage-popup", "claimsAlert");																	
									

									};
									
									$scope.checkAnnuityValidation = function(){
										if($scope.productType != "TERM"){
											for(var i=0;i<=$scope.claimCount;i++){
											if(parseInt($scope.claim.addClaims[i].annuity) + parseInt($scope.claim.addClaims[i].commutation)!=100){											
												return false;
											}
										}
										}
										
										return true;
									};
								
									
									$scope.upload = function(upId,docType) {
										var parentIndex=(upId.id).substr(upId.id.length - 1);
										parentIndexForUploadFile=parentIndex;
										$scope.preloaderCheck=false;
								        var desc_Id = angular.element(document
								            .querySelector('#' + upId.id+'_errMsg'));
								        var upload_Msg = angular.element(document
								            .querySelector('#' + upId.id+'_upText'));
								     
								            if(upId.files.length != 0){  
								            	upload_Msg[0].innerHTML="";	
								            	desc_Id[0].innerHTML="";
								            	$scope.allowedExtensions=["PDF","pdf","TIFF","tiff","JPG","jpg","JPEG" ,"jpeg" ,"xls","XLS","xlsx","XLSX"];
								            	csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,$scope.functionalityId,$scope.fileUploadCallBack,$scope.policynumber,'Upload File',$scope.allowedExtensions);
								            }
								         
										};
										
								
								            $scope.fileUploadCallBack = function(uploadFileJsonResp, fileId, upload_Msg,message) {
								            	
								            	if(uploadFileJsonResp=="ERROR")
								            	{
								            	
								          	    upload_Msg[0].innerHTML =  message;
								          	  $scope.claim.addClaims[parentIndexForUploadFile].uploadFileList=[];
								            	
								            	return false;
								            	}
								            	
								            	else
								            		{
								    	        var fileUploadResJsonObj = angular.fromJson(uploadFileJsonResp);
								    	        if (fileUploadResJsonObj != null &&
								    	            fileUploadResJsonObj != '' && fileUploadResJsonObj != "") {
								    
								    				if(fileUploadResJsonObj.errorCode!=undefined)
								    				{
								    					ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
								    				}
								    				else
								    				{
								    					 $scope.claim.addClaims[parentIndexForUploadFile].uploadFileList=[];
								    	        	for(var i=0;i<fileUploadResJsonObj.length;i++)
								    	        		{
								    	  
								    	        		if(angular.fromJson(fileUploadResJsonObj[i]).errorCode=="0")
								    	        		{
								    	        	   $scope.claim.addClaims[parentIndexForUploadFile].uploadFileList.push(angular.fromJson(fileUploadResJsonObj[i]));

								       	            if(fileId.length==1)
								       	            	{
								       	             upload_Msg[0].innerHTML =  "Document uploaded successfully.";
								       	            	}
								       	            else if(fileId.length>1)
								       	            	{
								       	            	upload_Msg[0].innerHTML =  "Documents uploaded successfully.";
								       	            	}
								    	        		}
								    	        		else
								    	        		{
								    	        			ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
								    	        		}
								    	        		}
								    	         
								    	           }
								    	            
								    	        } else {
								    	          
								    	            ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup", "SuccessAlert");
								    	        }
								    	        
								            		}
								    	        $rootScope.preloaderCheck=false;
								    	    };
								    	    
								    	    $scope.checkDate= function(currentElement,errorMsgElement){
								    	    	if(angular.element(document.getElementById(currentElement)).val()=="")
								    	    		{
								    	    		angular.element(document.getElementById(currentElement)).addClass('invalid1');
								    	    		angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
								    	    		return false;
								    	    		}
								    	    	else
								    	    		{
								    	    		angular.element(document.getElementById(currentElement)).removeClass('invalid1');
								    	    		angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
								    	    		}
								    	    	return true;
								    	    		
								    	    	};
								    	    
								    	    $scope.successMethod = function(response) {	
								    	    	$rootScope.preloaderCheck=false;
								    	    	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
								    	    	if (response != null && response != "null") {
								    	    		var requestId=angular.fromJson(response);
								    	    		$rootScope.openAlertID1 = true;
								    	    		$scope.action="success";
								    	    		$scope.message = "Your request has been submitted successfully";								    	    	
								    	    	}
								    	    	}
													};																								
													
													$scope.failureMethod=function(){														
														$rootScope.preloaderCheck=false;														
														$rootScope.openAlertID1 = true;
														$scope.action="failure";
														$scope.message = "Some Error Occured.";
													};
								
								
							}]);
							