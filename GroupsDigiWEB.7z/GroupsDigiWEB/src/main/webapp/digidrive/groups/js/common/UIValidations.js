var uiValidationApp = angular.module('uiValidations',['generalUtility'])
uiValidationApp.directive("validateField",function(generalUtilityService){
	return{
		restrict:"A",
		link:function(scope,element,attrs){
		  
			var validateObj = (attrs.validateField == "")?"": eval('(' + attrs.validateField + ')');
			var regex="";
			var restrict_regex = "";
			if(angular.isDefined(validateObj) && validateObj !=""){
				
				if(angular.isDefined(validateObj.type) && validateObj.type !=""){
					regex = regexArr[validateObj.type.toUpperCase()+"_VALIDATION"];
					restrict_regex = restrictregexArr[validateObj.type.toUpperCase()+"_RESTRICT_VALIDATION"];
				}
				//enters all mandatory fields in errorArray on page load
				if(angular.isDefined(validateObj.ismandatory) && validateObj.ismandatory !="" && validateObj.ismandatory == "true"){
					scope.errorArray.push(attrs.id);
				}
				
				var errDiv = angular.element(document.querySelector('#'+attrs.id+'_errMsg'));
				
				element.bind(validateObj.eventType,function(){
					var formattedValue = element.val();
					if((attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'percentage')){
						element.val(element.val().trim());
						formattedValue = element.val();
					}				
					if(validateObj.type == 'number'){
						formattedValue = generalUtilityService.removeComma(element.val());
					}else if(validateObj.type == 'name'){
						element.val(element.val().trim());
						formattedValue = element.val().toUpperCase();
					}
					
					
				    
					errDiv = angular.element(document.querySelector('#'+attrs.id+'_errMsg'));
					//mandatory fields filled or not   
					if(validateObj.ismandatory=="true" && (formattedValue == null || formattedValue == "")){
						addInvalidClass(element,errDiv);
						if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
							errDiv.text(validateObj.errorMsg);
						}else{
							errDiv.text('Please Enter '+ attrs.title);
						}
						if(scope.errorArray.indexOf(attrs.id) == -1){
							scope.errorArray.push(attrs.id);
						}
					}
					else if((attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'percentage' || attrs.type == 'password') && formattedValue!="" && !regex.test(formattedValue)){
						
						addInvalidClass(element,errDiv);
						if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
							errDiv.text(validateObj.errorMsg);
						}else{
							errDiv.text('Please Enter Valid '+ attrs.title);
						}
						var regex_ConsecutiveLetter = regexArr['TWO_CONSEC_IDENTICAL_CHAR_VALIDATION'];
						if(validateObj.type == 'name' && regex_ConsecutiveLetter.test(formattedValue)){
							errDiv.text('More Than Two Same Consecutive Characters Not Allowed');
//								errDiv.text('More than Two Same Consecutive Letters are not allowed in '+ attrs.title);
						}
						if(scope.errorArray.indexOf(attrs.id) == -1){
							scope.errorArray.push(attrs.id);
						}
					}else if((attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'password') && formattedValue!="" && regex.test(formattedValue)){
						 removeInvalidClass(element,errDiv);
						if(scope.errorArray.indexOf(attrs.id) != -1){
							scope.errorArray.splice(scope.errorArray.indexOf(attrs.id),1);
						}
					}
					if(validateObj.ismandatory=="false" && (formattedValue == null || formattedValue == "")){
						 removeInvalidClass(element,errDiv);
						 if(scope.errorArray.indexOf(attrs.id) != -1){
								scope.errorArray.splice(scope.errorArray.indexOf(attrs.id),1);
							}
					}
					
					//Text Field minLength & maxLength Checks
					
					if(angular.isDefined(element.attr("maxlength")) && element.attr("maxlength") != ""){
						validateObj.maxLength = element.attr("maxlength");
					}

					if(angular.isDefined(validateObj.minLength) && validateObj.minLength!="" 
						&& angular.isDefined(validateObj.maxLength) && validateObj.maxLength!="" 
						&&  (attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'password') && formattedValue != ""){
						
						
						if(validateObj.minLength == validateObj.maxLength){
							if(formattedValue.length<validateObj.minLength || formattedValue.length>validateObj.maxLength)
							{
								addInvalidClass(element,errDiv);
								if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
									errDiv.text(validateObj.errorMsg);
								}else{
									errDiv.text(attrs.title+" should be of length "+validateObj.minLength);
								}
								
								if(scope.errorArray.indexOf(attrs.id) == -1){
									scope.errorArray.push(attrs.id);
								}
								
							}else if(formattedValue.length == validateObj.minLength && regex.test(formattedValue)){
								removeInvalidClass(element,errDiv);
								if(scope.errorArray.indexOf(attrs.id) != -1){
									scope.errorArray.splice(scope.errorArray.indexOf(attrs.id),1);
								}
							}
						}
						else if(formattedValue.length<validateObj.minLength || formattedValue.length>validateObj.maxLength){
							addInvalidClass(element,errDiv);
							if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
								errDiv.text(validateObj.errorMsg);
							}else{
								errDiv.text(attrs.title +" should be between "+validateObj.minLength+" and "+validateObj.maxLength+" characters");
							}
							
							if(scope.errorArray.indexOf(attrs.id) == -1){
								scope.errorArray.push(attrs.id);
							}
						}
						else if(formattedValue.length>=validateObj.minLength && formattedValue.length<=validateObj.maxLength && regex.test(formattedValue)){
	 						removeInvalidClass(element,errDiv);
							if(scope.errorArray.indexOf(attrs.id) != -1){
								scope.errorArray.splice(scope.errorArray.indexOf(attrs.id),1);
							}
	 					}
					}
					else if(angular.isDefined(validateObj.minLength) && validateObj.minLength!="" && (attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'password') && formattedValue != ""){
						if(formattedValue.length<validateObj.minLength){
							addInvalidClass(element,errDiv);
							if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
								errDiv.text(validateObj.errorMsg);
							}else{
								errDiv.text(attrs.title+" should be of minimum length "+validateObj.minLength);
							}
							
							if(scope.errorArray.indexOf(attrs.id) == -1){
								scope.errorArray.push(attrs.id);
							}
						}
						else if(formattedValue.length>=validateObj.minLength && regex.test(formattedValue)){
	 						removeInvalidClass(element,errDiv);
							if(scope.errorArray.indexOf(attrs.id) != -1){
								scope.errorArray.splice(scope.errorArray.indexOf(attrs.id),1);
							}
	 					}
					}else if(angular.isDefined(validateObj.maxLength) && validateObj.maxLength!="" && (attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'password') && formattedValue != ""){
						if(formattedValue.length>validateObj.maxLength){
							addInvalidClass(element,errDiv);
							if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
								errDiv.text(validateObj.errorMsg);
							}else{
								errDiv.text(attrs.title+" should be of maximum length "+validateObj.maxLength);
							}
							
							if(scope.errorArray.indexOf(attrs.id) == -1){
								scope.errorArray.push(attrs.id);
							}
						}
						else if(formattedValue.length<=validateObj.maxLength && regex.test(formattedValue)){
	 						removeInvalidClass(element,errDiv);
							if(scope.errorArray.indexOf(attrs.id) != -1){
								scope.errorArray.splice(scope.errorArray.indexOf(attrs.id),1);
							}
	 					}
					}
					
					//checking max Range
					if(angular.isDefined(validateObj.maxRange) && validateObj.maxRange != ""){
						//validateObj.maxRange = element.attr("maxRange");
						
						formattedValue = generalUtilityService.removeComma(element.val());
						
						if(!isNaN(validateObj.maxRange) && parseInt(formattedValue)>parseInt(validateObj.maxRange)){
							addInvalidClass(element,errDiv);
							if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
								errDiv.text(validateObj.errorMsg);
							}else{
								errDiv.text(attrs.title+" should not be greater than "+validateObj.maxRange);
							}
							
							if(scope.errorArray.indexOf(attrs.id) == -1){
								scope.errorArray.push(attrs.id);
							}
						}
						/*else if(formattedValue.length<=validateObj.maxLength && regex.test(formattedValue)){
	 						removeInvalidClass(element,errDiv);
							if(scope.errorArray.indexOf(attrs.id) != -1){
								scope.errorArray.splice(scope.errorArray.indexOf(attrs.id),1);
							}
	 					}*/

					
					}
					
					
					//checking max Range ends
					
					//Select (DropDown) fields Check
	 				if(element.prop('tagName')=='SELECT'){
	 					if(angular.isUndefined(formattedValue) || formattedValue == "" || formattedValue == "-" || formattedValue.indexOf("?") != -1){
	 						addInvalidClass(element,errDiv);
	 						if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
	 							errDiv.text(validateObj.errorMsg);
	 						}else{
	 							errDiv.text("Please Select "+ attrs.title);
	 						}
	 						
	 						if(scope.errorArray.indexOf(attrs.id) == -1){
	 							scope.errorArray.push(attrs.id);
	 						}
	 					}
	 					else {
	 						removeInvalidClass(element,errDiv);
	 						if(scope.errorArray.indexOf(attrs.id) != -1){
	 							scope.errorArray.splice(scope.errorArray.indexOf(attrs.id),1);
	 						}
	 					}
	 				}
	 				
	 				//Radio fields Checks
	 				if(element.prop('tagName') == 'DIV'){
	 					var elementChildRadios = element[0].querySelectorAll('input[type=radio]:checked');
	 					if(angular.isUndefined(elementChildRadios) || elementChildRadios.length <1){
	 						
	 						addInvalidClass(element,errDiv);
	 						if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
	 							errDiv.text(validateObj.errorMsg);
	 						}else{
	 							errDiv.text("Please Select "+ attrs.title);
	 						}
	 						
	 						if(scope.errorArray.indexOf(attrs.id) == -1){
		 							scope.errorArray.push(attrs.id);
		 					}
	 						
	 					}else{
	 						
	 						removeInvalidClass(element,errDiv);
	 						if(scope.errorArray.indexOf(attrs.id) != -1){
	 							scope.errorArray.splice(scope.errorArray.indexOf(attrs.id),1);
	 						}
	 					}
	 				}
	 				
			});
			
			//Restrict Inputs fields (Uses Restrict_Regex)
			if(attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'password'){
				element.bind('keypress',function(event){
					var keyCode = event.which;
			        var keyCodeChar = String.fromCharCode(keyCode);
			        if(allowBasicKeys.indexOf(keyCode) != -1){
 			          /* allow basic keys like backspace,space,delete */
			          }else if(!keyCodeChar.match(restrict_regex)){
			                event.preventDefault();
			          }
			         
 
				});
				
			}
			
			if(validateObj.type.toUpperCase() == 'ANNUALINCOME' || validateObj.type.toUpperCase() == 'BENEFITSHARE' || validateObj.type.toUpperCase() == 'WEIGHT_HQ'){
				element.bind('keyup keypress',function(event){
					if(element.val != null && element.val != undefined && element.val != ""){
						var leadingzero=new RegExp(/^[0]+/g);
						if(leadingzero.test(generalUtilityService.removeComma(element.val()))){
							//var value = generalUtilityService.removeComma(element.val()).replace(/^0*/,'');
							var value = element.val().replace(/^[0,]+/g,'');
							element.val(value);
						}
					}
				
			});
			}
			
			if(attrs.type == 'percentage' || attrs.type == 'percentage')
			{
			  element.bind('keypress',function(event){
			    var formattedValue = (validateObj.type == 'number')?generalUtilityService.removeComma(element.val()):element.val();
			    var keyCode = event.which;
          var keyCodeChar = String.fromCharCode(keyCode);
          if(allowBasicKeys.indexOf(keyCode) != -1){
            /* allow basic keys like backspace,space,delete */
            }else if(!restrict_regex.test(formattedValue+''+keyCodeChar)){
                  event.preventDefault();
            }
          //formattedValue = ''+ 
			  });
			}
			
			
			//Radio Fields Binded with Change Event to remove Error in case of selected
			if(validateObj.type == "radio"){
				var elementChildRadios = element[0].querySelectorAll('input[type=radio]');
				if(angular.isDefined(elementChildRadios) && elementChildRadios.length>0){
					for(var i=0;i<elementChildRadios.length;i++){
						var elem = angular.element(elementChildRadios[i]);
						
						elem.bind('change',function(value){
							if(angular.isDefined(value) && value !=""){
								removeInvalidClass(element,errDiv);
		 						if(scope.errorArray.indexOf(attrs.id) != -1){
		 							scope.errorArray.splice(scope.errorArray.indexOf(attrs.id),1);
		 						}
							}else{
								addInvalidClass(element,errDiv);
		 						if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
		 							errDiv.text(validateObj.errorMsg);
		 						}else{
		 							errDiv.text("Please Select ");
		 						}
		 						
		 						if(scope.errorArray.indexOf(attrs.id) == -1){
			 							scope.errorArray.push(attrs.id);
			 					}
							}
						});
					}
				}
			}
	
			
		 
	   }
	 }
	};
});

uiValidationApp.directive("modalValidateField",function(generalUtilityService){
	return{
		restrict:"A",
		link:function(scope,element,attrs){
		  
			var validateObj = (attrs.modalValidateField == "")?"": eval('(' + attrs.modalValidateField + ')');
			var regex="";
			var restrict_regex = "";
			if(angular.isDefined(validateObj) && validateObj !=""){
				
				if(angular.isDefined(validateObj.type) && validateObj.type !=""){
					regex = regexArr[validateObj.type.toUpperCase()+"_VALIDATION"];
					restrict_regex = restrictregexArr[validateObj.type.toUpperCase()+"_RESTRICT_VALIDATION"];
				}
				//enters all mandatory fields in errorArray on page load
				if(angular.isDefined(validateObj.ismandatory) && validateObj.ismandatory !="" && validateObj.ismandatory == "true"){
					scope.modalErrorArray.push(attrs.id);
				}
				
				var errDiv = angular.element(document.querySelector('#'+attrs.id+'_errMsg'));
				
				element.bind(validateObj.eventType,function(){
					var formattedValue = element.val();
					if((attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'percentage')){
						element.val(element.val().trim());
						formattedValue = element.val();
					}				
					if(validateObj.type == 'number'){
						formattedValue = generalUtilityService.removeComma(element.val());
					}else if(validateObj.type == 'name'){
						element.val(element.val().trim());
						formattedValue = element.val().toUpperCase();
					}
					
					
				    
					errDiv = angular.element(document.querySelector('#'+attrs.id+'_errMsg'));
					//mandatory fields filled or not   
					if(validateObj.ismandatory=="true" && (formattedValue == null || formattedValue == "")){
						addInvalidClass(element,errDiv);
						if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
							errDiv.text(validateObj.errorMsg);
						}else{
							errDiv.text('Please Enter '+ attrs.title);
						}
						if(scope.modalErrorArray.indexOf(attrs.id) == -1){
							scope.modalErrorArray.push(attrs.id);
						}
					}
					else if((attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'percentage' || attrs.type == 'password') && formattedValue!="" && !regex.test(formattedValue)){
						
						addInvalidClass(element,errDiv);
						if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
							errDiv.text(validateObj.errorMsg);
						}else{
							errDiv.text('Please Enter Valid '+ attrs.title);
						}
						var regex_ConsecutiveLetter = regexArr['TWO_CONSEC_IDENTICAL_CHAR_VALIDATION'];
						if(validateObj.type == 'name' && regex_ConsecutiveLetter.test(formattedValue)){
							errDiv.text('More Than Two Same Consecutive Characters Not Allowed');
//								errDiv.text('More than Two Same Consecutive Letters are not allowed in '+ attrs.title);
						}
						if(scope.modalErrorArray.indexOf(attrs.id) == -1){
							scope.modalErrorArray.push(attrs.id);
						}
					}else if((attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'password') && formattedValue!="" && regex.test(formattedValue)){
						 removeInvalidClass(element,errDiv);
						if(scope.modalErrorArray.indexOf(attrs.id) != -1){
							scope.modalErrorArray.splice(scope.modalErrorArray.indexOf(attrs.id),1);
						}
					}
					if(validateObj.ismandatory=="false" && (formattedValue == null || formattedValue == "")){
						 removeInvalidClass(element,errDiv);
						 if(scope.modalErrorArray.indexOf(attrs.id) != -1){
								scope.modalErrorArray.splice(scope.modalErrorArray.indexOf(attrs.id),1);
							}
					}
					
					//Text Field minLength & maxLength Checks
					
					if(angular.isDefined(element.attr("maxlength")) && element.attr("maxlength") != ""){
						validateObj.maxLength = element.attr("maxlength");
					}

					if(angular.isDefined(validateObj.minLength) && validateObj.minLength!="" 
						&& angular.isDefined(validateObj.maxLength) && validateObj.maxLength!="" 
						&&  (attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'password') && formattedValue != ""){
						
						
						if(validateObj.minLength == validateObj.maxLength){
							if(formattedValue.length<validateObj.minLength || formattedValue.length>validateObj.maxLength)
							{
								addInvalidClass(element,errDiv);
								if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
									errDiv.text(validateObj.errorMsg);
								}else{
									errDiv.text(attrs.title+" should be of length "+validateObj.minLength);
								}
								
								if(scope.modalErrorArray.indexOf(attrs.id) == -1){
									scope.modalErrorArray.push(attrs.id);
								}
								
							}else if(formattedValue.length == validateObj.minLength && regex.test(formattedValue)){
								removeInvalidClass(element,errDiv);
								if(scope.modalErrorArray.indexOf(attrs.id) != -1){
									scope.modalErrorArray.splice(scope.modalErrorArray.indexOf(attrs.id),1);
								}
							}
						}
						else if(formattedValue.length<validateObj.minLength || formattedValue.length>validateObj.maxLength){
							addInvalidClass(element,errDiv);
							if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
								errDiv.text(validateObj.errorMsg);
							}else{
								errDiv.text(attrs.title +" should be between "+validateObj.minLength+" and "+validateObj.maxLength+" characters");
							}
							
							if(scope.modalErrorArray.indexOf(attrs.id) == -1){
								scope.modalErrorArray.push(attrs.id);
							}
						}
						else if(formattedValue.length>=validateObj.minLength && formattedValue.length<=validateObj.maxLength && regex.test(formattedValue)){
	 						removeInvalidClass(element,errDiv);
							if(scope.modalErrorArray.indexOf(attrs.id) != -1){
								scope.modalErrorArray.splice(scope.modalErrorArray.indexOf(attrs.id),1);
							}
	 					}
					}
					else if(angular.isDefined(validateObj.minLength) && validateObj.minLength!="" && (attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'password') && formattedValue != ""){
						if(formattedValue.length<validateObj.minLength){
							addInvalidClass(element,errDiv);
							if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
								errDiv.text(validateObj.errorMsg);
							}else{
								errDiv.text(attrs.title+" should be of minimum length "+validateObj.minLength);
							}
							
							if(scope.modalErrorArray.indexOf(attrs.id) == -1){
								scope.modalErrorArray.push(attrs.id);
							}
						}
						else if(formattedValue.length>=validateObj.minLength && regex.test(formattedValue)){
	 						removeInvalidClass(element,errDiv);
							if(scope.modalErrorArray.indexOf(attrs.id) != -1){
								scope.modalErrorArray.splice(scope.modalErrorArray.indexOf(attrs.id),1);
							}
	 					}
					}else if(angular.isDefined(validateObj.maxLength) && validateObj.maxLength!="" && (attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'password') && formattedValue != ""){
						if(formattedValue.length>validateObj.maxLength){
							addInvalidClass(element,errDiv);
							if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
								errDiv.text(validateObj.errorMsg);
							}else{
								errDiv.text(attrs.title+" should be of maximum length "+validateObj.maxLength);
							}
							
							if(scope.modalErrorArray.indexOf(attrs.id) == -1){
								scope.modalErrorArray.push(attrs.id);
							}
						}
						else if(formattedValue.length<=validateObj.maxLength && regex.test(formattedValue)){
	 						removeInvalidClass(element,errDiv);
							if(scope.modalErrorArray.indexOf(attrs.id) != -1){
								scope.modalErrorArray.splice(scope.modalErrorArray.indexOf(attrs.id),1);
							}
	 					}
					}
					
					//checking max Range
					if(angular.isDefined(validateObj.maxRange) && validateObj.maxRange != ""){
						//validateObj.maxRange = element.attr("maxRange");
						
						formattedValue = generalUtilityService.removeComma(element.val());
						
						if(!isNaN(validateObj.maxRange) && parseInt(formattedValue)>parseInt(validateObj.maxRange)){
							addInvalidClass(element,errDiv);
							if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
								errDiv.text(validateObj.errorMsg);
							}else{
								errDiv.text(attrs.title+" should not be greater than "+validateObj.maxRange);
							}
							
							if(scope.modalErrorArray.indexOf(attrs.id) == -1){
								scope.modalErrorArray.push(attrs.id);
							}
						}
						/*else if(formattedValue.length<=validateObj.maxLength && regex.test(formattedValue)){
	 						removeInvalidClass(element,errDiv);
							if(scope.modalErrorArray.indexOf(attrs.id) != -1){
								scope.modalErrorArray.splice(scope.modalErrorArray.indexOf(attrs.id),1);
							}
	 					}*/

					
					}
					
					
					//checking max Range ends
					
					//Select (DropDown) fields Check
	 				if(element.prop('tagName')=='SELECT'){
	 					if(angular.isUndefined(formattedValue) || formattedValue == "" || formattedValue == "-" || formattedValue.indexOf("?") != -1){
	 						addInvalidClass(element,errDiv);
	 						if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
	 							errDiv.text(validateObj.errorMsg);
	 						}else{
	 							errDiv.text("Please Select "+ attrs.title);
	 						}
	 						
	 						if(scope.modalErrorArray.indexOf(attrs.id) == -1){
	 							scope.modalErrorArray.push(attrs.id);
	 						}
	 					}
	 					else {
	 						removeInvalidClass(element,errDiv);
	 						if(scope.modalErrorArray.indexOf(attrs.id) != -1){
	 							scope.modalErrorArray.splice(scope.modalErrorArray.indexOf(attrs.id),1);
	 						}
	 					}
	 				}
	 				
	 				//Radio fields Checks
	 				if(element.prop('tagName') == 'DIV'){
	 					var elementChildRadios = element[0].querySelectorAll('input[type=radio]:checked');
	 					if(angular.isUndefined(elementChildRadios) || elementChildRadios.length <1){
	 						
	 						addInvalidClass(element,errDiv);
	 						if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
	 							errDiv.text(validateObj.errorMsg);
	 						}else{
	 							errDiv.text("Please Select "+ attrs.title);
	 						}
	 						
	 						if(scope.modalErrorArray.indexOf(attrs.id) == -1){
		 							scope.modalErrorArray.push(attrs.id);
		 					}
	 						
	 					}else{
	 						
	 						removeInvalidClass(element,errDiv);
	 						if(scope.modalErrorArray.indexOf(attrs.id) != -1){
	 							scope.modalErrorArray.splice(scope.modalErrorArray.indexOf(attrs.id),1);
	 						}
	 					}
	 				}
	 				
			});
			
			//Restrict Inputs fields (Uses Restrict_Regex)
			if(attrs.type == 'text' || element.prop('tagName')=='TEXTAREA' || attrs.type == 'password'){
				element.bind('keypress',function(event){
					var keyCode = event.which;
			        var keyCodeChar = String.fromCharCode(keyCode);
			        if(allowBasicKeys.indexOf(keyCode) != -1){
 			          /* allow basic keys like backspace,space,delete */
			          }else if(!keyCodeChar.match(restrict_regex)){
			                event.preventDefault();
			          }
			         
 
				});
				
			}
			
			if(validateObj.type.toUpperCase() == 'ANNUALINCOME' || validateObj.type.toUpperCase() == 'BENEFITSHARE' || validateObj.type.toUpperCase() == 'WEIGHT_HQ'){
				element.bind('keyup keypress',function(event){
					if(element.val != null && element.val != undefined && element.val != ""){
						var leadingzero=new RegExp(/^[0]+/g);
						if(leadingzero.test(generalUtilityService.removeComma(element.val()))){
							//var value = generalUtilityService.removeComma(element.val()).replace(/^0*/,'');
							var value = element.val().replace(/^[0,]+/g,'');
							element.val(value);
						}
					}
				
			});
			}
			
			if(attrs.type == 'percentage' || attrs.type == 'percentage')
			{
			  element.bind('keypress',function(event){
			    var formattedValue = (validateObj.type == 'number')?generalUtilityService.removeComma(element.val()):element.val();
			    var keyCode = event.which;
          var keyCodeChar = String.fromCharCode(keyCode);
          if(allowBasicKeys.indexOf(keyCode) != -1){
            /* allow basic keys like backspace,space,delete */
            }else if(!restrict_regex.test(formattedValue+''+keyCodeChar)){
                  event.preventDefault();
            }
          //formattedValue = ''+ 
			  });
			}
			
			
			//Radio Fields Binded with Change Event to remove Error in case of selected
			if(validateObj.type == "radio"){
				var elementChildRadios = element[0].querySelectorAll('input[type=radio]');
				if(angular.isDefined(elementChildRadios) && elementChildRadios.length>0){
					for(var i=0;i<elementChildRadios.length;i++){
						var elem = angular.element(elementChildRadios[i]);
						
						elem.bind('change',function(value){
							if(angular.isDefined(value) && value !=""){
								removeInvalidClass(element,errDiv);
		 						if(scope.modalErrorArray.indexOf(attrs.id) != -1){
		 							scope.modalErrorArray.splice(scope.modalErrorArray.indexOf(attrs.id),1);
		 						}
							}else{
								addInvalidClass(element,errDiv);
		 						if(angular.isDefined(validateObj.errorMsg) && validateObj.errorMsg != "null" && validateObj.errorMsg!=""){
		 							errDiv.text(validateObj.errorMsg);
		 						}else{
		 							errDiv.text("Please Select ");
		 						}
		 						
		 						if(scope.modalErrorArray.indexOf(attrs.id) == -1){
			 							scope.modalErrorArray.push(attrs.id);
			 					}
							}
						});
					}
				}
			}
	
			
		 
	   }
	 }
	};
});

//Adds Invalid Class to the Element
function addInvalidClass(currentElement,errorMsgElement){
	currentElement.addClass('invalid1');
	errorMsgElement.css('visibility','visible');
	
}

//Removes Invalid Class from the Element
function removeInvalidClass(currentElement,errorMsgElement){
	currentElement.removeClass('invalid1');
	errorMsgElement.css('visibility','hidden');
}