var app = angular.module('groupApp',['ajaxUtil','ui.materialize','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection']);

app.controller('contributionHistoryController',['$rootScope','$scope','$location','ajaxHttpFactory','uiGridConstants',function($rootScope, $scope,$location,ajaxHttpFactory,uiGridConstants){

	$scope.absUrl =window.location.origin + window.location.pathname+window.location.search;
	$scope.contributionHistoryData=[];
	 $scope.contributionHistroy={};
	

	var paginationOptions = {
		    pageNumber: 1,
		    pageSize: 10,
		    sort: null
		  };
	
	var getContributionHistoryData = function () { 
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("getContributionHistoryData",$scope.absUrl)
		.then(function(response) {
		$rootScope.preloaderCheck=false;
		if (response != null && response != "null") {
			var responseData = response.data;
			$scope.contributionHistoryData = responseData;
			$scope.contributionHistroy.totalItems=$scope.contributionHistoryData.length;
			getPage();
			
			
		}
	},
	function(errResponse) {
		$rootScope.preloaderCheck=false;
		console.error('Error while fetching profile details.');

	});

};


getContributionHistoryData();


var getPage = function() {
	   var firstRow = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
	   $scope.contributionHistroy.data = $scope.contributionHistoryData.slice(firstRow, firstRow + paginationOptions.pageSize);
}


$scope.contributionHistroy = {
	    paginationPageSizes: [10],
	    paginationPageSize: 10,
	    useExternalPagination: true,
	    useExternalSorting: true,
	    enableColumnMenus: false,
	    enableFiltering: true,
	    totalItems:$scope.contributionHistoryData.length,
	    enableRowSelection : true,
        multiSelect : false,
        enableRowHeaderSelection : false,
        
	    columnDefs: [
	      { field: 'transactionDate', displayName: 'Date', width: "10%", resizable: false,enableSorting: false},
	      { field: 'fundType', displayName: 'Fund Type', width: "50%", resizable: false,enableSorting: false},
	      { field: 'amount', displayName: 'Amount (Rs.)', width: "20%", resizable: false,enableSorting: false,enableFiltering: false},
	      { field: 'nav', displayName: 'NAV', width: "7%", resizable: false,enableSorting: false,enableFiltering: false},
	      { field: 'units', displayName: 'Units', width: "13%", resizable: false,enableSorting: false,enableFiltering: false}
	      
	    
	      
	      
	    ],
	    onRegisterApi: function(gridApi) {
	      $scope.gridApi = gridApi;
	      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
	        paginationOptions.pageNumber = newPage;
	        paginationOptions.pageSize = pageSize;
	        getPage();
	      });
	   
	   

	    }
	  };






}]);












