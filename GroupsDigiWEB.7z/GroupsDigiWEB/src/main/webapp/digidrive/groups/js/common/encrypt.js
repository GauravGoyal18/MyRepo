
function ascii_value (c)
{
	// restrict input to a single character
	c = c . charAt (0);

	// loop through all possible ASCII values
	var i;
	for (i = 0; i < 256; ++ i)
	{
		// convert i into a 2-digit hex string
		var h = i . toString (16);
		if (h . length == 1)
			h = "0" + h;

		// insert a % character into the string
		h = "%" + h;

		// determine the character represented by the escape code
		h = unescape (h);

		// if the characters match, we've found the ASCII value
		if (h == c)
			break;
	}
	return i;
}

	function encryptFunction(oriVal)
	{	
		var len = oriVal.length;
		var encVal = new Array(1);
		var revVal = new Array(1);
		var finVal = new Array(1);
		var keyVal = 33;
		for(var i=0;i<len;i++)
		{
			
			oriVal.charAt(i);
			encVal = encVal + oriVal.charAt(i);
			encVal = encVal + String.fromCharCode(keyVal);
			keyVal++;
		}
		var i=encVal.length;
		i=i-1;
		for (var x = i; x >=0; x--)
			revVal = revVal + encVal.charAt(x);
		
		for(var i=0;i<revVal.length;i++)
		{
			var asciVal = ascii_value(revVal.charAt(i))+1;
			finVal = finVal + String.fromCharCode(asciVal); 
		}		
		
		oriVal=finVal
		
		min = 33;
		max = 99;
	    var keyVal =Math.floor(Math.random() * (max - min + 1)) + min;

		var len = oriVal.length;
		var encVal = new Array(1);
		
		for(var i=0;i<len;i++)
		{
			
			oriVal.charAt(i);
			encVal = encVal + oriVal.charAt(i);
			encVal = encVal + String.fromCharCode(keyVal);
			keyVal++;
		}
		var finVal=encVal;
		return finVal;
	}