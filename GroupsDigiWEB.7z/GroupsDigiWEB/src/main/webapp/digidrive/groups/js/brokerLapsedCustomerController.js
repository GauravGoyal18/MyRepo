var app=angular.module('groupApp',['ui.materialize','uiValidations','ajaxUtil','ngRoute','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection','groupCommonUtil']);

app.controller('brokerLapsedCustomerController',['$rootScope','$scope','ajaxHttpFactory','$location','$window','$filter','$http','$rootScope','uiGridConstants','csrDocUploadFactory', function($rootScope,$scope,ajaxHttpFactory,$location,$window,$filter,$http,$rootScope,uiGridConstants,csrDocUploadFactory){
	
	$rootScope.preloaderCheck=true;
	$scope.trackType=[];
	$scope.trackStatus=[];
	$scope.logs={};
	$scope.errorArray=[];

	$scope.successResponse='';
	var ajaxurl=$location.absUrl();
	$scope.result=[];
	$scope.brokerLapsedCustomerView={};
	$scope.brokerLapsedCustomerData=[];
	$scope.brokerLapsedCustomerDiv=false;
	
	
	
	 $scope.openClosed="openClose";
	 var paginationOptions = {
			    pageNumber: 1,
			    pageSize: 10,
			    sort: null
			  };
	 
	 
	var onLoadData=function(){			
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("loadLapsedCustomer",ajaxurl)
		.then(function(bizRes){	
			
			if(ajaxHttpFactory.handleIPruException(bizRes.data, "errorMessage-popup", "exceptionAlert")){
				
							
				$rootScope.preloaderCheck=false;
			}			
			var responseData = bizRes.data;
			$scope.brokerLapsedCustomerData=responseData;
			$scope.brokerLapsedCustomerView.totalItems=$scope.brokerLapsedCustomerData.length;

			
			$scope.brokerLapsedCustomerDiv=true;
			
			$scope.getPageOC();
			
			$rootScope.preloaderCheck=false;					
		},
		function(errResponse){
			$rootScope.preloaderCheck=false;
			if(ajaxHttpFactory.handleIPruException(bizRes.data, "errorMessage-popup", "exceptionAlert")){
				
			}
		});
};
	
onLoadData();
	

$scope.getPageOC = function() {
	 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
    $scope.brokerLapsedCustomerView.data=$scope.brokerLapsedCustomerData.slice(firstRow, firstRow + paginationOptions.pageSize);	     
   
	};

	 
	 $scope.brokerLapsedCustomerView = {			 				
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,			   
			    enableRowSelection: false,		      	     
		        resizable: false,
		        enableColumnResizing: false,
		        enableSorting: false,		       
		        
			    columnDefs: [
			      { field: 'policyNumber', displayName: 'Policy No',headerTooltip:function(col){return col.displayName;}, width: "15%"},
			      { field: 'policyStatus',displayName: 'Policy Status',headerTooltip:function(col){return col.displayName;}, width: "13%"},
			      { field: 'productName',  displayName: 'Product Name',headerTooltip:function(col){return col.displayName;}, width: "20%"},
			      { field: 'branchCode', displayName: 'Branch Code',width: "14%",headerTooltip:function(col){return col.displayName;}, width: "13%"},
			      { field: 'clientName', displayName: 'Client Name',headerTooltip:function(col){return col.displayName;}, width: "40%"},
			      { field: 'premiumAmount', displayName: 'Premium Amount',headerTooltip:function(col){return col.displayName;}, width: "15%"},
			      { field: 'rcd', displayName: 'RCD',headerTooltip:function(col){return col.displayName;}, width: "10%"},
			      
			     
			     	      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageOC();
			      });			      			 
			    }
			  };
	 
	
	
		
		
	
	



	
	$scope.dataAlert= function (){
		$rootScope.openAlertID = false;											
		$window.location.href = "dashboard.htm";
	};


	$scope.successMethod = function(bizRes) {		
		if(!ajaxHttpFactory.handleIPruException(bizRes, "errorMessage-popup", "exceptionAlert")){					
			$scope.result=bizRes;
			$rootScope.preloaderCheck=false;
		}
	};
		
	$scope.failureMethod = function(bizRes) {
		if(!ajaxHttpFactory.handleIPruException(bizRes, "errorMessage-popup", "exceptionAlert")){			
			$rootScope.preloaderCheck=false;
		}
	};	
    
	
	
	
	
}]);