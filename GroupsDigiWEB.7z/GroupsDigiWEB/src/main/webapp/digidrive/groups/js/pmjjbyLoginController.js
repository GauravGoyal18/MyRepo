var app = angular.module('groupApp',['ajaxUtil','ui.materialize','uiValidations']);
app.controller("pmjjbyLoginController",['$rootScope','$scope','$location','ajaxHttpFactory','$http','$interval','$timeout',
                                   function($rootScope, $scope,$location,ajaxHttpFactory,$http, $interval, $timeout){
	
		
		$rootScope.preloaderCheck=false;
		var ajaxurl=$location.absUrl();
		$scope.pmjjbyLogin = {};
		$scope.errorArray = [];
		var passwordnew = "";
		
		
		
		$scope.generateIpruKey = function (){
			var hashObj = new jsSHA("mySuperPassword"+Math.random(), "ASCII");
			passwordnew = hashObj.getHash("SHA-512", "HEX");
		
		    var x = Math.floor((Math.random()*15000000)+1);
		    $.jCryption.authenticate(passwordnew, "encrypt?generateKeyPair=true&rnd="+x, "encrypt?handshake=true&rnd="+x,

		                 function(AESKey) {                                                                                                               

		                 },

		                 function() {

		                        // Authentication failed
		              	   

		                 }
		    );
		};
		
		$scope.generateIpruKey();
		
		$scope.submitPMJJBYLogin = function() {
			$rootScope.preloaderCheck=true;
			
			//Validate
			$scope.message = "";
			$scope.message = $scope.validatePMJJBY($scope.pmjjbyLogin);
			
			//$scope.generateIpruKey();
			var encryptedString = $.jCryption.encrypt($scope.pmjjbyLogin.password, passwordnew);
		    
			$scope.pmjjbyLogin.password = encryptedString;
			if ($scope.message == "") {
				
				var pmjjbyLoginJson = angular.toJson($scope.pmjjbyLogin);
				
				console.log(pmjjbyLoginJson);
				
				var ajaxurl = $location.absUrl();
		
				ajaxHttpFactory.postJsonDataSuccessFailure(pmjjbyLoginJson, "POST", ajaxurl,"SubmitPMJJBYLogin", $scope.successMethod,$scope.failureMethod);
				
			}else {
				$scope.mandatCheck = true;
				$rootScope.preloaderCheck=false;
			}
			
			
		};	
		
		$scope.validatePMJJBY = function(pmjjbyLogin) {
						
			errorMessage = "";
			
			if(angular.isUndefined(pmjjbyLogin.userName) || pmjjbyLogin.userName == "")
			{
				errorMessage = "Please enter valid username";
			}
			
			else if(angular.isUndefined(pmjjbyLogin.password) || pmjjbyLogin.password == "")
			{
				errorMessage = "Please enter valid password";
			}
			
			return errorMessage;
		}
		
		
		$scope.successMethod=function(response)
		{
			
			if (response != null && response != "null"){
				if(!ajaxHttpFactory.handleIPruException(response, "", "pmjjbyLoginAlert")){
					//hide spinner
					$rootScope.preloaderCheck=false;
					
					if(response.resultMap  != null && response.resultMap != "null" && response.resultMap.authenticatedUser != null && response.resultMap.authenticatedUser != "null")
					
						if(response.resultMap.authenticatedUser.isValidUser != null && response.resultMap.authenticatedUser.isValidUser != "null" && response.resultMap.authenticatedUser.isValidUser == true){
//					ajaxHttpFactory.showErrorSuccessMessagePopup("User Authenticated "+response.resultMap.authenticatedUser.isValidUser);
							$scope.loggedInUserName = response.resultMap.authenticatedUser.givenName;
							ajaxHttpFactory.linkRedirectionUrl("pmjjbyLoginHome.htm");
						}
				}
			}
		};
		
		$scope.failureMethod=function(response){
			
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "pmjjbyLoginAlert")){
				
				ajaxHttpFactory.showErrorSuccessMessagePopup("Some Error Occured : ","errorMessage-popup", "pmjjbyLoginAlert");
				
			}
		};
		
		$scope.okAlert = function() {
			$scope.mandatCheck = false;
		};

}]);