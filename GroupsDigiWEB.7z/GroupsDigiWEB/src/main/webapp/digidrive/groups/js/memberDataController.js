//var app = angular.module('groupApp',['ajaxUtil','ui.materialize','datatables']);
var app = angular.module('groupApp',['ajaxUtil','ui.materialize','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection']);
app.controller('memberDataController',['$rootScope','$scope','$location','$http','ajaxHttpFactory','uiGridConstants',function($rootScope, $scope,$location,$http,ajaxHttpFactory,uiGridConstants){
	$rootScope.preloaderCheck=false;
	$scope.memberList = {};
	$scope.policyNo = '';
	$scope.role = '';
	$scope.productType = '';
	$scope.showTrustDiv = false;
	$scope.showGTrustDiv = false;
	$scope.showTermDiv = false;
	$scope.showTrustGratuityDiv = false;
	var ajaxurl=$location.absUrl();
	$scope.sqlQuery = '';
	$rootScope.trustModal = false;
	$scope.count='';
	$scope.submitFundModalData = {};
	$scope.memberFundDataList = [];
	$scope.absUrl=$location.absUrl();
	$scope.memberDetails = {};
	$scope.getMemberData={};
	 $scope.selectedItem = null;

	 $scope.trustgridOptions = {};
	 $scope.trustGratuitygridOptions = {};
	$scope.gridRowClick = function(member){
		$scope.memberFundDataList=[];

		$rootScope.preloaderCheck=true;
		$scope.submitFundModalData.policyNo = $scope.policyNo;
		$scope.submitFundModalData.role = $scope.role;
		$scope.submitFundModalData.selectedMember = member.entity;
		
		var submitFundModalDataString = angular.toJson($scope.submitFundModalData);
		
		ajaxHttpFactory.postJsonDataSuccessFailure(submitFundModalDataString,"POST",ajaxurl,"getMemberFundDetailJson",$scope.submitSuccessMethod,$scope.submitFailureMethod);
		
		
	};
	
	$scope.submitSuccessMethod = function(response) {
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			var memberFundDataListJson = angular.fromJson(response);
			
			$scope.memberFundDataList = memberFundDataListJson.memberFundDataPOList;
			
			$rootScope.trustModal = true;
			
		} else {
			$rootScope.preloaderCheck=false;
		}
	};
	
	$scope.close = function() {
		$rootScope.trustModal = false;
	}
	
	$scope.submitFailureMethod = function(response) {
		//alert("In failureMethod");
		$rootScope.preloaderCheck=false;	
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
				
		} else {
			$rootScope.preloaderCheck=false;
		}
	};
	
	var paginationOptions = {
		    pageNumber: 1,
		    pageSize: 100,
		    sort: null
		  };
	
		$scope.trustGratuitygridOptions = {
			    paginationPageSizes: [100],
			    paginationPageSize: 100,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableFiltering: true,
			    enableRowSelection : true,
	            multiSelect : false,
	            enableRowHeaderSelection : false,
	            totalItems:$scope.count,
	            resizable: false,
	            enableColumnResizing: false,
	            
	           
	            	columnDefs: [
	           			      { field: 'memberId', displayName: 'Member ID', width: "20%", enableSorting: false},
	           			      { field: 'memberName', displayName: 'Member Name', width: "40%", enableSorting: false},
	           			      { field: 'dateOfBirth', displayName: 'Date of Birth', width: "20%", enableSorting: false,enableFiltering: false},
	           			      { field: 'dateOfJoining', displayName: 'Date of Joining', width: "20%", enableSorting: false,enableFiltering: false},
	           			      
	           			    ],
	            
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;
			      // call resize every 500 ms for 5 s after modal finishes opening - usually only necessary on a bootstrap modal
			      /*$interval( function() {
			        $scope.gridApi.core.handleWindowResize();
			      }, 1000, 10);*/
			      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;
			        $scope.getPage();
			      });
			   
			   
 
			    }
			  };
	
		$scope.trustgridOptions = {
			    paginationPageSizes: [100],
			    paginationPageSize: 100,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableFiltering: true,
			    enableRowSelection : true,
	            multiSelect : false,
	            enableRowHeaderSelection : false,
	            totalItems:$scope.count,
	            resizable: false,
	            enableColumnResizing: false,
	            
	            
	            	
	            
	            	columnDefs: [
	            	          { field: 'memberId', displayName: 'Member ID', width: "15%", enableSorting: false},
	            	          { field: 'memberName', displayName: 'Member Name', width: "35%", enableSorting: false},
	            	          { field: 'units', displayName: 'Total Units', width: "15%", enableSorting: false,enableFiltering: false},
	            	          { field: 'dateOfJoining', displayName: 'Date of Joining', width: "15%", enableSorting: false,enableFiltering: false},
	            	          { field: 'Action', displayName: 'Action', width: "20%", enableSorting: false,enableFiltering: false,cellTemplate : '<div ><p> <a modal data-target = "trustMemberDataModal" data-dismissible="false" ready="onReady" open= "trustModal" complete="onComplete"  ng-click="grid.appScope.gridRowClick(row)" class="uigridbtn">Fund Details</a></p></div>'}
			      
	            	         ],
	 			
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;
			      // call resize every 500 ms for 5 s after modal finishes opening - usually only necessary on a bootstrap modal
			      /*$interval( function() {
			        $scope.gridApi.core.handleWindowResize();
			      }, 1000, 10);*/
			      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;
			        $scope.getPage();
			      });
			   
			   
 
			    }
			  };
	
	 
	 $scope.gtrustgridOptions = {
			    paginationPageSizes: [100],
			    paginationPageSize: 100,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableFiltering: true,
			    enableRowSelection : true,
	            multiSelect : false,
	            enableRowHeaderSelection : false,
	            totalItems:$scope.count,
	            
			    columnDefs: [
			      { field: 'memberId', displayName: 'Member ID', width: "13%", resizable: false,enableSorting: false},
			      { field: 'memberName', displayName: 'Member Name', width: "16%", resizable: false,enableSorting: false},
			      { field: 'dateOfJoining', displayName: 'Date of Joining', width: "18%", resizable: false,enableSorting: false,enableFiltering: false},
			      { field: 'coverProvided', displayName: 'Cover Provided', width: "18%", resizable: false,enableSorting: false,enableFiltering: false},
			      { field: 'coverRequested', displayName: 'Cover Requested', width: "18%", resizable: false,enableSorting: false,enableFiltering: false},
			      { field: 'medicalRequired', displayName: 'Medical Required', width: "17%", resizable: false,enableSorting: false,enableFiltering: false},
			      
			      
			      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;
			        $scope.getPage();
			      });
			   
			   

			    }
			  };
	 $scope.termgridOptions = {
			    paginationPageSizes: [100],
			    paginationPageSize: 100,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableFiltering: true,
			    enableRowSelection : true,
	            multiSelect : false,
	            enableRowHeaderSelection : false,
	            totalItems:$scope.count,
	            
			    columnDefs: [
			      { field: 'memberId', displayName: 'Member ID', width: "11%", resizable: false,enableSorting: false},
			      { field: 'memberName', displayName: 'Member Name', width: "21%", resizable: false,enableSorting: false},
			      { field: 'dateOfJoining', displayName: 'Date of Joining', width: "18%", resizable: false,enableSorting: false,enableFiltering: false},
			      { field: 'coverProvided', displayName: 'Cover Provided', width: "18%", resizable: false,enableSorting: false,enableFiltering: false},
			      { field: 'coverRequested', displayName: 'Cover Requested', width: "16%", resizable: false,enableSorting: false,enableFiltering: false},
			      { field: 'medicalRequired', displayName: 'Medical Required', width: "16%", resizable: false,enableSorting: false,enableFiltering: false},
			      
			      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;
			        $scope.getPage();
			      });
			   
			   

			    }
			  };

	 $scope.getPage = function() {
		 
		 $scope.max=paginationOptions.pageSize;
			
		 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
		 
	      $scope.offset = firstRow;
			$rootScope.preloaderCheck=true;
			
			$scope.getMemberData.max=  $scope.max;
			$scope.getMemberData.offset= $scope.offset ;
			
			
			 var getMemberDataJson=angular.toJson($scope.getMemberData);
			 $rootScope.preloaderCheck=true;
		 ajaxHttpFactory.postJsonDataSuccessFailure(getMemberDataJson,"POST",ajaxurl,"getMemberListJson",$scope.successMethod,$scope.failureMethod);
		};

	 
	 $scope.successMethod=function(response){
		 $rootScope.preloaderCheck=false;
		 if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
	 if (response != null && response != "null") {
			var memberListPO = response;
		$scope.memberList = memberListPO.memberPOList;
			$scope.policyNo = memberListPO.policyNo;
			var role = memberListPO.role;
			var memberType = memberListPO.memberType;
			var productType = memberListPO.productType;
			$scope.role = role;
			$scope.memberType = memberType;
			$scope.productType = productType;
			
			if(memberType=="TRUST")
				{
					if(productType=="GRATUITY"){
						$scope.showTrustDiv = false;
						$scope.showGTrustDiv = false;
						$scope.showTermDiv = false;
						$scope.showTrustGratuityDiv = true;
				      
						$scope.trustGratuitygridOptions.totalItems=$scope.count;
						 
				      $scope.trustGratuitygridOptions.data = $scope.memberList;
					} else {
						$scope.showTrustDiv = true;
						$scope.showGTrustDiv = false;
						$scope.showTermDiv = false;
						$scope.showTrustGratuityDiv = false;
				      
						$scope.trustgridOptions.totalItems=$scope.count;
						 
				      $scope.trustgridOptions.data = $scope.memberList;
					}				
		     
				}
			else if(memberType=="GTRUST"){
				$scope.showTrustDiv = false;
				$scope.showGTrustDiv = true;
				$scope.showTermDiv = false;
				$scope.showTrustGratuityDiv = false;
				 
				$scope.gtrustgridOptions.totalItems=$scope.count;
				 $scope.gtrustgridOptions.data = $scope.memberList;	
				}
			else if(memberType=="TERM")
					{
				
					$scope.showTrustDiv = false;
					$scope.showGTrustDiv = false;
					$scope.showTermDiv = true;
					$scope.showTrustGratuityDiv = false; 
					$scope.termgridOptions.totalItems=$scope.count;
					 $scope.termgridOptions.data= $scope.memberList;
					}		     
		}
	 }
	 };
	

		var getCount = function () { //new Insertion
			$rootScope.preloaderCheck=true;
			return ajaxHttpFactory.getJsonData("getMembercount",$scope.absUrl)
		.then(function(response) {
			$rootScope.preloaderCheck=false;
			if (response != null && response != "null") {
				var responseData = response.data;
				$scope.count = responseData;
				$scope.getPage();
				
			}
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});

	};
	getCount();
	 
	

$scope.downloadDataFromServer=function(){
	$rootScope.preloaderCheck=true;		

		
	$http({
        url: 'MemberDownloadServlet.do',
        method: 'POST',
        responseType: 'arraybuffer',
        data: JSON.stringify($scope.openClosed),
        headers: {
            'Content-type': 'application/json; charset=utf-8'
        }
    }).success(function(result) {
        var blob = new Blob([result], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        });
        var downloadUrl = URL.createObjectURL(blob);
        var a = document.createElement("a");
        a.href = downloadUrl;
        a.download = "memberdata.xls";
        document.body.appendChild(a);
        a.click();
        
        $rootScope.preloaderCheck=false;
    }).error(
        function() {
            // Some error log
           
        	$rootScope.preloaderCheck=false;
			ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ","errorMessage-popup", "memberdataalert");

        });
	
};
	 
		
	}]);