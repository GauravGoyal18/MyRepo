var app = angular.module('groupApp',['ajaxUtil','ui.materialize','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection']);

app.controller('retirementCalenderController',['$rootScope','$scope','$location','ajaxHttpFactory','uiGridConstants',function($rootScope, $scope,$location,ajaxHttpFactory,uiGridConstants){

	$scope.absUrl =window.location.origin + window.location.pathname+window.location.search;
	$scope.retirementCalenderData=[];
	$scope.retirementData={};
	

	var paginationOptions = {
		    pageNumber: 1,
		    pageSize: 10,
		    sort: null
		  };
	
	var getRetirementCalenderData = function () { 
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("getRetirementCalenderData",$scope.absUrl)
		.then(function(response) {
		$rootScope.preloaderCheck=false;
		if (response != null && response != "null") {
			var responseData = response.data;
			$scope.retirementCalenderData = responseData;
			$scope.retirementData.totalItems=$scope.retirementCalenderData.length;
			getPage();
			
			
		}
	},
	function(errResponse) {
		$rootScope.preloaderCheck=false;
		console.error('Error while fetching profile details.');

	});

};


getRetirementCalenderData();


var getPage = function() {
	   var firstRow = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
	   $scope.retirementData.data = $scope.retirementCalenderData.slice(firstRow, firstRow + paginationOptions.pageSize);
}


$scope.retirementData = {
	    paginationPageSizes: [10],
	    paginationPageSize: 10,
	    useExternalPagination: true,
	    useExternalSorting: true,
	    enableColumnMenus: false,
	    enableFiltering: true,
	    totalItems:$scope.retirementCalenderData.length,
	    enableRowSelection : true,
        multiSelect : false,
        enableRowHeaderSelection : false,
        
	    columnDefs: [
	      { field: 'employeeId', displayName: 'Employee ID', width: "15%", resizable: false,enableSorting: false},
	      { field: 'firstName', displayName: 'First Name', width: "40%", resizable: false,enableSorting: false},
	      { field: 'birthDate', displayName: 'Date of Birth', width: "15%", resizable: false,enableSorting: false,enableFiltering: false},
	      { field: 'retirementDate', displayName: 'Retirement Date', width: "30%", resizable: false,enableSorting: false,enableFiltering: false}
	    
	      
	      
	    ],
	    onRegisterApi: function(gridApi) {
	      $scope.gridApi = gridApi;
	      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
	        paginationOptions.pageNumber = newPage;
	        paginationOptions.pageSize = pageSize;
	        getPage();
	      });
	   
	   

	    }
	  };






}]);












