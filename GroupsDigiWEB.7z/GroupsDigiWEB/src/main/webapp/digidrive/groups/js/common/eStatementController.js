var app = angular.module('groupApp', []);


app.controller('eStatementController',['$scope', function($scope){
	
	
	
	

    
}]);