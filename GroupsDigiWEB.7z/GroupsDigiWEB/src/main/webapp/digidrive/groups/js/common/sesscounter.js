function getContextPath()
	   {
	   	var contextpath=window.location.pathname.split('/');
	   	return contextpath[1];
	   }

	 function ReqCounterAjax(){
		// var tokenValue=document.getElementById('_tk').value;
		 var d = new Date();
		 var n = d.getMilliseconds(); 
		
		 	
		 	var contextpath=getContextPath();
			var url="/"+contextpath+"/SecReqCounterServlet?"+n;	
			
			$.ajax({
						url : url,
						type : "get",
						success : function(response) {
							//secs=sessionTime;
							sessionResponse=response;
							if(sessionResponse=="invalidate"){
								alert("Your session has expired");
								logOut();
								
							}
							
						}
						
					});	
		};