var app = angular.module('groupApp', ['ajaxUtil', 'uiValidations', 'ui.materialize', 'validationService', 'generalUtility', 'otpModalApp']);

app.controller('signUpController', ['$scope', '$rootScope', '$location', 'ajaxHttpFactory', '$window', 'validateFieldService', '$http', function($scope, $rootScope, $location, ajaxHttpFactory, $window, validateFieldService, $http) {

    $scope.showPolicyDetailsDiv = true;
    $scope.showEmailMobileDiv = false;
    $scope.showChangePasswordDiv = false;
    $scope.showCountryNames = false;
    $scope.signUpJson = {};
    $rootScope.preloaderCheck = false;
    $scope.errorArray = [];
    $scope.showCountryCode = false;
    $scope.showFullMobileNo = false;
    var ajaxurl = $location.absUrl();
    $scope.showNriMobileNo = false;
    $scope.showMobileNo = false;
    $scope.signUpJson.countryName = "INDIA";
    $scope.responseObj = [];
    $scopeshowEmailID = false;
    var getCountryDetails = function() {
        $rootScope.preloaderCheck = true;
        return ajaxHttpFactory.getJsonData("getCountryDetails", $location.absUrl())
            .then(function(response) {
                    $rootScope.preloaderCheck = false;
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
                        if (response != null && response != "null") {

                            $scope.successMethodOfGetCountryNames(response.data);
                        }
                    }
                },
                function(response) {
                    //			alert("In failureMethod");
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

                    }
                    $rootScope.preloaderCheck = false;
                });
    };
    getCountryDetails();

    $scope.onClickOfCountryButton = function(value) {
        if (value == "NRI") {

            $scope.showNriMobileNo = true;
            $scope.showCountryCode = true;
            $scope.showCountryNames = true;
            $scope.showEmailID = true;
            $scope.showMobileNo = false;
            $scope.signUpJson.mobileNo = "";
            $scope.signUpJson.emailId = "";
            $scope.signUpJson.countryName = value;


            var currentElement = angular.element(document.querySelector('#phoneNumber'));
            currentElement.removeClass('invalid1');
            $('#phoneNumber_errMsg').css("visibility", "");

            var currentElement = angular.element(document.querySelector('#emailID'));
            currentElement.removeClass('invalid1');
            $('#emailID_errMsg').css("visibility", "");

            $scope.errorArray = ["nriMobileNo", "countryName", "emailID"];

        } else {
            if (value == "INDIA") {
                $scope.showNriMobileNo = false;
                $scope.showCountryCode = false;
                $scope.showCountryNames = false;
                $scope.showMobileNo = true;
                $scope.showEmailID = true;
                $scope.signUpJson.mobileNo = "";
                $scope.signUpJson.emailId = "";
                $scope.signUpJson.countryName = "";
                $scope.signUpJson.code = "";

                $scope.signUpJson.countryName = value;



                var currentElement = angular.element(document.querySelector('#nriMobileNo'));
                currentElement.removeClass('invalid1');
                $('#nriMobileNo_errMsg').css("visibility", "");

                var currentElement = angular.element(document.querySelector('#emailID'));
                currentElement.removeClass('invalid1');
                $('#emailID_errMsg').css("visibility", "");

                var currentElement = angular.element(document.querySelector('#countryName'));
                currentElement.removeClass('invalid1');
                $('#countryName_errMsg').css("visibility", "");


                $scope.errorArray = ["phoneNumber", "emailID"];

            }
        }
    };

    $scope.successMethodOfGetCountryNames = function(response) {
        $scope.responseObj = response;

        $scope.onChangeCountryName = function() {
        	$scope.signUpJson.mobileNo="";
            for (var i = 0; i < response.length; i++) {
                if (response[i].countryName == $scope.signUpJson.countryName) {
                    $scope.signUpJson.code = response[i].countryCode;
                } else
                if ($scope.signUpJson.countryName == "") {
                    $scope.signUpJson.code = '';
                }
            }
        };
    }

    $scope.submitPolicyDetails = function() {

        var count = Object.keys($scope.signUpJson).length;
        for (var key in $scope.signUpJson) {
            var error = "#" + key;
            var other = key;
            var currentElement = angular.element(error);
            currentElement.removeClass('#invalid1');
            $('error_errMsg').css("visibility", "");

            for (var j = 0; j < $scope.errorArray.length; j++) {
                if ($scope.errorArray[j] == other) {
                    $scope.errorArray.splice(j, 1);
                    break;
                }
            }

        }
        $scope.errorArray = ["policyNo", "empId", "dob"];
        if ($scope.checkBasicFieldValidations()) {

            $rootScope.preloaderCheck = true;
            var policyDetailsSubmit = angular.toJson($scope.signUpJson);
            var ajaxurl = $location.absUrl();

            ajaxHttpFactory.postJsonDataSuccessFailure(policyDetailsSubmit, "POST", ajaxurl, "checkPolicyDetails", $scope.successMethodSubmitPolicyDetails, $scope.failureMethodSubmitPolicyDetails);

        } else {
            $rootScope.preloaderCheck = false;
            ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
        }
    };

    $scope.successMethodSubmitPolicyDetails = function(response) {
        $rootScope.preloaderCheck = false;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            $scope.showPolicyDetailsDiv = false;
            $scope.showEmailMobileDiv = true;
            $scope.showChangePasswordDiv = false;
            $scope.showMobileNo = true;
            $scope.showEmailID = true;
        }
    };

    $scope.failureMethodSubmitPolicyDetails = function(response) {
        $rootScope.preloaderCheck = false;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

        }
    };


    $scope.submitEmailMobile = function() {

        var count = Object.keys($scope.signUpJson).length;
        for (var key in $scope.signUpJson) {
            var error = "#" + key;
            var other = key;
            var currentElement = angular.element(error);
            currentElement.removeClass('#invalid1');
            $('error_errMsg').css("visibility", "");

            for (var j = 0; j < $scope.errorArray.length; j++) {
                if ($scope.errorArray[j] == other) {
                    $scope.errorArray.splice(j, 1);
                    break;
                }
            }

        }
        $scope.errorArray = ["phoneNumber", "emailID", "nriMobileNo", "countryName"];

        if ($scope.signUpJson.countryName == "INDIA" || $scope.signUpJson.countryName == undefined || $scope.signUpJson.countryName == "") {

            $scope.errorArray = ["phoneNumber", "emailID"];
        }

        if ($scope.signUpJson.countryName != "INDIA" & $scope.signUpJson.countryName != "") {


            $scope.errorArray = ["nriMobileNo", "countryName", "emailID"];

            if ($scope.checkBasicFieldValidations()) {
                $scope.failMobileNo = $scope.signUpJson.mobileNo;
                $scope.signUpJson.fullMobileNo = $scope.signUpJson.code + $scope.signUpJson.mobileNo;
                $scope.signUpJson.mobileNo = $scope.signUpJson.fullMobileNo;

                var emailMobileSubmit = angular.toJson($scope.signUpJson);
                var ajaxurl = $location.absUrl();

                ajaxHttpFactory.postJsonDataSuccessFailure(emailMobileSubmit, "POST", ajaxurl, "emailMobileSubmit", $scope.successMethodEmailMobileSubmit, $scope.failureMethodEmailMobileSubmit);

            } else {
                $rootScope.preloaderCheck = false;
                ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
            }
        } else {
            if ($scope.checkBasicFieldValidations()) {
                if ($scope.signUpJson.mobileNo.match(/^[7-9]+[\d]{9}$/)) {

                    var emailMobileSubmit = angular.toJson($scope.signUpJson);
                    var ajaxurl = $location.absUrl();

                    ajaxHttpFactory.postJsonDataSuccessFailure(emailMobileSubmit, "POST", ajaxurl, "emailMobileSubmit", $scope.successMethodEmailMobileSubmit, $scope.failureMethodEmailMobileSubmit);
                } else {
                    ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill valid  Indian mobileNo", "errorMessage-popup", "forgotPasswordAlert");
                }
            } else {
                $rootScope.preloaderCheck = false;
                ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
            }
        }
    }


    $scope.successMethodEmailMobileSubmit = function(response) {
        $rootScope.preloaderCheck = false;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

            $scope.linkRedirectionUrlWdgt();

            $rootScope.$on('otpHandShake', function(event, args) {
                if (args != null && args != undefined) {
                    $scope.showPolicyDetailsDiv = false;
                    $scope.showEmailMobileDiv = false;
                    $scope.showChangePasswordDiv = true;
                }
            });
        } else {
            $scope.signUpJson.mobileNo = $scope.failMobileNo;
            
        }
    };

    $scope.failureMethodEmailMobileSubmit = function(response) {
        $rootScope.preloaderCheck = false;
        ajaxHttpFactory.showErrorSuccessMessagePopup("Please enter valid mobile number", "errorMessage-popup", "forgotPasswordAlert");
        $scope.signUpJson.mobileNo = $scope.failMobileNo;
    };

    $scope.linkRedirectionUrlWdgt = function() {
        var url = $location.absUrl();
        ajaxHttpFactory.linkRedirectionUrlWdgt(url, '&otpType=transactionalOTP');

    };

    $scope.submitForgotPassword = function() {

        var count = Object.keys($scope.signUpJson).length;
        for (var key in $scope.signUpJson) {
            var error = "#" + key;
            var other = key;
            var currentElement = angular.element(error);
            currentElement.removeClass('#invalid1');
            $('error_errMsg').css("visibility", "");

            for (var j = 0; j < $scope.errorArray.length; j++) {
                if ($scope.errorArray[j] == other) {
                    $scope.errorArray.splice(j, 1);
                    break;
                }
            }

        }
        $scope.errorArray = ["newPassword", "confirmPassword"];
        if ($scope.checkBasicFieldValidations()) {
            if ($scope.checkPasswordValidation()) {
                $scope.signUpJson.newPassword = $.jCryption.encrypt($scope.signUpJson.newPassword, passwordnew);
                $scope.signUpJson.confirmPassword = $.jCryption.encrypt($scope.signUpJson.confirmPassword, passwordnew);

                var forgotPasswordSubmit = angular.toJson($scope.signUpJson);
                var ajaxurl = $location.absUrl();

                ajaxHttpFactory.postJsonDataSuccessFailure(forgotPasswordSubmit, "POST", ajaxurl, "changePasswordSubmit", $scope.successMethodForgotPasswordSubmit, $scope.failureMethodForgotPasswordSubmit);
            } else {
                ajaxHttpFactory.showErrorSuccessMessagePopup("New password and Confirm password should be same", "errorMessage-popup", "forgotPasswordAlert");
            }
        } else {
            ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
        }
    };

    $scope.successMethodForgotPasswordSubmit = function(response) {
        $rootScope.preloaderCheck = false;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            $rootScope.check = true;
            $rootScope.preloaderCheck = true;
            $scope.message = "Your details have been submitted successfully. Kindly go to https://www.iciciprulife.com , select login option as ‘Corporate’, select Login with Email Mobile, Enter your registered email Id/Mobile no and password , click submit to login.";
            $rootScope.preloaderCheck = false;
        } else {
            $scope.signUpJson.newPassword = "";
            $scope.signUpJson.confirmPassword = "";
        }
    };

    $scope.failureMethodForgotPasswordSubmit = function(response) {
        $rootScope.preloaderCheck = false;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

        }
    };

    $scope.okAlert = function() {
        $rootScope.preloaderCheck = true;
        $window.location.href = "group-home.htm?selectedLoginType=LoginWithEmailMobile";
    };

    $scope.resetPolicyDetails = function() {
        $scope.signUpJson.policyNo = '';
        $scope.signUpJson.empId = '';
        $scope.signUpJson.dob = '';

        var currentElement = angular.element(document.getElementsByClassName('invalid1'));
        currentElement.removeClass('invalid1');
        $('.err-msg').css("visibility", "");


    }

    $scope.resetForgotPassword = function() {
        $scope.signUpJson.newPassword = '';
        $scope.signUpJson.confirmPassword = '';

        var currentElement = angular.element(document.getElementsByClassName('invalid1'));
        currentElement.removeClass('invalid1');
        $('.err-msg').css("visibility", "");
    };

    $scope.resetEmailMobile = function() {
        $scope.signUpJson.emailId = '';
        $scope.signUpJson.mobileNo = '';

        var currentElement = angular.element(document.getElementsByClassName('invalid1'));
        currentElement.removeClass('invalid1');
        $('.err-msg').css("visibility", "");

        $scope.onClickOfCountryButton("INDIA");
        var radiobtn = document.getElementById("India");
        radiobtn.checked = true;

        //  $scope.errorArray=["mobileNo","emailID"];

    };

    $scope.checkPasswordValidation = function() {
        if ($scope.signUpJson.newPassword == $scope.signUpJson.confirmPassword) {
            return true;
        } else {
            return false;
        }
    };

    $scope.checkBasicFieldValidations = function() {


        if ($scope.showChangePasswordDiv == true) {
            var returnTrue = false;

            if (!angular.isDefined($scope.signUpJson.newPassword) || $scope.signUpJson.newPassword == "") {
                var currentElement = angular.element(document.querySelector('#newPassword'));
                currentElement.addClass('invalid1');
                $('#newPassword_errMsg').css("visibility", 'visible');
                returnTrue = true;
            }
            if (!angular.isDefined($scope.signUpJson.confirmPassword) || $scope.signUpJson.confirmPassword == "") {
                var currentElement = angular.element(document.querySelector('#confirmPassword'));
                currentElement.addClass('invalid1');
                $('#confirmPassword_errMsg').css("visibility", 'visible');
                returnTrue = true;
            }

            if (returnTrue == true) {
                return false;
            }
        }

        if ($scope.errorArray.length > 0) {
            for (var i = 0; i < $scope.errorArray.length; i++) {
                var lengthBfr = $scope.errorArray.length;
                var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
                if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT" || errorElement.prop('type') == "password") {
                    errorElement.triggerHandler("blur");
                }
                var lengthAftr = $scope.errorArray.length;
                if (lengthAftr < lengthBfr) {
                    i--;
                }
            }
            if ($scope.errorArray.length > 0) {
                $("#" + $scope.errorArray[0]).focus();
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    };


    var currentTime = new Date();
    $scope.currentTime = currentTime;
    $scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    $scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    $scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

    $scope.today = '';
    $scope.clear = 'Clear';
    $scope.close = 'Done';
    var days = 100;
    $scope.minDate = (new Date($scope.currentTime.getTime() - (10000000 * 60 * 60 * 24 * days))).toISOString();
    $scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();

    $scope.onStart = function() {

    };
    $scope.onRender = function() {

    };
    $scope.onOpen = function() {

    };
    $scope.onClose = function() {


    };
    $scope.onSet = function() {


    };

    $scope.onStop = function() {

    };

    $scope.checkDate = function(currentElement, errorMsgElement) {
        if (angular.element(document.getElementById(currentElement)).val() == "") {
            angular.element(document.getElementById(currentElement)).addClass('invalid1');
            angular.element(document.getElementById(errorMsgElement)).css('visibility', 'visible');
            $scope.onSet();
            return false;
        } else {

            angular.element(document.getElementById(currentElement)).removeClass('invalid1');
            angular.element(document.getElementById(errorMsgElement)).css('visibility', 'hidden');
            $scope.onSet();
        }
        return true;
    }

}]);