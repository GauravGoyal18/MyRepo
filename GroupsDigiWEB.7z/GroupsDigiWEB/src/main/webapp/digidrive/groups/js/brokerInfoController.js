var app = angular.module('groupApp', [ 'ajaxUtil', 'ui.materialize','uiValidations','groupCommonUtil','validationService']);
app.controller('brokerInfoController',['$rootScope','$scope','$location','ajaxHttpFactory','$window','validateFieldService','$http',function($rootScope, $scope, $location, ajaxHttpFactory,$window,validateFieldService,$http) {
	

	$scope.absUrl =window.location.origin + window.location.pathname+window.location.search;
	$scope.brokerInfoModel={};
	$scope.brokerInfoData={};
	$scope.errorArray=[];
	$scope.brokerInfoModelData={};

	$scope.hideForm=false;


$scope.brokerInfoDataSubmitForm = function()
{
	 if($scope.checkBasicFieldValidations())
		{
	if(new Date($scope.brokerInfoModel.startDate)<=new Date($scope.brokerInfoModel.endDate)){
		var brokerInfoDataJson=angular.toJson($scope.brokerInfoModel);
		 $rootScope.preloaderCheck=true;
		ajaxHttpFactory.postJsonDataSuccessFailure(brokerInfoDataJson,"POST",$scope.absUrl,"brokerInfoDataSubmit",$scope.successMethod,$scope.failureMethod);
		}
	else if(new Date($scope.brokerInfoModel.startDate)>new Date($scope.brokerInfoModel.endDate))
	{
		$rootScope.preloaderCheck=false;
	ajaxHttpFactory.showErrorSuccessMessagePopup("End Date should be greater than start date","errorMessage-popup", "BrokerAlert");
	}
	else{
		$rootScope.preloaderCheck=false;
		}
	}
	
};
	

$scope.failureMethod=function(response){
	$rootScope.preloaderCheck=false;
	
	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "BrokerAlert")){
		
		ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured please try again. ","errorMessage-popup", "BrokerAlert");
	}
};

  

$scope.successMethod=function(response){
	$rootScope.preloaderCheck=true;
	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "BrokerAlert"))
		
	{ if (response != null && response != "null") {
   	 var responseData = response;
   	 
	 
	 if(responseData!==null && responseData!="" && responseData!=="null")
		 {
		 $scope.hideForm=true;
			$rootScope.preloaderCheck=false;
		 $scope.brokerInfoModelData=responseData;
		 }
	 else
		 {
		 ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured please try again. ","errorMessage-popup", "BrokerAlert");	
		 }
	}}
	};


	var currentTime = new Date();
	$scope.currentTime = currentTime;
	$scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	$scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	$scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
	$scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

	$scope.today = '';
	$scope.clear = 'Clear';
	$scope.close = 'Done';
	var days = 100;
	$scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
	$scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
	
	$scope.onStart = function () {
	   
	};
	$scope.onRender = function () {
	   
	};
	$scope.onOpen = function () {
	 
	    
	   

	    
	};
	$scope.onClose = function () {
    
	};

	
	$scope.dayDiff = function(){
	    var date2 = new Date($scope.maxDate);
	    var date1 = new Date($scope.unitStatementModel.startDate);
	    var timeDiff = Math.abs(date2.getTime() - date1.getTime());   
	    $scope.diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
	    
	}

	$scope.onSet = function () {};


	$scope.onStop = function () {
	  
	};




	$scope.checkBasicFieldValidations = function() {
		if ($scope.errorArray.length > 0) {
			for ( var i = 0; i < $scope.errorArray.length; i++) {
				var lengthBfr = $scope.errorArray.length;
				var errorElement = angular
						.element(document
								.querySelector('#'
										+ $scope.errorArray[i]));
				if (errorElement.prop('type') == "text"
						|| errorElement.prop('type') == "textarea"
						|| errorElement.prop('tagName') == 'DIV'
						|| errorElement.prop('tagName') == "SELECT") {
					errorElement.triggerHandler("blur");
				}
				var lengthAftr = $scope.errorArray.length;
				if (lengthAftr < lengthBfr) {
					i--;
				}
			}
			if ($scope.errorArray.length > 0) {
				$("#" + $scope.errorArray[0]).focus();
				return false;
			} else {
				return true;
			}
		} else {
			return true;
		}
	};
	$scope.checkDate= function(currentElement,errorMsgElement){
		if(angular.element(document.getElementById(currentElement)).val()=="")
			{
			angular.element(document.getElementById(currentElement)).addClass('invalid1');
			angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
			$scope.onSet();
			return false;
			}
		else
			{
		
			angular.element(document.getElementById(currentElement)).removeClass('invalid1');
			angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
			$scope.onSet();
			}
		return true;
		}
	
	$scope.resetButton=function()
	{
		 var currentElement = angular.element(document.getElementsByClassName('invalid1'));
	        currentElement.removeClass('invalid1');
	        $('.err-msg').css("visibility", "");
	        $scope.unitStatementModel = {};
	}


	}]);
							