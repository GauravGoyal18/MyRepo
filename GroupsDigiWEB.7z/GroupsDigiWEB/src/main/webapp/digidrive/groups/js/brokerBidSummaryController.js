
var app = angular.module('groupApp',['ajaxUtil','ui.materialize','uiValidations','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection']);
app.controller("brokerBidSummaryController",['$rootScope','$scope','$location','ajaxHttpFactory','$http','$q','$interval','$timeout','uiGridConstants',
                                   function($rootScope, $scope,$location,ajaxHttpFactory,$http, $q, $interval, $timeout,uiGridConstants){


       $scope.errorArray=[];
       $scope.brokerBidSummaryJson={};
       $rootScope.preloaderCheck=false;
       $scope.brokerBidSummaryView={};
       $scope.BrokerBidSummaryData=[];
       $scope.showBrokerBidSummaryGrid=false;
       $scope.showBrokerBidSummaryPolicyNumber=true;
       $scope.disablePolicynumber=false;
       $scope.showsubmit=true;
      
      $scope.result='';
      
      var paginationOptions = {
  		    pageNumber: 1,
  		    pageSize: 100,
  		    sort: null
  	};
  	
       
       
       var loadOnloadData = function() {
    	   $rootScope.preloaderCheck=true;
    	   return ajaxHttpFactory.getJsonData("brokerBidSummaryOnLoad",$location.absUrl())
   		.then(function(response) {
   	       $scope.disableFields=false;
   			$rootScope.preloaderCheck=false;
   			$scope.result=response.data;
   			if (response != null && response != "null") {
   				$scope.selectedOption = response.data;
   			
   			}
   		}, 
		function(errResponse) {
			
			$rootScope.preloaderCheck=false;
		});
       };
       
       loadOnloadData();
       
       $scope.resetPolicynumber=function()
       {
    	   var currentElement = angular.element(document.getElementsByClassName('invalid1'));
           currentElement.removeClass('invalid1');
           $('.err-msg').css("visibility", "");
         
           $scope.brokerBidSummaryJson={};
           $scope.errorArray=["policyNo"];
           $scope.showBrokerBidSummaryGrid=false;
           $scope.disablePolicynumber=false;
           $scope.showsubmit=true;
       }
       

       $scope.submitPolicyNumber=function()
       {
    	   $rootScope.preloaderCheck=true;
    	   if($scope.checkBasicFieldValidations())
    		   {
    		    var submitBrokerBidSummary=angular.toJson($scope.brokerBidSummaryJson);
                var ajaxurl=$location.absUrl(); 
    		   	ajaxHttpFactory.postJsonDataSuccessFailure(submitBrokerBidSummary,"POST",ajaxurl,"submitBrokerBidSummary",$scope.successBrokerBidSummaryMethod,$scope.failureBrokerBidSummaryMethod);
    		   }
    	   else
    		   {
    		   	ajaxHttpFactory.showErrorSuccessMessagePopup("Please fill All Mandatory Fields. ","errorMessage-popup", "BrokerBidSummaryAlert");
    		   }
       
            
       };
       
       $scope.successBrokerBidSummaryMethod = function(response){
           
          
        	   $rootScope.preloaderCheck=true; 
        	   if(!ajaxHttpFactory.handleIPruException(angular.toJson(response.data), "errorMessage-popup")) {
   				if (response != null && response != "null") {
   				 $scope.showBrokerBidSummaryPolicyNumber=true;
   					
   					var responseData = response;
   					$scope.BrokerBidSummaryData = responseData;
   					
   					$scope.brokerBidSummaryView.totalItems=$scope.BrokerBidSummaryData.length;
   					$scope.showBrokerBidSummaryGrid=true;
   					$scope.getPage();
   				 $scope.showsubmit=false;
   					$scope.disablePolicynumber=true;
   					$rootScope.preloaderCheck=false;	
   					
   				}
   			}
        		else{
    				$rootScope.preloaderCheck=false;
    				if(ajaxHttpFactory.handleIPruException(response.data, "errorMessage-popup", "exceptionAlert")){
						
    				}
    			}
                 
           
         
           
    };
    
    $scope.failureBrokerBidSummaryMethod=function()
    {
		
		$rootScope.preloaderCheck=false;
		
		$rootScope.openAlertID = true;
		$scope.action="failure";
		$scope.message = "Some Error Occured.";
	};
	
    
    
    $scope.getPage = function() {
		   var firstRow = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
		   $scope.brokerBidSummaryView.data = $scope.BrokerBidSummaryData.slice(firstRow, firstRow + paginationOptions.pageSize);
	 };
   
	 
	 $scope.brokerBidSummaryView = {
			    paginationPageSizes: [100],
			    paginationPageSize: 100,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableFiltering: false,
			    enableRowSelection : true,
	            multiSelect : false,
	            enableRowHeaderSelection : false,
	            totalItems:$scope.count,
	            resizable: false,
	            enableColumnResizing: false,
			    columnDefs: [
			      { field: 'balance', displayName: 'Balance(Rs)', width: "30%", enableSorting: false},
			      { field: 'unitName', displayName: 'Unit Name', width: "70%", enableSorting: false},
			      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;
			 
			      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;
			        $scope.getPage();
			      });
			   
			   

			    }
			  };
	 
    
$scope.checkBasicFieldValidations = function() {
              
      
           if ($scope.errorArray.length > 0) {
               for (var i = 0; i < $scope.errorArray.length; i++) {
                   var lengthBfr = $scope.errorArray.length;
                   var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
                   if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
                       errorElement.triggerHandler("blur");
                   }
                   var lengthAftr = $scope.errorArray.length;
                   if (lengthAftr < lengthBfr) {
                       i--;
                   }
               }
               if ($scope.errorArray.length > 0) {
                   $("#" + $scope.errorArray[0]).focus();
                   return false;
               } else {
                   return true;
               }
           } else {
               return true;
           }
       };
       
  
}]);
