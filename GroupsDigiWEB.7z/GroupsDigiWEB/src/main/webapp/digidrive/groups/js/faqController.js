var app=angular.module('groupApp',['ui.materialize']);

app.controller('faqController',['$scope','$rootScope', function($scope,$rootScope){
	
	$rootScope.preloaderCheck=false;
	$scope.groupgratuity=false;
	$scope.groupsuperannuation=false;
	$scope.onclickgroupgratuity=function(){
		  angular.element( document.querySelector('#groupsuperannuation')).removeClass("active");
		   angular.element( document.querySelector('#groupgratuity')).addClass("active");
		$scope.groupgratuity=true;	
		$scope.groupsuperannuation=false;
		
	}
	$scope.onclickgroupgratuity();
	
	$scope.onclickgroupsuperannuation=function(){
		angular.element( document.querySelector('#groupgratuity')).removeClass("active");
		   angular.element( document.querySelector('#groupsuperannuation')).addClass("active");
		$scope.groupgratuity=false;	
		$scope.groupsuperannuation=true;
	}
 

}]);

