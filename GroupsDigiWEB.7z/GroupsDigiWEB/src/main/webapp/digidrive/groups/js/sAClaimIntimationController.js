var app = angular.module('groupApp', [ 'ajaxUtil', 'ui.materialize','uiValidations','groupCommonUtil','validationService']);
app.controller('sAClaimIntimationController',['$rootScope','$scope','$location','ajaxHttpFactory','csrDocUploadFactory','$window','validateFieldService','$filter','$http',function($rootScope, $scope, $location, ajaxHttpFactory,csrDocUploadFactory,$window,validateFieldService,$filter,$http) {

	
	$scope.errorArray = [];
	$scope.cityList1=[];
	$scope.cityList2=[];
	$scope.cityList3=[];
	$scope.sAClaimIntimation={};
	$scope.SAClaimIntimationFinal={};
	$scope.sAClaimIntimation.beneficiary={};
	$scope.sAClaimIntimation.spouse={};
	$scope.sAClaimIntimation.modeOfPayment='Electronic Credit';
	$rootScope.preloaderCheck=false;
	$scope.claimModal=false;
	$scope.disableFields=false;
	$scope.preloaderCheck=false;
	$scope.showAge=false;
	$scope.appointeeShow=false;
	$scope.prepop=false;
	$scope.showHtmlPage=false;
	$rootScope.openannuityOptionAlertId=false;
	$scope.openonSubmitOpenAlertId=false;
	
	
	//$scope.annuityOptionDesc=false;
	
	
	$scope.onClickcClaimModal=function()
	{
		
	}
	
	$scope.onChangeofClaimType=function(){
		$scope.sAClaimIntimation.beneficiary={};
	};
	
	
	var getDetailsOnLoad = function() {
		$scope.preloaderCheck=true;
        var ajaxurl = $location.absUrl();
			ajaxHttpFactory.getJsonData('getsAClaimIntiDetailsOnLoad',ajaxurl,'','GET').then(
                   function successCallback(response) {
					$rootScope.preloaderCheck = false;
					if (response != null && response != "null") {
						var responseData = response.data;
							$rootScope.preloaderCheck = false;
							if(responseData.firstTime==false)
							{
								
								$scope.downloadPDF();
							}
							else
							{
								$scope.showHtmlPage=true;
								
								$scope.sAClaimIntimation.policyNo =responseData.policyNo;
								$scope.sAClaimIntimation.trustName =responseData.trustName;
								$scope.sAClaimIntimation.empId =responseData.empId;
								$scope.sAClaimIntimation.empName =responseData.empName;
								$scope.prepop=true;
								
							}
					}
               }
			);
	};
	
	$scope.validatePurchaseOption=function(){
		
		if(($scope.sAClaimIntimation.rulesOfScheme==undefined && $scope.sAClaimIntimation.purchaseOption==undefined)||($scope.sAClaimIntimation.rulesOfScheme==undefined && $scope.sAClaimIntimation.purchaseOption.length>0)||($scope.sAClaimIntimation.purchaseOption==undefined && $scope.sAClaimIntimation.rulesOfScheme.length>0||($scope.sAClaimIntimation.purchaseOption.length>0)||($scope.sAClaimIntimation.rulesOfScheme.length>0)))
		{
			var currentElement = angular.element( document.querySelector('#purchaseOption'));
			currentElement.removeClass('invalid1');
			$('#purchaseOption_errMsg').css("visibility", "");
			
		
			var currentElement = angular.element( document.querySelector('#rulesOfScheme'));
			currentElement.removeClass('invalid1');
			$('#rulesOfScheme_errMsg').css("visibility", "");
	
		}
		
	};
		

	$scope.okAlert = function() {
		$rootScope.openAlertID = false;
		$window.location.href = "dashboard.htm";
	};
	
	$scope.okAnnuityAlert=function()
	{
		$rootScope.openannuityOptionAlertId=false;
	}
	
	$scope.onAnnuityOptionSelect=function(desc)
	{
		$scope.sAClaimIntimation.spouse={};
		for(var i=0;i<$scope.annuityOptions.length;i++)
		{
			if((desc)==($scope.annuityOptions[i].Id))
			{
				$scope.annuityOptionPopUpMsg = $scope.annuityOptions[i].Desc;
				$rootScope.openannuityOptionAlertId=true;
			}
		}
	}
	
	//download PDF function
	$scope.downloadPDF=function()
	{

	 	$scope.methodType = 'POST';
		
		$http({
            url: 'GrpSAClaimIntiServlet.do',
            method: $scope.methodType,
            responseType: 'arraybuffer',
            data: undefined,
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/pdf'
            }
        }).success(function(data) {
        	$rootScope.preloaderCheck=true; 
        	if(data.byteLength>0)
        	{
            var blob = new Blob([data], {
                type: 'application/pdf'
            });
            saveAs(blob, 'GRP_SA_Claim_Intimation'+ '.pdf');
            $rootScope.preloaderCheck=false;
			//ajaxHttpFactory.showErrorSuccessMessagePopup("File downloaded successfully. ","errorMessage-popup", "GrpSAClaimInti");
			//$window.location.href = "dashboard.htm";
            $scope.openAlertID=true;
            $scope.message="File downloaded successfully";
        	}
        	else
        	{
        		$rootScope.preloaderCheck=false;
				ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "GrpSAClaimInti");

        	}
            
            
        }).error(
            function() {
             	$rootScope.preloaderCheck=false;
				ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "GrpSAClaimInti");

            });
	}
	
	getDetailsOnLoad();
	
	var getStatesOnLoad = function() {
		$scope.preloaderCheck=true;
        var ajaxurl = $location.absUrl();
			ajaxHttpFactory.getJsonData('getStatesOnLoad',ajaxurl,'','GET').then(
                   function successCallback(response) {
					$rootScope.preloaderCheck = false;
					if (response != null && response != "null") {
						var responseData = response.data;
							$scope.state=responseData;
							$rootScope.preloaderCheck = false;
					}
               }
			);
	};
	// getStatesOnLoad
	getStatesOnLoad();
	
	var getCityOnLoad=function(){
		$rootScope.preloaderCheck=true;
		var ajaxurl = $location.absUrl();
		ajaxHttpFactory.getJsonData('getCityOnLoad',ajaxurl,'','GET').then(
                   function successCallback(response) {
			if (response != null && response != "null") {
				var responseData = response.data;
				
					$scope.cityDetails=(responseData);
				}	
			$rootScope.preloaderCheck=false;
			}
		);
	};
	
	// onLoadCityDetails
	getCityOnLoad();
	
	
	$scope.onChangeROS=function()
	{
		$scope.sAClaimIntimation.purchaseOption="";
	}
	
	//on Change of States
	$scope.onChangeStates=function(selectedState)
	{
		$scope.cityList1=[];
		 for(var i=0;i<$scope.cityDetails.length;i++)
			 {
			    if(selectedState==$scope.cityDetails[i].key)
			    	{
			    	$scope.cityList1.push($scope.cityDetails[i].value);
			    	}
			 }
	};
	
	$scope.onChangeBenStates=function(selectedState)
	{
		$scope.cityList2=[];
		 for(var i=0;i<$scope.cityDetails.length;i++)
			 {
			    if(selectedState==$scope.cityDetails[i].key)
			    	{
			    	$scope.cityList2.push($scope.cityDetails[i].value);
			    	}
			 }
	};
	
	$scope.onChangeaAnnuStates=function(selectedState)
	{
		$scope.cityList3=[];
		 for(var i=0;i<$scope.cityDetails.length;i++)
			 {
			    if(selectedState==$scope.cityDetails[i].key)
			    	{
			    	$scope.cityList3.push($scope.cityDetails[i].value);
			    	}
			 }
	}
	
	
	$scope.onChangeOfClaim=function()
	{
		$scope.sAClaimIntimation.beneficiary={};
		$scope.sAClaimIntimation.annuityOption={};
		$scope.sAClaimIntimation.dateType="";
		$scope.sAClaimIntimation.freqOfPayment="";
		$scope.sAClaimIntimation.compBuildName="";
		$scope.sAClaimIntimation.flatUnitNo="";
		$scope.sAClaimIntimation.streetArea="";
		$scope.sAClaimIntimation.pincode="";
		$scope.sAClaimIntimation.state="";
		$scope.sAClaimIntimation.city="";
		$scope.sAClaimIntimation.emailId="";
		$scope.sAClaimIntimation.mobileNumber="";
		$scope.sAClaimIntimation.bankName="";
		$scope.sAClaimIntimation.branch="";
		$scope.sAClaimIntimation.bankContactNumber="";
		$scope.sAClaimIntimation.accountNumber="";
		$scope.appointeeShow=false;
	};
	
	$scope.onChangeOfPurchaseOption=function()
	{
		$scope.sAClaimIntimation.rulesOfScheme="";
		if($scope.sAClaimIntimation.purchaseOption!='Transfer to new fund')
		{
			delete $scope.sAClaimIntimation.nameOfFundComp;
		}
		else
		{
			$scope.sAClaimIntimation.nameOfFundComp="";
		}
		
		
	};
	
	$scope.onChangeOfAnnuityOptions=function()
	{
		$scope.sAClaimIntimation.spouse={};
	};
	
	/*$scope.onChangeOfModOfPay=function()
	{
		if($scope.sAClaimIntimation.modeOfPayment!='Electronic Credit')
			{
				delete $scope.sAClaimIntimation.micr;
				delete $scope.sAClaimIntimation.ifsc;
			}
		else
		{
			$scope.sAClaimIntimation.micr="";
			$scope.sAClaimIntimation.ifsc="";
		}
	};*/
	
	$scope.removeError=function()
	{
		
	 	   var count = Object.keys($scope.sAClaimIntimation).length;
	 	   for(var key in $scope.sAClaimIntimation )
	 	   {
	 		   var error = "#"+key;
	 		   var other = key;
	 		   var currentElement = angular.element(error);
	 		   currentElement.removeClass('#invalid1');
	 		   $('error_errMsg').css("visibility", "");
	 	   		
	 		   for (var j = 0; j < $scope.errorArray.length; j++)
	 	   		{
	 			   if ($scope.errorArray[j] == other) 
	 			   { 
	 				   $scope.errorArray.splice(j, 1);
	 				   break;
	 			   }
	 	   		}
	 	   					
	         }
	};
	
	//preview Claim Form
	$scope.proceedsACalimForm=function(){
		$scope.removeError();
		$scope.checkingErrorArray();
		if($scope.checkBasicFieldValidations()){
			
			if(($scope.sAClaimIntimation.rulesOfScheme==null&&$scope.sAClaimIntimation.purchaseOption==null)||($scope.sAClaimIntimation.rulesOfScheme==""&&$scope.sAClaimIntimation.purchaseOption==""))
			{
				$scope.claimModal=false;
				$rootScope.preloaderCheck=false;
				ajaxHttpFactory.showErrorSuccessMessagePopup("Please select Purchase Option Field or Rules of Scheme Option","errorMessage-popup", "sAClaimIntimation");
			}
			else
			{
				if($scope.sAClaimIntimation.annuityOption==4||$scope.sAClaimIntimation.annuityOption==14)
				{
					if($scope.isBenefAndSpouseEqual())
					{
						ajaxHttpFactory.showErrorSuccessMessagePopup("Beneficiary & Spouse can not be same : Beneficiary Should be third Person","errorMessage-popup", "sAClaimIntimation");
						
					}
					else
					{
						for(var i=0;i<$scope.annuityOptions.length;i++)
						{
							if(($scope.sAClaimIntimation.annuityOption)==($scope.annuityOptions[i].Id))
							{
							$scope.sAClaimIntimation.annuityOptionValue = $scope.annuityOptions[i].Value;
							$scope.sAClaimIntimation.annuityOptionId = $scope.annuityOptions[i].Id;
							}
						}
						
						for(var i=0;i<$scope.rulesOfSchemeOption.length;i++)
						{
							if($scope.sAClaimIntimation.rulesOfScheme==($scope.rulesOfSchemeOption[i].Id))
							{
								$scope.sAClaimIntimation.rulesOfSchemeValue = $scope.rulesOfSchemeOption[i].Value;
								$scope.sAClaimIntimation.rulesOfSchemeId = $scope.rulesOfSchemeOption[i].Id;
							}
						}
						$scope.claimModal=true;
						$scope.disableFields=true;
						$scope.SAClaimIntimationFinal = $scope.sAClaimIntimation;
						
						
					}
				}
				
				else
				{
					for(var i=0;i<$scope.annuityOptions.length;i++)
					{
						if(($scope.sAClaimIntimation.annuityOption)==($scope.annuityOptions[i].Id))
						{
							$scope.sAClaimIntimation.annuityOptionValue = $scope.annuityOptions[i].Value;
							$scope.sAClaimIntimation.annuityOptionId = $scope.annuityOptions[i].Id;
						}
					}
					for(var i=0;i<$scope.rulesOfSchemeOption.length;i++)
					{
						if($scope.sAClaimIntimation.rulesOfScheme==($scope.rulesOfSchemeOption[i].Id))
						{
							$scope.sAClaimIntimation.rulesOfSchemeValue = $scope.rulesOfSchemeOption[i].Value;
							$scope.sAClaimIntimation.rulesOfSchemeId = $scope.rulesOfSchemeOption[i].Id;
						}
					}
					
				
					$scope.claimModal=true;
					$scope.SAClaimIntimationFinal = $scope.sAClaimIntimation;
					$scope.disableFields=true;
					
					
				}
			}
			
			
			
		}
		else 
		{
			$rootScope.preloaderCheck=false;
			ajaxHttpFactory.showErrorSuccessMessagePopup("All the fields should be filled","errorMessage-popup", "sAClaimIntimation");
		}
		
	};
	
	$scope.isBenefAndSpouseEqual=function()
	{
		if(($scope.sAClaimIntimation.beneficiary.firstName.toLowerCase()==$scope.sAClaimIntimation.spouse.firstName.toLowerCase())
		&&($scope.sAClaimIntimation.beneficiary.lastName.toLowerCase()==$scope.sAClaimIntimation.spouse.lastName.toLowerCase())&&
		($scope.sAClaimIntimation.beneficiary.dateOfBirth==$scope.sAClaimIntimation.spouse.dateOfBirth))
		{return true; }
		else
			return false;
	}
	
	// Reset button
	$scope.resetsAForm=function(){
		$window.location.href = "superAnnuationClaimIntimation.htm";
	};
	
	//cancel preview modal
	$scope.cancelPreviewForm=function(){
		$scope.claimModal=false;
		$scope.disableFields=false;
		$scope.openonSubmitOpenAlertId=false;
		
		
			
	};
	
	$scope.onSubmitOpenAlert=function()
	{
		$scope.openonSubmitOpenAlertId=true;
	};
	
	
	// Submit Form
	$scope.submitSACalimForm=function(){
		var ajaxurl = $location.absUrl();
		var  sAClaimIntimationSubmit =angular.toJson($scope.SAClaimIntimationFinal);
			ajaxHttpFactory.postJsonDataSuccessFailure(sAClaimIntimationSubmit,"POST",ajaxurl,"submitSAClaimIntiForm",$scope.successMethod,$scope.failureMethod);
	};
	
	$scope.successMethod=function(response){
		 if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
	            $rootScope.preloaderCheck = false;
	            $scope.downloadPDF();
	        }
	};
	$scope.failureMethod=function(response)
	{
		if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            $rootScope.preloaderCheck = false;
        }
	}
	
	// Date function
	
	var currentTime = new Date();
    $scope.currentTime = currentTime;
    $scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    $scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    $scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

    $scope.today = '';
    $scope.clear = 'Clear';
    $scope.close = 'Done';
    var days = 100;
    $scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
    $scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
    $scope.onStart = function () {
       
    };
    $scope.onRender = function () {
    };
    $scope.onOpen = function () {   
    };
    $scope.onClose = function () {
    };
    $scope.onSet = function (dob) {
    	$scope.birthday = new Date(dob);
		if ($scope.birthday != '' || $scope.birthday != undefined) {
			$scope.sAClaimIntimation.Age = $scope.calculateAge($scope.birthday);
			$scope.sAClaimIntimation.beneficiary.category='major';
				if($scope.sAClaimIntimation.Age<18)
				{
					$scope.appointeeShow=true;
					$scope.sAClaimIntimation.beneficiary.category='minor';
				}
				else
				{	$scope.appointeeShow=false;
				
				}
		}
		
    };
    $scope.onSetDOB=function(DOB)
    {
    	$scope.birthday1 = new Date(DOB);
		if ($scope.birthday1 != '' || $scope.birthday1 != undefined) {
			$scope.sAClaimIntimation.Age = $scope.calculateAge($scope.birthday1);
			$scope.sAClaimIntimation.beneficiary.category='major';
				if($scope.sAClaimIntimation.Age<18)
				{
					$scope.appointeeShow=true;
					$scope.sAClaimIntimation.beneficiary.category='minor';
				}
				else
				{	$scope.appointeeShow=false;
				
				}
		}
    };
    $scope.onSet1 = function (dob) {
    };
    $scope.onSet2 = function(dob){	
    };
    $scope.onStop = function () {   
    };
         
    $scope.calculateAge = function(birthday) {

		var ageDifMs = Date.now() - birthday.getTime();
		var ageDate = new Date(ageDifMs);

		return Math.abs(ageDate.getUTCFullYear() - 1970);
	};
	
	$scope.checkDate = function(currentElement, errorMsgElement) {
		$scope.sAClaimIntimation.beneficiary.appointeeFName="";
		$scope.sAClaimIntimation.beneficiary.appointeeLName="";
		$scope.sAClaimIntimation.beneficiary.appointeeRelation="";
		if (angular.element(document.getElementById(currentElement))
				.val() == "") {
			angular.element(document.getElementById(currentElement))
					.addClass('invalid1');
			angular.element(document.getElementById(errorMsgElement))
					.css('visibility', 'visible');
			return false;
		} else {
			if (currentElement == "benefdateOfBirth") {
				$scope.showAge = true;
			} 
			angular.element(document.getElementById(currentElement))
					.removeClass('invalid1');
			angular.element(document.getElementById(errorMsgElement))
					.css('visibility', 'hidden');
			return true;
		}

	}
	
    
	
    $scope.typeOfClaims=[{Id :1,Name : 'Normal Retirement'},{Id :2,Name : 'Early Retirement'},{Id :3,Name : 'Resignation'}];
    $scope.rulesOfSchemeOption=[{Id :1,Value : '2/3 of value of units to be utilized for immediate pension through ICICI Pru Life 1/3 of value of units to be paid in lumpsum (commutation)'},{Id :2,Value : '1/2 of value of units to be utilised for immediate pension through ICICI Pru Life 1/2 of value of units to be paid in lumpsum (commutation)'},{Id :3,Value : '100% of value of units to be utilized for immediate pension through ICICI Pru Life'}];
    $scope.purchaseOption=[{Id : 1,Value :'Open Market Option'},{Id : 2,Value : 'Transfer to new fund'}];
    $scope.relation=[{Id : 1,Value :'Father'},{Id :2,Value:'Mother' },{Id :3,Value:'Daughter'},{Id:4,Value:'Son'}];
    $scope.ageProof=[{Id:1,Value:'Birth Certificate'},{Id:'2',Value:'Passport'},{Id:'3',Value:'School College Extract'},{Id:'4',Value:'Employer certificate for PSU/Govt company/Public Ltd company'}];
    $scope.paymentFrequency=[{Id:1,Value:'Monthly'},{Id:2,Value:'Quaterly'},{Id:3,Value:'Half Yearly'},{Id:4,Value:'Yearly'}];
    $scope.annuityOptions =[{Id:'1',Value:'Life annuity',Desc:'The Annuitant will get a guaranteed pension for life as long as he/she lives'},
                            {Id:'2',Value:'Life annuity with return of premium',Desc:'This option pays you annuity for life and on death the Purchase Price is returned to your nominee'},
                            {Id:'3',Value:'Joint life last survivor (JLSS) (This option is applicable only when annuitant has spouse at time of commencement of pension.)',Desc:'This option pays you annuity for life and on death the annuity continues for the life of the named spouse'},
                            {Id:'4',Value:'Joint life last survivor with return of Purchase price (JLSS) (This option is applicable only when annuitant has spouse at time of commencement of pension.)',Desc:'This option pays you annuity for life and on death the annuity continues for the life of the named spouse.On the demise of the last survivor the Purchase Price is returned to your nominee.Where the named spouse is no longer a legal spouse at the time of your demise, no benefits shall be payable except the Return of Purchase Price to the nominee'},
                            {Id:'5',Value:'Life annuity guaranteed for 5 years and life thereafter',Desc:'This option pays you annuity for a guaranteed period of 5years(as chosen by you), and life thereafter.In case of demise during the guaranteed period, annuity for the remaining guaranteed period will be paid to your nominee'},
                            {Id:'6',Value:'Life annuity guaranteed for 10 years and life thereafter',Desc:'This option pays you annuity for a guaranteed period of 10years(as chosen by you), and life thereafter.In case of demise during the guaranteed period, annuity for the remaining guaranteed period will be paid to your nominee'},
                            {Id:'7',Value:'Life annuity guaranteed for 15 years and life thereafter',Desc:'This option pays you annuity for a guaranteed period of 15years(as chosen by you), and life thereafter.In case of demise during the guaranteed period, annuity for the remaining guaranteed period will be paid to your nominee'},
                            {Id:'8',Value:'Life Annuity with Return of 50% Purchase Price',Desc:'This option pays you annuity for life and on death, 50% of the Purchase Price is returned to your nominee'},
                            {Id:'9',Value:'Life Annuity with Return of 75% Purchase Price',Desc:'This option pays you annuity for life and on death, 75% of the Purchase Price is returned to your nominee'},
                            {Id:'10',Value:'Life Annuity with Return of Balance Purchase price',Desc:'This option pays you annuity for life and on death, the Balance Purchase Price is returned to your nominee.Balance Purchase price will be equal to Purchase Price (premium paid by you in the beginning excluding taxes) less sum total of the annuities paid.If the balance is negative, then no benefit will be payable on death'},
                            {Id:'11',Value:'Life Annuity Guaranteed for 5/10/15 years and payable for life thereafter',Desc:'This option pays you annuity for a guaranteed period of 5, 10 or 15 years (as chosen by you), and life thereafter.In case of demise during the guaranteed period, annuity for the remaining guaranteed period will be paid to your nominee'},
                            {Id:'12',Value:'Life Annuity with Return of Purchase Price on Critical illness (CI) or Permanent Disability due to accident (PD) or Death',Desc:'This option pays you annuity till earlier of first occurrence of any of the 7 specified CI or PD before the age of 80 years, or death'},
                            {Id:'13',Value:'Life Annuity with annual increase of 5%',Desc:'The Annuitant will get a guaranteed pension for life as long as he/she lives.Annuity payout increases at a simple rate of 5% for each complete policy year throughout the life of annuitant'},
                            {Id:'14',Value:'Joint Life, Last Survivor with Return of Purchase Price in parts',Desc:'This option pays you annuity for life and on death the annuity continues for the life of the named spouse.On the demise of the last survivor the Purchase Price is returned to your nominee.Where the named spouse is no longer a legal spouse at the time of your demise, no benefits shall be payable except the Return of Purchase Price to the nominee'}];
    $scope.modeofPay=[{Id:1,Value:'Electronic Credit'}];
    $scope.salutations=[{Id:1,Value:'Capt.'},{Id:2,Value:'Dr.'},{Id:3,Value:'Mr.'},{Id:4,Value:'Ms.'},{Id:5,Value:'Mrs.'}];
    $scope.gender=[{Id:1,Value:'Male'},{Id:2,Value:'Female'}];
    
    
    $scope.checkBasicFieldValidations = function() {
        
	      
        if ($scope.errorArray.length > 0) {
            for (var i = 0; i < $scope.errorArray.length; i++) {
                var lengthBfr = $scope.errorArray.length;
                var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
                if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
                    errorElement.triggerHandler("blur");
                }
                var lengthAftr = $scope.errorArray.length;
                if (lengthAftr < lengthBfr) {
                    i--;
                }
            }
            if ($scope.errorArray.length > 0) {
                $("#" + $scope.errorArray[0]).focus();
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    };
    
    $scope.checkingErrorArray=function()
    {
    		if($scope.sAClaimIntimation.purchaseOption=='Transfer to new fund')
    		{
    			if($scope.sAClaimIntimation.annuityOption==3)
    			{
    					if($scope.sAClaimIntimation.Age<18 && $scope.sAClaimIntimation.Age!="")
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType","nameOfFundComp",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"appointeeFName","appointeeLName","appointeeRelation","empcompBuildName",
    											"empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"spSalutation","spouseFirstName","spouseLastName","spousedateOfBirth"];
    					}
    					else
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType","nameOfFundComp",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"empcompBuildName","empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"spSalutation","spouseFirstName","spouseLastName","spousedateOfBirth"];
    					}
    			}
    			else if($scope.sAClaimIntimation.annuityOption==2||$scope.sAClaimIntimation.annuityOption==8||$scope.sAClaimIntimation.annuityOption==9||$scope.sAClaimIntimation.annuityOption==10||$scope.sAClaimIntimation.annuityOption==12)
    			{
    				
    					if($scope.sAClaimIntimation.Age<18 && $scope.sAClaimIntimation.Age!="")
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType","nameOfFundComp",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"appointeeFName","appointeeLName","appointeeRelation","empcompBuildName",
    											"empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"salutation2","beneficiaryFirstName2","beneficiaryLastName2","benefrelationShipWithMember","benefdateOfBirth2",
    											"bencompBuildName","benflatUnitNo","benstreatArea",
    											"benpincode","benstate","bencity","benemailId","bencontactNumber"];
    					}
    					else
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType","nameOfFundComp",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"empcompBuildName","empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"salutation2","beneficiaryFirstName2","beneficiaryLastName2","benefrelationShipWithMember","benefdateOfBirth2",
    											"bencompBuildName","benflatUnitNo","benstreatArea",
    											"benpincode","benstate","bencity","benemailId","bencontactNumber"];
    					}
    			}
    			else if($scope.sAClaimIntimation.annuityOption==4||$scope.sAClaimIntimation.annuityOption==14)
    			{
    					if($scope.sAClaimIntimation.Age<18 && $scope.sAClaimIntimation.Age!="")
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType","nameOfFundComp",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"empcompBuildName","empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"salutation2","beneficiaryFirstName2","beneficiaryLastName2","benefrelationShipWithMember","benefdateOfBirth2",
    											"bencompBuildName","benflatUnitNo","benstreatArea",
    											"benpincode","benstate","bencity","benemailId","bencontactNumber",
    											"spSalutation","spouseFirstName","spouseLastName","spousedateOfBirth",
    											"appointeeFName","appointeeLName","appointeeRelation"];
    					}
    					else
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType","nameOfFundComp",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"empcompBuildName","empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"salutation2","beneficiaryFirstName2","beneficiaryLastName2","benefrelationShipWithMember","benefdateOfBirth2",
    											"bencompBuildName","benflatUnitNo","benstreatArea",
    											"benpincode","benstate","bencity","benemailId","bencontactNumber",
    											"spSalutation","spouseFirstName","spouseLastName","spousedateOfBirth"];
    					}
    			}
    			else
    			{
    					$scope.errorArray=["panNumber","typeOfClaim","dateType","nameOfFundComp","payeeName","annudateOfBirth",
											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo","freqOfPayment",
    										"annuityOption","ifsc","micr","empcompBuildName",
    										"empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    										"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo"];	
    			}
    			
    		}
    		else
    		{//no nameoffundComp
    			if($scope.sAClaimIntimation.annuityOption==3)
    			{
    					if($scope.sAClaimIntimation.Age<18 && $scope.sAClaimIntimation.Age!="")
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"appointeeFName","appointeeLName","appointeeRelation","empcompBuildName",
    											"empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"spSalutation","spouseFirstName","spouseLastName","spousedateOfBirth"];
    					}
    					else
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"empcompBuildName","empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"spSalutation","spouseFirstName","spouseLastName","spousedateOfBirth"];
    					}
    			}
    			else if($scope.sAClaimIntimation.annuityOption==2||$scope.sAClaimIntimation.annuityOption==8||$scope.sAClaimIntimation.annuityOption==9||$scope.sAClaimIntimation.annuityOption==10||$scope.sAClaimIntimation.annuityOption==12)
    			{
    					if($scope.sAClaimIntimation.Age<18 && $scope.sAClaimIntimation.Age!="")
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"appointeeFName","appointeeLName","appointeeRelation","empcompBuildName",
    											"empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"salutation2","beneficiaryFirstName2","beneficiaryLastName2","benefrelationShipWithMember","benefdateOfBirth2",
    											"bencompBuildName","benflatUnitNo","benstreatArea",
    											"benpincode","benstate","bencity","benemailId","bencontactNumber"];
    					}
    					else
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"empcompBuildName","empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"salutation2","beneficiaryFirstName2","beneficiaryLastName2","benefrelationShipWithMember","benefdateOfBirth2",
    											"bencompBuildName","benflatUnitNo","benstreatArea",
    											"benpincode","benstate","bencity","benemailId","bencontactNumber"];
    					}
    			}
    			else if($scope.sAClaimIntimation.annuityOption==4||$scope.sAClaimIntimation.annuityOption==14)
    			{
    					if($scope.sAClaimIntimation.Age<18 && $scope.sAClaimIntimation.Age!="")
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"empcompBuildName","empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"salutation2","beneficiaryFirstName2","beneficiaryLastName2","benefrelationShipWithMember","benefdateOfBirth2",
    											"bencompBuildName","benflatUnitNo","benstreatArea",
    											"benpincode","benstate","bencity","benemailId","bencontactNumber",
    											"spSalutation","spouseFirstName","spouseLastName","spousedateOfBirth",
    											"appointeeFName","appointeeLName","appointeeRelation"];
    					}
    					else
    					{
    						$scope.errorArray=["panNumber","typeOfClaim","dateType",
    											"payeeName","annudateOfBirth",
    											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    											"annuityOption","ifsc","micr","freqOfPayment",
    											"empcompBuildName","empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    											"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber",
    											"salutation2","beneficiaryFirstName2","beneficiaryLastName2","benefrelationShipWithMember","benefdateOfBirth2",
    											"bencompBuildName","benflatUnitNo","benstreatArea",
    											"benpincode","benstate","bencity","benemailId","bencontactNumber",
    											"spSalutation","spouseFirstName","spouseLastName","spousedateOfBirth"];
    					}
    			}
    			else
    			{
    				if($scope.sAClaimIntimation.modeOfPayment=='Electronic Credit')
    				{
    					$scope.errorArray=["panNumber","typeOfClaim","dateType","freqOfPayment","payeeName","annudateOfBirth",
											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo",
    										"annuityOption","ifsc","micr","empcompBuildName",
    										"empflatUnitNo","empstreatArea","emppincode","empstate","empcity",
    										"empemailId","empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber"];
    				}
    				else
    				{
    					$scope.errorArray=["panNumber","typeOfClaim","dateType","payeeName","annudateOfBirth",
											"annuitantsBankName","annuitantsBankBranch","annuitantsAccountNo","freqOfPayment",
    										"annuityOption","empcompBuildName","empflatUnitNo",
    										"empstreatArea","emppincode","empstate","empcity","empemailId",
    										"empcontactNumber","empbankName","empbankBranch","empaccountNo","bankcontactNumber"];
    				}
    			}
    		}	
    }//checkingErrorArrayfunctionClosed
    
}]);
							