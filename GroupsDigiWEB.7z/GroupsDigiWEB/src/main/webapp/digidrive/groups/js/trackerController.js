var app=angular.module('groupApp',['ui.materialize','uiValidations','ajaxUtil','ngRoute','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection','groupCommonUtil']);

app.controller('serviceTrackerController',['$rootScope','$scope','ajaxHttpFactory','$location','$window','$filter','$http','$rootScope','uiGridConstants','csrDocUploadFactory', function($rootScope,$scope,ajaxHttpFactory,$location,$window,$filter,$http,$rootScope,uiGridConstants,csrDocUploadFactory){
	
	$rootScope.preloaderCheck=true;
	$scope.trackType=[];
	$scope.trackStatus=[];
	$scope.logs={};
	$scope.errorArray=[];
	$scope.downloadTab=true;
	$scope.openTab=true;
	$scope.closeTab=true;
	$scope.successResponse='';
	var ajaxurl=$location.absUrl();
	$scope.result=[];
	$scope.trackerOpenCloseData=[];
	$scope.trackerOpenData=[];
	$scope.trackerCloseData=[];
	$scope.trackerOpenCloseViewDiv=false;
	$scope.trackerOpenViewDiv=false;
	$scope.trackerCloseViewDiv=false;

	 $scope.openClosed="openClose";
	 var paginationOptions = {
			    pageNumber: 1,
			    pageSize: 10,
			    sort: null
			  };
	 
	 $scope.trackerOpenCloseView = {			 				
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,			   
			    enableRowSelection: false,		      	     
		        resizable: false,
		        enableColumnResizing: false,
		        enableSorting: false,		       
		        
			    columnDefs: [
			      { field: 'requestId', displayName: 'REQUESTED ID', width: "20%"},
			      { field: 'requestTime', displayName: 'REQUESTED DATE', width: "20%"},			     			    
			      { field: 'functionalityName', displayName: 'FUNCTIONALITY', width: "20%"},			  
			      { field: 'status', displayName: 'STATUS', width: "20%"},
			      { field: 'updtTime', displayName: 'UPDATED DATE', width: "20%"}
			     	      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageOC();
			      });			      			 
			    }
			  };
	 
	 $scope.trackerOpenView = {			 				
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,			   			 
			    enableRowSelection: false,		      	      
		        resizable: false,
		        enableColumnResizing: false,
		        enableSorting: false,		       
		        
			    columnDefs: [
			                 { field: 'requestId', displayName: 'REQUESTED ID', width: "20%"},
						      { field: 'requestTime', displayName: 'REQUESTED DATE', width: "20%"},			     			    
						      { field: 'functionalityName', displayName: 'FUNCTIONALITY', width: "20%"},			  
						      { field: 'status', displayName: 'STATUS', width: "20%"},
						      { field: 'updtTime', displayName: 'UPDATED DATE', width: "20%"}
			     	      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageO();
			      });			      			 
			    }
			  };
	 
	 $scope.trackerCloseView = {			 				
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableRowSelection: false,		      	     
		        resizable: false,
		        enableColumnResizing: false,
		        enableSorting: false,		       
		        
			    columnDefs: [
			                 { field: 'requestId', displayName: 'REQUESTED ID', width: "20%"},
						      { field: 'requestTime', displayName: 'REQUESTED DATE', width: "20%"},			     			    
						      { field: 'functionalityName', displayName: 'FUNCTIONALITY', width: "20%"},			  
						      { field: 'status', displayName: 'STATUS', width: "20%"},
						      { field: 'updtTime', displayName: 'UPDATED DATE', width: "20%"}
			     	      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageC();
			      });			      			 
			    }
			  };
	 
	 $scope.getPageOC = function() {
		 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
	     $scope.trackerOpenCloseView.data=$scope.trackerOpenCloseData.slice(firstRow, firstRow + paginationOptions.pageSize);	     
	    
		};
		
		$scope.getPageC = function() {
			 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
			 $scope.trackerCloseView.data=$scope.trackerCloseData.slice(firstRow, firstRow + paginationOptions.pageSize);	     		     
			};
			
			$scope.getPageO = function() {
				 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);				 	    
			     $scope.trackerOpenView.data=$scope.trackerOpenData.slice(firstRow, firstRow + paginationOptions.pageSize);
				};

	
	var onLoadData=function(){			
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("LoadTacker",ajaxurl)
		.then(function(response){	
			
			if(ajaxHttpFactory.handleIPruException(response.data, "errorMessage-popup", "exceptionAlert")){
				$scope.openTab=false;
				$scope.closeTab=false;
				$scope.downloadTab=false;				
				$rootScope.preloaderCheck=false;
			}			
						
			$scope.result=response.data;	
			var openData=$scope.result.openList;
			$scope.trackerOpenData=openData;
			$scope.trackerOpenView.totalItems=$scope.trackerOpenData.length;
			
			var closeData=$scope.result.closeList;
			$scope.trackerCloseData=closeData;
			$scope.trackerCloseView.totalItems=$scope.trackerCloseData.length;
			
			for(var i=0;i<openData.length;i++){
				$scope.trackerOpenCloseData.push($scope.trackerOpenData[i]);
			}
			for(var j=0;j<closeData.length;j++){
				$scope.trackerOpenCloseData.push($scope.trackerCloseData[j]);
			}
			
			
			$scope.trackerOpenCloseView.totalItems=$scope.trackerOpenCloseData.length;
			
			if($scope.trackerOpenData.length==0){
				$scope.downloadTab=false;
			}else{
				$scope.downloadTab=true;
			}
			if($scope.trackerCloseData.length==0){
				$scope.downloadTab=false;
			}else{
				$scope.downloadTab=true;
			}
			if($scope.trackerOpenCloseData.length==0){
				$scope.downloadTab=false;
			}else{
				$scope.downloadTab=true;
			}

			$scope.trackerOpenCloseViewDiv=true;
			$scope.trackerOpenViewDiv=false;
			$scope.trackerCloseViewDiv=false;
			$scope.getPageOC();
			$scope.getPageC();
			$scope.getPageO();
			$rootScope.preloaderCheck=false;					
		},
		function(errResponse){
			$rootScope.preloaderCheck=false;			
		});
};
	
onLoadData();


$scope.openLogs=function(){	
	
	 angular.element( document.querySelector('#Death')).removeClass("claimbtn");
	 angular.element( document.querySelector('#nonDeath')).addClass("claimbtn");
	$rootScope.preloaderCheck=false;	
	$scope.trackerOpenCloseViewDiv=false;
	$scope.trackerOpenViewDiv=true;
	$scope.trackerCloseViewDiv=false;	
	$scope.openClosed="open";
};

$scope.closeLogs=function(){

	 angular.element( document.querySelector('#nonDeath')).removeClass("claimbtn");
	 angular.element( document.querySelector('#Death')).addClass("claimbtn");
	 
	$rootScope.preloaderCheck=false;	
	$scope.trackerOpenCloseViewDiv=false;
	$scope.trackerOpenViewDiv=false;
	$scope.trackerCloseViewDiv=true;	
	$scope.openClosed="close";
};

	
 
	$scope.downloadToExcel=function(){
		   $rootScope.preloaderCheck=true;	
		
		/*var xhr = new XMLHttpRequest();
		xhr.open("POST", "ExcelDownload.do");
		xhr.send("key" + encodeURIComponent($scope.openClosed));*/
		//$.post("ExcelDownload.do", { "key": $scope.openClosed });
			
		$http({
	        url: 'ExcelDownload.do',
	        method: 'POST',
	        responseType: 'arraybuffer',
	        data: JSON.stringify($scope.openClosed),
	        headers: {
	            'Content-type': 'application/json; charset=utf-8'
	        }
	    }).success(function(data) {
	        var blob = new Blob([data], {
	            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
	        });
	        var downloadUrl = URL.createObjectURL(blob);
	        var a = document.createElement("a");
	        a.href = downloadUrl;
	        a.download = "data.xls";
	        document.body.appendChild(a);
	        a.click();
	        //saveAs(blob, 'bidStatement' + '.xls');
	        $rootScope.preloaderCheck=false;
	    }).error(
	        function() {
	            // Some error log
	           // $rootScope.$broadcast('pageSpinner', false);
	        	$rootScope.preloaderCheck=false;
				ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ","errorMessage-popup", "bidAlert");

	        });
		
	};
	
/*	$scope.dataAlert= function (){
		$rootScope.openAlertID = false;											
		$window.location.href = "dashboard.htm";
	};*/


	$scope.successMethod = function(response) {		
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){					
			$scope.result=response;
			$rootScope.preloaderCheck=false;
		}
	};
		
	$scope.failureMethod = function(response) {
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){			
			$rootScope.preloaderCheck=false;
		}
	};	
    
	
	
	
	
}]);

