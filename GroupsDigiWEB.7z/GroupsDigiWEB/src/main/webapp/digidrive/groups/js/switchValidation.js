angular.module('switchValidation',[])
.factory('validiteSwitchService', function(){
	var errorMessage = "";
	
	var fundTransactionValidation = function(switchType,fromFund,toFund,amountOrUnitValue,switchFundDetails,fromFundCode,toFundCode,fundMaster) {
	
		errorMessage = "";
		//Maximum number of switch allowed
		if(!maxNoOfSwitchAllowed(switchFundDetails))
		{
			return errorMessage;
		}
		
		
		if(!checkFundTransaction(switchType,fromFund,toFund,amountOrUnitValue))
		{
			return errorMessage;
		}
		
		//Check if fund transfer has alreay been done from from and to fund. Eg If A -> B Again A -> B should not be allowed
		if(!checkTransferAlreadyDone(fromFund,toFund,switchFundDetails))
		{
			return errorMessage;
		}
		
		//Cannot transfer from Non CG to CG Fund
		if(!checkNonCGToCG(fromFundCode,toFundCode,switchFundDetails,fundMaster))
		{
			return errorMessage;
		}
		
		//No of digits post decimal point
		if(!noOfDigitPostDecimal(switchType,amountOrUnitValue))
		{
			return errorMessage;
		}
		
		return errorMessage;
	};
	
	
	var noOfDigitPostDecimal = function(switchType,amountOrUnitValue)
	{
		var digitPostDecimalArray = amountOrUnitValue.toString().split(".");
		var digitPostDecimal;
		
		if(digitPostDecimalArray.length == 2 )
		{
			digitPostDecimal = digitPostDecimalArray[1].length;
		}
			
		if(switchType == "Units")
		{
			if(digitPostDecimal > 3){
				errorMessage = "Max 3 digits post decimal point when switch type is Unit";
				return false;
			}
		}else if(switchType == "amount"){
			if(digitPostDecimal > 0){
				errorMessage = "Please enter whole number for amount. No decimal values when switch type is Amount";
				return false;
			}
		}
		
		return true;
		
	};
	
	
	var checkNonCGToCG = function(fromFundCode,toFundCode,switchFundDetails,fundMaster)
	{
	
		if(angular.isDefined(fundMaster) || fundMaster != "" )
		{
			for(var i = 0; i < fundMaster.length; i++)
			{
				if(fundMaster[i].fundCode == fromFundCode){
					isCGFromFund = fundMaster[i].isCapital;
				}
				
				else if(fundMaster[i].fundCode == toFundCode){
					isCGToFund = fundMaster[i].isCapital;
				}

			}
			
			if(isCGFromFund == "N" && isCGToFund == "Y")
			{
				errorMessage = "Cannot switch from Non CG Fund to CG Fund";
				return false;
			}	
				
			return true;
		}
		
		return true;
		
	};
	
	
	var maxNoOfSwitchAllowed = function(switchFundDetails)
	{
		if(angular.isDefined(switchFundDetails) || switchFundDetails != "" )
		{
			if(switchFundDetails.length > 9)
			{
				errorMessage = "Max number of switch should not be greater than 10";
				return false;
			}
		}
		
		return true;
		
	};
	
	var checkTransferAlreadyDone = function(fromFund,toFund,switchFundDetails)
	{
			
		for(var i = 0; i < switchFundDetails.length; i++)
		{
			if(switchFundDetails[i].fromFundName == fromFund && switchFundDetails[i].toFundName == toFund){
				errorMessage = "Fund transfer already done";
				return false;
			}
		}
		
		return true;
		
	};
	
	var checkFundTransaction = function(switchType,fromFund,toFund,amountOrUnitValue)
	{
		if(angular.isUndefined(switchType) || switchType == "" )
		{
			errorMessage = "Please select Switch Type";
			return false;
		}
		
		if(angular.isUndefined(fromFund) || fromFund == "" )
		{
			errorMessage = "Please select From Fund";
			return false;
		}
		
		if(angular.isUndefined(toFund) || toFund == "")
		{
			errorMessage = "Please select To Fund";
			return false;	
		}
		
		if(fromFund == toFund)
		{
			errorMessage = "From and To Fund cannot be the same";
			return false;	
		}
		
		if(angular.isUndefined(amountOrUnitValue) || amountOrUnitValue == "")
		{
			errorMessage = "Please select Amount or Unit value";
			return false;	
		}
		
		return true;
		
	};
	
	var switchValidation = function(validationParam)
	{
		errorMessage = "";

		if(validationParam.switchFundDetails.length == 0)
		{
			errorMessage = "Please make a fund allocation";
			return errorMessage;
		}
		
		if(checkMinimumSwitchAmount(validationParam) != "")
		{
			return errorMessage;
		}
		/*else if(!checkTotalFundPercentage(validationParam["skills"]))
		{
			errorMessage = "Switch percentage should not be greater than 100%.";
			return errorMessage;
		}*/
		
		/*if(angular.isUndefined(validationParam.isAgreedCheck) || !Boolean(validationParam.isAgreedCheck))
		{
			errorMessage = "Please read and accept the terms and conditions.";
			return errorMessage;
		}*/
		return errorMessage;
	};
	
	
	var checkMinimumSwitchAmount = function(validationParam)
	{
		errorMessage = "";

		if(validationParam.totalFundSwitchValue < Number(validationParam.productSwitchAmount.minSwitchAmount) || validationParam.totalFundSwitchValue > Number(validationParam.productSwitchAmount.maxSwitchAmount))
		{
			errorMessage = "Total Switch Amount must be between "+ Number(validationParam.productSwitchAmount.minSwitchAmount) + " and "+ Number(validationParam.productSwitchAmount.maxSwitchAmount);
			return errorMessage;
		}
		
		return errorMessage;
	};
	
	var validateFundAvailable = function(fromFund,toFund)
	{
		errorMessage = "";

		if(fromFund.length == 0)
		{
			errorMessage = "No From fund";
			return errorMessage;
		}
		
		if(toFund.length == 0)
		{
			errorMessage = "No To fund";
			return errorMessage;
		}
		return errorMessage;
	};
	
	
	return {
		validateFundTransaction: function(switchType,fromFund,toFund,amountOrUnitValue,switchFundDetails,fromFundCode,toFundCode,fundMaster){
 		      return fundTransactionValidation(switchType,fromFund,toFund,amountOrUnitValue,switchFundDetails,fromFundCode,toFundCode,fundMaster);
 		},
 		
		validateSwitch: function(validationParam){
			return switchValidation(validationParam);
		},
	
		validateFundAvailable: function(fromFund,toFund){
			return validateFundAvailable(fromFund,toFund);
		}
	};
});
