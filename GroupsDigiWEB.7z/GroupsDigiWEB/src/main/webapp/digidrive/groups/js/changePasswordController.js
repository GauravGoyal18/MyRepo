var app = angular.module('groupApp', ['ajaxUtil','uiValidations','ui.materialize','validationService','generalUtility']);

app.controller('changePasswordCtrl',['$scope','$rootScope','$location','ajaxHttpFactory','$window','validateFieldService', function($scope,$rootScope,$location,ajaxHttpFactory,$window,validateFieldService){ 

	$scope.passwordDetail={};
	$scope.detail={};
	$rootScope.preloaderCheck=false;	
	var passwordnew = "";

	
	 $scope.errorArray=[];
	
	$scope.submit=function()
	{
		$rootScope.preloaderCheck=true;
		if($scope.checkBasicFieldValidations()){
			
			if($scope.detail.oldPwd != $scope.detail.newPwd){
				
				if($scope.detail.newPwd == $scope.detail.confirmPwd){
					$scope.passwordDetail.oldPassword = $.jCryption.encrypt($scope.detail.oldPwd, passwordnew);
					$scope.passwordDetail.newPassword = $.jCryption.encrypt($scope.detail.newPwd, passwordnew);
					$scope.passwordDetail.confirmPassword = $.jCryption.encrypt($scope.detail.confirmPwd, passwordnew);
					
					var passwordDetail=angular.toJson($scope.passwordDetail);
					ajaxHttpFactory.postJsonDataSuccessFailure(passwordDetail,"POST",$location.absUrl(),"Submit",$scope.successMethod,$scope.failureMethod);
				}else{
					$rootScope.preloaderCheck=false;
					ajaxHttpFactory.showErrorSuccessMessagePopup("New password and Confirm password should be same","errorMessage-popup", "changePasswordAlert");
				}								
				
			}else{
				$rootScope.preloaderCheck=false;
				ajaxHttpFactory.showErrorSuccessMessagePopup("Old password and new password should be different","errorMessage-popup", "changePasswordAlert");					
			}					
			
		}else{
			$rootScope.preloaderCheck=false;
			ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details","errorMessage-popup", "changePasswordAlert");			
		}																								
	};
	
	$scope.checkBasicFieldValidations = function() {
	    if ($scope.errorArray.length > 0) {
	        for (var i = 0; i < $scope.errorArray.length; i++) {
	            var lengthBfr = $scope.errorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT" || errorElement.prop('type') == "password") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = $scope.errorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	        if ($scope.errorArray.length > 0) {
	            $("#" + $scope.errorArray[0]).focus();
	            return false;
	        } else {
	            return true;
	        }
	    } else {
	        return true;
	    }
	};
	
	$scope.resetBtn=function(){
		
		$scope.detail.oldPwd="";
		$scope.detail.newPwd="";
		$scope.detail.confirmPwd="";
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$('.err-msg').css("visibility", "");
		$scope.errorArray=["oldPassword","newPassword","confirmPassword"];

	}
		
	 $scope.successMethod = function(response) {	
	    	$rootScope.preloaderCheck=false;
	    	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
	    	if (response != null && response != "null") {								    	    	
	    		$rootScope.openAlertID = true;	    		
	    		$scope.message = "Your password has been changed successfully";		    		
	    	}
	    	}
	};	
	
	$scope.failureMethod=function(){														
		$rootScope.preloaderCheck=false;														
		$rootScope.openAlertID = true;
		//$scope.action="failure";
		$scope.message = "Some Error Occured.";
	};
	
	$scope.okAlert=function(){
		$rootScope.preloaderCheck=false;
		$rootScope.openAlertID = false;
		$scope.resetBtn();
	};
	
	$scope.generateIpruKey = function (){
		var hashObj = new jsSHA("mySuperPassword"+Math.random(), "ASCII");
		passwordnew = hashObj.getHash("SHA-512", "HEX");
	
	    var x = Math.floor((Math.random()*15000000)+1);
	    $.jCryption.authenticate(passwordnew, "encrypt?generateKeyPair=true&rnd="+x, "encrypt?handshake=true&rnd="+x,

	                 function(AESKey) {                                                                                                               

	                 },

	                 function() {
	                        // Authentication failed
	                 }
	    );
	};
	
	$scope.generateIpruKey();
	

}]);