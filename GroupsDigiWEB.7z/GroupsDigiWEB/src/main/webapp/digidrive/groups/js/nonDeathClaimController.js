var app = angular.module('groupApp',['uiValidations','ajaxUtil','ui.materialize','groupCommonUtil']);
app.controller('nonDeathClaimController',[ '$scope','ajaxHttpFactory','$location','$window','$rootScope','csrDocUploadFactory', function($scope,ajaxHttpFactory,$location,$window,$rootScope,csrDocUploadFactory){
	
	
//	$rootScope.preloaderCheck=true;
	$scope.submitJson = {};
	$scope.errorArray = [];
	$scope.submitJson.uploadFileList=[];
	$scope.uploadArray={};
	$rootScope.preloaderCheck=false;
	$scope.allowedExtensions=[];
	
	$rootScope.openAlertID = false;
	
	$scope.okalert= function()
	{
		$window.location.href = "dashboard.htm";	
	};
	
	$scope.OnSubmitBtn = function(){
		$rootScope.preloaderCheck=true;
		if($scope.submitJson != null && angular.isDefined($scope.submitJson)){
			if($scope.submitJson.uploadFileList.length>0){
				var submitJsonString = angular.toJson($scope.submitJson);
				var ajaxurl = $location.absUrl();				
				ajaxHttpFactory.postJsonDataSuccessFailure(submitJsonString,"POST",ajaxurl,"SubmitNonDeathClaim",$scope.submitSuccessMethod,$scope.submitFailureMethod);
				
			} else {
				$rootScope.preloaderCheck=false;
				ajaxHttpFactory.showErrorSuccessMessagePopup("Please upload file. ","errorMessage-popup", "fileErrorAlert");
			}
		} else {
			$rootScope.preloaderCheck=false;
		}
	};
	
	$scope.submitSuccessMethod = function(response) {
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			var fileUploadJson = angular.fromJson(response);
			if(fileUploadJson != null){
				var requestId = fileUploadJson.customerTrxnId;
				$rootScope.check = true;
				$scope.message = "Your request submitted successfully. Reference No : "+requestId;
				$scope.OnResetBtn();
				$rootScope.preloaderCheck=false;
			}
		}
	};
	
	$scope.submitFailureMethod = function(response) {
		$rootScope.preloaderCheck=false;
		
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			
		}		
	};
	
	$scope.OnResetBtn = function(){
		$scope.submitJson.uploadFileList=[];		
		var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
		m.empty();
		m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
		
		var m2 = angular.element( document.querySelector( '#file-upload-main_upText'));
		m2.empty();
		$rootScope.preloaderCheck=false;
	};
	
	
	$scope.upload = function(upId, docType) {
		$rootScope.preloaderCheck=true;
        var desc_Id = angular.element(document
            .querySelector('#' + upId.id+'_errMsg'));
        var upload_Msg = angular.element(document
            .querySelector('#' + upId.id + '_upText'));
            if(upId.files.length != 0){   
            	
            	//alert("upId.files"+upId.files+", desc_Id "+desc_Id+", upload_Msg"+upload_Msg+", " );
            	upload_Msg[0].innerHTML="";	
            	desc_Id[0].innerHTML="";
            	$scope.allowedExtensions=["xls","XLS","xlsx","XLSX"];
            	csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,'21',$scope.fileUploadCallBack,$scope.policynumber,'Upload File',$scope.allowedExtensions);
            }
	};
	
	$scope.fileUploadCallBack = function(uploadFileJsonResp, fileId, upload_Msg,message) {
    	
    	if(uploadFileJsonResp=="ERROR")
    	{
    		
    		//$rootScope.check = true;
  	    //  $scope.message = "Invalid file format.";
  	      
  	    upload_Msg[0].innerHTML =  message;
  	  $scope.submitJson.uploadFileList=[];
    		
    		//ajaxHttpFactory.showErrorSuccessMessagePopup(message, "errorMessage-popup","submitSuccessAlert");
    	return false;
    	}
    	
    	else
    	{
    		var fileUploadResJsonObj = angular.fromJson(uploadFileJsonResp);
    		// alert(fileUploadResJsonObj);
    		if (fileUploadResJsonObj != null &&
            fileUploadResJsonObj != '' && fileUploadResJsonObj != "") {

			if(fileUploadResJsonObj.errorCode!=undefined)
			{
				    	        			
				  ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
				  var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
				  m.empty();
				  m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
			
			}
			else
			{
        	for(var i=0;i<fileUploadResJsonObj.length;i++)
        		{
  
        		if(angular.fromJson(fileUploadResJsonObj[i]).errorCode=="0")
        		{
        			$scope.submitJson.uploadFileList.length=0;
        			$scope.submitJson.uploadFileList.push(angular.fromJson(fileUploadResJsonObj[i]));

	            if(fileId.length==1)
	            	{	            	
	             upload_Msg[0].innerHTML =  "Document uploaded successfully.";
	            	}
	            else if(fileId.length>1)
	            	{
	            	upload_Msg[0].innerHTML =  "Documents uploaded successfully.";
	            	}
	             //$rootScope.$broadcast('pageSpinner', false);
        		}
        		else
        		{
        			ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
        			  $scope.submitJson.uploadFileList=[];
        			var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
  				  	m.empty();
  				  	m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
  				  	
        		}
        		}
         
           }
            
        } else {
           // $scope.errSuccessAlertObj['status'] = 'ERROR';
            ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup", "submitSuccessAlert");
            var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
			m.empty();
			m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
        }
        
    		}
        $rootScope.preloaderCheck=false;
    };
	
}]);