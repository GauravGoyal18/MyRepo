
var app = angular.module('groupApp', ['ajaxUtil','uiValidations','ui.materialize','validationService']);

app.controller('nomineeUpdateController',['$scope','$location','ajaxHttpFactory','validateFieldService','$rootScope','$window', function($scope,$location,ajaxHttpFactory,validateFieldService,$rootScope,$window){
	
	
$rootScope.preloaderCheck=true;	

$scope.nomineeUpdate=[];
$scope.counts=[];
$scope.submitData={};
$scope.nomineeUpdateBean=[];
$scope.Nominee=[];
$scope.NomineePrePopulate=[];
$scope.prePopulateNominee=[];
$scope.nomineeUpdate=[];
$scope.errorArray = [];
$scope.nomineeCount=0;
$scope.totalShare=0;
$scope.relation=[];
$scope.gender=['male','female'];
$scope.deleteId='';
$scope.disableApponiteeName=[];
$scope.disableBenName=[];

$scope.requestPerDay=false;
$scope.changeNomineeHide=true;
$scope.changeNomineeButton=false;
$scope.discardNomineeButton=true;
$scope.noNominee=false;
$scope.action="";
$scope.nomineeUpdateAccessMatrix={};


$scope.validateFields = function(name,action)  
{
  
	$scope.id=name;
	$scope.action1=action;
	$scope.result = validateFieldService.fieldValidate($scope.id,$scope.action1,$scope.nomineeUpdateAccessMatrix);
	return $scope.result;
	
};
var fetchNomineeData = function () { 

	$rootScope.preloaderCheck=true;
	return ajaxHttpFactory.getJsonData("nomineeUpdateLoadData",$location.absUrl())
	.then(function(response) {
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
		if (response != null && response != "null") {
		
			
			var responseData = response.data;
			$scope.nomineeUpdateAccessMatrix = responseData.fieldAccessMappingMap;
			$rootScope.preloaderCheck=false;
			if(responseData.fieldAccessMappingMap=="undefined" ||responseData.fieldAccessMappingMap==undefined)
			{
				$rootScope.preloaderCheck=false;
				$scope.changeNomineeButton=true;
			}
			else
				{
			if(responseData.nomineeUpdatePo=="undefined" || responseData.nomineeUpdatePo==undefined)
			{
				
				$scope.changeNomineeHide=false;
				$scope.nomineeCount	= 0;
				$scope.Nominee.push('Nominee_0');
			
				 $scope.disableApponiteeName[0]=true;
				 $scope.changeNomineeButton=true;
				 $scope.noNominee=true;
				 $scope.requestPerDay=true;
			}
			else
			{
			var nomineeData=responseData.nomineeUpdatePo;

			
			$scope.requestPerDay=responseData.requestPerDay;
			
			
			if(nomineeData.length==0 || nomineeData.length<0 || nomineeData==null )
			{
				
				$scope.changeNomineeHide=false;
				$scope.nomineeCount	= 0;
				$scope.Nominee.push('Nominee_0');
				
				 $scope.disableApponiteeName[0]=true;
				 $scope.noNominee=true;
				 $scope.changeNomineeButton=true;
			}
			else
				{
			
			$scope.prePopulateNominee=nomineeData;
			
				
			
			
			for(var i=0;i<nomineeData.length;i++)
			{
				
				$scope.NomineePrePopulate.push('Nominee_'+i);
				$scope.counts.push(i);
				
			}
			
			
				}
			
			
			}
			
			var relationData=responseData.nomineeUpdateRelationPo;
			
			if(relationData.length<=0 || relationData==null || relationData=="null")
			{	
			
				

				
					ajaxHttpFactory.showErrorSuccessMessagePopup("Found null Relation list. ","errorMessage-popup", "nomineeAlert");
					
					$rootScope.preloaderCheck=false;
					$scope.changeNomineeButton=true;
				
				
				
			}	
			else
			{
				
					for(var i=0;i<relationData.length;i++)
					{
						$scope.relation.push(relationData[i].value);
					}
				
			}
			
			
			
			
		}
			
		}	
		
	}
		else
			{
			$rootScope.preloaderCheck=false;
		$scope.changeNomineeButton=true;
			}
		$rootScope.preloaderCheck=false;
	
	},
	function(errResponse) {
		
		//$scope.changeNomineeButton=true;
		$rootScope.preloaderCheck=false;

		if(!ajaxHttpFactory.handleIPruException(errResponse, "", "nomineeAlert"))
		{
		
			ajaxHttpFactory.showErrorSuccessMessagePopup("Something went wrong. ","errorMessage-popup", "nomineeAlert");
	
		}

	});
	
	

};


$rootScope.openAlertID = false;

$scope.okAlert= function (){
	$rootScope.openAlertID = false;
	if($scope.action=="delete")
		{
	if($scope.nomineeCount==0)
	{
	
		ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 nominee should be there. ","errorMessage-popup", "nomineeAlert");
	}
	else
		{
		
	$scope.nomineeCount= $scope.nomineeCount-1;
	  $scope.Nominee.splice($scope.deleteId,1);
	 $scope.disableApponiteeName.splice($scope.deleteId,1);
	
	  $scope.nomineeUpdate.splice($scope.deleteId,1);
	  
	  $scope.Nominee=[];
	  for(var i=0;i<=$scope.nomineeCount;i++)
		  {
		
		$scope.disableApponiteeName.push(i);
	  $scope.Nominee.push('Nominee_' +i);

		  }
		  
		  
		  }
		}
	else if($scope.action=="success")
		{
		$window.location.href = "dashboard.htm";
		}
	else if($scope.action=="failure")
		{
		$window.location.href = "onlogout.htm";
		}
	
};
$scope.cancelAlert= function (){
	$rootScope.openAlertID = false;
	$window.location.href = "dashboard.htm";

};

fetchNomineeData(); 

	$scope.deleteNominee = function(index){
		
		if($scope.nomineeCount==0)
		{
		
			ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 nominee should be there. ","errorMessage-popup", "nomineeAlert");
		}
		else
			{
		
		$rootScope.openAlertID = true;
		$scope.action="delete";
		$scope.message = "Are you sure want to delete";
		$scope.deleteId=index;
			}
		 
	};
	

$scope.addNominee  = function(){
	
	
	if ($scope.checkBasicFieldValidations())
	{
		
		$scope.totalSharePer=0;

		for(var i=0;i<$scope.nomineeUpdate.length;i++)
		{
			
		$scope.totalSharePer=parseInt($scope.totalSharePer)+parseInt($scope.nomineeUpdate[i].share);
		}
		
	if($scope.totalSharePer<100)
	{
	if($scope.nomineeCount<9)
	{
		$scope.nomineeCount	= $scope.nomineeCount+1;
		$scope.Nominee.push('Nominee_' +$scope.nomineeCount);
		
		
		$scope.disableApponiteeName[$scope.nomineeCount]=true;
		$scope.disableBenName[$scope.nomineeCount]=false;
		
	
	}
	else
		ajaxHttpFactory.showErrorSuccessMessagePopup("You cannot add more Nominees . ","errorMessage-popup", "nomineeAlert");	
	}
	else
		ajaxHttpFactory.showErrorSuccessMessagePopup("You cannot add more Nominees, Share% is 100% . ","errorMessage-popup", "nomineeAlert");	
	}
	else
		ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details for Nominee ","errorMessage-popup", "nomineeAlert");
		
	};
	
	
	
	
	
	
	$scope.changeNominee  = function(){
		
		$scope.changeNomineeButton=true;
		$scope.discardNomineeButton=false;
		if(!$scope.requestPerDay)
		{
			
			ajaxHttpFactory.showErrorSuccessMessagePopup("You can not send more than one request per day. ","errorMessage-popup", "nomineeAlert");	
			$scope.changeNomineeHide=true;
			
		}
		else
		{
		
			$scope.changeNomineeHide=false;
			$scope.nomineeCount	= 0;
			$scope.Nominee.push('Nominee_0');
		
			 $scope.disableApponiteeName[0]=true;
		
			
		}
		
		
		
		};
	
	
		$scope.discardNominee = function(){
			
			$scope.changeNomineeButton=false;
			$scope.discardNomineeButton=true;
			$scope.changeNomineeHide=true;
			$scope.nomineeUpdate=[];
			 $scope.nomineeCount=0;
			 $scope.Nominee=[];
		};
	
	
	
	
	
	
	




$scope.updateNominee=function()
{
	
	if ($scope.checkBasicFieldValidations())
	{	
		
	$rootScope.preloaderCheck=true;
	$scope.nomineeUpdateBean=[];
	$scope.totalShare=0;
	
	
	
	
	for(var i=0;i<$scope.nomineeUpdate.length;i++)
	{
		$scope.submitData=$scope.nomineeUpdate[i];
		
		$scope.totalShare=parseInt($scope.totalShare)+parseInt($scope.nomineeUpdate[i].share);

		
	
	
	

	for (var key in $scope.submitData) {
	  var tempObj = {};
	  tempObj["fieldId"]=key+"_"+i;
	  tempObj["value"] = $scope.submitData[key];
	  if($scope.submitData[key]!="")
	  $scope.nomineeUpdateBean.push(tempObj);
	  
	}

	}
	var updateNomineeSubmit=angular.toJson($scope.nomineeUpdateBean);
	var ajaxurl=$location.absUrl();
	
	if($scope.totalShare!=100)
	{

		$rootScope.preloaderCheck=false;
		ajaxHttpFactory.showErrorSuccessMessagePopup("Total Share % should be 100%. ","errorMessage-popup", "nomineeAlert");	
	}
	else{
	ajaxHttpFactory.postJsonDataSuccessFailure(updateNomineeSubmit,"POST",ajaxurl,"updateNomineeSubmit",$scope.successMethod,$scope.failureMethod);

	}
	
	}
	else
		{
		
		ajaxHttpFactory.showErrorSuccessMessagePopup("Enter Mandatory Fields. ","errorMessage-popup", "nomineeAlert");
		}
	
};




$scope.checkBasicFieldValidations = function() {
	var deleteDetails=false;
    if ($scope.errorArray.length > 0) {
    	
    	var arrlength=$scope.errorArray.length;
    	for(var j=0;j<$scope.errorArray.length;j++)
    	{
    		 
    		if(deleteDetails)
    		{
    			j=0;
    		}
    		var index=parseInt($scope.errorArray[j].indexOf("_"));
			var count=$scope.errorArray[j].substring(index+1,$scope.errorArray[j].length);
    		if($scope.errorArray[j].indexOf("apointee")==0)
    		{
    			
    			
    			if($scope.disableApponiteeName[parseInt(count)]  ||  $scope.disableApponiteeName[parseInt(count)]==undefined ||  $scope.disableApponiteeName[parseInt(count)]=="undefined" || $scope.disableApponiteeName[parseInt(count)]==0)
    			{
    				$scope.errorArray.splice(j, 1);
    				deleteDetails=true;
    				j--;
    			}
    			else
    				{
    				deleteDetails=false;
    				}
    			
    			
    			
    		}
    		else
    		{
    			if($scope.nomineeUpdate[parseInt(count)]==undefined)
    			{
    				$scope.errorArray.splice(j, 1);
    				deleteDetails=true;
    				j--;
    			}
    			else
    				{
    				deleteDetails=false;
    				}
    			
    		}
    		
    		 
    		 
    	}
    	
    	
        for (var i = 0; i < $scope.errorArray.length; i++) {
            var lengthBfr = $scope.errorArray.length;
            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
                errorElement.triggerHandler("blur");
            }
            var lengthAftr = $scope.errorArray.length;
            if (lengthAftr < lengthBfr) {
                i--;
            }
        }
        
        
        
        
        if ($scope.errorArray.length > 0) {
            $("#" + $scope.errorArray[0]).focus();
            
            return false;
        } else {
            return true;
        }
    } else {
        return true;
    }
};

$rootScope.$on('isOkClicked', function(event, args) {
	 if (args == 'exceptionAlert') {
		alert("Exception came") ;
	 } if (args == 'submitSuccessAlert') {
		
	 }		 
});

$scope.successMethod=function(response)
{$rootScope.preloaderCheck=false;
	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
	
	if (response != null && response != "null") {
		var requestId=angular.fromJson(response);
		$rootScope.openAlertID = true;
		$scope.action="success";
		$scope.message = "Your request submitted successfully with request Id "+requestId.customerTrxnId;
		//$scope.action="success";
	}
	}
	
};
$scope.failureMethod=function(){
	
	$rootScope.preloaderCheck=false;
	
	$rootScope.openAlertID = true;
	$scope.action="failure";
	$scope.message = "Some Error Occured.";
};



$scope.calculateAge = function(birthday) { 
	

    var ageDifMs = Date.now() - birthday.getTime();
    var ageDate = new Date(ageDifMs); 
   
    
    return Math.abs(ageDate.getUTCFullYear() - 1970);
};

var currentTime = new Date();
$scope.currentTime = currentTime;
$scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
$scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
$scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
$scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

$scope.today = '';
$scope.clear = 'Clear';
$scope.close = 'Done';
var days = 100;
$scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
$scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
$scope.onStart = function () {
  
};
$scope.onRender = function () {
   
};
$scope.onOpen = function () {
   
    
   

    
};
$scope.onClose = function () {
	$(".picker__holder").blur();
  
    

    
    
};




$scope.onSet = function (index) {
	
	if($scope.nomineeUpdate[index]!='' && $scope.nomineeUpdate[index]!=undefined)
	{
    $scope.birthday= new Date($scope.nomineeUpdate[index].dob);
    $scope.age= $scope.calculateAge($scope.birthday);
    if($scope.age<18)
    {
    	
    	
    	// $scope.disableApponiteeName[index]=false;
    	// $scope.nomineeUpdate[index].apointeeFirstappointeeName="";
    	 //$scope.nomineeUpdate[index].apointeeLasttappointeeName="";
    	 //$scope.nomineeUpdate[index].apointeeRelation="";
    	 //$scope.nomineeUpdate[index].apointeeDob="";
    	 //$scope.nomineeUpdate[index].apointeeGender="";
    	
    	
    	 
    }
    else	
    {
    	 
    	 $scope.disableApponiteeName[index]=true;
    }
	}
};
$scope.onStop = function () {
   
};
$scope.checkDate= function(currentElement,errorMsgElement){
if(angular.element(document.getElementById(currentElement)).val()=="")
	{
	angular.element(document.getElementById(currentElement)).addClass('invalid1');
	angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
	return false;
	}
else
	{
	angular.element(document.getElementById(currentElement)).removeClass('invalid1');
	angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
	}
return true;
}
    

    
}]);