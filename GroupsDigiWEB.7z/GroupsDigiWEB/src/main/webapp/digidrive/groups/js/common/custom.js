/*header js*/
login();
/*mega menu desktop js*/
if ($(window).width() > 1200) {
    $(".scheme-hold li").hover(schemes);
    $(".tabs-menu li").hover(tabs);
    $(".inner-tabs li").hover(tabs);
};

/*mega menu tab and mobile js*/
if ($(window).width() < 1100) {
    tab();
};

if ($(window).width() < 760) {
    mobile();
}


/*header js ends here*/

/*get quote page js*/
$(".gendernew, .age, .smoking, .see-buybotton button").fadeTo(100, 0.1);
$(".policy input:radio").click(function() {
    $(".gendernew").fadeTo(100, 1);
    $('.gendernew input:radio').removeAttr('disabled');
});
$(".gendernew input:radio").click(function() {
    $(".age").fadeTo(100, 1);
    $('.age input:radio').removeAttr('disabled');
    $(".smoking").fadeTo(100, 1);
    $('.smoking input:radio').removeAttr('disabled');
});
$(".smoking input:radio").click(function() {
    $(".see-buybotton button").fadeTo(100, 1);
    $('.see-buybotton button').removeAttr('disabled');
    $('.see-buybotton button').hover(function() {
        $(this).css("transform", "scale(0.9)");
    }, function() {
        $(this).css("transform", "scale(1.0)");
    });
});
if ($('#after').text() != '') {
    $('#after').bootstrapNumber();
}
if ($('#colorful').hasClass('colorful')) {
    $('#colorful').bootstrapNumber({
        upClass: 'more',
        downClass: 'less'
    });
}
if ($(window).width() < 767) {
    $(".policy input:radio").click(function() {
        $('html,body').animate({
                scrollTop: $(".gendernew").offset().top - 5
            },
            'slow');
    });
    $(".gendernwe input:radio").click(function() {
        $('html,body').animate({
                scrollTop: $(".age").offset().top - 5
            },
            'slow');
    });
    $(".smoking input:radio").click(function() {
        $('html,body').animate({
                scrollTop: $(".callbtn").offset().top - 300
            },
            'slow');
    });
}
$(".age").on("keypress keyup blur", function(event) {
    $(this).val($(this).val().replace(/[^\d].+/, ""));
    if ((event.which > 57)) {
        event.preventDefault();
    }
});
if ($(window).width() < 980) {
    $(".gendernew input:radio").click(function() {
        $('html,body').animate({
                scrollTop: $(".age").offset().top - 5
            },
            'slow');
    });
    $(".smoking input:radio").click(function() {
        $('html,body').animate({
                scrollTop: $(".callbtn").offset().top - 300
            },
            'slow');
    });
}
$(".age").on("keypress keyup blur", function(event) {
    $(this).val($(this).val().replace(/[^\d].+/, ""));
    if ((event.which > 57)) {
        event.preventDefault();
    }
});


/*gratification js part*/
if ($("#owl-benefits").text() != '') {
    var owl = $("#owl-benefits");
    owl.owlCarousel({
        items: 3, //10 items above 1000px browser width
        itemsDesktop: [2200, 3], //5 items between 1000px and 901px
        itemsDesktopSmall: [1199, 2], // betweem 900px and 601px
        itemsTablet: [992, 2], //2 items between 600 and 0
        itemsMobile: [600, 1], // itemsMobile disabled - inherit from itemsTablet option
        navigation: true,
        navigationText: ["<span class='glyphicon glyphicon-chevron-left' aria-hidden='true'></span>", "<span class='glyphicon glyphicon-chevron-right' aria-hidden='true'></span>"],
        rewindNav: true,
        pagination: false
    });
}

if ($("#premium-calender").text() != '') {
    var owl = $("#premium-calender");
    owl.owlCarousel({
        items: 3, //10 items above 1000px browser width
        itemsDesktop: [2200, 3], //5 items between 1000px and 901px
        itemsDesktopSmall: [1199, 3], // betweem 900px and 601px
        itemsTablet: [992, 2], //2 items between 600 and 0
        itemsMobile: [600, 1], // itemsMobile disabled - inherit from itemsTablet option
        navigation: true,
        navigationText: ["<span class='glyphicon glyphicon-chevron-left' aria-hidden='true'></span>", "<span class='glyphicon glyphicon-chevron-right' aria-hidden='true'></span>"],
        rewindNav: true,
        pagination: false
    });
}

$('.prcnt-btns .prcnt-list').click(function() {
    $(this).parent('li').siblings().removeClass('active');
    $(this).parent('li').addClass('active');
    var id1 = $(this).attr('id');
    if (id1 == 'ten-prcnt' || id1 == 'twlve-prcnt' || id1 == 'fiftn-prcnt') {
        $('.footer').hide();
        $('.cash-head, .secondary-head').fadeOut(100);
        $('.extra-points').css('display', 'none');
        $('main.content').addClass('no-header');
        $('.close').fadeIn(50);
    };
});
$('.header-tital .close').click(function() {
    $('.footer').show();
    $('.cash-head, .secondary-head').fadeIn(100);
    $('.extra-points').css('display', 'block');
    $('.close').fadeOut(50);
    $('main.content').removeClass('no-header');
});
/*if ($(window).width() < 767) {
    $(".open-list").click(function() {
        $(this).parent().siblings().children(".footer-list").slideUp();
        $(this).parent().children(".footer-list").slideToggle();
    });
};*/
if ($('.scroll-pane').text() != '') {
    $('.scroll-pane').jScrollPane({
        autoReinitialise: true
    });
}

function reposition() {
    var modal = $(this),
        dialog = modal.find('.modal-dialog');
    modal.css('display', 'block');
    // Dividing by two centers the modal exactly, but dividing by three 
    // or four works better for larger screens.
    dialog.css("margin-top", Math.max(0, ($(window).height() - dialog.height()) / 2));
}
// Reposition when a modal is shown
$('.modal').on('show.bs.modal', reposition);
// Reposition when the window is resized
$(window).on('resize', function() {
    $('.modal:visible').each(reposition);
});
/*Smart Login JS*/
//////// Tab Jqery Start//////
$(document).ready(function() {
    //Horizontal Tab


    if ($('.smart-tabs').text() != '') {

        // Child Tab
        $('#ChildVerticalTab_1').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true,
            tabidentify: 'ver_1', // The tab groups identifier
            activate: function() {

                var idx = $(this).index();
                var tabindex = $(".resp-tab-content:eq(" + idx + ")");
                tabindex.siblings(".resp-tab-content").find(".err-msg").css("visibility", "hidden");
                tabindex.siblings(".resp-tab-content").find(".form-row").find("input, select").val("").removeClass("on");
                tabindex.siblings(".resp-tab-content").find("input, select").removeClass("invalid1");
                $("select").removeClass("invalid1");
                $("select").siblings(".err-msg").css("visibility", "hidden");
                $(".getotpbutton").fadeTo(100, 0.2);
                $(".getotpbutton").attr("disabled", "disabled");
                $(".getotp_text").hide();

                /*if ($('.fixheighttab').text() != '' && $(window).width() > 767) {
                    $('.fixheighttab').jScrollPane();
                }*/
            },
            activetab_bg: '#fff', // background color for active tabs in this group
            inactive_bg: '#F5F5F5', // background color for inactive tabs in this group
            active_border_color: '#c1c1c1', // border color for active tabs heads in this group
            active_content_border_color: '#5AB1D0' // border color for active tabs contect in this group so that it matches the tab head border
        });
        //Vertical Tab
        var tabHeight = $('.resp-tab-item').outerHeight(true);
        var ibank = $('.ibank');
        var adhar = $('.aadhaar');
        var basicinfo = $('.basic');
        var tab_to_hide = [];
        hideTab(tab_to_hide);
        var tabcount = $('#smart-tab').children('li').length;
        //alert(tabcount);
        var smrt_type = $('.smart-logintital');
        smrt_type.css('padding-top', 0);
        //smrt_type.outerHeight(150 * (tabcount - 1));
        //alert(smrt_type.outerHeight());
        //alert($('.smart1').width());

        smrt_type.css('padding-top', (((smrt_type.outerHeight() - $('.smart1').width()) / 2) + 40));
        //smrt_type.css('padding-top', 70);
        /*
                        $("#panotp").click(function() {
                               
                                });*/
    }

    $('label').on('click', function() {
        if ($(this).parent().find('select').length >= 1) {
            //   open($(this).prev('select'));
        }
    });



});


function validatePan(panNumber) {
    var regpan = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
    return regpan.test(panNumber);
}

function hideTab(tab_to_hide) {
    var _tab = $('#smart-tab');
    var _tab_content = $('#smart-tab-content');
    var smrt_type = $('.smart-logintital');
    var smrt_type1 = $('.smart-logintital2');
    tab_to_hide.sort(function(a, b) {
        return a - b
    });
    var counter = 0;
    for (var i = 0; i < tab_to_hide.length; i++) {
        var toremove = tab_to_hide[i];
        _tab.find('li:eq(' + toremove + ')').remove();
        _tab_content.find('.resp-tab-content:eq(' + toremove + ')').remove();
        _tab_content.find('.resp-accordion:eq(' + toremove + ')').remove();
        switch (toremove) {
            case 0:
                if (counter == 0) {
                    smrt_type.outerHeight(300).css('padding-top', (smrt_type.outerHeight() - $('.smart1').height()) / 2);
                } else if (counter == 1) {
                    smrt_type.outerHeight(150).css('padding-top', (smrt_type.outerHeight() - $('.smart1').height()) / 2);
                } else {
                    smrt_type.remove();
                }
                break;
            case 1:
                $('.aadhaar .tab-or').hide();
                if (counter == 0) {
                    smrt_type.outerHeight(300).css('padding-top', (smrt_type.outerHeight() - $('.smart1').height()) / 2);
                } else if (counter == 1) {
                    smrt_type.outerHeight(150).css('padding-top', (smrt_type.outerHeight() - $('.smart1').height()) / 2);
                } else {
                    smrt_type.remove();
                }
                break;
            case 2:
                $('.pan .tab-or').hide();
                if (counter == 0) {
                    smrt_type.outerHeight(300).css('padding-top', (smrt_type.outerHeight() - $('.smart1').height()) / 2);
                } else if (counter == 1) {
                    smrt_type.outerHeight(150).css('padding-top', (smrt_type.outerHeight() - $('.smart1').height()) / 2);
                } else {
                    smrt_type.remove();
                }
                break;
            case 3:
                smrt_type.outerHeight(450).css('padding-top', (smrt_type.outerHeight() - $('.smart1').height()) / 2);
                if (counter == 1) {
                    smrt_type.outerHeight(300).css('padding-top', (smrt_type.outerHeight() - $('.smart1').height()) / 2);
                }else if (counter == 2) {
                    smrt_type.outerHeight(150).css('padding-top', (smrt_type.outerHeight() - $('.smart1').height()) / 2);
                }
                $('.basic').hide();
                smrt_type1.remove();

                break;
            default:
        }
        counter++;
    }
    _tab.find('li:eq(0)').addClass('resp-tab-active');
    _tab_content.find('.resp-tab-content:eq(0)').addClass('resp-tab-content-active');
    _tab_content.find('.resp-accordion:eq(0)').addClass('resp-tab-active');
}

function validateMobile(mobilenumber) {
    console.log(mobilenumber.length);
    if (mobilenumber.length < 10 || mobilenumber.length > 12) {
        return false
    } else {
        return true
    }
}

function reset(fn) {
    return fn ? this.bind("reset", fn) : this.trigger("reset");
};
//////// Tab Jqery End//////   
///////only tab submit jquery////
var mobilevalidate;
$(".tabsubmit").click(function(e) {
    e.preventDefault();
    e.stopPropagation();
    $(".resp-tab-content-active .form-row input, select").siblings(".resp-tab-content").children("input").removeClass("invalid1");
    $(".resp-tab-content-active .form-row input, select").siblings(".resp-tab-content").children(".err-msg").css("visibility", "hidden");
    $(".resp-tab-content-active .form-row input").not(".not-mand").each(function() {
        var value = $(this).val()
        if ($('#icici-account-number').is(':visible')) {
            // alert('is visible');
            if ($('#icici-account-number').val().length < 12 || $('#icici-account-number').val().length > 12) {
                $('#icici-account-number').addClass("invalid1");
                $('#icici-account-number').siblings(".err-msg").css("visibility", "visible");
            }
        }

        if ($(this).hasClass('mobile-no')) {
            mobilevalidate = validateMobile(value);
        }

        if (value == "" || value.length < 4) {
            $(this).addClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "visible");
        } else {
            $(this).removeClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "hidden");
            // return true;
        }
        if ($(this).hasClass('mobile-no')) {
            if (mobilevalidate == false) {
                $(this).addClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "visible");
            } else {
                $(this).removeClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "hidden");
                //return true;
            }
        }


        // alert('is mobile number');

    });
    $('.resp-tab-content-active .form-row select').each(function() {
        if ($(this).is(':visible')) {
            var selval = $(this).find("option:selected").val();
            //  alert(selval);
            if (selval == "") {
                //alert('in if');
                $("select").addClass("invalid1");
                $("select").siblings(".err-msg").css("visibility", "v]isible");
            } else {
                // alert('in else');
                $("select").removeClass("invalid1");
                $("select").siblings(".err-msg").css("visibility", "hidden");
            };
        }

    });

    if ($(this).parent().siblings().hasClass('personal-info')) {
        //alert("personal info button");
        var radioselected = $(this).parent().siblings('.personal-info').find('.toggle-btn-grp input[type="radio"]:checked').val();
        //alert(radioselected);

        if ($('.dependant-info').is(':visible') == false) {
            $('.dependant-info').find('input,select').removeClass('invalid1');
            $('.dependant-info').find('input,select').siblings('.err-msg').css('visibility', 'hidden');
        }
        if ($('.personal-info').is(':visible') == false) {
            $('.personal-info').find('input,select').removeClass('invalid1');
            $('.personal-info').find('input,select').siblings('.err-msg').css('visibility', 'hidden');
        }
        if (radioselected == 'dependant' && $(this).parent().siblings().children().find('input,select').hasClass('invalid1') == false) {
            $('.personal-info').fadeOut(500).removeClass('active');
            setTimeout(function() {
                $('.dependant-info').fadeIn(500).addClass('active');
                $('.personal-info').siblings().children('.backbtn').show();
                $('.personal-info').siblings().children('.tabsubmit').text('Continue to Benefits').blur();
                if ($(window).width() < 480) {
                    $('.personal-info').siblings().children('.backbtn').text('Back to Personal Details');
                }
            }, 400);
        } else {
            //  return false
        }

    }

    if ($(this).parent().siblings().children().find('input,select').hasClass('invalid1') == false) {
        // alert("all successful");
        var indxbasic = $(this).parents('.resp-tabs-container').prev('#smart-tab').children('li.basic').index();
        //alert(indxbasic);
        $(this).parents('.resp-tabs-container').prev('#smart-tab').children('li').not('.basic').addClass('disabled-tab').off('click').css('cursor', 'not-allowed');
        $(this).parents('.resp-tabs-container').prev('#smart-tab').children('li.basic').addClass('resp-tab-active');
        $(this).parents('.resp-tabs-container').find('div.resp-tab-content').removeClass('resp-tab-content-active').hide();
        $(this).parents('.resp-tabs-container').find('div.resp-tab-content:eq(' + indxbasic + ')').addClass('resp-tab-content-active').show();
        if ($(window).width() < 768) {
            $(this).parents('.resp-tabs-container').find('h2.resp-accordion').removeClass('resp-tab-active').off("click");
            $(this).parents('.resp-tabs-container').find('h2.resp-accordion:eq(' + indxbasic + ')').addClass('resp-tab-active');
        }
    }


});
$('.backbtn').click(function(e) {
    e.preventDefault();

    /*   if ($(this).parent().siblings().children().find('input,select').hasClass('invalid1') == false) {*/
    $('.dependant-info').fadeOut(500).removeClass('active');
    setTimeout(function() {
        $('.personal-info').fadeIn(500).addClass('active');
        $('.personal-info').siblings().children('.backbtn').hide();
        $('.personal-info').siblings().children('.tabsubmit').text('Continue').blur();
    }, 500);
    /*}*/

});
///////only tab submit jquery////
//////// Get OPT Jqery Start//////  
$(".getotp_text").hide();
$(document).ready(function() {
    $('.getotpbutton').click(function() {
        $(".getotp_text").show();
    });
});
//////// Get OPT Jqery End//////
$(".otpmassage").hide();
$(".resendotp").click(function() {
    $(".otpmassage").show();
    $(".resendmassge").hide();
});
$(".form-row input").on('change', function() {
    var value = $(this).val()
    if (value == "" || value.length < 1) {
        $(this).addClass("invalid1");
        $(this).siblings(".err-msg").css("visibility", "visible");
    };
});
$("select#retirement-gender").on({
    "change": function() {
        $("#retirement-gender option").each(function() {
            console.log($(this).val());
        });
    }
}).trigger("change");
$(".aadhaarnumber").keyup(function() {
    var mmfAmount = $(".aadhaarnumber").val();
    if (mmfAmount.length == 12) {
        $(".getotpbutton").fadeTo(100, 1.0);
        $(".getotpbutton").removeAttr("disabled");
        $(".getotpbutton").hover(function() {
            $(this).css("transform", "scale(0.9)");
        }, function() {
            $(this).css("transform", "scale(1.0)");
        });
    } else {
        $(".getotpbutton").fadeTo(100, 0.2);
        $(".getotpbutton").attr("disabled", "disabled");
    }
});

$('.panno').on('keyup', function() {
    var panvalue = $(this).val();
    console.log(panvalue);
    if (validatePan(panvalue) == true) {
        // alert("pan wrong");
        $("#panotp").fadeTo(100, 1.0);
        $("#panotp").removeAttr("disabled");
        $("#panotp").hover(function() {
            $(this).css("transform", "scale(0.9)");
        }, function() {
            $(this).css("transform", "scale(1.0)");
        });
    } else {
        $("#panotp").fadeTo(100, 0.2);
        $("#panotp").attr("disabled", "disabled");
    }

});

/*$('select').on("focus", function(event) {
    var cb = document.getElementsByTagName('select').addEventListener(
        'mousedown',
        function(e) { console.log('event triggered'); }, false);
    console.log('before call');
    simulateClick();
    console.log('after call');
});

function simulateClick() {
    var test = new MouseEvent('test');
    var event = new MouseEvent('mousedown', { 'view': window, 'bubbles': true, 'cancelable': true });
    var cb = document.getElementsByTagName('select');
    cb.dispatchEvent(event);
}*/

/*smart login js ends here*/

$(document).ready(function() {
    if ($('.agencyTab').text() != '') {
        //Horizontal Tab
        $('.agencyTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical,
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function() {
                var idx = $(this).index();
                var tabindex = $(".resp-tab-content:eq(" + idx + ")");
                tabindex.siblings(".resp-tab-content").find(".err-msg").css("visibility", "hidden");
                tabindex.siblings(".resp-tab-content").find(".form-row").find("input").val("").removeClass("on");
                tabindex.siblings(".resp-tab-content").find("input").removeClass("invalid1");
            },
        });
    }
});
$(document).ready(function() {
    //Horizontal Tab
    if ($('.corporateagentTab').text() != '') {
        $('.corporateagentTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function() {
                var idx = $(this).index();
                var tabindex = $(".psf .resp-tab-content:eq(" + idx + ")");
                tabindex.siblings(".resp-tab-content").find(".err-msg").css("visibility", "hidden");
                tabindex.siblings(".resp-tab-content").find(".form-row").find("input").val("").removeClass("on");
                tabindex.siblings(".resp-tab-content").find("input").removeClass("invalid1");
            },
        });
    }
});
$(document).ready(function() {
    if ($('.psfTab').text() != '') {
        //Horizontal Tab
        $('.psfTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function() {
                var idx = $(this).index();
                var tabindex = $(".psf .resp-tab-content:eq(" + idx + ")");
                tabindex.siblings(".resp-tab-content").find(".err-msg").css("visibility", "hidden");
                tabindex.siblings(".resp-tab-content").find(".form-row").find("input").val("").removeClass("on");
                tabindex.siblings(".resp-tab-content").find("input").removeClass("invalid1");
            },
        });
    }
});
$(".agency, .corporateagent, .broker, .psf, .scb").hide();
$(document).ready(function() {
    $(".agenttabs .form-row select").change(function() {
        $(this).find("option:selected").each(function() {
            if ($(this).attr("value") == "agency") {
                $(".agency").show();
                $(".corporateagent, .broker, .psf, .scb").hide();
                $(".resp-tab-content").find(".err-msg").css("visibility", "hidden");
                $(".resp-tab-content").find(".form-row").find("input").val("").removeClass("on");
                $(".resp-tab-content").find("input").removeClass("invalid1");
            }
            if ($(this).attr("value") == "corporateagent") {
                $(".corporateagent").show();
                $(".agency, .broker, .psf, .scb").hide();
                $(".resp-tab-content").find(".err-msg").css("visibility", "hidden");
                $(".resp-tab-content").find(".form-row").find("input").val("").removeClass("on");
                $(".resp-tab-content").find("input").removeClass("invalid1");
            }
            if ($(this).attr("value") == "broker") {
                $(".broker").show();
                $(".agency, .corporateagent, .psf, .scb").hide();
                $(".resp-tab-content").find(".err-msg").css("visibility", "hidden");
                $(".resp-tab-content").find(".form-row").find("input").val("").removeClass("on");
                $(".resp-tab-content").find("input").removeClass("invalid1");
            }
            if ($(this).attr("value") == "psf") {
                $(".psf").show();
                $(".agency, .corporateagent, .broker, .scb").hide();
                $(".resp-tab-content").find(".err-msg").css("visibility", "hidden");
                $(".resp-tab-content").find(".form-row").find("input").val("").removeClass("on");
                $(".resp-tab-content").find("input").removeClass("invalid1");
            }
            if ($(this).attr("value") == "scb") {
                $(".scb").show();
                $(".agency, .corporateagent, .broker, .psf").hide();
                $(".resp-tab-content").find(".err-msg").css("visibility", "hidden");
                $(".resp-tab-content").find(".form-row").find("input").val("").removeClass("on");
                $(".resp-tab-content").find("input").removeClass("invalid1");
            }
        });
    }).change();
});
/*agent register ends here*/
/*fund allocation starts here*/
$(".top").click(function() {
    $('html,body').animate({
            scrollTop: $("#top").offset().top + 50
        },
        800);
});

$('.alloctioninp').attr('maxlength', 2);

if ($(window).width() < 992) {

    $('.allocationscroll').find('.panel-heading a').addClass('collpase');
    $('.allocationscroll').find('.panel-collapse.collapse').removeClass('in');

}
$(".incomefund").keyup(function() {
    var mmfAmount = $(".incomefund").val();
    if (mmfAmount > 0) {
        $("#applyATS").removeClass("hidden");
        $(".red").removeClass("hidden");
    } else {
        $("#applyATS").addClass("hidden");
        $(".red").addClass("hidden");
    }
});
$(".incomefund").change(function() {
    var mmfAmount = $(".incomefund").val();
    if (mmfAmount > 0) {
        $("#applyATS").removeClass("hidden");
    } else {
        $("#applyATS").addClass("hidden");
    }
});
$(".moneymarketfund").keyup(function() {
    var mmfAmount = $(".moneymarketfund").val();
    if (mmfAmount > 0) {
        $("#applyATS").removeClass("hidden");
        $(".red").removeClass("hidden");
    } else {
        $("#applyATS").addClass("hidden");
        $(".red").addClass("hidden");
    }
});
$(".moneymarketfund").change(function() {
    var mmfAmount = $(".moneymarketfund").val();
    if (mmfAmount > 0) {
        $("#applyATS").removeClass("hidden");
    } else {
        $("#applyATS").addClass("hidden");
    }
});
$(document).ready(function() {
    $(".applay").keydown(function() {
        $("applay").css("cursor", "not-allowed");
    });
    $(".applay").keyup(function() {
        $("applay").css("cursor", "disabled");
    });
});
$(document).ready(function() {
    $(".widthhun .btn-primary:last-child").click(function() {
        $("label").removeClass("colorbg");
    });
});
if ($('.accordion').text() != '') {
    // $('.accordion').accordion();
    $('.accordion > ul > li > a').click(function(e) {
        e.preventDefault();
        $(this).parent().siblings().removeClass('active').find('.accor-content').slideUp();
        $(this).next('.accor-content').slideToggle().parent().toggleClass('active');
    });
}

if ($('.accordion').text() != '') {
    // $('.accordion').accordion();
    $('.accordion > ul > li > a').click(function(e) {
        e.preventDefault();
        $(this).parent().siblings().removeClass('active').find('.policy-content').slideUp();
        $(this).next('.policy-content').slideToggle().parent().toggleClass('active');
    });
}

if ($('.accordion').text() != '') {
    // $('.accordion').accordion();
    $('.accordion > ul > li > a').click(function(e) {
        e.preventDefault();
        $(this).parent().siblings().removeClass('active').find('.my-policy-content').slideUp();
        $(this).next('.my-policy-content').slideToggle().parent().toggleClass('active');
    });
}

if ($(window).width() > 992) {

    $('#accordion .panel-heading a').on('click', function(e) {
        console.log("clikced");
        e.preventDefault();
        return false;
    });
}

var actContent = $('#actionpolicy').clone();

$('.action-btn').click(function(e) {
    e.preventDefault();
    //alert(actContent.html());
    $('#actionpolicy').html("");
    $('#action-policy .modal-body').html(actContent.html());
    $('#action-policy').modal('show');
});
if ($(window).width() > 767) {
    $('#surrender').click(function(e) {
        e.preventDefault();
        //alert(actContent.html());
        $('#surrender-policy').modal('show');
    });
}
if ($(window).width() < 767) {
    $('.modal-body').on('click', '#surrender', function(e) {
        e.preventDefault();
        //console.log('clicked');
        $('#action-policy').modal('hide');
        $('#surrender-policy').modal('show');
    })
}

$('#sp').click(function(e) {
    e.preventDefault();
    $('#authenticate').modal('show');

});

$('#authenticate').on('hide.bs.modal', function() {

    $('#sp-btn').parent().show();
    $('#popup-sp').hide();
    // body...
});

$('#sp-btn').click(function(e) {
    e.preventDefault();
    $('#sp-btn').parent().hide();
    $('.popup-sp').show();
    $('#authenticate .modal-dialog').css('margin-top', '100px');

});

if ($(window).width() < 767) {
    $('#sp-btn').click(function(e) {
        $('#authenticate .modal-dialog').css('margin-top', '30px');
    });

}

//$('#popup-sp').hide();

$('#resend').click(function(e) {
    $(this).parent('p').text("Confirmation code has been resent to your registered email address and mobile number");


});




$(function() {
    $(".sp-ul > li > .tasks-redio-item").click(function() {
        $(this).parent().siblings().find('.sp-li-box').slideUp();
        $(this).next('.sp-li-box').slideDown();
    });
    if ($('.tasks-redio-cb').is(':checked') == true) {
        $('.tasks-redio-cb:checked').parent().next('.sp-li-box').show();
    }

    $('.sp-li-box textarea').focus(function() {

        $(this).val('');
    });

});




$('.goBtn').click(function() {
    $(this).parents('section').hide();
    $(this).parents('section').next().show();
});

$(".exampleInputPassword1").keypress(function(e) {
    //if the letter is not digit then display error and don't type anything
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
        $(".hint--right:after").html("Digits Only").show().fadeOut("slow");
        return false;
    }
});
if ($(window).width() < 992) {
    /*footer links in mobile*/
    //$("div").removeClass("in");
};
$("#submit-btn").click(function() {
    if ($('.iaccept .tasks-list-cb:checked').hasClass('active') == false) {
        $(".iaccept .tasks-list-item span").each(function() {
            $(".iaccept .tasks-list-item span").removeClass("tasks-list-mark errorchbox").addClass("tasks-list-mark errorchbox invalid");
        });
    }
});
$(".iaccept .checknone").click(function() {
    $(".iaccept .tasks-list-item span").removeClass("tasks-list-mark errorchbox invalid").addClass("tasks-list-mark errorchbox");
});
$(".submitbutton").click(function() {
    $(".form-row input, select").each(function() {
        var value = $(this).val()
        if (value == "" || value.length < 4) {
            $(this).addClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "visible");
            if ($(".boxheid").is(":visible") === false) {
                $(".boxheid input, select").removeClass("invalid1");
                $(".boxheid input,.boxheid select").siblings(".err-msg").css("visibility", "hidden");
            }
        } else {
            $(this).removeClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "hidden");
        };
    });
});
/*fund allocation ends here*/
/*product listing starts here*/
$(window).load(function() {
    $('.card').each(function() {
        $(this).hover(function() {
            $(this).toggleClass('applyflip');
        }.bind(this));
    })
});
/*product listing ends here*/

if ($(window).width() < 767) {
    if ($('#invst-brkup').text() != "") {

        $(".item").find(".no-mobile").remove();

        $('#invst-brkup').owlCarousel({
            singleItem: true,
            // Navigation
            navigation: true,
            navigationText: ["<span class='glyphicon glyphicon-chevron-left' aria-hidden='true'></span>", "<span class='glyphicon glyphicon-chevron-right' aria-hidden='true'></span>"],
            rewindNav: false,
            scrollPerPage: false,
            pagination: false
        });

        /*$("#pay-table-one").data('owlCarousel').removeItem(4);*/
    };
}
/*7d-benefit calculation starts here*/

$(".editButton").click(function() {
    $(this).siblings(".saveButton").show();
    $(this).hide();
    $(this).parentsUntil(".box5").find(".ipBox5 input").prop("disabled", false);
    $(".applyATS").removeClass("hidden");
});
$(".remove").click(function() {
    $(".editButton").show();
    $(".saveButton").hide();
    //$(this).hide();
    $(this).parentsUntil(".box5").find(".ipBox5 input").prop("disabled", true);
    $(".applyATS").addClass("hidden");
});
////////// Calculate Bouuton Click Button Jquery Start //////////////
$("#paynowbutton").click(function() {
    $(".calculatetext").show();
});
$(document).ready(function() {
    $('input[type="checkbox"]').click(function() {
        if ($(this).attr("value") == "green") {
            $(".green").toggle();
        }
    });
    /*    if ($('.taxmdal').text() != '') {
        $('.taxmdal .modal-body').jScrollPane({
            autoReinitialise: true
        });
    }*/

});
////////// Calculate Bouuton Click Button Jquery End //////////////
///////////////// Frequency of Premium Payment Select List /////////////
$(document).ready(function() {
    $("#maturity-period").change(function() {
        $(this).find("option:selected").each(function() {

            //   alert('selected value ='+$(this).attr("value"));
            switch ($(this).attr("value")) {
                case 'regularpay':
                    //   alert("regularpay");
                    break;
                case 'fivepay':
                    //    alert("fivepay");
                    break;
                case 'onlyone':
                    //   alert("onepay");
                    $('#freq').text('Once');
                    $('#maturity-period-yrs option:contains("10")').prop('selected', true);
                    $('#term').text($('#maturity-period-yrs').find('option:selected').text());
                    break;
            }

            /*if ($(this).attr("value") == "") {
              $('.onlyonediv label').removeAttr('disabled');
              $(".onlyonediv label").fadeTo(100, 1);
              $(".frequency").fadeTo(100, 1);
              $(".onlyonediv label input").removeAttr('disabled');
            }
            if ($(this).attr("value") == "regularpay") {
              $('.onlyonediv label').removeAttr('disabled');
              $(".onlyonediv label").fadeTo(100, 1);
              $(".frequency").fadeTo(100, 1);
              $(".onlyonediv label input").removeAttr('disabled');
              $(".liferedio").hide();
              $(".life_cover_text").show()
            }
            if ($(this).attr("value") == "fivepay") {
              $('.onlyonediv label').removeAttr('disabled');
              $(".onlyonediv label").fadeTo(100, 1);
              $(".frequency").fadeTo(100, 1);
              $(".onlyonediv label input").removeAttr('disabled');
              $(".liferedio").hide();
              $(".life_cover_text").show();
            }*/
            if ($(this).attr("value") == "onlyone") {
                /*$('.onlyonediv label').removeClass('active').attr('disabled', 'disabled');
                $(".onlyonediv label").fadeTo(100, 0.2);
                $(".onlyonediv label input").attr('disabled', 'disabled');
        
                $(".frequency").fadeTo(100, 0.2);
                $(".life_cover_text").hide();
                $(".liferedio").show();*/
                $(".life_cover_text").hide();
                $(".liferedio").show();
                $('#term-period').prop('disabled', true);
            } else {
                $('#term-period').prop('disabled', false);
                $(".life_cover_text").show();
                $(".liferedio").hide();
            }
        });
    }).change();
    $('#term-period').change(function() {
        //alert($(this).find('option:selected').val());
        $('#freq').text($(this).find('option:selected').text());
        if ($(this).find('option:selected').val() == 'monthly') {
            $('.youpaytab').show();
        } else {
            $('.youpaytab').hide();
        }
    });

    $('#maturity-period-yrs').change(function() {
        //   alert('maturity changed');
        $('#term').text($(this).find('option:selected').text());

    });


    $("#sv5").unbind("click");
});
$(window).load(function() {
    $('.card').each(function() {
        $(this).hover(function() {
            $(this).addClass('applyflip');
        }.bind(this), function() {
            $(this).removeClass('applyflip');
        });
    })
});
/*7d-benefit calculation starts here*/
/*basic details screen 9 starts here*/
$(document).ready(function() {
    $('.policy-show').click(function() {
        var polsh = $(this).is(":checked");
        if (polsh) {
            $(".extra-policy").show();
        } else {
            $(".extra-policy").hide();
        }
    });
    /* click to call js*/
    /*if ($('#call').text() != "") {
        $('body').on('mousedown', '#call', function(e) {
            $(this).addClass('draggable').parents().on('mousemove', function(e) {
                $('.draggable').offset({
                    top: e.pageY - $('.draggable').outerHeight(true) / 2,
                    left: e.pageX - $('.draggable').outerWidth(true) / 2
                }).on('mouseup', function() {
                    $(this).removeClass('draggable');
                });
            });
            e.preventDefault();
        }).on('mouseup', function() {
            $('.draggable').removeClass('draggable');
            var offsetfromtop = $('#call').position().top;
            console.log(offsetfromtop);
            if (offsetfromtop < 0) {
                $('#call').css({ 'top': 100 });
            }

        });
    }*/
    $('#call-submit').click(function(event) {
        //alert('submit clicked');
        event.preventDefault();
        callSubmit($(this));
    });

    $('.call-acknowledge .close').click(function() {
        $('.callback').fadeOut(500);
    });
    if ($(window).width() > 767) {
        $('.clicktocall').not('.draggable').click(function(event) {
            event.preventDefault();

            $(this).parent().next('.call-info').slideToggle(500);
        });
    }
    if ($(window).width() < 767) {
        var flag;
        var c2ccontent = $('.call-info').clone();
        var c2cacknowledge = $('.call-acknowledge').clone();
        $('.call-info, .call-acknowledge').remove();
        $('#c2cmobile .modal-body').html(c2ccontent);
        $('.clicktocall').click(function(event) {
            event.preventDefault();
            $('#c2cmobile').modal('show');
        });
        $('#call-submit').click(function(event) {
            flag = false;
            // alert('submit clicked');
            event.preventDefault();
            flag = callSubmit($(this));
            if (flag == true) {
                $('#c2cmobile .modal-body').append(c2cacknowledge);
            }
        });

    }


});
/*basic details screen 9 ends here*/
/*application tracker js starts here*/
$(function() {
    var frstitem = $('.track-list li:first-child a').text();

    /*if ($(window).width() < 767) {
        setTimeout(function () {
            $('.track-list a').trigger('click');
            $('.track-list li:first-child a').text(frstitem);
        }, 1);
    }*/

    $('.track-list a').click(function(e) {
        if ($(this).parent('li').hasClass('active-link') == true || $(this).parent('li').hasClass('pending-link') == true || $(this).parent('li').hasClass('rejected-link') == true) {
            // alert("can be clicked");
            // alert($(this).text());
            var idxoff = $(this).parent().index();
            if ($(window).width() < 767) {
                $('.track-list li:first-child a').text($(this).text());
            }
            var ofleft = $(this).parent('li').width();
            var listoff = $(this).parents('.track-list').siblings('.tracker-content').children('.status-popup:eq(' + idxoff + ')').position();
            //  alert("index ="+idxoff);


            //  alert("list width ="+ofleft);
            //  alert("staus div offset ="+listoff.left);

            $(this).parents('.track-list').siblings('.tracker-content').children('.status-popup').fadeOut(100).removeClass('active');
            $(this).parents('.track-list').siblings('.tracker-content').children('.status-popup:eq(' + idxoff + ')').fadeIn(500).addClass('active');
        } else {
            //  alert("cannot be clicked");
            return false;
        }
    });

    $('.track-list li:first-child a').click(function() {
        $(this).text(frstitem);
    });

    if ($('.footable').text() != '') {
        $('.footable').footable();
    }
    var count = 0;
    $('.document-table>tbody .file-name').each(function() {
        $(this).bind('DOMSubtreeModified', function() {
            if ($(this).text() != '') {
                count++;
            }
            // alert(count);
            if (count > 0) {
                $('.document-table').prev('.clearfix').find('.uploadbtn').removeClass('disabled');
            }
        });
    });
    var d1 = new Date();
    var datechoosen;
    $('#dayfield').val(d1.getDate()).addClass('active');
    datechoosen = $('#dayfield').val();
    $('#dayfield').on('change', function() {
        var datefield = $(this).val();
        if (datefield > 31) {
            $(this).val('');
        } else {
            datechoosen = datefield;
        }
    });
    var mnthchosen,
        yrchosen;
    yrchosen = $('#yrfield').val();
    mnthchosen = $("#mnthfield").val();
    $('#mnthfield').on('change', function() {
        mnthchosen = $(this).val();
    });
    $('#yrfield').on('change', function() {
        var yearfield = $(this).val();
        if (yearfield > d1.getFullYear() || yearfield < d1.getFullYear()) {
            $(this).val(yrchosen);
        } else {
            yrchosen = yearfield;
        }
    });

    var months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

    $('#fixappntmnt').click(function(event) {
        event.preventDefault();
        var dateentered = datechoosen + " " + mnthchosen + " " + yrchosen;
        var dateformatted = moment(dateentered, "DD MMM YYYY");
        // alert(dateformatted);
        var appntdate = new Date(dateformatted);
        console.log(appntdate.toLocaleDateString());
        appntdate = appntdate.toLocaleDateString();
        var conversiondate = new Date(appntdate);
        var minDate = new Date(d1.getFullYear(), d1.getMonth(), d1.getDate());
        var maxDate = new Date(d1.getFullYear(), d1.getMonth() + 3, d1.getDate() - 1);
        var fixeddate = conversiondate.getDate() + " " + months[conversiondate.getMonth()] + " " + conversiondate.getFullYear();
        if (conversiondate < minDate || conversiondate > maxDate) {
            alert("wrong date entered");
        } else {
            alert("Your appointment is fixed for " + fixeddate);
        }
        //alert(dateformatted.isValid());
        console.log(conversiondate.getDate() + " " + months[conversiondate.getMonth()] + " " + conversiondate.getFullYear());
    });
});
/*application tracker js ends here*/
/*health and habits starts here*/
$(document).ready(function() {
    $('.tobacco-show').click(function() {
        var polsh = $(this).is(":checked");
        if (polsh) {
            $(".tobacco-extra").show();
        } else {
            $(".tobacco-extra").hide();
        }
    });
    $('.remark-show').click(function() {
        var l = $('.extra-qust .ans').find('input:checked').length;
        if (l > 0) {
            $(".remark-extra").show();
        } else {
            $(".remark-extra").hide();
        }
    });
    $('.alchohol-show').click(function() {
        var polsh = $(this).is(":checked");
        if (polsh) {
            $(".alchohol-extra").show();
        } else {
            $(".alchohol-extra").hide();
        }
    });
    if ($('#heightft').length != 0) {
        $.fn.select2.amd.require(['select2/compat/matcher'], function(oldMatcher) {
            $("#heightft").select2({
                maximumInputLength: 1,
                matcher: oldMatcher(matchStart)
            })
        });
        $("input.select2-search__field").on("keypress", function(event) {
            var len = $(this).val().length();
            if (len > 0) {
                event.preventDefault();
            };
        });
    }
    $("#weightkg").on("change", function() {
        var wt = $(this).val();
        if (wt > 800) {
            $(this).val("800");
        };
        if (wt < 25) {
            $(this).val("25");
        };
    });
    $("#heightft").on("change", function() {
        var v = $(this).val();
        var converted = feetconvert(v);
        $("#heightcm").val(converted).focus();
    });
    $(".submit-habits").click(function() {
        var selv = $("#select2-heightft-container").text();
        if (selv == "" || selv.length == 0) {
            $("#select2-heightft-container").parent(".select2-selection").addClass("invalid1");
            $("#select2-heightft-container").parents(".select2").siblings(".err-msg").css("visibility", "visible");
        } else {
            $("#select2-heightft-container").parent(".select2-selection").removeClass("invalid1");
            $("#select2-heightft-container").parents(".select2").siblings(".err-msg").css("visibility", "hidden");
        };
        $(".form-row input").each(function() {
            var value = $(this).val()
            if (value == "" || value.length == 0) {
                $(this).addClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "visible");
                if ($(".tobacco-extra-entry").is(":visible") === false) {
                    $(".tobacco-extra-entry input,.tobacco-extra-entry select").removeClass("invalid1");
                    $(".tobacco-extra-entry input,.tobacco-extra-entry select").siblings(".err-msg").css("visibility", "hidden");
                }
                if ($(".alchohol-extra-entry").is(":visible") === false) {
                    $(".alchohol-extra-entry input,.alchohol-extra-entry select").removeClass("invalid1");
                    $(".alchohol-extra-entry input,.alchohol-extra-entry select").siblings(".err-msg").css("visibility", "hidden");
                }
                if ($(".remark-extra-entry").is(":visible") === false) {
                    $(".remark-extra-entry input").removeClass("invalid1");
                    $(".remark-extra-entry input").siblings(".err-msg").css("visibility", "hidden");
                }
            } else {
                $(this).removeClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "hidden");
            };
        });
        $("select").each(function() {
            var selval = $(this).find(":selected").val();
            if (selval == "") {
                $(this).next(".selectboxit-container").find('.selectboxit').addClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "visible");
                if ($(".tobacco-extra-entry").is(":visible") === false) {
                    $(".tobacco-extra-entry select").next(".selectboxit-container").find('.selectboxit').removeClass("invalid1");
                    $(".tobacco-extra-entry select").siblings(".err-msg").css("visibility", "hidden");
                }
                if ($(".alchohol-extra-entry").is(":visible") === false) {
                    $(".alchohol-extra-entry select").next(".selectboxit-container").find('.selectboxit').removeClass("invalid1");
                    $(".alchohol-extra-entry select").siblings(".err-msg").css("visibility", "hidden");
                }
            };
        });
    });
});

function matchStart(term, text) {
    if (text.toUpperCase().indexOf(term.toUpperCase()) == 0) {
        return true;
    }
    return false;
}

function roundit(which) {
    return (Math.round(which * 100) / 100).toFixed(0);
}

function feetconvert(value) {
    value = roundit(value * 2.54);
    return value;
}
/*health and habits ends here*/
/*nominee detaiuls starts here*/
$(document).ready(function() {
    $('.nominee-show').click(function() {
        var polsh = $(this).is(":checked");
        if (polsh) {
            $(".nominee-extra").hide();
            $(".mwpa-extra").show();
        } else {
            $(".nominee-extra").show();
            $(".mwpa-extra").hide();
        }
    });
    $("#date-of-birth").on("change", function() {
        var dt = $(this).val();
        console.log("date =" + dt);
        var yr = parseInt(calcAge(dt));
        console.log("age in years" + yr);
        if (yr < 18) {
            $("#minor").show();
        } else {
            $("#minor").hide();
        }
    });
});

function calcAge(dateString) {
    var birthday = new Date(dateString);
    var ageDifMs = Date.now() - birthday.getTime();
    var ageDate = new Date(ageDifMs); // miliseconds from epoch
    return Math.abs(ageDate.getFullYear() - 1970);
}

$(".submitnom").click(function() {
    $(".form-row input, select").each(function() {
        var value = $(this).val()
        if (value == "" || value.length == 0) {
            $(this).addClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "visible");
            if ($(".mwpa-extra-entry").is(":visible") === false) {
                $(".mwpa-extra-entry input,.mwpa-extra-entry select").removeClass("invalid1");
                $(".mwpa-extra-entry input,.mwpa-extra-entry select").siblings(".err-msg").css("visibility", "hidden");
                $(".tasks-list-item span").each(function() {
                    $(".tasks-list-item span").removeClass("tasks-list-mark errorchbox invalid").addClass("tasks-list-mark errorchbox");
                });
            } else if ($('.tasks-list-cb:checked').hasClass('active') == false) {
                $(".tasks-list-item span").each(function() {
                    $(".tasks-list-item span").removeClass("tasks-list-mark errorchbox").addClass("tasks-list-mark errorchbox invalid");
                });
            }
        } else {
            $(this).removeClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "hidden");
        };
    });
});
/*nominee details ends here*/
/*aplication address form starts here*/
$(document).ready(function() {
    $('.permanent-show').click(function() {
        var polsh = $(this).is(":checked");
        if (polsh) {
            $(".permanent-extra").hide();
        } else {
            $(".permanent-extra").show();
        }
    });
});
/*application address ends here*/
/*application review starts here */
if ($('.signcontrol').children().length > 0) {
    $('#signControl').signature({
        syncField: '#signatureJSON'
    });
    $('#clear2Button').click(function() {
        $('#signControl').signature('clear');
        if ($('#signControl').children("svg").length > 0) {
            $('#signControl').find("svg").remove();
            $('#signControl').signature({
                syncField: '#signatureJSON',
                color: '#000'
            });
        };
    });
    $('.submit').click(function() {
        var svgContent = $('#signControl').signature('toSVG');
        $('#esign').val(svgContent);
        //alert("e signature" + $('#esign').val());
    });
}
/*application review ends here*/
/*application payment starts here*/
if ($('#payment-tab').text() != '') {


    /*$('.pay_1 > li > a').click(function() {
        var iden = $(this).attr('id');
        var result = iden.substring(0, iden.length - 2);
        $('#' + result).html(localStorage.getItem('shadowcontent'));
        $('#' + result).siblings().html('');
        if ($('.dob-picker').length > 0) {
            $('.dob-picker').bootstrapDP({
                format: "dd M yyyy",
                startView: 2,
                autoclose: true,
                defaultViewDate: {
                    year: 1977,
                    month: 04,
                    day: 25
                }
            });
        }

        if (result == 'net') {
            $('.pay-type,.prepaid-card,  .tmscon, .proname, .datedis, .branchname, .bankname, .micr, .ddno, .chqno, .paydate').hide();
        };
        if (result == 'deb') {
            $('.aexpress,.emi,.prepaid-card,.selectbank, .tmscon, .proname, .datedis, .branchname, .bankname, .micr, .ddno, .chqno, .paydate').hide();
            $('.pay-type,.top-margin').show();
        };
        if (result == 'cre') {
            $('.rupay,.maestro,.atm,.prepaid-card,.selectbank, .tmscon, .proname, .datedis, .branchname, .bankname, .micr, .ddno, .chqno, .paydate').hide();
            $('.pay-type').show();
        };
        if (result == 'dd') {
            $('.pay-type,.amtpay,.selectbank,.prepaid-card,.top-margin,.aexpress,.emi,.rupay,.maestro,.atm,.or, .tmscon, .proname, .datedis, .chqno,.setsi').hide();
            $('.paydate,.ddno,.branchname, .bankname,.micr,.top-margin').show();
        };
        if (result == 'cheq') {
            $('.pay-type,.selectbank,.prepaid-card,.top-margin,.aexpress,.emi,.rupay,.maestro,.atm,.or, .tmscon, .proname, .datedis, .ddno,.setsi').hide();
            $('.paydate,.branchname,.chqno.bankname,.micr,.top-margin').show();
        };
        if (result == 'cash') {
            $('.paydate,.ddno,.pay-type,.prepaid-card, .aexpress,.emi,.rupay,.maestro,.atm,.or,.selectbank, .tmscon,  .branchname, .bankname, .micr, .setsi, .chqno').hide();
            $('.top-margin,.proname, .datedis,.amtpay').show();
        };
        if (result == 'wal') {
            $('.aexpress,.emi,.rupay,.maestro,.atm,.or,.selectbank').hide();
            $('.pay-type,.prepaid-card, .top-margin').show();
        };
    });*/


    //alert("amount value = "+amnt);

}

/*servicing consolidation*/
$('.small-btn').click(function() {
    if ($(this).parents().hasClass('table-slider')) {
        $(this).next('.green-btn').css('display', 'inline-block');
        $(this).hide();
    }
});

$('.green-btn').click(function() {
    if ($(this).parents().hasClass('table-slider')) {
        $(this).prev('.small-btn').css('display', 'inline-block');
        $(this).hide();
    }
});
$('.mainchk').click(function() {
    //  alert("test");
    $('.policy-table .checkbox > label').toggleClass('active');

    if ($(this).parent('label').hasClass('active') == true) {
        $(this).parent('label').removeClass('active')
    } else {
        $(this).parent('label').addClass('active');
    };
});

/*top up */
$(document).ready(function() {

    $(".deathbenefit").hide();
    $(".premiumamount input").attr("disabled", "disabled");
    $(".premiumamount").fadeTo(100, 0.4);

    $(".owl-carousel input:radio").click(function() {
        $('html,body').animate({
                scrollTop: $(".fundallcation").offset().top - 100
            },
            'slow');

        $(".premiumamount").fadeTo(100, 1.0);
        $('.premiumamount input').removeAttr("disabled");
    });

    $("#premiumamount").keyup(function() {
        // $('body').on('keyup', '#premiumamount', function() {
        var mmfAmount = $("#premiumamount").val();
        if (mmfAmount != "") {
            $(".applyATS").removeClass("hidden");
            $(".red").removeClass("hidden");
            $(".dispnonea").hide();
            $(".paynowbutton").removeAttr("disabled");
            $(".paynowbutton").hover(function() {
                $(this).css("transform", "scale(0.9)");
            }, function() {
                $(this).css("transform", "scale(1.0)");
            });
            $(".paynowbutton").fadeTo(100, 1.0);
            $(this).addClass('active');
            $(".deathbenefit").show();
        } else {
            $(".applyATS").addClass("hidden");
            $(".red").addClass("hidden");
            $(".dispnonea").hide();
            $(".paynowbutton").attr("disabled", "disabled");
            $(".paynowbutton").fadeTo(100, 0.4);
            $(this).parentsUntil(".box5").find(".ipBox5 input").prop("disabled", true);
            $(".topup-table-content-two ul li:last-child").hide();
            $(".deathbenefit").hide();
            $(this).removeClass('active');
        }
    });

    $('.deleteRowButton').click(DeleteRow);

    $("#ed8").click(function() {
        $(this).siblings(".saveButton").show();
        $(this).hide();
    });
    $("#sv8").click(function() {
        $(this).siblings(".editButton").show();
        $(this).hide();
    });

    $("#ed5").click(function() {

        $(".dispnonea").show();
        $(".topup-table-content-two ul li:last-child").show();
        $(this).siblings(".saveButton").show();
        $(this).hide();
        $(this).parentsUntil(".box5").find(".ipBox5 input").prop("disabled", false);
    });


    $("#sv6").click(function() {
        $(".dispnonea").hide();
        $(".topup-table-content-two ul li:last-child").hide();
        $(this).siblings(".editButton").show();
        $(this).hide();
        $(this).parentsUntil(".box5").find(".ipBox5 input").prop("disabled", true);
    });

});
/*$('#premiumamount').on('click focus',function(){
alert('focused or clicked');
});*/

/*application payment ends here*/

/*servicing inbox js*/



/*documents upload js*/
$(".noticon").hide();
$(".righticon").hide();
$(".otherinput").hide();
$(document).ready(function() {
    $(".incometax select").change(function() {
        $(this).find("option:selected").each(function() {
            if ($(this).attr("value") == "") {
                $(".pannumber, .panupload").hide();
            }
            if ($(this).attr("value") == "pan") {
                $(".pannumber").show();
                $(".panupload").hide();
            }
            if ($(this).attr("value") == "panacknowledgement") {
                $(".panupload").show();
                $(".pannumber").hide();
            }
            if ($(this).attr("value") == "form") {
                $(".panupload").show();
                $(".pannumber").hide();
            }
        });
    }).change();
    $(".other").click(function() {
        $(".otherinput").show();
    });
    $(".otherinputnone").click(function() {
        $(".otherinput").hide();
    });
    $('input[type="checkbox"]').on('click', function() {
        $(this).parent('label').toggleClass('active');
    });
});
/*documents upload js ends here*/
/*medicall test screen 17 starts here*/
$(document).ready(function() {
    if ($('#datetimepicker3').length > 0) {
        $('#datetimepicker3').datetimepicker({
            format: 'LT'
        });
    }
    //Sumbit Button Jquery//
    $(".submitapt").click(function() {
        $(".form-row input, select").each(function() {
            var value = $(this).val()
            if (value == "" || value.length == 0) {
                $(this).addClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "visible");
            } else {
                $(".apptset, .upldoc").show();
                $(".setappt").hide();
                $(".close").show();
            }
        });
    });
});
$(document).ready(function() {
    var d1 = new Date();
    if ($('#clockbox').length > 0) {
        if ($(window).width() > 1025) {
            $('#clockbox').datetimeEntry({
                minDatetime: new Date(d1.getFullYear(), d1.getMonth(), d1.getDate(), d1.getHours() + 3, 00),
                datetimeFormat: 'W, n Y  H:M a',
                timeSteps: [1, 15, 1]
            });
            $('#clockbox').datetimeEntry('setDatetime', new Date(new Date().setTime(new Date().getTime() + (2 * 60 * 60 * 1000))))
        }
        if ($(window).width() < 1025) {
            $("#clockbox").datepick({
                dateFormat: 'dd-M-yyyy',
                showOnFocus: true,
                beforeShow: function() {
                    $('#clockbox').blur();
                }
            });
        }
    }
});
$(document).ready(function() {
    $("#onload").modal('show');
    $(".modal").unbind("click");
});
$(".close").click(function() {
    $("#onload").hide();
    $(".modal-backdrop").hide();
});
/*medicall test screen 17 ends here*/

/*print button js*/
$(function() {

    $('.printbtn').click(function() {
        //printDiv(printid);
        window.print();
    });

});

/*need analysis js starts here*/
$(function() {
    if ($(window).width() < 768) {

        $('.need-steps .steps img').attr('src', 'images/needmobile1.png');
        $('.need-steps .steps h3 br').remove();
        $('.retirement-calc .padleft,.retirement-calc .padright').addClass('paddnone');
        $('.life-stage .radio input:radio').click(function(e) {
            // alert('label clickd');
            var scrollbtn = $(this).parents('.life-stage').next();
            $('html,body').animate({
                scrollTop: scrollbtn.offset().top - 30
            }, 800);
        });

    }
    //var needcaptured;

    //needcaptured = $('.life-stage > li.active > a').attr('data-value');

    /*$('.life-stage > li > a').click(function(e){
    e.preventDefault();
    needcaptured = $(this).attr('data-value');
    console.log(needcaptured);
    $(this).parent().siblings().removeClass('active');
    $(this).parent().addClass('active');
    });*/
    $('.need-tracking .track-list > li > a').off('click');
    $('.need-tracking .track-list > li > a').on('click', function() {
        return false;
    });
    $('.needsubmit').click(function(e) {
        e.preventDefault();

        $('html, body').animate({
            scrollTop: 0
        }, 800);

        var lifestage = $('input[name="lifestage"]:checked').val();
        var lifeneed = $('input[name="lifeneed"]:checked').val();
        var riskprofile = $('input[name="riskprofile"]:checked').val();

        if ($(this).attr('id') == "proceedtocalc") {

            showCalc(lifestage, lifeneed, riskprofile);
        }

        $(this).parents('.tracker-content').prev('.track-list').find('li.active-link').addClass('completed').next().addClass('active-link');
        $(this).parents('.status-popup').removeClass('active');
        $(this).parents('.status-popup').next().addClass('active');


        $('.track-list li:first-child').find('.selectedoptn').text(lifestage);
        $('.track-list li:nth-child(2)').find('.selectedoptn').text(lifeneed);
        $('.track-list li:nth-child(3)').find('.selectedoptn').text(riskprofile);



    });

    if ($(".numberbox").length != '') {
        setSpinner($('#protectionage'), 20, 18, 55, 1, 'Years');
        setCustomNumericSpinner($('#protectionincome'), 100000, 100000, 1500000000);
        setCustomNumericSpinner($('#protectionloan'), 100000, 100000, 1500000000);
        /*marriage calculator*/
        setCustomNumericSpinner($('#marriageinvst'), 300000, 100000, 1500000000);
        setSpinner($('#marriageterm'), 5, 1, 30, 1, 'Years');
        setSpinner($('#rormarriage'), 8, 4, 20, 1, '%');
        /*child education calculator*/
        setCustomNumericSpinner($('#educost'), 100000, 100000, 1500000000);
        setCustomNumericSpinner($('#edusavings'), 100000, 100000, 1500000000);
        setSpinner($('#edutime'), 5, 1, 30, 1, 'Years');
        setSpinner($('#eduroi'), 8, 4, 20, 1, '%');
        setSpinner($('#eduinflation'), 8, 4, 20, 1, '%');
        setSpinner($('#eduterm'), 5, 2, 30, 1, 'Years');
        /*wealth calculator*/
        setCustomNumericSpinner($('#holidaycost'), 100000, 100000, 1500000000);
        setCustomNumericSpinner($('#holidaysavings'), 100000, 100000, 1500000000);
        setSpinner($('#holidayterm'), 5, 2, 30, 1, 'Years');
        setSpinner($('#expectroi'), 8, 4, 20, 1, '%');
        setSpinner($('#roi'), 8, 4, 20, 1, '%');
        setSpinner($('#investterm'), 8, 4, 20, 1, 'Years');
        /*retirement calculator*/
        setCustomNumericSpinner($('#mnthlyxpense'), 100000, 100000, 1500000000);
        setCustomNumericSpinner($('#retiresaving'), 100000, 100000, 1500000000);
        setSpinner($('#retireage'), 40, 30, 65, 1, 'Years');
        setSpinner($('#curentage'), 20, 18, 55, 1, 'Years');
        setSpinner($('#retirexpectedroi'), 8, 4, 20, 1, '%');
        setSpinner($('#retireinvstterm'), 8, 4, 20, 1, 'Years');
        setSpinner($('#retireroi'), 8, 4, 20, 1, '%');

        /*INPUT FOCUS jquery*/
        $('.dp-numberPicker-input').focus(function() {
            // alert($(this).val());
            var activeval = $(this).val();
            console.log(activeval);
            console.log($(this).parent().attr('data-value'));
            $(this).val($(this).parent().attr('data-value'));
            // console.log(activeval);

        });

    }

    $('.calcbtn').click(function(e) {
        e.preventDefault();
        $(this).parents('.calc').removeClass('active').fadeOut(100);
        $(this).parents('.calc').next('.rslt').delay(800).fadeIn(500).addClass('active');
    });
});

/*need analysis js ends here*/

/*my dashboard */

if ($('.alerts').text() != '') {

    if ($(window).width() > 768) {
        $('.alerts').jScrollPane({ autoReinitialise: true });
    }

}
if ($('.invest-view .policy-table').text() != '') {

    if ($(window).width() > 768) {
        $('.invest-view .policy-table .table-slider').jScrollPane({
            autoReinitialise: true
        });
    }

}

if ($('#advisor-slider').length > 0) {

    $('#advisor-slider').owlCarousel({
        singleItem: true,
        // Navigation
        navigation: true,
        navigationText: ["", ""],
        rewindNav: true,
        scrollPerPage: false,
        pagination: false,
        autoPlay: 5000
    });
}
if ($(window).width() < 755) {
    if ($('#pay-table-one').length > 0) {

        $(".item").find(".sub-title").parent().remove();

        $('#pay-table-one').owlCarousel({
            singleItem: true,
            // Navigation
            navigation: true,
            navigationText: ["<span class='glyphicon glyphicon-chevron-left' aria-hidden='true'></span>", "<span class='glyphicon glyphicon-chevron-right' aria-hidden='true'></span>"],
            rewindNav: false,
            scrollPerPage: false,
            pagination: false
        });
    };
}
/*my dashboard ends here*/

/*agent dashboard */

if ($('.applicationlist').length > 0) {
    /* $("#agentdshboardtab").easyResponsiveTabs({
         type: 'default', //Types: default, vertical, accordion           
         width: 'auto', //auto or any custom width
         fit: true, // 100% fits in a container
         closed: false, // Close the panels on start, the options 'accordion' and 'tabs' keep them closed in there respective view types
         active_border_color: '#f58220', // border color for active tabs heads in this group
         active_content_border_color: 'transparent' // border color for active tabs contect in this group so that it matches the tab head border
     });*/
    if ($(window).width() > 767) {
        $('.applicationlist .resp-tabs-list > li').click(function(e) {
            e.preventDefault();
            $(this).siblings().removeClass('resp-tab-active');
            $(this).addClass('resp-tab-active');
            // alert($(this).index());
            var tabindexdashbrd = $(this).index();
            //  alert(tabindexdashbrd);
            $(this).parent().next('.resp-tabs-container').find('.resp-tab-content').removeClass('resp-tab-content-active');
            $(this).parent().next('.resp-tabs-container').find('.resp-tab-content').eq(tabindexdashbrd).addClass('resp-tab-content-active');
        });
    }
    if ($(window).width() < 768) {
        $('ul.resp-tabs-list').each(function() {
            var $select = $('<select class="tablist dropdown1"/>');

            $(this).find('li').each(function() {
                var $option = $('<option />');
                if ($(this).hasClass('resp-tab-active') == true) {
                    $option.attr('selected', 'true');
                }
                $option.attr('value', $(this).children().html()).html($(this).children().html());
                $option.attr('data-select', $(this).attr('data-select'));
                $select.append($option);
            });
            $(this).replaceWith($select);
            $('ul.resp-tabs-list').wrap("<div class='select-drpdwn1'></div>");
        });
        $('.tablist').change(function() {
            var a = $(".tablist option:selected").val();
            var idselected = $(".tablist option:selected").attr('data-select');
            $('#' + idselected).addClass('resp-tab-content-active').siblings().removeClass('resp-tab-content-active');
        });
    }

}

/*agent dashboard ends here*/

//Sumbit Button Jquery//
$(".submit").click(function() {
    $(".form-row input, select, textarea,.inpt-txt input").not(".not-mand").each(function() {
        var value = $(this).val();

        if (value == "" || value.length == 0) {
            $(this).addClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "visible");
        } else {
            $(this).removeClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "hidden");
        }


        if ($(this).hasClass('mobile-no')) {
            mobilevalidate = validateMobile(value);
            if (mobilevalidate == false) {
                $(this).addClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "visible");
            } else {
                $(this).removeClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "hidden");
                //return true;
            }
        }

        if ($(".extra-policy-entry").is(":visible") === false) {
            $(".extra-policy-entry input,.extra-policy-entry select").removeClass("invalid1");
            $(".extra-policy-entry input,.extra-policy-entry select").siblings(".err-msg").css("visibility", "hidden");
        }
        if ($(".permanent-extra").is(":visible") === false) {
            $(".permanent-extra input,.permanent-extra select").removeClass("invalid1");
            $(".permanent-extra input,.permanent-extra select").siblings(".err-msg").css("visibility", "hidden");
        }
        if ($('.tasks-list-item').not(".not-mand").hasClass('active') == false) {
            $(".tasks-list-item").not(".not-mand").each(function() {
                $(this).children('span').addClass("invalid");
            });
        }
        $(".inputfile").not('.not-mand').each(function() {
            if ($(this).siblings('.file-name').text() == '') {
                $(this).siblings('.err-msg1').show();
                $(this).addClass('invalid').removeClass('valid');
            } else {
                $(this).siblings('.err-msg1').hide();
                $(this).addClass('valid').removeClass('invalid');
            }
        });
        $('.supo-name').each(function() {
            var chkactive = $(this).find('.tasks-list-item');
            var filetxt = $(this).parent().next('.upload-task').find('.inputfile');
            if (chkactive.hasClass('active')) {
                //alert("chkbox has active");
                if (filetxt.siblings('.file-name').text() == '') {
                    filetxt.siblings('.err-msg1').show();
                    filetxt.addClass('invalid').removeClass('valid');
                } else {
                    filetxt.siblings('.err-msg1').hide();
                    filetxt.addClass('valid').removeClass('invalid');
                }
            } else {
                filetxt.siblings('.err-msg1').hide();
                filetxt.addClass('valid').removeClass('invalid');
            };

        });
        if ($(window).width() < 760) {
            $(".inputfile").not('.not-mand').each(function() {
                //alert("in 760");
                if ($(this).siblings('.file-name').text() == '') {
                    $(this).siblings('.err-msg1').hide();
                    $(this).addClass('invalid').removeClass('valid');
                } else {
                    $(this).siblings('.err-msg1').hide();
                    $(this).addClass('valid').removeClass('invalid');
                }
            });
        };
    });
});
////////Number Jquery Start////////
$('.number,.numbers').keypress(function(event) {
    var keycode = event.which;
    if (!(event.shiftKey == false && (keycode == 46 || keycode == 8 || keycode == 37 || keycode == 39 || (keycode >= 48 && keycode <= 57)))) {
        event.preventDefault();
    }
});
////////Number Jquery End////////
////////Amount Number Jquery Start////////
$('.amountnumber').on('keyup', function(event) {
    // skip for arrow keys
    if (event.which >= 37 && event.which <= 40) return;
    // format number
    $(this).val(function(index, value) {
        return value
            .replace(/\D/g, "")
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    });
});
$('.amountnumber').keypress(validateNumber);

function validateNumber(event) {
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46 || event.keyCode === 37 || event.keyCode === 39) {
        return true;
    } else if (key < 48 || key > 57) {
        return false;
    } else return true;
};
//////Amount Number Jquery End/////
/////Only Text Input start/////
$('.inpt-txt input,.form-row input').each(function() {
    // This will be triggered everytime a user types anything
    // in the input field with id as input-field
    $('.inpt-txt input.txtinput,.form-row input.txtinput').on('keyup', function(e) {
        // Our regex
        // a-z => allow all lowercase alphabets
        // A-Z => allow all uppercase alphabets
        // 0-9 => allow all numbers
        // @ => allow @ symbol
        var regex = /^[a-zA-Z ]+$/;
        // This is will test the value against the regex
        // Will return True if regex satisfied
        if (regex.test(this.value) !== true)
        // You can replace the invalid characters by:
            this.value = this.value.replace(/[^a-zA-Z ]+/, '');
        console.log(this.value);
    });
});
/////Only Text Input end/////
//Input Form, Date and Selecter Jquery//
$(function() {
    $(document).on({
        blur: function() {
            var $this = $(this);
            if ($this.data('type') == 'currency') {
                $this[$this.val() == '₹' || $this.val() == '' ? 'removeClass' : 'addClass']('on');
            } else if ($this.data('type') == 'percentage') {
                $this.val(String($this.val()).replace(/[^0-9\.-]+/g, '') + '%');
                $this[$this.val() == '%' || $this.val() == '' ? 'removeClass' : 'addClass']('on');
            } else {
                $this[$this.val() == '' ? 'removeClass' : 'addClass']('on');
            }
        },
        focus: function() {
            var $this = $(this);
            if ($this.data('type') == 'currency' && !$this.val()) $this.val('₹');
            if ($this.data('type') == 'percentage') {
                if (!$this.val() || $this.val() == '%') {
                    $this.val('%');
                    setTimeout(function() {
                        $this.get(0).setSelectionRange(0, 0);
                    }, 100);
                } else {
                    setTimeout(function() {
                        $this.get(0).setSelectionRange(0, $this.val().length - 1);
                    }, 100);
                }
            }
        },
        change: function(e) {
            var $this = $(this);
            if ($this.data('type') == 'currency') {
                $this[$this.val() == '₹' || $this.val() == '' ? 'removeClass' : 'addClass']('on');
            } else {
                $this[$this.val() == '' ? 'removeClass' : 'addClass']('on');
            }
        }
    }, '.magic-placeholder');
    $(document).on('click', 'label', function() {
        var $styledSelect = $(this).prev('.selectboxit-container');
        if ($styledSelect.length) {
            $styledSelect.children('span').trigger('click');
        }
    });
    if ($('.dob-picker').parent('.form-row').text() != '') {
        var datepicker = $.fn.datepicker.noConflict();
        $.fn.bootstrapDP = datepicker;
        $('.dob-picker').bootstrapDP({
            format: "dd M yyyy",
            startView: 2,
            autoclose: true,
            defaultViewDate: {
                year: 1977,
                month: 04,
                day: 25
            }
        }).on('show', function(event) {
            $(this).addClass('datepicker-open');
            event.preventDefault();
        }).on('hide', function(e) {
            var $this = $(this);
            $this.removeClass('datepicker-open');
            var dateArr = $this.val().split('/');
            $('.dob-day').val(dateArr[0]);
            $('.dob-month').val(dateArr[1]);
            $('.dob-year').val(dateArr[2]);
        });
    }

    /*label click for select boxes*/
    $("label").mouseover(function() {
        var $this = $(this);
        var $input = $('#' + $(this).attr('for'));
        if ($input.is("select") && !$('.lfClon').length) {
            var $clon = $input.clone("true");
            var getRules = function($ele) {
                return {
                    position: 'absolute',
                    left: $ele.offset().left,
                    top: $ele.offset().top,
                    width: $ele.outerWidth(),
                    height: $ele.outerHeight(),
                    opacity: 0,
                    margin: 0,
                    padding: 0
                };
            };
            var rules = getRules($this);
            $clon.css(rules);
            $clon.on("mousedown.lf", function() {
                $clon.css({
                    marginLeft: $input.offset().left - rules.left,
                    marginTop: $input.offset().top - rules.top,
                });
                $clon.on('change blur', function() {
                    $input.val($clon.val()).show();
                    $clon.remove();
                });
                $clon.off('.lf');
            });
            $clon.on("mouseout.lf", function() {
                $(this).remove();
            });
            $clon.prop({ id: '', className: 'lfClon' });
            $clon.appendTo('body');
        }
    });

});
/*$('select').change(function() {
   // alert($(this).find("option:selected").val());    
});*/
/////////Instant Gratification ////////
////Email Id Validate Start /////
function ValidateEmail(email) {
    var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    return expr.test(email);
};
$('.input-email').on('change', function() {
    if (ValidateEmail($(this).val()) == true) {
        $('.input-email').removeClass('invalid1');
        $(this).siblings(".err-msg").css("visibility", "hidden");
    } else {
        $('.input-email').addClass('invalid1');
        $(this).siblings(".err-msg").css("visibility", "visible");
    }
});
////Email Id Validate End /////
///////input file upload jquery start/////////
$('.file-name').bind("DOMSubtreeModified", function() {
    $(this).siblings('.err-msg1').hide();
    $(this).siblings('.inputfile').removeClass('invalid').addClass('valid');
});
$('.inputfile').each(function() {
    var $input = $(this),
        $label = $input.next('label'),
        labelVal = $label.html();
    $input.on('change', function(e) {
        var fileName = '';
        if (this.files && this.files.length > 1)
            fileName = (this.getAttribute('data-multiple-caption') || '').replace('{count}', this.files.length);
        else if (e.target.value)
            fileName = e.target.value.split('\\').pop();
        if (fileName)
            $label.next('.file-name').html(fileName);
        else
            $label.html(labelVal);
    });
});


////////////////////mital/////////////////////////


/*my profile page js*/


var prevValue;

$('.profile-fields .inpt-txt .editBtn').click(function() {
    $('.profile-fields .inpt-txt .editBtn').hide();
    $(this).prev('.editBtn-disabled').hide();
    editTextField($(this));
});


$('.profile-fields .inpt-txt .saveBtn').click(function() {
    saveTextField($(this));
    $('.profile-fields .inpt-txt .editBtn').show();
    $(this).parent().siblings('.editBtn-disabled').show();
});



$('#pan-editbtn').click(function() {
    $('#panedit').show();
    $('#pan-block').hide();
});

$('#address-edit').click(function() {
    $('#addedit').show();
    $('#address-block').hide();
});

///////input file upload jquery start/////////
$('.file-name').bind("DOMSubtreeModified", function() {
    $(this).siblings('.err-msg1').hide();
    $(this).siblings('.inputfile').removeClass('invalid').addClass('valid');
});
$('.inputfile').each(function() {
    var $input = $(this),
        $label = $input.next('label'),
        labelVal = $label.html();
    $input.on('change', function(e) {
        var fileName = '';
        if (this.files && this.files.length > 1)
            fileName = (this.getAttribute('data-multiple-caption') || '').replace('{count}', this.files.length);
        else if (e.target.value)
            fileName = e.target.value.split('\\').pop();
        if (fileName)
            $label.next('.file-name').html(fileName);
        else
            $label.html(labelVal);
    });
});
///////input file upload jquery end/////////

$('.edit-box .savebtns a').click(function(e) {
    e.preventDefault();
    var ida = $(this).attr('id');
    if (ida == 'show-popup') {
        // alert('has popup id');
        $('#myModal').modal('show');
    }
    $('#addedit').fadeOut();
    $('#address-block').fadeIn();
    $('#panedit').fadeOut();
    $('#pan-block').fadeIn();
    $('#pan-block input').prop('disabled', 'true').addClass('disabled-input');
    saveTextField($(this));
    $('.profile-fields .inpt-txt .editBtn').show();
    $('.profile-fields .inpt-txt  .editBtn-disabled').show();
    $('.savebtns').hide();
});

// Reposition when a modal is shown
$('.modal').on('show.bs.modal', reposition);
// Reposition when the window is resized
$(window).on('resize', function() {
    $('.modal:visible').each(reposition);
});
$('#other-options').on('change', function() {

    if ($('#other-options').hasClass('active')) {
        //alert('checkbox checked');
        $('#form-dwnld').show();
    } else {
        $('#form-dwnld').hide();
    }
});

/*my profile js ends here*/
var otpcondn;

$('.policy-otp').click(function(e) {
    e.preventDefault();
    var b = $(this).parents('.switch-inpts');
    var condn = validateInput(b);
    //alert(condn);
    if (condn == true) {
        $('#policy-popup').modal('show');
    }
});
$('#validate-otp').click(function(e) {
    e.preventDefault();
    var otpcondn = validatePopup($(this).parent('.popup-policy'));
    //alert(otpcondn);
    if (otpcondn == true) {
        $('#policy-popup').modal('hide');
        $('#policy-popup').find(':input').val('').removeClass('on');
        var parentref = $('.accordion ul li.active .policy-content');
        parentref.find('.switch-inpts .policy-otp').hide();
        parentref.find('.switch-inpts .policy-otp').next('.aftr-otp').show();
        parentref.find(':input').addClass('disabled-input').prop('disabled', true).fadeTo(500, 0.4);
    }
});
$('.reset').click(function(e) {
    e.preventDefault();
    $(this).parents('.aftr-otp').siblings().find(':input').val('').removeClass('active on disabled-input').fadeTo(500, 1).prop('disabled', false);
    $(this).parents('.aftr-otp').fadeOut();
    $(this).parents('.aftr-otp').prev('.policy-otp').fadeIn();
})
$('.policy-submit').click(function(e) {
    e.preventDefault();
    var b = $(this).parents('.switch-inpts');
    var subcondn = validateInput(b);
    // alert(subcondn);
    if (subcondn == true) {
        $(this).next('.aftr-otp').css('display', 'inline-block');
    }
});



//////mital//////////////////////////////////////////


/*fund value js starts here*/
var seriesColors = ['#b02a31', '#f58220', '#004a80', '#ed1c26', '#ff9f4c', '#b9b89e', '#005d9e', '#cd4b52', '#f15a22']
    // For Bonus
var totalAmount = 0;
var totalUnits = 0;

/*if ($('.pie-charts').text() != '') {

    var pie2 = $.map($.makeArray(investview), function(v, i) {



        //v.x = new Date(v.x).getTime(); 
        // v.x = Date.UTC(v.x.split('-')[2], Months.indexOf(v.x.split('-')[1]), v.x.split('-')[0]);

        v.fundName = v.fundName.toString();
        v.Sfin = v.sfin.toString();
        v.fundValue = parseFloat(v.fundValue);
        v.Units = parseFloat(v.Units);
        v.Nav = parseFloat(v.Nav);
        totalUnits += v.Units;
        alert(" " + v.fundName + " " + v.Sfin + " " + v.fundValue);
        return { "name": v.fundName, "y": v.fundValue, "Units": v.Units, "NAV": v.Nav, "SFIN": v.Sfin };

    });

    Highcharts.getOptions().plotOptions.pie.colors = (function() {
        var colors = [],
            base = Highcharts.getOptions().colors[0],
            i;

        for (i = 0; i < 10; i += 1) {
            // Start out with a darkened base color (negative brighten), and end
            // up with a much brighter color
            colors.push(seriesColors[i]);
        }
        return colors;
    }());
    $('#allocation_pie').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.y:.2f}</b>'
        },
        title: false,
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: false,
                    format: '<b>{point.fundName}</b>: {point.percentage:.2f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    }
                }
            }
        },
        series: [{
            name: 'Brands',
            colorByPoint: true,
            data: pie2
        }]
    });
    renderTemplate('#allocationTemplate', '#allocation-table tbody', investview);
    setLegendColour(seriesColors, '#allocation-table tbody')

    // alert(totalAmount);
    var fivalue = numDifferentiation(totalAmount);
    // alert("converted value = " + fivalue);
    var fivalue = numberFormatter(fivalue);
    $("#total-bonus").text(fivalue);
    //    fivalue = setValF(fivalue);
    $("#current-valuation").text(numberFormatter(totalUnits));
    fivalue = removeCommas(fivalue);
    //  wordAmount = toWords(fivalue);
    //alert(parseFloat(fivalue).toFixed(2));
    var amt = number2text(fivalue);
    var valuation = removeCommas(totalUnits.toString());
    //alert("reformatted =" + valuation);
    var valuation = number2text(valuation);
    //alert('valuation in words  = '+valuation);
    $('#total-bonus-words').text(amt.toLowerCase());
    $('#total-valuation-words').text(valuation.toLowerCase());
    //For Allocation
}*/

if ($('.advisor').text() != '') {

    $('.advisor').owlCarousel({
        singleItem: true,
        // Navigation
        navigation: true,
        navigationText: ["", ""],
        rewindNav: true,
        scrollPerPage: false,
        pagination: false,
        autoPlay: 5000
    });
}

/*fund value js ends here*/



/*my policy js*/
function removeCommas(numWidCommas) {
    var numWidoutCommas = numWidCommas.replace(/[,]/g, '');
    return numWidoutCommas
}

function setValF(value) {

    var returnvalue = '';
    var slice1 = '';
    if (value.indexOf('Crore') > 0) {
        slice1 = value.replace(/[^0-9]/g, '');
        returnvalue = slice1 + '00000'
    } else if (value.indexOf('Lacs') > 0) {
        slice1 = value.replace(/[^0-9]/g, '');
        returnvalue = slice1 + '000'
    } else {
        returnvalue = removeCommas(value)
    }
    if (returnvalue.length < 6) {
        returnvalue = numberFormatter(returnvalue);
    }

    return returnvalue
        // alert("in set val f");
}


function numDifferentiation(val) {

    if (val >= 10000000) {

        val = (val / 10000000);
        //var finalval = Math.round(val);
        //alert("final value"+finalval);
        return val + ' Crore';
    } else if (val >= 100000) {
        val = (val / 100000);
        //var finalval = Math.round(val);
        //  alert("final value"+finalval);
        return val + ' Lacs';
    } else if (val < 100000) {
        val = numberFormatter(val);
        //val = parseInt(val);
    }

    return val;


}

function numberFormatter(x) {
    // skip for arrow keys
    // format number
    /* var formattedNumber = number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
     // alert("formatted="+formattedNumber);
     return formattedNumber;*/
    x = x.toString();
    var afterPoint = '';
    if (x.indexOf('.') > 0)
        afterPoint = x.substring(x.indexOf('.'), x.length);
    x = Math.floor(x);
    x = x.toString();
    var lastThree = x.substring(x.length - 3);
    var otherNumbers = x.substring(0, x.length - 3);
    if (otherNumbers != '')
        lastThree = ',' + lastThree;
    var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + afterPoint;
    // alert("formatted=" + res);
    return res;
}




var a = ['', 'One ', 'Two ', 'Three ', 'Four ', 'Five ', 'Six ', 'Seven ', 'Eight ', 'Nine ', 'Ten ', 'Eleven ', 'Twelve ', 'Thirteen ', 'Fourteen ', 'Fifteen ', 'Sixteen ', 'Seventeen ', 'Eighteen ', 'Nineteen '];
var b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

function inWords(num) {
    if ((num = num.toString()).length > 15)
        return 'overflow';
    n = ('000000000' + num).substr(-9).match(
        /^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n)
        return;
    var str = '';
    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : '';
    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lac ' : '';
    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : '';
    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
    str += (n[5] != 0) ? ((str != '') ? ' ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + ' ' : '';
    return str;
}

function isValid(str) {

    var iChars = "0123456789";

    for (var i = 0; i < str.length; i++) {
        if (iChars.indexOf(str.charAt(i)) != -1) {
            return true;
        }
    }
    return false;
}

function number2text(value) {
    var fraction = Math.round(frac(value) * 100);
    var f_text = "";

    if (fraction > 0) {
        f_text = "AND " + convert_number(fraction) + " PAISE";
    }

    return convert_number(value) + " RUPEE " + f_text + " ONLY";
}

function frac(f) {
    return f % 1;
}

function convert_number(number) {
    if ((number < 0) || (number > 999999999)) {
        return "NUMBER OUT OF RANGE!";
    }
    var Gn = Math.floor(number / 10000000); /* Crore */
    number -= Gn * 10000000;
    var kn = Math.floor(number / 100000); /* lakhs */
    number -= kn * 100000;
    var Hn = Math.floor(number / 1000); /* thousand */
    number -= Hn * 1000;
    var Dn = Math.floor(number / 100); /* Tens (deca) */
    number = number % 100; /* Ones */
    var tn = Math.floor(number / 10);
    var one = Math.floor(number % 10);
    var res = "";

    if (Gn > 0) {
        res += (convert_number(Gn) + " CRORE");
    }
    if (kn > 0) {
        res += (((res == "") ? "" : " ") +
            convert_number(kn) + " LAKH");
    }
    if (Hn > 0) {
        res += (((res == "") ? "" : " ") +
            convert_number(Hn) + " THOUSAND");
    }

    if (Dn) {
        res += (((res == "") ? "" : " ") +
            convert_number(Dn) + " HUNDRED");
    }


    var ones = Array("", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN");
    var tens = Array("", "", "TWENTY", "THIRTY", "FOURTY", "FIFTY", "SIXTY", "SEVENTY", "EIGHTY", "NINETY");

    if (tn > 0 || one > 0) {
        if (!(res == "")) {
            res += " AND ";
        }
        if (tn < 2) {
            res += ones[tn * 10 + one];
        } else {

            res += tens[tn];
            if (one > 0) {
                res += ("-" + ones[one]);
            }
        }
    }

    if (res == "") {
        res = "zero";
    }
    return res;
}




///////input file upload jquery end/////////
function payval(e) {
    $(".net-banking .form-row input,.net-banking .inpt-txt input").not(".not-mand").each(function() {
        var value = $(this).val();

        if (value == "" || value.length < 4) {
            //   alert("");
            $(this).addClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "visible");
        } else {
            $(this).removeClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "hidden");
        }
        if ($(this).hasClass('panno')) {
            var panboolean = validatePan(value);
            console.log(panboolean);
            if (panboolean == false) {
                $(this).addClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "visible");
            } else {
                $(this).removeClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "hidden");
            }
        }
    });
    $(".net-banking select").each(function() {
        var selval = $(this).find(":selected").val();
        // alert("selected value = "+selval);
        if (selval == "") {
            //alert("errorr");
            $(this).addClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "visible");
        } else {
            $(this).removeClass("invalid1");
            $(this).siblings(".err-msg").css("visibility", "hidden");
        }
    });
    if ($('.net-banking .tasks-list-item').not(".not-mand").hasClass('active') == false) {
        //  alert('chkbox');
        $(".net-banking .tasks-list-item").not(".not-mand").each(function() {
            $(this).children('span').addClass("invalid");
        });
    }
    $(".inputfile").not('.not-mand').each(function() {
        if ($(this).siblings('.file-name').text() == '') {
            $(this).siblings('.err-msg1').show();
            $(this).addClass('invalid').removeClass('valid');
        } else {
            $(this).siblings('.err-msg1').hide();
            $(this).addClass('valid').removeClass('invalid');
        }
    });
    if ($(window).width() < 760) {
        $(".inputfile").not('.not-mand').each(function() {
            //alert("in 760");
            if ($(this).siblings('.file-name').text() == '') {
                $(this).siblings('.err-msg1').hide();
                $(this).addClass('invalid').removeClass('valid');
            } else {
                $(this).siblings('.err-msg1').hide();
                $(this).addClass('valid').removeClass('invalid');
            }
        });
    };
}

function showCalc(lifestage, lifeneed, riskprofile) {
    //call some function to identify the calculator that needs to be displayed.

    //following dummy code for testing.
    switch (lifestage) {
        case "Young and Single":
            //code block
            $('#protection-calc').addClass('active');
            $('#protection-calc').find('.calc').fadeIn().addClass('active');
            $('#protection-calc').siblings().removeClass('active');
            $('#protection-calc').siblings().children('.calc').removeClass('active');

            break;
        case "Young and Married":
            //code block

            $('#marriage-calc').addClass('active');
            $('#marriage-calc').find('.calc').fadeIn().addClass('active');
            $('#marriage-calc').siblings().removeClass('active');
            $('#marriage-calc').siblings().children('.calc').removeClass('active');
            break;
        case "Young Parent":
            //code block
            $('#childeduction-calc').addClass('active');
            $('#childeduction-calc').find('.calc').fadeIn().addClass('active');
            $('#childeduction-calc').siblings().removeClass('active');
            $('#childeduction-calc').siblings().children('.calc').removeClass('active');
            break;
        case "Older Parent":
            //code block
            $('#wealth-calc').addClass('active');
            $('#wealth-calc').find('.calc').fadeIn().addClass('active');
            $('#wealth-calc').siblings().removeClass('active');
            $('#wealth-calc').siblings().children('.calc').removeClass('active');
            break;
        case "Retired":
            //code block
            $('#retirement-calc').addClass('active');
            $('#retirement-calc').find('.calc').fadeIn().addClass('active');
            $('#retirement-calc').siblings().removeClass('active');
            $('#retirement-calc').siblings().children('.calc').removeClass('active');

            break;
        default:
            //code block
            break;
    }
}

function setSpinner(objSpinner, defaultValue, minValue, maxValue, incrementStep, valueUnits) {
    objSpinner.attr('data-value', defaultValue);
    objSpinner.dpNumberPicker({
        value: defaultValue,
        min: minValue,
        max: maxValue,
        step: incrementStep,
        formatter: function(val) {
            return val + " " + valueUnits;
        },
        afterChange: function(val) {
            if (val < minValue || val > maxValue) {
                return false;
            }
        }
    });
}

function setCustomNumericSpinner(objSpinner, defaultValue, minValue, maxValue) {

    var valueunits;
    var incrementStep = getIncrementStep(defaultValue);
    objSpinner.attr('data-value', defaultValue);
    objSpinner.dpNumberPicker({
        value: defaultValue,
        min: minValue,
        max: maxValue,
        step: incrementStep,
        editable: true,
        formatter: function(val) {
            return numDifferentiation(val);
        },
        beforeChange: function() {
            this.value = objSpinner.attr('data-value');
        },
        afterChange: function() {
            var val = this.options.value;
            //alert(this);
            //alert(this.id);
            objSpinner.attr('data-value', val);
            console.log(val);
            console.log(objSpinner.attr('data-value'));
            this.options.formatter = function(val) {
                return numDifferentiation(val);
            }
            this.options.step = getIncrementStep(val);
            this.update();
        }
    });
}

function getIncrementStep(itemValue) {
    var incrementStep = 0;

    if (itemValue >= 0 && itemValue < 100000) {
        incrementStep = 10000;
    }
    if (itemValue >= 100000 && itemValue < 1000000) {
        incrementStep = 50000;
    }
    if (itemValue >= 1000000 && itemValue < 2500000) {
        incrementStep = 100000;
    }
    if (itemValue >= 2500000 && itemValue < 5000000) {
        incrementStep = 500000;
    }
    if (itemValue >= 5000000 && itemValue < 10000000) {
        incrementStep = 1000000;
    }
    if (itemValue >= 10000000 && itemValue < 100000000) {
        incrementStep = 5000000;
    }
    if (itemValue >= 100000000 && itemValue < 10000000000) {
        incrementStep = 10000000;
    }

    return incrementStep;
}

/*header js functions*/
function schemes() {

    if ($(this).hasClass("active") == false) {
        //$(".scheme-hold li.active").removeClass("active");
        $(this).siblings().removeClass("active");
        $(this).addClass("active");
        var tabNum = $(this).index();
        var nthChild = tabNum + 1;
        // $(".list-content-hold li.active").removeClass("active");
        //$(".list-content-hold li:nth-child(" + nthChild + ")").addClass("active");
        $(this).parent().next(".list-content-hold").children("li.active").removeClass("active");
        $(this).parent().next(".list-content-hold").children("li:nth-child(" + nthChild + ")").addClass("active");
        //  alert("in function...");
    }
    // alert("in schemes...");

};

function login() {
    /*login box checkbox js*/
    $(".chklabel").click(function() {
        $(".chkbox").toggleClass("checked");

        $('.usr-input .userinput').removeClass("invalid");
        $('.usr-input .userinput').siblings(".err-msg").css("visibility", "hidden");
    });
    /*login box radio buttons*/
    $(".radio-label").click(function() {
        var _this = $(this);
        var block = _this.parent().siblings();
        /* block.find('input[type="radio"]').prop("checked", false);*/
        block.find(".radio-label").removeClass('checked').blur();
        _this.addClass('checked');
        _this.blur();
        //  alert("in login....");
    });

    $(".customer-type .radio-label").click(function() {
        $('.usr-input .userinput').removeClass("invalid");
        $('.usr-input .userinput').siblings(".err-msg").css("visibility", "hidden");
        if ($(this).hasClass('checked') == true) {
            $('.username-input .userinput').val('');
            $('.password-input .userinput').val('');
        }
    });

    $('.password-input .hintone').click(function() {
        $('.usr-input .userinput').removeClass("invalid");
        $('.usr-input .userinput').siblings(".err-msg").css("visibility", "hidden");
    });

    $(".login-box label.mobilehint, .login-box .chkbox, .login-box a.mobilehint").click(function() {
        $('.usr-input .userinput').removeClass("invalid");
        $('.usr-input .userinput').siblings(".err-msg").css("visibility", "hidden");
    });

    /*customer login*/
    $("#login-toggle").click(function(e) {
        e.stopPropagation();
        $(".login-box").slideToggle();
        $(this).parent(".login-dropdown").toggleClass("active");
    });
    $(".login-box").click(function(event) {
        event.stopPropagation();
    });

    // $("body").on('touchstart',function() {
    //     $(".login-box").slideUp();
    //     $(".login-dropdown").removeClass("active");
    //     $(".mobile-search").slideUp();
    // });

    $("body").click(function() {
        $(".login-box").slideUp();
        $(".login-dropdown").removeClass("active");
        $(".mobile-search").slideUp();
    });

    $(".usr-input .userinput").blur(function() {
        var value = $(this).val()
        if (value == "" || value.length < 4) {
            //alert("");
            $(this).addClass("invalid");
            $(this).siblings(".err-msg").css("visibility", "visible");
        };
    });
    $("#signIn").click(function(event) {
        event.preventDefault();
        $(".usr-input .userinput").each(function() {
            var value = $(this).val()
            if (value == "" || value.length < 4) {
                //alert("");
                $(this).addClass("invalid");
                $(this).siblings(".err-msg").css("visibility", "visible");

            } else {
                $(this).removeClass("invalid");
                $(this).siblings(".err-msg").css("visibility", "hidden");
            };
        });
    });

};

function tabs(event) {
    event.preventDefault();
    event.stopPropagation();
    $(this).addClass("active").siblings().removeClass("active");
    var tab = $(this).children("a").attr("href");
    $(this).closest("ul")
        .next(".tab-content")
        .find(" > .tab-pane")
        .not(tab).removeClass("active");
    $(tab).addClass("active");
    // alert("in tabs function");
};

function mobile() {

    /*$(".login-icon").click(function(e) {
        e.stopPropagation();
        $(".mobile-login").slideToggle();
        $(".mobile-search").slideUp();
    });*/
    /*footer links in mobile*/
    $(".open-list").click(function() {
        $(this).parent().siblings().children(".footer-list").slideUp();
        $(this).parent().children(".footer-list").slideToggle();
    });

    $(".second-mobile ul > li").click(innerMenu);

    //   alert("in mobile..");
};

function tab() {

    /*login for tab*/
    /*if ($(window).width() > 767 && $(window).width() < 1000) {*/
    $(".login-icon").click(function(event) {
        closeNav(event);
        event.stopPropagation();
        $(".login-box").slideToggle();
        $(".mobile-search").slideUp();

    });
    /*  };*/
    /*search button js*/
    $(".search-icon").click(function(event) {
        closeNav(event);
        event.stopPropagation();
        $(".mobile-search").slideToggle(); /*24/11/15*/
        $(".login-box").slideUp();
        $(".mobile-login").slideUp();

    });

    $(".mobile-search").click(function(event) {
        event.stopPropagation();
    });

    $("body").click(function() {
        $(".secondary-navigation > li > div").slideUp(200);
        $(".secondary-navigation > li").removeClass("active");
        /*$(".navbar-collapse").removeClass('in');
        $(".navbar-collapse").attr('aria-expanded','false');*/
    });

    function closeNav(event) {
        var clickover = $(event.target);
        var _opened = $(".navbar-collapse").hasClass("in");
        if (_opened === true && !clickover.hasClass("navbar-toggle")) {
            $("button.navbar-toggle").click();
        }
    }

    // $(document).on('touchstart',function(event) {
    //     //event.preventDefault();
    //     closeNav(event);
    //     //event.stopPropagation();
    // });

    $(document).on('click', function(event) {
        closeNav(event);
    });

    if ($(window).height() < 500) {
        var winH = $(window).height();
        $('.second-nav').height(winH - 55);
        $('.login-box').css('height', winH - 55);
    }

    $(".secondary-navigation > li").not(".only-mobile").click(function(e) {
        e.stopPropagation();
        $(this).siblings().children(".first-layer").slideUp(100);
        $(this).children(".first-layer").slideDown(500);
        $(this).siblings().removeClass("active");
        $(this).addClass("active");
    });

    $(".tabs-menu li").click(tabs);
    $(".inner-tabs li").click(tabs);

    $(".secondary-navigation > li.only-mobile a").click(function(e) {
        e.stopPropagation();
    });

    $(".scheme-hold li").click(schemes);

    $(".scheme-hold li").click(function(e) {
        e.stopPropagation();
        e.preventDefault();
    });


    $(".second-mobile ul > li").click(innerMenu);

    if ($(window).width() < 900) {

        $(".secondary-navigation > li").not(".only-mobile").click(function(e) {
            e.stopPropagation();
            $(this).siblings().children(".mobile-menu").slideUp(500);
            $(this).children(".mobile-menu").slideDown(500);
        });

        $(".secondary-navigation > li").not(".only-mobile").children("a").click(function(e) {

            if ($(this).parent().hasClass("active") == true) {
                e.stopPropagation();
                e.preventDefault();
                $(this).parent().siblings().children(".mobile-menu").slideUp(500);
                $(this).parent().children(".mobile-menu").slideUp(500);
                $(this).parent("li").removeClass("active");
                //alert("hi");
            };

        });

        $(".mobile-accor > li").click(function() {

            $(this).siblings().children(".second-mobile").slideUp(500);
            $(this).siblings().children().find(".inner-menu").removeClass("on");
            $(this).siblings().children(".second-mobile").find("li").removeClass("active");
            $(this).children(".second-mobile").slideDown(500);
            $(this).siblings().removeClass("active");
            $(this).children().removeClass("active");
            $(this).addClass("active");
        });
        $(".mobile-accor > li > a").click(function(e) {

            if ($(this).parent().hasClass("active") == true) {
                e.stopPropagation();
                $(this).parent().siblings().children(".second-mobile").slideUp(500);
                $(this).parent().siblings().children().find(".inner-menu").slideUp(500);
                $(this).parent().siblings().children(".second-mobile").find("li").removeClass("active");
                $(this).parent().children(".second-mobile").slideUp(500);
                $(this).parent().siblings().removeClass("active");
                $(this).parent().children().removeClass("active");
                $(this).parent().removeClass("active");
            };

        });

    };
}

function innerMenu() {

    $(this).siblings().removeClass("active");
    $(this).addClass("active");
    $(this).siblings().children(".inner-menu").slideUp(500).removeClass("on");
    $(this).children(".inner-menu").slideDown(500).toggleClass("on");

};


function DeleteRow() {

    if (!confirm('Are you sure you want to delete')) {
        return false;
    } else {
        $(this).parents('.item').first().remove();
    }

}

function validateAmount(event) {
    // skip for arrow keys
    if (event.which >= 37 && event.which <= 40) return;
    // format number
    $(this).val(function(index, value) {
        return value
            .replace(/\D/g, "")
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    });
}

function validateInput(elementParent) {
    // alert("parent element received = " + elementParent);
    elementParent.find(":input").each(function() {

        if ($('.input-email').is(':visible') == false) {
            $('.input-email').removeClass('invalid1');
        }
        if ($(this).hasClass('input-email')) {
            if (ValidateEmail($(this).val()) == false) {
                $(this).addClass('invalid1');
                $(this).siblings('.err-msg').css('visibility', 'visible');
            } else {
                $(this).removeClass('invalid1');
                $(this).siblings('.err-msg').css('visibility', 'hidden');
            }
        } else
        if ($(this).val() == '') {
            $(this).addClass('invalid1');
            $(this).siblings('.err-msg').css('visibility', 'visible');
        } else {
            $(this).removeClass('invalid1');
            $(this).siblings('.err-msg').css('visibility', 'hidden');
        }
    });

    if (elementParent.find(":input").hasClass('invalid1') == true) {
        return false;
    } else {
        return true;
    }
}

function validatePopup(elementParent) {
    // alert("parent element received = " + elementParent);
    elementParent.find(":input[type='text']").each(function() {

        if ($(this).val() == '') {
            $(this).addClass('invalid1');
            $(this).siblings('.err-msg').css('visibility', 'visible');
        } else {
            $(this).removeClass('invalid1');
            $(this).siblings('.err-msg').css('visibility', 'hidden');
        }
    });

    if (elementParent.find(":input[type='text']").hasClass('invalid1') == true) {
        return false;
    } else {
        return true;
    }
}

function renderTemplate(renderTemp, targetElement, dataCollection) {
    var template = $.templates(renderTemp);
    var htmlOutput = template.render(dataCollection);
    $(targetElement).html(htmlOutput);
}

function setLegendColour(colorSeries, tableid) {
    var rows = $(tableid).children().length;

    for (var i = 0; i < rows; i++) {
        $(tableid).children().eq(i).find('.colorcode').css("background-color", colorSeries[i]);
    }
}



function editTextField(editlinkclicked) {

    editlinkclicked.next('input').prop('disabled', false).removeClass('disabled-input').addClass('input-field');
    editlinkclicked.siblings('.savebtns').show();
    editlinkclicked.hide();
    prevValue = editlinkclicked.siblings('input').val();
    $('.edit-box .savebtns').show();
}

function saveTextField(editlinkclicked) {
    editlinkclicked.parent().siblings('input').prop('disabled', true).removeClass('input-field').addClass('disabled-input');
    editlinkclicked.parent('.savebtns').hide();
    editlinkclicked.parent().siblings('.editBtn').show();
    if (editlinkclicked.hasClass('cancelBtn') == true) {
        editlinkclicked.parent().siblings('input').val(prevValue);
    }
}


function callSubmit(clikbutton) {
    var flag = false;
    //alert('in call submit');
    clikbutton.parents('.call-info').find(':input').each(function() {
        var value = $(this).val();
        if (value == null || value == "") {
            $(this).addClass('invalid1');
            $(this).siblings(".err-msg").css("visibility", "visible");
            //return false;
        } else if ($(this).hasClass('mobile-no')) {
            mobilevalidate = validateMobile(value);
            if (mobilevalidate == false) {
                $(this).addClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "visible");
            } else {
                $(this).removeClass("invalid1");
                $(this).siblings(".err-msg").css("visibility", "hidden");
                return true;
            }
        } else if ($('.tasks-list-item').not(".not-mand").hasClass('active') == false) {
            $(".tasks-list-item").not(".not-mand").each(function() {
                $(this).children('span').addClass("invalid");
            });
        } else {
            $(this).removeClass('invalid1');
            $(this).siblings(".err-msg").css("visibility", "hidden");
        }
        if (clikbutton.parents('.call-info').find(':input').hasClass('invalid1') == false) {
            flag = true;
            $(this).removeClass('invalid1');
            //$('.callback').animate({ 'top': '50%' })
            clikbutton.parents('.call-info').fadeOut();
            clikbutton.parents('.call-info').next('.call-acknowledge').fadeIn();
            $('.clicktocall').unbind('click');
            $('.clicktocall span').text('Thank You');

        }
    });

    return flag;
}


/*function dragStart(ev) {
    ev.dataTransfer.effectAllowed = 'move';
    ev.dataTransfer.setData("Text", ev.target.id);
    ev.dataTransfer.setDragImage(ev.target, 100, 100);
    return true;
}

function dragEnter(ev) {
    event.preventDefault();
    return true;
}

function dragOver(ev) {
    event.preventDefault();
}

function dragDrop(ev) {
    var data = ev.dataTransfer.getData("Text");
   //ev.target.appendChild(document.getElementById(data));
    $('#c2cbody').append($('#' + data).html());
    ev.dataTransfer.clearData();
    ev.stopPropagation();
    return false;
}
*/

function open(elem) {
    if (document.createEvent) {
        var e = document.createEvent("MouseEvents");
        e.initMouseEvent("mousedown", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
        elem[0].dispatchEvent(e);
    } else if (element.fireEvent) {
        elem[0].fireEvent("onmousedown");
    }
}
