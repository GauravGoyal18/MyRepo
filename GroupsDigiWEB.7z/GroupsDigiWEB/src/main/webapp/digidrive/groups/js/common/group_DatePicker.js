/** @author: Nikita
 * 
 */
/**
	 * This method is used to load the DatePicker UI.
	 * @param Date Picker Field ID
	 * @param Age Field ID
	 * @param Hidden Date ID
	 * @param Function name which id to be executed after date selection
	 * @param Max Date limit to be displayed on date picker
	 * @param Min Date limit to be displayed on date picker
	 */
function datePicker(dateElement,ageElement,dateHiddenElement,callBackFunc,maxDisplayDate,minDisplayDate)
{
	var contextpath = "/"+getContextPath();
	$(function() {
	$( "#"+ dateElement).datepicker(
	{
		//executed when date selected from DatePicker
		onSelect: function(value, ui) 
		{
			if(ageElement!="")
			{
				age = getAge(value,dateHiddenElement);
				$("#"+ageElement).val(age + ' Years');
			}
			callBackFunc();
		},
		showOn: "both",
		changeMonth: true,
		changeYear: true,
		buttonImage: contextpath+"/digidrive/groups/images/calendar.gif",
		buttonImageOnly: true,
		autoSize: true,
		maxDate: maxDisplayDate,
		minDate: minDisplayDate,
		yearRange: "1814:2100"
	});
	$("#"+ dateElement ).datepicker( "option", "dateFormat", "dd MM, yy" );
});
}

function getAge(DOB,hiddenDOB)
{
	//get current date
	var now = new Date();
	var currentyear = now.getFullYear();
	var currentmonth=now.getMonth()+1;
	var currentday=now.getDate();
	
	//split Date Picker date to get day, month and year
	var dateObtained =DOB.replace(',','');
	var dateArray = dateObtained.split(' ');
	var birth_day =dateArray[0];
	var monthq =dateArray[1];
	var birth_year =dateArray[2];
	
	//get Month in numeric form
	var birth_month =  getDatePickerMonthInReverse(monthq);
	
	//converted the datepicker date format for further process
	var strDate=birth_day+"/"+birth_month+"/"+birth_year;
	$("#"+hiddenDOB).val(strDate);
	
	var agechck=0;
	
	//calculated Age 
	var diff_m=Number(currentmonth) -Number(birth_month);
	var diff_d=Number(currentday) - Number(birth_day);
	
	if(diff_m<0)
		{
		agechck=currentyear-birth_year-1;
		}
	else if(diff_m>0)
		{
		agechck=currentyear-birth_year;
		}
	else if(diff_m==0)
		{
		if(diff_d<0)
			{
			agechck=currentyear-birth_year-1;
			}
		else if(diff_d>0)
			{
			agechck=currentyear-birth_year;
			}
		else if(diff_d==0)
			{
			agechck=currentyear-birth_year;
			}
		}
	return agechck;
}

function getDatePickerMonthInReverse(mnth)
{
	if(mnth!=""|| mnth!=null)
	{
		if(mnth=="January")
		{
			return "01";
		}
		if(mnth=="February")
		{
			return "02";
		}
		if(mnth=="March")
		{
			return "03";
		}
		if(mnth=="April")
		{
			return "04";
		}
		if(mnth=="May")
		{
			return "05";
		}
		if(mnth=="June")
		{
			return "06";
		}
		if(mnth=="July")
		{
			return "07";
		}
		if(mnth=="August")
		{
			return "08";
		}
		if(mnth=="September")
		{
			return "09";
		}
		if(mnth=="October")
		{
			return "10";
		}
		if(mnth=="November")
		{
			return "11";
		}
		if(mnth=="December")
		{
			return "12";
		}
	}
	else
	{
		return "";
	}
}
function getContextPath()
{
	var contextpath=window.location.pathname.split('/');
	return contextpath[1];
}
function getDatePickerMonthInWord(mnth)
{
	if(mnth!=""|| mnth!=null)
	{
		if(mnth=="01")
		{
			return "January";
		}
		if(mnth=="02")
		{
			return "February";
		}
		if(mnth=="03")
		{
			return "March";
		}
		if(mnth=="04")
		{
			return "April";
		}
		if(mnth=="05")
		{
			return "May";
		}
		if(mnth=="06")
		{
			return "June";
		}
		if(mnth=="07")
		{
			return "July";
		}
		if(mnth=="08")
		{
			return "August";
		}
		if(mnth=="09")
		{
			return "September";
		}
		if(mnth=="10")
		{
			return "October";
		}
		if(mnth=="11")
		{
			return "November";
		}
		if(mnth=="12")
		{
			return "December";
		}
	}
	else
	{
		return "";
	}
}

//===Added by Hiren Sonawala====//
function getDatePickerMonthInShortWord(mnth) 
{
	if(mnth!=""|| mnth!=null)
	{
		if(mnth=="January")
		{
			return "Jan";
		}
		if(mnth=="February")
		{
			return "Feb";
		}
		if(mnth=="March")
		{
			return "Mar";
		}
		if(mnth=="April")
		{
			return "Apr";
		}
		if(mnth=="May")
		{
			return "May";
		}
		if(mnth=="June")
		{
			return "Jun";
		}
		if(mnth=="July")
		{
			return "Jul";
		}
		if(mnth=="August")
		{
			return "Aug";
		}
		if(mnth=="September")
		{
			return "Sep";
		}
		if(mnth=="October")
		{
			return "Oct";
		}
		if(mnth=="November")
		{
			return "Nov";
		}
		if(mnth=="December")
		{
			return "Dec";
		}
	}
	else
	{
		return "";
	}
}