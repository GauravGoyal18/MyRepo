var app = angular.module('groupApp', [ 'ajaxUtil', 'ui.materialize','uiValidations','groupCommonUtil','validationService']);
app.controller('serviceDeskController',['$rootScope','$scope','$location','ajaxHttpFactory','csrDocUploadFactory','$window','validateFieldService','$filter',function($rootScope, $scope, $location, ajaxHttpFactory,csrDocUploadFactory,$window,validateFieldService,$filter) {


//var app=angular.module('groupApp',['ui.materialize']);

//app.controller('serviceDeskController',['$scope','$rootScope', function($scope,$rootScope){
	
	$rootScope.preloaderCheck=true;	
	$scope.serviceDesk=[];
	$scope.addressspilt=[];
	$scope.ServiceDatabaseDiv=false;
	$scope.ServiceStaticDiv=false;
	
	$scope.absUrl = window.location.origin + window.location.pathname+window.location.search;
        	
       var getServiceDeskdata = function () { 
    	   
    	       	  		
		return ajaxHttpFactory.getJsonData("getServiceDeskdata",$location.absUrl())
		.then(function(response) {
	
		if (response != null && response != "null") {
			var responseData = response.data;
		  
		if(responseData!=null && responseData !="null"){
			
			 $scope.serviceDesk = responseData;
			// $scope.addressspilt = responseData.address.split("\"); 
			 $scope.ServiceDatabaseDiv=true;
			 $scope.ServiceStaticDiv=false;
			 $rootScope.preloaderCheck=false;
			 
			 }else
				 {
				    $scope.ServiceDatabaseDiv=false;
				    $scope.ServiceStaticDiv=true;
				    $rootScope.preloaderCheck=false;
				 }
			 
			//alert( $scope.addressspilt);
			 
			
		}else{
			    $scope.ServiceDatabaseDiv=false;
			    $scope.ServiceStaticDiv=true;
			    $rootScope.preloaderCheck=false;
		   }
	},
	function(errResponse) {
		
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			
		}
	//	$rootScope.preloaderCheck=false;
		//$rootScope.preloaderCheck=true;
		//console.error('Error while fetching profile details.');

	});

};

getServiceDeskdata();
	  


}]);

