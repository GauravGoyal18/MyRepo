var app = angular.module('groupApp', ['ajaxUtil', 'uiValidations', 'ui.materialize', 'generalUtility', 'otpModalApp']);

app.controller('updateEmailMobileController', ['$scope', '$rootScope', '$location', 'ajaxHttpFactory', '$window', '$http', function($scope, $rootScope, $location, ajaxHttpFactory, $window, $http) {



    $scope.passwordDetail = {};
    $scope.updateEmailMobileJson = {};
    $rootScope.preloaderCheck = false;
    $scope.showCountryNames = false;
    //var passwordnew = "";
    $scope.errorArray = [];
    $scope.responseObj = [];
    $scope.showCountryCode = false;
    $scope.showFullMobileNo = false;
    var ajaxurl = $location.absUrl();
    $scope.showNriMobileNo = false;
    $scope.showMobileNo = true;
    $scope.updateEmailMobileJson.countryName = "INDIA";

    /*$scope.generateIpruKey = function (){
		var hashObj = new jsSHA("mySuperPassword"+Math.random(), "ASCII");
		passwordnew = hashObj.getHash("SHA-512", "HEX");
	
	    var x = Math.floor((Math.random()*15000000)+1);
	    $.jCryption.authenticate(passwordnew, "encrypt?generateKeyPair=true&rnd="+x, "encrypt?handshake=true&rnd="+x,

	                 function(AESKey) {                                                                                                               

	                 },

	                 function() {
	                        // Authentication failed
	                 }
	    );
	};
	
	$scope.generateIpruKey();*/


    $scope.successMethodOfGetCountryNames = function(response) {
        $scope.responseObj = response

        $scope.onChangeCountryName = function() {


            $scope.updateEmailMobileJson.mobileNo = "";
            for (var i = 0; i < response.length; i++) {
                if (response[i].countryName == $scope.updateEmailMobileJson.countryName) {
                    $scope.updateEmailMobileJson.code = response[i].countryCode;
                } else
                if ($scope.updateEmailMobileJson.countryName == "") {
                    $scope.updateEmailMobileJson.code = '';
                }
            }
        };
    }



    var getCountryDetails = function() {
        $rootScope.preloaderCheck = true;
        return ajaxHttpFactory.getJsonData("getCountryDetails", $location.absUrl())
            .then(function(response) {
                    $rootScope.preloaderCheck = false;
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
                        if (response != null && response != "null") {

                            $scope.successMethodOfGetCountryNames(response.data);
                        }
                    }
                },
                function(response) {
                    //			
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

                    }
                    $rootScope.preloaderCheck = false;
                });
    };

    getCountryDetails();
    $scope.submitEmailMobile = function() {
        if ($scope.updateEmailMobileJson.countryName == "INDIA" || $scope.updateEmailMobileJson.countryName == undefined || $scope.updateEmailMobileJson.countryName == "") {
            var currentElement = angular.element(document.querySelector('#countryName'));
            currentElement.removeClass('invalid1');
            $('#countryName_errMsg').css("visibility", "");
            for (var i = 0; i < $scope.errorArray.length; i++)
                if ($scope.errorArray[i] == "countryName") {
                    $scope.errorArray.splice(i, 1);
                    break;
                }

            var currentElement = angular.element(document.querySelector('#nriMobileNo'));
            currentElement.removeClass('invalid1');
            $('#nriMobileNo_errMsg').css("visibility", "");
            for (var i = 0; i < $scope.errorArray.length; i++)
                if ($scope.errorArray[i] == "nriMobileNo") {
                    $scope.errorArray.splice(i, 1);
                    break;
                }

        }

        if ($scope.updateEmailMobileJson.countryName != "INDIA" && $scope.updateEmailMobileJson.countryName != "") {

            var currentElement = angular.element(document.querySelector('#phoneNumber'));
            currentElement.removeClass('invalid1');
            $('#phoneNumber_errMsg').css("visibility", "");
            for (var i = 0; i < $scope.errorArray.length; i++)
                if ($scope.errorArray[i] == "phoneNumber") {
                    $scope.errorArray.splice(i, 1);
                    break;
                }
            if ($scope.checkBasicFieldValidations()) {
                $scope.failMobileNo = $scope.updateEmailMobileJson.mobileNo;
                $scope.updateEmailMobileJson.fullMobileNo = $scope.updateEmailMobileJson.code + $scope.updateEmailMobileJson.mobileNo;
                $scope.updateEmailMobileJson.mobileNo = $scope.updateEmailMobileJson.fullMobileNo;

                var emailMobileSubmit = angular.toJson($scope.updateEmailMobileJson);
                var ajaxurl = $location.absUrl();

                ajaxHttpFactory.postJsonDataSuccessFailure(emailMobileSubmit, "POST", ajaxurl, "checkEmailMobileExist", $scope.successMethodEmailMobileSubmit, $scope.failureMethodEmailMobileSubmit);

            } else {
                $rootScope.preloaderCheck = false;
                ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
            }
        } else {
            if ($scope.checkBasicFieldValidations()) {
                if ($scope.updateEmailMobileJson.mobileNo.match(/^[7-9]+[\d]{9}$/)) {

                    var emailMobileSubmit = angular.toJson($scope.updateEmailMobileJson);
                    var ajaxurl = $location.absUrl();

                    ajaxHttpFactory.postJsonDataSuccessFailure(emailMobileSubmit, "POST", ajaxurl, "checkEmailMobileExist", $scope.successMethodEmailMobileSubmit, $scope.failureMethodEmailMobileSubmit);
                } else {
                    ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill valid  Indian mobileNo", "errorMessage-popup", "forgotPasswordAlert");
                }
            } else {
                $rootScope.preloaderCheck = false;
                ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
            }
        }



    };

    $scope.onClickOfCountryButton = function(value) {
        if (value == "NRI") {

            $scope.showNriMobileNo = true;
            $scope.showCountryCode = true;
            $scope.showCountryNames = true;
            $scope.showMobileNo = false;
            $scope.updateEmailMobileJson.mobileNo = "";
            $scope.updateEmailMobileJson.emailId = "";
            $scope.updateEmailMobileJson.countryName = value;


            var currentElement = angular.element(document.querySelector('#phoneNumber'));
            currentElement.removeClass('invalid1');
            $('#phoneNumber_errMsg').css("visibility", "");

            var currentElement = angular.element(document.querySelector('#emailID'));
            currentElement.removeClass('invalid1');
            $('#emailID_errMsg').css("visibility", "");

            $scope.errorArray = ["nriMobileNo", "countryName", "emailID"];

        } else {
            if (value == "INDIA") {
                $scope.showNriMobileNo = false;
                $scope.showCountryCode = false;
                $scope.showCountryNames = false;
                $scope.showMobileNo = true;
                $scope.updateEmailMobileJson.mobileNo = "";
                $scope.updateEmailMobileJson.emailId = "";
                $scope.updateEmailMobileJson.countryName = "";
                $scope.updateEmailMobileJson.code = "";

                $scope.updateEmailMobileJson.countryName = value;



                var currentElement = angular.element(document.querySelector('#nriMobileNo'));
                currentElement.removeClass('invalid1');
                $('#nriMobileNo_errMsg').css("visibility", "");

                var currentElement = angular.element(document.querySelector('#emailID'));
                currentElement.removeClass('invalid1');
                $('#emailID_errMsg').css("visibility", "");

                var currentElement = angular.element(document.querySelector('#countryName'));
                currentElement.removeClass('invalid1');
                $('#countryName_errMsg').css("visibility", "");


                $scope.errorArray = ["phoneNumber", "emailID"];

            }
        }
    };




    $scope.successMethodEmailMobileSubmit = function(response) {

        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            $rootScope.preloaderCheck = false;

            if (response == "NOT_MATCHED") {
                $scope.linkRedirectionUrlWdgt();
                $rootScope.$on('otpHandShake', function(event, args) {
                    debugger;
                    if (args != null && args != undefined) {
                        var emailMobileSubmit = angular.toJson($scope.updateEmailMobileJson);
                        var ajaxurl = $location.absUrl();
                        $rootScope.preloaderCheck = true;
                        ajaxHttpFactory.postJsonDataSuccessFailure(emailMobileSubmit, "POST", ajaxurl, "emailMobileSave", $scope.saveEmailMobileSucces, $scope.saveEmailMobileFailure);



                    }
                });
            }
            $scope.saveEmailMobileSucces = function(response) {
                $rootScope.preloaderCheck = false;
                if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

                    $rootScope.check = true;
                    $scope.message = "Your email Id and Mobile number has been updated successfully.Kindly Login with your updated email Id/Mobile no ";
                }
            };

            $scope.saveEmailMobileFailure = function(response) {
                $rootScope.preloaderCheck = false;
                if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

                }

            };
        } else {

            if ($scope.updateEmailMobileJson.countryName != "INDIA" || $scope.updateEmailMobileJson.countryName != "") {
                $scope.updateEmailMobileJson.mobileNo = $scope.failMobileNo;
            }
            if ($scope.updateEmailMobileJson.countryName == "INDIA" || $scope.updateEmailMobileJson.countryName == "") {
                $scope.updateEmailMobileJson.mobileNo = "";
                $scope.updateEmailMobileJson.emailId = "";
            }
        }
    };

    $scope.failureMethodEmailMobileSubmit = function(response) {
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            $rootScope.preloaderCheck = false;
        }
    };

    $scope.linkRedirectionUrlWdgt = function() {
        var url = $location.absUrl();
        ajaxHttpFactory.linkRedirectionUrlWdgt(url, '&otpType=transactionalOTP');

    };



    $scope.okAlert = function() {

        $window.location.href = "onlogout.htm";
    };


    $scope.resetEmailMobile = function() {
        $scope.updateEmailMobileJson.emailId = '';
        $scope.updateEmailMobileJson.mobileNo = '';
        $scope.updateEmailMobileJson.countryName = '';
        $scope.updateEmailMobileJson.code = '';
        $scope.onClickOfCountryButton("INDIA");

        var radiobtn = document.getElementById("India");
        radiobtn.checked = true;



        var currentElement = angular.element(document.getElementsByClassName('invalid1'));
        currentElement.removeClass('invalid1');
        $('.err-msg').css("visibility", "");
        $scope.errorArray = ["phoneNumber", "emailID", "nriMobileNo", "countryName"];
    };

  

    $scope.checkBasicFieldValidations = function() {


        if ($scope.errorArray.length > 0) {
            for (var i = 0; i < $scope.errorArray.length; i++) {
                var lengthBfr = $scope.errorArray.length;
                var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
                if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT" || errorElement.prop('type') == "password") {
                    errorElement.triggerHandler("blur");
                }
                var lengthAftr = $scope.errorArray.length;
                if (lengthAftr < lengthBfr) {
                    i--;
                }
            }
            if ($scope.errorArray.length > 0) {
                $("#" + $scope.errorArray[0]).focus();
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    };

}]);