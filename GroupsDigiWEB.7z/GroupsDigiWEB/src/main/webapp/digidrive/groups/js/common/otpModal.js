try
{
	if(!(otpModalScope!=null && typeof otpModalScope === 'boolean'))
	{
		otpModalScope=false;
	}
}
catch(e)
{
	otpModalScope=false;
}

angular.module('otpModalApp', ['uiValidations','ajaxUtil'])//added ajaxutil
    /*.run(['spinnerFactory',function(spinnerFactory) {
        spinnerFactory.addIfNotPresent("otpSpinner");
    }])*/
    .directive('otpModal',['$timeout', function($timeout) {
        return {
            restrict: 'E',
            scope: otpModalScope,
            templateUrl: function(elem, attr) {
                if (angular.isUndefined(attr.url))
                    return "digidrive/groups/html/otp.html";
                else
                    return attr.url;
            },
            controller: ['$scope', 'ajaxHttpFactory', '$rootScope', '$location', '$http','$window', function($scope, ajaxHttpFactory, $rootScope, $location, $http,$window) {
                $scope.otpBean = {};
                $scope.otpBean.errorMsgFlag = false;
                $scope.formFlag = false;
                $scope.errorArray = [];
                $scope.showOtpPopup=false;
                $rootScope.otpForm = {};
                $rootScope.preloaderCheck=false;
                try
				{
					if(otpAsPopup!=null && typeof otpAsPopup === 'boolean')
					{
						$scope.otpAsPopup=otpAsPopup;
					}
					else
					{
						$scope.otpAsPopup=true;
					}
				}
				catch(e)
				{
					$scope.otpAsPopup=true;
				}
                $scope.setParam = function() {
                	var otpFormJsonString = angular.toJson($rootScope.otpForm);
                    if ($rootScope.transactionalOtp) {
                        $scope.url = $location.absUrl();
                        
                        if($scope.url!=null && $scope.url.indexOf('#')>-1)
                        {
                        	$scope.url=$scope.url.substring(0, $scope.url.indexOf('#'));
                        }
                        
//                        document.otpForm.action = $scope.url;
                        ajaxHttpFactory.postJsonDataSuccessFailure(otpFormJsonString,"POST",$scope.url,"setOTPParam",$scope.OtpParamCallbackSuccessFunc,$scope.OtpParamCallbackFailureFunc);
//                        ajaxHttpFactory.normalHttpMethodCall(transformer.formId, 'setOTPParam', $scope.OtpParamCallbackFunc, 'load', 'otp_errMsg');

                     
                    } else {
                        $scope.url = ($rootScope.otpExecutionKey != undefined) ? "otpmanager.htm?execution=" + $rootScope.otpExecutionKey : "otpmanager.htm";
//                        document.otpForm.action = $scope.url;
                        ajaxHttpFactory.postJsonDataSuccessFailure(otpFormJsonString,"POST",$scope.url,"setOTPParam",$scope.OtpParamCallbackSuccessFunc,$scope.OtpParamCallbackFailureFunc);
                        //ajaxHttpFactory.normalHttpMethodCall(transformer.formId, 'setOTPParam', $scope.OtpParamCallbackFunc, 'load', 'otp_errMsg');
                    }
                };
                $scope.OtpParamCallbackSuccessFunc = function(response) {
                	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
                		$scope.generateOtp();
                	}

                };
                $scope.OtpParamCallbackFailureFunc = function(response){
                	//alert("In OtpParamCallbackFailureFunc");
                	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
                		
                	}
                };
                $scope.generateOtp = function() {
                	var otpFormJsonString = angular.toJson($rootScope.otpForm);
                    $scope.otpBean.otpNumber = "";
//                    transformer.formId = "otpForm";
                   // $rootScope.$broadcast('otpSpinner', true);
                    $scope.url = ($rootScope.otpExecutionKey != undefined) ? "otpmanager.htm?execution=" + $rootScope.otpExecutionKey : "otpmanager.htm";
//                    document.otpForm.action = $scope.url;
//                    ajaxHttpFactory.normalHttpMethodCall(transformer.formId, 'generateOtp', $scope.generateOtpCallbackFunc, 'load', 'otp_errMsg');
                    $rootScope.preloaderCheck=true;
                    ajaxHttpFactory.postJsonDataSuccessFailure(otpFormJsonString,"POST",$scope.url,"generateOtp",$scope.generateOtpCallbackSuccessFunc,$scope.generateOtpCallbackFailureFunc);
                };
                $scope.generateOtpCallbackSuccessFunc = function(response) {
                	  $rootScope.preloaderCheck=false;
                	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
                		var resParam = angular.fromJson(response);
                		$rootScope.otpForm.message = resParam.msg;
                		Materialize.toast('Confirmation Code have been send successfully', 3000);
                        $rootScope.otpDisplay=true;//check the message and then set the parameter.
                		// $rootScope.$broadcast('pageSpinner', false);
                		//$rootScope.$broadcast('otpSpinner', false);
                	}
                };
                $scope.generateOtpCallbackFailureFunc = function(response){
                	 $rootScope.preloaderCheck=false;
                	//alert("In generateOtpCallbackFailureFunc");
                	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
                		
                	}
                };                

                $scope.checkBasicFieldValidations = function() {
                    if ($scope.errorArray.length > 0) {
                        for (var i = 0; i < $scope.errorArray.length; i++) {
                            var lengthBfr = $scope.errorArray.length;
                            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
                            if (!($("#" + $scope.errorArray[i]).is(':visible'))) {
                                $scope.errorArray.splice($scope.errorArray.indexOf(errorElement.prop('id')), 1);
                            } else if (errorElement.prop('type') == "password" || errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
                            	
                            	errorElement.triggerHandler("blur");
                            }

                            var lengthAftr = $scope.errorArray.length;

                            if (lengthAftr < lengthBfr) {
                                i--;
                            }
                        }

                        if ($scope.errorArray.length > 0) {
                            return false;
                        } else {
                            return true;
                        }
                    } else {
                        return true;
                    }
                };

                //encryption of otp
                
                $scope.generateIpruKey = function (){
            		var hashObj = new jsSHA("mySuperPassword"+Math.random(), "ASCII");
            		passwordnew = hashObj.getHash("SHA-512", "HEX");
            	
            	    var x = Math.floor((Math.random()*15000000)+1);
            	    $.jCryption.authenticate(passwordnew, "encrypt?generateKeyPair=true&rnd="+x, "encrypt?handshake=true&rnd="+x,

            	                 function(AESKey) {                                                                                                               

            	                 },

            	                 function() {
            	                        // Authentication failed
            	                 }
            	    );
            	};
            	/*$scope.cancelOtpModal=function()
            	{
            		$rootScope.otpFlag = false;
            	}*/
            	
            	$scope.generateIpruKey();
                 
                $scope.validateOtp = function() {
                    
                    if ($scope.checkBasicFieldValidations()) {
                    
                    	$rootScope.otpForm.otpNumber = $.jCryption.encrypt($rootScope.otpForm.otpNumber, passwordnew);
                    	
                    // $rootScope.$broadcast('pageSpinner', true);
                    	var otpFormJsonString = angular.toJson($scope.otpForm);
 //                       transformer.formId = "otpForm";
                        $scope.url = ($rootScope.otpExecutionKey != undefined) ? "otpmanager.htm?execution=" + $rootScope.otpExecutionKey : "otpmanager.htm";
 //                       document.otpForm.action = $scope.url;
//                        transformer.setFormElement("otpNumberHdn", $scope.otpBean.otpNumber);
//                        ajaxHttpFactory.normalHttpMethodCall(transformer.formId, 'validateOtp', $scope.validateOtpCallbackFunc, 'OTPCheck', 'otp_errMsg');
                        $rootScope.preloaderCheck=true;
                        ajaxHttpFactory.postJsonDataSuccessFailure(otpFormJsonString,"POST",$scope.url,"validateOtp",$scope.validateOtpCallbackSuccessFunc,$scope.validateOtpCallbackFailureFunc);
                    }
                };

                $scope.validateOtpCallbackSuccessFunc = function(response) {
                	  $rootScope.preloaderCheck=false;
               //  $rootScope.$broadcast('pageSpinner', false);
                	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
                		var resParam = angular.fromJson(response);
                		$rootScope.otpVerificationStatus=resParam.VERFCN_STATUS;
                		if (resParam.VERFCN_STATUS == 'True') {
                       
                			$rootScope.otpFlag = false;
                			if (resParam.transactionalOTPCallback=="true") {
                				$rootScope.$broadcast('otpHandShake', resParam.transactionalOTPCallback);
                			} else {
                				ajaxHttpFactory.linkRedirectionUrl($rootScope.redirectionUrl);
                            //$rootScope.$broadcast('pageSpinner', true);
                			}
                		}
                	}
                };
                
                $scope.validateOtpCallbackFailureFunc = function(response){
                	  $rootScope.preloaderCheck=false;
                	//alert("In validateOtpCallbackFailureFunc");
                	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
                		
                	}          
                };

                $scope.hide = function(m) {
                    if (m === 1) {
                        $rootScope.otpFlag = false;
                        removeInvalidClass(angular.element(document.getElementById('otpnumber')),angular.element(document.getElementById('otpnumber_errMsg')));
                        if(backbtn != undefined && backbtn==true){
                        	$window.location.href='http://www.iciciprulife.com';
                        };
                    }
                };

                $rootScope.$watch('otpFlag', function() {
                	
                    if ($rootScope.otpFlag) {
                    	// $rootScope.$broadcast('otpSpinner', true);
                        $scope.setParam();
                        $scope.showOtpPopup=true;
                    } else {
                    	  $scope.showOtpPopup=false;
                    }
                });


            }]

        };
    }]);  