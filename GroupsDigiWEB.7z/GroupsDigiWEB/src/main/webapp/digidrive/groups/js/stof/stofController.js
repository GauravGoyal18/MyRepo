var app = angular.module('groupApp',['ajaxUtil','uiValidations','ui.materialize','stofValidation']);

app.controller('stofController', ['$scope','$location','ajaxHttpFactory','$rootScope','$http','$q','$interval', '$timeout','$window','validiteStofService', function($scope,$location,ajaxHttpFactory,$rootScope,$http,$q,$interval, $timeout,$window,validiteStofService){
	$rootScope.preloaderCheck=true;
	$scope.errorArray = [];
	$scope.fundToList=[];
	$scope.oldFundDetails=[];
	$scope.fundMasterList=[];
	$scope.fundFromList=[];
	$scope.currentFunds=[];
	$scope.displayCurrentFunds=[];
	$scope.stofDetails={};
	$scope.stofSubmitDetails={};
	$scope.stofSubmitDetails.stof=[];
	$scope.fundCodes='';
	$scope.policyNumber='';
	$scope.count=0;
	$scope.stofSubmitDetails.totalStofAmount=0;
	$scope.selectedFund='';
	$scope.minAmount='';
	$scope.maxAmount='';
	var totalAmountWithAddedAmount=0;
	$rootScope.openAlertID = false;
	$scope.stofSubmitDetails.totalFundAmount=0;
	$scope.requestPerDay=true;
	$scope.showSwitchType=false;
	$scope.stofForm=true;
	$scope.stofShowDetails=true;
	$scope.frequencyOfTransfer=[];
	var ajaxurl=$location.absUrl();

	
	
	var fetchStofData = function ()
	{
		$scope.requestPerDay=true;
	var ajaxurl1 = ajaxurl + "&_eventId=" + "stofLoadData";
	var ajaxurl2 = ajaxurl + "&_eventId=" + "getFundCurrentDetails";

	
	d1 = $http({method: 'GET', url: ajaxurl1})
		.then(function(response) {
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
				
				

         if (typeof response.data === 'object') {
        	 	
                return response.data;
          } else {
              
  			ajaxHttpFactory.showErrorSuccessMessagePopup("Something went wrong. ","errorMessage-popup", "stofAlert");

      		$rootScope.preloaderCheck=false;

                return $q.reject(response.data);
            }
		}
			$rootScope.preloaderCheck=false;	
			
        }, function(response) {
          
			ajaxHttpFactory.showErrorSuccessMessagePopup("Something went wrong. ","errorMessage-popup", "stofAlert");

    		$rootScope.preloaderCheck=false;

            return $q.reject(response.data);
        });


	d2 = $http({method: 'GET', url: ajaxurl2})
	 .then(function(response) {
	
               if (typeof response.data === 'object') {
              
                   return response.data;
                   
               } else {
           		$rootScope.preloaderCheck=false;

    			ajaxHttpFactory.showErrorSuccessMessagePopup("Something went wrong. ","errorMessage-popup", "stofAlert");

                
                   return $q.reject(response.data);
               }

           }, function(response) {
              
   			ajaxHttpFactory.showErrorSuccessMessagePopup("Something went wrong. ","errorMessage-popup", "stofAlert");

       		$rootScope.preloaderCheck=false;

               return $q.reject(response.data);
           });


	$q.all([d1, d2])
	.then(function(response){

		$rootScope.preloaderCheck=false;

   
    
    var responseData=response[0];
    if(response[0].activeApplicableToFundList!=null)
    {	
    $scope.fundToList=responseData.activeApplicableToFundList;
    }
    
    if(response[0].activeFromFundList!=null)
    {	
    $scope.fundFromList=responseData.activeFromFundList;
    }
    
    if(response[0].fundMasterList!=null)
    {	
    $scope.fundMasterList=responseData.fundMasterList;
    }
    
    if(response[0].fundCodes!=null)
    {	
    	$scope.fundCodes=responseData.fundCodes;
    }
   
    if(response[0].policyNumber!=null)
    {	
    	$scope.policyNumber=responseData.policyNumber;
    }

    if(response[0].productSwitchAmount!=null)
    {	
    	$scope.minAmount=responseData.productSwitchAmount.minSwitchAmount;
    	$scope.maxAmount=responseData.productSwitchAmount.maxSwitchAmount;
    }
    
   if(response[0].isRequestPerDayExist!=null)
	  {
	   
	   $scope.requestPerDay=response[0].isRequestPerDayExist;
	   if($scope.requestPerDay)
		{
			ajaxHttpFactory.showErrorSuccessMessagePopup("You can not perform stof more than one time in a day. ","errorMessage-popup", "stofAlert");

			
		}
	  }
	if(response[0].freqOfTrans!=null)
	{
		
		$scope.frequencyOfTransfer=response[0].freqOfTrans;
	}
    if(response[0].fundDetailsVOList!=null)
    {	
        $scope.currentFunds=response[0].fundDetailsVOList;
    }
    
    if(response[1].fundDetailsVOList!=null)
    {	
        $scope.currentFunds=response[1].fundDetailsVOList;
    }
	
   for(var j=0;j<$scope.currentFunds.length;j++)
    {
    	
    	$scope.displayCurrentFunds.push($scope.currentFunds[j]);
    
    }
    	$scope.oldFundDetails=angular.copy($scope.displayCurrentFunds);

});

	};
	
	fetchStofData();
	
	
	
	var fetchTotalFundValue = function() 
	{
		
		var total=0;
		
		for(var i = 0; i < $scope.currentFunds.length; i++)
		{
			
			total = Number(total) +  Number($scope.currentFunds[i].totalAmount);
		}
		return total;
	};
	
	
	$scope.fetchUnitFromFund = function(fromFund) {
		
		
		for(var i = 0; i< $scope.currentFunds.length; i++)
		{
			if($scope.currentFunds[i].funddesc.trim() == fromFund.trim())
				return $scope.currentFunds[i].units;
		}
	};
	
	
	
	$scope.setUnitFromFund = function(fromFund,amount) {
				
		for(var i = 0; i< $scope.currentFunds.length; i++)
		{
			if($scope.currentFunds[i].funddesc.trim() == fromFund.trim())
				$scope.currentFunds[i].units=amount;
		}
	};
	
	
	$scope.fetchTotalAmountFromFund=function(fromFund)
	{
		
		for(var i=0;i<$scope.currentFunds.length;i++)
		{
			if($scope.currentFunds[i].funddesc.trim()==fromFund.trim())
			{
				return $scope.currentFunds[i].totalAmount;
				
			}
		}
		
		
	};
	
	$scope.setTotalAmountFromFund=function(fromFund,amount)
	{
		
		for(var i=0;i<$scope.currentFunds.length;i++)
		{
			if($scope.currentFunds[i].funddesc.trim()==fromFund.trim())
			{
				$scope.currentFunds[i].totalAmount=amount;
				
			}
		}
		
		
	};
	
	
	
	$scope.addStofDetails=function()
	{
		
		
		
		if ($scope.checkBasicFieldValidations())
		{
		
		if(!($scope.stofSubmitDetails.stof.length>9))	
		{
			
		if($scope.stofDetails.unitOrAmount!="0")	
		{
		if(checkNonCGToCG())
		{
		var add=true;
		
		var totalFromUnit = 0;
		$scope.stofDetails.fromAmount = 0;
		$scope.stofDetails.fromUnit = 0;
		$scope.stofDetails.fromNAV = 0;
		$scope.stofDetails.toAmount = 0;
		$scope.stofDetails.toUnit = 0;
		$scope.stofDetails.toNAV = 0;
		
		
		
		
		$scope.stofDetails.toAmount = 20000;
		$scope.stofDetails.toUnit = 2000;
		$scope.stofDetails.oNAV = 10;
		
		totalFromUnit=$scope.fetchUnitFromFund($scope.stofDetails.fundFromName.trim());
		totalFromUnit=Number(totalFromUnit).toFixed(3);
		$scope.stofDetails.fromUnit=totalFromUnit;
		
		for(var i=0;i<$scope.stofSubmitDetails.stof.length;i++)
		{
			
			if($scope.stofDetails.fundFromName.trim()==$scope.stofSubmitDetails.stof[i].fundFromName.trim())
			{
				if($scope.stofDetails.fundToName.trim()==$scope.stofSubmitDetails.stof[i].fundToName.trim())
				{
					ajaxHttpFactory.showErrorSuccessMessagePopup("You can not perform stof for same request. ","errorMessage-popup", "stofAlert");
					add=false;
				}
			}
		}
		if(add)
		{
		var totalAmountInvested = $scope.fetchTotalAmountInvested($scope.stofDetails.fundFromName.trim());
		if(Number($scope.stofDetails.numberOfTransfer)>100 || Number($scope.stofDetails.numberOfTransfer)<=0)
		{
			ajaxHttpFactory.showErrorSuccessMessagePopup("Number of transfer must be less than 100 and greater than 0. ","errorMessage-popup", "stofAlert");

		}
		else
			{
	
			var  totalAmountForSelectedFund=0;
			var flag=false;
		
			
			totalAmountForSelectedFund=$scope.fetchTotalAmountFromFund($scope.stofDetails.fundFromName.trim());
		
			
			$scope.stofDetails.fromAmount=totalAmountForSelectedFund;
			if(totalAmountForSelectedFund!=0)
			{

				flag=true;
			}
			
		
		if(flag)
		{
		

	
		if($scope.stofSubmitDetails.switchType == 'Units')
		{
			
			var amount=Number($scope.stofDetails.unitOrAmount).toFixed(3)*Number($scope.stofDetails.nav);

				amount=Number(amount).toFixed(2);
				
				totalAmountWithAddedAmount = totalAmountInvested + Number(amount);
				
				
				
				if(Number(totalAmountForSelectedFund)>=Number(totalAmountWithAddedAmount))
				{
					
					$scope.stofDetails.switchType=$scope.stofSubmitDetails.switchType;
					$scope.stofDetails.unit=$scope.stofDetails.unitOrAmount;
					
					$scope.stofDetails.unit=Number($scope.stofDetails.unit).toFixed(3);
					$scope.stofDetails.toAmount=0;
					$scope.stofDetails.toUnit=$scope.stofDetails.unit;
					$scope.stofDetails.ammount=0;
					
					$scope.stofDetails.totalValue=Number($scope.stofDetails.unitOrAmount)*Number($scope.stofDetails.nav);
					$scope.stofDetails.totalValue=Number($scope.stofDetails.totalValue).toFixed(2);
					
					
					
					$scope.stofSubmitDetails.totalStofAmount=Number($scope.stofSubmitDetails.totalStofAmount)+Number($scope.stofDetails.totalValue);
					$scope.stofSubmitDetails.totalStofAmount=Number($scope.stofSubmitDetails.totalStofAmount).toFixed(2);
			
					
						
				
				$scope.stofSubmitDetails.stof.push($scope.stofDetails);
				$scope.count++;
				$scope.stofDetails={};	
				$scope.stofDetails.unitOrAmount='';
				$scope.stofDetails.fundFromName='';
				$scope.stofDetails.fundToName='';
				$scope.stofDetails.nav='';
				$scope.stofDetails.frequency='';
				$scope.stofDetails.numberOfTransfer='';
			
				$scope.stofShowDetails=false;
				}
				else
				{
					
					ajaxHttpFactory.showErrorSuccessMessagePopup("You dont have sufficient funds. ","errorMessage-popup", "stofAlert");

				}
		}
		else if($scope.stofSubmitDetails.switchType == 'amount')
		{
			

			var amount=Number($scope.stofDetails.unitOrAmount).toFixed(2);

			totalAmountWithAddedAmount = totalAmountInvested + Number(amount);

			
			
			if(Number(totalAmountForSelectedFund)>=Number(totalAmountWithAddedAmount))
			{
				
				
				
				
				$scope.stofDetails.switchType=$scope.stofSubmitDetails.switchType;
				
				$scope.stofDetails.unit=0;
				
				
				$scope.stofDetails.ammount=$scope.stofDetails.unitOrAmount;
			
				$scope.stofDetails.ammount=Number($scope.stofDetails.ammount).toFixed(2);

				$scope.stofDetails.toAmount=$scope.stofDetails.ammount;
				$scope.stofDetails.toUnit=0;
				
				
				$scope.stofDetails.totalValue=$scope.stofDetails.unitOrAmount;
				$scope.stofDetails.totalValue=Number($scope.stofDetails.totalValue).toFixed(2);
				
				
				$scope.stofSubmitDetails.totalStofAmount=Number($scope.stofSubmitDetails.totalStofAmount)+Number($scope.stofDetails.totalValue);
				$scope.stofSubmitDetails.totalStofAmount=$scope.stofSubmitDetails.totalStofAmount.toFixed(2);
				
				
				
			$scope.stofSubmitDetails.stof.push(JSON.parse(JSON.stringify($scope.stofDetails)));
			$scope.stofDetails={};	
			$scope.stofDetails.unitOrAmount='';
			$scope.stofDetails.fundFromName='';
			$scope.stofDetails.fundToName='';
			$scope.stofDetails.nav='';
			$scope.stofDetails.frequency='';
			$scope.stofDetails.numberOfTransfer='';
	
			$scope.count++;
		
			$scope.stofShowDetails=false;
			}
			else
			{
				ajaxHttpFactory.showErrorSuccessMessagePopup("You don't have sufficient funds. ","errorMessage-popup", "stofAlert");

			}
		}
		else{
		ajaxHttpFactory.showErrorSuccessMessagePopup("Please select switch type. ","errorMessage-popup", "stofAlert");
		}
		
		
		
		
			}
		else
			{
			ajaxHttpFactory.showErrorSuccessMessagePopup("Please select fund from name. ","errorMessage-popup", "stofAlert");

			};
		
			}
		
		
		
	}
		}
		else
			{
			ajaxHttpFactory.showErrorSuccessMessagePopup("You can not stof from Non-CG to CG","errorMessage-popup", "stofAlert");

			}
		
		}
		
		
		
		else
		{
		ajaxHttpFactory.showErrorSuccessMessagePopup("Units/Amount must be greater than 0","errorMessage-popup", "stofAlert");

		}
		}
		else
			{
			ajaxHttpFactory.showErrorSuccessMessagePopup("You can not add more than 10 stof at a time","errorMessage-popup", "stofAlert");

			}
	}
		else
			{
			ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details","errorMessage-popup", "stofAlert");

			}
	};
	
	$scope.getNav=function(fundName)
	{
		for(var i=0;i<$scope.currentFunds.length;i++)
		{
			if(($scope.currentFunds[i].funddesc).trim()==fundName.trim())
			{
				$scope.stofDetails.nav=$scope.currentFunds[i].navValue;
				break;
			};
			
			
		};
		
	
		if($scope.selectedFund=="" || $scope.selectedFund=='')
		{
			
			for(var i=0;i<$scope.fundToList.length;i++)
			{
			
				if(($scope.fundToList[i].trim()==fundName.trim()))
				{
					$scope.selectedFund=fundName;
					$scope.fundToList.splice(i,1);
					break;
				};
				
				
			};
		
		}
	
		else if($scope.selectedFund.trim()!=fundName.trim())
		{
			$scope.fundToList.push($scope.selectedFund);
			for(var i=0;i<$scope.fundToList.length;i++)
			{
			
				if(($scope.fundToList[i].trim()==fundName.trim()))
				{
					$scope.selectedFund=fundName;
					$scope.fundToList.splice(i,1);
					break;
				};
				
				
			};
			
		}
		
		
		
		
	};
	
	$scope.deleteStofDetails=function(deleteId)
	{
		
	

		$scope.stofSubmitDetails.totalStofAmount=Number($scope.stofSubmitDetails.totalStofAmount).toFixed(2)-Number($scope.stofSubmitDetails.stof[deleteId].totalValue).toFixed(2);
		
		
	
		$scope.stofSubmitDetails.totalStofAmount=$scope.stofSubmitDetails.totalStofAmount.toFixed(2);
		
		$scope.stofSubmitDetails.stof.splice(deleteId,1);
		
		if($scope.stofSubmitDetails.stof.length!=0)
			{
	
		
			}
		
		else
			{
		$scope.stofShowDetails=true;
			}
		$scope.count=$scope.count-1;
		
		
		
		
	};
	
	
	$scope.changeStofData=function()
	{
		
		
	
		$scope.stofSubmitDetails.stof=[];
		$scope.stofDetails={};
		$scope.count=0;
		$scope.stofSubmitDetails.totalStofAmount=0;
		$scope.stofForm=false;
		$scope.stofShowDetails=true;
		
	};
	
	
	$scope.fetchTotalAmountInvested = function(fromFund) {
		
		
		var total = 0;
		
		for(var i = 0; i < $scope.stofSubmitDetails.stof.length; i++)
		{
			if($scope.stofSubmitDetails.stof[i].fundFromName.trim() == fromFund){
				total = total +  Number($scope.stofSubmitDetails.stof[i].totalValue);
			}
		}
		return total;
	};
	
	
	$scope.submitStofData=function()
	{
		if($scope.stofSubmitDetails.stof.length==0)
		{
			
			ajaxHttpFactory.showErrorSuccessMessagePopup("Atleast one record should be there. ","errorMessage-popup", "stofAlert");

		}
		else
		{
			
			if($scope.stofSubmitDetails.iAgreeTnC)
				{
			if((Number($scope.minAmount)<=Number($scope.stofSubmitDetails.totalStofAmount))&& ($scope.stofSubmitDetails.totalStofAmount)<=Number($scope.maxAmount))
				{
				$rootScope.preloaderCheck=true;	
			$scope.stofSubmitDetails.totalFundAmount=fetchTotalFundValue();	
			var stofSubmitData=angular.toJson($scope.stofSubmitDetails);
			ajaxurl=$location.absUrl();
			
			ajaxHttpFactory.postJsonDataSuccessFailure(stofSubmitData,"POST",ajaxurl,"stofSubmit",$scope.successMethod,$scope.failureMethod);

				}
			else
				{
				ajaxHttpFactory.showErrorSuccessMessagePopup("Total Switch amount must be between "+$scope.minAmount+" & "+$scope.maxAmount ,"errorMessage-popup", "stofAlert");

				}
			
			
				}
			else
				{
				ajaxHttpFactory.showErrorSuccessMessagePopup("Please select I accept Terms and Conditions " ,"errorMessage-popup", "stofAlert");

				}
		}
		
		
	};
	
	
	
	$scope.successMethod=function(response)
	{
		$rootScope.preloaderCheck=false;

		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "nomineeAlert"))

		{
			if (response != null && response != "null") {
				
				$rootScope.openAlertID = true;
				$scope.action="success";
				$scope.message = "Your request submitted successfully with Request id "+response.stofTransactionId+". Your Request Execution date is "+response.reqExecutionDate;

			}
			
			
		}
		/*else
			{
		
			ajaxHttpFactory.showErrorSuccessMessagePopup("Something went wrong. ","errorMessage-popup", "nomineeAlert");

			}
*/	};
	$scope.failureMethod=function(){
		
		$rootScope.preloaderCheck=false;
		
		$rootScope.openAlertID = true;
		$scope.action="failure";
		$scope.message = "Some Error Occured.";
	};
	$scope.okAlert= function (){
		$rootScope.openAlertID = false;
		if($scope.action=="success")
			{
			$window.location.href = "dashboard.htm";
			}
		else if($scope.action=="failure")
			{
			$window.location.href = "onlogout.htm";
			}
		
	};

	
	$scope.checkBasicFieldValidations = function() {
		
		
		$scope.error=validiteStofService.validateFundDetails($scope.stofDetails);
		for (var i=0;i<$scope.error.length;i++)
			{
			$scope.errorArray.push($scope.error[i]);
			}
		
	    if ($scope.errorArray.length > 0) {
	        for (var i = 0; i < $scope.errorArray.length; i++) {
	            var lengthBfr = $scope.errorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = $scope.errorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	        if ($scope.errorArray.length > 0) {
	            $("#" + $scope.errorArray[0]).focus();
	            return false;
	        } else {
	            return true;
	        }
	    } else {
	        return true;
	    }
	};


	
	
	var checkNonCGToCG = function()
	{
		
		var isCGFromFund='';
		var isCGToFund='';
			for(var i = 0; i < $scope.fundMasterList.length; i++)
			{
				if($scope.fundMasterList[i].fundName.trim() == $scope.stofDetails.fundFromName.trim()){
					isCGFromFund = $scope.fundMasterList[i].isCapital;
				}
				
				else if($scope.fundMasterList[i].fundName.trim() == $scope.stofDetails.fundToName.trim()){
					isCGToFund = $scope.fundMasterList[i].isCapital;
				}

			
			}
			if(isCGFromFund == "N" && isCGToFund == "Y")
			{
				
				return false;
			}	
				
			return true;
	
		
	
		
	};
	
	
	
	
	
}]);
	