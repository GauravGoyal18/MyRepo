/*$(".button-collapse").sideNav();*/
 $('select').material_select();
 /* $('ul.tabs').tabs('select_tab', 'tab_id');
// $('.responsive-table').DataTable();
 $('.datepicker1').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15, // Creates a dropdown of 15 years to control year
    //min: true,
    onOpen: function () {
      this.clear();
    },
    onSet: function () {
      var x,y,year,date,month;
      x = $('.datepicker1').pickadate().val().toString();
      y = x.split(/[ ,]+/);
      date = y[0];
      month = y[1];
      year = y[2];
      console.log(y[0]+" "+ y[1]+ " "+ y[2]);
      if(date && month && year){
        this.close();
      }
    }
  });
 
 $('.datepicker2').pickadate({
	    selectMonths: true, // Creates a dropdown to control month
	    selectYears: 15, // Creates a dropdown of 15 years to control year
	    //min: true,
	    onOpen: function () {
	      this.clear();
	    },
	    onSet: function () {
	      var x,y,year,date,month;
	      x = $('.datepicker2').pickadate().val().toString();
	      y = x.split(/[ ,]+/);
	      date = y[0];
	      month = y[1];
	      year = y[2];
	      console.log(y[0]+" "+ y[1]+ " "+ y[2]);
	      if(date && month && year){
	        this.close();
	      }
	    }
	  });
  
 var currVal;
  $('span.edit').on('click', function(){
	  
	  $('.edit').each(function(i){
		  if(!$(this).hasClass('noHide'))
			  $(this).hide();
	  });
	  //$('.editopt').show();
	  $(this).siblings(".editopt").show();
	  $(this).siblings("input").attr('disabled', false);
	  currVal = $(this).siblings("input").val();
	  if($(this).siblings('.noHide')) 
		$(this).siblings('.noHide').hide();
  })
  
  $('.cancel').on('click', function(){
	  $('.edit').show();
	  $(".editopt").hide();
	  $(this).parent().siblings("input").attr('disabled', true);
	  $(this).parent().siblings("input").val(currVal);
  });
  
  $('.save').on('click', function(){
	  $('.edit').show();
	  $(".editopt").hide();
	  $(this).parent().siblings("input").attr('disabled', true);
  });
  
  
  
  
   $('.modal').modal({
      dismissible: true, // Modal can be dismissed by clicking outside of the modal
      opacity: .5, // Opacity of modal background
      in_duration: 300, // Transition in duration
      out_duration: 200, // Transition out duration
      starting_top: '4%', // Starting top style attribute
      ending_top: '10%', // Ending top style attribute
      ready: function(modal, trigger) { // Callback for Modal open. Modal and trigger parameters available.
       // alert("Ready");
        console.log(modal, trigger);
      },
      complete: function() {
		  // alert('Closed');
	   } // Callback for Modal close
   });*/