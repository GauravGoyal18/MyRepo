var app = angular.module('groupApp',['ajaxUtil','ui.materialize','uiValidations','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection']);
app.controller("bidSummaryController",['$rootScope','$scope','$location','ajaxHttpFactory','$http','$q','$interval','$timeout','uiGridConstants',
                                   function($rootScope, $scope,$location,ajaxHttpFactory,$http, $q, $interval, $timeout,uiGridConstants){
	
	//$rootScope.preloaderCheck=true;
	//alert("2");
	var ajaxurl = $location.absUrl();
	$scope.bidSummaryData = [];
	$scope.bidData={};
	
	//$scope.retirementCalenderData=[];
	//$scope.retirementData={};
	
	
	var paginationOptions = {
		    pageNumber: 1,
		    pageSize: 100,
		    sort: null
	};
	
	var bidSummary = function () { 
    	//alert("BID Summary2");
    	$rootScope.preloaderCheck=true;
    	return ajaxHttpFactory.getJsonData("bidSummary",ajaxurl)
		.then(function(response) {
			
			$rootScope.preloaderCheck=false;
			if(!ajaxHttpFactory.handleIPruException(angular.toJson(response.data), "errorMessage-popup")) {
				if (response != null && response != "null") {
					var responseData = response.data;

					
					
			/*		if(angular.isDefined(responseData) && responseData != null && responseData != ""){
						for(var i=0; i< responseData.length;i++)
						{
							$scope.bidSummaryData.push(responseData[i]);
							$scope.trustgridOptions.data = $scope.memberList;
						}
					}*/
					
					
					$scope.bidSummaryData = responseData;
					$scope.bidData.totalItems=$scope.bidSummaryData.length;
					$scope.getPage();
					
					
				}
			}
			else{
				$rootScope.preloaderCheck=false;
			}
		},
		function(errResponse) {
			//$rootScope.preloaderCheck=false;
			console.error('Error while fetching intial setup details.');

		});
    };
	
    bidSummary();
    
    $scope.getPage = function() {
		   var firstRow = (paginationOptions.pageNumber - 1) * paginationOptions.pageSize;
		   $scope.bidData.data = $scope.bidSummaryData.slice(firstRow, firstRow + paginationOptions.pageSize);
	 };
	
	 $scope.bidData = {
			    paginationPageSizes: [100],
			    paginationPageSize: 100,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableFiltering: true,
			    enableRowSelection : true,
	            multiSelect : false,
	            enableRowHeaderSelection : false,
	            totalItems:$scope.count,
	            resizable: false,
	            enableColumnResizing: false,
			    columnDefs: [
			      { field: 'balance', displayName: 'Balance(Rs)', width: "30%", enableSorting: false},
			      { field: 'unitName', displayName: 'Unit Name', width: "70%", enableSorting: false},
			      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;
			 
			      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;
			        $scope.getPage();
			      });
			   
			   
 
			    }
			  };

}]);
	

