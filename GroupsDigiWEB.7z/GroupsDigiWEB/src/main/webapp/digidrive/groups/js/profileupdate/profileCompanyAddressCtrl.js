		/*var app = angular.module('groupApp', ['ajaxUtil','ui.materialize','validationService','uiValidations']);*/
app.controller('profileCompanyAddressCtrl',['$rootScope','$scope','$location','ajaxHttpFactory','validateFieldService','$window','csrDocUploadFactory', function($rootScope, $scope,$location,ajaxHttpFactory,validateFieldService,$window,csrDocUploadFactory){
 

	$rootScope.preloaderCheck=true;
	$scope.modalErrorArray=[];
	$scope.loadCompanyPersonDetails={};
	$scope.resultMap={};
	$scope.state=[];
	$scope.cityDetails=[];
	$scope.city=[];
	$scope.addressType=[];
	$scope.addressProof=[];
	$scope.CompanyAddress=false;
	$scope.companyAddressPoData=[];
	$scope.errorArray=[];
	$scope.PrepopulateCompanyPersonDetails=[];
	$scope.showEditAddrFields=false;
	$scope.absUrl =window.location.origin + window.location.pathname+window.location.search;
	$scope.companyAddressChangeSubmit={};
	$scope.CompanyAddressAccessMatrix={};
	$rootScope.enable=true;
	$scope.companyAddrConstant="companyAddressChange";
	$scope.list=[];
	$scope.uploadFileList=[];
	$scope.addressOldvalue="";
	$scope.companyDiv=false;
	 $scope.submitJson={};
	$scope.functionalityId = "";
	$scope.addressInsertLimit=true;
	$scope.radiodiv=false;
	$scope.fileDiv=false;
	
	
	$scope.onClickCompanyAddress= function(){
		$scope.loadCompanyPersonDetails.addressType.newValue="";
		$scope.loadCompanyPersonDetails.companyOrBuildingName.newValue="";
		$scope.loadCompanyPersonDetails.flatOrUnitNumber.newValue="";
		$scope.loadCompanyPersonDetails.streetOrArea.newValue="";
		$scope.loadCompanyPersonDetails.landmark.newValue="";
		$scope.loadCompanyPersonDetails.pincode.newValue="";
		$scope.loadCompanyPersonDetails.state.newValue="";
		$scope.loadCompanyPersonDetails.city.newValue="";
		//$scope.loadCompanyPersonDetails.addressproof.newValue="";
	/*	var upload_file=angular.element(document
	            .querySelector('#file-upload-main-placeholder'));
		upload_file[0].innerHTML =  "";*/
		 var upload_Msg = angular.element(document
		            .querySelector('#file-upload-main2_errMsg'));
		 

		 upload_Msg[0].innerHTML ="";
		 
		 var des_Msg = angular.element(document
		            .querySelector('#file-upload-main2_upText'));
		 
		 des_Msg[0].innerHTML =  "";
		 
	$scope.modalErrorArray=["companyAddress_addressType_new", "companyAddress_Company_new", "companyAddress_Flat_new", "companyAddress_Street_new", "companyAddress_Landmark_new", "companyAddress_Pincode_new", "companyAddress_State_new", "companyAddress_City_new"];
		$scope.CompanyAddress = true;
		 
		 
		
	};
	$scope.showReadOnlyAddress=function(){
		return $scope.validateFields($scope.companyAddrConstant,'show') && !$scope.showEditAddrFields;
	};
	
	$scope.showEditAddress=function(){
		return $scope.validateFields($scope.companyAddrConstant,'edit') && $rootScope.enable;
	};
	$scope.showSaveCancelOnEditAddress=function(){
		return (!$scope.validateFields($scope.companyAddrConstant,'edit')) && $scope.showEditAddrFields;
	};
	
	$scope.onCallRadioButton= function (index){
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$('.err-msg').css("visibility", "");
		$scope.OnResetBtn();
		$scope.companyDiv=true;
		$scope.index=index;
		$scope.city=[];
		
		$scope.addressOldvalue=$scope.PrepopulateCompanyPersonDetails[$scope.index].prePopulateList;
		$scope.PrepopulateCompanyPersonDetails[$scope.index].prePopulateList=$scope.addressOldvalue;
		$scope.PrepopulateCompanyPersonDetails[$scope.index].addressType.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].addressType.oldValue;
		$scope.PrepopulateCompanyPersonDetails[$scope.index].companyOrBuildingName.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].companyOrBuildingName.oldValue;
		$scope.PrepopulateCompanyPersonDetails[$scope.index].flatOrUnitNumber.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].flatOrUnitNumber.oldValue;
		$scope.PrepopulateCompanyPersonDetails[$scope.index].streetOrArea.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].streetOrArea.oldValue;
		$scope.PrepopulateCompanyPersonDetails[$scope.index].landmark.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].landmark.oldValue;
		$scope.PrepopulateCompanyPersonDetails[$scope.index].pincode.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].pincode.oldValue;
		$scope.PrepopulateCompanyPersonDetails[$scope.index].state.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].state.oldValue;
		$scope.getCityList($scope.PrepopulateCompanyPersonDetails[$scope.index].state.newValue);
        $scope.PrepopulateCompanyPersonDetails[$scope.index].city.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].city.oldValue;
		//$scope.PrepopulateCompanyPersonDetails[$scope.index].addressproof.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].addressproof.oldValue;
	
	};
	
	$scope.companyAddressChangeCancel= function (){
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$('.err-msg').css("visibility", "");
		$scope.OnResetBtn();
		$scope.CompanyAddress = false;
		$scope.onClickCompanyAddress();
		
		
	};
	var getCompanyAddressDetailsAccessMatrix = function () { 
		
			return ajaxHttpFactory.getJsonData("getCompanyAddressDetailsAccessMatrix",$scope.absUrl)
			.then(function(response) {
				$rootScope.preloaderCheck=false;
				if (response != null && response != "null") {
					var responseData = response.data;
					$scope.CompanyAddressAccessMatrix = responseData.resultMap;
				
				}
			},
			function(errResponse) {
				$rootScope.preloaderCheck=false;
				console.error('Error while fetching profile details.');

			});

		};
		getCompanyAddressDetailsAccessMatrix();	
	
var loadCompanyAddressDetails = function () { 
		
			return ajaxHttpFactory.getJsonData("loadCompanyAddressDetails",$scope.absUrl)
		.then(function(response) {
			$rootScope.preloaderCheck=false;
			if (response != null && response != "null") {
				var responseData = response.data;
				$scope.loadCompanyPersonDetails = responseData;
				$scope.functionalityId=$scope.loadCompanyPersonDetails.functionalityId;
			}
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});

	};
	loadCompanyAddressDetails();

	
	var prePopulateCompanyAddressDetails = function () { 
		
		
			return ajaxHttpFactory.getJsonData("prePopulateCompanyAddressDetails",$scope.absUrl)
			.then(function(response) {
				$rootScope.preloaderCheck=false;
				if (response != null && response != "null") {
					var responseData = response.data;
					$scope.PrepopulateCompanyPersonDetails = responseData;
					if($scope.PrepopulateCompanyPersonDetails.length > 3)
						{
						$scope.addressInsertLimit=false;
						
						}
					
					if($scope.PrepopulateCompanyPersonDetails.length > 0)
						{
						$scope.radiodiv=true;
						}
					
					
					
				}
			},
			function(errResponse) {
				$rootScope.preloaderCheck=false;
				console.error('Error while fetching profile details.');

			});

		};
		prePopulateCompanyAddressDetails();
		
		$scope.companyAddressChangeSubmitForm = function()
			{
			 if($scope.checkBasicFieldValidationsModal())
			 {
				
			 if($scope.uploadFileList.length>0 )
					 {
					 
					 $scope.companyAddressChangeSubmit=$scope.loadCompanyPersonDetails;
					 $scope.companyAddressChangeSubmit.uploadFiles=$scope.uploadFileList;
					
						
					 var companyAddressChangeSubmitJson=angular.toJson($scope.companyAddressChangeSubmit);

					$rootScope.preloaderCheck=true;
					ajaxHttpFactory.postJsonDataSuccessFailure(companyAddressChangeSubmitJson,"POST",$scope.absUrl,"companyAddressChangeSubmit",$scope.successMethod,$scope.failureMethod);
					 } 
					 else
					 {
						
						 ajaxHttpFactory.showErrorSuccessMessagePopup("Please upload file", "errorMessage-popup", "submitFileAlert");
					 }
				
					 }
				
					
			 };
		


$scope.editcompanyAddressChangeSubmitForm = function(id)
		{
	 if($scope.checkBasicFieldValidations())
	 {


		
		
		$scope.PrepopulateCompanyPersonDetails[$scope.index].prePopulateListval=$scope.PrepopulateCompanyPersonDetails[$scope.index].addressType.newValue+' '+$scope.PrepopulateCompanyPersonDetails[$scope.index].companyOrBuildingName.newValue+' '+$scope.PrepopulateCompanyPersonDetails[$scope.index].flatOrUnitNumber.newValue+' '+$scope.PrepopulateCompanyPersonDetails[$scope.index].streetOrArea.newValue+' '+$scope.PrepopulateCompanyPersonDetails[$scope.index].landmark.newValue+' '+$scope.PrepopulateCompanyPersonDetails[$scope.index].pincode.newValue+' '+$scope.PrepopulateCompanyPersonDetails[$scope.index].city.newValue+' '+$scope.PrepopulateCompanyPersonDetails[$scope.index].state.newValue;
		if($scope.PrepopulateCompanyPersonDetails[$scope.index].prePopulateListval==$scope.addressOldvalue){
			
			
			ajaxHttpFactory.showErrorSuccessMessagePopup("Enter a different value to save ","errorMessage-popup", "CompanyAddressAlert"); 	
	}
		else{

			$scope.editcompanyAddressChangeSubmit=$scope.PrepopulateCompanyPersonDetails[$scope.index];
			if($scope.uploadFileList.length>0)
				{
				$scope.validateFields(id,'save');
				if(id==$scope.companyAddrConstant) 
				{
					$scope.showEditAddrFields=false;
				}
			$scope.editcompanyAddressChangeSubmit.uploadFiles=$scope.uploadFileList;
			$scope.editcompanyAddressChangeSubmit.index=$scope.index;
			var editcompanyAddressChangeSubmitJson=angular.toJson($scope.editcompanyAddressChangeSubmit);
			
			$rootScope.preloaderCheck=true;
			ajaxHttpFactory.postJsonDataSuccessFailure(editcompanyAddressChangeSubmitJson,"POST",$scope.absUrl,"editcompanyAddressChangeSubmit",$scope.successMethod,$scope.failureMethod);
			$scope.PrepopulateCompanyPersonDetails[$scope.index].prePopulateList=$scope.addressOldvalue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].addressType.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].addressType.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].companyOrBuildingName.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].companyOrBuildingName.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].flatOrUnitNumber.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].flatOrUnitNumber.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].streetOrArea.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].streetOrArea.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].landmark.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].landmark.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].pincode.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].pincode.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].state.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].state.oldValue;
	        $scope.PrepopulateCompanyPersonDetails[$scope.index].city.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].city.oldValue;
		//	$scope.PrepopulateCompanyPersonDetails[$scope.index].addressproof.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].addressproof.oldValue;
				}else
					{
					 ajaxHttpFactory.showErrorSuccessMessagePopup("please upload file.", "errorMessage-popup", "submitFileCompanyAddress");
					}
		}
		$rootScope.enable=true;
		
	 }
	};
	
	
	$scope.successMethod=function(response){
		$rootScope.preloaderCheck=false;
	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "AuthChangeAlert"))
		
	{
		ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. ","errorMessage-popup", "CompanyAddressAlert"); 
		$scope.CompanyAddress = false;
		$scope.OnResetBtn();
		$scope.onClickCompanyAddress();
	}
};

	$scope.failureMethod=function(response){
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "AuthChangeAlert")){
			$scope.OnResetBtn();
			$scope.onClickCompanyAddress();
			
		}
	};
	
	
		var getStateDetails=function(){
			$rootScope.preloaderCheck=true;
			return ajaxHttpFactory.getJsonData("getStateDetails",$scope.absUrl)
			.then(function(response) {
				$rootScope.preloaderCheck=false;
				if (response != null && response != "null") {
			var responseData = response.data;
			for(var i = 0; i < responseData.length; i++)
			{
				
				$scope.state.push(responseData[i]);
			 
			      
			}
				}
				$rootScope.preloaderCheck=false;
			},
			function(errResponse) {
				$rootScope.preloaderCheck=false;
				console.error('Error while fetching profile details.');

			});
		};
		
		getStateDetails();
		
		$scope.validateFields = function(name,action)  
		{
	      
			$scope.id=name;
			$scope.action=action;
			$scope.result = validateFieldService.fieldValidate($scope.id,$scope.action,$scope.CompanyAddressAccessMatrix);
			return $scope.result;
			
		};
		
		var getCityDetails=function(){
			$rootScope.preloaderCheck=true;
			return ajaxHttpFactory.getJsonData("getCityDetails",$scope.absUrl)
			.then(function(response) {

				if (response != null && response != "null") {
					var responseData = response.data;
					
						$scope.cityDetails.push(responseData);
					
				}	
				$rootScope.preloaderCheck=false;
			},
			function(errResponse) {
				$rootScope.preloaderCheck=false;
				console.error('Error while fetching profile details.');

			});
		};
		
		getCityDetails();

		
		 $scope.getCityList = function(stateDetails) {
			
			 $scope.city=[];
			 if(stateDetails!=null){
			 var getCityDetails=$scope.cityDetails;
		
				var data1=getCityDetails[0];
				for(var i=0;i<data1.length;i++)
			 {
					if(data1[i].key==stateDetails){
					$scope.city.push(data1[i].value);
					
					}
					}
			 }
			
				
		
		 };
		 
	$scope.onloadCityDetails=function()
	{
		
		 $scope.getCityList($scope.PrepopulateCompanyPersonDetails[$scope.index].state.newValue);
	};
	

	
		 
		var getAddressType=function()
		{
			$rootScope.preloaderCheck=true;
			return ajaxHttpFactory.getJsonData("getAddressType",$scope.absUrl)
			.then(function(response) {
				if (response != null && response != "null") {
					var responseData = response.data;
					for(var i = 0; i < responseData.length; i++)
					{
						$scope.addressType.push(responseData[i]);
					}
				}
				$rootScope.preloaderCheck=false;
			},
			function(errResponse) {
				$rootScope.preloaderCheck=false;
				console.error('Error while fetching profile details.');
			});
		};
		getAddressType();
		
		var getAddressProof=function()
		{
			$rootScope.preloaderCheck=true;
			return ajaxHttpFactory.getJsonData("getAddressProof",$scope.absUrl)
			.then(function(response) {
				if (response != null && response != "null") {
					var responseData = response.data;
					for(var i = 0; i < responseData.length; i++)
					{
						$scope.addressProof.push(responseData[i]);
					}
				}
				$rootScope.preloaderCheck=false;
			},
			function(errResponse) {
				$rootScope.preloaderCheck=false;
				console.error('Error while fetching profile details.');
			});
		};
		getAddressProof();
	
		
		$scope.onclickeditbtn = function(id)    //On click of Edit Button
		{
			
			$scope.validateFields(id,'enable');
			$rootScope.enable=false;
			
			if(id==$scope.companyAddrConstant) 
			{
			
					$scope.getCityList($scope.PrepopulateCompanyPersonDetails[$scope.index].state.newValue);
					
				$scope.showEditAddrFields=true;
				
			}
			
			
		};

	

		$scope.onClickCancelBn = function(id)   //On click of Cancel Button
		{
		
			var currentElement = angular.element(document.getElementsByClassName('invalid1'));
			currentElement.removeClass('invalid1');
			$('.err-msg').css("visibility", "");
			
			
			$scope.PrepopulateCompanyPersonDetails[$scope.index].prePopulateList=$scope.addressOldvalue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].addressType.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].addressType.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].companyOrBuildingName.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].companyOrBuildingName.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].flatOrUnitNumber.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].flatOrUnitNumber.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].streetOrArea.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].streetOrArea.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].landmark.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].landmark.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].pincode.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].pincode.oldValue;
			$scope.PrepopulateCompanyPersonDetails[$scope.index].state.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].state.oldValue;
			$scope.getCityList($scope.PrepopulateCompanyPersonDetails[$scope.index].state.newValue);
	        $scope.PrepopulateCompanyPersonDetails[$scope.index].city.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].city.oldValue;
			//$scope.PrepopulateCompanyPersonDetails[$scope.index].addressproof.newValue=$scope.PrepopulateCompanyPersonDetails[$scope.index].addressproof.oldValue;
			
			$scope.validateFields(id,'cancel');
			if(id==$scope.companyAddrConstant)
			{
				$scope.showEditAddrFields=false;
			}
		
			$scope.OnResetBtn();
			$rootScope.enable=true;
		
		};

		
	
		$scope.upload = function(upId, docType) {
			
			$rootScope.preloaderCheck=false;
			
	        var desc_Id = angular.element(document
	            .querySelector('#' + upId.id+'_errMsg'));
	        var upload_Msg = angular.element(document
	            .querySelector('#' + upId.id + '_upText'));
	    
	            if(upId.files.length != 0){
	            	
	            	if(upId.files[0].size<5242880)
	            		{
	            	var length=upId.files[0].name.lastIndexOf('.');
	            	var ext=upId.files[0].name.substring(length+1,upId.files[0].name.length);
	            	if(ext=='PDF' || ext=='pdf' || ext=='jpg' || ext=='JPG' || ext=='JPEG' || ext=='jpeg' || ext=='TIFF' || ext=='tiff'||ext=='TIF' || ext=='tif')
	            		{
	            	
	            		upload_Msg[0].innerHTML="";	
	            		desc_Id[0].innerHTML="";
	            		$scope.allowedExtensions=["PDF","pdf","TIFF","tiff","JPG","jpg","JPEG" ,"jpeg","TIF","tif"];
	            	csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,$scope.functionalityId,$scope.fileUploadCallBack,$scope.policynumber,'Upload File',$scope.allowedExtensions);
	            		}
	            	else
	            		{
	            		$scope.uploadFileList.length=0;
	            		upload_Msg[0].innerHTML="";
	            		desc_Id[0].innerHTML="";
	            		upload_Msg[0].innerHTML="<span class=red-text>Error While Uploading. File extension should be PDF or JPEG or TIFF</span>";
	            		}
	            		}
	            	else
	            		{
	            		$scope.uploadFileList.length=0;
	            		upload_Msg[0].innerHTML="";
	            		desc_Id[0].innerHTML="";
	            		upload_Msg[0].innerHTML="<span class=red-text>Error While Uploading.File size should not be more than 5 MB</span>";
	            		}
	            		}
		
			};
			
	
	            $scope.fileUploadCallBack = function(uploadFileJsonResp, fileId, upload_Msg,message) {
	            	
	            	if(uploadFileJsonResp=="ERROR")
	            	{
	            	
	          	    $scope.upload_Msg[0].innerHTML =  message;
	            	
	            	return false;
	            	}
	            	
	            	else
	            		{
	    	        var fileUploadResJsonObj = angular.fromJson(uploadFileJsonResp);
	    	        if (fileUploadResJsonObj != null &&
	    	            fileUploadResJsonObj != '' && fileUploadResJsonObj != "") {
	    
	    				if(fileUploadResJsonObj.errorCode!=undefined)
	    				{
	    					ajaxHttpFactory.showErrorSuccessMessagePopup("<span class=red-text>Error while uploading file. Please try again.</span>", "errorMessage-popup","submitSuccessAlert");
	    				}
	    				else
	    				{
	    	        	for(var i=0;i<fileUploadResJsonObj.length;i++)
	    	        		{
	    	  
	    	        		if(angular.fromJson(fileUploadResJsonObj[i]).errorCode=="0")
	    	        		{
	    	        			$scope.uploadFileList.length=0;
	    	        			
	    	        			$scope.uploadFileList.push(angular.fromJson(fileUploadResJsonObj[i]));

	       	            if(fileId.length==1)
	       	            	{
	       	            upload_Msg[0].innerHTML =  "<span class=green-text>Document uploaded successfully.</span>";
	       	            	}
	       	            else if(fileId.length>1)
	       	            	{
	       	            upload_Msg[0].innerHTML =  "<span class=green-text>Documents uploaded successfully.</span>";
	       	            	}
	    	        		}
	    	        		else
	    	        		{
	    	        			ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
	    	        		}
	    	        		}
	    	         
	    	           }
	    	            
	    	        } else {
	    	          
	    	            ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup", "submitSuccessAlert");
	    	        }
	    	        
	            		}
	    	        $rootScope.preloaderCheck=false;
	    	    };
	    	    
	    	    $scope.checkBasicFieldValidations = function() {
	    		    if ($scope.errorArray.length > 0) {
	    		        for (var i = 0; i < $scope.errorArray.length; i++) {
	    		            var lengthBfr = $scope.errorArray.length;
	    		            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
	    		            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	    		                errorElement.triggerHandler("blur");
	    		            }
	    		            var lengthAftr = $scope.errorArray.length;
	    		            if (lengthAftr < lengthBfr) {
	    		                i--;
	    		            }
	    		        }
	    		        if ($scope.errorArray.length > 0) {
	    		            $("#" + $scope.errorArray[0]).focus();
	    		            return false;
	    		        } else {
	    		            return true;
	    		        }
	    		    } else {
	    		        return true;
	    		    }
	    		};
	    		
	    		$scope.checkBasicFieldValidationsModal = function() {
	    		    if ($scope.modalErrorArray.length > 0) {
	    		        for (var i = 0; i < $scope.modalErrorArray.length; i++) {
	    		            var lengthBfr = $scope.modalErrorArray.length;
	    		            var errorElement = angular.element(document.querySelector('#' + $scope.modalErrorArray[i]));
	    		            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	    		                errorElement.triggerHandler("blur");
	    		            }
	    		            var lengthAftr = $scope.modalErrorArray.length;
	    		            if (lengthAftr < lengthBfr) {
	    		                i--;
	    		            }
	    		        }
	    		        if ($scope.modalErrorArray.length > 0) {
	    		            $("#" + $scope.modalErrorArray[0]).focus();
	    		            return false;
	    		        } else {
	    		            return true;
	    		        }
	    		    } else {
	    		        return true;
	    		    }
	    		};
	    		
	    		
	    		$scope.OnResetBtn = function(){
	    			$scope.uploadFileList.length=0;
	    			$scope.uploadFileList=[];
	    			angular.element("input[type='file']").val(null);
	    			var m1 = angular.element( document.querySelector( '#file-upload-main_errMsg'));
	    			m1.empty();
	    			var m2 = angular.element( document.querySelector( '#file-upload-main_upText'));
	    			m2.empty();
	    		
	    			var m3= angular.element( document.querySelector( '#file-upload-main1_errMsg'));
	    			m3.empty();
	    			var m4 = angular.element( document.querySelector( '#file-upload-main1_upText'));
	    			m4.empty();
	    		};
	    		
	    		/*$scope.showFile = function(){
	    			if(angular.isDefined($scope.loadCompanyPersonDetails.addressproof.newValue) && $scope.loadCompanyPersonDetails.addressproof.newValue!="")
	    			$scope.fileDiv=true;
	    			else
	    				$scope.fileDiv=false;	
	    			
	    		};*/
	            

	    		
}]);


