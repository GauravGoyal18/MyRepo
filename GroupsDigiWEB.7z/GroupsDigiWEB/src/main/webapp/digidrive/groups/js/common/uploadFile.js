var app=angular.module("groupApp",['csrCommonUtil']);
app.controller("uploadFile",function($scope,csrDocUploadFactory,$rootScope){
	
	alert("insideController");
	$scope.uploadArray={};
	$scope.policynumber=222;
	$scope.errSuccessAlertObj = {};
	
	$scope.upload = function(upId, docType) {
        var desc_Id = angular.element(document
            .querySelector('#' + upId.id+'_errMsg'));
        var upload_Msg = angular.element(document
            .querySelector('#' + upId.id + '_upText'));
            if(upId.files.length != 0){   
        csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,$scope.fileUploadCallBack,$scope.policynumber,'Upload File');
    	}
    };

    
    $scope.fileUploadCallBack = function(uploadFileJsonResp, fileId, upload_Msg) {
        var fileUploadResJsonObj = JSON
            .parse(uploadFileJsonResp);
        alert("fileUploadResJsonObj : "+fileUploadResJsonObj);
        if (fileUploadResJsonObj != null &&
            fileUploadResJsonObj != '') {
            if (upload_Msg[0].id.split("_")[0] == 'UploadFile') {
                $scope.UploadFile.docType = fileUploadResJsonObj[0].docType;
                $scope.UploadFile.documentName = fileUploadResJsonObj[0].docName;
                $scope.UploadFile.docPath = fileUploadResJsonObj[0].encryptedpath;
                $scope.UploadFile.applicationNo = fileUploadResJsonObj[0].custId;
                
            } 
             upload_Msg[0].innerHTML =  "Document uploaded successfully.";
             $rootScope.$broadcast('pageSpinner', false);
        } else {
        	alert("fileUploadResJsonObj");
            $scope.errSuccessAlertObj['status'] = 'ERROR';
            ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", '', $scope.errSuccessAlertObj);
        }
    }; 
});