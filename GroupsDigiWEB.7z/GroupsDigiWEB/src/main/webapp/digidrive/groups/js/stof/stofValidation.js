angular.module('stofValidation',[])
.factory('validiteStofService', function(){
	var errorArray=[];
	var fundDetailsValidation= function(stofDetails)
	{
		if(stofDetails.unitOrAmount=='' || stofDetails.unitOrAmount==undefined )
		{
			errorArray.push('units');
		}
	
		if(stofDetails.fundFromName=='' || stofDetails.fundFromName==undefined)
		{
			errorArray.push('frm-fund');
		}
		
		if(stofDetails.fundToName=='' || stofDetails.fundToName==undefined)
		{
			errorArray.push('to-fund');
			
		}
	
		if(stofDetails.frequency=='' ||  stofDetails.frequency==undefined)
		{
			errorArray.push('Frequency');
		}
		if(stofDetails.numberOfTransfer=='' || stofDetails.numberOfTransfer==undefined)
		{
			errorArray.push('transfers');
		}
		return errorArray;
	}
	
	
	
	return {
		validateFundDetails: function(stofDetails){
 		      return fundDetailsValidation(stofDetails);
 		},
 		
	};	
	
	
});