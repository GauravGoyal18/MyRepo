var app = angular.module('groupApp', [ 'ajaxUtil', 'ui.materialize','uiValidations','groupCommonUtil','validationService','webcam','otpModalApp']);
app.controller('digitalLifeVerification',['$rootScope','$scope','$location','ajaxHttpFactory','csrDocUploadFactory','$window','validateFieldService','$filter','$http',function($rootScope, $scope, $location, ajaxHttpFactory,csrDocUploadFactory,$window,validateFieldService,$filter,$http) {
	
	
	$scope.showForm=false;
	$scope.digitalLifeVerify={};
	$scope.prepop=true;
	$scope.showFrontView=true;
	$scope.uploadArray={};
	$scope.uploadArray.mainFile=[];
	$scope.digitalLifeVerify = {};
	$scope.digitalLifeVerify.uploadFileList=[];
	$scope.uploadArray.mainFile=[];
	$scope.functionalityId='41';
	$scope.openonSubmitOpenAlertId=false;
		
	// transition on load function starts	
	
	 $scope.DocumentRequired = [
	                              {
	                                   "id" : "panCard",
	                                   "value" : " 1.PAN Card"
	                               },{
	                                   "id" : "passport",
	                                   "value" : "2.Passport"
	                               },{
	                                   "id" : "voterId",
	                                   "value" : "3.Voter 	Id"
	                               },
	                               {
	                                   "id" : "license",
	                                   "value" : "4.Driving license"
	                               },
	                               {
	                                   "id" : "adharCard",
	                                   "value" : "5.Adhar Card"
	                               }
	                           ]
	
	$scope.linkRedirectionUrlWdgt = function() {
	    var url = $location.absUrl();
	    ajaxHttpFactory.linkRedirectionUrlWdgt(url, '&otpType=transactionalOTP');

	};
	
	$scope.upload = function(upId, docType) {
		$rootScope.preloaderCheck=true;
        var desc_Id = angular.element(document
            .querySelector('#' + upId.id+'_errMsg'));
        var upload_Msg = angular.element(document
            .querySelector('#' + upId.id + '_upText'));
            if(upId.files.length != 0){   
            	
            	//alert("upId.files"+upId.files+", desc_Id "+desc_Id+", upload_Msg"+upload_Msg+", " );
            	upload_Msg[0].innerHTML="";	
            	desc_Id[0].innerHTML="";
            	csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,$scope.functionalityId,$scope.fileUploadCallBack,$scope.policynumber,'Upload File',$scope.allowedExtensions);
            }
		};
		
		$scope.fileUploadCallBack = function(uploadFileJsonResp, fileId, upload_Msg,message) {
        	
        	if(uploadFileJsonResp=="ERROR")
        	{
        		
        		//$rootScope.check = true;
      	    //  $scope.message = "Invalid file format.";
      	      
      	    upload_Msg[0].innerHTML =  message;
      	  $rootScope.preloaderCheck=false;
        		
        		//ajaxHttpFactory.showErrorSuccessMessagePopup(message, "errorMessage-popup","submitSuccessAlert");
        	return false;
        	}
        	
        	else
        		{
	        var fileUploadResJsonObj = angular.fromJson(uploadFileJsonResp);
	       // alert(fileUploadResJsonObj);
	        if (fileUploadResJsonObj != null &&
	            fileUploadResJsonObj != '' && fileUploadResJsonObj != "") {

				if(fileUploadResJsonObj.errorCode!=undefined)
				{
					    	        			
					  ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
					  var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
					  m.empty();
					  m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
				
				}
				else
				{
	        	for(var i=0;i<fileUploadResJsonObj.length;i++)
	        		{
	  
	        		if(angular.fromJson(fileUploadResJsonObj[i]).errorCode=="0")
	        		{
	        	   $scope.digitalLifeVerify.uploadFileList.push(angular.fromJson(fileUploadResJsonObj[i]));

   	            if(fileId.length==1)
   	            	{
   	             upload_Msg[0].innerHTML =  "Document uploaded successfully.";
   	            	}
   	            else if(fileId.length>1)
   	            	{
   	            	upload_Msg[0].innerHTML =  "Documents uploaded successfully.";
   	            	}
   	             //$rootScope.$broadcast('pageSpinner', false);
	        		}
	        		else
	        		{
	        			ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
	        			var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
	  				  	m.empty();
	  				  	m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
	        		}
	        		}
	         
	           }
	            
	        } else {
	           // $scope.errSuccessAlertObj['status'] = 'ERROR';
	            ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup", "submitSuccessAlert");
	            var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
				  	m.empty();
				  	m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
	        }
	        
        		}
	        $rootScope.preloaderCheck=false;
	    };
	
	var getDetailsOnLoad = function() {
		$scope.preloaderCheck=true;
        var ajaxurl = $location.absUrl();
			ajaxHttpFactory.getJsonData('getDigiLifeVeriDetailsOnLoad',ajaxurl,'','GET').then(
                   function successCallback(response) {
					$rootScope.preloaderCheck = false;
					
					 if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert"))
			  			{
						 $scope.responseData = response.data;
							if($scope.responseData=="success")
            				{
            				
            				  $scope.linkRedirectionUrlWdgt();
            				  
            				  $rootScope.$on('otpHandShake', function(event, args) {
            		                if (args != null && args != undefined) {
            		                	$scope.getPrePopulateData();
            		                	/*$scope.showForm=true;
            		                	$rootScope.preloaderCheck=false;*/
            		    				
            		    				
            		    				
            		                }
            		            });
            				
            				}
			  			}
					
               }
			);
	};
	
	getDetailsOnLoad();	
	// transition on load function starts
	
	
	
	
	//WebCAm code starts
	var _video = null,
	 patData = null;
	 
	$scope.patOpts = {x: 0, y: 0, w: 25, h: 25};

	 $scope.channel = {};
			$scope.usable = true; //for disabling take pic and submit button
	    $scope.webcamError = false;
	    $scope.onError = function (err) {
	        $scope.$apply(
	            function() {
	                $scope.webcamError = err;

	                $scope.usable = !$scope.usable; // for disabling take pic and submit button
	                       }
	        );
	    };
		
	 $scope.onSuccess = function () {
	        // The video element contains the captured camera data
	        _video = $scope.channel.video;
	        $scope.$apply(function() {
	            $scope.patOpts.w = _video.width;
	            $scope.patOpts.h = _video.height;
	            //$scope.showDemos = true;
	        });
	    };
		
	 $scope.onStream = function (stream) {
	        // You could do something manually with the stream.
	    };
		
		 var getVideoData = function getVideoData(x, y, w, h) {
	        var hiddenCanvas = document.createElement('canvas');
	        hiddenCanvas.width = _video.width;
	        hiddenCanvas.height = _video.height;
	        var ctx = hiddenCanvas.getContext('2d');
	        ctx.drawImage(_video, 0, 0, _video.width, _video.height);
	        return ctx.getImageData(x, y, w, h);
	    };

		$scope.makeSnapshot1 = function() {
	        if (_video) {
	            var patCanvas = document.querySelector('#sideSnapshot');
	            sideSnapshot
	            if (!patCanvas) return;

	            patCanvas.width = _video.width;
	            patCanvas.height = _video.height;
	            var ctxPat = patCanvas.getContext('2d');

	            var idata = getVideoData($scope.patOpts.x, $scope.patOpts.y, $scope.patOpts.w, $scope.patOpts.h);
	            ctxPat.putImageData(idata, 0, 0);

	            sideSelfieSendSnapshotToServer(patCanvas.toDataURL());

	            patData = idata;
	        }
	    };
	    
	    $scope.makeSnapshot = function() {
	        if (_video) {
	            var patCanvas = document.querySelector('#snapshot');
	            sideSnapshot
	            if (!patCanvas) return;

	            patCanvas.width = _video.width;
	            patCanvas.height = _video.height;
	            var ctxPat = patCanvas.getContext('2d');

	            var idata = getVideoData($scope.patOpts.x, $scope.patOpts.y, $scope.patOpts.w, $scope.patOpts.h);
	            ctxPat.putImageData(idata, 0, 0);

	            sendSnapshotToServer(patCanvas.toDataURL());

	            patData = idata;
	        }
	    };
	    //WEBCAM ImplementationCode Starts
	    
	    /**
	     * Redirect the browser to the URL given.
	     * Used to download the image by passing a dataURL string
	     */
	    $scope.downloadSnapshot = function downloadSnapshot(dataURL) {
	        window.location.href = dataURL;
	    };
			
			   /**
		     * This function could be used to send the image data
		     * to a backend server that expects base64 encoded images.
		     *
		     * In this example, we simply store it in the scope for display.
		     */
	    var sendSnapshotToServer = function sendSnapshotToServer(imgBase64) {
	    	$scope.snapshotData = imgBase64;
	    };
	    
	    var sideSelfieSendSnapshotToServer = function sendSnapshotToServer(imgBase64) {
	    	$scope.sideSnapshotData = imgBase64;
	    };

	  //WebCAm code starts
	    
	    
	    
	    // Date Function starts
	    
	    var currentTime = new Date();
	    $scope.currentTime = currentTime;
	    $scope.digitalLifeVerify.createdDate=$scope.currentTime;
	    $scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	    $scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	    $scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
	    $scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

	    $scope.today = '';
	    $scope.clear = 'Clear';
	    $scope.close = 'Done';
	    var days = 100;
	    $scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
	    $scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
	    $scope.onStart = function () {
	       
	    };
	    $scope.onRender = function () {
	    };
	    $scope.onOpen = function () {   
	    };
	    $scope.onClose = function () {
	    };
	    $scope.onStop = function () {   
	    };
	    
	    $scope.checkDate = function(currentElement, errorMsgElement) {
			$scope.sAClaimIntimation.beneficiary.appointeeFName="";
			$scope.sAClaimIntimation.beneficiary.appointeeLName="";
			$scope.sAClaimIntimation.beneficiary.appointeeRelation="";
			if (angular.element(document.getElementById(currentElement))
					.val() == "") {
				angular.element(document.getElementById(currentElement))
						.addClass('invalid1');
				angular.element(document.getElementById(errorMsgElement))
						.css('visibility', 'visible');
				return false;
			} else {
				if (currentElement == "benefdateOfBirth") {
					$scope.showAge = true;
				} 
				angular.element(document.getElementById(currentElement))
						.removeClass('invalid1');
				angular.element(document.getElementById(errorMsgElement))
						.css('visibility', 'hidden');
				return true;
			}
		}
	 // Date Function ends
	    
	    $scope.getPrePopulateData=function(){			
			$rootScope.preloaderCheck=true;
			var ajaxurl = $location.absUrl();
			return ajaxHttpFactory.getJsonData("getPrePopulateData",ajaxurl)
			.then(function(bizRes){	
				
				if(!ajaxHttpFactory.handleIPruException(bizRes.data, "errorMessage-popup", "exceptionAlert")){
		     
			                	$scope.responseData = bizRes.data;
			                	$scope.digitalLifeVerify.polholName=$scope.responseData.firstname;
			                	$scope.digitalLifeVerify.policyid=$scope.responseData.policyid;
			                	//$scope.digitalLifeVerify.annuPolicyNo=$scope.responseData.policyid;
			                	$scope.digitalLifeVerify.trustname=$scope.responseData.trustname;
			                	$scope.digitalLifeVerify.phonemobile=$scope.responseData.phonemobile;			                	
			                	$scope.showForm=true;
			                	$rootScope.preloaderCheck=false;
			              
				}
										
					
			
			},
			function(errResponse){
				$rootScope.preloaderCheck=false;
				if(ajaxHttpFactory.handleIPruException(bizRes.data, "errorMessage-popup", "exceptionAlert")){
					
				}
			});
	};
	
	$scope.onClickFrontView=function()
	{
		$scope.showFrontView=true;
	}
	$scope.onClickSideView=function()
	{
		$scope.showFrontView=false;
	}
	
	$scope.submitData=function()
	{
		if($scope.digitalLifeVerify != null && angular.isDefined($scope.digitalLifeVerify)){
			
//			alert("$scope.submitJson.selectedMenu.requestMenuName  :"+ $scope.submitJson.selectedMenu.requestMenuName+":");
//			alert("$scope.submitJson.detailOfRequest  :"+$scope.submitJson.detailOfRequest+":");
			
				if($scope.checkBasicFieldValidations()){
					if($rootScope.responseData.dateofbirth.split(" ")[0]==$scope.digitalLifeVerify.dateOfBirth && $rootScope.responseData.panno==$scope.digitalLifeVerify.panNumber)
                    {

						if($scope.digitalLifeVerify.uploadFileList.length>0)
							{
							$scope.digitalLifeVerify.sideSnapShot=$scope.sideSnapshotData;
							$scope.digitalLifeVerify.snapShot=$scope.snapshotData;
							var submitJsonString = angular.toJson($scope.digitalLifeVerify);
							var ajaxurl = $location.absUrl();
							//$rootScope.preloaderCheck=true;
							ajaxHttpFactory.postJsonDataSuccessFailure(submitJsonString,"POST",ajaxurl,"submitDigiLifeVerifiData",$scope.submitSuccessMethod,$scope.submitFailureMethod);
							
							}
						else
							{
							ajaxHttpFactory.showErrorSuccessMessagePopup("Please upload file. ","errorMessage-popup", "fileErrorAlert");
							}
						
                    }
                    else
                    {
                    ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill Valid Date Of Birth and Pan Number", "errorMessage-popup", "digiLifeVerificationAlert");
                    }
				}
				else {
					$rootScope.preloaderCheck=false;
				}
			}
	}
	
	$scope.submitSuccessMethod=function(response){
		$rootScope.preloaderCheck=false;
    	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
    	if (response != null && response != "null") {	
    		$scope.openonSubmitOpenAlertId=true;
    		$scope.action="success";
    		$scope.message = "Your request submitted successfully with request Id "+response;	
    		}
    	}
	}
	    
}]);
