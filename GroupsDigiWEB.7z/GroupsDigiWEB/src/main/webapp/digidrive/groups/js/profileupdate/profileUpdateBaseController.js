var app = angular.module('groupApp', ['ajaxUtil','validationService','uiValidations','ui.materialize','ngRoute','groupCommonUtil']);


/*var profilepath="digidrive/groups/html/profileupdate";
app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "www.iciciprulife.com",
    })
    .when("/companyAddressChange", {
    	templateUrl : profilepath+'/companyAddressChange.html',
    	controller  : 'profileCompanyAddressCtrl',
    })
    .when("/contactPersonChange", {
        templateUrl :profilepath+'/contactPersonChange.html',
        	controller  : 'profileContactPersonCtrl',
    })
    .when("/authorizedSignatoryChange", {
        templateUrl : profilepath+'/authorizedSignatoryChange.html',
        controller : 'profileAuthorizedSigChangeCtrl',
    });
   
});*/


var profilepath="digidrive/groups/html/profileupdate";
app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "www.iciciprulife.com",
    })
    .when("/companyAddressChange", {
    	templateUrl : profilepath+'/CompanyAddressChangeModal.html',
    	controller  : 'profileCompanyAddressCtrl',
    })
    .when("/contactPersonChange", {
        templateUrl :profilepath+'/contactPersonChangeModal.html',
        	controller  : 'profileContactPersonCtrl',
    })
    .when("/authorizedSignatoryChange", {
        templateUrl : profilepath+'/authorizedSignatoryChangeModal.html',
        controller : 'profileAuthorizedSigChangeCtrl',
    })
    
    .when("/memberAddressTraditional", {
        templateUrl : profilepath+'/memberAddressTraditionalModel.html',
        controller : 'memberAddressTraditionalCtrl',
    });
    
    
   
});

app.controller('profileUpdateBaseController',['$rootScope','$scope','$location','ajaxHttpFactory','validateFieldService','$window','$timeout',function($rootScope, $scope,$location,ajaxHttpFactory,validateFieldService,$window,$timeout){
	
	$scope.showCompanyAddress=false;
	$rootScope.preloaderCheck=true;
	$scope.errorArray=[];
	$scope.absUrl =window.location.origin + window.location.pathname+window.location.search;
	$scope.loadProfileUpdateDetails={};
	$scope.onloadFlagCompanyAddress=false;
	$scope.onloadFlagTraditionalProfile=false;
	$scope.manuList=[];
	$scope.companyAddressChange='companyAddressChange';
	$scope.memberDetailsChange='memberDetailsChange';
	$scope.memberAddressTraditional='memberAddressTraditional';
	$scope.showCompanyAddrDiv=function(){
		$scope.showCompanyAddress=false;
		
		

	};
	

var loadProfileUpdateAccessMatrix = function () { 
	
	return ajaxHttpFactory.getJsonData("loadProfileUpdateAccessMatrix",$scope.absUrl)
	.then(function(response) {
		$rootScope.preloaderCheck=false;
		if (response != null && response != "null") {
			var responseData = response.data;
			$scope.loadProfileUpdateDetails = responseData.resultMap;
		
	
			if(!angular.isUndefined($scope.loadProfileUpdateDetails.companyAddressChange.rdComponent) && $scope.companyAddressChange == $scope.loadProfileUpdateDetails.companyAddressChange.rdComponent)
				{
				$timeout(function() {
					angular.element('#companyAddressChange').trigger('click');
		
				},100,true);
				}
			if(!angular.isUndefined($scope.loadProfileUpdateDetails.memberDetailsChange.rdComponent) && $scope.memberDetailsChange==$scope.loadProfileUpdateDetails.memberDetailsChange.rdComponent)
			{
			$timeout(function() {
				angular.element('#companyAddressChange').trigger('click');
			
			},100,true);
			}
		if((!angular.isUndefined($scope.loadProfileUpdateDetails.memberAddressTraditional.rdComponent) || !""==$scope.loadProfileUpdateDetails.memberAddressTraditional.rdComponent ) && $scope.memberAddressTraditional ==$scope.loadProfileUpdateDetails.memberAddressTraditional.rdComponent)
				{
				$timeout(function() {
					angular.element('#memberAddressTraditional').trigger('click');
		
				},100,true);
				}
				
		
		}
	},
	function(errResponse) {
		$rootScope.preloaderCheck=false;
		console.error('Error while fetching profile details.');

	});

};
loadProfileUpdateAccessMatrix();



$scope.validateFields = function(name,action)  
{
  
	$scope.id=name;
	$scope.action=action;
	$scope.result = validateFieldService.fieldValidate($scope.id,$scope.action,$scope.loadProfileUpdateDetails);
	return $scope.result;
	
};


$scope.onLeftMenuClick = function ( path ) {
	  $location.path( path );
	};
	

/*$rootScope.$on('$includeContentLoaded', function (event) {
	    // it has loaded!

	if($scope.onloadFlag==true){
		
		$timeout(function() {
			angular.element('#companyAddressChange').trigger('click');
			$scope.onloadFlag=false;
		},100,true);
		}*/
		

}]);












