var app = angular.module('groupApp',['ajaxUtil','switchValidation','ui.materialize','uiValidations']);
//app.controller('switchController',function($rootScope, $scope,$location,ajaxHttpFactory,$http, $q, $interval, $timeout,validiteSwitchService){
app.controller("switchController",['$rootScope','$scope','$location','ajaxHttpFactory','$http','$q','$interval','$timeout','validiteSwitchService',
                                   function($rootScope, $scope,$location,ajaxHttpFactory,$http, $q, $interval, $timeout,validiteSwitchService){
	
	$rootScope.preloaderCheck=true;
	//alert("2");
	$scope.policyDetails = {};
	$scope.policy = '';
	$scope.role = '';
	$scope.employeeId = '';
	var ajaxurl = $location.absUrl();
	$scope.fundNamesResponse=[];
	$scope.switchFund={};
	$scope.errorArray = [];
	$scope.switchFund.fromFund='';
	$scope.switchFund.switchFundDetails=[];
	$scope.switchFund.totalFundSwitchValue = 0;
	//$scope.switchFund.isAgreedCheck = false;
	var d1 = '';
	var d2 = '';
	$scope.mandatCheck =false;
	
	//show hide from fund to fund block
	$scope.showFromFundToFundSwitchBlock = false;
	
	//show hide switch table block
	$scope.showFromFundToFundTableBlock = false;
	
	//show hide Submit Block
	$scope.showSubmitBlock = false;
	
	//show hide Terms and Condition Block
	//$scope.showTermsandConditionBlock = false;
	
	var initialSetUp = function () { 
		//$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("initialSetUp",ajaxurl)
		.then(function(response) {
			
			if(!ajaxHttpFactory.handleIPruException(angular.toJson(response.data), "errorMessage-popup")) {
				if (response != null && response != "null") {
					var responseData = response.data;
					//$scope.results = responseData.resultMap;
					//$rootScope.preloaderCheck=false;
					
					
					$scope.switchFund.productSwitchAmount = responseData.productSwitchAmount;
					//To fund
					$scope.switchFund.activeApplicableToFundList = responseData.activeApplicableToFundList;
					$scope.switchFund.activeApplicableToFundMap = responseData.activeApplicableToFundMap;
					
					$scope.switchFund.fundMasterList = responseData.fundMasterList;
					
					$scope.employeeId = responseData.userVO.empId;
					displayData();
				}
			}
			else{
				$rootScope.preloaderCheck=false;
			}
		},
		function(errResponse) {
			//$rootScope.preloaderCheck=false;
			console.error('Error while fetching intial setup details.');

		});

	};
	
	initialSetUp();
	
	//$scope.switchFund.productSwitchAmount = angular.fromJson(productSwitchAmount);
	
	var displayData = function () { 	
		var ajaxurl1 = ajaxurl + "&_eventId=" + "fetchFundNavUnit";
		/*var ajaxurl2 = ajaxurl + "&_eventId=" + "fetchReturnsInception";*/
		
		d1 = $http({method: 'GET', url: ajaxurl1})
		 		.then(function(response) {
		 			//alert("d1");
                     if (typeof response.data === 'object') {
                            return response.data;
                      } else {
                            // invalid response
                            return $q.reject(response.data);
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject(response.data);
                    });
		
		
		/*d2 = $http({method: 'GET', url: ajaxurl2})
			 .then(function(response) {
				 //alert("d2");
                        if (typeof response.data === 'object') {
                            return response.data;
                            
                        } else {
                            // invalid response
                            return $q.reject(response.data);
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject(response.data);
                    });*/
	
		/*$q.all([d1, d2])
    	.then(function(response){*/
    		$q.all([d1])
        	.then(function(response){
    	//alert("hello1");
	    if(!ajaxHttpFactory.handleIPruException(angular.toJson(response[0]), "errorMessage-popup")) {
	        var policyDetails = '';
	        
	      
	        /*if (response[0] != null && response[1] != null){*/
	        if (response[0] != null){
	        	//Got response from both webservice
	        	/*if(response[1].fundDetailPOList != undefined && response[1].fundDetailPOList != null)
	        	{
	        		//alert("both");
	        		policyDetails = response[1];
	    			
	        	}*/
	        	
	        	 if(response[0].fundDetailPOList != undefined && response[0].fundDetailPOList != null){
	        		//alert("single");
	        		policyDetails = response[0];
	        	}
	        	
	        	//spinner hide
	        	$rootScope.preloaderCheck=false;
	        	
	        	//to display webservice response grid in front end
	        	$scope.fundDetailsList = policyDetails.fundDetailPOList;
				$scope.policy = policyDetails.policy;
				
				
				/*$scope.fromFund =  policyDetails.activeApplicableFromFundJsonString;
				for(var i=0; i<$scope.fundDetailsList.length; i++)
				{
					$scope.fund = {
						fundNames : $scope.fundDetailsList[i].funddesc,
					};
					$scope.fundNamesResponse.push($scope.fund);
				}
	        */
	        	
	        
	        		
	        	//$scope.message = validiteSwitchService.validateFundAvailable(policyDetails.activeFromFund, angular.fromJson(activeApplicableToFundJsonString));
				//Validate from and to fund
				$scope.message = validiteSwitchService.validateFundAvailable(policyDetails.activeFromFund, $scope.switchFund.activeApplicableToFundList);
	        	if ($scope.message == "") {
	        		
	        		$scope.fromFund = policyDetails.activeFromFund;
	        		//$scope.toFund =  angular.fromJson(activeApplicableToFundJsonString);
	        		//$scope.toFund =  angular.fromJson(activeApplicableToFundJsonStringMap);
	        		$scope.toFund =  $scope.switchFund.activeApplicableToFundMap;
	        		
	        	}
	        	else
	        	{
	        		//alert($scope.message);
	        		$scope.hideSubmitBlock = true;
	        		$scope.mandatCheck = true;
	        		
	        	}
	        }
	    	} 
    	else{
			$rootScope.preloaderCheck=false;
		}

			
    });//then
	
	}
	
	
	$scope.checkBasicFieldValidations = function() {
	    if ($scope.errorArray.length > 0) {
	        for (var i = 0; i < $scope.errorArray.length; i++) {
	            var lengthBfr = $scope.errorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = $scope.errorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	        if ($scope.errorArray.length > 0) {
	            $("#" + $scope.errorArray[0]).focus();
	            return false;
	        } else {
	            return true;
	        }
	    } else {
	        return true;
	    }
	};
	
	$scope.addSwitchSkill = function() {
		
		//alert("addSwitchSkill32");
		
		$scope.message = validiteSwitchService.validateFundTransaction($scope.switchFund.switchType,$scope.switchFund.fromFund, $scope.switchFund.toFund, $scope.switchFund.amountOrUnitValue,$scope.switchFund.switchFundDetails,$scope.switchFund.fromFundCode,$scope.switchFund.toFundCode,$scope.switchFund.fundMasterList);
		//$scope.message = ""
		if ($scope.checkBasicFieldValidations())
			{	
				if($scope.message == "") {
	
				var totalAmountWithAddedAmount = 0;
				//var totalFromUnit = 0;
				var fromAmount = 0;
				var fromAmountDisplay = 0;
				var fromUnit = 0;
				var fromNAV = 0;
				var toAmount = 0;
				var toUnit = 0;
				var toNAV = 0;
				var transferNAV = 0;
				/*toAmount = 0;
				toUnit = 0;
				toNAV = 10;*/
				
				//var switchJson = angular.toJson($scope.switchFund);
				
				//fetch NAV to calculate amount when switch type is unit
				fromNAV =  $scope.fetchNAVFromFund($scope.switchFund.fromFund);
				
				//fetch total Unit Available in From Fund
				//totalFromUnit =  $scope.fetchUnitFromFund($scope.switchFund.fromFund);
				
				
				if($scope.switchFund.switchType == "amount")
				{
					fromAmount = $scope.switchFund.amountOrUnitValue;
					toAmount = $scope.switchFund.amountOrUnitValue;
					//to display in front end
					fromAmountDisplay = $scope.switchFund.amountOrUnitValue;
					//transferUnit = fromAmount/fromNAV;
					//Round to 3 decimal places
					//fromUnit = fromUnit.toFixed(3);
				}else if($scope.switchFund.switchType == "Units"){
					fromUnit = Number($scope.switchFund.amountOrUnitValue);
					toUnit = Number($scope.switchFund.amountOrUnitValue);
					//used for calculations
					fromAmount = Number(fromUnit * fromNAV);
					//Round to 2 decimal places
					fromAmount = fromAmount.toFixed(2);
					//to display in front end
					fromAmountDisplay = fromAmount;
				}
				//Fetch Total Amount Available in Product ---  From Webservice
				var totalFundValue = $scope.fetchTotalFundValue().toFixed(2);
				
				//Fetch Total Amount Available in From Fund
				var totalAmount = $scope.fetchAmountFromFund($scope.switchFund.fromFund);
				
				//Total Amount Invested in From Fund
				var totalAmountInvested = $scope.fetchTotalAmountInvested($scope.switchFund.fromFund);
				
				
				totalAmountWithAddedAmount = totalAmountInvested + Number(fromAmount);
				
				
				
				
				if(totalAmount >= totalAmountWithAddedAmount){
									
					//create object and assign values
					var  switchDetail= new Object();
					switchDetail.fromFundName = $scope.switchFund.fromFund;//to display on screen
					switchDetail.toFundName = $scope.switchFund.toFund;//to display on screen
					switchDetail.unitsOrAmount = $scope.switchFund.amountOrUnitValue;
					//switchDetail.fromAmount = $scope.switchFund.fromAmount;
					
					switchDetail.fromFundCode = $scope.switchFund.fromFundCode;
					switchDetail.toFundCode = $scope.switchFund.toFundCode;
					switchDetail.switchType = $scope.switchFund.switchType;
					switchDetail.fromNAV = fromNAV;
					switchDetail.fromUnit = fromUnit;
					switchDetail.fromAmount = fromAmount;
					switchDetail.fromAmountDisplay = fromAmountDisplay;
					switchDetail.toUnit = toUnit;
					switchDetail.toAmount = toAmount;
					
					
					
					//switchDetail.totalFundValue = totalFundValue;
					//switchDetail.totalFundSwitchValue = totalFundSwitchValue;
					
					
			/*		switchDetail.unitsOrAmount = $scope.switchFund.amountOrUnitValue;
					
					switchDetail.transferNAV = fromNAV;
					switchDetail.transferUnit = transferUnit;
					switchDetail.transferAmount = transferAmount;
					
					
					
					switchDetail.toNAV = toNAV;*/
					//alert(JSON.stringify(switchDetail));
					
				/*	if($scope.switchFund.switchType == "Units"){
						switchDetail.fromAmount = 0;
					}*/
					
					$scope.switchFund.switchFundDetails.push(switchDetail);
					
					
					/*//Pre fund Details - Start
					var  switchPreDetail= new Object();
					switchPreDetail.fundCode = $scope.switchFund.fromFundCode;
					switchPreDetail.fundNAV = $scope.switchFund.fromFundNAV;
					switchPreDetail.fundNAVEffectiveDate = $scope.switchFund.fundNAVEffectiveDate;
					switchPreDetail.preFundUnit = $scope.switchFund.preFundUnit;
					switchPreDetail.preFundAmount = $scope.switchFund.preFundAmount;
					$scope.switchFund.switchPreFundDetails.push(switchPreDetail);
					//Pre fund Details - End
	*/				
					$scope.switchFund.totalFundValue = totalFundValue;
					$scope.switchFund.totalFundSwitchValue = Number($scope.switchFund.totalFundSwitchValue) + Number(fromAmount);
					$scope.switchFund.totalFundSwitchValue = Number($scope.switchFund.totalFundSwitchValue).toFixed(2);
			
					$scope.switchFund.fromFund = '';
					$scope.switchFund.toFund = '';
					//$scope.switchFund.switchType = '';
					$scope.switchFund.amountOrUnitValue = '';
					
					
				
					
					//Disable switch type once a record is added
					$scope.disableSwitchType = true;
					//$scope.showFromFundToFundTableSubmitBlock = true;
					$scope.showFromFundToFundTableBlock = true;
					
					//Show Terms and Condition Block
					//$scope.showTermsandConditionBlock = true;
					
					//Show submit Button
					$scope.showSubmitBlock = true;
				}
				else{
					//alert("Cannot add");
					
					//ajaxHttpFactory.showErrorSuccessMessagePopup("Cannot add.", "errorMessage-popup","submitSuccessAlert");
					$scope.mandatCheck = true;
					$scope.message = "Cannot Switch!!! No sufficient Fund ";
				}
			}
			else
			{
				$scope.mandatCheck = true;
			}
		}
		else
		{
			$scope.mandatCheck = true;
			$scope.message = "Cannot Switch!!! Errors exist ";
		}
	};
	
	$scope.fetchTotalAmountInvested = function(fromFund) {
		//alert("fetchTotalAmountInvested");
		
		var total = 0;
		
		for(var i = 0; i < $scope.switchFund.switchFundDetails.length; i++)
		{
			if($scope.switchFund.switchFundDetails[i].fromFundName == fromFund){
				total = total +  Number($scope.switchFund.switchFundDetails[i].fromAmount);
			}
		}
		return total;
	};
	
/*	$scope.fetchLeftAmountUnit = function(fromFund) {
		alert("fetchLeftAmountUnit");
		
		var total = 0;
		
		for(var i = 0; i < $scope.switchFund.switchFundDetails.length; i++)
		{
			if($scope.switchFund.switchFundDetails[i].fromFundName == fromFund){
				total = total +  Number($scope.switchFund.switchFundDetails[i].fromAmount);
			}
		}
		return total;
	};
	*/
	
	$scope.fetchNAVFromFund = function(fromFund) {
		//alert("fetchNAVFromFund");
		
		for(var i = 0; i< $scope.fundDetailsList.length; i++)
		{
			if($scope.fundDetailsList[i].funddesc.trim() == fromFund)
				return $scope.fundDetailsList[i].navValue;
		}
	};
	
/*	$scope.fetchUnitFromFund = function(fromFund) {
		//alert("fetchNAVFromFund");
		
		for(var i = 0; i< $scope.fundDetailsList.length; i++)
		{
			if($scope.fundDetailsList[i].funddesc == fromFund)
				return $scope.fundDetailsList[i].units;
		}
	};*/
	
	$scope.fetchAmountFromFund = function(fromFund) {
		//alert("fetchAmountFromFund");
		
		
		for(var i = 0; i< $scope.fundDetailsList.length; i++)
		{
			if($scope.fundDetailsList[i].funddesc.trim() == fromFund)
				return $scope.fundDetailsList[i].totalAmount;
		}
	};
	
	
	$scope.fetchTotalFundValue = function() {
		var total = 0;
		
		for(var i = 0; i < $scope.fundDetailsList.length; i++)
		{
				total = total +  Number($scope.fundDetailsList[i].totalAmount);
		}
		return total;
		
	};
	
	$scope.okAlert = function() {
		$scope.mandatCheck = false;
	};

	
	
	
	$scope.deleteSwitchSkill = function(index) {
		
		$scope.switchFund.totalFundSwitchValue -= Number($scope.switchFund.switchFundDetails[index].fromAmount);
		//$scope.switchFund.totalFundSwitchValue.toFixed(2);
		$scope.switchFund.totalFundSwitchValue = $scope.switchFund.totalFundSwitchValue.toFixed(2);
		$scope.switchFund.switchFundDetails.splice(index, 1);
		
		//Enable switch type when no records in switchFundDetails
		if($scope.switchFund.switchFundDetails.length == 0){
			$scope.switchFund.totalFundSwitchValue = 0;
			$scope.disableSwitchType = false;
			$scope.showFromFundToFundTableBlock = false;
			$scope.showSubmitBlock = false;
			//$scope.showTermsandConditionBlock = false;
			
		}
	};
	

	
	
	$scope.submitSwitchRequest = function() {
		//alert("submitSwitchRequest");
		$rootScope.preloaderCheck=true;
		
		$scope.message = validiteSwitchService.validateSwitch($scope.switchFund);
		//$scope.message = "";
		if ($scope.message == "") {
			var switchJson = angular.toJson($scope.switchFund);
			
			var ajaxurl = $location.absUrl();
	
			ajaxHttpFactory.postJsonDataSuccessFailure(switchJson, "POST", ajaxurl,"SubmitSwitch", $scope.successMethod,$scope.failureMethod);
		}else {
			//alert($scope.message);
			//ajaxHttpFactory.showErrorSuccessMessagePopup($scope.message);
			$scope.mandatCheck = true;
			$rootScope.preloaderCheck=false;
		}
		
		
	};
	
	$scope.successMethod=function(response)
	{
		
		if (response != null && response != "null"){
			if(!ajaxHttpFactory.handleIPruException(response, "", "switchAlert")){
				//hide spinner
				$rootScope.preloaderCheck=false;
				
				if(response.resultMap  != null && response.resultMap != "null")
				
				ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. Your transaction id is "+response.resultMap.switchTransactionId +  " and Switch will be executed on " + response.resultMap.switchExecutionDate + "."  ,"errorMessage-popup", "SwitchAlert","SUCCESS");
			}
		//redirect
		}
	};
	
	$scope.failureMethod=function(response){
		
		
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "switchAlert")){
		
			ajaxHttpFactory.showErrorSuccessMessagePopup("Some Error Occured : ","errorMessage-popup", "SwitchAlert");
			
		}
	};
	/*
	$scope.clickAgreed = function() {
		$scope.switchFund.isAgreedCheck = !$scope.switchFund.isAgreedCheck;
	};*/
	
/*	$scope.fetchFromFund = function() {
		//alert("fetchFromFund");
		
		var ajaxurl = $location.absUrl();

		return ajaxHttpFactory.getJsonData("fetchFromFund",ajaxurl)
		.then(function(response) {

			if (response != null && response != "null") {
				
				var responseData = response.data;
				//$scope.results = responseData.resultMap;
			}
		},
		function(errResponse) {
			console.error('Error while fetching profile details.');

		});
	};*/
	

/*	$scope.onclickEditbtn = function(id)    //On click of Edit Button
	{
     
		//alert("Edit");
		//$scope.validateFields(id,'enable');
		$scope.enable=false;
	};*/
	
	
	//When switch type is changed show from fund and to fund block
	$scope.onChangeSwitchType = function()    
	{
		$scope.showFromFundToFundSwitchBlock = true;
	};
	
	$scope.setToFundCode = function(toFund) {
		  var obj = $scope.switchFund.activeApplicableToFundMap;
		  angular.forEach(obj,function(value, key) {
				
				if(key == toFund)
				{
					$scope.switchFund.toFundCode = value.fundCode;
				}
			});
	};
	
	$scope.setFromFundCode = function(fromFund) {
		
		for(var i = 0; i< $scope.fundDetailsList.length; i++)
		{
			if($scope.fundDetailsList[i].funddesc.trim() == fromFund)
				//return $scope.fundDetailsList[i].fundcode;
				$scope.switchFund.fromFundCode = $scope.fundDetailsList[i].fundcode;
		}
	};
	
}]);
	

