var app = angular.module('groupApp', ['uiValidations', 'ajaxUtil', 'ui.materialize', 'validationService', 'generalUtility', 'otpModalApp']);

app.controller('contactabilityController', ['$rootScope', '$scope', 'ajaxHttpFactory', '$location', 'validateFieldService', '$window', '$http', function($rootScope, $scope, ajaxHttpFactory, $location, validateFieldService, $window, $http) {

    $scope.submitEmailMobileJson = {};
    $rootScope.preloaderCheck = false;
    $scope.errorArray = [];
    $scope.showCountryCode = false;
    $scope.showFullMobileNo = false;
    var ajaxurl = $location.absUrl();
    $scope.showNriMobileNo = false;
    $scope.showMobileNo = true;
    $scope.submitEmailMobileJson.countryName = "INDIA";
    $scope.responseObj = [];
    $scopeshowEmailID = false;
    $scope.showCountryCode = false;
    $scope.showCountriesDiv = false;

    $scope.successMethodOfGetCountryNames = function(response) {
        $scope.responseObj = response

        $scope.onChangeCountryName = function() {
        	$scope.submitEmailMobileJson.mobileNo="";
            for (var i = 0; i < response.length; i++) {
                if (response[i].countryName == $scope.submitEmailMobileJson.countryName) {
                    $scope.submitEmailMobileJson.code = response[i].countryCode;
                } else
                if ($scope.submitEmailMobileJson.countryName == "") {
                    $scope.submitEmailMobileJson.code = '';
                }
            }
        };
    }

    var getCountryDetails = function() {
        $rootScope.preloaderCheck = true;
        return ajaxHttpFactory.getJsonData("getCountryDetails", $location.absUrl())
            .then(function(response) {
                    $rootScope.preloaderCheck = false;
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
                        if (response != null && response != "null") {

                            $scope.successMethodOfGetCountryNames(response.data);
                        }
                    }
                },
                function(response) {
                    //			alert("In failureMethod");
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

                    }
                    $rootScope.preloaderCheck = false;
                });
    };

    getCountryDetails();
    $scope.contactDetailsSubmitForm = function() {




        if ($scope.submitEmailMobileJson.countryName == "INDIA" || $scope.submitEmailMobileJson.countryName == undefined || $scope.submitEmailMobileJson.countryName == "") {
            var currentElement = angular.element(document.querySelector('#countryName'));
            currentElement.removeClass('invalid1');
            $('#countryName_errMsg').css("visibility", "");
            for (var i = 0; i < $scope.errorArray.length; i++)
                if ($scope.errorArray[i] == "countryName") {
                    $scope.errorArray.splice(i, 1);
                    break;
                }

            var currentElement = angular.element(document.querySelector('#nriMobileNo'));
            currentElement.removeClass('invalid1');
            $('#nriMobileNo_errMsg').css("visibility", "");
            for (var i = 0; i < $scope.errorArray.length; i++)
                if ($scope.errorArray[i] == "nriMobileNo") {
                    $scope.errorArray.splice(i, 1);
                    break;
                }

        }

        if ($scope.submitEmailMobileJson.countryName != "INDIA" & $scope.submitEmailMobileJson.countryName != "") {

            var currentElement = angular.element(document.querySelector('#phoneNumber'));
            currentElement.removeClass('invalid1');
            $('#phoneNumber_errMsg').css("visibility", "");
            for (var i = 0; i < $scope.errorArray.length; i++)
                if ($scope.errorArray[i] == "phoneNumber") {
                    $scope.errorArray.splice(i, 1);
                    break;
                }
            if ($scope.checkBasicFieldValidations()) {
                $scope.failMobileNo = $scope.submitEmailMobileJson.mobileNo;
                $scope.submitEmailMobileJson.fullMobileNo = $scope.submitEmailMobileJson.code + $scope.submitEmailMobileJson.mobileNo;
                $scope.submitEmailMobileJson.mobileNo = $scope.submitEmailMobileJson.fullMobileNo;
                var encryptedString = $.jCryption.encrypt($scope.submitEmailMobileJson.property, passwordnew);

                $scope.submitEmailMobileJson.property = encryptedString;


                var submitEmailMobileJsonString = angular.toJson($scope.submitEmailMobileJson);
                var ajaxurl = $location.absUrl();

                ajaxHttpFactory.postJsonDataSuccessFailure(submitEmailMobileJsonString, "POST", ajaxurl, "emailMobileSubmit", $scope.submitEmailMobileSuccessMethod, $scope.submitEmailMobileFailureMethod);

            } else {
                $rootScope.preloaderCheck = false;
                ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
            }
        } else {
            if ($scope.checkBasicFieldValidations()) {

                var encryptedString = $.jCryption.encrypt($scope.submitEmailMobileJson.property, passwordnew);

                $scope.submitEmailMobileJson.property = encryptedString;

                var submitEmailMobileJsonString = angular.toJson($scope.submitEmailMobileJson);
                var ajaxurl = $location.absUrl();
                if ($scope.submitEmailMobileJson.mobileNo.match(/^[7-9]+[\d]{9}$/)) {


                    ajaxHttpFactory.postJsonDataSuccessFailure(submitEmailMobileJsonString, "POST", ajaxurl, "emailMobileSubmit", $scope.submitEmailMobileSuccessMethod, $scope.submitEmailMobileFailureMethod);
                } else {
                    ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill valid  Indian mobileNo", "errorMessage-popup", "forgotPasswordAlert");
                }
            } else {
                $rootScope.preloaderCheck = false;
                ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
            }
        }




    };



    $scope.onClickOfCountryButton = function(value) {
        if (value == "NRI") {

            $scope.showNriMobileNo = true;
            $scope.showCountryCode = true;
            $scope.showCountryNames = true;
            $scope.showMobileNo = false;
            $scope.submitEmailMobileJson.mobileNo = "";
            $scope.submitEmailMobileJson.emailId = "";
            $scope.submitEmailMobileJson.property="";
            $scope.submitEmailMobileJson.countryName = value;


            var currentElement = angular.element(document.querySelector('#phoneNumber'));
            currentElement.removeClass('invalid1');
            $('#phoneNumber_errMsg').css("visibility", "");

            var currentElement = angular.element(document.querySelector('#emailID'));
            currentElement.removeClass('invalid1');
            $('#emailID_errMsg').css("visibility", "");

            var currentElement = angular.element(document.querySelector('#password'));
            currentElement.removeClass('invalid1');
            $('#password_errMsg').css("visibility", "");


            $scope.errorArray = ["nriMobileNo", "countryName", "emailID", "password"];

        } else {
            if (value == "INDIA") {
                $scope.showNriMobileNo = false;
                $scope.showCountryCode = false;
                $scope.showCountryNames = false;
                $scope.showMobileNo = true;
                $scope.submitEmailMobileJson.mobileNo = "";
                $scope.submitEmailMobileJson.emailId = "";
                $scope.submitEmailMobileJson.countryName = "";
                $scope.submitEmailMobileJson.code = "";
                $scope.submitEmailMobileJson.property="";

                $scope.submitEmailMobileJson.countryName = value;



                var currentElement = angular.element(document.querySelector('#nriMobileNo'));
                currentElement.removeClass('invalid1');
                $('#nriMobileNo_errMsg').css("visibility", "");

                var currentElement = angular.element(document.querySelector('#emailID'));
                currentElement.removeClass('invalid1');
                $('#emailID_errMsg').css("visibility", "");

                var currentElement = angular.element(document.querySelector('#countryName'));
                currentElement.removeClass('invalid1');
                $('#countryName_errMsg').css("visibility", "");

                var currentElement = angular.element(document.querySelector('#password'));
                currentElement.removeClass('invalid1');
                $('#password_errMsg').css("visibility", "");

                $scope.errorArray = ["phoneNumber", "emailID", "password"];

            }
        }
    };

    $scope.submitEmailMobileSuccessMethod = function(response) {

        $rootScope.preloaderCheck = false;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

            $scope.linkRedirectionUrlWdgt();

            $rootScope.$on('otpHandShake', function(event, args) {

                if (args != null && args != undefined) {
                    var submitEmailMobileJsonString = angular.toJson($scope.submitEmailMobileJson);
                    var ajaxurl = $location.absUrl();
                    $rootScope.preloaderCheck = true;
                    ajaxHttpFactory.postJsonDataSuccessFailure(submitEmailMobileJsonString, "POST", ajaxurl, "emailMobileSave", $scope.saveEmailMobileSucces, $scope.saveEmailMobileFailure);
                }

            });
        } else {
            $scope.submitEmailMobileJson.mobileNo = $scope.failMobileNo;
            var currentElement = angular.element(document.querySelector('#password'));
            currentElement.removeClass('invalid1');
            $('#password_errMsg').css("visibility", "");
            $scope.submitEmailMobileJson.property = "";
        }

    };

    $scope.submitEmailMobileFailureMethod = function(response) {
        $rootScope.preloaderCheck = false;

        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

        }

    };

    $scope.saveEmailMobileSucces = function(response) {
        $rootScope.preloaderCheck = false;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

            $rootScope.check = true;
            $scope.message = "Your details have been submitted successfully. Kindly go to https://www.iciciprulife.com , select login option as ‘Corporate’, select Login with Email Mobile, Enter your registered email Id/Mobile no and password , click submit to login.";
        }
    };

    $scope.saveEmailMobileFailure = function(response) {
        $rootScope.preloaderCheck = false;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

        }

    };

    $scope.linkRedirectionUrlWdgt = function() {
        var url = $location.absUrl();
        ajaxHttpFactory.linkRedirectionUrlWdgt(url, '&otpType=transactionalOTP');

    };

    $scope.checkBasicFieldValidations = function() {
        if ($scope.errorArray.length > 0) {
            for (var i = 0; i < $scope.errorArray.length; i++) {
                var lengthBfr = $scope.errorArray.length;
                var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
                if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT" || errorElement.prop('type') == "password") {
                    errorElement.triggerHandler("blur");
                }
                var lengthAftr = $scope.errorArray.length;
                if (lengthAftr < lengthBfr) {
                    i--;
                }
            }
            if ($scope.errorArray.length > 0) {
                $("#" + $scope.errorArray[0]).focus();
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    };

    $scope.okalert = function() {
        $window.location.href = "onlogout.htm";
    };

}]);