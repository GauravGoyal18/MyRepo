angular.module('customTable', ['ngJScrollPane', 'payment', 'ui.filters', 'overlay-spinner', 'generalUtility', 'ngSanitize']).value('customTableVO', {
    selectedPolicyNos: [],
    selectedPolicyIndex: 0,
    setSIsStatus: [],
    checkedPolicyNo: '',
    checkedPolicyNos: [],
    selectedPendingInst: []
})

.directive('customisedPolicydetails', ['$rootScope', 'customTableVO', 'transformer', 'ajaxHttpFactory', '$timeout', '$window', '$filter', function($rootScope, customTableVO, transformer, ajaxHttpFactory, $timeout, $window, $filter) {
    return {
        restrict: "E",
        scope: {
            type: "@",
            descriptions: "=",
            items: "=",
            amountdetails: "=",
            fnforradiobutton: "&",
            message: "@"
        },
        templateUrl: function(elem, attr) {
            if (angular.isUndefined(attr.url)) return "digidrive/csr/pages/views/html/csr_customisedPolicyDetails.html";
            else return attr.url;
        },
        controller: ['$scope', function($scope) {
            //start : Variables initialization

            var summaryDetailInit = {
                suspenseAmt: 0,
                reInstAmt: 0,
                reInstAmtWver: 0,
                amtToBePaid: 0,
                totalPremium: 0
            };
            var firstElementLi = ($scope.type == "dashboard") ? "0%" : "5%";
            var secondElementLi = ($scope.type == "dashboard") ? "30%" : "25%";
            var lastElementLi = ($scope.type == "dashboard") ? "15%" : "10%";
			
			$scope.ellipsesLength = 15;
			$scope.ellipsesVar = 15;
            $scope.totalPremium = 0;
            $scope.selectedPolicyNos = [];
            $rootScope.summaryPaymentDetail = angular.copy(summaryDetailInit);
            $scope.selectedPolicyNosTemp = [];
            $scope.selectAllCheckbox = false;
            $scope.autoHeight = false;
            $scope.isSplitPaymentAllowed = false;
            $scope.paneConfig = {
                verticalDragMinHeight: 60
            };
            var maxScrollPaneHeight = ($scope.type == "dashboard") ? 260 : 300;
            var scrollPaneHeight = 0;
            var result = {};
            var wrappedResult = {};
            var isDesktopMode = true;
            var w = angular.element($window);

            //end : Variables initialization

            //start: function declarations

            angular.element(document).ready(function() {
                //$rootScope.$broadcast('pageSpinner',false);
                //$rootScope.$broadcast('policyTableSpinner',true);
            });
	
			$scope.showMore = function(length){
				if(length > $scope.ellipsesLength)
					$scope.ellipsesVar = length;
			};
			
			$scope.showLess = function(){
				$scope.ellipsesVar = $scope.ellipsesLength;
			};
			
            $rootScope.$watch('resizeTable', function(val) {
                if (val) {
                    $timeout(function() {
                        isDesktopMode = ($window.outerWidth > 787) ? true : false;
                        result = document.getElementsByClassName("pay-table-title");
                        wrappedResult = angular.element(result);
                        $scope.resize(wrappedResult.find("li"), isDesktopMode);
                        result = document.getElementsByClassName("pay-table-content");
                        wrappedResult = angular.element(result);
                        angular.forEach(wrappedResult.find("ul"), function(value, key) {
                            $scope.resize(angular.element(value).find("li"), isDesktopMode);
                        });
                        $scope.enableScrolling();
                        $scope.frequencyLegend = $filter('unique')($scope.items, "frequency");
                        var frequencyList = [];
                        angular.forEach($scope.frequencyLegend, function(value, key) {
                            frequencyList.push($filter('limitTo')(value.frequency, 1) + " - " + value.frequency + " ");
                        });
                        $scope.frequencyLegend = frequencyList;
                        if (customTableVO.checkedPolicyNos != "" && customTableVO.checkedPolicyNos.length >= 1) {
                            angular.forEach(customTableVO.checkedPolicyNos, function(value) {
                                customTableVO.checkedPolicyNo = value;
                                $scope.getAmountSummary(0);
                            });
                            customTableVO.checkedPolicyNo = '';
                        }
                        $rootScope.areCheckPageAjaxCallsDone = true;
                    });
                }
            });

            w.bind('resize', function(event) {
                //$scope.$broadcast('reinit-pane', 'pay-table-one');
                result = document.getElementsByClassName("pay-table-content");
                wrappedResult = angular.element(result);
                angular.forEach(wrappedResult.find("ul"), function(value, key) {
                    isDesktopMode = ($window.outerWidth > 787) ? true : false;
                    $scope.resize(angular.element(value).find("li"), isDesktopMode);
                });
                $scope.enableScrolling();
            });

            $scope.enableScrolling = function() {
                if (scrollPaneHeight >= maxScrollPaneHeight) $scope.$broadcast('reinit-pane', 'pay-table-one');
                result = document.getElementsByClassName("jspDrag");
                wrappedResult = angular.element(result);
                wrappedResult.css("height", "60px")
                if ($scope.type != "dashboard" && scrollPaneHeight <= maxScrollPaneHeight && $scope.items.length <= 5 && isDesktopMode) {
                    result = angular.element(document.querySelector('.jspVerticalBar'));
                    result.remove();
                }

            };

            $scope.resize = function(elements, isDesktop) {
                if ($scope.type != "dashboard")
                    scrollPaneHeight = ($scope.items.length < 5 && isDesktopMode) ? ((maxScrollPaneHeight / 5) * $scope.items.length) : maxScrollPaneHeight;
                else
                    scrollPaneHeight = 105;
                result = document.getElementsByClassName("scroll-pane");
                wrappedResult = angular.element(result);
                wrappedResult.css("height", scrollPaneHeight + "px");
                var length = elements.length;
                var remainingPerc = ($scope.type != "dashboard") ? 60 : 50;
                var effective = remainingPerc / (length - 3);
                angular.forEach(elements, function(value, key) {
                    if (key == 0) {
                        (isDesktop) ? angular.element(value).css('width', firstElementLi): angular.element(value).css('width', '');
                    } else if (key == 1) {
                        (isDesktop) ? angular.element(value).css('width', secondElementLi): angular.element(value).css('width', '');
                    } else if (key == length - 1) {
                        (isDesktop) ? angular.element(value).css('width', lastElementLi): angular.element(value).css('width', '');
                    } else {
                        (isDesktop) ? angular.element(value).css('width', effective + '%'): angular.element(value).css('width', '');
                    }
                })
            };

            $scope.getAmountSummary = function(index, isSelectedAllClicked) {
                if (angular.isUndefined(isSelectedAllClicked)) {
                    $scope.countChecked = 0;
                    $scope.items[index].isChecked = (customTableVO.checkedPolicyNo == "" && !$scope.items[index].isPolicyDisabled) ? !$scope.items[index].isChecked : $scope.items[index].isChecked;
                    $scope.items[index].setSi = (!$scope.items[index].isChecked && $scope.items[index].setSi == "Y") ? "N" : $scope.items[index].setSi;
                    var count = $filter('filter')($scope.items, {
                        setSi: "Y"
                    }).length;
                    if (count == 0) $rootScope.$emit('siPayment', false);
                    $scope.selectedPolicyNos = angular.copy($scope.selectedPolicyNosTemp);
                    customTableVO.setSIsStatus = [];
                    var count = $filter('filter')($scope.items, {
                        setSi: "Y"
                    }).length;
                    angular.forEach($scope.items, function(value, key) {
                        if (value.policynumber == customTableVO.checkedPolicyNo) {
                            $scope.items[key].isChecked = !$scope.items[key].isChecked;
                            customTableVO.checkedPolicyNo = "";
                            index = key;
                        }
                        if (value.isChecked == true) {
                            //$scope.selectedPolicyNos.push(value.policynumber);
                            $scope.countChecked++;
                        }
                    });
                    $scope.selectAllCheckbox = ($scope.countChecked == $scope.items.length) ? true : false;
                }
                if ($scope.items[index].isChecked) {
                    $scope.totalPremium += $scope.items[index].premium;
                } else $scope.totalPremium -= $scope.items[index].premium;
                angular.forEach($scope.amountdetails[index], function(value, key) {
                    if ($scope.items[index].isChecked) {
                        $rootScope.summaryPaymentDetail[key] += value;
                    } else {
                        if (key == "amtToBePaid" && $scope.items[index].pendingInstallments != $scope.items[index].numOfInstSelected) {
                            $rootScope.summaryPaymentDetail[key] = $rootScope.summaryPaymentDetail[key] - ($scope.items[index].premium * $scope.items[index].numOfInstSelected / $scope.items[index].pendingInstallments);
                            $scope.items[index].numOfInstSelected = $scope.items[index].pendingInstallments;
                        } else $rootScope.summaryPaymentDetail[key] -= value;
                    }
                });
                $rootScope.summaryPaymentDetail["totalPremium"] = $scope.totalPremium;
                if ($scope.totalPremium == 0) {
                    $rootScope.summaryPaymentDetail["amtToBePaid"] = 0;
                }
                //customTableVO.selectedPolicyNos = $scope.selectedPolicyNos;
                $scope.isSplitPaymentAllowed = ($scope.countChecked == 1) && ($scope.items[index].isSplitAllowed) && $rootScope.summaryPaymentDetail.amtToBePaid > 10000;
                $rootScope.$emit('splitPayment', {
                    isSplitPaymentAllowed: $scope.isSplitPaymentAllowed,
                    totalPremium: $scope.totalPremium,
                    amtToBePaid: $rootScope.summaryPaymentDetail.amtToBePaid
                });
            };

            $scope.reCalculateAmount = function(index, selectedValue) {
                $scope.items[index].prevNumOfInstSelected = selectedValue;
                var amountPerinstallment = $scope.items[index].premium / $scope.items[index].pendingInstallments;
                $rootScope.summaryPaymentDetail.amtToBePaid = $rootScope.summaryPaymentDetail.amtToBePaid - (amountPerinstallment * selectedValue) + (amountPerinstallment * $scope.items[index].numOfInstSelected);
                $rootScope.$emit('splitPayment', {
                    isSplitPaymentAllowed: $scope.isSplitPaymentAllowed,
                    totalPremium: $scope.totalPremium,
                    amtToBePaid: $rootScope.summaryPaymentDetail.amtToBePaid
                });
            };

            $scope.selectAllClicked = function() {
                $scope.selectAllCheckbox = !$scope.selectAllCheckbox;
                var count = 0;
                $rootScope.summaryPaymentDetail = angular.copy(summaryDetailInit);
                $scope.totalPremium = 0;
                $scope.selectedPolicyNos = angular.copy($scope.selectedPolicyNosTemp);
                angular.forEach($scope.items, function(value, key) {
                    if (!$scope.selectAllCheckbox) {
                        value.isChecked = false;
                    } else {
                        value.isChecked = $scope.selectAllCheckbox && !value.isPolicyDisabled;
                        $scope.getAmountSummary(count, '');
                        $scope.selectedPolicyNos.push(value.policynumber);
                        count++;
                    }
                });
                if (!$scope.selectAllCheckbox) {
                    $scope.$emit('splitPayment', {
                        isSplitPaymentAllowed: $scope.isSplitPaymentAllowed,
                        totalPremium: $scope.totalPremium,
                        amtToBePaid: $rootScope.summaryPaymentDetail.amtToBePaid
                    });
                }
                customTableVO.selectedPolicyNos = $scope.selectedPolicyNos;
            };

            $scope.updateSetSi = function(index) {
                $rootScope.$broadcast('pageSpinner', true);
                transformer.formId = "paymentBean";
                $scope.polNos = $scope.items[index].policynumber;
                $scope.polIndex = index;
                if (!$scope.items[index].isCLSIPaymentAllowed && $scope.type == "paypremium") {
                    transformer.setFormElement("policyN", $scope.polNos);
                    // transformer.setFormElement("strSIReqType","CLSI");
                    //transformer.setFormElement("paymentTypeH","CLSI");
                    ajaxHttpFactory.securedHttpMethodCall(transformer.formId, 'checkForCLSI', $scope.SICallbackFunc, 'load', null, true);
                } else if (!$scope.items[index].isCLSIPaymentAllowed && $scope.type == "sasi") {
                    if (customTableVO.selectedPolicyNos.length <= 3) {
                        transformer.setFormElement("policyN", $scope.polNos);
                        transformer.setFormElement("strSIReqType", "SASI");
                        transformer.setFormElement("paymentTypeH", "SASI");
                        ajaxHttpFactory.securedHttpMethodCall(transformer.formId, 'csr_set_SASI', $scope.SICallbackFunc, 'load', null, true);
                    } else {
                        $rootScope.message = "SI can be set for three polices at a time.";
                        $('#policy-popup').modal('show');
                        //alert("SI can be set for three polices at a time.");
                    }
                } else {
                    $scope.items[$scope.polIndex].isCLSIPaymentAllowed = false;
                    $scope.items[index].setSi = ($scope.items[index].setSi == "Y") ? "N" : "Y";
                    if ($scope.type == "sasi") customTableVO.selectedPolicyNos.splice(customTableVO.selectedPolicyNos.indexOf($scope.polNos), 1);
                    else if ($scope.type == "paypremium") {
                        angular.forEach($scope.selectedPolicyNos, function(value, key) {
                            if (value == $scope.items[index].policynumber) {
                                customTableVO.setSIsStatus[key] = ($scope.items[index].setSi == "Y") ? "Y" : "";
                            }
                        });
                    }
                    $rootScope.$broadcast('pageSpinner', false);
                }
                var count = $filter('filter')($scope.items, {
                    setSi: "Y"
                }).length;
                if (count == 0) $rootScope.$emit('siPayment', false);
                else $rootScope.$emit('siPayment', true);
            };

            $scope.SICallbackFunc = function(response) {
                $scope.data = angular.fromJson(response);
                $scope.PDRFlag = $scope.data.siObject.pdrFlag;
                if ($scope.data.error == "") {
                    if ($scope.data.siObject.ECS_DD == "Y") {
                        $rootScope.message = "The facility is not available for policies that are on existing ECS/Direct Debit.";
                        $('#policy-popup').modal('show');
                    } else if ($scope.PDRFlag == "Y") {
                        $rootScope.message = "Please submit a personal health declaration at nearest branch for policy number " + $scope.polNos + ".";
                        $('#policy-popup').modal('show');
                    } else {
                        $scope.items[$scope.polIndex].isCLSIPaymentAllowed = true;
                        $scope.items[$scope.polIndex].setSi = ($scope.items[$scope.polIndex].setSi == "Y") ? "N" : "Y";
                        if ($scope.type == "sasi") {
                            customTableVO.selectedPolicyNos.push($scope.polNos);
                        }
                    }
                } else {
                    $rootScope.message = $scope.data.error;
                    $('#policy-popup').modal('show');
                    $scope.items[$scope.polIndex].showSetSI = false;
                }
                var count = $filter('filter')($scope.items, {
                    setSi: "Y"
                }).length;
                if (count == 0) $rootScope.$emit('siPayment', false);
                else $rootScope.$emit('siPayment', true);
                $rootScope.$broadcast('pageSpinner', false);
            };

            $scope.getPolicySelected = function(index) {
                customTableVO.selectedPolicyIndex = index;
                $scope.fnforradiobutton();
            };

            $scope.linkRedirectionUrlWdgt = function(url, param, divId) {
                url = url + '?polno=' + param;
                ajaxHttpFactory.linkRedirectionUrlWdgt(url);
            };

            //end: function declarations
        }]
    };

}])

.directive("customisedInvestmentDetails", function() {
    return {
        restrict: "E",
        scope: {
            type: "@",
            itemDetails: "=",
            otherDetails: "="
        },
        templateUrl: function(elem, attr) {
            if (angular.isUndefined(attr.url)) return "digidrive/csr/pages/views/html/csr_investment_break_up.html";
            else return attr.url;
        },
        controller: ['$scope', function($scope) {
            //start : Variables initialization
            //end : Variables initialization
            //start: function declarations
            //end: function declarations
        }]
    };

})

.directive('customisedPolicySummary', function() {
    return {
        restrict: "E",
        scope: {
            leftItemDetails: "=",
            rightItemDetails: "=",
            otherDetails: "=",
            type: "@"
        },
        templateUrl: function(elem, attr) {
            if (angular.isUndefined(attr.url)) return "digidrive/csr/pages/views/html/csr_policy_summary.html";
            else return attr.url;
        },
        controller: ['$scope', function($scope) {
        }]
    };
});