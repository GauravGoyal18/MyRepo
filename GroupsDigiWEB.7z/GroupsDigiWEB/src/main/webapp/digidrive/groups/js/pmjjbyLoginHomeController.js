var app = angular.module('groupApp',['ajaxUtil','ui.materialize','uiValidations']);
app.controller("pmjjbyLoginHomeController",['$rootScope','$scope','$location','ajaxHttpFactory','$http',
                                   function($rootScope, $scope,$location,ajaxHttpFactory,$http){
	

	//hide spinner
	$rootScope.preloaderCheck=false;

}]);
	

