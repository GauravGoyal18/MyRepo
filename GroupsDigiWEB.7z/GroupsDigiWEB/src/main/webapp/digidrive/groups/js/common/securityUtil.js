var httpSecurityApp = angular.module('httpSecurity', [])
httpSecurityApp.config(function($httpProvider) {
    $httpProvider.interceptors.push('templateInterceptor');
});

// register the interceptor as a service
httpSecurityApp.factory('templateInterceptor', function($q) {
            return {
                'responseError': function(rejection) {
                	
                	if(rejection.config.url.indexOf(window.location.pathname.split('/')[1])>-1 || !(rejection.config.url.indexOf('checkIsValidProduct')>-1))
            		{
                		//if(rejection.config.url.indexOf(window.location.hostname)>-1)
                		//{
	                    if (rejection.status == 404) {
	                        var isTemplate = !!rejection.config.url.match(/^content/g);
	                        if (isTemplate) {
	                            rejection.data = '<div><template-error url="\'' + (rejection.config.url) + '\'"><strong>Error from interceptor.</strong></template-error></div>';
	                            return rejection;
	                        } else {
	                            window.location.href = "error.htm";
	                            return $q.reject(rejection);
	                        }
	                    } else if (rejection.status == 400 || rejection.status == 403 || rejection.status == 409 || rejection.status == 500) {
	                        window.location.href = "error.htm";
	                        return $q.reject(rejection);
	                    }
                	//}
                    }
                	return $q.reject(rejection);
                }
             }
});