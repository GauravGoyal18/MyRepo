
var app = angular.module('groupApp', ['ajaxUtil','uiValidations','ui.materialize','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection','groupCommonUtil','otpModalApp']);

app.controller('coiController',['$scope','$location','ajaxHttpFactory','$rootScope','$window','csrDocUploadFactory','$http','$filter','uiGridConstants', function($scope,$location,ajaxHttpFactory,$rootScope,$window,csrDocUploadFactory,$http,$filter,uiGridConstants){ 


       $scope.errorArray=[];
       $scope.modalErrorArray=[];
       $scope.coi={};
       $scope.coiPan={};
       $scope.coiModalObj={};
       $scope.coiModal=false;
       $scope.selectedOption = '';
       $rootScope.preloaderCheck=false;
       $scope.coiPannoViewDiv=false;
       $scope.coigridPannoOptionsView={};
       $scope.coiPannoViewData=[];
       $scope.showSubmit=true;
       $scope.disableFields=false;
       $scope.showTotalSumAssured=false;
       
       
      

       
       var paginationOptions = {
                  pageNumber: 1,
                  pageSize: 10,
                  sort: null
                };
       
       
       $scope.onClickcoiModal=function(){
              $scope.coiModal=true;
       }
       
       $scope.cancelModal=function(){
              var currentElement = angular.element(document.getElementsByClassName('invalid1'));
              currentElement.removeClass('invalid1');
              $('.err-msg').css("visibility", "");
              $scope.modalErrorArray=[];
              
              $scope.coiModal=false;
              
       }
       
       $scope.cancelCoi=function(){
              var currentElement = angular.element(document.getElementsByClassName('invalid1'));
              currentElement.removeClass('invalid1');
              $('.err-msg').css("visibility", "");
              
              $scope.coiPannoViewDiv=false;
              $scope.coi={};
       }
       
       $scope.cancelCoiPanno=function(){
              var currentElement = angular.element(document.getElementsByClassName('invalid1'));
              currentElement.removeClass('invalid1');
              $('.err-msg').css("visibility", "");
              $scope.coiPannoViewDiv=false;
               $window.location.href = "coiPan.htm";
              $scope.coiPan={};
    	   $scope.showSubmit=true;
    	    $scope.showTotalSumAssured=false;
    	
       }
       
       
       
       $scope.submitCoi=function()
       {
       
             
             
              
              if($scope.checkBasicFieldValidations())
              {
              if(($scope.coi.memLoanAcc==null || $scope.coi.memLoanAcc=='') && ($scope.coi.panNo==null || $scope.coi.panNo==''))
              {
                     ajaxHttpFactory.showErrorSuccessMessagePopup("Please fill Member id/Loan number/Account number OR Pan Number. ","errorMessage-popup", "nomineeAlert");

              }
              else
              {
              
              
              $rootScope.preloaderCheck=true;
              var coiSubmit=angular.toJson($scope.coi);
              var ajaxurl=$location.absUrl();  //
              
              

                ajaxHttpFactory.postJsonDataSuccessFailure(coiSubmit,"POST",ajaxurl,"coiSubmit",$scope.successMethod,$scope.failureMethod);

              }
              
              }
       };
       
       
       
       $scope.submitCoiPanNo=function()
       {            
    	   
    	   
              if($scope.checkBasicFieldValidations())
              {
            	  if(($scope.coiPan.mobileNo==null || $scope.coiPan.mobileNo=='') && ($scope.coiPan.emailId==null || $scope.coiPan.emailId==''))
                  {
            		 
                         ajaxHttpFactory.showErrorSuccessMessagePopup("Please enter Email-ID OR Mobile Number. ","errorMessage-popup", "coiAlert");

                  }
            	  else{
            	  $rootScope.preloaderCheck=true;
                  $scope.coiPannoViewDiv=false;
               var coiPanNoSubmit=angular.toJson($scope.coiPan);
               var ajaxurl=$location.absUrl();  

               ajaxHttpFactory.postJsonDataSuccessFailure(coiPanNoSubmit,"POST",ajaxurl,"coiPanNoSubmit",$scope.successMethodcoiPanNoSubmit,$scope.failureMethodPan)
            	 
              }
              }
              else
              {
            	  ajaxHttpFactory.showErrorSuccessMessagePopup("Please fill All Mandatory Fields. ","errorMessage-popup", "nomineeAlert");
                   
            	 
              }
              
             
       };
       
       $scope.successMethodcoiPanNoSubmit = function(response){
              
              if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
                     
                     $scope.linkRedirectionUrlWdgt();
              
              $rootScope.$on('otpHandShake', function (event, args) {
                     if(args!=null && args!=undefined)
                           {
                           var coiPanJsonString = angular.toJson($scope.coiPan);
                                  var ajaxurl = $location.absUrl(); 
                                  $rootScope.preloaderCheck=true;
                                  ajaxHttpFactory.postJsonDataSuccessFailure(coiPanJsonString,"POST",ajaxurl,"coiPanNoSave",$scope.successMethodPan,$scope.failureMethodPan);
                           }
              });
              }
       };
       
       $scope.download = function(data){                      
              $rootScope.preloaderCheck=true;
              
              var coiDownloadPdf = angular.toJson(data.entity);
              var ajaxurl=$location.absUrl();
              ajaxHttpFactory.postJsonDataSuccessFailure(coiDownloadPdf,"POST",ajaxurl,"coiDownloadPdf",$scope.successMethodPdf,$scope.submitFailureMethod);
             
       };
       
       $scope.downloadIICDFile = function(data){ 
    	   
    	   $rootScope.preloaderCheck=true;
           var coiDownloadPdf = angular.toJson(data.entity);
           var ajaxurl=$location.absUrl();
            	  ajaxHttpFactory.postJsonDataSuccessFailure(coiDownloadPdf,"POST",ajaxurl,"coiDownloadDocFlagPdf",$scope.successMethodDocFlagPdf,$scope.submitFailureMethodDOcFlagPdf); 
            	  
       };
       
       
       $scope.submitKnowYourPolicy=function()
       {
              if($scope.coiModalObj.memLoanAcc!="")
              {
                     var currentElement = angular.element( document.querySelector('#panNo1'));
                     currentElement.removeClass('invalid1');
                     $('#panNo1_errMsg').css("visibility", "");
                     for (var i = 0; i < $scope.modalErrorArray.length; i++)
                         if ($scope.modalErrorArray[i] == "panNo1") { 
                            $scope.modalErrorArray.splice(i, 1);
                             break;
                         }
              }             
              else if($scope.coiModalObj.panNo!="")
                     {
                     var currentElement = angular.element( document.querySelector('#memberID'));
                     currentElement.removeClass('invalid1');
                     $('#memberID_errMsg').css("visibility", "");
                     for (var i = 0; i < $scope.modalErrorArray.length; i++)
                         if ($scope.modalErrorArray[i] == "memberID") { 
                            $scope.modalErrorArray.splice(i, 1);
                             break;
                         }
                     }
              if($scope.checkBasicFieldValidationsModal())
              {
              if(($scope.coiModalObj.memLoanAcc==null || $scope.coiModalObj.memLoanAcc=='') && ($scope.coiModalObj.panNo==null || $scope.coiModalObj.panNo==''))
              {
                     ajaxHttpFactory.showErrorSuccessMessagePopup("Please fill Member id OR Pan Number. ","errorMessage-popup", "nomineeAlert");
                     $scope.coiModal=true;
              }
              else
              {
              
              $rootScope.preloaderCheck=true;
              var coiSubmit=angular.toJson($scope.coiModalObj);
              var ajaxurl=$location.absUrl();
              ajaxHttpFactory.postJsonDataSuccessFailure(coiSubmit,"POST",ajaxurl,"coiKnowYourPolicy",$scope.successMethod1,$scope.failureMethod);
              
              
              
              }
              
              
              }
       }
       
       
$scope.failureMethod=function(){
              
              $rootScope.preloaderCheck=false;
              $rootScope.openAlertID = true;
              $scope.action="failure";
              $scope.message = "Some Error Occured.";
              $scope.coi={};
              $scope.coiModalObj={};
              $scope.coiPan={};
              
       };
       
       
       
$scope.successMethod1=function(response)
       {
              $rootScope.preloaderCheck=false;

       if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){

              $rootScope.preloaderCheck=false;
             
              $scope.coi.policyNumber=response;
       
              $scope.coiModalObj={};
              $scope.coiModal=false;
              }
       }
       



$scope.successMethodPdf=function(response){
		$rootScope.preloaderCheck=true;
       $rootScope.openAlertID = false;
       if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
              if(response=="success")
              {
             $scope.methodType = 'POST';
              
              $http({
            url: 'PDFStatementServlet.do',
            method: $scope.methodType,
            responseType: 'arraybuffer',
            data: undefined,
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/pdf'
            }
        }).success(function(data) {
        	$rootScope.preloaderCheck=true;
              if(data.byteLength>0)
              {
            var blob = new Blob([data], {
                type: 'application/pdf'
            });
            saveAs(blob, 'coiStatement' + '.pdf');
            $rootScope.preloaderCheck=false;
                     ajaxHttpFactory.showErrorSuccessMessagePopup("File downloaded successfully. ","errorMessage-popup", "bidAlert");
              
              }
              else
              {
                     $rootScope.preloaderCheck=false;
                           ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "bidAlert");
                           $window.location.href = "coi.htm";
              }
            
            
        }).error(
            function() {
             $rootScope.preloaderCheck=false;
                           ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "bidAlert");
                           $window.location.href = "coi.htm";
            });
              
              
              
              }
       else
              {
              $rootScope.preloaderCheck=false;
              ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ","errorMessage-popup", "bidAlert");
              $window.location.href = "coi.htm";

              }
       }
     
       $rootScope.preloaderCheck=false;
};


$scope.submitFailureMethod=function(response)
	{
	if(ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
		
	}
	};

$scope.successMethod=function(response){
       $rootScope.preloaderCheck=true;
              $rootScope.openAlertID = false;
              if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
                     if(response=="success")
                     {
                    $scope.methodType = 'POST';
                     
                     $http({
                url: 'PDFStatementServlet.do',
                method: $scope.methodType,
                responseType: 'arraybuffer',
                data: undefined,
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/pdf'
                }
            }).success(function(data) {
              $rootScope.preloaderCheck=true;
              if(data.byteLength>0)
              {
                var blob = new Blob([data], {
                    type: 'application/pdf'
                });
                saveAs(blob, 'coiStatement' + '.pdf');
                $rootScope.preloaderCheck=false;
                           ajaxHttpFactory.showErrorSuccessMessagePopup("File downloaded successfully. ","errorMessage-popup", "bidAlert");
                     
              }
              else
              {
                     $rootScope.preloaderCheck=false;
                                  ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "bidAlert");
                                  $window.location.href = "coi.htm";
              }
                
                
            }).error(
                function() {
                     $rootScope.preloaderCheck=false;
                                  ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "bidAlert");
                                  $window.location.href = "coi.htm";
                });
                     
                     
                     
                     }
              else
                     {
                     $rootScope.preloaderCheck=false;
                     ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ","errorMessage-popup", "bidAlert");
                     $window.location.href = "coi.htm";

                     }
              }
              $scope.coi={};
             
              $rootScope.preloaderCheck=false;
       };
       
       

$scope.successMethodPan=function(response)
       {
	$scope.totalSumAssured=0;
              $rootScope.preloaderCheck=false;
              $scope.showSubmit=false;
              
       if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){

              $rootScope.preloaderCheck=false;
              
              var responseData = response;
              for(var i=0;i<responseData.length;i++)
            	  {
            	  	if(responseData[i].sumassured==null)
            	  		{
            	  		responseData[i].sumassured=0;
            	  		}
            	  	 $scope.totalSumAssured= parseInt($scope.totalSumAssured)+parseInt(responseData[i].sumassured);
            	  }
              //$scope.totalSumAssured=response.totalSumAssured;
              
              
             /* if($scope.totalSumAssured==null)
        	  {
            	  $scope.totalSumAssured=0;
        	  }
              else
            	  {
            	  $scope.totalSumAssured=response.totalSumAssured;
            	  }*/
            	  $scope.showTotalSumAssured=true;
              $scope.coiPannoViewData=responseData;
              $scope.coigridPannoOptionsView.totalItems=$scope.coiPannoViewData.length;
      	       $scope.disableFields=true;

              $scope.coiPannoViewDiv=true;
              $scope.otpForm.otpNumber='';
             
              
              $scope.getPageD();
              
              $rootScope.preloaderCheck=false;
    
              
       }
       
       };
       
       $scope.failureMethodPan=function()
       {
              $rootScope.preloaderCheck=false;
              $rootScope.openAlertID = true;
              $scope.action="failure";
              $scope.message = "Some Error Occured.";
              $scope.coiPan={};
       };
       

       var currentTime = new Date();
       $scope.currentTime = currentTime;
       $scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
       $scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
       $scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
       $scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

       $scope.today = '';
       $scope.clear = 'Clear';
       $scope.close = 'Done';
       var days = 100;
       $scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
       $scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
       $scope.onStart = function () {
          
       };
       $scope.onRender = function () {
          
       };
       $scope.onOpen = function () {
       
           
          

           
       };
       $scope.onClose = function () {
              
         
           
           
       };


       $scope.onSet = function () {
              
         
         

         
         
       };


       $scope.onStop = function () {
         
       };
              
       $scope.okAlert= function (){
              $rootScope.openAlertID = false;

              if($scope.action=="success")
                     {
                     $rootScope.openAlertID = false;
                     $window.location.href = "coi.htm";
                     
                     }
              else if($scope.action=="failure")
                     {
                     $rootScope.openAlertID = false;
                     $window.location.href = "coi.htm";
                     }
              
       };
       
       $scope.cancelAlert= function (){
       
              $rootScope.openAlertID = false;
              $window.location.href = "coi.htm";
       };
       
       
       $scope.checkBasicFieldValidationsModal = function() {
           if ($scope.modalErrorArray.length > 0) {
               for (var i = 0; i < $scope.modalErrorArray.length; i++) {
                   var lengthBfr = $scope.modalErrorArray.length;
                   var errorElement = angular.element(document.querySelector('#' + $scope.modalErrorArray[i]));
                   if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
                       errorElement.triggerHandler("blur");
                   }
                   var lengthAftr = $scope.modalErrorArray.length;
                   if (lengthAftr < lengthBfr) {
                       i--;
                   }
               }
               if ($scope.modalErrorArray.length > 0) {
                   $("#" + $scope.modalErrorArray[0]).focus();
                   return false;
               } else {
                   return true;
               }
           } else {
               return true;
           }
       };
              
       
$scope.checkBasicFieldValidations = function() {
              
      
           if ($scope.errorArray.length > 0) {
               for (var i = 0; i < $scope.errorArray.length; i++) {
                   var lengthBfr = $scope.errorArray.length;
                   var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
                   if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
                       errorElement.triggerHandler("blur");
                   }
                   var lengthAftr = $scope.errorArray.length;
                   if (lengthAftr < lengthBfr) {
                       i--;
                   }
               }
               if ($scope.errorArray.length > 0) {
                   $("#" + $scope.errorArray[0]).focus();
                   return false;
               } else {
                   return true;
               }
           } else {
               return true;
           }
       };
       
       
       
              
       $scope.checkDate= function(currentElement,errorMsgElement){
              if(angular.element(document.getElementById(currentElement)).val()=="")
                     {
                     angular.element(document.getElementById(currentElement)).addClass('invalid1');
                     angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
                     return false;
                     }
              else
                     {
                     angular.element(document.getElementById(currentElement)).removeClass('invalid1');
                     angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
                     }
              return true;
              }
       
     
           
           
        $scope.coigridPannoOptionsView = {
                         paginationPageSizes: [10],
                         paginationPageSize: 10,
                         useExternalPagination: true,
                         useExternalSorting: true,
                         enableColumnMenus: false,
                         enableFiltering: false,
                         multiSelect: true,
                          
                 enableRowSelection: true,
                      enableSelectAll: true,                 
                      showGridFooter:true,                   
                      resizable: false,
                      enableColumnResizing: true,
                      enableSorting: false,                   
                      
                         columnDefs: [
                           { field: 'policynumber', displayName: 'Policy Number', width: "15%"},
                           { field: 'masterpolicy', displayName: 'Master Policy Number', width: "17%"},                        
                           { field: 'employeeid', displayName: 'Employee Id', width: "20%"},                       
                           { field: 'pannumber', displayName: 'Pan Number', width: "20%"},
                           { field: 'Action', displayName: 'COI', width: "14%",cellTemplate:'<button ng-click="grid.appScope.download(row)"><img src="digidrive/groups/images/download-icon.png" /></button>'},
                           { field: 'docFlag', displayName: 'ICD', width: "14%",cellTemplate:'<div ng-if=\"row.entity.docFlag == \'IICD\'" ><button ng-click="grid.appScope.downloadIICDFile(row)"><img src="digidrive/groups/images/download-icon.png" /></button></div><div ng-if=\"row.entity.docFlag != \'IICD\'" ></div>'}
                           ],
                         
                       
                         onRegisterApi: function(gridApi) {
                           $scope.gridApi = gridApi;                                            
                           gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
                             paginationOptions.pageNumber = newPage;
                             paginationOptions.pageSize = pageSize;                     
                             $scope.getPageD();                       
                           });                        
                          
                          
                         }
                       };
       
        $scope.linkRedirectionUrlWdgt=function(){
                     var url=$location.absUrl();
                     ajaxHttpFactory.linkRedirectionUrlWdgt(url,'&otpType=transactionalOTP');
                     
              };
       
        
              $scope.getPageD = function() {
              var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
            $scope.coigridPannoOptionsView.data=$scope.coiPannoViewData.slice(firstRow, firstRow + paginationOptions.pageSize);
           
              };
              
              $scope.successMethodDocFlagPdf=function(response){
            	  
          		$rootScope.preloaderCheck=false;
          		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
          		
          			$window.open(angular.fromJson(response),'_blank');
          			
          		} else {
          			$rootScope.preloaderCheck=false;
          		}
          	};
              
           $scope.submitFailureMethodDOcFlagPdf=function(response)
       	{
       	if(ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
       		
       		ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured please try again. ","errorMessage-popup","coiDocPdfAlert");
       	}
       	};
           
}]);
