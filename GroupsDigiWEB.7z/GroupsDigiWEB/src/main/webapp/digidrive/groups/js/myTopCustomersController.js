var app=angular.module('groupApp',['ui.materialize','uiValidations','ajaxUtil','ngRoute','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection','groupCommonUtil']);

app.controller('myTopCustomersController',['$rootScope','$scope','ajaxHttpFactory','$location','$window','$filter','$http','$rootScope','uiGridConstants','csrDocUploadFactory', function($rootScope,$scope,ajaxHttpFactory,$location,$window,$filter,$http,$rootScope,uiGridConstants,csrDocUploadFactory){
	
	$rootScope.preloaderCheck=true;
	$scope.errorArray=[];
	$scope.newTabCoi={};
	$scope.newTabCoidata={};
	
	var ajaxurl=$location.absUrl();
	$scope.result=[];
	$scope.excelValidationdata={};
	$scope.brokerTopCustomerOpenView={};
	$scope.brokerTopCustomerOpenData=[];
	$scope.brokerTopCustomerOpenViewDiv=false;
	
	$scope.gridRowClickOnClick = function(member){				
		
		$rootScope.preloaderCheck=true;
/*		$scope.newTabCoi.policynumber=$scope.newTabCoidata.policynumber;*/
		$scope.newTabCoi = member.entity;
		$scope.newTabCoidata.policynumber=$scope.newTabCoi.policynumber;
		
		var excelJson = angular.toJson($scope.newTabCoidata);
		
		ajaxHttpFactory.postJsonDataSuccessFailure(excelJson,"POST",ajaxurl,"getNewTabCoi",$scope.success2Method,$scope.failure2Method);
		
	};
	
	 $scope.openClosed="openClose";
	 var paginationOptions = {
			    pageNumber: 1,
			    pageSize: 10,
			    sort: null
			  };
	 
	 
	var onLoadData=function(){			
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("LoadTopCustomer",ajaxurl)
		.then(function(bizRes){	
			
			if(ajaxHttpFactory.handleIPruException(bizRes.data, "errorMessage-popup", "exceptionAlert")){
				
							
				$rootScope.preloaderCheck=false;
			}			
			var responseData = bizRes.data;
			$scope.brokerTopCustomerOpenData=responseData;
			$scope.brokerTopCustomerOpenView.totalItems=$scope.brokerTopCustomerOpenData.length;

			
			$scope.brokerTopCustomerOpenViewDiv=true;
			
			$scope.getPageOC();
			
			$rootScope.preloaderCheck=false;					
		},
		function(errResponse){
			$rootScope.preloaderCheck=false;
			if(ajaxHttpFactory.handleIPruException(bizRes.data, "errorMessage-popup", "exceptionAlert")){
				
			}
		});
};
	
onLoadData();
	

$scope.getPageOC = function() {
	 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
    $scope.brokerTopCustomerOpenView.data=$scope.brokerTopCustomerOpenData.slice(firstRow, firstRow + paginationOptions.pageSize);	     
   
	};

	 
	 $scope.brokerTopCustomerOpenView = {			 				
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,			   
			    enableRowSelection: false,		      	     
		        resizable: false,
		        enableColumnResizing: false,
		        enableSorting: false,		       
		        
			    columnDefs: [
			      { field: 'policynumber', displayName: 'Policy Number',headerTooltip:function(col){return col.displayName;}, width: "12%"},
			      { field: 'statusKey',displayName: 'Status Key',headerTooltip:function(col){return col.displayName;}, width: "10%"},
			      { field: 'productName',  displayName: 'Product Name',headerTooltip:function(col){return col.displayName;}, width: "20%"},
			      { field: 'branchCode', displayName: 'Branch Code',width: "14%",headerTooltip:function(col){return col.displayName;}, width: "10%"},
			      { field: 'clientName', displayName: 'Client Name',headerTooltip:function(col){return col.displayName;}, width: "40%"},
			      { field: 'premiumAmount', displayName: 'Premium Amount',headerTooltip:function(col){return col.displayName;}, width: "15%"},
			      { field: 'rcd', displayName: 'RCD',headerTooltip:function(col){return col.displayName;}, width: "15%"}
			    //  { field: 'coiLink', displayName: 'COILink', width: "10%", enableSorting: false,enableFiltering: false,cellTemplate : '<div ><p class="center-align"> <a ng-click="grid.appScope.gridRowClickOnClick(row)" class="uigridbtn">click</a></p></div>'}
			    
			     	      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageOC();
			      });			      			 
			    }
			  };
	 
	
	
		
		
	
	



	
	$scope.dataAlert= function (){
		$rootScope.openAlertID = false;											
		$window.location.href = "dashboard.htm";
	};


	$scope.successMethod = function(bizRes) {		
		if(!ajaxHttpFactory.handleIPruException(bizRes, "errorMessage-popup", "exceptionAlert")){					
			$scope.result=bizRes;
			$rootScope.preloaderCheck=false;
		}
	};
		
	$scope.failureMethod = function(bizRes) {
		if(!ajaxHttpFactory.handleIPruException(bizRes, "errorMessage-popup", "exceptionAlert")){			
			$rootScope.preloaderCheck=false;
		}
	};	
    
$scope.success2Method = function(response) {
		
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
		
			$window.open(angular.fromJson(response),'_blank');
			
		} else {
			$rootScope.preloaderCheck=false;
		}
	};
	
	$scope.failure2Method = function(response) {
		$rootScope.preloaderCheck = false;
		if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup","claimAlert")) {

			ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured please try again. ","errorMessage-popup","claimAlert");
		}
	};
	
}]);