function serverHit(){

  ReqCounterAjax(); 

  requestCounter();
  }
  function requestCounter() {
  
    setTimeout(serverHit,requestHitTime);
  }
requestCounter();

function logOut(){
  
  //alert("logout called");
  //window.location.href="${pageContext.request.contextPath}"+"/logout.htm";
  var logoutUrl="onlogout.htm";
  $("#logoutPageForm").attr("action",logoutUrl);
  $("#logoutPageForm").submit();
}
/*function preventBrowserBack(){
  window.history.forward();}
setTimeout("preventBrowserBack()", 0);
*/
var sPath=window.location.pathname;
var sPage = sPath.substring(sPath.lastIndexOf('/') + 1);
var isIE = /*@cc_on!@*/false || !!document.documentMode;
var isEdge = !isIE && !!window.StyleMedia;

if ((isIE || isEdge) && sPage == "home.htm") {

} else {
  history.pushState(null, null);
  window.addEventListener('popstate', function () {
      history.pushState(null, null);
  });
}
