var app = angular.module('groupApp',['ajaxUtil','ui.materialize','validationService','generalUtility']);

app.controller('portfolioController',['$scope','$rootScope','ajaxHttpFactory','$location','validateFieldService',function($scope,$rootScope,ajaxHttpFactory,$location,validateFieldService){

	
	$scope.fieldAccessMappingMap =[];
	$scope.portfolioData = {};
	$scope.fundDetails = [];
	$rootScope.preloaderCheck=true;
	
	var loadPortfolioData = function() {
		
		return ajaxHttpFactory.getJsonData("getPortfolioJson",$location.absUrl())
		.then(function(response) {
			$rootScope.preloaderCheck=false;

			if(!ajaxHttpFactory.handleIPruException(response.data, "errorMessage-popup")){
				if (response != null && response.data != null && response.data != "null") {
					var portfolioDataPO = response.data;
					$scope.portfolioData = portfolioDataPO;
					$scope.portfolioData.navDate= new Date($scope.portfolioData.navDate);					
					$scope.fieldAccessMappingMap = $scope.portfolioData.fieldAccessMappingMap;
					$scope.fundDetails = $scope.portfolioData.fundDetails;
					$rootScope.preloaderCheck=false;
				}
				
			}
		}, 
		function(response) {
			$rootScope.preloaderCheck=false;
			//alert("In failureMethod");
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
				
			}			
		});	
	};
	
	loadPortfolioData();
	
	$scope.validateFields = function(id,action)  
	{
      
		$scope.id=id;
		$scope.action=action;
		$scope.result = validateFieldService.fieldValidate($scope.id,$scope.action,$scope.fieldAccessMappingMap);
		return $scope.result;
		
	};
	
}]);
