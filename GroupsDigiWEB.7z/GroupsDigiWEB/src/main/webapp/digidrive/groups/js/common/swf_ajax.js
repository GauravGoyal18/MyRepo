/* Exception Handling */
var pasaFlow;
var data;
var obj;
var iosFlag;
var cookieName="icicipru_source_tracker";
function errorhandler(status) {

	if (status === 404) {
		Ext.Msg.alert("Error", "The Page you are seeking does not exist!");
	}
	if (status === 403)
		Ext.Msg.alert("Error",
				"Operation could not be carried out successfully");
	if (status === 500)
		Ext.Msg.alert("Error",
				"Operation could not be carried out successfully");
	if (status === 200)
	{

	}
	return;
}

/* Exception Handling End */

var SimpleRequestJquery = function(targetElementId, url, method, parameters) {
 	//var targetElement = targetElementId;
 	//alert(url);
 	if (targetElementId == null) {
 		throw 'Target element is null!';
 	}
 	if (url == null) {
 		throw 'URL has to be provided';
 	}
 	if (method == null) {
 		method = 'get';
 	} else if (method != 'get' && method != 'post') {
 		throw 'Method should be get or post';
 	}
 	
 	jQuery(targetElementId).css("min-height","50px");
 	
 	//blockUI('Please Wait...');
 	//making a sync ajax call
 	/*jQuery('#' + targetElementId).innerHTML=*/ $.ajax({
 	    type: "GET",
 	    url: url,
 	    async: true,
 	    success : function(data, textStatus, jqXHR) {
 	    	jQuery('#' + targetElementId).html(data);
 	    	//$.unblockUI();
 		}
 	});

 	
 };

var SimpleRequest = function(targetElementId, url, method, parameters) {
	if (targetElementId == null) { 
		throw 'Target element is null!';
	}
	if (url == null) {
		throw 'URL has to be provided';
	}
	if (method == null) {
		method = 'get';
	} else if (method != 'get' && method != 'post') {
		throw 'Method should be get or post';
	}
	
	jQuery(targetElementId).css("min-height","50px");
	
	block('Please Wait...');
	jQuery('#' + targetElementId).load(url,function(response,status,xhr) 
     {
		if(status=='success')
		{
			unblock();
		}
		if(status=='error'){
			unblock();
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
		}
		else if(status=='timeout'){
			unblock();
		}
		
	 });
};
var SimpleRequestCallBack = function(targetElementId, url, method, parameters,callBackFunc) {
	
	if (targetElementId == null) {
		throw 'Target element is null!';
	}
	if (url == null) {
		throw 'URL has to be provided';
	}
	if (method == null) {
		method = 'get';
	} else if (method != 'get' && method != 'post') {
		throw 'Method should be get or post';
	}
	parent.$('#'+targetElementId).css("min-height","50px");
	
	block('Please Wait...');
	parent.jQuery('#'+targetElementId).load(url,function(response,status,xhr) {
		if(status=='success')
		{
			unblock();
		}
		if(status=='error'){
			unblock();
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
		}
		else if(status=='timeout')
		{
			unblock(); 
		}
		callBackFunc(response);
		});
};
var SimpleRequestCallBackForHealthQuestions = function(targetElementId, url, method, parameter1,parameter2,parameter3,callBackFunc) {
	
	if (targetElementId == null) {
		throw 'Target element is null!';
	}
	if (url == null) {
		throw 'URL has to be provided';
	}
	if (method == null) {
		method = 'get';
	} else if (method != 'get' && method != 'post') {
		throw 'Method should be get or post';
	}
	parent.$('#'+targetElementId).css("min-height","50px");
	
	block('Please Wait...');
	parent.jQuery('#'+targetElementId).load(url,function(response,status,xhr) {
		if(status=='success')
		{
			unblock();
			
			$("#healthQuestionsEditable_new").html("<h4>Life Assured Health Details</h4>");
			/*if (appInfo !=undefined && appInfo.assure.select == "SELF")
 			{
 				$("#healthQuestionsEditable_new").html("<h4>Proposer Health Details</h4>"); 			
 			}
 			else
 			{
 				$("#healthQuestionsEditable_new").html("<h4>Life Assured Health Details</h4>");
 			}*/
		}
		if(status=='error'){
			unblock();
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
		}
		else if(status=='timeout')
		{
			unblock(); 
		}
		callBackFunc(parameter1,parameter2,parameter3);
		});
};

var CsrSimpleRequestCallBack = function(targetElementId, url, method,callBackFunc) {
	
	if (targetElementId == null) {
		throw 'Target element is null!';
	}
	if (url == null) {
		throw 'URL has to be provided';
	}
	if (method == null) {
		method = 'get';
	} else if (method != 'get' && method != 'post') {
		throw 'Method should be get or post';
	}
	parent.$('#'+targetElementId).css("min-height","50px");
	
	parent.jQuery('#'+targetElementId).load(url,function(response,status,xhr) {
		//alert("Status:::"+status); 
		
		if(status=='error'){
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
		}
		else if(status=='timeout')
		{/* alert("Timeout"); */ 
		}
		else {
			callBackFunc();
		}
		
		});
};


var formelementid;
var event_type;
var buttonid1;
var aysnchmode = 0;


var formelementid;
var event_type;
var buttonid1;
var aysnchmode = 0;
function formRequest(formElementId, buttonid, aysnchMode, eventtype) {
	
	//making url for submit
	var formElement = document.getElementById(formElementId);
	var url = formElement.action;
	url = url + "&_eventId=" + buttonid;
	
	
	
	jQuery.ajax({ // create an AJAX call...
		data : jQuery(formElement).serialize(), 
		type : jQuery(this).attr('method'), 
		url : url, 
		success : function(data, textStatus, jqXHR) {
			secs=sessionTime;
			if (aysnchMode == 2){
				$('#'+formElementId).html(data);
				
			}
			

		},

		error : function(data, textStatus, jqXHR) {
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
			if (returntype == true) {
				errorhandler(response.status);
			} else if (returntype == false) {
				errorhandlerJson(response.status);
			}

		}
	});
}



function formRequestCalculators(formElementId, buttonid, aysnchMode, succesCallBack) {
	
	//making url for submit
	var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"Saving Data..."},{align:'center'});
	myMask.show();
	var formElement = document.getElementById(formElementId);
	var url = formElement.action;
	url = url + "&_eventId=" + buttonid;
	
	
	
	jQuery.ajax({ // create an AJAX call...
		data : jQuery(formElement).serialize(), 
		type : jQuery(this).attr('method'), 
		url : url, 
		success : function(data, textStatus, jqXHR) {
			secs=sessionTime;
			succesCallBack();
			myMask.hide();
			

		},
	
		error :function(data, textStatus, jqXHR){
			myMask.hide();
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
			if (returntype == true) {
				errorhandler(response.status);
				
			} else if (returntype == false) {
				errorhandlerJson(response.status);
			}

		}
	});


}



function formRequestPdf(formElementId, buttonid, aysnchMode, eventtype) {
	var contextpath=getContextPath();
	//making url for submit
	var formElement = document.getElementById(formElementId);
	var url = formElement.action;
	url = url + "&_eventId=" + buttonid+"&IllustrationFlag="+"true";
	
	
	
	$.ajax({ // create an AJAX call...
		data : $(formElement).serialize(), 
		type : 'post', 
		url : url, 
		success : function(data, textStatus, jqXHR) { 
					
			//secs=sessionTime;
			//alert(data);
			var response=jQuery.parseJSON(data);
			if(response.ErrorCode=="E00")
				{
				var storyCode="";
				var d=new Date();
				if(response.PremiumSummary != null || response.PremiumSummary != undefined){
					var ProductCode=response.PremiumSummary.ProductCode;
					
					if(response.PremiumSummary.StoryCode!=null && response.PremiumSummary.StoryCode!="" && response.PremiumSummary.StoryCode!=undefined) 
						{
						 storyCode=response.PremiumSummary.StoryCode;
						}
					
					if(ProductCode=="E11" || ProductCode=="ULA1" || ProductCode=="UA1" || ProductCode=="UA2" || ProductCode=="ULA4" ||
							ProductCode=="UA3"  || ProductCode=="UA4" || ProductCode=="UA5" || ProductCode=="UA6"|| ProductCode=="ULA5" ||
							storyCode=="AY" || storyCode=="AZ" || storyCode=="BA" ||storyCode=="AW" || ProductCode=="E12"
								|| storyCode=="BB" || storyCode=="BC"  || storyCode=="BE" || ProductCode=="T82" || ProductCode=="E15" || ProductCode=="E16" || ProductCode=="E18" || ProductCode=="U98" || ProductCode=="U99"
									|| ProductCode=="T34" || ProductCode=="T35" || ProductCode=="T36" || ProductCode=="T37" || ProductCode=="T38" || ProductCode=="T39" || ProductCode=="T41"|| ProductCode=="I12"|| ProductCode=="U96"|| ProductCode=="U97" || ProductCode=="I05" || ProductCode=="T26" || ProductCode=="T27" || ProductCode=="E10"|| ProductCode=="ULA8" || ProductCode=="UA8"||ProductCode=="UA9"
									|| ProductCode=="T24" || ProductCode=="T25")
						{
						
						}
					else
						{
						getContextAndCall();
						}
					
					
				
				
				}else if(response.PremiumSummary1!=null && response.PremiumSummary1!="" && response.PremiumSummary1!=undefined){
				
					storyCode=response.PremiumSummary1.StoryCode;
					if(storyCode=="AY" || storyCode=="AZ" || storyCode=="BA" || storyCode=="BB" || storyCode=="BC" || storyCode=="BE" || storyCode=="AX" || storyCode=="AW" || storyCode=="AV" || storyCode=="BH" || storyCode=="BF" || storyCode=="BI" || storyCode=="BJ" || storyCode=="BK" || storyCode=="BN" || storyCode=="BL" || storyCode=="BM" || storyCode=="BT" || storyCode=="BS" || storyCode=="BQ" || storyCode=="BR" || storyCode=="BU" || storyCode=="BW")
					{
					
					}
				else
					{
					getContextAndCall();
					}
				
				}
					
				//generatedEbi();
				//myMask.hide();
			//	myMaskForPdf.hide();
				}
			else
				{
				alert(response.ErrorMessage);
			//	myMaskForPdf.hide();
				}
		},

		error : function(response) {
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
			myMaskForPdf.hide();
		}
	});
	return false; 
}
function getContextAndCall(LAPDFflag)
{

	var contextpath=getContextPath();
	var d=new Date();
	var url;
	if(LAPDFflag=="LA")
		url = '/'+contextpath+'/PDFGeneratorCommon.pdf?randomKey='+d.getTime();
	else
		url = '/'+contextpath+'/PDFGenerator.pdf?randomKey='+d.getTime();
	if(typeof iosFlag!='undefined' && iosFlag=='true')
		{
			document.getElementById('pdfForm').action = url;
			$('#pdfForm').submit();
		}
	else
		{
		//window.location.href = url;
		myWindow=window.open(url,'','width=700,height=700,resizable=yes');
		}
}
/*Srashti - Added for cashflow pdf - Start*/
function openCashFlowPdf()
{
	calcAttachConstant.cashFlowClicked = false;
	var sequenceNo = calcAttachConstant.seqNo;
	var contextpath=getContextPath();
	var d=new Date();
	var url;
	url = '/'+contextpath+'/PDFGenerator.pdf?randomKey='+d.getTime()+'&iAttach=true&sequenceNo='+sequenceNo;
	if(typeof iosFlag!='undefined' && iosFlag=='true')
		{
			document.getElementById('pdfForm').action = url;
			$('#pdfForm').submit();
		}
	else
	{
		jQuery.ajax({ // create an AJAX call...
			data : {}, 
			type : 'POST', 
			url :url , 
			success : function(data, textStatus, jqXHR) { 
				if(jqXHR.status=="200"){
					myWindow=window.open(url,'','width=700,height=700,resizable=yes');
				}
				else if(jqXHR.status=="0"){
					alert("Cash Flow PDF is not available.");
				}
			},
			error :function(response){
				alert("Cash Flow PDF is not available.");
			}
		});
	}
}
/*Srashti - Added for cashflow pdf - End*/

function getContextAndCallForPdf_PS(pdf)
{

	var contextpath=getContextPath();
	var d=new Date();
	var url = '/'+contextpath+'/PSPDFGenerator.pdf?randomKey='+d.getTime()+"&printPdf="+pdf;
	if(typeof iosFlag!='undefined' && iosFlag=='true')
		{
			document.getElementById('pdfForm').action = url;
			$('#pdfForm').submit();
		}
	else
		{
			myWindow=window.open(url,'','width=700,height=700,resizable=yes');
		}
}
function setIOSFlag(value)
{
	iosFlag = value;
}

function setMobTabAppFlag(appFlag) {
	
	var url = "setSessionDevice.htm?deviceFlag="+appFlag;
		
		 $.ajax({
			method: "GET",
			url: url,
			data: {  }
			})
			.done(function( msg ) {
			//alert(msg);
			})
			.fail(function() {
 			 }); 
	}

function getContextPath()
	{
		var contextpath=window.location.pathname.split('/');
		return contextpath[1];
	}
//for individual pdfs
function downLoadIndividualPDF(code,pdfFlag){
	var contextpath=getContextPath();
	var url='/'+contextpath+'/generateExistingPdf.htm';
	jQuery.ajax({ // create an AJAX call...
		data : {
			
			'Code':code,
			'PdfFlag':pdfFlag
				}, 
		type : 'get', 
		url :url , 
		success : function(data, textStatus, jqXHR) { 
			var response=jQuery.parseJSON(data);
				var d=new Date();
			if(response.ErrorCode=="E00"){
				getContextAndCall();
			}
			else{
				alert(response.ErrorMessage);
			}
		},
	
		
		error :function(response){
			
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
		
		}
	});
}
function downLoadIntegratedProductPDF(code,pdfFlag){
	var contextpath=getContextPath();
	var url='/'+contextpath+'/generateIntegratedProductPdf.htm';
	jQuery.ajax({ // create an AJAX call...
		data : {
			
			'Code':code,
			'PdfFlag':pdfFlag
				}, 
		type : 'get', 
		url :url , 
		success : function(data, textStatus, jqXHR) { 
			var response=jQuery.parseJSON(data);
				var d=new Date();
			if(response.ErrorCode=="E00"){
				myWindow=window.open('/'+contextpath+'/PDFGenerator?randomKey='+d.getTime(),'','width=700,height=700');
			}
			else{
				alert(response.ErrorMessage);
			}
		},
	
		
		error :function(response){
			
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
		
		}
	});
	
	
}

function openPDF(formElementId, buttonid, aysnchMode, eventtype) {
		
		
		
	var contextpath=getContextPath();
		//making url for submit
		var formElement = document.getElementById(formElementId);
		var url = formElement.action;
		url = url + "&_eventId=" + buttonid+"&IllustrationFlag="+"true";
		
		
		
		$.ajax({ // create an AJAX call...
			data : $(formElement).serialize(), 
			type : 'post', 
			url : url, 
			timeout:calcCommonConstant.TIMEOUTPERIOD,
			success : function(data, textStatus, jqXHR) { 
				var LAPDFflag = "INEO";
				var productCode=EBIInputJson.ProductCode_PreEbi;
				var getPDFFromLA =calcCommonConstant.EBIPDF_FROM_LA.indexOf(productCode)
				if(getPDFFromLA != -1)
				{
					LAPDFflag = "LA";
				}
				var response=jQuery.parseJSON(data);
				var d=new Date();
				if(response.ErrorCode=="E00")
				{
					if(typeof(calcAttachConstant) !="undefined" && typeof(calcAttachConstant.cashFlowClicked) !="undefined" && calcAttachConstant.cashFlowClicked){
						openCashFlowPdf(); // For Cashflow Pdf
					} else {
						if(response.PremiumSummary != null || response.PremiumSummary != undefined){

							getContextAndCall(LAPDFflag);
						}else{
							getContextAndCall(LAPDFflag);
						}
					}
				}
				else
				{
					alert(response.ErrorMessage);
					//	myMaskForPdf.hide();
				}
			},

			error : function(xhr, ajaxOptions, thrownError) {
				if(ajaxOptions=="timeout") {
					var LAPDFflag = "INEO";
					var value = calcCommonFunction.checkForIneoPdf();
					if(value == "INEO")
						getContextAndCall(LAPDFflag);
					else
						alert(value);
				} 
				else 
				{
					alert("GEN99: Technical Error");
					window.location.href='/'+contextpath+'/error.htm';	
						
				}
			}

				
			//	myMaskForPdf.hide();
			
		});
		return false; 
}

function handlerFunc(transport) {
	var response = transport;
	// alert("response alert: "+response);

	var identifierResponse = response.substring(0, 30);
	var id = response.substring(31);

	if (identifierResponse.trim() == "Response after saving new Lead") {
		if (document.getElementById("leadId_new") != null) {
			document.getElementById("leadId_new").value = id.trim();
			alert("Lead Details have been saved for lead bearing id: " + id);
		}
	}
}

var errFunc = function(transport) {
	errorhandler(transport.status);
};

function handleSubmitEvent2(formElement, buttonid1, elementId) {
	
	var formElement = document.getElementById(formElement);

	if (formElement.tagName.toLowerCase() != 'form') {
		throw 'Element ' + formElement + ' is not a FORM element!';
	}
	var method = formElement.method;

	if (method == null) {
		method = 'get';
	}
	var url = formElement.action; // '${flowExecutionUrl}&_eventId=Submit';
	url = url + "&_eventId=" + buttonid1;// Submit";

	if (url == null) {
		throw 'No action defined on ' + formElement;
	}
	try {
		
		$.ajax({ // create an AJAX call...
			data : $(formElement).serialize(),
			type : $(this).attr('method'),
			url : url,
			success : function(response) {
				secs=sessionTime;
				handlerFunc(response);
				$('#' + elementId).html(response);
				
			},

			error : function(response) {
				alert("GEN99: Technical Error");
				window.location.href="error.htm";
			}
		});

	} finally {
		return false;
	}
};

// Created by Chintan
function handleClickEvent2(formelementid, buttonid1, elementId) {
	var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"Saving Data..."},{align:'center'});
	myMask.show();
	var formElement = document.getElementById(formelementid);// Event.element(event);
	

	if (formElement.tagName.toLowerCase() != 'form') {

		throw 'Element ' + formElement + ' is not a FORM element!';
	}
	var method = formElement.method;

	if (method == null) {
		method = 'get';
	}
	var url = formElement.action; // '${flowExecutionUrl}&_eventId=Submit';
	url = url + "&_eventId=" + buttonid1;// Submit";

	if (url == null) {

		throw 'No action defined on ' + formElement;
	}

	/*if (Ext.isIE) {
		method = 'post';
	}
	if (Ext.isGecko3) {
		method = 'post';
	}
	if (Ext.isChrome) {
		method = 'post';
	}*/
	
	try {
		

		$.ajax({ // create an AJAX call...
			data : $(formElement).serialize(),
			type : 'post',
			url : url,
			success : function(response) {
				secs=sessionTime;
					$('#' + elementId).html(response);
					simpleClose();
					myMask.hide();
			},

			error : function(response) {
				myMask.hide();
				alert("GEN99: Technical Error");
				window.location.href="error.htm";

			}
		});

	} finally {
		return false;
	}
}

function handleClickEventSave(formelementid, buttonid1, callBackFunc) {
	
	//Kindly do not comment this linem if you have any issue contact me(Danesh)
	blockUI('Please Wait...');
	var formElement = document.getElementById(formelementid);// Event.element(event);
	var flagForLead =false;
	if (formElement.tagName.toLowerCase() != 'form') {

		throw 'Element ' + formElement + ' is not a FORM element!';
	}
	var method = formElement.method;

	if (method == null) {
		method = 'get';
	}
	
	
	var url = formElement.action; // '${flowExecutionUrl}&_eventId=Submit';
	url = url + "&_eventId=" + buttonid1;// Submit";
	var timeoutforajax = 30000;
	if(typeof calcCommonConstant != "undefined" && typeof calcCommonConstant.AJAXTIMEOUT != "undefined" && calcCommonConstant.AJAXTIMEOUT != ""){
		timeoutforajax = calcCommonConstant.AJAXTIMEOUT;
	}
	try {
		/*$.when(*/$.ajax({ // create an AJAX call...
			data : $(formElement).serialize(),
			type : 'post',
			url : url,
			async: true,
			timeout: timeoutforajax,
			success : function(response) {
				
				$.unblockUI();
//				secs=sessionTime;
			    flagForLead=callBackFunc(response);
				return flagForLead;
				
			},

			error : function(response) {
				$.unblockUI();
				alert("GEN99: Technical Error");
				window.location.href="error.htm";
				return flagForLead;
			}
		});
		

	}finally {
		
		return flagForLead;
	}
}

/**
 * Use this function for masking purpose in SOL BOL Merger
 * pass the message and it will block the whole UI with the given message.
 * to unblock UI type $.unblockUI();
 * @param message
 */
function blockUI(message)
{
	$.blockUI({ 
//    	message: '<div><b>'+message+'</b><img width=50px  src="merger/img/loading.gif"/></div>',
		message: '<div><b>'+message+'</b></div>',
    	css: { 
        border: 'none', 
        padding: '15px', 
        backgroundColor: '#000', 
        '-webkit-border-radius': '10px', 
        '-moz-border-radius': '10px', 
        opacity: .5, 
        color: '#fff' 
    } }); 

}

/** This is workaround for: BLOCK UI not working due to inclusion of jquery.jpanelmenu.js
 *	Use this function instead of traditional blockUI(message) in you application 
 *  unblock it using unblock() funtion.
 * @param message
 */
function block(message)
{
	$(".jPanelMenu").block({ 
//    	message: '<div><b>'+message+'</b><img width=50px  src="merger/img/loading.gif"/></div>',
		message: '<div style="font-size: 120%;"><b>'+message+'</b></div>',
		allowBodyStretch: true,
		ignoreIfBlocked: true,
    	css: { 
        border: 'none', 
        padding: '15px', 
        backgroundColor: '#000', 
        '-webkit-border-radius': '10px', 
        '-moz-border-radius': '10px', 
        opacity: .5, 
        color: '#fff' 
    } }); 

}

/**
 * Use this function to unblock masking when masked with block(message) funtion.
 */
function unblock(){
	$(".jPanelMenu").unblock();
}
/**
 * This function shows masking to the element of the particular class
 * @param classname
 * @param message
 */
function blockElementByClass(classname,message)
{
	$("."+classname).block({ 
//    	message: '<div><b>'+message+'</b><img width=50px  src="merger/img/loading.gif"/></div>',
		message: '<div><b>'+message+'</b></div>',
    	css: { 
        border: 'none', 
        padding: '15px', 
        backgroundColor: '#000', 
        '-webkit-border-radius': '10px', 
        '-moz-border-radius': '10px', 
        opacity: .5, 
        color: '#fff' 
    } }); 

}

/**
 * This function shows masking to the element of the particular id
 * @param classname
 * @param message
 */
function blockElementByID(idname,message)
{
	$("#"+idname).block({ 
//    	message: '<div><b>'+message+'</b><img width=50px  src="merger/img/loading.gif"/></div>',
		message: '<div><b>'+message+'</b></div>',
    	css: { 
        border: 'none', 
        padding: '15px', 
        backgroundColor: '#000', 
        '-webkit-border-radius': '10px', 
        '-moz-border-radius': '10px', 
        opacity: .5, 
        color: '#fff' 
    } }); 

}

/**
 * This function shows removes masking to the element of the particular class
 * @param classname
 */
function unblockElementByClass(classname)
{
	$("."+classname).unblock(); 

}

/**
 * This function shows masking to the element of the particular id
 * @param classname
 */

function unblockElementByid(classname)
{
	$("#"+classname).unblock(); 
}


function blockalert(message)
{
	$.blockUI({ 
		message: '<div style="font-weight: bold; margin: 10px; font-size: 14px;">'+message+'</div><input type="button" value="ok" onclick="$.unblockUI();">',
		css:{cursor:'default'},
		overlayCSS:{cursor:'default'}
	}); 

}

function blockconfirm(message, okcallback,cancelcallback)
{
	$.blockUI({ 
		message: '<div style="font-weight: bold; margin: 10px; font-size: 14px;">'+message+'</div><input type="button" value="ok" onclick="$.ajax({url: "",cache: false,complete: function() {$.unblockUI();}});"/><input type="button" value="cancel" onclick="$.unblockUI();">',
		css:{cursor:'default'},
		overlayCSS:{cursor:'default'}
	}); 
}
//$.ajax({url: 'wait.php',cache: false,complete: function() {$.unblockUI();}});
function syncSaveFunction(formelementid, buttonid1, callBackFunc) {
	
	blockUI('Please Wait...');
var formElement = document.getElementById(formelementid);// Event.element(event);
var flagForLead =false;
if (formElement.tagName.toLowerCase() != 'form') {

	throw 'Element ' + formElement + ' is not a FORM element!';
}
var method = formElement.method;

if (method == null) {
	method = 'get';
}


var url = formElement.action; // '${flowExecutionUrl}&_eventId=Submit';
url = url + "&_eventId=" + buttonid1;// Submit";

/*if (Ext.isIE) {
	method = 'post';
}
if (Ext.isGecko3) {
	method = 'post';
}
if(Ext.isChrome)
	{
	method = 'post';
	}
*/
if (url == null) {

	throw 'No action defined on ' + formElement;
}

try {
	$.when($.ajax({ // create an AJAX call...
		data : $(formElement).serialize(),
		type : $(this).attr('method'),
		url : url,
		async: false,
		success : function(response) {
			secs=sessionTime;
			$.unblockUI();
		    flagForLead=callBackFunc(response);
			return flagForLead;
			
		},

		error : function(response) {
			$.unblockUI();
			alert("GEN99: Technical Error");
				window.location.href="error.htm";
			return flagForLead;
		}
	})).done(function(){
		return flagForLead;
	});

}finally {
	
	return flagForLead;
}
}

/** *******************newLEad ajax call******************************** */

/* Exception Handling */

function Connect() {
	//alert("inside connect1");
	var req = null;
	try {
		if (window.XMLHttpRequest) {
			//alert("inside connect2");
			secs=sessionTime;
			req = new XMLHttpRequest();
			if (req.overrideMimeType) {
				req.overrideMimeType('text/xml');
			}
		} else if (window.ActiveXObject) {
			try {
				//alert("inside connect3");
				req = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					req = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {
				}
			}
		}
	} catch (e) {
		errHandler(e, 'Connect()', 'commonAgent.js');
	}
	//alert("inside connect4");
	return req;
}

function ajaxFunctionAsync(htmlMethod, string, callBackFunc)
{
	//Ravinder (BRE Time OUT) Start
	var temptimeout=180000;
	if(appInfo!=undefined && appInfo!='undefined' && appInfo!=null)
	{
		var nproducts=appInfo.lst_ProductInfo.length;
		temptimeout=nproducts*40000;
	}
	if(temptimeout<180000)
	{
		temptimeout=180000;
	}
	//Ravinder (BRE Time OUT) End
	
//	var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"Please wait..."},{align:'center'});
	
//	myMask.show();
	blockUI('Please Wait');
	try {
		$.when($.ajax({ // create an AJAX call...
			data : $("#callAppFrmPost").serialize(),
			type :htmlMethod,
			url : string,
			timeout: temptimeout,
			
			success : function(response) {
				secs=sessionTime;
				//alert(response);
				callBackFunc(response);
				$.unblockUI();
			//	setAppFormMask(false);
			//	 myMask.hide();
				
				
			},

			error : function(response) {
			//	setAppFormMask(false);
				//myMask.hide();
				/*$.unblockUI();
				alert("GEN99: Technical Error");
				window.location.href="error.htm";*/
				var errorMsg = '{"breDecision":"1","errorCode":""}';
				callBackFunc(errorMsg);
				$.unblockUI();
				
			}
		})).done(function(){
			//alert("done");
			$.unblockUI();
		});

	}finally {
		//alert("in final close"+flagForLead);
		//myMask.hide();
		
	}
	

}


function ajaxFunction(htmlMethod, string, method) {
	
	var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"Please wait..."},{align:'center'});
	var flagForLead;
	myMask.show();
	try {
		// alert(url);
		 //alert("Data has been saved successfully.");

		$.when($.ajax({ // create an AJAX call...
			//data : $(formElement).serialize(),
			type :'post',
			url : string,
			async: false,
			success : function(response) {
				secs=sessionTime;
				//alert(response);
				 flagForLead=response;
				// alert("In swf"+flagForLead);
				 myMask.hide();
				 return flagForLead;
				
			},

			error : function(response) {
				myMask.hide();
				
				alert("GEN99: Technical Error");
				window.location.href="error.htm";
				return flagForLead;
			}
		})).done(function(){
			//alert("done");
			return flagForLead;
		});

	}finally {
		//alert("in final close"+flagForLead);
		myMask.hide();
		return flagForLead;
	}
	
}
	


	function ajaxFunctionWithCallback(htmlMethod, string, method,callBackFunc,parameters,formElement) {
	//	var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"Please wait..."},{align:'center'});
		//parameters.push(myMask);
		blockUI('Please Wait...');
		var flagForLead;
	//	myMask.show();
		//secs=sessionTime;
		try {
			// alert(url);
			 //alert("Data has been saved successfully.");

			/*$.when(*/$.ajax({ // create an AJAX call...
				data : $(formElement).serialize(),
				
				type :'post',
				url : string,
				async: true,
				success : function(response) {
					$.unblockUI();
					flagForLead=callBackFunc(response,parameters);
				//	 myMask.hide();
					
				},

			error : function(response) {
				//myMask.hide();
				$.unblockUI();
				alert("GEN99: Technical Error");
				window.location.href="error.htm";
			}
				})
		}finally {
			//alert("in final close"+flagForLead);
			//myMask.hide();
			//return flagForLead;
		}
	
	
	}
	
	
	
	function ajaxFunctionWithCallback_ECS(htmlMethod, string, method,callBackFunc,parameters) {
		var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"Please wait..."},{align:'center'});
		//parameters.push(myMask);
		var flagForLead;
		myMask.show();
		//secs=sessionTime;
		
		try {
			// alert(url);
			 //alert("Data has been saved successfully.");

			/*$.when(*/$.ajax({ // create an AJAX call...
				//data : $(formElement).serialize(),
				
				type :'post',
				url : string,
				
				success : function(response) {
					
					flagForLead=callBackFunc(response,parameters);
					 myMask.hide();
					
				},

			error : function(response) {
				myMask.hide();
				
				alert("GEN99: Technical Error");
				window.location.href="error.htm";
			}
				});
		}finally {
			//alert("in final close"+flagForLead);
			//myMask.hide();
			//return flagForLead;
		}
	
	
	}
	
	
	


function ajaxFunctionExtjs(htmlMethod, string, method) {
	var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"Please wait..."},{align:'center'});
	myMask.show();
	// alert("ajax funtion inside");
	var req = Connect();
	 //alert("ajax funtion after connect");
	var response;
	req.onreadystatechange = function() {
		if (req.readyState == 4) {
			// alert("ajax 4 status"+req.responseText);
			if (req.status == 200) {
				response = req.responseText;
				 //alert("ajax 200 status"+req.responseText);
			} else {
				response = null;
			}
		}
	};
	req.open(htmlMethod, string, method);
	req.send(null);
	// Added for Mozilla compatibility
	if (req.readyState == 4) {
		if (req.status == 200) {
			response = req.responseText;
		} else {
			response = null;
		}
	}
	if (response != undefined) {
		//alert("last saved complete");
		myMask.hide();
		return response;
	}
	else
		{
			myMask.hide();
			alert("System Error");
		}
}




function formRequestProfile(formElementId, buttonid, aysnchMode, eventtype) {
	
	
	
	
	//making url for submit
	var formElement = document.getElementById(formElementId);
	var url = formElement.action;
	url = url + "&_eventId=" + buttonid;
	
	
	
	$.ajax({ // create an AJAX call...
		data : $(formElement).serialize(), 
		type :'post', 
		url : url, 
		success : function(data, textStatus, jqXHR) { 
					
			secs=sessionTime;
		
			//myMask.hide();

alert('Successfully Updated');

window.location.href=landingPage+".htm";
		},
	
		error :function(response){
			

			if (returntype == true) {
				errorhandler(response.status);
				
			} else if (returntype == false) {
				errorhandlerJson(response.status);
			}
			
			alert(' Not Successfully Updated');

		}
	});
	return false; 

}

//form request for image viewing
function formRequestImage(url,buttonid,docType, appNo, transactionId) {
	
	
	
	
	//making url for submit
	
	url = url + "&_eventId=" + buttonid+"&documentType="+docType+"&applicationNo="+appNo;
	
	
	
	$.ajax({ // create an AJAX call...
		 
		type : 'post', 
		url : url, 
		success : function(data, textStatus, jqXHR) { 
					
			secs=sessionTime;
			//alert(data);
			var curdate=new Date();
			myWindow=window.open('PreviewImage?date='+curdate,'',' scrollbars=no, location=no, menubar=no, status=no,width=700,height=500');
		},

		error : function() {
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
			myMaskForPdf.hide();
		}
	});
	return false; 

}

function formRequestImageTrsctnId(url,buttonid,docType, appNo, transactionId) {
	
	
	
	
	//making url for submit
	
	url = url + "&_eventId=" + buttonid+"&documentType="+docType+"&applicationNo="+appNo+"&transactionId="+transactionId;
	
	
	
	$.ajax({ // create an AJAX call...
		 
		type : 'post', 
		url : url, 
		success : function(data, textStatus, jqXHR) { 
					
			secs=sessionTime;
			//alert(data);
			var curdate=new Date();
			myWindow=window.open('PreviewImage?date='+curdate,'',' scrollbars=no, location=no, menubar=no, status=no,width=700,height=500');
		},

		error : function() {
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
			myMaskForPdf.hide();
		}
	});
	return false; 

}

function extendSession() {
	//making url for submit
	var contextpath=getContextPath();
	url = "/"+contextpath+"/sessionextend.htm";
	
	$.ajax({ // create an AJAX call...
		 
		type : 'post', 
		url : url, 
		success : function(data, textStatus, jqXHR) { 
					
			secs=sessionTime;
			document.getElementById("sessionExpireBox").style.display="none";
			//alert(data);
		},

		error : function() {
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
			//myMaskForPdf.hide();
		}
	});
	return false; 

}

function formRequestUM(formElementId, buttonid, returnFunc,idPuw) {
	var myMask = new Ext.LoadMask(Ext.get(idPuw), {msg:"Please wait..."},{align:'center'});
	myMask.show();

	//making url for submit
	var formElement = document.getElementById(formElementId);
	var url = formElement.action;
	url = url + "&_eventId=" + buttonid;

	//alert(url);
	/*var myMask = new Ext.LoadMask(Ext.get(formElementId), {msg:"Please wait..."},{align:'center'});
	myMask.show();*/
	$.ajax({ // create an AJAX call...
		data : $(formElement).serialize(), 
		type : 'post', 
		url : url, 
		success : function(response) {
			secs=sessionTime;
			    myMask.hide();
				returnFunc(response);
				
		},
		failure: function(){
			myMask.hide();
		},
		error :function(response){
			alert("System Error");
			myMask.hide();
		}
		
		
	});
	return false; 
}



function ajaxFunctionWithCallbackECS(htmlMethod, string, method,callBackFunc,parameters) {
	//var myMask = new Ext.LoadMask(Ext.get("CentralNewLeadForm"), {msg:"Please wait..."},{align:'center'});
	//parameters.push(myMask);
	var flagForLead;
	//myMask.show();
	//secs=sessionTime;
	try {
		// alert(url);
		 //alert("Data has been saved successfully.");

		/*$.when(*/$.ajax({ // create an AJAX call...
			//data : $(formElement).serialize(),
			
			type :'post',
			url : string,
			async: true,
			success : function(response) {
				
				flagForLead=callBackFunc(response,parameters);
				// myMask.hide();
				
			},

		error : function(response) {
			//myMask.hide();
			
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
		}
			})
	}finally {
		//alert("in final close"+flagForLead);
		//myMask.hide();
		//return flagForLead;
	}


}

function handleClickEventWithMsg(formelementid, buttonid1, callBackFunc,message) {
	
	
	blockUI('Please Wait...');
var formElement = document.getElementById(formelementid);// Event.element(event);
var flagForLead =false;
if (formElement.tagName.toLowerCase() != 'form') {

	throw 'Element ' + formElement + ' is not a FORM element!';
}
var method = formElement.method;

if (method == null) {
	method = 'get';
}


var url = formElement.action; // '${flowExecutionUrl}&_eventId=Submit';
url = url + "&_eventId=" + buttonid1;// Submit";
method = 'post';
/*if (Ext.isIE) {
	method = 'post';
}
if (Ext.isGecko3) {
	method = 'post';
}
if(Ext.isChrome)
	{
	method = 'post';
	}
*/
if (url == null) {

	throw 'No action defined on ' + formElement;
}


try {
	/*$.when(*/$.ajax({ // create an AJAX call...
		data : $(formElement).serialize(),
		type : method,
		url : url,
		async: true,
		success : function(response) {
			$.unblockUI();
			secs=sessionTime;
		    flagForLead=callBackFunc(response);
			return flagForLead;
			
		},
		error : function(response) {
			$.unblockUI();
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
			return flagForLead;
		}
	})/*).done(function(){
		return flagForLead;
	})*/;
	

	}finally {
		
		return flagForLead;
	}
}


function handleClickEventWithStrCallBack(formelementid, buttonid1, callBackFunc,message) {
	
	
	var myMask = new Ext.LoadMask(Ext.getBody(), {msg:message},{align:'center'});
	myMask.show();
var formElement = document.getElementById(formelementid);// Event.element(event);
var flagForLead =false;
if (formElement.tagName.toLowerCase() != 'form') {

	throw 'Element ' + formElement + ' is not a FORM element!';
}
var method = formElement.method;

if (method == null) {
	method = 'get';
}


var url = formElement.action; // '${flowExecutionUrl}&_eventId=Submit';
url = url + "&_eventId=" + buttonid1;// Submit";

if (Ext.isIE) {
	method = 'post';
}
if (Ext.isGecko3) {
	method = 'post';
}
if(Ext.isChrome)
	{
	method = 'post';
	}

if (url == null) {

	throw 'No action defined on ' + formElement;
}


try {
	/*$.when(*/$.ajax({ // create an AJAX call...
		data : $(formElement).serialize(),
		type : method,
		url : url,
		async: true,
		success : function(response) {
			
			myMask.hide();
			secs=sessionTime;
		    flagForLead=window[callBackFunc]();
			return flagForLead;
			
		},

		error : function(response) {
			myMask.hide();
			
			alert("GEN99: Technical Error");
			window.location.href="error.htm";
			return flagForLead;
		}
	})/*).done(function(){
		return flagForLead;
	})*/;
	

}finally {
	
	return flagForLead;
}
}

/**
 * Method to change correct and wrong icon css and show error messages
 * to the corresponding id values passed. 
 * @author VivekGrewal554674(TCS)
 * @param id : Where msg to be shown
 * @param isCorrect : isCorrect decides whether to show correct or wrong icon
 * @param msg : Message to be shown in id
 */
function changeIconWithMsg(id,isCorrect,msg)
{
	if(isCorrect)
		$("#"+id).removeClass('merger_form_row_arrow_wrong').addClass('merger_form_row_arrow_right');
	else
		$("#"+id).removeClass('merger_form_row_arrow_right').addClass('merger_form_row_arrow_wrong');
	$("#"+id).html(msg);
	$("#"+id).show();
}

/**
 * Method to change correct and wrong icon css and show error messages
 * to the corresponding id values passed. 
 * @author VivekGrewal554674(TCS)
 * @param id : Where msg to be shown
 * @param isCorrect : isCorrect decides whether to show correct or wrong icon
 * @param msg : Message to be shown in id
 */
function changeIconWithMsgApp(id,isCorrect,msg)
{
	if(isCorrect)
		$("#"+id).removeClass('merger_app_row_arrow_wrong').addClass('merger_app_row_arrow_right');
	else
		$("#"+id).removeClass('merger_app_row_arrow_right').addClass('merger_app_row_arrow_wrong');
	$("#"+id).html(msg);
	$("#"+id).show();
}

/**
 * Method to change correct and wrong icon css and show error messages
 * to the corresponding id values passed. This can be used for bulk
 * msg change for making all the fields correct.
 * @author VivekGrewal554674(TCS)
 * @param id : Where msg to be shown
 * @param isCorrect : isCorrect decides whether to show correct or wrong icon
 * @param msg : Message to be shown in id
 */
function changeIconWithMsgIdArray(idArr,isCorrect,msg)
{
	for(var i=0;i<idArr.length;i++)
		{
		changeIconWithMsg(idArr[i],isCorrect,msg);
		}
}
/**
 * Reseting all the icons if submit is pressed again.
 * @param divs
 */
function resetIconsWithMsg(divs)
{
	for(var i=0;i<divs.length;i++)
		{
		$("#"+divs[i]).removeClass('merger_form_row_arrow_wrong');
		$("#"+divs[i]).removeClass('merger_form_row_arrow_right');
		$("#"+divs[i]).html('');
		}
}

/**
 * Reseting all the icons if submit is pressed again.
 * @param divs
 */
function resetIconsWithMsgApp(divs)
{
	for(var i=0;i<divs.length;i++)
		{
		$("#"+divs[i]).removeClass('merger_app_row_arrow_wrong');
		$("#"+divs[i]).removeClass('merger_app_row_arrow_right');
		$("#"+divs[i]).html('');
		}
}
var SyncSimpleRequest = function(targetElementId, url,postCallFunc) {
	
	if (targetElementId == null) {
		throw 'Target element is null!';
	}
	if (url == null) {
		throw 'URL has to be provided';
	}
	
	jQuery(targetElementId).css("min-height","50px");
	
	jQuery('#' + targetElementId).load(url,function(response,status,xhr) 
		{
			if(status=='error')
			{
				alert("GEN99: Technical Error");
				window.location.href="error.htm";
			}
			else if(status=='timeout')
			{ 
				
			}
			else
			{
				postCallFunc();
			}
		});
};

function CsrAjaxFunctionWithCallback(htmlMethod, string, method,callBackFunc,parameters) {
		var flagForLead;
		var reqMethod = null;
		if(htmlMethod==null||htmlMethod=='undefined'||htmlMethod==undefined||htmlMethod=='null'){
			reqMethod = 'GET';
		}else {
			reqMethod = htmlMethod.toUpperCase();
		}
		try {
			// alert(url);
			 //alert("Data has been saved successfully.");

			/*$.when(*/$.ajax({ // create an AJAX call...
				//data : $(formElement).serialize(),
				
				type :reqMethod,
				url : string,
				async: true,
				success : function(response) {
					
					flagForLead=callBackFunc(response,parameters);
				//	 myMask.hide();
					
				},

			error : function(response) {
				//myMask.hide();
				
				alert("GEN99: Technical Error");
				//window.location.href="error.htm";
			}
				})
		}finally {
			//alert("in final close"+flagForLead);
			//myMask.hide();
			//return flagForLead;
		}
	
	
	}

function openSales_Details(productId) {
	var contextpath=getContextPath();
	//document.getElementById('hidden_salesDetails').click();
	//$(location).attr('href','/'+contextpath+'/salesdataentry.htm?source=newlead');
	$('#SalesData').removeClass("merger_none");
	$('#ebi').addClass("merger_none");
	//blockUIGeneric("load");
	/*jQuery('#SalesData').load('/'+contextpath+'/salesdataentry.htm?source=newlead',function(data){
	//$.unblockUI();
	});*/
	url='/'+contextpath+'/salesdataentry.htm?source=newlead';
	jQuery.ajax({ 
			async: false,
			type : jQuery(this).attr('POST'), 
			url:url,
			success : function(response) {
				$("#"+productId+"_loader_div").unblock();
				 $('#SalesData').append(response);
				// $("#"+productId+"_preEbi").show();
			}
			});
	
	//window.location ='/'+contextpath+'/salesdataentry.htm?source=newlead';

}

function detectBrowserForIpad()
{
	var ua = navigator.userAgent;
	var matches = ua.match(/^.*(iPhone|iPad).*(OS\s[0-9]).*(CriOS|Version)\/[.0-9]*\sMobile.*$/i);
	var flag = false;
	if (matches)
		{
		if(matches[1].toUpperCase()=='IPAD')
			{
			  if (matches[3] === 'CriOS') 
			  {
			  }
			  else 
			  {	  
				 flag = true;
			  }
			}
		}
		return flag;
}

function ajaxFunctionWithCallback_thankyou(htmlMethod, string, method,callBackFunc,parameters,formElement) {
	//	var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"Please wait..."},{align:'center'});
		//parameters.push(myMask);
		blockUI('Please Wait...');
		var flagForLead;
	//	myMask.show();
		//secs=sessionTime;
		try {
			// alert(url);
			 //alert("Data has been saved successfully.");

			/*$.when(*/$.ajax({ // create an AJAX call...
				data : $(formElement).serialize(),
				
				type :'post',
				url : string,
				async: true,
				success : function(response) {
					$.unblockUI();
					flagForLead=callBackFunc(response,parameters);
				//	 myMask.hide();
					
				},

			error : function(response) {
				//myMask.hide();
				$.unblockUI();
				alert("GEN99: Technical Error");
				window.location.href="error.htm";
			}
				})
		}finally {
			//alert("in final close"+flagForLead);
			//myMask.hide();
			//return flagForLead;
		}
	
	
	}
function ajaxFormPost(formelementid, url, callBackFunc) 
{
	//Kindly do not comment this linem if you have any issue contact me(Danesh)
	blockUI('Please Wait...');
	var formElement = document.getElementById(formelementid);// Event.element(event);
	var successFlag =false;
	if (formElement.tagName.toLowerCase() != 'form') {

		throw 'Element ' + formElement + ' is not a FORM element!';
	}
	
	if (url == null) {
		throw 'url  is not a Valid!';
	}
	
	var serializedData =  $('#'+formelementid).serialize();
	try {
		$.ajax({ // create an AJAX call...
			data :serializedData,
			type : 'POST',
			url : url,
			async: true,
			success : function(response) {
				
				$.unblockUI();
			    successFlag=callBackFunc(response);
				return successFlag;
				
			},

			error : function(response) {
				$.unblockUI();
				alert("GEN99: Technical Error");
				window.location.href="error.htm";
				return successFlag;
			}
		});
		

	}finally {
		
		return successFlag;
	}
}
function get_browser(){
    var ua=navigator.userAgent,tem,M=ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || []; 
    if(/trident/i.test(M[1])){
        tem=/\brv[ :]+(\d+)/g.exec(ua) || []; 
        return 'IE '+(tem[1]||'');
        }   
    if(M[1]==='Chrome'){
        tem=ua.match(/\bOPR\/(\d+)/)
        if(tem!=null)   {return 'Opera '+tem[1];}
        }   
    M=M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
    if((tem=ua.match(/version\/(\d+)/i))!=null) {M.splice(1,1,tem[1]);}
    return M[0];
    }

function get_browser_version(){
    var ua=navigator.userAgent,tem,M=ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];                                                                                                                         
    if(/trident/i.test(M[1])){
        tem=/\brv[ :]+(\d+)/g.exec(ua) || [];
        return 'IE '+(tem[1]||'');
        }
    if(M[1]==='Chrome'){
        tem=ua.match(/\bOPR\/(\d+)/)
        if(tem!=null)   {return 'Opera '+tem[1];}
        }   
    M=M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
    if((tem=ua.match(/version\/(\d+)/i))!=null) {M.splice(1,1,tem[1]);}
    return M[1];
    }
function checkBrowserNew()
{
	var browser = get_browser().toUpperCase();
	var browser_version = get_browser_version();
	var browserAllowed=false;
	var userAgent = navigator.userAgent;
	if(browser=='MSIE')
	{
		if(browser_version>8)
		{
			browserAllowed = true;
		}
		else
		{
			browserAllowed = false;
		}
	}
	else if(browser=='FIREFOX')
	{
		if(userAgent.indexOf('Iceweasel')!=-1)
		{
				browserAllowed = false;
		}
		else if(browser_version>13)
		{
			browserAllowed = true;
		}
		else
		{
			browserAllowed = false;
		}
	}
	else if(browser=='CHROME' || browser=='SAFARI' || browser=='IE 11' || browser=='OPERA')
	{
		browserAllowed=true;
	}
	else
	{
		browserAllowed=false;
	}
	return browserAllowed;
}  


/*function ValidateEMail(value)
{
		if(value!="" && value!=undefined && value!=null)
		{
		var regex1 = /^([a-zA-Z0-9])+([_\.]?[a-zA-Z0-9]+)?([_\.]?[a-zA-Z0-9]+)?\@([a-zA-Z0-9\-])+(\.([a-zA-Z]{2,12})){1,2}$/;
			return regex1.test(value);
		}else{
			return false;
		}
}
*/
function ValidateCity(value)
{
		if(value!="" && value!=undefined && value!=null)
		{
			var regex1 = CITY_VALIDATION;
			return regex1.test(value);
		}else{
			return false;
		}
}


function handleClickEventSaveWithErrorDiv(formelementid, buttonid1, callBackFunc, action, errorDivId) {
    //Kindly do not comment this linem if you have any issue contact me(Danesh)
	blockUIGeneric(action);
    var formElement = document.getElementById(formelementid);// Event.element(event);
    var flagForLead =false;
    if (formElement.tagName.toLowerCase() != 'form') {

        throw 'Element ' + formElement + ' is not a FORM element!';
    }
    var method = formElement.method;

    if (method == null) {
        method = 'get';
    }


    var url = formElement.action; 
    // '${flowExecutionUrl}&_eventId=Submit';
    url = url + "&_eventId=" + buttonid1;// Submit";

    try {
        $.ajax({ // create an AJAX call...
            data : $(formElement).serialize(),
            type : 'post',
            url : url,
            async: true,
            success : function(response) {
            	$.unblockUI();
                
//                secs=sessionTime;
                if(!handleCsrAppException(response,errorDivId)){
                	flagForLead = true;
                	callBackFunc(response);
                	
                }
//                flagForLead=callBackFunc(response);
                
                return flagForLead;
                
            },

            error : function(response) {
            	$.unblockUI();
                alert("GEN99: Technical Error");
                window.location.href="error.htm";
                return flagForLead;
            }
        });


    }finally {
    	return flagForLead;
    	
    }

}

//Added by Shashikant for generic function for image change on perticuler action. 
function blockUIGeneric(action)
{
	var contextpath=getContextPath();
	var imageURL='<div><b></b><img src="/SellOnline/merger/img/loader_plus.gif" ></div>';
	
	 if(action == 'save'){
		 imageURL = '<div><b></b><img src=/'+contextpath+'/merger/img/loader_saving.gif></div>';
	 }else if(action == 'load'){
		 imageURL = '<div><b></b><img src=/'+contextpath+'/merger/img/loader_load.gif class="img-responsive"></div>';
	 }else if(action == 'verify'){
		 imageURL = '<div><b></b><img src=/'+contextpath+'/merger/img/loader_veri.gif></div>';
		// imageURL = '<div><b></b><img src=/'+contextpath+'"/merger/img/loader_veri.gif"/></div>';
		 
		 
	 }
	$.blockUI({ 
	 		
		message : imageURL,
    	css: { 
        border: 'none', 
        padding: '15px', 
        backgroundColor: '#fff', 
        '-webkit-border-radius': '10px',  
        '-moz-border-radius': '10px', 
        opacity: .5, 
        color: '#fff' 
    } }); 

} 
//added by tausif for storing cookie data on payment thank you and document upload page
function storeCookieDataPayment(url,buttonid)
{
	//var cookieDate = readCookie(cookieName);
	var token = $("#_tk").val();
	url = url + "&_eventId=" + buttonid;
	$.ajax
	({ 
		type : 'POST', 
		url : url,
		data: {'_tk':token},
		success : function(responseText) 
		{ 
			//returnFunc(responseText);
		},
		error:function (xhr, ajaxOptions, thrownError)
		{   
		    
		} 
		
	});
	
}

function readCookie(name) {
		var nameEQ = name + "=";
		var tempCookie="";
		var finalCookie="";
		//alert("nameEQ :::"+nameEQ)
		var ca = document.cookie.split(';');
		//alert("ca :::"+ca);
		for(var i=0;i < ca.length;i++) {
			//alert("ca length:::"+ca.length);
			//alert("inside for loop of readcookie");
			var c = ca[i];
			//alert("c :::"+c)
			while (c.charAt(0)==' ') c = c.substring(1,c.length);
			//alert("c after while :::"+c);
			if (c.indexOf(nameEQ) == 0){
				//alert("inside if loop of readcookie :::");
				tempCookie=c.substring(nameEQ.length,c.length);
				finalCookie=tempCookie.replace("%7C", "|");
				finalCookie=finalCookie.replace("%3B", ";");
				finalCookie=finalCookie.replace("%3B", ";");
				if(document.getElementById("hidden_cookieData")!=null && document.getElementById("hidden_cookieData")!=undefined)
				document.getElementById("hidden_cookieData").value=finalCookie;
				//alert("hidden cookie data value :::"+document.getElementById("hidden_cookieData").value);
				//alert("Return Value:::"+c.substring(nameEQ.length,c.length));
				return finalCookie;
			}
		}
		return null;
}
//added by tausif for storing cookie data on payment thank you and document upload page
//added by tausif for lead conversion code
/*Commented by Aakash for Conversion Code on App Form*/
/*function conversioncode()
{
	var gcc = new Image();
    var rand_time = (new Date()).getTime();
    var productLabel = getLeadConversionCode();
    gcc.src='//www.googleadservices.com/pagead/conversion/964212897/?label='+productLabel+'&amp;guid=ON&amp;script=0&rand_time='+rand_time;
}
function getLeadConversionCode()
{
	var leadConversionLabel='';
	if(productId_merger=='E10')//cash advantage
	{
		leadConversionLabel = 'vf81CMentwUQofHiywM';
	}
	else if(productId_merger=='U97')//easy retirement
	{
		leadConversionLabel = 'DSpxCK-NtQUQofHiywM';
	}
	else if(productId_merger=='E11'|| productId_merger=='E12')//saving suraksha
	{
		leadConversionLabel = '4ABFCMeKtQUQofHiywM';
	}
	else if(productId_merger=='ULA5' || productId_merger=='ULA6' || productId_merger=='UA5' || productId_merger=='UA6')//Wealth Bulider 2 ULA5,ULA6,UA5,UA6 
	{
		leadConversionLabel = 'FnUOCM_vnAcQofHiywM';
	}
	else if(productId_merger='ULA5')//Income protect
	{
		leadConversionLabel = 'TgFBCMfwnAcQofHiywM';
	}
	else if(productId_merger=='T38' || productId_merger=='T39' || productId_merger=='T41')//icare 2 T38,T39,T41 
	{
		leadConversionLabel = 'QeGxCLf46gcQofHiywM';
	}
	else if(productId_merger=='ULA1' || productId_merger=='ULA2' || productId_merger=='UA1' || productId_merger=='UA2')//elite life 2 ULA1,ULA2,UA1,UA2 
	{
		leadConversionLabel = 'fMlgCP_QoQcQofHiywM';
	}
	else if(productId_merger=='E18')//ASIP E18 
	{
		leadConversionLabel = 'q26LCJ6hvlcQofHiywM';
	}
	else if(productId_merger=='ULA8' || productId_merger=='ULA9' || productId_merger=='UA8' || productId_merger=='UA9')//SKRP new --smart life ULA8,ULA9,UA8,UA9 
	{
		leadConversionLabel = '3RIfCK__owUQofHiywM';
	}
	else if(productId_merger=='ULA3' || productId_merger=='ULA4' || productId_merger=='UA3' || productId_merger=='UA4')//Elite Wealth 2 ULA3,ULA4,UA3,UA4 
	{
		leadConversionLabel = 'cCHCCO_SoQcQofHiywM';
	}
	else if(productId_merger=='T24' || productId_merger=='T25' || productId_merger=='T26' || productId_merger=='T27')//iProtect T24,T25,T26,T27  
	{
		leadConversionLabel = 'i5ClCOe-pQgQofHiywM';
	}
	else if(productId_merger=='T42')//Health Protector T42 
	{
		leadConversionLabel = 'pw78CMfmsQUQofHiywM';
	}
	else if(productId_merger=='U97')//Easy Retirement SP U97 
	{
		leadConversionLabel = 'UGORCIuupFgQofHiywM';
	}
	else if(productId_merger=='E15' || productId_merger=='E16')//Anmol Bachat E15,E16 
	{
		leadConversionLabel = 'gdiiCOm_qVgQofHiywM';
	}
	else if(productId_merger=='U98' || productId_merger=='U99')//GWP U98,U99
	{
		leadConversionLabel = 'k66ZCPD0pVgQofHiywM';
	}
	else if(productId_merger=='T34' || productId_merger=='T35' || productId_merger=='T36' || productId_merger=='T37')//Loan Protect T34,T35,T36,T37 
	{
		leadConversionLabel = '_lkBCPnGqVgQofHiywM';
	}
	else if(productId_merger=='U96' || productId_merger=='U97')//easy retirement
  	{
  		leadConversionLabel='DSpxCK-NtQUQofHiywM';
  	}
	return leadConversionLabel;
}*/
//added by tausif for lead conversion code
/*Commented by Aakash for Conversion Code on App Form - Ends*/

//Added by Aakash for Date Picker Enhancement - Start

function createIndividualDatePicker(id,labelId,isFutureEnabled,dateRange,onSelectFunction)
{
	  
	var contextpath=getContextPath();
	var imgPath="/"+contextpath+"/merger/img/calendar.gif";
	
	if(isFutureEnabled=='false')
	{
		var currentDate = new Date();
		$("#"+id).datepicker({
		onSelect: function(value, ui) {
			var today = new Date(); 
			dob = new Date(value);
			age = (new Date).getFullYear() - ui.selectedYear;
			if(labelId!=null && labelId!=undefined)
				{
				$("#"+labelId).text(age + ' Years');
				}
			validation(id,onSelectFunction());
		},
		showOn: "both",
		changeMonth: true,
		changeYear: true,
		buttonImage: imgPath,
		buttonImageOnly: true,
		autoSize: true,
		maxDate: currentDate,
		yearRange: dateRange
	   	});
	   	$("#"+id).datepicker( "option", "dateFormat", "dd MM, yy" );   	
	   	//$("#"+id).datepicker("setDate", currentDate);
	 }
	 else if(isFutureEnabled=='true')
	 {
	 	var currentDate = new Date();
		$("#"+id).datepicker({
		onSelect: function(value, ui) {
			var today = new Date(), 
			dob = new Date(value), 
			age = (new Date).getFullYear() - ui.selectedYear;
			$("#"+labelId).text(age + ' Years');
			validation(id,onSelectFunction());
		},
		showOn: "both",
		changeMonth: true,
		changeYear: true,
		buttonImage: imgPath,
		buttonImageOnly: true,
		autoSize: true,
		minDate: currentDate,
		yearRange: dateRange
	   	});
	   	$("#"+id).datepicker( "option", "dateFormat", "dd MM, yy" );   	
	   	//$("#"+id).datepicker("setDate", currentDate);
	 }
}

function getDatePicker(id,outputFormat)
{
var value = $("#"+id).val();
if(value!=null && value!="" && value!=undefined)
	{
		var formattedValue = $.datepicker.formatDate(outputFormat, new Date(value));
		return formattedValue;
	}
}

function setDatePicker(id,value,inputFormat,outputFormat)
{
if(value!=null && value!="" && value!=undefined)
	{
		var parsedVal = $.datepicker.parseDate(inputFormat, value);
		var formattedValue = $.datepicker.formatDate(outputFormat,parsedVal);
		$("#"+id).val(formattedValue);
	}
}
//Added by Aakash for Date Picker Enhancement - End


function ValidateEMail(value)
{
		if(value!="" && value!=undefined && value!=null)
		{
			var regex1 = EMAIL_VALIDATION;
			return regex1.test(value);
		}else{
			return false;
		}
}
/* Added by Gaurav/IPRU23667 for Email Validations- - END
 * */
 
 /* Added by arvind for name validation - Start
  * First character must not be spaces, No two spaces together, No more than three consecutive identical char allowed
 **/
 
 function ValidateName(name)
 {
	var regexp = NAME_VALIDATION;
	if (name.search(regexp) == -1)
	{
		return false; 
	}
	else
	{
		return true; 
	}
 }
 
  function ValidateMoreThanThreeConsecutiveIdenticalChar(name)
 {
	var regexp = THREE_CONSEC_IDENTICAL_CHAR_VALIDATION;
	if (name.search(regexp) == -1)
		{
			return true; 
			}
		else{
			return false;
		}
 }
 /* Added by arvind for name validation - End
 * */
  
//added by tausif for lead conversion code
  /*Commented by Aakash for Conversion Code on App Form*/
  /*function conversioncode()
  {
  	var gcc = new Image();
      var rand_time = (new Date()).getTime();
      var productLabel = getLeadConversionCode();
      gcc.src='//www.googleadservices.com/pagead/conversion/964212897/?label='+productLabel+'&amp;guid=ON&amp;script=0&rand_time='+rand_time;
  }
  function getLeadConversionCode()
  {
  	var leadConversionLabel='';
  	if(productId_merger=='E10')//cash advantage
  	{
  		leadConversionLabel = 'vf81CMentwUQofHiywM';
  	}
  	else if(productId_merger=='U97')//easy retirement
  	{
  		leadConversionLabel = 'DSpxCK-NtQUQofHiywM';
  	}
  	else if(productId_merger=='E11'|| productId_merger=='E12')//saving suraksha
  	{
  		leadConversionLabel = '4ABFCMeKtQUQofHiywM';
  	}
  	else if(productId_merger=='ULA5' || productId_merger=='ULA6' || productId_merger=='UA5' || productId_merger=='UA6')//Wealth Bulider 2 ULA5,ULA6,UA5,UA6 
  	{
  		leadConversionLabel = 'FnUOCM_vnAcQofHiywM';
  	}
  	else if(productId_merger='ULA5')//Income protect
  	{
  		leadConversionLabel = 'TgFBCMfwnAcQofHiywM';
  	}
  	else if(productId_merger=='T38' || productId_merger=='T39' || productId_merger=='T41')//icare 2 T38,T39,T41 
  	{
  		leadConversionLabel = 'QeGxCLf46gcQofHiywM';
  	}
  	else if(productId_merger=='ULA1' || productId_merger=='ULA2' || productId_merger=='UA1' || productId_merger=='UA2')//elite life 2 ULA1,ULA2,UA1,UA2 
  	{
  		leadConversionLabel = 'fMlgCP_QoQcQofHiywM';
  	}
  	else if(productId_merger=='E18')//ASIP E18 
  	{
  		leadConversionLabel = 'q26LCJ6hvlcQofHiywM';
  	}
  	else if(productId_merger=='ULA8' || productId_merger=='ULA9' || productId_merger=='UA8' || productId_merger=='UA9')//SKRP new --smart life ULA8,ULA9,UA8,UA9 
  	{
  		leadConversionLabel = '3RIfCK__owUQofHiywM';
  	}
  	else if(productId_merger=='ULA3' || productId_merger=='ULA4' || productId_merger=='UA3' || productId_merger=='UA4')//Elite Wealth 2 ULA3,ULA4,UA3,UA4 
  	{
  		leadConversionLabel = 'cCHCCO_SoQcQofHiywM';
  	}
  	else if(productId_merger=='T24' || productId_merger=='T25' || productId_merger=='T26' || productId_merger=='T27')//iProtect T24,T25,T26,T27  
  	{
  		leadConversionLabel = 'i5ClCOe-pQgQofHiywM';
  	}
  	else if(productId_merger=='T42')//Health Protector T42 
  	{
  		leadConversionLabel = 'pw78CMfmsQUQofHiywM';
  	}
  	else if(productId_merger=='U97')//Easy Retirement SP U97 
  	{
  		leadConversionLabel = 'UGORCIuupFgQofHiywM';
  	}
  	else if(productId_merger=='E15' || productId_merger=='E16')//Anmol Bachat E15,E16 
  	{
  		leadConversionLabel = 'gdiiCOm_qVgQofHiywM';
  	}
  	else if(productId_merger=='U98' || productId_merger=='U99')//GWP U98,U99
  	{
  		leadConversionLabel = 'k66ZCPD0pVgQofHiywM';
  	}
  	else if(productId_merger=='T34' || productId_merger=='T35' || productId_merger=='T36' || productId_merger=='T37')//Loan Protect T34,T35,T36,T37 
  	{
  		leadConversionLabel = '_lkBCPnGqVgQofHiywM';
  	}
  	else if(productId_merger=='U96' || productId_merger=='U97')//easy retirement
  	{
  		leadConversionLabel='DSpxCK-NtQUQofHiywM';
  	}
  	return leadConversionLabel;
  }*/
  //added by tausif for lead conversion code
  /*Commented by Aakash for Conversion Code on App Form - Ends*/
  
  function handleCsrAppException(response, errorDivId) {
	  try
	  	{
	  		if(response!=""&&response!=null&&response!=undefined&&response!='undefined')
	  		{
	  	        var res=JSON.parse(response);
	  	        
	  	        if (res.errorMsg==null||res.errorMsg==undefined) 
	  	        {
	  	            return false;
	  	        }
	  	        else 
	  	        {
	  	        	if($("#"+errorDivId).val()==null||$("#"+errorDivId).val()==undefined||$("#"+errorDivId).val()=='undefined')
	          		{
	  	        		alert(res.errorMsg);
	  	        		return true;
	          		}
	  	        	else
	  	        	{
	  		            $("#"+errorDivId).html(res.errorMsg);
	  		            $("#"+errorDivId).addClass('merger_form_row_arrow_wrong');
	  		            $("#"+errorDivId).show();
	  		            $("#"+errorDivId).focus();
	  	        	}
	  	            return true;
	  	        }
	  		}
	  	}
	  	catch(e)
	  	{
	  	//If response is not of JSON type do nothing
	  	}	
	  	
	  	return false;
}

  function winforSocialLogin(scurl)
  {

  	var contextpath=getContextPath();
  	var url = '/'+contextpath+scurl;
  	myWindow=window.open(url,'','width=700,height=700,resizable=yes');
  	
  }
  
//********************Added by Hiren Sonawala for Security fixes********************************//
  function securedPost(formelementid, buttonid1, callBackFunc, action, errorDivId) {
  	//Kindly do not comment this linem if you have any issue contact me(Danesh)
  	blockUIGeneric(action);
      var formElement = document.getElementById(formelementid);// Event.element(event);
      var flagForLead =false;
      if (formElement.tagName.toLowerCase() != 'form') {

          throw 'Element ' + formElement + ' is not a FORM element!';
      }
      var method = formElement.method;
      var data = null;
      if (method == null) {
          method = 'get';
      }
      //alert("value of csr_isPaymentEnabled =="+csr_isPaymentEnabled);
      if(csr_isPaymentEnabled==true)
      {
      	var queryString=$(formElement).serialize();
          var encyptedQueryString=$.jCryption.encrypt(queryString,passwordnew); 
          data={"jc_param":encyptedQueryString};
      }
      else if(csr_isPaymentEnabled==false)
      {
      	data=$(formElement).serialize();
      }
      else
      {
      	var queryString=$(formElement).serialize();
          var encyptedQueryString=$.jCryption.encrypt(queryString,passwordnew); 
          data={"jc_param":encyptedQueryString};
      }
      
      var url = formElement.action; 
      // '${flowExecutionUrl}&_eventId=Submit';
      url = url + "&_eventId=" + buttonid1;// Submit";

      try {
          $.ajax({ // create an AJAX call...
              data : data,
              type : 'post',
              url : url,
              async: true,
              success : function(response) {
              	$.unblockUI();
                  
//                  secs=sessionTime;
  			
                  if(!handleCsrAppException(response,errorDivId)){
                  	flagForLead = true;
                  	callBackFunc(response);
                  	
                  }
//                  flagForLead=callBackFunc(response);
                  
                  return flagForLead;
                  
              },

              error : function(response) {
              	$.unblockUI();
                  alert("GEN99: Technical Error");
                  window.location.href="error.htm";
                  return flagForLead;
              }
          });


      }finally {
      	return flagForLead;
      	
      }

  }
  //Added by Hiren Sonawala for removing Token add submitting form for Security Fixes of Jcryption
  function securedPostToken(formElementId)
  {
	  if(csr_isPaymentEnabled==true)
	  {
		  $("#"+formElementId+ " > #_tk").remove();
	  }
  }

  //Added by Hiren Sonawala for setting values in form and encrypt Value using Jcryption Security Fixes
  function securedPostValues(formElementId,response)
  {
  	if(csr_isPaymentEnabled==true)
    {
  		$("#"+formElementId+" > #jc_param").val(response);
  	  	var formElement = document.getElementById(formElementId);
  	  	var queryString=$(formElement).serialize();
	  	var encyptedQueryString=$.jCryption.encrypt(queryString,passwordnew); 
	  	$("#"+formElementId+" > #jc_param").val(encyptedQueryString);
    }
  	else
  	{
  		$("#"+formElementId+" > #jc_param").val(response);
  	}
  }

//added by krishna generic back button landing page redirection function start
  function backToLandingPage(landingPage){
  		if(landingPage!=null && landingPage!=undefined && landingPage.trim()!=""){
  			var landingPageUrl=landingPage+".htm";
  			window.location.href=landingPageUrl;
  		}
  }
  // added by krishna generic back button landing page redirection function end


  function closeESignDilog()
  {
  	 $(".ui-dialog-titlebar-close").trigger('click');
  }
  
  function genericAjaxCallWithCallBacks(data,methodType,url,aysncValue,successCallBackfunction,errorCallBackFunction)
{
	$.ajax({ 
            data : data,
            type : methodType,
            url : url,
            async: aysncValue,
            success : function(response) {
            	successCallBackfunction(response);
            },
            error : function(response) {
            	errorCallBackFunction(response);
            }
        });
}