function trackIneoDTM()
{
	$LAB
			.script("//assets.adobedtm.com/d3eeee3af0e71d3e08925a67c3851dbe616793b2/satelliteLib-51e5f7ee0dd387b293e25b0c9833ae2f6c51222d-staging.js")
			.wait(function(){
				track(); });
};
