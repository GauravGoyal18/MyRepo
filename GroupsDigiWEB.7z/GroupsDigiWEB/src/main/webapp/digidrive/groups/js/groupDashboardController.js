var app = angular.module('groupApp', ['uiValidations', 'ajaxUtil', 'ui.materialize', 'validationService', 'generalUtility']);


app.controller('groupDashboardController', ['$rootScope', '$scope', 'ajaxHttpFactory', '$location', 'validateFieldService', '$window', function($rootScope, $scope, ajaxHttpFactory, $location, validateFieldService, $window) {

    $rootScope.preloaderCheck = true;
    $scope.policyDetails = {};
    $scope.accessMappingList = {};
    $scope.fieldAccessMappingMap = [];
    $scope.roleAccessMapList = {};
    $scope.errorArray = [];
    $scope.showModal = false;
    $rootScope.response = '';
    $rootScope.policyDetailJsonString = "";

    var loadDashboardData = function() {
        $rootScope.preloaderCheck = true;
        return ajaxHttpFactory.getJsonData("loadDashboardDetails", $location.absUrl())
            .then(function(response) {
                    $rootScope.preloaderCheck = false;
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
                        if (response != null && response != "null") {
                            var dashboardDetailsPO = response.data;
                            var selectedPolicy = dashboardDetailsPO.selectedPolicy;
                            var policyDetailList = dashboardDetailsPO.policyDetailList;
                            $scope.policyDetailList = policyDetailList;
                            $scope.policyDetails = $scope.policyDetailList[0];
                            //Valid user for switch 
                          
                            $rootScope.SaMemberStatus = response.data;
                            if (angular.isDefined(selectedPolicy)) {
                                for (var j = 0; j < policyDetailList.length; j++) {
                                    if (policyDetailList[j].clientId == selectedPolicy.clientId) {
                                        $scope.policyDetails = policyDetailList[j];
                                    }
                                }
                                $rootScope.isValiUser = selectedPolicy.isValidUser;
                            }
                            

                            if (angular.isDefined($scope.policyDetails.trusteeList) && $scope.policyDetails.trusteeList.length > 1) {
                                $scope.showTrusteeName = true;
                                $scope.trusteeListlength = $scope.policyDetails.trusteeList.length - 1;
                            } else {
                                $scope.showTrusteeName = false;
                            }
                           // $scope.policyDetails.policyCommencementDate = new Date($scope.policyDetails.policyCommencementDate);
                           // $scope.policyDetails.ard = new Date($scope.policyDetails.ard);
                            //					$scope.accessMappingList = $scope.policyDetails.accessMappingList;
                            $scope.fieldAccessMappingMap = $scope.policyDetails.fieldAccessMappingMap;
                            $scope.roleAccessMapList = $scope.policyDetails.roleAccessMapList;

                            if (angular.isDefined($scope.roleAccessMapList[0])) {
                                $scope.accessMappingList = $scope.roleAccessMapList[0].accessMappingList;
                            }

                            $rootScope.preloaderCheck = false;
                        }
                        $rootScope.preloaderCheck = false;
                    } else {
                        $rootScope.preloaderCheck = false;
                    }
                },
                function(response) {
                    //			alert("In failureMethod");
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

                    }
                    $rootScope.preloaderCheck = false;
                });
    };

    loadDashboardData();

    $scope.onChangePolicy = function(policy) {

        $rootScope.preloaderCheck = true;

        $scope.roleAccessMapList = policy.roleAccessMapList;
        $scope.accessMappingList = $scope.roleAccessMapList[0].accessMappingList;
        $scope.roleScreenAccessMapPO = $scope.roleAccessMapList[0];
        $rootScope.isValiUser = policy.isValidUser;
        $scope.onclickTab(0);

        var policyDetailJsonString = angular.toJson(policy);
        var ajaxurl = $location.absUrl();

        ajaxHttpFactory.postJsonDataSuccessFailure(policyDetailJsonString, "POST", ajaxurl, "changePolicyDetails", $scope.changePolicySuccessMethod, $scope.changePolicyFailureMethod);

    };

    $scope.changePolicySuccessMethod = function(response) {
        $rootScope.preloaderCheck = false;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

        }
    };

    $scope.changePolicyFailureMethod = function(response) {
        $rootScope.preloaderCheck = false;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

        }
    };

    $scope.validateFields = function(id, action) {

        $scope.id = id;
        $scope.action = action;
        $scope.result = validateFieldService.fieldValidate($scope.id, $scope.action, $scope.fieldAccessMappingMap);
        return $scope.result;

    };

    $scope.onclickIcon = function(id) {
        $rootScope.response = id;
        /* if(id.isPopUp=="yes")
			 {
			 $scope.showModal=true;
		 }
		 else
			 {*/
        var url = id.screenCode + ".htm";
        if (url != "" && angular.isDefined(url))
            if (url == "switch.htm") {

                if ($rootScope.isValiUser == null) {
                    var ajaxurl = $location.absUrl();
                    ajaxHttpFactory.postJsonDataSuccessFailure("", "POST", ajaxurl, "getIsValidUserForSwitch", $scope.getIsValidUserForSwitchSuccessMethod, $scope.getIsValidUserForSwitchFailureMethod);
                }


                /* $scope.getIsValidUserForSwitchSuccessMethod = function(response) {
	        		        $rootScope.preloaderCheck = true;
	        		        $rootScope.isValiUser= response[0].status;
	        		        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
	        		        	  $rootScope.preloaderCheck = false;
	        		        }
	        		    };*/
                else {

                    if ($rootScope.isValiUser == "Y") {
                        var ajaxurl = $location.absUrl();
                        ajaxHttpFactory.postJsonDataSuccessFailure($rootScope.isValiUser, "POST", ajaxurl, "checkValidUserForSwitch", $scope.getCheckIsValidUserForSwitchSuccessMethod, $scope.getCheckIsValidUserForSwitchFailureMethod);

                    } else if ($rootScope.isValiUser == "N") {
                        $scope.showModal = true;

                    }
                }




                $rootScope.preloaderCheck = false;




            } else {
                if (url == "serviceWebPage.htm") {
                    url = url + "?selectedOption=" + id.displayName;
                }

                $window.location.href = url;

            }


    };

    $scope.getIsValidUserForSwitchSuccessMethod = function(response) {
        $rootScope.preloaderCheck = true;
        var ajaxurl = $location.absUrl();
        $rootScope.isValiUser = response[0].status;
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

            if ($rootScope.isValiUser == "N") {
                $rootScope.preloaderCheck = false;
                $scope.showModal = true;
            } else {
                ajaxHttpFactory.postJsonDataSuccessFailure($rootScope.isValiUser, "POST", ajaxurl, "checkValidUserForSwitch", $scope.getCheckIsValidUserForSwitchSuccessMethod, $scope.getCheckIsValidUserForSwitchFailureMethod);
            }
        }
    };

    $scope.getCheckIsValidUserForSwitchSuccessMethod = function(response) {
        $rootScope.preloaderCheck = true;
        $rootScope.isValiUserForSwitch = response;

        if ($rootScope.isValiUserForSwitch == $rootScope.isValiUser || $rootScope.isValiUser == null) {

            $rootScope.preloaderCheck = false;
            var id = $rootScope.response;
            // $scope.showModal=false;
            var url = id.screenCode + ".htm";
            if (url != "" && angular.isDefined(url))
                $window.location.href = url;
        } else {
            $scope.showModal = true;
            $rootScope.preloaderCheck = false;
        }

    };

    $scope.getIsValidUserForSwitchFailureMethod = function(response) {
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            $rootScope.preloaderCheck = false;
        }
    };

    $scope.getCheckIsValidUserForSwitchFailureMethod = function(response) {
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            $rootScope.preloaderCheck = false;
        }
    };

    $scope.OK = function() {


        $scope.showModal = false;



    };

    $scope.CANCEL = function() {
        $scope.showModal = false;
    }



    $scope.onclickTab = function(id) {

        var roleAccessList = $scope.roleAccessMapList;

        for (var i = 0; i < roleAccessList.length; i++) {
            $('#tab_a_' + i).removeClass('active');
        }

        // $('#tab_a_0').removeClass('active');
        $('#tab_a_' + id).addClass('active');
        if (angular.isDefined($scope.roleAccessMapList[id])) {
            $scope.accessMappingList = $scope.roleAccessMapList[id].accessMappingList;
        }
    };




    $scope.validateTrusteeName = function(id, action) {
        var showField = $scope.validateFields(id, action);
        if (angular.isDefined($scope.policyDetails.trusteeList) && $scope.policyDetails.trusteeList.length > 1) {
            return showField;
        } else {
            return false;
        }
    };

}]);