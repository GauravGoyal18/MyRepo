var app=angular.module('groupApp',['ui.materialize','uiValidations','ajaxUtil','ngRoute','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection','groupCommonUtil']);

app.controller('switchTrackerController',['$rootScope','$scope','ajaxHttpFactory','$location','$window','$filter','$http','$rootScope','uiGridConstants','csrDocUploadFactory', function($rootScope,$scope,ajaxHttpFactory,$location,$window,$filter,$http,$rootScope,uiGridConstants,csrDocUploadFactory){
	
	$rootScope.preloaderCheck=true;
	$scope.trackType=[];
	$scope.trackStatus=[];
	$scope.logs={};
	$scope.errorArray=[];

	$scope.successResponse='';
	var ajaxurl=$location.absUrl();
	$scope.result=[];
	$scope.switchTrackerOpenView={};
	$scope.switchTrackerOpenData=[];
	$scope.switchTrackerOpenViewDiv=false;
	
	
	
	 $scope.openClosed="openClose";
	 var paginationOptions = {
			    pageNumber: 1,
			    pageSize: 10,
			    sort: null
			  };
	 
	 
	var onLoadData=function(){			
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("switchLoadTacker",ajaxurl)
		.then(function(bizRes){	
			
			if(ajaxHttpFactory.handleIPruException(bizRes.data, "errorMessage-popup", "exceptionAlert")){
				
							
				$rootScope.preloaderCheck=false;
			}			
			var responseData = bizRes.data;
			$scope.switchTrackerOpenData=responseData;
			$scope.switchTrackerOpenView.totalItems=$scope.switchTrackerOpenData.length;

			
			$scope.switchTrackerOpenViewDiv=true;
			
			$scope.getPageOC();
			
			$rootScope.preloaderCheck=false;					
		},
		function(errResponse){
			$rootScope.preloaderCheck=false;
			if(ajaxHttpFactory.handleIPruException(bizRes.data, "errorMessage-popup", "exceptionAlert")){
						
			}
		});
};
	
onLoadData();
	

$scope.getPageOC = function() {
	 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
    $scope.switchTrackerOpenView.data=$scope.switchTrackerOpenData.slice(firstRow, firstRow + paginationOptions.pageSize);	     
   
	};

	 
	 $scope.switchTrackerOpenView = {			 				
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,			   
			    enableRowSelection: false,		      	     
		        resizable: false,
		        enableColumnResizing: false,
		        enableSorting: false,		       
		        
			    columnDefs: [
			      { field: 'switchTransactionId', displayName: 'TRANSACTION ID',headerTooltip:function(col){return col.displayName;}, width: "15%"},
			      { field: 'fromFundCode',cellTooltip:function(row){ return row.entity.fromFundCode;}, displayName: 'FROM FUND NAME',headerTooltip:function(col){return col.displayName;}, width: "30%"},
			      { field: 'toFundCode', cellTooltip:function(row){ return row.entity.toFundCode;}, displayName: 'TO FUND NAME',headerTooltip:function(col){return col.displayName;}, width: "34%"},
			      { field: 'switchType', displayName: 'TYPE OF SWITCH',cellTemplate:'<div>{{row.entity[col.field].substring(0,1).toUpperCase()+row.entity[col.field].substring(1)}}</div>',headerTooltip:function(col){return col.displayName;}, width: "14%"},
			      { field: 'fromUnit', displayName: 'UNITS',headerTooltip:function(col){return col.displayName;}, width: "9%"},
			      { field: 'fromNAV', displayName: 'NAV',headerTooltip:function(col){return col.displayName;}, width: "10%"},
			      { field: 'fromAmount', displayName: 'AMOUNT',headerTooltip:function(col){return col.displayName;}, width: "10%"},
			      { field: 'totalFundSwitchValue', displayName: 'TOTAL FUND SWITCH VALUE',headerTooltip:function(col){return col.displayName;}, width: "22%"},
			      { field: 'totalFundValue', displayName: 'TOTAL FUND VALUE',headerTooltip:function(col){return col.displayName;}, width: "17%"},			     			    
			      { field: 'reqExecutionDate', displayName: 'REQUEST DATE',headerTooltip:function(col){return col.displayName;}, width: "14%"},
			      { field: 'status', displayName: 'STATUS',headerTooltip:function(col){return col.displayName;}, width: "10%"}
			     
			     	      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageOC();
			      });			      			 
			    }
			  };
	 
	
	
		
		
	
	



	
	$scope.dataAlert= function (){
		$rootScope.openAlertID = false;											
		$window.location.href = "dashboard.htm";
	};


	$scope.successMethod = function(bizRes) {		
		if(!ajaxHttpFactory.handleIPruException(bizRes, "errorMessage-popup", "exceptionAlert")){					
			$scope.result=bizRes;
			$rootScope.preloaderCheck=false;
		}
	};
		
	$scope.failureMethod = function(bizRes) {
		if(!ajaxHttpFactory.handleIPruException(bizRes, "errorMessage-popup", "exceptionAlert")){			
			$rootScope.preloaderCheck=false;
		}
	};	
    
	
	
	
	
}]);