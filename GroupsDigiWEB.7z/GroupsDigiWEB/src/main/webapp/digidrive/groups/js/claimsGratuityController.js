
var app = angular.module('groupApp', ['ajaxUtil','uiValidations','ui.materialize','ngTouch','groupCommonUtil']);

app.controller('claimsGratuityController',['$scope','$location','ajaxHttpFactory','$rootScope','$window','csrDocUploadFactory','$http','$filter', function($scope,$location,ajaxHttpFactory,$rootScope,$window,csrDocUploadFactory,$http,$filter){ 


       $scope.errorArray=[];     
       $rootScope.preloaderCheck=false;
       $scope.disableAddLeave=[];
       $scope.disableAddLeave[0]=false;
       $scope.disableDeleteLeave=[];
       $scope.disableDeleteLeave[0]=false;
       
       $scope.disableAllField=true;
       
       $scope.disablewithDrawalUnit=[];
       $scope.disablewithDrawalUnit[0]=false;
       $scope.showDropdown=true;
      // $scope.showCommanFields=false;
       $scope.showDeathFields=false;
       $scope.showLeaveTaken=true;
       $scope.showNextButton1=true;
       $scope.showNextButton2=false;
       $scope.showBenificiary=false;
       $scope.showAppointeeDetails=false;
       $scope.showWithDrawalUnits=false;
       $scope.showPaymentDetails=false;
       $scope.showModal = false;
       $scope.showPreviewPage=false;
       $scope.previewPageField=true;
       $scope.count=0;
       $scope.leaveCount=[];
       $scope.leaveCount[0]=0;
       $scope.withdrawalUnitCount=[];
       $scope.withdrawalUnitCount[0]=0;
       $scope.showAddButton=[];
       $scope.totalPercentage=0;
      
       $scope.showAddButton[0]=[];
       $scope.ajaxurl=$location.absUrl();
       $scope.state=[];
       $scope.cityDetails=[];
       $scope.cityList=[];
       $scope.showHtmlPage=false;
       $scope.withrawalArray=[];
       
  
       $scope.leaveArray=[];
       $scope.leaveArray.push('leave_0');
       $scope.withdrawalUnit=[];
       $scope.withdrawalUnit.push('withdraw_0');
       $scope.withdrawalErrorArray=[];
    
       
      
       $scope.claimsGratuityJson={};
       $scope.claimsGratuityJson.leaveArray=[];
      // $scope.claimsGratuityJson.benificiary=[];
       $scope.claimsGratuityJson.withdrawalUnit=[];
       $scope.disablePolTruNameEmpName=false;
       $scope.showPolicyEmpId=true;
       $scope.previewClaimsGratuityJson={}
       $scope.disablePolicyNumber=true;
       $scope.showDeathDocument=false;
       
      
       
       
       
       
       
       $scope.removeError=function()
   	{
   		
   	 	   var count = Object.keys($scope.claimsGratuityJson).length;
   	 	   for(var key in $scope.claimsGratuityJson )
   	 	   {
   	 		   var error = "#"+key;
   	 		   var other = key;
   	 		   var currentElement = angular.element(error);
   	 		   currentElement.removeClass('#invalid1');
   	 		   $('error_errMsg').css("visibility", "");
   	 	   		
   	 		   for (var j = 0; j < $scope.errorArray.length; j++)
   	 	   		{
   	 			   if ($scope.errorArray[j] == other) 
   	 			   { 
   	 				   $scope.errorArray.splice(j, 1);
   	 				   break;
   	 			   }
   	 	   		}
   	 	   					
   	         }
   	};
       
       //Extra Code Started
       $scope.submitPolEmp=function()
       {
     		   
    		 /*  if($scope.checkBasicFieldValidations())
    		   {*/
    	   if($scope.previewClaimsGratuityJson.memberIdPreview=='' || $scope.previewClaimsGratuityJson.memberIdPreview==undefined)
    		   {
    		   var currentElement = angular.element( document.querySelector('#memberIdPreview'));
               currentElement.addClass('invalid1');
                $('#memberIdPreview_errMsg').css("visibility",'visible');
    		   }
    	   else
    		   {
    		   $rootScope.preloaderCheck=true;
    		  
    		   $scope.previewClaimsGratuityJson.memberId=$scope.previewClaimsGratuityJson.memberIdPreview;
  	         var policyEmpIDJsonSubmit=angular.toJson($scope.previewClaimsGratuityJson);
  	         var ajaxurl=$location.absUrl();  //
  	         
  	         

  	           ajaxHttpFactory.postJsonDataSuccessFailure(policyEmpIDJsonSubmit,"POST",ajaxurl,"polEmpGratuitySubmit",$scope.polSubSuccessMethod,$scope.polSubfailureMethod);

    		   }
    	   			
    	   		 
    	   			
    		   /*}
    		   else
    			   {
    			   ajaxHttpFactory.showErrorSuccessMessagePopup("You Can add Maximum Four Unit WithDrawl Details. ","errorMessage-popup", "beneficiaryAlert");
    			   }*/
    		   
    	   
    	   		
       }
       
       $scope.cancelPolEmp=function()
       {
    	   var currentElement = angular.element( document.querySelector('#memberIdPreview'));
			currentElement.removeClass('invalid1');
			$('#memberIdPreview_errMsg').css("visibility", "");
			$scope.previewClaimsGratuityJson.memberIdPreview=null;
       }
       
       var onLoadDataPolicyNumber=function(){			
      		$rootScope.preloaderCheck=true;
      	// var ajaxurl=$location.absUrl();
      		/*return ajaxHttpFactory.getJsonData("onloadGratityClaim",$scope.ajaxurl)
      		.then(function(response){	*/
      			
      			ajaxHttpFactory.getJsonData('onloadPolicyNumber',$scope.ajaxurl,'','GET').then(
                       function successCallback(response) {

      			
      			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert"))
      			{  		
      				$scope.response=response.data;
      				$scope.previewClaimsGratuityJson.policyNumber=$scope.response;
      				
      				$rootScope.preloaderCheck=false;
      				
      			}			
      								
      		},
      		function(errResponse){
      			$rootScope.preloaderCheck=false;
      			if(ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
      				
      			}
      		});
      };
       
       
      onLoadDataPolicyNumber();
       
       
       
       
       $scope.polSubSuccessMethod=function(response)
       {
    	   $rootScope.preloaderCheck=true;
    	   if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert"))
  			{  		
  				$scope.response=response;
  				if($scope.response.firstTimeUser==true)
  					{
  					$scope.showHtmlPage=true;
  					
  					$scope.claimsGratuityJson.policyNumber=$scope.response.policyNumber;
  					$scope.claimsGratuityJson.trustieeName=$scope.response.trustieeName;
  					$scope.claimsGratuityJson.employeeName=$scope.response.employeeName;
  					$scope.claimsGratuityJson.memberId=$scope.response.memberId;
  					$scope.disablePolTruNameEmpName=true;
  					$scope.showPolicyEmpId=false;
  					$scope.showHtmlPage=true;
  					
  					}
  				else
  					{
  					  $scope.downloadSuccessMethod();
  					//$window.location.href = "";
  					$scope.showHtmlPage=false;
  					$scope.showPolicyEmpId=false;
  					  
  					}
  				$rootScope.preloaderCheck=false;
  				
  			}
       }
       
       
       
       $scope.removeErrorFromJson=function(){           	   	
	 	  
	 	   var count = Object.keys($scope.claimsGratuityJson).length;
	 	   for(var key in $scope.claimsGratuityJson )
	 	   {
	 		   var error = "#"+key;
	 		   var other = key;
	 		   var currentElement = angular.element(error);
	 		   currentElement.removeClass('#invalid1');
	 		   $('error_errMsg').css("visibility", "");
	 	   		
	 		   for (var j = 0; j < $scope.errorArray.length; j++)
	 	   		{
	 			   if ($scope.errorArray[j] == other) 
	 			   { 
	 				   $scope.errorArray.splice(j, 1);
	 				   break;
	 			   }
	 	   		}
	 	   					
	         }
       }
      
       //$scope.errorArray=["dob","doj","lwd","lastDrawnSalary","disability","monthOfService","amountPaid","payeeName","planName_withdraw_0","withdrawalPercent_withdraw_0"];
       
       //Extra Code Ended
       
       var getStateDetails=function(){
			$rootScope.preloaderCheck=true;
				
				ajaxHttpFactory.getJsonData('getStateDetails',$scope.ajaxurl,'','GET').then(
	                    function successCallback(response) {
	                    	
				$rootScope.preloaderCheck=false;
				if (response != null && response != "null") {
			var responseData = response.data;
			for(var i = 0; i < responseData.length; i++)
			{
				
				$scope.state.push(responseData[i]);
			 
			      
			}
				}
				$rootScope.preloaderCheck=false;
			},
			function(errResponse) {
				$rootScope.preloaderCheck=false;
				console.error('Error while fetching profile details.');

			});
		};
		
		getStateDetails();
		
		var getCityDetails=function(){
			$rootScope.preloaderCheck=true;
				ajaxHttpFactory.getJsonData('getCityDetails',$scope.ajaxurl,'','GET').then(
	                    function successCallback(response) {

				if (response != null && response != "null") {
					var responseData = response.data;
					
					$scope.cityDetails=responseData;
						
					
				}	
				$rootScope.preloaderCheck=false;
			},
			function(errResponse) {
				$rootScope.preloaderCheck=false;
				console.error('Error while fetching profile details.');

			});
		};
		
		getCityDetails();
		
		
		$scope.onChangeStates=function(selectedState)
	       {
	              $scope.cityList=[];
	              for(var i=0;i<$scope.cityDetails.length;i++)
	                     {
	                         if(selectedState==$scope.cityDetails[i].key)
	                            {
	                            $scope.cityList.push($scope.cityDetails[i].value);
	                            }
	                     }
	       };

       
       $scope.onChangeOfClaimCause=function(claimCause)
       { 
    	   $scope.DocumentRequired=[];
    	   if(claimCause=="accDeath")
    		   {
    		   	$scope.getAccDeathDocOption();
    		   }
    	   else if(claimCause=="nonAccDeath")
    		   {
    		   $scope.getNonAccDeathDocOption();
    		   }
    	  
       }
       
       $scope.getAccDeathDocOption=function()
       {
    	   $scope.DocumentRequired = [
    	                              {
    	                                   "id" : "postMortemReport",
    	                                   "value" : " 1.Copy of Post Mortem Report"
    	                               },{
    	                                   "id" : "fir",
    	                                   "value" : "2.Copy of FIR"
    	                               },{
    	                                   "id" : "deathCirtificate",
    	                                   "value" : "3.Copy of Death Certificate issued by local authority"
    	                               }
    	                           ]
       }
       
       $scope.getNonAccDeathDocOption=function()
       {
    	   $scope.DocumentRequired = [
    	                              {
    	                                   "id" : "deathCirtificate",
    	                                   "value" : " 1. Copy of Death Certificate issued by local authority"
    	                               }
    	                           ]
       }
       
       $scope.relation=[{Id : 1,Value :'Father'},{Id :2,Value:'Mother' },{Id :3,Value:'Daughter'},{Id:4,Value:'Son'}];
       
       $scope.onChangeOfClaimType=function(claimType)
       {
    	   $rootScope.claimType=claimType;
    	   if(claimType=="retirement" || claimType=="resignation")
    		   {
    		   
    		   $scope.errorArray=["dob","doj","lwd","lastDrawnSalary","monthOfService","amountPaid","payeeName","planName_withdraw_0","withdrawalPercent_withdraw_0"];
									
    		   		//$scope.showCommanFields=true;
    		   		$scope.showDeathFields=false;
    		   		$scope.showBenificiary=false;
    		   		$scope.showAppointeeDetails=false;
    		   		$scope.showDeathDocument=false;
    		   	
    		   		$scope.claimsGratuityJson.majorMinor=null;
    		   		
    		   		
    		   		var currentElement = angular.element( document.querySelector('#beneficiaryDob'));
    				currentElement.removeClass('invalid1');
    				$('#beneficiaryDob_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.beneficiaryDob=null;
    				$scope.showbeneficiaryAge=false;
    		   		
    				var currentElement = angular.element( document.querySelector('#dateOfDeath'));
    				currentElement.removeClass('invalid1');
    				$('#dateOfDeath_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.dateOfDeath=null;
    				
    				var currentElement = angular.element( document.querySelector('#causeOfClaim'));
    				currentElement.removeClass('invalid1');
    				$('#causeOfClaim_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.causeOfClaim=null;
    				
    		  
    		   		var currentElement = angular.element( document.querySelector('#addressLine1'));
    				currentElement.removeClass('invalid1');
    				$('#addressLine1_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.addressLine1=null;
    				
    				var currentElement = angular.element( document.querySelector('#addressLine2'));
    				currentElement.removeClass('invalid1');
    				$('#addressLine2_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.addressLine2=null;
    				
    				
    				var currentElement = angular.element( document.querySelector('#addressLine3'));
    				currentElement.removeClass('invalid1');
    				$('#addressLine3_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.addressLine3=null;
    				
    				
    				var currentElement = angular.element( document.querySelector('#state'));
    				currentElement.removeClass('invalid1');
    				$('#state_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.state=null;
    				
    				var currentElement = angular.element( document.querySelector('#city'));
    				currentElement.removeClass('invalid1');
    				$('#city_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.city=null;
    				
    				var currentElement = angular.element( document.querySelector('#beneficiaryRelation'));
    				currentElement.removeClass('invalid1');
    				$('#beneficiaryRelation_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.beneficiaryRelation=null;
    				
    				
    				/*if($scope.claimsGratuityJson.beneficiaryAge>18)
    					{*/
    				var currentElement = angular.element( document.querySelector('#appointeeFirstName'));
    				currentElement.removeClass('invalid1');
    				$('#appointeeFirstName_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.appointeeFirstName=null;
    				
    				var currentElement = angular.element( document.querySelector('#appointeeMiddleName'));
    				currentElement.removeClass('invalid1');
    				$('#appointeeMiddleName_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.appointeeMiddleName=null;
    				
    				
    				var currentElement = angular.element( document.querySelector('#appointeeSurName'));
    				currentElement.removeClass('invalid1');
    				$('#appointeeSurName_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.appointeeSurName=null;
    				
    				var currentElement = angular.element( document.querySelector('#appointeeRelation'));
    				currentElement.removeClass('invalid1');
    				$('#appointeeRelation_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.appointeeRelation=null;
    				
    				var currentElement = angular.element( document.querySelector('#beneficiaryFirstName'));
    				currentElement.removeClass('invalid1');
    				$('#beneficiaryFirstName_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.beneficiaryFirstName=null;
    				
    				var currentElement = angular.element( document.querySelector('#beneficiaryMiddleName'));
    				currentElement.removeClass('invalid1');
    				$('#beneficiaryMiddleName_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.beneficiaryMiddleName=null;
    				
    				var currentElement = angular.element( document.querySelector('#beneficiarySurName'));
    				currentElement.removeClass('invalid1');
    				$('#beneficiarySurName_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.beneficiarySurName=null;
    				
    				var currentElement = angular.element( document.querySelector('#disability'));
    				currentElement.removeClass('invalid1');
    				$('#disability_errMsg').css("visibility", "");
    				$scope.claimsGratuityJson.disability=null;
    				
    					/*}*/
    				
    		   }
    	   else if(claimType=="death")
    		   {
    		   	
    		   $scope.errorArray=["dob","doj","lwd","withdrawalPercent_withdraw_0","dateOfDeath",	
    		                      "lastDrawnSalary","disability","planName_withdraw_0",
    		                      "monthOfService","amountPaid","payeeName","causeOfClaim","addressLine1","addressLine3","beneficiarySurName","addressLine2","beneficiaryDob","city","beneficiaryFirstName",  		                   
    		                      "state","beneficiaryMiddleName","beneficiaryRelation"
		   		                    ];
    		   		//$scope.showCommanFields=true;
    		   		$scope.showDeathFields=true;
    		   		$scope.showBenificiary=true;
    		   		$scope.showbeneficiaryAge=true;
    		   		$scope.showDeathDocument=true;
    		   		
    		   		
    		   }
    	   else
    		   {
    		  // $scope.showCommanFields=false;
		   		$scope.showDeathFields=false;
		   		
		   		
    		   }
       }
       
       $scope.addLeaveTaken=function(addindex)
       {
    	   $scope.leaveCount.length= $scope.leaveArray.length;
    	   $scope.leaveCount[addindex]=addindex
    	   $scope.index=$scope.leaveCount[addindex];
    	   
    	   if(($scope.claimsGratuityJson.leaveArray[addindex].fromDate=='') || ($scope.claimsGratuityJson.leaveArray[addindex].toDate=='') || ($scope.claimsGratuityJson.leaveArray[addindex].reasonForLeave=='') || ($scope.claimsGratuityJson.leaveArray[addindex].illnessType==''))
		   {
		  
		   ajaxHttpFactory.showErrorSuccessMessagePopup("Please fill All Fields Of Leave Taken. ","errorMessage-popup", "beneficiaryAlert");
		   }
    	   else
    		   {
    		   if($scope.leaveCount.length<4)
   					{
   						$scope.leaveCount[addindex]	= $scope.leaveCount[addindex]+1;
   							$scope.leaveArray.push('leave_'+$scope.leaveCount[addindex]);
   								$scope.disableAddLeave[addindex]=true;
   								$scope.disableDeleteLeave[addindex]=true;
   								/*$scope.showAddButton[addindex]=false;
   					$scope.addindexInc=addindex+1;
   					$scope.showAddButton[addindexInc]=true;*/
   				
   				
   				
   					}
       	   else
       		   {
       		   		ajaxHttpFactory.showErrorSuccessMessagePopup("You Can Add Maximum Four Leave Taken One year prior Commencement of member's Cover. ","errorMessage-popup", "beneficiaryAlert");
       		   }
    		  }
    	   
    	   
    	 	   
       }
       $scope.deleteLeave=function(leavedeleteId)
       {
    	   $scope.leavedeleteId=leavedeleteId;
    	 
    		   if($scope.leavedeleteId!=0)
    	   {
    		   $scope.leaveArray.splice($scope.leavedeleteId,1);
    		   $scope.claimsGratuityJson.leaveArray.splice($scope.leavedeleteId,1);
    		   $scope.leavedeleteIdInc=leavedeleteId-1;
    		   $scope.disableAddLeave[$scope.leavedeleteIdInc]=false;
    		   $scope.disableDeleteLeave[$scope.leavedeleteIdInc]=false;
    	   } 
    	  
       }
       
       
      /* $scope.addLeaveTaken=function(addindex)
       {
    	   $scope.claimsGratuityJson.leaveArray[0].fromDate
    	   $scope.leaveCount[addindex]=addindex
    	   $scope.index=$scope.leaveCount[addindex];
    	   
    	   if($scope.leaveCount.length<4)
			{
				$scope.leaveCount[addindex]	= $scope.leaveCount[addindex]+1;
				$scope.leaveArray.push('leave_'+$scope.leaveCount[addindex]);
				
				$scope.showAddButton[addindex]=false;
				$scope.addindexInc=addindex+1;
				$scope.showAddButton[addindexInc]=true;
				
				
				
			}
    	   
    	 	   
       }*/
       
       $scope.addWithDrawalUnit=function(withdrawIndex)
       {
    	   
    	
    	  
    	   $scope.withdrawalUnitCount[withdrawIndex]=withdrawIndex;
    	   $scope.index=$scope.withdrawalUnitCount[withdrawIndex];
    	   if(($scope.claimsGratuityJson.withdrawalUnit[withdrawIndex].planName=='') || ($scope.claimsGratuityJson.withdrawalUnit[withdrawIndex].withdrawalPercent==''))
    		   {
    		  
    		   
    		   ajaxHttpFactory.showErrorSuccessMessagePopup("Please fill Unit WithDrawl Details. ","errorMessage-popup", "beneficiaryAlert");
    		   }
    	   else
    		   {
    		
    		   	if($scope.withdrawalUnitCount.length<4)
    		   		{
    		   		
    		   			$scope.withdrawalUnitCount[withdrawIndex] = $scope.withdrawalUnitCount[withdrawIndex]+1;
    		   			$scope.withdrawalUnit.push('withdraw_'+$scope.withdrawalUnitCount[withdrawIndex]);
    		   			
    		   			$scope.disablewithDrawalUnit[withdrawIndex]=true;
    		   			$scope.withrawalArray.push('withdrawalPercent_withdraw_'+$scope.withdrawalUnitCount[withdrawIndex]);
    		   			$scope.withrawalArray.push('planName_withdraw_'+$scope.withdrawalUnitCount[withdrawIndex]);
    		   			
    		   			
    		   			
    		   			
    		   		}
    		   	else
    		   		{
    		   		ajaxHttpFactory.showErrorSuccessMessagePopup("You Can add Maximum Four Unit WithDrawl Details. ","errorMessage-popup", "beneficiaryAlert");
    		   		}
    		   	
    		   }
    	   
    	   
    	   
    	   
       }
       
       $scope.deleteWithDrawalUnit=function(withDrawDeleteId)
       {
    	   if(withDrawDeleteId!=0)
    {
    	  if($scope.claimsGratuityJson.withdrawalUnit.length<=1)
    		  {
    		  ajaxHttpFactory.showErrorSuccessMessagePopup("Add Atleast one Unit WithDrawl Details. ","errorMessage-popup", "beneficiaryAlert");
    		  }
    	  else
    		  {
    		  $scope.removewithdrawalerror(withDrawDeleteId);
    		 
    		  $scope.showBeneficiaryErrors(withDrawDeleteId);
    		    	$scope.withDrawDeleteId=withDrawDeleteId;
    		    	$scope.withdrawalUnit.splice($scope.withDrawDeleteId,1);
    		    	$scope.withdrawalUnitCount.splice($scope.withDrawDeleteId,1);// Added Extra
    		    
    		    	$scope.claimsGratuityJson.withdrawalUnit.splice($scope.withDrawDeleteId,1);
    		    	$scope.withDrawDeleteIdInc=withDrawDeleteId-1;
    		    	$scope.disablewithDrawalUnit[$scope.withDrawDeleteIdInc]=false;
    		    	
    		    	
    		    
    		    	
    		  }
    }
    	  
    	   
       }
       
       $scope.showBeneficiaryErrors=function(i)
   	{
   					
   			$scope.removeErrors(i);												
   		
   	}
       
       
       $scope.removeErrors=function(i)
   	{		
   			
    	  
    	   index = $scope.errorArray.indexOf("planName_withdraw_"+i);
    	   if(index!=-1)
      			$scope.errorArray.splice(index,1);
    	   index = $scope.errorArray.indexOf("withdrawalPercent_withdraw_"+i);
    	   if(index!=-1)
      			$scope.errorArray.splice(index,1);
   			
   			
   	}
       $scope.removewithdrawalerror=function(i)
      	{		
      			
       	  
       	   index = $scope.withrawalArray.indexOf("planName_withdraw_"+i);
       	   if(index!=-1)
         			$scope.withrawalArray.splice(index,1);
       	   index = $scope.withrawalArray.indexOf("withdrawalPercent_withdraw_"+i);
       	   if(index!=-1)
         			$scope.withrawalArray.splice(index,1);
      			
      			
      	}
      
   	
       
       
       /*$scope.onClickProceed1=function()
       {
    	
    	   $scope.showModal = true;
       }*/
      
       $scope.onClickCancel=function()
       {
    	   $scope.showModal = false;
       }
       $scope.submitPreview=function()
       { 
    	   $scope.totalPercentage=0;
    	   $scope.removeErrorFromJson();
    	   if($rootScope.claimType=="death")
    		   {
    		   $scope.errorArray=["claimType","dob","doj","lwd","withdrawalPercent_withdraw_0","dateOfDeath",	
    		                      "lastDrawnSalary","disability","planName_withdraw_0",
    		                      "monthOfService","amountPaid","payeeName","causeOfClaim","addressLine1","addressLine3","beneficiarySurName","addressLine2","beneficiaryDob","beneficiaryRelation","beneficiaryMiddleName","beneficiaryFirstName","city",		                   
    		                      "state"
		   		                    ];
    		   for(var i=0;i<$scope.withrawalArray.length;i++)
    			   {
    			   $scope.errorArray.push($scope.withrawalArray[i]);
    			   }
    		   }
    	   else
		   {
		   
		   $scope.errorArray=["claimType","dob","doj","lwd","lastDrawnSalary","monthOfService","amountPaid","payeeName","planName_withdraw_0","withdrawalPercent_withdraw_0"];
		   }
    	   for(var i=0;i<$scope.withrawalArray.length;i++)
		   {
		   $scope.errorArray.push($scope.withrawalArray[i]);
		   }
    	   if($rootScope.claimType=="death" && $scope.claimsGratuityJson.beneficiaryAge<18 && $scope.claimsGratuityJson.beneficiaryAge!='')
    		   {
    		   $scope.errorArray.push('appointeeFirstName');
    		   $scope.errorArray.push('appointeeMiddleName');
    		   $scope.errorArray.push('appointeeSurName');
    		   $scope.errorArray.push('appointeeRelation');
    		   
    		   }
    	   
    	  
    	   if($scope.checkBasicFieldValidations())
		   {
		    
    	   if($rootScope.claimType=="death")
    		   { 
    		   if($scope.deathFieldsvalidation())
    		   {
    			   for(var i=0;i<$scope.claimsGratuityJson.withdrawalUnit.length;i++)
       	    			{
    				   
    				   	$scope.totalPercentage=parseInt($scope.totalPercentage)+parseInt($scope.claimsGratuityJson.withdrawalUnit[i].withdrawalPercent);
       	    			}
    			   if($scope.totalPercentage!=100)
       	    	{
       	    	//$scope.totalPercentage=0;
       	    	ajaxHttpFactory.showErrorSuccessMessagePopup("Sum Of withDrawalUnit Percentage Should be 100%. ","errorMessage-popup", "beneficiaryAlert");
       	    	}
    			   else
    				   {
    				   $scope.showModal = true;
    				   }
    			   
    		   }
    		   else
    			   {
    			   ajaxHttpFactory.showErrorSuccessMessagePopup("Fill All Mandatory Fields. ","errorMessage-popup", "beneficiaryAlert");
    			   }
    		   			
    		   }
    	   
    	   else if($rootScope.claimType=="retirement" || $rootScope.claimType=="resignation")
    		   {
    		   		for(var i=0;i<$scope.claimsGratuityJson.withdrawalUnit.length;i++)
    		   		{
    		   				$scope.totalPercentage=parseInt($scope.totalPercentage)+parseInt($scope.claimsGratuityJson.withdrawalUnit[i].withdrawalPercent);
	    			}
    		   		if($scope.totalPercentage!=100)
           	    	{
           	    	$scope.totalPercentage=0;
           	    	ajaxHttpFactory.showErrorSuccessMessagePopup("Sum Of withDrawalUnit Percentage Should be 100%. ","errorMessage-popup", "beneficiaryAlert");
           	    	}
    		   		else
    		   			{
    		   			$scope.showModal = true;
    		   			}
    		   }
    	   
    	    
    	    /*if($scope.totalPercentage!=100)
    	    	{
    	    	$scope.totalPercentage=0;
    	    	ajaxHttpFactory.showErrorSuccessMessagePopup("Sum Of withDrawalUnit Percentage Should be 100%. ","errorMessage-popup", "beneficiaryAlert");
    	    	}*/
    	   
    	  //  $scope.showModal = true;
    	 
    		   		
    		   }
    	   else
    	   {
    		   ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill all mandatory Fields. ","errorMessage-popup", "beneficiaryAlert");
    	   }
    	   
       }
      /* $scope.cancelPreview=function()
       {
    	   $scope.showPreviewPage=false;
       }
       */
       $scope.onChangeMinorMajor=function(type)
       {
    	   $rootScope.type=type;
    	   if($rootScope.type=="minor")
    		   {
    		   		$scope.showAppointeeDetails=true;
    		   }
    	   else
    		   {
    		   $scope.showAppointeeDetails=false;
    		   }
       }
       
       
       var onLoadData=function(){			
   		$rootScope.preloaderCheck=true;
   	// var ajaxurl=$location.absUrl();
   		/*return ajaxHttpFactory.getJsonData("onloadGratityClaim",$scope.ajaxurl)
   		.then(function(response){	*/
   			
   			ajaxHttpFactory.getJsonData('onloadGratityClaim',$scope.ajaxurl,'','GET').then(
                    function successCallback(response) {

   			
   			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert"))
   			{  		
   				$scope.response=response.data;
   				if($scope.response.firstTimeUser==true)
   					{
   					$scope.showHtmlPage=true;
   					
   					$scope.claimsGratuityJson.policyNumber=$scope.response.policyNumber;
   					$scope.claimsGratuityJson.trustieeName=$scope.response.trustieeName;
   					$scope.claimsGratuityJson.employeeName=$scope.response.employeeName;
   					$scope.disablePolTruNameEmpName=true;
   					
   					}
   				else
   					{
   					  $scope.downloadSuccessMethod();
   					//$window.location.href = "";
   					$scope.showHtmlPage=false;
   					  
   					}
   				$rootScope.preloaderCheck=false;
   				
   			}			
   								
   		},
   		function(errResponse){
   			$rootScope.preloaderCheck=false;
   			if(ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
   				
   			}
   		});
   };
   	
  // onLoadData();
       
     
$scope.checkBasicFieldValidations = function() {
              
      
           if ($scope.errorArray.length > 0) {
               for (var i = 0; i < $scope.errorArray.length; i++) {
                   var lengthBfr = $scope.errorArray.length;
                   var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
                   if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
                       errorElement.triggerHandler("blur");
                   }
                   var lengthAftr = $scope.errorArray.length;
                   if (lengthAftr < lengthBfr) {
                       i--;
                   }
               }
               if ($scope.errorArray.length > 0) {
                   $("#" + $scope.errorArray[0]).focus();
                   return false;
               } else {
                   return true;
               }
           } else {
               return true;
           }
       };
       
       
       $scope.downloadSuccessMethod=function(){
   		$rootScope.preloaderCheck=true; 
   		
   	 	$scope.methodType = 'POST';
   		
   		$http({
               url: 'ClaimGratuityServlet.do',
               method: $scope.methodType,
               responseType: 'arraybuffer',
               data: undefined,
               headers: {
                   'Content-type': 'application/json',
                   'Accept': 'application/pdf'
               }
           }).success(function(data) {
           	$rootScope.preloaderCheck=true; 
           	if(data.byteLength>0)
           	{
               var blob = new Blob([data], {
                   type: 'application/pdf'
               });
               saveAs(blob, 'ClaimGratuityPDF.pdf');
               $rootScope.preloaderCheck=false;
               
   			$scope.openAlertID=true;
   			$scope.message="File Downloaded Successfully"

           	}
           	else
           	{
           		$rootScope.preloaderCheck=false;
   				ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "PmjjbyAlert");

           	}
               
               
           }).error(
               function() {
                	$rootScope.preloaderCheck=false;
   				ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "PmjjbyAlert");

               });
   		
   		$rootScope.preloaderCheck=false;
   	};
   	
   	$scope.okalert=function()
   	{
   		$scope.openAlertID=false;
   	 $window.location.href = "dashboard.htm";
   	}
   	$scope.cancelAlert=function()
   	{
   		$scope.openAlertID=false;
      	 $window.location.href = "dashboard.htm";
   	}
   	
   	$scope.successMethod=function(response)
   	{
   	
   		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert"))
   			{
   					if(response=="true")
   						{
   							$scope.showPreviewPage=false;
   						}
   			}
     }
   
   	
    var currentTime = new Date();
    $scope.currentTime = currentTime;
    $scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    $scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    $scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

    $scope.today = '';
    $scope.clear = 'Clear';
    $scope.close = 'Done';
    var days = 100;
    $scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
    $scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
    $scope.onStart = function () {
       
    };
    $scope.onRender = function () {
       
    };
    $scope.onOpen = function () {
    
        
       

        
    };
    $scope.onClose = function () {
           
      
        
        
    };


    $scope.onSet = function () {
    
    };


    $scope.onStop = function () {
      
    };
    
    
    $scope.onSet1 = function(dob) {

		$scope.birthday = new Date(dob);
		if ($scope.birthday != '' || $scope.birthday != undefined) {
			$scope.claimsGratuityJson.beneficiaryAge = $scope
					.calculateAge($scope.birthday);

		}
		
		if($scope.claimsGratuityJson.beneficiaryAge<18)
			{
				$scope.showAppointeeDetails=true;
				$scope.claimsGratuityJson.majorMinor="minor";
				$scope.claimsGratuityJson.appointeeMiddleName=null;
				$scope.claimsGratuityJson.appointeeFirstName=null;
				$scope.claimsGratuityJson.appointeeSurName=null;
				$scope.claimsGratuityJson.appointeeRelation=null;
				
			}
		else
			{
			$scope.showAppointeeDetails=false;
			$scope.claimsGratuityJson.majorMinor="major";
			$scope.claimsGratuityJson.appointeeMiddleName=null;
			$scope.claimsGratuityJson.appointeeFirstName=null;
			$scope.claimsGratuityJson.appointeeSurName=null;
			$scope.claimsGratuityJson.appointeeRelation=null;
			}

	};
	
	
	$scope.calculateAge = function(birthday) {

		var ageDifMs = Date.now() - birthday.getTime();
		var ageDate = new Date(ageDifMs);

		return Math.abs(ageDate.getUTCFullYear() - 1970);
	};
    
    $scope.checkDate= function(currentElement,errorMsgElement){
        if(angular.element(document.getElementById(currentElement)).val()=="")
               {
               angular.element(document.getElementById(currentElement)).addClass('invalid1');
               angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
               return false;
               }
        else
               {
               angular.element(document.getElementById(currentElement)).removeClass('invalid1');
               angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
               }
        return true;
        }
    
    $scope.checkRetirementDate= function(currentElement,errorMsgElement){
        
               angular.element(document.getElementById(currentElement)).removeClass('invalid1');
               angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
               
        return true;
        }
    
    
  
    $scope.onClickSubmit=function()
    {
    	$scope.previewMessage="Are You Sure You Want To Submit";
    	$rootScope.openPreviewModalAlert=true;
    	
    	
 		 
    }
    $scope.okPreviewAlert=function()
    {
    	$rootScope.openPreviewModalAlert=false;
    	 $rootScope.preloaderCheck=true;
         var claimsGratuityJsonSubmit=angular.toJson($scope.claimsGratuityJson);
         var ajaxurl=$location.absUrl();  //
         
         

           ajaxHttpFactory.postJsonDataSuccessFailure(claimsGratuityJsonSubmit,"POST",ajaxurl,"claimsGratuitySubmit",$scope.submitSuccessMethod,$scope.failureMethod);

    }
    $scope.cancelPreviewAlert=function()
    {
    	$rootScope.preloaderCheck=false;
    	$rootScope.openPreviewModalAlert=false;
    }
    
 	
   	$scope.submitSuccessMethod=function(response)
   	{
   	
   		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert"))
   			{
   					if(response=="success")
   						{
   							//$scope.showPreviewPage=false;
   						    $scope.downloadSuccessMethod();
   						}
   			}
     }
   	
   	
  /* 	$scope.onBlurCauseOfClaim = function() {
        if ($scope.claimsGratuityJson.causeOfClaim == "" || $scope.claimsGratuityJson.causeOfClaim == undefined) {      	
            var currentElement = angular.element(document.querySelector('#causeOfClaim'));
            currentElement.addClass('invalid1');
            $('#causeOfClaim_errMsg').css("visibility", 'visible');
            return false;
        }

     
    return true;
};
	$scope.onBlurAddress1 = function() {
        if ($scope.claimsGratuityJson.addressLine1 == "" || $scope.claimsGratuityJson.addressLine1 == undefined) {      	
            var currentElement = angular.element(document.querySelector('#addressLine1'));
            currentElement.addClass('invalid1');
            $('#addressLine1_errMsg').css("visibility", 'visible');
            return false;
        }

     
    return true;
};
	$scope.onBlurAddress2 = function() {
        if ($scope.claimsGratuityJson.addressLine2 == "" || $scope.claimsGratuityJson.addressLine2 == undefined) {      	
            var currentElement = angular.element(document.querySelector('#addressLine2'));
            currentElement.addClass('invalid1');
            $('#addressLine2_errMsg').css("visibility", 'visible');
            return false;
        }

     
    return true;
};
	$scope.onBlurAddress3 = function() {
        if ($scope.claimsGratuityJson.addressLine3 == "" || $scope.claimsGratuityJson.addressLine3 == undefined) {      	
            var currentElement = angular.element(document.querySelector('#addressLine3'));
            currentElement.addClass('invalid1');
            $('#addressLine3_errMsg').css("visibility", 'visible');
            return false;
        }

     
    return true;
};
$scope.onBlurBenFirstName = function() {
    if ($scope.claimsGratuityJson.beneficiaryFirstName == "" || $scope.claimsGratuityJson.beneficiaryFirstName == undefined) {      	
        var currentElement = angular.element(document.querySelector('#beneficiaryFirstName'));
        currentElement.addClass('invalid1');
        $('#beneficiaryFirstName_errMsg').css("visibility", 'visible');
        return false;
    }

 
return true;
};
$scope.onBlurBenMidName = function() {
    if ($scope.claimsGratuityJson.beneficiaryMiddleName == "" || $scope.claimsGratuityJson.beneficiaryMiddleName == undefined) {      	
        var currentElement = angular.element(document.querySelector('#beneficiaryMiddleName'));
        currentElement.addClass('invalid1');
        $('#beneficiaryMiddleName_errMsg').css("visibility", 'visible');
        return false;
    }

 
return true;
};$scope.onBlurBenSurName = function() {
    if ($scope.claimsGratuityJson.beneficiarySurName == "" || $scope.claimsGratuityJson.beneficiarySurName == undefined) {      	
        var currentElement = angular.element(document.querySelector('#beneficiarySurName'));
        currentElement.addClass('invalid1');
        $('#beneficiarySurName_errMsg').css("visibility", 'visible');
        return false;
    }

 
return true;
};
$scope.onBlurAppointeeFirstName = function() {
    if ($scope.claimsGratuityJson.appointeeFirstName == "" || $scope.claimsGratuityJson.appointeeFirstName == undefined) {      	
        var currentElement = angular.element(document.querySelector('#appointeeFirstName'));
        currentElement.addClass('invalid1');
        $('#appointeeFirstName_errMsg').css("visibility", 'visible');
        return false;
    }

 
return true;
};
$scope.onBlurAppointeeMidName = function() {
    if ($scope.claimsGratuityJson.appointeeMiddleName == "" || $scope.claimsGratuityJson.appointeeMiddleName == undefined) {      	
        var currentElement = angular.element(document.querySelector('#appointeeMiddleName'));
        currentElement.addClass('invalid1');
        $('#appointeeMiddleName_errMsg').css("visibility", 'visible');
        return false;
    }

 
return true;
};
$scope.onBlurAppointeeSurName = function() {
    if ($scope.claimsGratuityJson.appointeeSurName == "" || $scope.claimsGratuityJson.appointeeSurName == undefined) {      	
        var currentElement = angular.element(document.querySelector('#appointeeSurName'));
        currentElement.addClass('invalid1');
        $('#appointeeSurName_errMsg').css("visibility", 'visible');
        return false;
    }

 
return true;
};
$scope.onBlurAppointeeRelation = function() {
    if ($scope.claimsGratuityJson.appointeeRelation == "" || $scope.claimsGratuityJson.appointeeRelation == undefined) {      	
        var currentElement = angular.element(document.querySelector('#appointeeRelation'));
        currentElement.addClass('invalid1');
        $('#appointeeRelation_errMsg').css("visibility", 'visible');
        return false;
    }

 
return true;
};*/
   	
   	
   	
   	
   	
   	$scope.deathFieldsvalidation=function()
   	{
   		$rootScope.count=0;
   		if($rootScope.claimType=='death')
   			{
   			
   				
   				if($scope.claimsGratuityJson.beneficiaryDob=='' || $scope.claimsGratuityJson.beneficiaryDob==undefined)
   					{
   						var currentElement = angular.element( document.querySelector('#beneficiaryDob'));
      	                currentElement.addClass('invalid1');
      	                 $('#beneficiaryDob_errMsg').css("visibility",'visible');
      	               var errorElement = angular.element(document.querySelector('#beneficiaryDob'));
      	             
      	               $rootScope.count=1;
      	               
   					}
   				
   				if($scope.claimsGratuityJson.addressLine1=='' || $scope.claimsGratuityJson.addressLine1==undefined)
   					{
   					var currentElement = angular.element( document.querySelector('#addressLine1'));
      	             currentElement.addClass('invalid1');
      	             $('#addressLine1_errMsg').css("visibility",'visible');
      	           
      	           $rootScope.count=1;
      	           
   					}
   				
   				if($scope.claimsGratuityJson.addressLine2=='' || $scope.claimsGratuityJson.addressLine2==undefined)
					{
					var currentElement = angular.element( document.querySelector('#addressLine2'));
  	             currentElement.addClass('invalid1');
  	             $('#addressLine2_errMsg').css("visibility",'visible');
  	           
  	           $rootScope.count=1;
  	           
					}
   				
   				if($scope.claimsGratuityJson.addressLine3=='' || $scope.claimsGratuityJson.addressLine3==undefined)
				{
				var currentElement = angular.element( document.querySelector('#addressLine3'));
	             currentElement.addClass('invalid1');
	             $('#addressLine3_errMsg').css("visibility",'visible');
	             
	             $rootScope.count=1;
	             
				}
   				
   				if($scope.claimsGratuityJson.state=='' || $scope.claimsGratuityJson.state==undefined)
   					{
   						var currentElement = angular.element( document.querySelector('#state'));
   						currentElement.addClass('invalid1');
   						$('#state_errMsg').css("visibility",'visible');
   						
   						$rootScope.count=1;
   						
   					}
   				if($scope.claimsGratuityJson.city=='' || $scope.claimsGratuityJson.city==undefined)
   					{
   					var currentElement = angular.element( document.querySelector('#city'));
      	             currentElement.addClass('invalid1');
      	             $('#city_errMsg').css("visibility",'visible');
      	           
      	           $rootScope.count=1;
      	           
   					}
   				
   				if($scope.claimsGratuityJson.dateOfDeath=='' || $scope.claimsGratuityJson.dateOfDeath==undefined)
					{
					var currentElement = angular.element( document.querySelector('#dateOfDeath'));
  	             currentElement.addClass('invalid1');
  	             $('#dateOfDeath_errMsg').css("visibility",'visible');
  	          
  	           $rootScope.count=1;
  	           
					}
   				
   				if($scope.claimsGratuityJson.causeOfClaim=='' || $scope.claimsGratuityJson.causeOfClaim==undefined)
					{
					var currentElement = angular.element( document.querySelector('#causeOfClaim'));
  	             currentElement.addClass('invalid1');
  	           
  	             $('#causeOfClaim_errMsg').css("visibility",'visible');
  	          
  	          
  	             
  	           $rootScope.count=1;
  	           
					}
   				
   				if($scope.claimsGratuityJson.beneficiaryFirstName=='' || $scope.claimsGratuityJson.beneficiaryFirstName==undefined)
					{
						var currentElement = angular.element( document.querySelector('#beneficiaryFirstName'));
  	                currentElement.addClass('invalid1');
  	                 $('#beneficiaryFirstName_errMsg').css("visibility",'visible');
  	              
  	               $rootScope.count=1;
  	               
					}
   				
   				if($scope.claimsGratuityJson.beneficiaryMiddleName=='' || $scope.claimsGratuityJson.beneficiaryMiddleName==undefined)
				{
					var currentElement = angular.element( document.querySelector('#beneficiaryMiddleName'));
	                currentElement.addClass('invalid1');
	                 $('#beneficiaryMiddleName_errMsg').css("visibility",'visible');
	              
	               $rootScope.count=1;
	               
				}
   				
   				if($scope.claimsGratuityJson.beneficiarySurName=='' || $scope.claimsGratuityJson.beneficiarySurName==undefined)
				{
					var currentElement = angular.element( document.querySelector('#beneficiarySurName'));
	                currentElement.addClass('invalid1');
	                 $('#beneficiarySurName_errMsg').css("visibility",'visible');
	              
	               $rootScope.count=1;
	               
				}
   				
   				if($scope.claimsGratuityJson.beneficiaryRelation=='' || $scope.claimsGratuityJson.beneficiaryRelation==undefined)
				{
					var currentElement = angular.element( document.querySelector('#beneficiaryRelation'));
	                currentElement.addClass('invalid1');
	                 $('#beneficiaryRelation_errMsg').css("visibility",'visible');
	              
	               $rootScope.count=1;
	               
				}
   					
   				if($scope.claimsGratuityJson.beneficiaryAge=='' || $scope.claimsGratuityJson.beneficiaryAge==undefined)
				{
					var currentElement = angular.element( document.querySelector('#beneficiaryAge'));
	                currentElement.addClass('invalid1');
	                 $('#beneficiaryAge_errMsg').css("visibility",'visible');
	              
	               $rootScope.count=1;
	               
				}
   						
   				if($scope.claimsGratuityJson.beneficiaryAge<18 &&($scope.claimsGratuityJson.appointeeFirstName=='' || $scope.claimsGratuityJson.appointeeFirstName==undefined))
				{
					var currentElement = angular.element( document.querySelector('#appointeeFirstName'));
	                currentElement.addClass('invalid1');
	                 $('#appointeeFirstName_errMsg').css("visibility",'visible');
	              
	               $rootScope.count=1;
	               
				}
   				
   				if($scope.claimsGratuityJson.beneficiaryAge<18 &&($scope.claimsGratuityJson.appointeeMiddleName=='' || $scope.claimsGratuityJson.appointeeMiddleName==undefined))
				{
					var currentElement = angular.element( document.querySelector('#appointeeMiddleName'));
	                currentElement.addClass('invalid1');
	                 $('#appointeeMiddleName_errMsg').css("visibility",'visible');
	              
	               $rootScope.count=1;
	               
				}
   				
   				if($scope.claimsGratuityJson.beneficiaryAge<18 && ($scope.claimsGratuityJson.appointeeSurName=='' || $scope.claimsGratuityJson.appointeeSurName==undefined))
				{
					var currentElement = angular.element( document.querySelector('#appointeeSurName'));
	                currentElement.addClass('invalid1');
	                 $('#appointeeSurName_errMsg').css("visibility",'visible');
	              
	               $rootScope.count=1;
	               
				}
   				
   				if($scope.claimsGratuityJson.beneficiaryAge<18 &&($scope.claimsGratuityJson.appointeeRelation=='' || $scope.claimsGratuityJson.appointeeRelation==undefined))
				{
					var currentElement = angular.element( document.querySelector('#appointeeRelation'));
	                currentElement.addClass('invalid1');
	                 $('#appointeeRelation_errMsg').css("visibility",'visible');
	              
	               $rootScope.count=1;
	               
				}
   				
   				if($scope.claimsGratuityJson.disability=='' || $scope.claimsGratuityJson.disability==undefined)
				{
					var currentElement = angular.element( document.querySelector('#disability'));
	                currentElement.addClass('invalid1');
	                 $('#disability_errMsg').css("visibility",'visible');
	               var errorElement = angular.element(document.querySelector('#disability'));
	             
	               $rootScope.count=1;
	               
				}
   						
   					
   			
   			}
   		if($rootScope.count==1)
   			{
   				return false;
   			}
   		else {
       	 return true;
        }
   		
   	 return true;
   		
   		
   	}
   	
           
}]);
