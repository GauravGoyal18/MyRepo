var app=angular.module('groupApp',['ui.materialize','uiValidations','ajaxUtil','ngRoute','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection','groupCommonUtil']);

app.controller('brokerRenewalDueController',['$rootScope','$scope','ajaxHttpFactory','$location','$window','$filter','$http','$rootScope','uiGridConstants','csrDocUploadFactory', function($rootScope,$scope,ajaxHttpFactory,$location,$window,$filter,$http,$rootScope,uiGridConstants,csrDocUploadFactory){
	
	$rootScope.preloaderCheck=false;
	/*$scope.trackType=[];
	$scope.trackStatus=[];*/
	$scope.logs={};
	$scope.errorArray=[];

	$scope.successResponse='';
	var ajaxurl=$location.absUrl();
	$scope.result=[];
	$scope.renewalDueView={};
	$scope.renewalDueData=[];
	$scope.renewalDueViewDiv=false;
	
	
	
	 $scope.openClosed="openClose";
	 var paginationOptions = {
			    pageNumber: 1,
			    pageSize: 10,
			    sort: null
			  };
	 
	 
	var onLoadData=function(){			
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("loadBrokerRenewalDue",ajaxurl)
		.then(function(bizRes){	
			
			if(ajaxHttpFactory.handleIPruException(bizRes.data, "errorMessage-popup", "exceptionAlert")){
				
							
				$rootScope.preloaderCheck=false;
			}			
			var responseData = bizRes.data;
			$scope.renewalDueData=responseData;
			$scope.renewalDueView.totalItems=$scope.renewalDueData.length;

			
			$scope.renewalDueViewDiv=true;
			
			$scope.getPageOC();
			
			$rootScope.preloaderCheck=false;					
		},
		function(errResponse){
			$rootScope.preloaderCheck=false;			
		});
};
	
onLoadData();
	

$scope.getPageOC = function() {
	 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
    $scope.renewalDueView.data=$scope.renewalDueData.slice(firstRow, firstRow + paginationOptions.pageSize);	     
   
	};

	 
	 $scope.renewalDueView = {			 				
			 paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,			   
			    enableRowSelection: false,		      	     
		        resizable: false,
		        enableColumnResizing: false,
		        enableSorting: false,		       
		        
			    columnDefs: [
			      { field: 'policynumber', displayName: 'Policy Number',headerTooltip:function(col){return col.displayName;}, width: "12%"},
			      { field: 'statusKey',displayName: 'Status Key',headerTooltip:function(col){return col.displayName;}, width: "10%"},
			      { field: 'productName',  displayName: 'Product Name',headerTooltip:function(col){return col.displayName;}, width: "20%"},
			      { field: 'branchCode', displayName: 'Branch Code',width: "14%",headerTooltip:function(col){return col.displayName;}, width: "10%"},
			      { field: 'clientName', displayName: 'Client Name',headerTooltip:function(col){return col.displayName;}, width: "40%"},
			      { field: 'premiumAmount', displayName: 'Premium Amount',headerTooltip:function(col){return col.displayName;}, width: "15%"},
			      { field: 'anniversaryDate', displayName: 'RCD',headerTooltip:function(col){return col.displayName;}, width: "15%"},
			      
			     
			     	      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageOC();
			      });			      			 
			    }
			  };
	 
	
	
		
		
	
	



	
	$scope.dataAlert= function (){
		$rootScope.openAlertID = false;											
		$window.location.href = "dashboard.htm";
	};


	$scope.successMethod = function(bizRes) {		
		if(!ajaxHttpFactory.handleIPruException(bizRes, "errorMessage-popup", "exceptionAlert")){					
			$scope.result=bizRes;
			$rootScope.preloaderCheck=false;
		}
	};
		
	$scope.failureMethod = function(bizRes) {
		if(!ajaxHttpFactory.handleIPruException(bizRes, "errorMessage-popup", "exceptionAlert")){			
			$rootScope.preloaderCheck=false;
		}
	};	
    
	
	
	
	
}]);