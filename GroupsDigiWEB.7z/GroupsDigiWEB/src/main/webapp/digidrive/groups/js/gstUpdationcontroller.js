var app = angular.module('groupApp', ['uiValidations','ui.materialize','otpModalApp','ajaxUtil']);
	app.controller('gstUpdationcontroller',['$rootScope','$scope','$location','ajaxHttpFactory','$filter','$window',function($rootScope, $scope,$location,ajaxHttpFactory,$filter,$window)
	{
		$rootScope.preloaderCheck=false;
		$scope.showotherCOB=false;
		$scope.showfields=true;
		$scope.showothercustomerType=false;
		$scope.errorArray=[];
		//$scope.gstupdation={};
		$scope.gstFormSubmitJson={};
		$scope.submitEmailMobileJson = {};
		$scope.submitDetailsJson={};
		$scope.modalErrorArray=[];
		$scope.gstFormSubmitJson.isActive = true;
		$scope.gstFormSubmitJson.declarationDate=$filter('date')(new Date(),'dd MMMM, yyyy');
		$scope.modalOpen=false;
		$scope.states=[];
		 $scope.state="";
		 $scope.stateCode="";
		 $scope.stateAndStateCode={};
		 $scope.openAlertId=false;
		
		 var loadFormData = function() {
			 $rootScope.preloaderCheck = true;
				return ajaxHttpFactory.getJsonData("loadGstFormData",$location.absUrl())
				.then(function(response) {
					$rootScope.preloaderCheck = false;
					if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
						if (response != null && response != "null") {
							var requestJson = response.data;
							$scope.stateAndStateCode=requestJson.stateAndStateCode;					
	               		 	$scope.states=requestJson.state;
							$scope.gstFormSubmitJson.policyNumber = requestJson.policyNo;
							if(angular.isUndefined($scope.gstFormSubmitJson.policyNumber) || $scope.gstFormSubmitJson.policyNumber == ""){
								$scope.openAlertId=true;
								$scope.message="Link is not Valid";
							}							
						}
					}
				}, 
				function(response) {
					$rootScope.preloaderCheck = false;
					if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
						
					}
				});
			};
		
		loadFormData();
	
		$scope.getStateCodeList = function(stateDetails) {		
			$rootScope.preloaderCheck=true;
			 $scope.gstFormSubmitJson.stateCode="";
				 if(stateDetails!=null){					
						$scope.gstFormSubmitJson.stateCode=$scope.stateAndStateCode[stateDetails];								
				 }
			 };
		
		$scope.onclickofOthers=function(){
			if($scope.gstFormSubmitJson.cob=="Others"){
				
				$scope.showotherCOB=true;
				
			}else{
				$scope.showotherCOB=false;
				
			}
		};
		$scope.validcob=function(){
			if($scope.gstFormSubmitJson.cob=="Others"){
		if($scope.gstFormSubmitJson.otherCOB==""){
			var currentElement = angular.element( document.querySelector('#otherCOB'));
			currentElement.addClass('invalid1');
			$('#otherCOB_errMsg').css("visibility",'visible');
			}
			else
				{
				var currentElement = angular.element( document.querySelector('#otherCOB'));
				currentElement.removeClass('invalid1');
				$('#otherCOB_errMsg').css("visibility", "");
				}
			}
			
		};
		$scope.validcustomerType=function(){
			if($scope.gstFormSubmitJson.customerType=="Others"){
				
				if($scope.gstFormSubmitJson.otherCustomerType==""){
				var currentElement = angular.element( document.querySelector('#otherCustomerType'));
				currentElement.addClass('invalid1');
				$('#otherCustomerType_errMsg').css("visibility", 'visible');
				}else
					{
					var currentElement = angular.element( document.querySelector('#otherCustomerType'));
					currentElement.removeClass('invalid1');
					$('#otherCustomerType_errMsg').css("visibility", "");
					}
			}
		};
	
		$scope.onclickofothercustomerType=function(){
			if($scope.gstFormSubmitJson.customerType=="Others"){
				$scope.showothercustomerType=true;
				
			}	else{
				$scope.showothercustomerType=false;
				
			}	
		};
		
		$scope.onclickofRegister=function(){
			
			if($scope.gstFormSubmitJson.isActive==true){
				
				$scope.showfields=true;
				$scope.gstFormSubmitJson.isRegisteredUser ="YES";
				
				
			}else{
				
				$scope.showfields=false;
				$scope.gstFormSubmitJson.isRegisteredUser ="NO";
			    $scope.gstFormSubmitJson.registrationStatus="";
				$scope.gstFormSubmitJson.registrationDate="";
				$scope.gstFormSubmitJson.gstinOrUin="";
				$scope.gstFormSubmitJson.address="";
				$scope.gstFormSubmitJson.pinCode="";
				$scope.gstFormSubmitJson.state="";
				$scope.gstFormSubmitJson.stateCode="";
				$scope.gstFormSubmitJson.isdNo="";
			};
			
		};
		$scope.OnResetBtn=function(){
			var currentElement = angular.element(document.getElementsByClassName('invalid1'));
			currentElement.removeClass('invalid1');
			$('.err-msg').css("visibility", "");
			//$scope.errorArray=[];
			$scope.gstFormSubmitJson={};
			$scope.gstFormSubmitJson.isActive = true;
		};
		
		$scope.onclickGstFormsubmitbtn = function(){
			$rootScope.preloaderCheck = true;
			
			if($scope.gstFormSubmitJson != null && angular.isDefined($scope.gstFormSubmitJson)){
				
					 if($scope.modalOpen==false)
						 {
						 	for(var i = 0; i < $scope.errorArray.length; i++) {
						 		if($scope.errorArray[i]=="phoneNumber" || $scope.errorArray[i]=="emailID"){
						 			$scope.errorArray.splice(i, 1);
						 			i--;
						 		}
						 	}
						 }
					 	if($scope.gstFormSubmitJson.isActive==true){
							$scope.gstFormSubmitJson.isRegisteredUser = "YES";							
						}else{
							$scope.gstFormSubmitJson.isRegisteredUser = "NO";
							
						}
			
					 if($scope.gstFormSubmitJson.isRegisteredUser == "YES"){
							if($scope.checkBasicFieldValidations())
							{
								if($scope.checkBasicFieldValidationsModal()){
									var gstFormSubmitJsonString = angular.toJson($scope.gstFormSubmitJson);
									var ajaxurl = $location.absUrl();
									ajaxHttpFactory.postJsonDataSuccessFailure(gstFormSubmitJsonString,"POST",ajaxurl,"gstFormSubmit",$scope.submitGstFormSuccessMethod,$scope.submitGstFormFailureMethod);
								}
							} else {
								$scope.checkBasicFieldValidationsModal();
							}
					}
					 else{
				if($scope.checkBasicFieldValidations()){
					
					
					
					var gstFormSubmitJsonString = angular.toJson($scope.gstFormSubmitJson);
					var ajaxurl = $location.absUrl();	
					$rootScope.preloaderCheck=true;
					ajaxHttpFactory.postJsonDataSuccessFailure(gstFormSubmitJsonString,"POST",ajaxurl,"gstFormSubmit",$scope.submitGstFormSuccessMethod,$scope.submitGstFormFailureMethod);
					
			}
					 }
			}
			
			$rootScope.preloaderCheck = false;
		};
		
		$scope.submitGstFormSuccessMethod = function(response){
			
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
				$rootScope.$broadcast('popup', true);
				$rootScope.preloaderCheck=false;
				$scope.OnResetBtn();
			}
			$rootScope.preloaderCheck=false;
		};
		
		$scope.submitGstFormFailureMethod = function(response){
			$rootScope.preloaderCheck=false;
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
				
			}
		};
		
		$scope.contactDetailsSubmitForm= function()
	    {
			$rootScope.preloaderCheck = true;
			if($scope.submitEmailMobileJson != null && angular.isDefined($scope.submitEmailMobileJson)){
				 if($scope.modalOpen==true)
				 {
				 if(angular.isUndefined($scope.submitEmailMobileJson.mobileNo))
					 {
					 $scope.errorArray.push("phoneNumber");
					 }
				 if(angular.isUndefined($scope.submitEmailMobileJson.emailId))
				 {
					 $scope.errorArray.push("emailID");
					 }
					
				 }
				
				if($scope.checkBasicFieldValidations()){
					var submitEmailMobileJsonString = angular.toJson($scope.submitEmailMobileJson);
					var ajaxurl = $location.absUrl();	
					$rootScope.preloaderCheck=true;
					ajaxHttpFactory.postJsonDataSuccessFailure(submitEmailMobileJsonString,"POST",ajaxurl,"emailMobileSubmit",$scope.submitEmailMobileSuccessMethod,$scope.submitEmailMobileFailureMethod);		
				}
			}
			$rootScope.preloaderCheck = false;
	    };
	    
	    $scope.submitEmailMobileSuccessMethod = function(response) {
	    	$rootScope.preloaderCheck=false;
	    	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
	    		$rootScope.$broadcast('popup', false);	
	    	    $scope.linkRedirectionUrlWdgt();
	    	    	
	    	    $rootScope.$on('otpHandShake', function (event, args) {
	    	    		
	    	    	if(args!=null && args!=undefined)
	    				{
	    	    			$scope.submitDetailsJson.emailMobileJson = $scope.submitEmailMobileJson;
	    	    			$scope.submitDetailsJson.gstFormJson = $scope.gstFormSubmitJson;	    	    			
	    					var ssubmitDetailsJsonString = angular.toJson($scope.submitDetailsJson);
	    					var ajaxurl = $location.absUrl();	
	    					$rootScope.preloaderCheck=true;
	    					ajaxHttpFactory.postJsonDataSuccessFailure(ssubmitDetailsJsonString,"POST",ajaxurl,"gstFormSave",$scope.saveEmailMobileSucces,$scope.saveEmailMobileFailure);			
	    				}
	    	    	});
	    	    }
	    };
	    	    
	    $scope.submitEmailMobileFailureMethod = function(response) {
	    	$rootScope.preloaderCheck=false;
	        	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
	        	}
	    	    	
	    };
	    
	    $scope.saveEmailMobileSucces = function(response){
	    	$rootScope.preloaderCheck=false;
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
				$scope.openAlertId=true;
				$scope.message="Your details have been submitted successfully";
				
			}
		};
		$scope.okAlert=function()
		{
			
			$window.location.href = "https://www.iciciprulife.com/";		
			
			
		}
		
		
		$scope.saveEmailMobileFailure = function(response){
			$rootScope.preloaderCheck=false;
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			}
		};
		
		$scope.checkBasicFieldValidations = function() {
		    if ($scope.errorArray.length > 0) {
		        for (var i = 0; i < $scope.errorArray.length; i++) {
		            var lengthBfr = $scope.errorArray.length;
		            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
		            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
		                errorElement.triggerHandler("blur");
		            }
		            var lengthAftr = $scope.errorArray.length;
		            if (lengthAftr < lengthBfr) {
		                i--;
		            }
		        }
		        if ($scope.errorArray.length > 0) {
		            $("#" + $scope.errorArray[0]).focus();
		            return false;
		        } else {
		            return true;
		        }
		    } else {
		        return true;
		    }
		};
		$scope.checkBasicFieldValidationsModal = function() {
		    if ($scope.modalErrorArray.length > 0) {
		        for (var i = 0; i < $scope.modalErrorArray.length; i++) {
		            var lengthBfr = $scope.modalErrorArray.length;
		            var errorElement = angular.element(document.querySelector('#' + $scope.modalErrorArray[i]));
		            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
		                errorElement.triggerHandler("blur");
		            }
		            var lengthAftr = $scope.modalErrorArray.length;
		            if (lengthAftr < lengthBfr) {
		                i--;
		            }
		        }
		        if ($scope.modalErrorArray.length > 0) {
		            $("#" + $scope.modalErrorArray[0]).focus();
		            return false;
		        } else {
		            return true;
		        }
		    } else {
		        return true;
		    }
		};
		
		$scope.$on('popup', function(event, args) {
	    	 
	    	 if(args){
	    		 $('#contactPopupAlert').openModal({dismissible:false});
	    		 $scope.modalOpen=true;
	    	 }else{
	    		 $('#contactPopupAlert').closeModal();
	    		 $scope.modalOpen=false;
	    	 }
	    	 
	    });
		
		$scope.linkRedirectionUrlWdgt=function(){
			var url=$location.absUrl();
			ajaxHttpFactory.linkRedirectionUrlWdgt(url,'&otpType=transactionalOTP');			 
		};
		
		var currentTime = new Date();
		$scope.currentTime = currentTime;
		$scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		$scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
		$scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
		$scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

		$scope.today = '';
		$scope.clear = 'Clear';
		$scope.close = 'Done';
		var days = 100;
		$scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
		$scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
		$scope.onStart = function () {
		   
		};
		$scope.onRender = function () {
		   
		};
		$scope.onOpen = function () {		    
		};
		$scope.onClose = function () {
	    
		};


		$scope.onSet = function () {
	 
		  
		};


		$scope.onStop = function () {
		  
		};
		$scope.checkDate= function(currentElement,errorMsgElement){
			if(angular.element(document.getElementById(currentElement)).val()=="")
				{
				angular.element(document.getElementById(currentElement)).addClass('invalid1');
				angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
				return false;
				}
			else
				{
				angular.element(document.getElementById(currentElement)).removeClass('invalid1');
				angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
				}
			return true;
			}

			
}]);

