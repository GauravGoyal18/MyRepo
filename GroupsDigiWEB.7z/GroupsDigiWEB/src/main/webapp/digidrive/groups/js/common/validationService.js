angular.module('validationService',[])

.factory('validateFieldService', function(){

	var validateField = function(id,action,results)    //To validate Fields

	{

		var result=false;

		var div = results[id];

		if(angular.isDefined(div)){

			if(action=="show")                 //To Display

			{

				if(div.opShow=='1')          

					result=true;

			}

			else if(action=="disabled")      //To Disable

			{

				if(div.opShowDisabled=='1')

					result=true;

			}

			else if(action=="edit")        //To be Editable(Edit Link)

			{

				if(div.opShowEdit=='1')

					result=true;

			}

			else if(action=="enable")     //To Enable

			{

				if(div.opShowEdit=='1')

				{

					div.opShowDisabled='0';

					div.opShowEdit='0';

					result=true;

				}

			}

			else if(action=="save")       //To Save

			{

				if(div.opShowEdit=='0')

				{

					div.opShowDisabled='1';

					div.opShowEdit='1';

					result=true;

				}

			}

			else if(action=="cancel")   //To Cancel

			{

				if(div.opShowEdit=='0')

				{

					div.opShowDisabled='1';

					div.opShowEdit='1';

					result=true;

				}

			}

		}

		return result;

	};
	var checkDate= function(currentElement,errorMsgElement){
		if(currentElement.val()=="")
			{
			currentElement.addClass('invalid1');
			errorMsgElement.css('visibility','visible');
			return false;
			}
		else{
			currentElement.removeClass('invalid1');
			errorMsgElement.css('visibility','hidden');
		return true;
		}
		};

	return{

		fieldValidate: function(id,action,results){

			return validateField(id,action,results);

		},
		dateValidation : function(currentElement,errorMsgElement)
		{
			return checkDate(currentElement,errorMsgElement);
		}

	};

});
