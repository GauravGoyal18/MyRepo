var app=angular.module('groupApp',['ui.materialize','uiValidations','ajaxUtil','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection','groupCommonUtil']);

app.controller('pmjjbyController',['$scope','ajaxHttpFactory','$location','$window','$filter','$http','$rootScope','uiGridConstants','csrDocUploadFactory', function($scope,ajaxHttpFactory,$location,$window,$filter,$http,$rootScope,uiGridConstants,csrDocUploadFactory)
    {

	$scope.errorArray = [];
	$scope.submitJson = {};
	$scope.details={};
	$scope.details.bankAccNo='';
	$scope.details.dobOfAssured='';
	$scope.details.nominee='';
	$rootScope.preloaderCheck=false;
	var ajaxurl=$location.absUrl();


	$scope.Cancel = function(){
		
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$('.err-msg').css("visibility", "");
		$scope.details = {};
		$scope.errorArray=['accountNo'];
   	};
   		$scope.submit=function()
	{
		
		
		if($scope.checkBasicFieldValidations()){	
			$rootScope.preloaderCheck=true;
		//$scope.errorArray = ["accountNo","dobDate","nominee"];
		var pmjjbyData=angular.toJson($scope.details);
		ajaxHttpFactory.postJsonDataSuccessFailure(pmjjbyData,"POST",ajaxurl,"Submit",$scope.successMethod,$scope.failureMethod);
		
		
		}else{
			$rootScope.preloaderCheck=false;
		}	
	
	};
	var currentTime = new Date();
	$scope.currentTime = currentTime;
	$scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	$scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	$scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
	$scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

	$scope.today = '';
	$scope.clear = 'Clear';
	$scope.close = 'Done';
	var days = 100;
	$scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
	$scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
	
	$scope.onStart = function () {
	    
	};
	$scope.onRender = function () {
	   
	};
	$scope.onOpen = function () {
	   							    
	};
	$scope.onClose = function () {
		 
	    
	};
	$scope.onSet = function () {
		 
	 
	};
	
    $scope.checkDate= function(currentElement,errorMsgElement){
    	if(angular.element(document.getElementById(currentElement)).val()=="")
    		{
    		angular.element(document.getElementById(currentElement)).addClass('invalid1');
    		angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
    		return false;
    		}
    	else
    		{
    		angular.element(document.getElementById(currentElement)).removeClass('invalid1');
    		angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
    		}
    	return true;
    	};
	
	$scope.successMethod=function(response){
		$rootScope.preloaderCheck=true; 	
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
//		$.post("PmjjbyServlet.do", { "key": $scope.details });
		
		if(response=="success")
		{
	 	$scope.methodType = 'POST';
		
		$http({
            url: 'PmjjbyServlet.do',
            method: $scope.methodType,
            responseType: 'arraybuffer',
            data: undefined,
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/pdf'
            }
        }).success(function(data) {
        	$rootScope.preloaderCheck=true; 
        	if(data.byteLength>0)
        	{
            var blob = new Blob([data], {
                type: 'application/pdf'
            });
            saveAs(blob, 'CertificateIncsuranceCOIPMJJBY_'+ Date() + '.pdf');
            $rootScope.preloaderCheck=false;
			ajaxHttpFactory.showErrorSuccessMessagePopup("File downloaded successfully. ","errorMessage-popup", "PmjjbyAlert");

        	}
        	else
        	{
        		$rootScope.preloaderCheck=false;
				ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "PmjjbyAlert");

        	}
            
            
        }).error(
            function() {
             	$rootScope.preloaderCheck=false;
				ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "PmjjbyAlert");

            });
		
		}
		else
			{
			$rootScope.preloaderCheck=false;
			ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ","errorMessage-popup", "PmjjbyAlert");

			}
		}
		$rootScope.preloaderCheck=false;
	};
	
	$scope.failureMethod=function(){
		
		$scope.action="failure";
		$scope.message = "Some Error Occured.";
	};
	
	$scope.checkBasicFieldValidations = function() {
	 if ($scope.errorArray.length > 0) {
	        for (var i = 0; i < $scope.errorArray.length; i++) {
	            var lengthBfr = $scope.errorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = $scope.errorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	        if ($scope.errorArray.length > 0) {
	            $("#" + $scope.errorArray[0]).focus();
	            return false;
	        } else {
	            return true;
	        }
	    } else if($scope.details.dobOfAssured.length===0 && $scope.details.nominee.length===0){
			ajaxHttpFactory.showErrorSuccessMessagePopup("Please Provide Nominee or Dirth Of Birth","errorMessage-popup", "PmjjbyAlert");			
			return false;
		}else {
	        return true;
	    }
	};


}]);