function toggleRadioClass(radioGroupName)
{
		var radioGroup=document.getElementsByName(radioGroupName);
		var radioValue="";
		if(radioGroup!=null && radioGroup.length!=0)
		{
			for(var i=0;i<radioGroup.length;i++)
			{
				if(radioGroup[i].checked)
				{
					//alert(radioGroup[i].id);
					document.getElementById(radioGroup[i].id+"_label").className="cb-enable selected";
				}
				else
				{
					document.getElementById(radioGroup[i].id+"_label").className="cb-disable";
				}
			}	
		}
}
function getRadioValue(name)
	{
		var radioGroup=document.getElementsByName(name);
		var radioValue="";
		if(radioGroup!=null && radioGroup.length!=0)
		{
			for(var i=0;i<radioGroup.length;i++)
			{
				if(radioGroup[i].checked)
				{
					radioValue=radioGroup[i].value;
					break;
				}
			}	
		}
		
		return radioValue;
	}
	function toggleCustAdvEmp(labelId)
	{
		var radioElementId=labelId.replace("_label","");
		document.getElementById(radioElementId).click();
		var isCustTrackerReq=getRadioValue("isCustTracker");
		toggleRadioClass("isCustTracker");
		document.getElementById("firstname").value="";
		
		if(isCustTrackerReq=="1")
		{
			document.getElementById("firstname").title="Enter User Id/Email/Mobile *";
			document.getElementById("firstname").value="Enter User Id/Email/Mobile *";
		}
		if(isCustTrackerReq=="2")
		{
			document.getElementById("firstname").title="Enter User Id/Email/Mobile *";
			document.getElementById("firstname").value="Enter User Id/Email/Mobile *";
		}
		if(isCustTrackerReq=="3")
		{
			document.getElementById("firstname").title="Enter User Id/Email/Mobile *";
			document.getElementById("firstname").value="Enter User Id/Email/Mobile *";
		}
	}
	
	
	function onblur_custAdvEmp()
	{/*
		if(document.getElementById("firstname").value="" || document.getElementById("firstname").value=="Enter Registered Email Id *" || document.getElementById("firstname").value=="Enter Agent Code Number *" || document.getElementById("firstname").value=="Enter Employee Number *")
		{
			
		//	inCorrectUserName();			
			var radioGroup=document.getElementsByName("isCustTracker");
			if(radioGroup!=null && radioGroup.length!=0)
			{
				for(var i=0;i<radioGroup.length;i++)
				{
					if(radioGroup[i].checked)
					{
						toggleCustAdvEmp(radioGroup[i].id+"_label");
						//radioGroup[i].click();
						break;
					}
				}	
			}
		}
		else{
		//	correctUserName();		
		}
	*/}
	
	
	
	function onkeypress_policyAppNo(event)
	{
		var isAppTrackerReq=getRadioValue("isAppTracker");
		
		if(isAppTrackerReq=="Yes")
		{
			allowAlphaNumeric(event);
		}
		else if(isAppTrackerReq=="No")
		{
			onlyNumbers(event);
		}
	}
	
	function resetFieldValueOnFocus(fieldId)
	{
		if(document.getElementById(fieldId).title==document.getElementById(fieldId).value)
		{
			document.getElementById(fieldId).value="";
		}
	}
	function onblur_policyAppNo()
	{
		if(document.getElementById("reqPolicyNumber").value=="Policy No *" || document.getElementById("reqPolicyNumber").value=="Application No *")
		{
			var radioGroup=document.getElementsByName("isAppTracker");
			if(radioGroup!=null && radioGroup.length!=0)
			{
				for(var i=0;i<radioGroup.length;i++)
				{
					if(radioGroup[i].checked)
					{
						toggleAppNoPolicyNo(radioGroup[i].id+"_label");
						//radioGroup[i].click();
						break;
					}
				}	
			}
		}
	}
	
	function changeLoginRequFunctionality(functionality,linkId)
	{
		if(linkId!="" && linkId !=undefined)
		{
			toggleActiveLink(linkId);
		}
		document.getElementById("nonLoggedInSecTab").click();
		document.getElementById("nonLoginPolicy").click();
		
		if(functionality=="preIssuancePayment")
		{
			document.getElementById("nonLoginPreIssuance_label").click();
			document.getElementById("loginReqFunctionality").value="";
		}
		else if(functionality=="appTracker")
		{
//			document.getElementById("nonLoginAppTracker_label").click();
			document.getElementById("loginReqFunctionality").value="";
		}
		else
		{
			document.getElementById("nonLoginPolicy_label").click();
			document.getElementById("loginReqFunctionality").value=functionality;	
		}
		document.getElementById("reqPolicyNumber").focus();
		
	}
	
	function toggleActiveLink(linkId)
	{
		var linkIdArray=['paymentLink','estatementLink','eswitchLink','siLink','preIssuancePaymentLink','fundProgressLink','appTrackerLink'];
		for(var i=0;i<linkIdArray.length;i++)
		{
			if(linkIdArray[i]==linkId)
			{
				if(document.getElementById(linkIdArray[i])!=null)
				document.getElementById(linkIdArray[i]).className="activelink";	
			}
			else
			{
				if(document.getElementById(linkIdArray[i])!=null)
				document.getElementById(linkIdArray[i]).className="";
			}
				
		}	
	}
	
	function dob_day_keypress(event){
		onlyNumbers(event);
	}
	function onlyNumbers(event)
	{
		if(event.keyCode !=0)
		{
			if (event.keyCode < 48 || event.keyCode > 57)
			{

				event.returnValue = false;

			}
		}
		else 
		{
			if (event.charCode < 48 || event.charCode > 57)
			{

				event.preventDefault();

			}

		}
	}
	function handleKeyPress(event)
		{  
			var keyCode = event.keyCode;
			var charCode = event.charCode;
			if(event.keyCode !=0)
				{
					if(keyCode == 13) 
						{
							submitform();
						}
					}	
				else
					{	
						if(charCode == 13)
						{
							submitform();
						}
					}
			return true;
		}
	
	function handleKeyPressUnsecuredLogin(event,url)
	{  
		var keyCode = event.keyCode;
		var charCode = event.charCode;
		if(event.keyCode !=0)
			{
				if(keyCode == 13) 
					{
						submitformCustomer(url);
					}
				}	
			else
				{	
					if(charCode == 13)
					{
						submitformCustomer(url);
					}
				}
		return true;
	}
	
function allowAlphaNumeric(event)
	{
		
			  var keyCode = event.keyCode;
			  
				var charCode = event.charCode;
				if(event.keyCode !=0)
				{
					if(keyCode==64 || keyCode==95 || keyCode==46)
					{
					
					}
					else if((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 122)   && (keyCode < 48 || keyCode > 57) )
					{
					event.returnValue = false;
					}
				}	
				else
				{	
					if(charCode==64 || charCode==95 || charCode==46)
						{
						
						}
					else if((charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)  && (charCode < 48 || charCode > 57))
					{
						
						event.preventDefault();
					}
					else
					{
						
					}
				}
				
	 }
	function ChangeCase(elem)
	{
	    elem.value = elem.value.toUpperCase();
	}

	function onKeyPressUserName(element,event)
	{
		allowAlphaNumeric(event);
		//ChangeCase(element);
		
		document.getElementById('UN_ERROR_MSG').innerHTML = '';
		hideError("error-div");
		
		
		if(document.getElementById('PWD_ERROR_MSG').innerHTML != 'Please Enter Password')
		{
		document.getElementById('PWD_ERROR_MSG').innerHTML ="";
		hideError("error-div1");
		
		}
	}
	function onKeyUpUserName(element)
	{
		//ChangeCase(element);
		/* document.getElementById('UN_ERROR_MSG').innerHTML = '';
		if(document.getElementById('PWD_ERROR_MSG').innerHTML != 'Please Enter Password')
		{
		document.getElementById('PWD_ERROR_MSG').innerHTML ="";
		} */
		
	}
	function onBlurUserName()
	{
		var userNameLower = document.getElementById("firstname").value;
		//var userNameUpper = userNameLower.toUpperCase();
		document.getElementById("firstname").value = userNameLower;
	}
	
	
	
		/*By Neha Location tracking code for tablet*/
/*	if (navigator.geolocation)
{
navigator.geolocation.getCurrentPosition(GetLocation);

}
function GetLocation(location) {
	var userLatitude =location.coords.latitude;
	document.f.lattitude.value= userLatitude;
    var userLongitude =location.coords.longitude;
    document.f.longitude.value= userLongitude;
    
} */ 
var apkFlag = false;
function isAndroid() {
	apkFlag = true;

}

	/* ends here*/
	
	/*login work apurv*/
	function submitform()
		{
		 var encryptedString = $.jCryption.encrypt($("#lastname").val(),passwordnew);                                                                    

         if(encryptedString!=""){

         //str3  = hex_md5($("#password").val());

         //var encMDPwd = encryptData(str3);

         //$("#encryptedPassword").val(encMDPwd);

         $("#lastname").val(encryptedString);

         //$("#password").attr("value",encryptedString);
         }
         var encryptedUserId = $.jCryption.encrypt($("#useridloginradio").val(),passwordnew);
         if(encryptedUserId != ""){
        	 $("#useridloginradio").val(encryptedUserId);
         }
         
         var encryptedEmailMobileId = $.jCryption.encrypt($("#emailmobileloginradio").val(),passwordnew);
         if(encryptedEmailMobileId != ""){
        	 $("#emailmobileloginradio").val(encryptedEmailMobileId);
         }
         
         //validation of DOB 
         if($("#collapseOneCust").hasClass("in"))
         {
        	 var srcKey = $.jCryption.encrypt("customerSrcKey",passwordnew); 
        	 $("#sourceKey").val(srcKey);               	 

	         if($("#custLogin_DOB").val() != "")
	         {        	    
        	 var custDOB = $.jCryption.encrypt( $("#custLogin_DOB").val(),passwordnew);        	 	        	                	
        	 $("#custLogin_DOB").val(custDOB);	        	
	         }  
         }  

	document.getElementById('PWD_ERROR_MSG').innerHTML ="";
         document.getElementById('DOB_ERROR_MSG').innerHTML ="";
	
//	document.getElementById("loginReqFunctionality").value="";
 if((document.f.username.value==null)||(document.f.username.value=="") || (document.f.username.value==document.f.username.title))
		{
	
		document.getElementById('UN_ERROR_MSG').innerHTML = 'Please Enter Username';
	
		showError("error-div");
		
		hideError("error-div1");
		hideError("custLogin_DOBErrorDiv");		
		document.f.username.focus();
		
		
		}
	
	else{
		
		if($("#collapseOneCust").hasClass("in") && $("#custLogin_DOB").val() == "")
		{				
			showError("custLogin_DOBErrorDiv");
			$('#DOB_ERROR_MSG').html("Please select the DOB");
			document.getElementById('DOB_ERROR_MSG').innerHTML = 'Please select the DOB';
			hideError("error-div");
			hideError("error-div1");		
			$('#CustLogin_datepicker').focus();			
		}
		
		else if((document.f.j_password.value==null)||(document.f.j_password.value=="") || (document.f.j_password.value==document.f.j_password.title))
		{
			//document.getElementById("error-div1").className = "";
			showError("error-div1");
			
			document.getElementById('PWD_ERROR_MSG').innerHTML = 'Please Enter Password';
			
		
		document.f.j_password.focus();
		
		
		}
		
		else{  
			  
			var unSecuredElementIdArray = ["reqPolicyNumber","dob_day","dob_year","nonLoginPolicy","nonLoginAppTracker"]; //nonLoginPasa
			for(var i=0;i<unSecuredElementIdArray.length;i++)
			{
				document.getElementById(unSecuredElementIdArray[i]).value="";	
			}
			
			
			document.f.j_username.value = document.f.username.value;
			
			var correctDiv = ["userNameErrCorrect","pwdErrCorrect","userNameErrCorrectPL","pwdErrCorrectPL","userNameErrCorrectEL","pwdErrCorrectEL"]; //
//			for(var i=0;i<correctDiv.length;i++)
//			{
//				$("#"+correctDiv[i]).removeClass("merger_none");
//			}
			if($("#collapseThree").hasClass("in")){
				$("#nonLoginLdap").attr("checked","checked");
				
			}
			if($("#collapseFour").hasClass("in")){
				$("#nonLoginSCB").attr("checked","checked");
				
			}

						
		
			document.f.lattitude.value = document.f.lattitude.value;
			document.f.longitude.value = document.f.longitude.value;
			
				
			
			
			hideAllLoginError();
			$("#loginBtn").hide();
			document.f.submit();
		}
		
	}		

}


	
	function appTrackerReqCallBack(response)
	{
//		var resultJson = eval('(' + response + ')');
		var result = $.parseJSON(response);
		
		if(result!=null && result != undefined)
		{
			if(result.result=="2")
			{
				document.getElementById("PWD_ERROR_MSG").style.display="none";
				document.getElementById("reqPolicyNumber").readOnly=true;
				document.getElementById('PWD_ERROR_MSG_DOB').innerHTML = "ATS not generated. Please provide DOB";
				
				undoLoadingMask();	
				showDobDetails();
				
			}
			else if(result.result=="3" || result.result=="4" || result.result=="7" || result.result=="6" || result.result=="8")
			{
				undoLoadingMask();
				document.getElementById('PWD_ERROR_MSG_DOB').innerHTML = "Invalid Application No, DOB";
				
				//reloadUnsecCaptcha(); // changes for removal of captcha
			}
			else if(result.result=="1")
			{
				var policyNo=result.policyNo;
				window.location.href="csr_apptracker.htm", '_blank';

//				document.getElementById("nonLoggedInSecTab").click();
//				document.getElementById("nonLoginAppTracker_label").click();
			}
			else if(result.result=="5")
			{
				$("#reqPolicyNumber").val(result.appNo);
				$("#reqPolicyNumber").val($("#reqPolicyNumber").val().toUpperCase());
				
//				document.getElementById("reqPolicyNumber").value=document.getElementById("reqPolicyNumber").value.toUpperCase();

				document.f.submit();
			}
			/* else if(result.result=="PI2")
			{
				undoLoadingMask();
				document.getElementById('PWD_ERROR_MSG_DOB').innerHTML = "Captcha did not match";
		
				
			}
			else if(result.result=="PI3" || result.result=="PI4")
			{
				undoLoadingMask();
				document.getElementById('PWD_ERROR_MSG_DOB').innerHTML = "Invalid Application No, DOB";
				
				//reloadUnsecCaptcha();
			}
			else if(result.result=="PI5")
			{
				undoLoadingMask();
				document.getElementById('PWD_ERROR_MSG_DOB').innerHTML = "Unable to process your request, Please try after some time";
				
				
			}
			else if(result.result=="PI1")
			{	
				var policyNo=result.policyNo;
				//window.open("csr_preIssuance.htm?appNo="+encodeURIComponent(result.encryptedAppNo)+"&policyNo="+policyNo, '_blank');
				window.open("csr_preIssuance.htm?appNo="+encodeURIComponent(result.appNo), '_blank');
				resetNonLoggedInSection("PreIssuance");
			} */
			else if(result.result=="9")
			{	
				var appTrackerLink=result.appTrackerLink;
				undoLoadingMask();
//				document.getElementById("nonLoggedInSecTab").click();
//				document.getElementById("nonLoginAppTracker_label").click();
				window.open(appTrackerLink, '_blank');
			}
			else if(result.result=="InstaRedirect")
			{
				var instaRedirectLink=result.instaRedirectURL;
				undoLoadingMask();
//				document.getElementById("nonLoggedInSecTab").click();
//				document.getElementById("nonLoginAppTracker_label").click();
//				window.open(instaRedirectLink, '_blank');
				window.location.href=instaRedirectLink, '_blank';
			}
		}
	}
	function resetNonLoggedInSection()
	{
		var elementIdArray=['reqPolicyNumber','dob_day','dob_year']; //,'emailId','mobileNo','panNo'
		var isAppTrackerReq=getRadioValue("isAppTracker");
		
		for(var count=0;count<elementIdArray.length;count++)
		{
			document.getElementById(elementIdArray[count]).value=document.getElementById(elementIdArray[count]).title;
		}
		
		if(isAppTrackerReq=="Yes")
		{
			hideDobDetails();
		//	hideAdditionalUnsecParams();
		}
		else if(isAppTrackerReq=="No")
		{
			showDobDetails();	
		//	hideAdditionalUnsecParams();
		}
		else if(isAppTrackerReq=="PASA")
		{
			showDobDetails();	
		//	showAdditionalUnsecParams();
		}
		removeAppPolicyErr();
		document.getElementById("reqPolicyNumber").readOnly=false;
		document.getElementById('PWD_ERROR_MSG_DOB').innerHTML = "";
	//	dobMonthSelectBox.data("selectBox-selectBoxIt").selectOption(0);
	}
function formRequestCallbackWithoutMask(url, eventId, callBackFunction) {
	doLoadingMask();
	//making url for submit
	
	//var formElement = document.getElementById(formElementId);
	//var url = formElement.action;
	url = url + "&_eventId=" + eventId;
	
	
	
	jQuery.ajax({ // create an AJAX call...
		//data : jQuery(formElement).serialize(), 
		type : jQuery(this).attr('method'), 
		url : url, 
		success : function(ajaxResponse) {
			//secs=sessionTime;
			callBackFunction(ajaxResponse);
			
			

		},
	
		error :function(ajaxResponse){
			
			alert("GEN99: Technical Error");
			//window.location.href="error.htm";
			if (returntype == true) {
				errorhandler(response.status);
				
			} else if (returntype == false) {
				errorhandlerJson(response.status);
			}

		}
	});
}

function validateDateData()
{
	var year = document.getElementById('dob_year').value;
	var month = document.getElementById('dob_month').value;
	var day = document.getElementById('dob_day').value;
	
	var days = (year == ' ' || month == ' ')
	? 31 : daysInMonth(month,year);
	var now1 = new Date();
	var presentyear=now1.getFullYear();
	var presentmonth=now1.getMonth() + 1;
	var presentday=now1.getDate();
	
	
	if(year.length<4 && year.length>0){
		
		$("#dobCorrect").addClass("merger_none");
		$("#dobIncorrect").removeClass("merger_none");
		
		document.getElementById('dobIncorrectTxt').innerHTML="Please enter year in the YYYY format";
		document.f.dob.value = null;
		document.getElementById('dob_year').value="";
		document.getElementById('dob_year').focus();
		return false;
	}

	if((day>days || Number(day)<=0)&& ( year.length > 0)  )
	{
		document.getElementById('dobIncorrectTxt').innerHTML="Please select valid date";
		$("#dobCorrect").addClass("merger_none");
		$("#dobIncorrect").removeClass("merger_none");
		document.getElementById('dob_day').value="";
		document.getElementById('dob_day').focus();
		document.f.dob.value = null;
		return false;

	}
	
	if(Number(year) > Number(presentyear) || Number(year) < Number(1930) && year!="" && year !="yyyy" ){
		//document.getElementById('PWD_ERROR_MSG_DOB').style.display="block"
		document.getElementById('dobIncorrectTxt').innerHTML="Please enter valid year";
		$("#dobCorrect").addClass("merger_none");
		$("#dobIncorrect").removeClass("merger_none");
		document.getElementById('dob_year').value="";
		document.getElementById('dob_year').focus();
		document.f.dob.value = null;
		return false;	

	}

	if(Number(month)==Number(presentmonth) && 

			Number(year)>=Number(presentyear) && Number(presentday)<Number(day) ){
		//document.getElementById('PWD_ERROR_MSG_DOB').style.display="block";
		document.getElementById('dobIncorrectTxt').innerHTML="Date of Birth cannot be greater than present date";
		$("#dobCorrect").addClass("merger_none");
		$("#dobIncorrect").removeClass("merger_none");
		document.getElementById('dob_year').value="";
		document.getElementById('dob_year').focus();
		document.f.dob.value = null;
		return false;	

	}	
	if(Number(month)>Number(presentmonth) && 

			Number(year)>=Number(presentyear) ){
		//document.getElementById('PWD_ERROR_MSG_DOB').style.display="block";
		document.getElementById('dobIncorrectTxt').innerHTML="Date of Birth cannot be greater than present date";
		$("#dobCorrect").addClass("merger_none");
		$("#dobIncorrect").removeClass("merger_none");
		document.getElementById('dob_year').value="";
		document.getElementById('dob_year').focus();
		document.f.dob.value = null;
		return false;	

	}

	/* if(year!="" && year !="yyyy"){
		
	var agecheck=validateage_acb();
	alert(agecheck);
	if(Number(agecheck)<18)
		{
		//document.getElementById('PWD_ERROR_MSG_DOB').style.display="block";
		document.getElementById('PWD_ERROR_MSG_DOB').innerHTML="Age cannot be less than 18 Yrs";
		document.f.dob.value = null;
		document.getElementById('dob_year').value="";
		document.getElementById('dob_year').focus();
		return false;	
		}} */
	return true;
}
function daysInMonth(month,year) {

	var dd = new Date(year, month, 0);

	return dd.getDate();
	}
function validateage_acb()
{
	var monthArray=new Array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	var day=document.getElementById("dob_day").value;
	var month=document.getElementById('dob_month').value;
    for(var i=0;i<monthArray.length;i++)
    	{
    		if(monthArray[i]==month)
    			{
    				month=i+1;
    				break;
    			}
    	}
	var year =document.getElementById("dob_year").value;
	var now = new Date();
	var agechck=0;
	
	var currentyear = now.getFullYear();
	var currentmonth=now.getMonth()+1;
	
	var currentday=now.getDate();
	
	var diff_m=Number(currentmonth) -Number(month);
	var diff_d=Number(currentday) - Number(day);
	
	if(diff_m<0)
		{
		agechck=currentyear-year-1;
		}
	else if(diff_m>0)
		{
		agechck=currentyear-year;
		}
	else if(diff_m==0)
		{
		if(diff_d<0)
			{
			agechck=currentyear-year-1;
			}
		else if(diff_d>0)
			{
			agechck=currentyear-year;
			}
		else if(diff_d==0)
			{
			agechck=currentyear-year;
			}
		}
	
	return agechck;
}

if(document.getElementById("socialAppName")!=null)
{
	document.getElementById("socialAppName").innerHTML =socialApp;	
}

function reload()
{
  /*  document.getElementById("captchaIFrame").contentWindow.location.reload();
    document.getElementById("captchaent").value="";*/
	var random = Math.floor((Math.random()*15000000)+1);
	$("#captchaIFrame").prop("src", "CaptchaGenerator?"+ random);
	document.getElementById("captchaent").value="";
}

/*
function reloadUnsecCaptcha()
{
    document.getElementById("captchaIFrame_Unsec").contentWindow.location.reload();
    document.getElementById("captchaent_unsec").value=document.f.captchaent_unsec.title;
    
}*/
function doLoadingMask() {
		    $("#loadingMask").dialog({
		        modal: true,
		        width: 80,
		        height: 80,
		        position: [(window.width / 2),100],
		        closeOnEscape: false,
		        resizable: false,
		        open: function(event, ui) {
		            $(".ui-dialog-titlebar-close").hide();
		            $(".ui-dialog-titlebar").hide();
		            maskLoop = 1;
		           
		        }
		    });
}
function undoLoadingMask() {
			
		    $("#loadingMask").dialog("close");
		    $(".ui-dialog-titlebar-close").show();
		    $(".ui-dialog-titlebar").show();
}

function copyUserName(value){
	document.getElementById("firstname").value = value;
	
}
function copyPwd(value){
	document.getElementById("lastname").value = value;
	
}


/**
 * For Customer Login- id=1
 * For Partner Login- id=2
 * For Employee Login- id=3
 * 
 */
function resetField(id){
	
	document.getElementById("firstname").value = document.getElementById("firstname").title;
	document.getElementById("lastname").value = document.getElementById("lastname").title;
	
	/*var errLbl = ["UN_ERROR_MSG","PWD_ERROR_MSG"];
	for(var i=0;i<errLbl.length;i++){
		document.getElementById(errLbl[i]).innerHTML="";
	}
	hideAllLoginError();
*/	
	
	if(id=="1")
	{
		//$("#dynamicLoginAccrdn").addClass("merger_login_customer_form merger_form_main");
		document.getElementById("dynamicLoginAccrdn").className="merger_login_customer_form merger_form_main";
		document.getElementById("firstname").title="Enter User Id/Email/Mobile *";
		document.getElementById("firstname").value="Enter User Id/Email/Mobile *";
		document.getElementById("lastname").title="";
		document.getElementById("lastname").value="";
		document.getElementById("lastname").title="Password";
		document.getElementById("lastname").value="Password";
		$("#unlockPwdEmployee").addClass('merger_none2');
		$("#collapseThree").removeClass('in');
		$("#collapseTwo").removeClass('in');
		$("#collapseFour").removeClass('in');
		$('#cust_login_dob').removeClass('merger_none');
		$("#forgot_password").removeClass('merger_none2');
		// $("#sign_Up").removeClass('merger_none2');
		
		// sushma: done to hide signup and forgot password //
		//$("#forgot_password").addClass('merger_none2');
		$("#sign_Up").addClass('merger_none2');
		$("#forgot_password").html('Signup/Forgot Password?');
		if(($('#collapseOneCust').attr('class').split(' ')).indexOf("in") > 0){
			document.getElementById("dynamicLoginAccrdn").className="merger_none2";
			
		} 
	    //$("#collapseOneCust").addClass('in').css('height','auto');
	}
	if(id=="2")
	{  
		//$("#forgot_password").removeClass('merger_none2');	
		document.getElementById("dynamicLoginAccrdn").className="merger_login_partner_form merger_form_main";
		document.getElementById("firstname").title="Enter User Id/Email/Mobile *";
		document.getElementById("firstname").value="Enter User Id/Email/Mobile *";
		$("#unlockPwdEmployee").addClass('merger_none2');
		// added for partner servicing
		$("#sign_Up").addClass('merger_none2');
		//$("#forgot_password").addClass('merger_none2');
		$("#forgot_password").html('Signup/Forgot Password?');
		$("#collapseThree").removeClass('in');
		$("#collapseOneCust").removeClass('in');
		$("#collapseFour").removeClass('in');
		$('#cust_login_dob').addClass('merger_none');
		// added for hiding Sign_Up and forgot password
		$("#sign_Up").addClass('merger_none2');
		//$("#forgot_password").addClass('merger_none2');
		$("#forgot_password").html('Forgot Password/Signup');
		//	$("#collapseTwo").removeClass('in');
		//	$("#collapseOneCust").removeClass('in');
//		$("#sign_Up").removeClass('merger_none2');	//Hiding forgot password option for Employee Login
		//if(($('#collapseTwo').attr('class').split(' ')).indexOf("in") > 0){
		//	document.getElementById("dynamicLoginAccrdn").className="merger_none2";
		//} 
		
	}
	if(id=="3")
	{
		document.getElementById("dynamicLoginAccrdn").className="merger_login_employee_form merger_form_main";
		document.getElementById("firstname").title="Enter User Id/Email/Mobile *";
		document.getElementById("firstname").value="Enter User Id/Email/Mobile *";
		$("#collapseTwo").removeClass('in');
		$("#collapseOneCust").removeClass('in');
		$("#collapseFour").removeClass('in');
		$('#cust_login_dob').addClass('merger_none');
		$("#forgot_password").addClass('merger_none2');
		$("#unlockPwdEmployee").addClass('merger_none2');
		$("#sign_Up").addClass('merger_none2');
		$("#forgot_password").html('Forgot Password?');
		if(($('#collapseThree').attr('class').split(' ')).indexOf("in") > 0){
			document.getElementById("dynamicLoginAccrdn").className="merger_none2";
		} 
	}
	// added by Sushma for SCB placeholder
	if(id=="4")
	{
		document.getElementById("dynamicLoginAccrdn").className="merger_login_scb_form merger_form_main";
		document.getElementById("firstname").title="Enter User Id/Email/Mobile *";
		document.getElementById("firstname").value="Enter User Id/Email/Mobile *";
		$("#unlockPwdEmployee").removeClass('merger_none2');
		$("#collapseTwo").removeClass('in');
		$("#collapseOneCust").removeClass('in');
		$("#collapseThree").removeClass('in');
		$('#cust_login_dob').addClass('merger_none');
		$("#forgot_password").removeClass('merger_none2');
		$("#sign_Up").addClass('merger_none2');
		$("#forgot_password").html('Forgot Password?');
		if(($('#collapseFour').attr('class').split(' ')).indexOf("in") > 0){
			document.getElementById("dynamicLoginAccrdn").className="merger_none2";
		}
	}


}



function validatePolicyAppNo(isAppTrackerReq)
{
	if((document.f.reqPolicyNumber.value==null)||(document.f.reqPolicyNumber.value=="") || (document.f.reqPolicyNumber.value==document.f.reqPolicyNumber.title))
	{
		if(isAppTrackerReq=="Yes")
		{
			document.getElementById('appNoIncorrectTxt').innerHTML = 'Please Enter Application Number';
			$("#appNoIncorrect").removeClass("merger_none");
			$("#appNoCorrect").addClass("merger_none");
		}
		else if(isAppTrackerReq=="No" || isAppTrackerReq=="PASA")
		{
			document.getElementById('appNoIncorrectTxt').innerHTML = 'Please Enter Policy Number';
			$("#appNoIncorrect").removeClass("merger_none");
			$("#appNoCorrect").addClass("merger_none");
		}
		else if(isAppTrackerReq=="No_PI")
		{
			document.getElementById('appNoIncorrectTxt').innerHTML = 'Please Enter Application Number';
			$("#appNoIncorrect").removeClass("merger_none");
			$("#appNoCorrect").addClass("merger_none");
		}
		document.f.reqPolicyNumber.focus();
		return false;
	}
	else if(document.f.reqPolicyNumber.value.length<8 && (isAppTrackerReq=="No" || isAppTrackerReq=="PASA"))
	{
		for(var i=document.f.reqPolicyNumber.value.length;i<8;i++)
		{
			document.f.reqPolicyNumber.value="0"+document.f.reqPolicyNumber.value;
		}
		$("#appNoIncorrect").addClass("merger_none");
		$("#appNoCorrect").removeClass("merger_none");
		return true;
	} 
	$("#appNoIncorrect").addClass("merger_none");
	$("#appNoCorrect").removeClass("merger_none");
	return true;
}

function hideDobDetails()
{
	document.getElementById("dobRow").style.display="none";
	document.getElementById("dobHint").style.display="none";
	dobRequired=false;
}
function showDobDetails()
{
	document.getElementById("dobRow").style.display="block";
	document.getElementById("dobHint").style.display="block";
	dobRequired=true;
}

function toggleAppNoPolicyNo()
{
//	var radioElementId=labelId.replace("_label","");
//	document.getElementById(radioElementId).click();
	
	var isAppTrackerReq=getRadioValue("isAppTracker");
//	toggleRadioClass("isAppTracker");
	document.getElementById("reqPolicyNumber").value="";
	
	if(isAppTrackerReq=="Yes")
	{
//		$("#reqPolicyNumber").attr({ maxLength : 15 });
		document.getElementById("reqPolicyNumber").title="Application No *";
		document.getElementById("reqPolicyNumber").value="Application No *";
	}
	else if(isAppTrackerReq=="No" || isAppTrackerReq=="PASA")
	{
//		$("#reqPolicyNumber").attr({ maxLength : 8 });
		document.getElementById("reqPolicyNumber").title="Policy No *";
		document.getElementById("reqPolicyNumber").value="Policy No *";
	}
	
}

function validateDob()
{
	if(document.getElementById("dob_day").value=="" || document.getElementById("dob_day").value==null || document.getElementById("dob_day").value==document.getElementById("dob_day").title)
	{
		document.getElementById('dobIncorrectTxt').innerHTML = 'Please Enter date';
		$("#dobCorrect").addClass("merger_none");
		$("#dobIncorrect").removeClass("merger_none");
		document.getElementById("dob_day").focus();
		return false;
	}
	if(document.getElementById("dob_day").value.length<2)
	{
		document.getElementById("dob_day").value="0"+document.getElementById("dob_day").value;
	}
	else if(document.getElementById("dob_day").value<1 || document.getElementById("dob_day").value>31)
	{
		document.getElementById("dob_day").value="";
		document.getElementById('dobIncorrectTxt').innerHTML = 'Please Enter valid date';
		$("#dobCorrect").addClass("merger_none");
		$("#dobIncorrect").removeClass("merger_none");
		document.getElementById("dob_day").focus();
		return false;
	}
	if(document.getElementById("dob_year").value=="" || document.getElementById("dob_year").value==null || document.getElementById("dob_year").value==document.getElementById("dob_year").title)
	{
		document.getElementById('dobIncorrectTxt').innerHTML = 'Please Enter year';
		$("#dobCorrect").addClass("merger_none");
		$("#dobIncorrect").removeClass("merger_none");
		document.getElementById("dob_year").focus();
		return false;
	}
	
	
	if(!validateDateData())
	{
		return false;
	}
	$("#dobCorrect").removeClass("merger_none");
	$("#dobIncorrect").addClass("merger_none");
	return true;
}

function hideError(id){
	$("#"+id).addClass("merger_none");
}
function showError(id){
	$("#"+id).removeClass("merger_none");
}

function hideAllLoginError(){
	
	var incorrectDiv = ["error-div","error-div1","custLogin_DOBErrorDiv"]; 
	
	
	for(var i=0;i<incorrectDiv.length;i++)
	{
		$("#"+incorrectDiv[i]).addClass("merger_none");
	}
}

function showAllLoginError(){
	
	var incorrectDiv = ["error-div","error-div1","custLogin_DOBErrorDiv"]; 
	
	
	for(var i=0;i<incorrectDiv.length;i++)
	{
		$("#"+incorrectDiv[i]).removeClass("merger_none");
	}
}

function correctUserName(){
	
	$("#userNameErrCorrect").removeClass("merger_none");
	hideAllLoginError();
}

function inCorrectUserName(){
	
	$("#userNameErrCorrect").addClass("merger_none");
	showAllLoginError();
}
function defaultLoginPopup(){
var incorrectDiv = ["error-div","error-div1","userNameErrCorrect"]; 
	
	
	for(var i=0;i<incorrectDiv.length;i++)
	{
		$("#"+incorrectDiv[i]).addClass("merger_none");
	}
}
function removeAppPolicyErr(){
	document.getElementById('appNoIncorrectTxt').innerHTML = '';
	$("#appNoIncorrect").addClass("merger_none");
	$("#appNoCorrect").addClass("merger_none");
	$("#dobCorrect").addClass("merger_none");
	$("#dobIncorrect").addClass("merger_none");
}


function test(){
	
	$("#collapseTwo").append("<h3>sec</h3<div>test</div>").accordion();
}




//for forgot password and Sign Up

function onfocus_placeHolder(idvalue)
{
	if(document.getElementById(idvalue).title==document.getElementById(idvalue).value)
	{
		document.getElementById(idvalue).value="";
	}
}

function onblur_placeHolder(idvalue)
{
	if(document.getElementById(idvalue).value=="")
	{
		document.getElementById(idvalue).value=document.getElementById(idvalue).title;
	}
}

function showTittle(loginRole,functionality)
{//alert(functionality);
	if(functionality=="signUp"){
		//alert(loginRole);
		if(loginRole=="customer"){
		$("#forgotPwdDiv").text("Sign Up Customer");
		}
	   else if(loginRole=="partner"){
			$("#forgotPwdDiv").text("Sign Up Partner");
			}
		}
		else
			{
			if(loginRole=="customer"){
			$("#forgotPwdDiv").text("Signup / Forgot Password");
			}
			else if (loginRole=="partner"){
				$("#forgotPwdDiv").text("Forgot Password / Sign Up Partner");
			}
	}
}
function showHideAgent(loginRole,functionality)
{
	showTittle(loginRole,functionality);
	//if(document.getElementById("radioCustLogin").checked==true)
		if(loginRole=="customer")
	{
		hideDiv("agentDiv");
		hideDiv("submit_signup_agent");
		showDiv("customerDiv");
		showDiv("submit_signup_customer");		
		
		$("#dob_error_label").text("");
		$("#dob_error").removeClass("merger_form_row_arrow_wrong");
		$("#dob_error").removeClass("merger_form_row_arrow_right");
		$("#dob_day_forgotPasswd").val('');
		$("#dob_year_forgotpasswd").val('');
		
		$("#policy_error_label").text("");
		$("#policy_error").removeClass("merger_form_row_arrow_wrong");
		$("#policy_error").removeClass("merger_form_row_arrow_right");
		$("#policyNumber").val('');
		
		$("#agentCode_error_label").text("");
		$("#agentCode_error").removeClass("merger_form_row_arrow_wrong");
		$("#agentCode_error").removeClass("merger_form_row_arrow_right");
		$("#agentCode").val('');
		
		/* $("#mobile_error_label").text("");
		$("#mobile_error").removeClass("merger_form_row_arrow_wrong");
		
		$("#email_error_label").text("");
		$("#email_error").removeClass("merger_form_row_arrow_wrong"); */
	}
	//else if(document.getElementById("radioAdvisorLogin").checked==true)
	else if(loginRole=="partner")
	{
		//$("#forgotPwdDiv").text("Forgot Password Agent");
		hideDiv("customerDiv");
		hideDiv("submit_signup_customer");
		showDiv("agentDiv");
		showDiv("submit_signup_agent");
		
		$("#dob_error_label").text("");
		$("#dob_error").removeClass("merger_form_row_arrow_wrong");
		$("#dob_error").removeClass("merger_form_row_arrow_right");
		$("#dob_day_forgotPasswd").val('');
		$("#dob_year_forgotpasswd").val('');
		
		$("#policy_error_label").text("");
		$("#policy_error").removeClass("merger_form_row_arrow_wrong");
		$("#policy_error").removeClass("merger_form_row_arrow_right");
		$("#policyNumber").val('');
		
		$("#agentCode_error_label").text("");
		$("#agentCode_error").removeClass("merger_form_row_arrow_wrong");
		$("#agentCode_error").removeClass("merger_form_row_arrow_right");
		$("#agentCode").val('');
		
		/* $("#mobile_error_label").text("");
		$("#mobile_error").removeClass("merger_form_row_arrow_wrong");
		
		$("#email_error_label").text("");
		$("#email_error").removeClass("merger_form_row_arrow_wrong"); */
	}
}

function linkRedirectionNewTab(url)
{
	if(url!=null && url!= undefined && url!="null" && url!="undefined")
		window.open(url,'_blank');
}