angular.module('common', [])
.value('transformer', {
	global : {},
	formId : {},
	formBackUp :{},
	tk : "",
	setFormElement : function(fieldId, fieldValue) {
		if (this.formId == undefined)
			console.error("Error");
		else {
			var formObj = this.global[this.formId];
			var element = angular.element(document.getElementById(fieldId));
			var elementName = element.attr("name");
			if(elementName.indexOf(".") > -1){
			   if(formObj.hasOwnProperty(elementName.split(".")[0])){
			   		var p = formObj[elementName.split(".")[0]];
			   		p[elementName.split(".")[1]] = fieldValue;
			   		formObj[elementName.split(".")[0]] = p;
			   }
    			else{
     				var p = {};
     				p[elementName.split(".")[1]] = fieldValue;
     				formObj[elementName.split(".")[0]] = p;
     			}
   			 }
   			 else{
   			 	 formObj[elementName] = fieldValue;
   			 }
			element.attr("value",fieldValue);
		}
	},
	addFormElementToBackUp : function(formId,elementId){
		if (this.global[formId] == undefined)
			console.error("Error");
		else {
			if(!this.formBackUp.hasOwnProperty(formId)){
			   this.formBackUp[formId] ={};
			}
			var formBackUpObj = this.formBackUp[formId];
			var formObj = this.global[formId];
			var element = angular.element(document.getElementById(elementId));
			var elementName = element.attr("name");
			var elementValue= element.attr("value");
			if(elementName.indexOf(".") > -1){
				if(formBackUpObj.hasOwnProperty(elementName.split(".")[0])){
					var formElementObj = formBackUpObj[elementName.split(".")[0]];
					formElementObj[elementName.split(".")[1]] = elementValue;
					formBackUpObj[elementName.split(".")[0]] = formElementObj;  	
				}
				else{
				  	var p = {};
					p[elementName.split(".")[1]] = elementValue;
					formBackUpObj[elementName.split(".")[0]] = p;
				}
	   	    }
   			 else{
   			 	 formBackUpObj[elementName] = elementValue;
   			}

		}
	},
	copyElementsFromFormBackUp : function(formId){
		if(!this.formBackUp.hasOwnProperty(formId)){
			console.error("Error");
		}
		else if(!this.global.hasOwnProperty(formId)){
			console.error("Error");
		}
		else{
			var formObj = this.global[formId];
			var formBackUpObj = this.formBackUp[formId];
			angular.forEach(formBackUpObj, function(formBackUpElement,key) {
				if(formObj.hasOwnProperty(key)){
					if(angular.isObject(formBackUpElement) && angular.isObject(formObj[key])){
						var subFormObj = formObj[key];
						angular.forEach(formBackUpElement, function(formSubElement,subKey) {
						    if(subFormObj.hasOwnProperty(subKey)){
								subFormObj[subKey] = formSubElement;
								angular.element(document.getElementsByName(key+"."+subKey)[0]).attr("value",formSubElement);
							}
						});
						formObj[key] = subFormObj
						
					}
					else{
						formObj[key] = formBackUpElement;
						angular.element(document.getElementsByName(key)[0]).attr("value",formBackUpElement);
					}
				}
				
			});
		}
	},
	emptyFormElement : function(formId) {
		if (this.global[formId] == undefined)
			console.error("Error");
		else {
			var formObj = this.global[this.formId];
			var element = angular.element(document.getElementById(formId));
			angular.forEach(element.find("input"), function(formElement) {
				if(formElement.type == "hidden"){
				    var elementName = formElement.name;
					if(elementName.indexOf(".") > -1){
					   if(formObj.hasOwnProperty(elementName.split(".")[0])){
					   		var p = formObj[elementName.split(".")[0]];
					   		p[elementName.split(".")[1]] = "";
					   		formObj[elementName.split(".")[0]] = p;
					   }
		   			 }
		   			 else{
		   			 	 formObj[elementName] = "";
		   			 }
					formElement.value = "";
				}
				
			});
		}
	}
})
.directive('form', ['transformer',function(transformer) {
	return {
		restrict : 'E',
		link : function(scope, element, attrs) {
			var formObj = {};
			angular.forEach(element.find("input"), function(value) {
			    if(value.id.indexOf("_tk") > -1){
			      transformer.tk = value.value;
			    }
				if (value != null && value.type == "hidden") {
					if(value.name.indexOf(".") > -1){
					   if(formObj.hasOwnProperty(value.name.split(".")[0])){
					   		var p = formObj[value.name.split(".")[0]];
					   		p[value.name.split(".")[1]] = value.value;
					   		formObj[value.name.split(".")[0]] = p;
					   }
		    			else{
		     				var p = {};
		     				p[value.name.split(".")[1]] = value.value;
		     				formObj[value.name.split(".")[0]] = p;
		     			}
		   			 }
		   			 else{
		   			 	 formObj[value.name] = value.value;
		   			 }
					
				}
			});
				
			if(angular.isUndefined(attrs.id))
			  transformer.global[attrs.name] = formObj;
			  else
			  transformer.global[attrs.id] = formObj;
		}
	}
}])


