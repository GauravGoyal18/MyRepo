var app=angular.module('groupApp',['ui.materialize','uiValidations','ajaxUtil','ngRoute','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection','groupCommonUtil']);

app.controller('brokerAccruedCommissionSummaryController',['$rootScope','$scope','ajaxHttpFactory','$location','$window','$filter','$http','$rootScope','uiGridConstants','csrDocUploadFactory', function($rootScope,$scope,ajaxHttpFactory,$location,$window,$filter,$http,$rootScope,uiGridConstants,csrDocUploadFactory){
	
	$rootScope.preloaderCheck=false;
	
	$scope.logs={};
	$scope.errorArray=[];

	$scope.successResponse='';
	var ajaxurl=$location.absUrl();
	$scope.result=[];
	$scope.accruedCommissionSummaryView={};
	$scope.accruedCommissionSummaryData=[];
	$scope.accruedCommissionSummaryViewDiv=false;
	
	
	
	 $scope.openClosed="openClose";
	 var paginationOptions = {
			    pageNumber: 1,
			    pageSize: 10,
			    sort: null
			  };
	 
	 
	var onLoadData=function(){			
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("loadbrokerAccruedCommissionSummary",ajaxurl)
		.then(function(bizRes){	
			
			if(ajaxHttpFactory.handleIPruException(bizRes.data, "errorMessage-popup", "exceptionAlert")){
				
							
				$rootScope.preloaderCheck=false;
			}			
			var responseData = bizRes.data;
			$scope.accruedCommissionSummaryData=responseData;
			$scope.accruedCommissionSummaryView.totalItems=$scope.accruedCommissionSummaryData.length;

			
			$scope.accruedCommissionSummaryViewDiv=true;
			
			$scope.getPageOC();
			
			$rootScope.preloaderCheck=false;					
		},
		function(errResponse){
			$rootScope.preloaderCheck=false;			
		});
};
	
onLoadData();
	

$scope.getPageOC = function() {
	 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
    $scope.accruedCommissionSummaryView.data=$scope.accruedCommissionSummaryData.slice(firstRow, firstRow + paginationOptions.pageSize);	     
   
	};

	 
	 $scope.accruedCommissionSummaryView = {			 				
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,			   
			    enableRowSelection: false,		      	     
		        resizable: false,
		        enableColumnResizing: false,
		        enableSorting: false,		       
		        
			    columnDefs: [
			           { field: 'branchCode', displayName: 'Branch Code',headerTooltip:function(col){return col.displayName;}, width: "10%"},
			           { field: 'nationalCode',displayName: 'National Code',headerTooltip:function(col){return col.displayName;}, width: "12%"},
			           { field: 'policynumber',  displayName: 'Policy Number',headerTooltip:function(col){return col.displayName;}, width: "12%"},
			           { field: 'premiumWithStec', displayName: 'Premium With STEC',width: "14%",headerTooltip:function(col){return col.displayName;}, width: "15%"},
			           { field: 'premiumExclStec', displayName: 'PremiumEXCLSTEC',headerTooltip:function(col){return col.displayName;}, width: "15%"},
			           { field: 'commissionAmount', displayName: 'Commission Amount',headerTooltip:function(col){return col.displayName;}, width: "15%"},
			           { field: 'productName', displayName: 'Product Name',headerTooltip:function(col){return col.displayName;}, width: "25%"},
			           { field: 'policyIssuanceDate', displayName: 'Policy Issuance Date',headerTooltip:function(col){return col.displayName;}, width: "15%"}

			     	      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageOC();
			      });			      			 
			    }
			  };
	 
	
	
		
		
	
	



	
	$scope.dataAlert= function (){
		$rootScope.openAlertID = false;											
		$window.location.href = "dashboard.htm";
	};


	$scope.successMethod = function(bizRes) {		
		if(!ajaxHttpFactory.handleIPruException(bizRes, "errorMessage-popup", "exceptionAlert")){					
			$scope.result=bizRes;
			$rootScope.preloaderCheck=false;
		}
	};
		
	$scope.failureMethod = function(bizRes) {
		if(!ajaxHttpFactory.handleIPruException(bizRes, "errorMessage-popup", "exceptionAlert")){			
			$rootScope.preloaderCheck=false;
		}
	};	
    
	
	
	
	
}]);