var allServicesApp = angular.module('ipruApp', [ 'ajaxUtil', 'uiComponents','overlay-spinner']);
allServicesApp.controller('AllServiceDashboardCntrl', ['$scope', 'ajaxHttpFactory', '$location','$timeout', '$filter', 'allServicesFactory', function($scope, ajaxHttpFactory, $location, $timeout, $filter, allServicesFactory) {
	  
	  //start : Variables initialization
	    $scope.funcDetails = angular.fromJson(allServicesDetails.funcDisplayVO);
	    $scope.groupMapDetails = allServicesDetails.orderedFuncMap;
	    $scope.sectionHeaderDetails = [];
	    $scope.subFunctionDetails = [];
	    $scope.details = allServicesFactory.createHeaderAndData($scope.funcDetails, $scope.groupMapDetails);
	    $scope.sectionHeaderDetails = $scope.details["sectionHeaderDetails"];
	    $scope.subFunctionDetails = $scope.details["subFunctionDetails"];

	  //end : Variables initialization

	  //start: function declarations

	    angular.element(document).ready(function () {
	        document.getElementById('page-header-title-span').innerHTML = 'Service Options';
	    });
	   
	    $scope.$on('$viewContentLoaded', function(){
	      //Here your view content is fully loaded !!
	      $scope.$broadcast("triggerClick","top0");
	    });
	    
	    $timeout(function(){
	      $scope.$broadcast("triggerClick","top0");
	    },1000);
	    
	    
		
	  //end: function declarations

	}]);

	allServicesApp.directive('allServicesAccordian',function()
			{
		return {
			restrict : "EA",
			scope:{
			 data : "=",
			 header : "="
			},
			templateUrl:function(elem, attr){
				  if(angular.isUndefined(attr.url))
					  return "digidrive/common/pages/views/html/allServicesDashboard_accordian.html";
				  else
					  return attr.url;
			},
			
			controller: ['$scope', '$window', 'ajaxHttpFactory', '$rootScope',function($scope, $window, ajaxHttpFactory, $rootScope) {
			  
			  //start: function declarations
	    
				$scope.showSlider =  function(event){
				    if ($window.outerWidth > 787){	
				        var parentElementSlider = angular.element(event.currentTarget);
				        var childElementSlider = angular.element(parentElementSlider.children()[2]).toggleClass('inview');
				        parentElementSlider.toggleClass('inview');
				    }
				};
				
				  $scope.funct_blank={
						  resourcecenter:"resourcecenter",
						  psmailbox:"psmailbox",
						  pscms:"pscms",
						  prmimAcknwldgmnt:"prmimAcknwldgmnt",
						  csr_premiumAckRcpt:"csr_premiumAckRcpt",
						  psearnings:"psearnings",
						  pstdscert:"pstdscert",
						  psbsnoverview:"psbsnoverview",
						  psprmdue:"psprmdue",
						  psgrace:"psgrace",
						  pslapse:"pslapse",
						  pscstmbdy:"pscstmbdy",
						  psclntdrysrch:"psclntdrysrch",
						  pstpcust:"pstpcust",
						  pscustprtflio:"pscustprtflio",
						  psrwrdrecog:"psrwrdrecog",
						  psxrt:"psxrt",
						  psmedltr:"psmedltr",
						  psdpstrcpt:"psdpstrcpt",
						  microsite:"microsite",
						  psopenprofile:"psopenprofile",
						  psagent:"psagent",
						  psdl:"psdl",
						  intgrtdDgitlHelp:"intgrtdDgitlHelp",
						  psemplogin:"psemplogin",
						  policysearch:"policysearch",
						  myCustomer:"myCustomer"
						  };
				
				$scope.linkRedirectionUrlWdgt=function(url, id){	
			      $rootScope.$broadcast('pageSpinner',true);
			      
					if ($scope.funct_blank[id]!=undefined){
						$window.open(url, '_blank');
						$rootScope.$broadcast('pageSpinner',false);
					}
				   else{
					   ajaxHttpFactory.linkRedirectionUrl(url);
					}
					};
			  //end: function declarations
	        }]
		};
			});

	allServicesApp.factory('allServicesFactory',function(){
	  
	  var details={};
	  var sectionHeaderDetails =[];
	  var subFunctionDetails =[];
	  
	  
	  return{
	     createHeaderAndData: function(funcDetails,groupMapDetails){
	       
	       angular.forEach(funcDetails,function(displayGrid,index){
	         angular.forEach(groupMapDetails,function(subFunction,section){
	           if (displayGrid["functionality"] ==  section){
	             sectionHeaderDetails.push(displayGrid); 
	           }
	         
	           angular.forEach(subFunction,function(value,index){
	             if (displayGrid["functionality"] ==  value){
	               displayGrid["parent"] = section;
	               subFunctionDetails.push(displayGrid); 
	             }
	           });
	           
	           
	         });
	       });
	       
	       details["sectionHeaderDetails"] = sectionHeaderDetails;
	       details["subFunctionDetails"] = subFunctionDetails;
	       return details;
	       
	     }
	    
	  };
	  
	});