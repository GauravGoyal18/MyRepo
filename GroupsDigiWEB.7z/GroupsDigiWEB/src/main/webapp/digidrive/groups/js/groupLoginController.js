var app = angular.module('groupApp', ['ui.materialize', 'uiValidations', 'ajaxUtil']);

app.controller('groupLoginController', ['$rootScope', '$scope', 'ajaxHttpFactory', '$location', '$http', function($rootScope, $scope, ajaxHttpFactory, $location, $http) {

    $scope.groupLogin = {};
    $scope.showUserIdDiv = true;
    $scope.showEmailIdDiv = false;
    $scope.errorArray = [];
    $scope.errorMessage = errorMessage;
    $rootScope.preloaderCheck = false;
    $scope.showForgotPasswordLink = false;
   /* $scope.showCountryCode = false;
    $scope.showFullMobileNo = false;
    var ajaxurl = $location.absUrl();

    $scope.showMobileNo = true;
    $scope.groupLogin.countryName = "INDIA";
    $scope.countryName = "INDIA";
    $scope.showCountryNames = false;
*/
    var getOnLoadData = function() {
        $rootScope.preloaderCheck = true;
        return ajaxHttpFactory.getJsonData("loadLoginTypeDetails", $location.absUrl())
            .then(function(response) {
                    $rootScope.preloaderCheck = false;
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
                        var loginType = response.data;
                       /* getCountryDetails();*/
                        if (angular.isDefined(loginType)) {
                            if (loginType == "LoginWithEmailMobile") {
                                $scope.groupLogin.loginType = 'loginWithEmailMobile';
                                $scope.onLoadChangeOfLoginType();
                            }
                        }
                    }
                },
                function(response) {
                    $rootScope.preloaderCheck = false;
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

                    }
                });
    };

    getOnLoadData();

/*    $scope.successMethodOfGetCountryNames = function(response) {
        $scope.responseObj = response

        $scope.onChangeCountryName = function() {
            for (var i = 0; i < response.length; i++) {
                if (response[i].countryName == $scope.groupLogin.countryName) {
                    $scope.groupLogin.userName = response[i].countryCode;
                } else
                if ($scope.groupLogin.countryName == "") {
                    $scope.groupLogin.userName = '';
                }
            }
        };
    }*/

   /* $scope.onClickOfCountryButton = function(value) {
        if (value == "NRI") {


            $scope.showCountryCode = true;
            $scope.showCountryNames = true;
            $scope.showMobileNo = false;
            //$scope.groupLogin.countryName = value;
            $scope.groupLogin.userName = "";
            $scope.groupLogin.password = "";
            $scope.countryName = value;

            var currentElement = angular.element(document.querySelector('#userName1'));
            currentElement.removeClass('invalid1');
            $('#userName1_errMsg').css("visibility", "");

            var currentElement = angular.element(document.querySelector('#password1'));
            currentElement.removeClass('invalid1');
            $('#password1_errMsg').css("visibility", "");


            $scope.errorArray = ["userName1", "countryName", "password1"];

        } else {
            if (value == "INDIA") {

                $scope.showCountryCode = false;
                $scope.showCountryNames = false;
                $scope.showMobileNo = true;
                //$scope.groupLogin.countryName = value;
                $scope.countryName = value;
                $scope.groupLogin.countryName = "";
                $scope.groupLogin.userName = "";
                $scope.groupLogin.password = "";



                var currentElement = angular.element(document.querySelector('#userName1'));
                currentElement.removeClass('invalid1');
                $('#userName1_errMsg').css("visibility", "");

                var currentElement = angular.element(document.querySelector('#password1'));
                currentElement.removeClass('invalid1');
                $('#password1_errMsg').css("visibility", "");



                var currentElement = angular.element(document.querySelector('#countryName'));
                currentElement.removeClass('invalid1');
                $('#countryName_errMsg').css("visibility", "");


                $scope.errorArray = ["userName1", "password1"];

            }
        }
    };*/

   
/*    var getCountryDetails = function() {
        $rootScope.preloaderCheck = true;
        return ajaxHttpFactory.getJsonData("getCountryDetails", $location.absUrl())
            .then(function(response) {
                    $rootScope.preloaderCheck = false;
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
                        if (response != null && response != "null") {

                            $scope.successMethodOfGetCountryNames(response.data);
                        }
                    }
                },
                function(response) {
                    //			alert("In failureMethod");
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

                    }
                    $rootScope.preloaderCheck = false;
                });
    };*/


    $scope.OnResetBtn = function() {

        var currentElement = angular.element(document.querySelector('#userName1'));
        currentElement.removeClass('invalid1');
        $('#userName1_errMsg').css("visibility", "");

        var currentElement = angular.element(document.querySelector('#password1'));
        currentElement.removeClass('invalid1');
        $('#password1_errMsg').css("visibility", "");

        var currentElement = angular.element(document.querySelector('#userName'));
        currentElement.removeClass('invalid1');
        $('#userName_errMsg').css("visibility", "");


        var currentElement = angular.element(document.querySelector('#password'));
        currentElement.removeClass('invalid1');
        $('#password_errMsg').css("visibility", "");

      /*  var currentElement = angular.element(document.querySelector('#countryName'));
        currentElement.removeClass('invalid1');
        $('#countryName_errMsg').css("visibility", "");*/

        $scope.groupLogin.userName1 = "";
        $scope.groupLogin.password1 = "";
        $scope.groupLogin.userName = "";
        $scope.groupLogin.password = "";

       /* $scope.onClickOfCountryButton("INDIA");
        var radiobtn = document.getElementById("India");
        radiobtn.checked = true;*/

    };

    $scope.groupLogin = function(event) {

        if ($scope.checkBasicFieldValidations()) {
            $rootScope.preloaderCheck = true;
            $.jCryption.generateIpruKey(function() {
                $scope.prepareLogin();
                $scope.initiateLogin(event);

            });
        }
        /* else
         	{
         	  ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "LoginAlert");
         	}*/
    };

    $scope.prepareLogin = function() {
        $("#j_username").val($scope.groupLogin.userName);
        $("#j_password").val($scope.groupLogin.password);
        $("#j_logintype").val($scope.groupLogin.loginType);


        $("#j_password").val($scope.doEncryption($scope.groupLogin.password));
        $("#j_logintype").val($scope.doEncryption($scope.groupLogin.loginType));

        $scope.groupLogin.password = $scope.doEncryption($scope.groupLogin.password);

    };

    $scope.initiateLogin = function(event) {
        event.preventDefault();

        setTimeout(function() {
            $("#groupLoginForm").submit();
        }, 1000);

    };

    $scope.doEncryption = function(arg) {
        arg = $.jCryption.encrypt(arg, passwordnew);

        return arg;
    };


    $scope.onChangeOfLoginType = function() {
        $scope.errorMessage = "";
        if ($scope.groupLogin.loginType == "loginWithUserId") {
            $scope.showUserIdDiv = true;
            $scope.showEmailIdDiv = false;
            $scope.showForgotPasswordLink = false;

            var currentElement = angular.element(document.querySelector('#userName1'));
            currentElement.removeClass('invalid1');
            $('#userName1_errMsg').css("visibility", "");

            var currentElement = angular.element(document.querySelector('#password1'));
            currentElement.removeClass('invalid1');
            $('#password1_errMsg').css("visibility", "");

            $scope.groupLogin.userName1 = "";
            $scope.groupLogin.password1 = "";


        }
        if ($scope.groupLogin.loginType == "loginWithEmailMobile") {

            $scope.showUserIdDiv = false;
            $scope.showEmailIdDiv = true;
            $scope.showForgotPasswordLink = true;

            var currentElement = angular.element(document.querySelector('#userName'));
            currentElement.removeClass('invalid1');
            $('#userName_errMsg').css("visibility", "");


            var currentElement = angular.element(document.querySelector('#password'));
            currentElement.removeClass('invalid1');
            $('#password_errMsg').css("visibility", "");
            
          /*  var currentElement = angular.element(document.querySelector('#countryName'));
            currentElement.removeClass('invalid1');
            $('#countryName_errMsg').css("visibility", "");*/

            $scope.groupLogin.userName = "";
            $scope.groupLogin.password = "";
        }

    };

    $scope.onLoadChangeOfLoginType = function() {
        if ($scope.groupLogin.loginType == "loginWithUserId") {
            $scope.showUserIdDiv = true;
            $scope.showEmailIdDiv = false;
            $scope.showForgotPasswordLink = false;

            var currentElement = angular.element(document.querySelector('#userName1'));
            currentElement.removeClass('invalid1');
            $('#userName1_errMsg').css("visibility", "");

            var currentElement = angular.element(document.querySelector('#password1'));
            currentElement.removeClass('invalid1');
            $('#password1_errMsg').css("visibility", "");

            $scope.groupLogin.userName1 = "";
            $scope.groupLogin.password1 = "";


        }
        if ($scope.groupLogin.loginType == "loginWithEmailMobile") {

            $scope.showUserIdDiv = false;
            $scope.showEmailIdDiv = true;
            $scope.showForgotPasswordLink = true;

            var currentElement = angular.element(document.querySelector('#userName'));
            currentElement.removeClass('invalid1');
            $('#userName_errMsg').css("visibility", "");


            var currentElement = angular.element(document.querySelector('#password'));
            currentElement.removeClass('invalid1');
            $('#password_errMsg').css("visibility", "");


            $scope.groupLogin.userName = "";
            $scope.groupLogin.password = "";
        }

    };

    $scope.checkBasicFieldValidations = function() {
        if ($scope.groupLogin.loginType == "loginWithEmailMobile") {
           /* if ($scope.ShowCountryName()) {*/
                if ($scope.ShowEmailUName()) {
                    if ($scope.ShowEmailPassword()) {
                        return true;
                    } else {
                        return false;
                    }

                } else {
                    $scope.ShowEmailPassword();
                    return false;
                }
            /*} else {
                $scope.ShowEmailUName()
                $scope.ShowEmailPassword();
                return false;
            }*/
        }


        if ($scope.groupLogin.loginType == "loginWithUserId") {
            if ($scope.ShowUserName()) {
                if ($scope.ShowUserPassword()) {
                    return true;
                } else {
                    return false;
                }

            } else {
                $scope.ShowUserPassword();
                return false;
            }
        }
    };

    $scope.ShowUserName = function() {
        if ($scope.groupLogin.loginType == "loginWithUserId") {
            if ($scope.groupLogin.userName == "" || $scope.groupLogin.userName == undefined) {
                var currentElement = angular.element(document.querySelector('#userName'));
                currentElement.addClass('invalid1');
                $('#userName_errMsg').css("visibility", 'visible');
                return false;
            }

        } else {
            return false;
        }
        return true;
    };

    $scope.ShowUserPassword = function()

    {
        if ($scope.groupLogin.loginType == "loginWithUserId") {

            if ($scope.groupLogin.password == "" || $scope.groupLogin.password == undefined) {
                var currentElement = angular.element(document.querySelector('#password'));
                currentElement.addClass('invalid1');
                $('#password_errMsg').css("visibility", 'visible');
                return false;
            }
        } else {
            return false;
        }
        return true;
    };

  /*  $scope.ShowCountryName = function()

    {
        if ($scope.groupLogin.loginType == "loginWithEmailMobile") {


            if ($scope.countryName == "INDIA" && $scope.groupLogin.countryName == "" || $scope.groupLogin.countryName == undefined) {

                var currentElement = angular.element(document.querySelector('#countryName'));
                currentElement.removeClass('invalid1');
                $('#countryName_errMsg').css("visibility", "");

                return true;
            }
            if ($scope.countryName == "NRI" && $scope.groupLogin.countryName == "" || $scope.groupLogin.countryName == undefined) {

                var currentElement = angular.element(document.querySelector('#countryName'));
                currentElement.triggerHandler("blur");
               
                currentElement.addClass('invalid1');
                $('#countryName_errMsg').css("visibility", "visible");

                return false;
            }

        } else {
            return false;
        }
        return true;
    };*/

    $scope.ShowEmailUName = function()

    {
        if ($scope.groupLogin.loginType == "loginWithEmailMobile") {


            if ($scope.groupLogin.userName == "" || $scope.groupLogin.userName == undefined) {
                var currentElement = angular.element(document.querySelector('#userName1'));
                currentElement.addClass('invalid1');
                $('#userName1_errMsg').css("visibility", 'visible');

                return false;
            }

        } else {
            return false;
        }
        return true;
    };


    $scope.ShowEmailPassword = function() {
        if ($scope.groupLogin.loginType == "loginWithEmailMobile") {

            if ($scope.groupLogin.password == "" || $scope.groupLogin.password == undefined) {
                var currentElement = angular.element(document.querySelector('#password1'));
                currentElement.addClass('invalid1');
                $('#password1_errMsg').css("visibility", 'visible');
                if ($scope.groupLogin.countryName == "NRI") {
                    var currentElement = angular.element(document.querySelector('#countryName'));
                    currentElement.addClass('invalid1');
                    currentElement.triggerHandler("blur");

                }

                return false;
            }
        } else {
            return false;
        }
        return true;
    };



}]);