
var app = angular.module('groupApp', ['ajaxUtil','validationService','uiValidations','ui.materialize','groupCommonUtil']);


app.controller('claimRequestIBMCtrl',['$rootScope','$scope','$location','ajaxHttpFactory','$window','validateFieldService','$http','csrDocUploadFactory',function($rootScope, $scope, $location, ajaxHttpFactory,$window,validateFieldService,$http,csrDocUploadFactory){



$rootScope.preloaderCheck=false;
$scope.absUrl=window.location.origin + window.location.pathname+window.location.search;
$scope.claimRequestIBMModel={};
$scope.claimRequestIBMPOSubmit={};
$scope.claimRequestIBMPOSubmitWithDownload={};

$scope.prePopulateClaimRequestData={};
$scope.claimRequestData={};
$scope.typeOfClaimsData=[];
$scope.gratuityOptionsData=[];
$scope.loadTypeOfClaimsData={};
$scope.errorArray=[];
$scope.uploadFileList4=[];
$scope.uploadFileList3=[];
$scope.uploadFileList2=[];
$scope.uploadFileList1=[];
$scope.loadPrepopulateDataforClaimRequest={};
$scope.openAlert=false;
$scope.loadRedirectDetailsData={};
$scope.loadCommutationOption={};
$scope.commutationOption=[];
$scope.loadAnnuityPerOptions={};
$scope.annuityPerOptions=[];
$scope.functionalityId=0;
$scope.beneficiaryPayMode={};
$scope.beneficiaryPayModeOptions=[];  

$scope.hideForm=true;
/*var upload_Msg = angular.element(document
        .querySelector('#file-upload-main1_errMsg'));
upload_Msg[0].innerHTML ="";
var des_Msg = angular.element(document
        .querySelector('#file-upload-main1_upText'));
des_Msg[0].innerHTML =  "";
*/
/*
var upload_Msg2 = angular.element(document
        .querySelector('#file-upload-main2_errMsg'));
upload_Msg2[0].innerHTML ="";
var des_Msg2 = angular.element(document
        .querySelector('#file-upload-main2_upText'));
des_Msg2[0].innerHTML =  "";


var upload_Msg3 = angular.element(document
        .querySelector('#file-upload-main3_errMsg'));
upload_Msg3[0].innerHTML ="";
var des_Msg3 = angular.element(document
        .querySelector('#file-upload-main3_upText'));
des_Msg3[0].innerHTML =  "";



var upload_Msg4 = angular.element(document
        .querySelector('#file-upload-main4_errMsg'));
upload_Msg4[0].innerHTML ="";
var des_Msg4 = angular.element(document
        .querySelector('#file-upload-main4_upText'));
des_Msg4[0].innerHTML =  "";
*/
$scope.disableAllField=false;
$scope.disableField=false;
$scope.OnResetBtn = function(){
    var currentElement = angular.element(document.getElementsByClassName('invalid1'));
    currentElement.removeClass('invalid1');
    $('.err-msg').css("visibility", "");
    $scope.claimRequestIBMModel.gratuityApplication="";
    $scope.claimRequestIBMModel.commutationPer="";
    $scope.claimRequestIBMModel.annuityPer="";
    $scope.claimRequestIBMModel.empName="";
    $scope.claimRequestIBMModel.beneficiary="";
    $scope.claimRequestIBMModel.beneficiaryPayMode="";
    $scope.claimRequestIBMModel.ifscCode="";
    $scope.claimRequestIBMModel.micrCode="";
    $scope.claimRequestIBMModel.bankName="";
    $scope.claimRequestIBMModel.bankAccountNo="";
    $scope.claimRequestIBMModel.address="";

    };
/*var loadPrePopulateRedirectionDetails = function () {

    return ajaxHttpFactory.getJsonData("loadPrePopulateRedirectionDetails",$scope.absUrl)
    .then(function(response) {
        $rootScope.preloaderCheck=false;
        $scope.hideForm=true;
        $rootScope.preloaderCheck=false;
        if (response != null && response != "null") {
            var responseData = response.data;
            $scope.loadRedirectDetailsData = responseData;

            if($scope.loadRedirectDetailsData.isClaimReq=='1')
                {
                setTimeout(function(){
                    $window.location.href = "annuityCalculator.htm";
                },1000)


                }
        }
    },s
    function(errResponse) {
        $rootScope.preloaderCheck=false;
        console.error('Error while fetching profile details.');

    });

    };

loadPrePopulateRedirectionDetails();*/

    
    var prePopulateClaimRequestDetails = function () {
    	  $rootScope.preloaderCheck=true;
    	  
        return ajaxHttpFactory.getJsonData("prePopulateClaimAnnuityIBMDetails",$scope.absUrl)
        .then(function(response) {
            $rootScope.preloaderCheck=false;
  	      $scope.disableField=true;
            if (response != null && response != "null") {
            	 var responseData = response.data;
            	 
            	 if(responseData!==null && responseData!="" && responseData!=="null")
            		 {
            		
            		
            		if(responseData.type_of_claim.toUpperCase()=="RESIGNATION" || responseData.type_of_claim.toUpperCase()=="RETIREMENT")
            			 {
            			 $scope.hideForm=false;
            			 $scope.prePopulateClaimRequestData = responseData;
            			 $scope.claimRequestIBMModel.policyNo=$scope.prePopulateClaimRequestData.policyNo;
            			 $scope.claimRequestIBMModel.employeeId=$scope.prePopulateClaimRequestData.employee_id;
            			 $scope.claimRequestIBMModel.typeOfClaim=$scope.prePopulateClaimRequestData.type_of_claim;
            			 $scope.claimRequestIBMModel.gratuityApplicable=$scope.prePopulateClaimRequestData.gratuity_Applicable;
            			 $scope.claimRequestIBMModel.empName=$scope.prePopulateClaimRequestData.employee_name;
            			 $scope.functionalityId=$scope.prePopulateClaimRequestData.functionalityId;
            	
            			 }
            		 else
            			 {
            			 $scope.hideForm=true;
             			$scope.openAlert=true;
                         $scope.message = "Your claim request type is not Resignation or Retirement.";
            			 }
            		 }
            	 else
            		 {
            		 $scope.hideForm=true;
            			$scope.openAlert=true;
                        $scope.message = "Your claim request is not yet received from your trust.";
            		 }
            	 
            	 
            	
            }
            else
            	{
            	 $scope.hideForm=true;
            	$scope.openAlert=true;
                $scope.message = "Your claim request is not yet received from your trust.";
            	
            	}
        },
        function(errResponse) {
        	$rootScope.preloaderCheck=false;
        	$scope.openAlert=true;
            $scope.message = "Your claim request is not yet received from your trust.";
            console.error('Error while claim request details.');

        });

        };

        prePopulateClaimRequestDetails();




/*var loadGratuityOptions = function () {

return ajaxHttpFactory.getJsonData("loadGratuityOptions",$scope.absUrl)
.then(function(response) {
    $rootScope.preloaderCheck=false;
    if (response != null && response != "null") {
        var responseData = response.data;
        $scope.loadGratuityOptionsData = responseData;


        for(var i=0;i<$scope.loadGratuityOptionsData.length;i++)
            {
        		$scope.gratuityOptionsData.push($scope.loadGratuityOptionsData[i].value);
            }



    }
},
function(errResponse) {
    $rootScope.preloaderCheck=false;
    console.error('Error while fetching claim details.');

});

};
loadGratuityOptions();*/

var loadCommutationOption = function () {

    return ajaxHttpFactory.getJsonData("loadCommutationOption",$scope.absUrl)
    .then(function(response) {
        $rootScope.preloaderCheck=false;
        if (response != null && response != "null") {
            var responseData = response.data;
            
            
            $scope.commutationOption.length=0;
            $scope.loadCommutationOption = responseData;
            
            for(var i=0;i< $scope.loadCommutationOption.length;i++)
            	{
            	
            	
            	if(($scope.loadCommutationOption[i].value=="50" && $scope.claimRequestIBMModel.gratuityApplicable.toUpperCase()!="NO") || 
            			($scope.loadCommutationOption[i].value=="100" && $scope.claimRequestIBMModel.typeOfClaim.toUpperCase()!="RESIGNATION"))
            		{
            		//$scope.commutationOption.splice(i,1);
            		}
            	else
            		{
            	$scope.commutationOption.push($scope.loadCommutationOption[i].value);
            		}
            	
            	}
            
 
        }
    },
    function(errResponse) {
        $rootScope.preloaderCheck=false;
        console.error('Error while fetching profile details.');

    });

    };
    loadCommutationOption();

    
    
    var beneficiaryPayModeOption = function () {

        return ajaxHttpFactory.getJsonData("beneficiaryPayModeOption",$scope.absUrl)
        .then(function(response) {
            $rootScope.preloaderCheck=false;
            if (response != null && response != "null") {
                var responseData = response.data;
                $scope.beneficiaryPayMode = responseData;
                
                
                
                
                for(var i=0;i<$scope.beneficiaryPayMode.length;i++)
                {
                		$scope.beneficiaryPayModeOptions.push($scope.beneficiaryPayMode[i].value);
                }

            }
        },
        function(errResponse) {
            $rootScope.preloaderCheck=false;
            console.error('Error while fetching profile details.');

        });

        };
        beneficiaryPayModeOption();


    var loadAnnuityPerOptions = function () {

        return ajaxHttpFactory.getJsonData("loadAnnuityPerOptions",$scope.absUrl)
        .then(function(response) {
            $rootScope.preloaderCheck=false;
            if (response != null && response != "null") {
                var responseData = response.data;
                $scope.annuityPerOptions.length=0;
                $scope.loadAnnuityPerOptions = responseData;

                for(var i=0;i< $scope.loadAnnuityPerOptions.length;i++)
            	{
         if($scope.loadAnnuityPerOptions[i].value=="50" && $scope.claimRequestIBMModel.gratuityApplicable.toUpperCase()=="YES")
            		{
        		
            		}
            	else
            		{
            	   	$scope.annuityPerOptions.push($scope.loadAnnuityPerOptions[i].value);
            		}
            		}
            	
            
                
                
            }
        },
        function(errResponse) {
            $rootScope.preloaderCheck=false;
            console.error('Error while fetching profile details.');

        });

        };
        loadAnnuityPerOptions();

/*var loadTypeOfClaims = function () {

    return ajaxHttpFactory.getJsonData("loadTypeOfClaims",$scope.absUrl)
    .then(function(response) {
        $rootScope.preloaderCheck=false;
        if (response != null && response != "null") {
            var responseData = response.data;
            $scope.loadTypeOfClaimsData = responseData;


            for(var i=0;i<$scope.loadTypeOfClaimsData.length;i++)
                {
            	$scope.typeOfClaimsData.push($scope.loadTypeOfClaimsData[i].value);
                }

        }
    },
    function(errResponse) {
        $rootScope.preloaderCheck=false;
        console.error('Error while fetching profile details.');

    });

    };
loadTypeOfClaims();*/

/*$scope.onChangeShowCommutationEvent=function(typeOfClaim){
    if(!$scope.claimRequestIBMModel.typeOfClaim==""){
        $scope.commutationOption.length=0;

        if($scope.claimRequestIBMModel.typeOfClaim=="Resignation")
            {
            for(var i=0;i<$scope.loadCommutationOption.length;i++)
            {
            if($scope.claimRequestIBMModel.typeOfClaim)
 $scope.commutationOption.push($scope.loadCommutationOption[i].value);
            }
            }
        else
            {
            for(var i=0;i<$scope.loadCommutationOption.length;i++)
            {



                if($scope.loadCommutationOption[i].key=="100")
                    {
                    }
                else
                    {
 $scope.commutationOption.push($scope.loadCommutationOption[i].value);
                    }
            }
            }


    }



}*/

$scope.onChangeShowTypeOfClaim=function()
{
/*    $scope.gratuityOptionsData.length=0;*/
    $scope.claimRequestIBMModel.gratuityApplicable="";
    $scope.claimRequestIBMModel.commutationPer="";
    $scope.claimRequestIBMModel.annuityPer="";
    $scope.commutationOption.length=0;
    $scope.annuityPerOptions.length=0;

    }

/*$scope.onChangeShowCommutation50Event=function(gratuityOption)
{
    if(!$scope.claimRequestIBMModel.gratuityApplicable==""){

        if(!$scope.claimRequestIBMModel.typeOfClaim==""){


        if($scope.claimRequestIBMModel.gratuityApplicable=="No")
            {
            $scope.commutationOption.length=0;
            $scope.annuityPerOptions.length=0;
 $scope.onChangeShowCommutationEvent($scope.claimRequestIBMModel.typeOfClaim);

            for(var i=0;i<$scope.loadAnnuityPerOptions.length;i++)
                {
 $scope.annuityPerOptions.push($scope.loadAnnuityPerOptions[i].value);
                }


            }
        else
            {
            $scope.commutationOption.length=0;
            $scope.annuityPerOptions.length=0;
 $scope.onChangeShowCommutationEvent($scope.claimRequestIBMModel.typeOfClaim);


            for(var i=0;i<$scope.commutationOption.length;i++)
            {
            if($scope.commutationOption[i]=="50"){
                $scope.commutationOption.splice(i,1);
            }
            }

            for(var i=0;i<$scope.loadAnnuityPerOptions.length;i++)
            {
                if($scope.loadAnnuityPerOptions[i].value=="50")
                    {

                    }
                else{
 $scope.annuityPerOptions.push($scope.loadAnnuityPerOptions[i].value);
                    }
            }






            }

    }
    else{
        ajaxHttpFactory.showErrorSuccessMessagePopup("Please select Claim type","errorMessage-popup", "ClaimRequestAlert");
    }
    }

    else
        {
        ajaxHttpFactory.showErrorSuccessMessagePopup("Please select Gratuity Applicable","errorMessage-popup", "ClaimRequestAlert");
        }

}*/

/*var loadPrepopulateDataforClaimRequest = function () {

    return ajaxHttpFactory.getJsonData("loadPrepopulateDataforClaimRequest",$scope.absUrl)
    .then(function(response) {
        $rootScope.preloaderCheck=false;
        if (response != null && response != "null") {
            var responseData = response.data;
            $scope.loadPrepopulateDataforClaimRequest = responseData;
            $scope.disableField=true;
 $scope.claimRequestIBMModel.policyNo=$scope.loadPrepopulateDataforClaimRequest.policyNo;
 $scope.claimRequestIBMModel.employeeId=$scope.loadPrepopulateDataforClaimRequest.employeeId;
 $scope.functionality=$scope.loadPrepopulateDataforClaimRequest.functionalityId;
        }
    },
    function(errResponse) {
        $rootScope.preloaderCheck=false;
        console.error('Error while fetching profile details.');

    });

    };
    loadPrepopulateDataforClaimRequest();
*/





    $scope.onSubmitClaimRequestAnuityWithDownload=function(){
         $rootScope.preloaderCheck=true;
        
       /* $scope.openAlert=true;
        $scope.message = "This Application is not currently available";
        $rootScope.preloaderCheck=false;*/
 $scope.claimRequestIBMPOSubmitWithDownload.claimRequestIBMPO=$scope.claimRequestIBMModel;

    if($scope.uploadFileList4.length>0 && $scope.uploadFileList3.length>0 && $scope.uploadFileList2.length>0 && $scope.uploadFileList1.length>0)
        {

 $scope.claimRequestIBMPOSubmitWithDownload.uploadFileList4=$scope.uploadFileList4;
 $scope.claimRequestIBMPOSubmitWithDownload.uploadFileList3=$scope.uploadFileList3;
 $scope.claimRequestIBMPOSubmitWithDownload.uploadFileList2=$scope.uploadFileList2;
 $scope.claimRequestIBMPOSubmitWithDownload.uploadFileList1=$scope.uploadFileList1;

 ajaxHttpFactory.postJsonDataSuccessFailure(angular.toJson($scope.claimRequestIBMPOSubmitWithDownload),"POST",$scope.absUrl,"claimRequestIBMPOSubmitWithDownload",$scope.successMethod,$scope.failureMethod);
      
        }
    else
        {
         $rootScope.preloaderCheck=false;
        ajaxHttpFactory.showErrorSuccessMessagePopup("Please upload file","errorMessage-popup", "ClaimRequestAlert");
        }
}








    $scope.successMethod=function(response)
    {


        $rootScope.preloaderCheck=false;
        if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
            var claimIdJSON = angular.fromJson(response);
            if(claimIdJSON != null){
                var claimId = claimIdJSON;
                $scope.openAlert=true;
                $scope.message = "Your request submitted successfully. Reference No :"+claimId;

            }


        }



    };

    $scope.failureMethod=function(response){
        $rootScope.preloaderCheck=false;
        if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "claimAlert")){

            ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured please try again. ","errorMessage-popup", "claimAlert");
        }
    };

    $scope.okAlert= function (){
        $scope.openAlert=false;
        $window.location.href = "dashboard.htm";
    }



    $scope.onSubmitClaimRequestIBM=function()
    {
        $rootScope.preloaderCheck=true;
        var count=(parseFloat($scope.claimRequestIBMModel.commutationPer) + parseFloat($scope.claimRequestIBMModel.annuityPer));
    if(count==100){

        if($scope.checkBasicFieldValidations()){
 $scope.claimRequestIBMPOSubmit.claimRequestIBMPO=$scope.claimRequestIBMModel;

 ajaxHttpFactory.postJsonDataSuccessFailure(angular.toJson($scope.claimRequestIBMPOSubmit),"POST",$scope.absUrl,"cliamRequestIBMModelSubmit",$scope.successMethod1,$scope.failureMethod);

    }else{
        $rootScope.preloaderCheck=false;
    }
        }
        else
            {
            $rootScope.preloaderCheck=false;
            ajaxHttpFactory.showErrorSuccessMessagePopup("Sum of commutation and annuity should be 100","errorMessage-popup", "ClaimRequestAlert");

            }


    };



    $scope.successMethod1=function(response){
        $rootScope.preloaderCheck=true;
        if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "ClaimRequest"))

        {
            if(response=="success")

                $scope.methodType = 'POST';

                $http({
                    url: 'PDFStatementServlet.do',
                    method: $scope.methodType,
                    responseType: 'arraybuffer',
                    data: undefined,
                    headers: {
                        'Content-type': 'application/json',
                        'Accept': 'application/pdf'
                    }
                }).success(function(data) {
                    if(data.byteLength>0)
                    {
                    var blob = new Blob([data], {
                        type: 'application/pdf'
                    });
                    saveAs(blob, 'ClaimRequest' + '.pdf');
                    $rootScope.preloaderCheck=false;
                    $scope.disableAllField=true;
 //$scope.functionality=$scope.claimRequestIBMModel.functionalityId;

 ajaxHttpFactory.showErrorSuccessMessagePopup("File downloaded successfully. ","errorMessage-popup", "ClaimRequestAlert");


                    }
                    else
                    {
                        $rootScope.preloaderCheck=false;
 ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "ClaimRequestAlert");

                    }


                }).error(
                    function() {
                        $scope.OnResetBtn();
                        $rootScope.preloaderCheck=false;
 ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ","errorMessage-popup", "ClaimRequestAlert");

                    });



                }
        };

     

        $scope.upload = function(upId, docType) {
            $scope.preloaderCheck=false;
            var desc_Id = angular.element(document.querySelector('#' + upId.id+'_errMsg'));
            var upload_Msg = angular.element(document.querySelector('#' + upId.id + '_upText'));
                if(upId.files.length != 0){
                    if(upId.files[0].size<5242880)
                    {
                        var length=upId.files[0].name.lastIndexOf('.');
                        var ext=upId.files[0].name.substring(length+1,upId.files[0].name.length);
                        if(ext=='PDF' || ext=='pdf' || ext=='TIFF' || ext=='tiff')
                            {
                              upload_Msg[0].innerHTML="";
                              desc_Id[0].innerHTML="";
                              $scope.allowedExtensions=["PDF","pdf","TIFF","tiff","JPG","jpg","JPEG" ,"jpeg" ,"xls","XLS","xlsx","XLSX"];
csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,$scope.prePopulateClaimRequestData.functionalityId,$scope.fileUploadCallBack,$scope.claimRequestIBMModel.policyNo,'Upload File',$scope.allowedExtensions);
                            }
                        else
                        {
                        $scope.uploadFileList1.length=0;
                        $scope.uploadFileList2.length=0;
                        $scope.uploadFileList3.length=0;
                        $scope.uploadFileList4.length=0;
                        upload_Msg[0].innerHTML="";
                        desc_Id[0].innerHTML="";
                        upload_Msg[0].innerHTML="<span class=red-text>Error While Uploading. File extension should be PDF or TIFF</span>";
                        }
                    }
                    else
                    {
                        $scope.uploadFileList1.length=0;
                        $scope.uploadFileList2.length=0;
                        $scope.uploadFileList3.length=0;
                        $scope.uploadFileList4.length=0;
                        upload_Msg[0].innerHTML="";
                        desc_Id[0].innerHTML="";
                        upload_Msg[0].innerHTML="<span class=red-text>Error While Uploading.File size should not be more than 5 MB</span>";
                    }





                }


            };


$scope.restFileUpload=function(){
    var upload_Msg = angular.element(document
    .querySelector('#file-upload-main1_errMsg'));
    $scope.uploadFileList1.length=0;
    upload_Msg[0].innerHTML ="";
    var des_Msg = angular.element(document
            .querySelector('#file-upload-main1_upText'));
    des_Msg[0].innerHTML =  "";


    var upload_Msg2 = angular.element(document
            .querySelector('#file-upload-main2_errMsg'));
    $scope.uploadFileList2.length=0;
    upload_Msg2[0].innerHTML ="";
    var des_Msg2 = angular.element(document
            .querySelector('#file-upload-main2_upText'));
    des_Msg2[0].innerHTML =  "";


    var upload_Msg3 = angular.element(document
            .querySelector('#file-upload-main3_errMsg'));
    $scope.uploadFileList3.length=0;
    upload_Msg3[0].innerHTML ="";
    var des_Msg3 = angular.element(document
            .querySelector('#file-upload-main3_upText'));
    des_Msg3[0].innerHTML =  "";



    var upload_Msg4 = angular.element(document
            .querySelector('#file-upload-main4_errMsg'));
    $scope.uploadFileList4.length=0;
    upload_Msg4[0].innerHTML ="";
    var des_Msg4 = angular.element(document
            .querySelector('#file-upload-main4_upText'));
    des_Msg4[0].innerHTML =  "";
}
            $scope.fileUploadCallBack = function(uploadFileJsonResp, fileId, upload_Msg,message) {

                /*if(upload_Msg[0].id=="file-upload-main1_upText")
                    {
                    $scope.uploadFileList1.length=0;
                    }
                else if(upload_Msg[0].id=="ScannedClaimDocument")
                    {
                    $scope.uploadFileList2.length=0;
                    }
                else if(upload_Msg[0].id=="ITrETURNLAST3YEARDOC")
                    {
                    $scope.uploadFileList3.length=0;
                    }
                else if(upload_Msg[0].id=='pancard')
                    {
                    $scope.uploadFileList4.length=0;
                    }
                */
                if(uploadFileJsonResp=="ERROR")
                {

                  upload_Msg[0].innerHTML =  message;

                return false;
                }

                else
                    {
                var fileUploadResJsonObj = angular.fromJson(uploadFileJsonResp);
                if (fileUploadResJsonObj != null &&
                    fileUploadResJsonObj != '' && fileUploadResJsonObj != "") {

                    if(fileUploadResJsonObj.errorCode!=undefined)
                    {
 ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
                    }
                    else
                    {
                    for(var i=0;i<fileUploadResJsonObj.length;i++)
                        {

 if(angular.fromJson(fileUploadResJsonObj[i]).errorCode=="0")
                        {
 if(upload_Msg[0].id=="file-upload-main1_upText"){
                                $scope.uploadFileList1.length=0;
 $scope.uploadFileList1.push(angular.fromJson(fileUploadResJsonObj[i]));
                            }
                            else if(upload_Msg[0].id=="file-upload-main2_upText"){
                                $scope.uploadFileList2.length=0;
$scope.uploadFileList2.push(angular.fromJson(fileUploadResJsonObj[i]));
                                     }
                            else if(upload_Msg[0].id=="file-upload-main3_upText"){
                             $scope.uploadFileList3.length=0;
 $scope.uploadFileList3.push(angular.fromJson(fileUploadResJsonObj[i]));

 /*if($scope.uploadFileList3.length>4)
                                    {
$scope.uploadFileList3.length=0;
                                    upload_Msg[0].id==""
 ajaxHttpFactory.showErrorSuccessMessagePopup("Can not upload more than three files.", "errorMessage-popup","submitSuccessAlert");
                                    }*/

                             }
                            else if(upload_Msg[0].id=="file-upload-main4_upText"){
                                $scope.uploadFileList4.length=0;
$scope.uploadFileList4.push(angular.fromJson(fileUploadResJsonObj[i]));
                            }
                            else
                                {
 ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
                                }





                       if(fileId.length==1)
                           {
                        upload_Msg[0].innerHTML =  "Document uploaded successfully.";
                           }
                       else if(fileId.length<=3)
                           {
                           upload_Msg[0].innerHTML =  "Documents uploaded successfully.";
                           }
                       else{
 ajaxHttpFactory.showErrorSuccessMessagePopup("You can upload only 3 files", "errorMessage-popup","submitSuccessAlert");


                        var upload_Msg3 = angular.element(document
.querySelector('#file-upload-main3_errMsg'));
                        $scope.uploadFileList3.length=0;
                        upload_Msg3[0].innerHTML ="";
                        var des_Msg3 = angular.element(document
.querySelector('#file-upload-main3_upText'));
                        des_Msg3[0].innerHTML =  "";
                           return false;
                       }
                        }
                        else
                        {
 ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
                        }
                        }

                   }

                } else {

ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup", "SuccessAlert");
                }

                    }
                $rootScope.preloaderCheck=false;
            };


            $scope.checkBasicFieldValidations = function() {
                if ($scope.errorArray.length > 0) {
                    for (var i = 0; i < $scope.errorArray.length; i++) {
                        var lengthBfr = $scope.errorArray.length;
                        var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
                        if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
                            errorElement.triggerHandler("blur");
                        }
                        var lengthAftr = $scope.errorArray.length;
                        if (lengthAftr < lengthBfr) {
                            i--;
                        }
                    }
                    if ($scope.errorArray.length > 0) {
                        $("#" + $scope.errorArray[0]).focus();
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    return true;
                }
            };



}]);



