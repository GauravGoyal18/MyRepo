var app = angular.module('groupApp', [ 'ajaxUtil', 'ui.materialize',
		'uiValidations', 'groupCommonUtil', 'validationService' ]);
app
		.controller(
				'brokerTDSCertificateController',
				[
						'$rootScope',
						'$scope',
						'$location',
						'ajaxHttpFactory',
						'$window',
						'validateFieldService',
						'$http',
						function($rootScope, $scope, $location,
								ajaxHttpFactory, $window, validateFieldService,
								$http) {

							$scope.absUrl = window.location.origin
									+ window.location.pathname
									+ window.location.search;

							$scope.tdcCertificateJson = {};
							$scope.tDSCertificatePolicyList = [];
							$scope.paiCommissionResultView = {};

							$scope.errorArray = [];

							var getTDSCertificatePolicyList = function() {

								return ajaxHttpFactory
										.getJsonData(
												"getTDSCertificateOnLoad",
												$scope.absUrl)
										.then(
												function(response) {
													//$rootScope.preloaderCheck = false;
													if (response != null
															&& response != "null") {
														$rootScope.preloaderCheck = true;
														var responseData = response.data;
													
														$window.open(angular.fromJson(responseData), '_blank');
														$rootScope.preloaderCheck = false;
														/*$scope.tDSCertificatePolicyList = responseData;*/
														$window.location.href = "brokerDashboard.htm";
													}
												},
												function(errResponse) {
													$rootScope.preloaderCheck = false;
													console
															.error('Error while fetching getTDSCertificatePolicyList.');

												});

							};
							getTDSCertificatePolicyList();

							$scope.tdcCertificateSubmitForm = function() {
								
								if ($scope.checkBasicFieldValidations())

									if (new Date(
											$scope.tdcCertificateJson.startDate) <= new Date(
											$scope.tdcCertificateJson.endDate)) {

										$rootScope.preloaderCheck = true;

										ajaxHttpFactory
												.postJsonDataSuccessFailure(
														angular
																.toJson($scope.tdcCertificateJson),
														"POST",
														$scope.absUrl,
														"tdcCertificateJsonSubmit",
														$scope.successMethod,
														$scope.failureMethod);

									}

									else if (new Date(
											$scope.tdcCertificateJson.startDate) > new Date(
											$scope.tdcCertificateJson.endDate)) {
										$rootScope.preloaderCheck = false;
										ajaxHttpFactory
												.showErrorSuccessMessagePopup(
														"End Date should be greater than start date",
														"errorMessage-popup",
														"paidCommissionSummaryAlert");
									} else {
										$rootScope.preloaderCheck = false;
									}

							};

							var currentTime = new Date();
							$scope.currentTime = currentTime;
							$scope.month = [ 'January', 'February', 'March',
									'April', 'May', 'June', 'July', 'August',
									'September', 'October', 'November',
									'December' ];
							$scope.monthShort = [ 'Jan', 'Feb', 'Mar', 'Apr',
									'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct',
									'Nov', 'Dec' ];
							$scope.weekdaysFull = [ 'Sunday', 'Monday',
									'Tuesday', 'Wednesday', 'Thursday',
									'Friday', 'Saturday' ];
							$scope.weekdaysLetter = [ 'S', 'M', 'T', 'W', 'T',
									'F', 'S' ];

							$scope.today = '';
							$scope.clear = 'Clear';
							$scope.close = 'Done';
							var days = 100;
							$scope.minDate = (new Date($scope.currentTime
									.getTime()
									- (10000000 * 60 * 60 * 24 * days)))
									.toISOString();
							$scope.maxDate = (new Date($scope.currentTime
									.getTime())).toISOString();

							$scope.onStart = function() {

							};
							$scope.onRender = function() {

							};
							$scope.onOpen = function() {

							};
							$scope.onClose = function() {

							};

							$scope.dayDiff = function() {
								var date2 = new Date($scope.maxDate);
								var date1 = new Date(
										$scope.tdcCertificateJson.startDate);
								var timeDiff = Math.abs(date2.getTime()
										- date1.getTime());
								$scope.diffDays = Math.ceil(timeDiff
										/ (1000 * 3600 * 24));

							};

							$scope.onSet = function() {
								if (angular
										.isDefined($scope.tdcCertificateJson.startDate)) {
									$scope.minEndDate = (new Date(
											$scope.tdcCertificateJson.startDate))
											.toISOString();
									$scope.dayDiff();

									if ($scope.diffDays <= 366) {
										$scope.maxEndDate = $scope.maxDate;
									} else {
										$scope.maxEndDate = new Date(
												(Date
														.parse($scope.tdcCertificateJson.startDate))
														+ 60
														* 1000
														* 60
														* 24
														* 366).toISOString();
									}

								}
							};
							$scope.onStop = function() {

							};

							$scope.checkBasicFieldValidations = function() {
								if ($scope.errorArray.length > 0) {
									for ( var i = 0; i < $scope.errorArray.length; i++) {
										var lengthBfr = $scope.errorArray.length;
										var errorElement = angular
												.element(document
														.querySelector('#'
																+ $scope.errorArray[i]));
										if (errorElement.prop('type') == "text"
												|| errorElement.prop('type') == "textarea"
												|| errorElement.prop('tagName') == 'DIV'
												|| errorElement.prop('tagName') == "SELECT") {
											errorElement.triggerHandler("blur");
										}
										var lengthAftr = $scope.errorArray.length;
										if (lengthAftr < lengthBfr) {
											i--;
										}
									}
									if ($scope.errorArray.length > 0) {
										$("#" + $scope.errorArray[0]).focus();
										return false;
									} else {
										return true;
									}
								} else {
									return true;
								}
							};

							$scope.successMethod = function(response) {

								$rootScope.preloaderCheck = false;
								if (!ajaxHttpFactory.handleIPruException(
										response, "errorMessage-popup",
										"exceptionAlert")) {
									var paidCommissionData = angular
											.fromJson(response);
									if (paidCommissionData != null) {
										// $window.location.href="https://www.google.co.in/search?q=srk&oq=srk&aqs=chrome.1.69i60j69i59j69i60j0l3.3399j0j7&sourceid=chrome&ie=UTF-8";
										// $scope.paiCommissionResultView=paidCommissionData;
										$window.open(
												angular.fromJson(response),
												'_blank');
									}

								}

							};

							$scope.failureMethod = function(response) {
								$rootScope.preloaderCheck = false;
								if (!ajaxHttpFactory.handleIPruException(
										response, "errorMessage-popup",
										"claimAlert")) {

									ajaxHttpFactory
											.showErrorSuccessMessagePopup(
													"Some error occured please try again. ",
													"errorMessage-popup",
													"claimAlert");
								}
							};
							$scope.resetButton = function() {

								/*
								 * $window.location.href =
								 * "brokerTdcCertificate.htm"
								 */
								
								var currentElement = angular.element(document.getElementsByClassName('invalid1'));
								currentElement.removeClass('invalid1');
								$('.err-msg').css("visibility", "");
								$scope.tdcCertificateJson = {};
								$scope.errorArray=["policyNumber","startDate","endDate"];
								
								/*$scope.tdcCertificateJson.policyNumber="";
								$scope.tdcCertificateJson.startDate="";
								$scope.tdcCertificateJson.endDate="";*/
							/*	if($scope.tdcCertificateJson!=null)
								{
								$scope.tdcCertificateJson = {};*/
							
							}
							$scope.checkDate = function(currentElement,
									errorMsgElement) {
								if (angular
										.element(
												document
														.getElementById(currentElement))
										.val() == "") {
									angular
											.element(
													document
															.getElementById(currentElement))
											.addClass('invalid1');
									angular
											.element(
													document
															.getElementById(errorMsgElement))
											.css('visibility', 'visible');
									$scope.onSet();
									return false;
								} else {

									angular
											.element(
													document
															.getElementById(currentElement))
											.removeClass('invalid1');
									angular
											.element(
													document
															.getElementById(errorMsgElement))
											.css('visibility', 'hidden');
									$scope.onSet();
								}
								return true;
							};

						} ]);
