var app = angular.module('groupApp', ['ajaxUtil','validationService','uiValidations','ui.materialize','groupCommonUtil']);
app.controller('profilePOCController',['$rootScope','$scope','$location','ajaxHttpFactory','validateFieldService','$window','csrDocUploadFactory', function($rootScope, $scope,$location,ajaxHttpFactory,validateFieldService,$window,csrDocUploadFactory){
	 $rootScope.preloaderCheck=true;
	$scope.results=[];
	$scope.addressType=[];
	$scope.state=[];
	$scope.city=[];
	$scope.cityDetails=[];
	$scope.title=[];
	$scope.errorArray=[];
	$scope.functionality1 ={};
	$scope.functionality2={};
	$scope.functionality3 ={};
	$scope.functionality4 ={};
	$scope.fetchAddressDetails ={};

	$scope.companyAddress_new ={};
	$scope.contactPerson_new ={};
	$scope.authorized_new ={};
	$scope.bankDetails_new ={};
	$scope.uploadArray={};
	$scope.addressFields1="companyAddress_address1";
	$scope.address1=false;
	$scope.enable=true;
	$scope.oldval;
	$scope.uploadFileList=[];
	$scope.companyAddressChangeJson={};
	$scope.companyAddressChangeJsonRequest={};
	$scope.contactPersonChangeSubmit={};
	$scope.authorisedSignatorySubmitJson = {};
	$scope.bankAccountDetails={};
	
	$scope.country=["India"];
	
	$scope.enable=true;
	$scope.errSuccessAlertObj = {};
	$scope.checkDesignation=true;
	$scope.companyAddressJson=[];
	$scope.contactPersonJson=[];
	$scope.authorizedSignatoryJson=[];
	$scope.bankDetailsJson=[];
	$rootScope.CompanyAddress = false;
	$rootScope.AuthorizedSignatory = false;
	$rootScope.ContactPerson  = false;
	$rootScope.BankDetails  = false;
	$scope.fileUpload=false;
	$scope.profileUpdateEditOperation={};
	$scope.profileUpdateEditOperationJsonRequest={};
	$scope.loadCompanyAddreessChangeDetails={};
	$scope.loadContactPersonChangeDetails={};
	$scope.loadAuthoritySignatoryDetails={};
	$scope.getIFSCCodeJson={};
	$scope.gender=["Male","Female"];
	$scope.companyDiv=false;
	$scope.contactDiv=false;
	$scope.list=[];
	 $scope.companyhide=false;
	$scope.pageCheck=true;
	$scope.addresssplit=[];
	$scope.disableAuthorised=false;
	$scope.companyAddressOldvalues=[];
	$scope.saveEditJson={};
	
	
	$scope.onCallRadioButton1= function (index){
	
		if($scope.loadContactPersonChangeDetails.length!=0){
			$scope.contactIndex=index;
		if($scope.list[index].loadContactPersonChange==true ){
			$scope.contactDiv=true;
			if($scope.loadContactPersonChangeDetails[index].contactPerson_title=="Mr")
				{
				$scope.loadContactPersonChangeDetails[index].contactPerson_title="Male";
				$scope.functionality2.contactPerson_title=$scope.loadContactPersonChangeDetails[index].contactPerson_title;
				
				}
			else
				{
				$scope.loadContactPersonChangeDetails[index].contactPerson_title="Female";
				$scope.functionality2.contactPerson_title=$scope.loadContactPersonChangeDetails[index].contactPerson_title;
				}
			$scope.functionality2.contactPerson_firstName=$scope.loadContactPersonChangeDetails[index].contactPerson_firstName;
			$scope.functionality2.contactPerson_middleName=$scope.loadContactPersonChangeDetails[index].contactPerson_middleName;
			$scope.functionality2.contactPerson_lastName=$scope.loadContactPersonChangeDetails[index].contactPerson_lastName;
			$scope.functionality2.contactPerson_emailId=$scope.loadContactPersonChangeDetails[index].contactPerson_emailId;
			$scope.functionality2.contactPerson_number=$scope.loadContactPersonChangeDetails[index].contactPerson_number;
		}
		
		
		else
			{
			$scope.contactDiv=false;
			}
		}
	};
	
	
	$scope.onCallRadioButton= function (index){
		if($scope.loadCompanyAddreessChangeDetails.length!=0){
			$scope.companyIndex=index;
		if($scope.list[index].loadcompanyAddressChange==true ){
			$scope.companyDiv=true;
			$scope.companyAddressOldvalues.push($scope.loadCompanyAddreessChangeDetails[index]);
			$scope.functionality1.companyAddress_addressType=$scope.loadCompanyAddreessChangeDetails[index].companyAddress_addressType;
			$scope.functionality1.companyAddress_address1=$scope.loadCompanyAddreessChangeDetails[index].companyAddress_address1;
			$scope.addresssplit=($scope.functionality1.companyAddress_address1).split(',');
			
				$scope.functionality1.companyAddress_Company=$scope.addresssplit[1];
				$scope.functionality1.companyAddress_Flat=$scope.addresssplit[0];
				$scope.functionality1.companyAddress_Street=$scope.addresssplit[2];
				$scope.functionality1.companyAddress_Landmark=$scope.addresssplit[3];
				$scope.functionality1.companyAddress_Pincode=$scope.addresssplit[7];
				$scope.functionality1.companyAddress_City=$scope.addresssplit[4];
				$scope.functionality1.companyAddress_State=$scope.addresssplit[5];
				$scope.functionality1.companyAddress_addressproof="passport";
				
			
			
			
	}
		else
			{
			$scope.companyDiv=false;
			}
		}
		
	};
	
	
	$scope.prepopulateAuthorised= function(){
		if($scope.loadAuthoritySignatoryDetails.length!=0)
			{
			//$scope.authorizedIndex=0;
			
		$scope.disableAuthorised=true;
		for(var i=0;i<$scope.loadAuthoritySignatoryDetails.length;i++)
			{
			$scope.authorizedIndex=i;
			//$scope.functionality3.authorized_title=$scope.loadAuthoritySignatoryDetails[i].title;
			
			
		if($scope.loadAuthoritySignatoryDetails[i].authorized_title=="Mr")
		{
			$scope.loadAuthoritySignatoryDetails[i].authorized_title="Male";
		$scope.functionality3.authorized_title=$scope.loadAuthoritySignatoryDetails[i].authorized_title;
		}
		else
		{
			$scope.loadAuthoritySignatoryDetails[i].authorized_title="Female";
			$scope.functionality3.authorized_title=$scope.loadAuthoritySignatoryDetails[i].authorized_title;
		}
		$scope.functionality3.authorized_firstName=$scope.loadAuthoritySignatoryDetails[i].authorized_firstName;
		$scope.functionality3.authorized_middleName=$scope.loadAuthoritySignatoryDetails[i].authorized_middleName;
		$scope.functionality3.authorized_lastName=$scope.loadAuthoritySignatoryDetails[i].authorized_lastName;
		$scope.functionality3.authorized_number=$scope.loadAuthoritySignatoryDetails[i].authorized_number;
		$scope.functionality3.authorized_emailId=$scope.loadAuthoritySignatoryDetails[i].authorized_emailId;
		$scope.functionality3.authorized_active=$scope.loadAuthoritySignatoryDetails[i].authorized_active;
			}
	
			}
		
	};
	
	
	var getProfileAccessMatrix = function () { 
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("loadProfileAccessDetails",$location.absUrl())
		.then(function(response) {

			if (response != null && response != "null") {
				var responseData = response.data;
				$scope.results = responseData.resultMap;
				$rootScope.preloaderCheck=false;
			}
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});

	};
		getProfileAccessMatrix();
			  	
	
		var fetchCompanyAddressChangeDetails = function () { 
			$rootScope.preloaderCheck=true;
			return ajaxHttpFactory.getJsonData("getCompanyAddressChangeDetails",$location.absUrl())
			.then(function(response) {

				if (response != null && response != "null") {


					var responseData = response.data;

					$scope.companyAddressJson= responseData.resultMap;
					$rootScope.preloaderCheck=false;

				}	
			},
			function(errResponse) {
				$rootScope.preloaderCheck=false;
				console.error('Error while fetching profile details.');

			});

		};
	fetchCompanyAddressChangeDetails(); 
	
	
	var fetchContactPersonChangeDetails = function () { 
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("getContactPersonChangeDetails",$location.absUrl())
		.then(function(response) {
			if (response != null && response != "null") {
				var responseData = response.data;
				$scope.contactPersonJson= responseData.resultMap;
				$rootScope.preloaderCheck=false;
			}	
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});

	};
	fetchContactPersonChangeDetails(); 
	
	
	var fetchAuthoritySignatoryChangeDetails = function () {
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("getAuthoritySignatoryChangeDetails",$location.absUrl())
		.then(function(response) {
			if (response != null && response != "null") {
				var responseData = response.data;
				$scope.authorizedSignatoryJson= responseData.resultMap;
				$rootScope.preloaderCheck=false;
			}	
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});

	};
	fetchAuthoritySignatoryChangeDetails(); 
	
	
	
	var fetchBankAccountDetailsChangeDetails = function () { 
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("getBankAccountDetailsChange",$location.absUrl())
		.then(function(response) {
			if (response != null && response != "null") {
				var responseData = response.data;
				$scope.bankDetailsJson= responseData.resultMap;
				$rootScope.preloaderCheck=false;
			}	
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});

	};
	fetchBankAccountDetailsChangeDetails(); 	
	
	
	var loadCompanyAddressChangedata = function () { 

		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("companyAddressChangeLoadData",$location.absUrl())
		.then(function(response) {
			if (response != null && response != "null") {
				$scope.loadCompanyAddreessChangeDetails= response.data;

			}	
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');
		});

	};
	loadCompanyAddressChangedata(); 
	

	var loadcontactPersonChangedata = function () { 
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("contactPersonChangeLoadData",$location.absUrl())
		.then(function(response) {
			if (response != null && response != "null") {
				$scope.loadContactPersonChangeDetails= response.data;}	
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});

	};
	loadcontactPersonChangedata(); 
	
	
	
	var loadauthorisedSignatoryChangeData = function () { 
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("authorisedSignatoryChangeLoadData",$location.absUrl())
		.then(function(response) {
			if (response != null && response != "null") {
				$scope.loadAuthoritySignatoryDetails = response.data;
			}	
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});

	};
	loadauthorisedSignatoryChangeData(); 
	
	
	
//get Address Type Details
	var getAddressType=function()
	{
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("getAddressType",$location.absUrl())
		.then(function(response) {
			if (response != null && response != "null") {
				var responseData = response.data;
				for(var i = 0; i < responseData.length; i++)
				{
					$scope.addressType.push(responseData[i]);
				}
			}
			$rootScope.preloaderCheck=false;
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');
		});
	};
	getAddressType();
	
	var saveEditDetailsJson=function()
	{
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("saveEditDetailsJson",$location.absUrl())
		.then(function(response) {
			if (response != null && response != "null") {
				var responseData = response.data;
				for(var i = 0; i < responseData.length; i++)
				{
					$scope.saveEditJson=responseData[i];
				}
			}
			$rootScope.preloaderCheck=false;
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});
	};
	saveEditDetailsJson();
	
	
	//get state Details
	var getStateDetails=function(){
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("getStateDetails",$location.absUrl())
		.then(function(response) {
	
			if (response != null && response != "null") {
		var responseData = response.data;
		for(var i = 0; i < responseData.length; i++)
		{
			
			$scope.state.push(responseData[i]);
		 
		      
		}
			}
			$rootScope.preloaderCheck=false;
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});
	};
	
	getStateDetails();
	
	//get Title Details
	var getTitleDetails=function(){
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("getTitleDetails",$location.absUrl())
		.then(function(response) {
	
			if (response != null && response != "null") {

				var responseData = response.data;
		for(var i = 0; i < responseData.length; i++)
		{
			
			
			$scope.title.push(responseData[i]);
			
		      
		}
			}	
			$rootScope.preloaderCheck=false;
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});
	};
	
getTitleDetails();

	
	
	
	//get City Details
	var getCityDetails=function(){
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("getCityDetails",$location.absUrl())
		.then(function(response) {

			if (response != null && response != "null") {
				var responseData = response.data;
				for(var i=0; i< responseData.length;i++)
				{
					$scope.cityDetails.push(responseData[i]);
				}
			}	
			$rootScope.preloaderCheck=false;
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});
	};
	
	getCityDetails();

	
	$scope.getCityDetails = function(stateDetails) {

		$scope.data1=[];
		$scope.city=[];
		if(stateDetails!=null){
			var getCityDetails=$scope.cityDetails;
			for(var i=0; i<getCityDetails.length;i++)
			{
				var data2=getCityDetails[i];
				for(var j=0; j<data2.length;j++)
				{

					if(data2[j]==stateDetails){

						$scope.city.push(data2[1]);

					}
				}
			}

		}
		else
		{
		}
	};
	 
	 $scope.getCityDetails1 = function(stateDetails) {
		
		 $scope.data1=[];
		 $scope.city=[];
		 if(stateDetails!=null){
		 var getCityDetails=$scope.cityDetails;
		for(var i=0; i<getCityDetails.length;i++)
			{
		var data2=getCityDetails[i];
		for(var j=0; j<data2.length;j++)
			{
		
			if(data2[j]==stateDetails.newValue){
				
				$scope.city.push(data2[1]);
				
				}
			}
			}
		
		 }
		 else
			 {
			
			 }
	 };
	
	 
	 $scope.companyAddressChangeCancel= function()
		{
			$rootScope.CompanyAddress = false;	
		};
		
		 $scope.contactPersonChangeCancel= function()
		 {
			 $rootScope.ContactPerson  = false;
		 };
		 
		 $scope.authorisedSignatoryChangeCancel= function()
		 {
			 $rootScope.AuthorizedSignatory = false; 
		 };
		 
		 $scope.bankAccountChangeCancel= function()
		 {
			 $rootScope.BankDetails  = false;
		 };
	 
	$scope.companyAddressChangeSubmitForm=function(id,type){
		
		$scope.companyAddressErr=[];
		for(var i=0;i<$scope.errorArray.length;i++)
		{
			$scope.companyAddressErr.push($scope.errorArray[i]);
		}
		$scope.errorArray1=[];
		for(var i=0;i<$scope.companyAddressErr.length;i++)
		{
			
			$scope.companyAddressErr[i]= ($scope.companyAddressErr[i]).split(/(_)/);
			if($scope.companyAddressErr[i][0]==id && $scope.companyAddressErr[i][4]==type)
				{
				$scope.errorArray1.push(($scope.companyAddressErr[i]).join(""));
				}
			
		
		}
		if($scope.checkBasicFieldValidations($scope.errorArray1))
		{
			//$scope.companyAddressChangeJsonRequest.companyAddressDetails=$scope.companyAddress_addressproof_new;
			//$scope.companyAddressJson.companyAddress_address1_new.newValue=$scope.fetchAddressDetails.companyAddress_Company_new+' '+$scope.fetchAddressDetails.companyAddress_Flat_new+' '+$scope.fetchAddressDetails.companyAddress_Street_new+' '+$scope.fetchAddressDetails.companyAddress_Landmark_new+' '+$scope.fetchAddressDetails.companyAddress_Pincode_new+' '+$scope.fetchAddressDetails.companyAddress_City_new+' '+$scope.fetchAddressDetails.companyAddress_State_new+''+$scope.fetchAddressDetails.companyAddress_addressproof_new;	
			//$scope.companyAddressJson.companyAddress_address1_new.newValue=$scope.companyAddressChangeJsonRequest.companyAddressDetails;
			$scope.companyAddressChangeJsonRequest.uploadFileList=$scope.uploadFileList;
			$scope.companyAddressChangeJsonRequest.profileUpdateMap=$scope.companyAddressJson;
		
		
		var companyAddressChangeSubmitJson=angular.toJson($scope.companyAddressChangeJsonRequest);
		var ajaxurl=$location.absUrl();
		
		$rootScope.preloaderCheck=true;
		ajaxHttpFactory.postJsonDataSuccessFailure(companyAddressChangeSubmitJson,"POST",ajaxurl,"companyAddressChangeSubmit",$scope.successMethod,$scope.failureMethod);
		$rootScope.CompanyAddress = false;
		}		
	};
		 
	$scope.successMethod=function(response){
		$rootScope.preloaderCheck=false;
	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "comAddChangeAlert"))
	{
		
		ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. ","errorMessage-popup", "comAddChangeAlert"); 
	}
	};

	$scope.failureMethod=function(response){
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "comAddChangeAlert")){
			
			ajaxHttpFactory.showErrorSuccessMessagePopup("Some Error Occured : ","errorMessage-popup", "comAddChangeAlert"); 
		}
	};
	
	
	//contactPerson Change Submit Function
	
	$scope.contactPersonChangeSubmitForm=function(id,type){
		$scope.contactPersonErr=[];
		for(var i=0;i<$scope.errorArray.length;i++)
		{
			$scope.contactPersonErr.push($scope.errorArray[i]);
		}

		$scope.errorArray2=[];
		for(var i=0;i<$scope.contactPersonErr.length;i++)
		{

			$scope.contactPersonErr[i]= ($scope.contactPersonErr[i]).split(/(_)/);
			if($scope.contactPersonErr[i][0]==id && $scope.contactPersonErr[i][4]==type)
			{
				$scope.errorArray2.push(($scope.contactPersonErr[i]).join(""));
			}


		}

		if($scope.checkBasicFieldValidations($scope.errorArray2))
		{

			if($scope.contactPersonJson.contactPerson_title_new.newValue=="Male")
				$scope.contactPersonJson.contactPerson_title_new.newValue="Mr";
			else
				$scope.contactPersonJson.contactPerson_title_new.newValue="Ms";
			$scope.contactPersonChangeSubmit.profileUpdateMap=$scope.contactPersonJson;

			var contactPersonChangeSubmitJson=angular.toJson($scope.contactPersonChangeSubmit);


			var ajaxurl=$location.absUrl();

			$rootScope.preloaderCheck=true;
			ajaxHttpFactory.postJsonDataSuccessFailure(contactPersonChangeSubmitJson,"POST",ajaxurl,"contactPersonChangeSubmit",$scope.successMethod,$scope.failureMethod);
			$rootScope.ContactPerson = false;
		}

	};
	
		$scope.successMethod=function(response){
			$rootScope.preloaderCheck=false;
	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "contactChangeAlert"))
	{
		ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. ","errorMessage-popup", "contactChangeAlert"); 
	}
	};

	$scope.failureMethod=function(response){
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "comAddChangeAlert")){
			
			ajaxHttpFactory.showErrorSuccessMessagePopup("Some Error Occured : ","errorMessage-popup", "contactChangeAlert"); 
		}
	};

	
	$scope.authorisedSignatoryChangeSubmitForm=function(id,type){
		$scope.authorisedSignatoryErr=[];
		for(var i=0;i<$scope.errorArray.length;i++)
		{
			$scope.authorisedSignatoryErr.push($scope.errorArray[i]);
		}
		$scope.errorArray3=[];
		for(var i=0;i<$scope.authorisedSignatoryErr.length;i++)
		{

			$scope.authorisedSignatoryErr[i]= ($scope.authorisedSignatoryErr[i]).split(/(_)/);
			if($scope.authorisedSignatoryErr[i][0]==id && $scope.authorisedSignatoryErr[i][4]==type)
			{
				$scope.errorArray3.push(($scope.authorisedSignatoryErr[i]).join(""));
			}


		}
		if($scope.uploadFileList.length>0)
		{
			if($scope.checkBasicFieldValidations($scope.errorArray3))
			{
				//alert($scope.uploadFileList.length);
				if($scope.authorizedSignatoryJson.authorized_title_new.newValue=="Male")
					$scope.authorizedSignatoryJson.authorized_title_new.newValue="Mr";
				else
					$scope.authorizedSignatoryJson.authorized_title_new.newValue="Ms";
				if($scope.authorizedSignatoryJson.authorized_active_new.newValue==true)
					$scope.authorizedSignatoryJson.authorized_active_new.newValue="active";
				else
					$scope.authorizedSignatoryJson.authorized_active_new.newValue="deActive";	
				$scope.authorisedSignatorySubmitJson.uploadFileList =$scope.uploadFileList;
				$scope.authorisedSignatorySubmitJson.profileUpdateMap =$scope.authorizedSignatoryJson;



				var ajaxurl=$location.absUrl();



				var authorisedSignatoryChangeSubmitJson=angular.toJson($scope.authorisedSignatorySubmitJson);
				$rootScope.preloaderCheck=true;
				ajaxHttpFactory.postJsonDataSuccessFailure(authorisedSignatoryChangeSubmitJson,"POST",ajaxurl,"authorisedSignatoryChangeSubmit",$scope.successMethod,$scope.failureMethod);
				$rootScope.AuthorizedSignatory = false;
			}
		}
		else
		{
			ajaxHttpFactory.showErrorSuccessMessagePopup("Please upload file. ","errorMessage-popup", "AuthChangeAlert");
		}
	};
	
	
	$scope.successMethod=function(response){
		$rootScope.preloaderCheck=false;
	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "AuthChangeAlert"))
		
	{
		ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. ","errorMessage-popup", "AuthChangeAlert"); 
	}
};

	$scope.failureMethod=function(response){
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "AuthChangeAlert")){
			
			ajaxHttpFactory.showErrorSuccessMessagePopup("Some Error Occured : ","errorMessage-popup", "AuthChangeAlert"); 
		}
	};
	
	

	 $scope.getIFSCCode = function(IFSCCode) {
		
		 $scope.bankDetailsJson.bankAccount_IFSCCode_new.newValue=IFSCCode;
		 $scope.getIFSCCodeJson.profileUpdateMap =$scope.bankDetailsJson;
		 var ajaxurl=$location.absUrl();
		 var getIFSCCodeJson=angular.toJson( $scope.getIFSCCodeJson);
			ajaxHttpFactory.postJsonDataSuccessFailure(getIFSCCodeJson,"POST",ajaxurl,"getIFSCCodeSubmit",$scope.successMethod,$scope.failureMethod);
			$scope.bankAccountDetails.profileUpdateMap =$scope.bankDetailsJson;
			alert(IFSCCode);
		};
		

		
	
		$scope.bankAccountChangeSubmitForm=function(id,type){
			$scope.bankDetailsErr=[];
			for(var i=0;i<$scope.errorArray.length;i++)
			{
				$scope.bankDetailsErr.push($scope.errorArray[i]);
			}
			$scope.errorArray4=[];
			for(var i=0;i<$scope.bankDetailsErr.length;i++)
			{

				$scope.bankDetailsErr[i]= ($scope.bankDetailsErr[i]).split(/(_)/);
				if($scope.bankDetailsErr[i][0]==id && $scope.bankDetailsErr[i][4]==type)
				{
					$scope.errorArray4.push(($scope.bankDetailsErr[i]).join(""));
				}


			}
			if($scope.uploadFileList.length>0)
			{
				if($scope.checkBasicFieldValidations($scope.errorArray4))
				{

					$scope.bankAccountDetails.uploadFileList =$scope.uploadFileList;
					$scope.bankAccountDetails.profileUpdateMap =$scope.bankDetailsJson;

					var ajaxurl=$location.absUrl();

					var bankAccountDetailsChangeSubmit=angular.toJson($scope.bankAccountDetails);
					$rootScope.preloaderCheck=true;
					ajaxHttpFactory.postJsonDataSuccessFailure(bankAccountDetailsChangeSubmit,"POST",ajaxurl,"bankAccountDetailsChangeSubmit",$scope.successMethod,$scope.failureMethod);
					$rootScope.BankDetails  = false;
				}
			}
			else

			{
				ajaxHttpFactory.showErrorSuccessMessagePopup("Please upload file. ","errorMessage-popup", "BankChangeAlert");
			}

		};
		
	$scope.successMethod=function(response){
		$rootScope.preloaderCheck=false;
	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "BankChangeAlert"))
	{
		ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. ","errorMessage-popup", "BankChangeAlert"); 
	}
	};
	$scope.failureMethod=function(response){
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "BankChangeAlert")){
			
			ajaxHttpFactory.showErrorSuccessMessagePopup("Some Error Occured : ","errorMessage-popup", "BankChangeAlert"); 
		}
	};
	
	
	$scope.checkBasicFieldValidations = function(errorArray) {
	    if (errorArray.length > 0) {
	        for (var i = 0; i < errorArray.length; i++) {
	            var lengthBfr = errorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + errorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = errorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	        if (errorArray.length > 0) {
	            $("#" + errorArray[0]).focus();
	            return false;
	        } else {
	            return true;
	        }
	    } else {
	        return true;
	    }
	};
	
	
	
	$scope.validateFields = function(id,action)  
	{
      
		$scope.id=id;
		$scope.action=action;
		$scope.result = validateFieldService.fieldValidate($scope.id,$scope.action,$scope.results);
		return $scope.result;
		
	};


	$scope.onclickeditbtn = function(id)    //On click of Edit Button
	{
		$scope.pageCheck=false;
		$scope.validateFields(id,'enable');
		$scope.enable=false;
		if(id=="authorized_firstName" || id=="authorized_lastName")
		 $scope.fileUpload=true;
		if(id==$scope.addressFields1) 
		{
			$scope.address1=true;
			
		}
		
		
	};

	$scope.onClickSaveBn = function(id)  //On click of Save Button
	{
		$scope.pageCheck=true;
		if( $("#" + id + '_errMsg').css("visibility")!="visible")
		{
			if(id=="authorized_firstName" || id=="authorized_lastName")
				 $scope.fileUpload=false;
			$scope.validateFields(id,'save');
			if(id==$scope.addressFields1) 
			{
				$scope.functionality1.companyAddress_address1=$scope.functionality1.companyAddress_Company+' '+$scope.functionality1.companyAddress_Flat+' '+$scope.functionality1.companyAddress_Street+' '+$scope.functionality1.companyAddress_Landmark+' '+$scope.functionality1.companyAddress_Pincode+' '+$scope.functionality1.companyAddress_City+' '+$scope.functionality1.companyAddress_State;
				value=$scope.functionality1.companyAddress_address1;
				$scope.address1=false;
				
			}
			if(angular.isDefined($scope.functionality1[id]))
			{
				val=$scope.loadCompanyAddreessChangeDetails[$scope.companyIndex][id];
				value = $scope.functionality1[id];
				index=$scope.companyIndex;
				
				
			}
			else if(angular.isDefined($scope.functionality2[id]))
			{
				
				val=$scope.loadContactPersonChangeDetails[$scope.contactIndex][id];
				value = $scope.functionality2[id];
				if(value=="Male")
					{
					value="Mr";
					}
				else if(value=="Female")
					{
					value="Ms";
					}
				index=$scope.contactIndex;
				
			}
			else if(angular.isDefined($scope.functionality3[id]))
			{
				val=$scope.loadAuthoritySignatoryDetails[$scope.authorizedIndex][id];
				value = $scope.functionality3[id];
				if(value=="Male")
				{
				value="Mr";
				}
				else if(value=="Female")
				{
				value="Ms";
				}
				index=$scope.authorizedIndex;
			}
			else if(angular.isDefined($scope.functionality4[id]))
			{
				value = $scope.functionality4[id];
				
			}
			if(value==val){
				
					
					ajaxHttpFactory.showErrorSuccessMessagePopup("Enter a different value to save ","errorMessage-popup", "BankChangeAlert"); 
				
				
			}
			else{
				
				/*$scope.array=[];
			
				
					$scope.array.push(id);//id
					$scope.array.push(value);//new value
					$scope.array.push(index);//old value
					
					//var profileUpdateEditOperation = angular.toJson($scope.array);
					$scope.json={
							'fieldName':"",
							'newValue':"",
							'index':""
					};*/
				$scope.saveEditJson.fieldName=id;
				$scope.saveEditJson.newValue=value;
				$scope.saveEditJson.index=index;
					
					if(id==$scope.addressFields1) 
					{
						$scope.saveEditJson.newValue=$scope.saveEditJson.newValue+' '+$scope.functionality1.companyAddress_addressproof;
						}
				$scope.profileUpdateEditOperation = angular.toJson($scope.saveEditJson);
				
					if(id==$scope.addressFields1) 
					{
					
						$scope.profileUpdateEditOperationJsonRequest.uploadFileList=$scope.uploadFileList;
						
					}
					
					$scope.profileUpdateEditOperationJsonRequest.profileUpdateEditMap=$scope.saveEditJson;
					
					var profileUpdateEditOperationJson=angular.toJson($scope.profileUpdateEditOperationJsonRequest);
					
					var ajaxurl = $location.absUrl();
					
					ajaxHttpFactory.postJsonDataSuccessFailure(profileUpdateEditOperationJson,"POST",ajaxurl,"editOperation",$scope.successMethod,$scope.failureMethod);
					
				
			
			$scope.enable=true;
		}
		}
	};

	$scope.onClickCancelBn = function(id)   //On click of Cancel Button
	{
		$scope.pageCheck=true;
		if(id=="authorized_firstName" || id=="authorized_lastName")
			 $scope.fileUpload=false;
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$("#" + id + '_errMsg').css("visibility", "");
		
		
		if(angular.isDefined($scope.functionality1[id]))
		{
			$scope.functionality1[id]=$scope.loadCompanyAddreessChangeDetails[$scope.companyIndex][id];
		}
		else if(angular.isDefined($scope.functionality2[id]))
		{
			$scope.functionality2[id]= $scope.loadContactPersonChangeDetails[$scope.contactIndex][id];
		}
		else if(angular.isDefined($scope.functionality3[id]))
		{
			$scope.functionality3[id]= $scope.loadAuthoritySignatoryDetails[$scope.authorizedIndex][id];
		}
		else if(angular.isDefined($scope.functionality4[id]))
		{
			$scope.functionality4[id]= $scope.oldval;
		}
		$scope.validateFields(id,'cancel');
		if(id==$scope.addressFields1)
		{
			$scope.address1=false;
		}
		$scope.enable=true;
	
	};


	
	

	
	$scope.onClickCompanyAddress= function(){
		$scope.companyAddressJson.companyAddress_addressType_new.newValue="";
		$scope.companyAddressJson.companyAddress_address1_new.newValue="";
		$scope.fetchAddressDetails.companyAddress_Company_new="";
		$scope.fetchAddressDetails.companyAddress_Flat_new="";
		$scope.fetchAddressDetails.companyAddress_Street_new="";
		$scope.fetchAddressDetails.companyAddress_Landmark_new="";
		$scope.fetchAddressDetails.companyAddress_Pincode_new="";
		$scope.fetchAddressDetails.companyAddress_City_new="";
		$scope.fetchAddressDetails.companyAddress_State_new="";
		$scope.fetchAddressDetails.companyAddress_addressproof_new="";
		$rootScope.CompanyAddress = true;
		 
		 
		
	};

	$scope.onClickAuthorizedSignatory= function(){
		$scope.authorizedSignatoryJson.authorized_title_new.newValue="";
		$scope.authorizedSignatoryJson.authorized_firstName_new.newValue="";
		$scope.authorizedSignatoryJson.authorized_middleName_new.newValue="";
		$scope.authorizedSignatoryJson.authorized_lastName_new.newValue="";
		$scope.authorizedSignatoryJson.authorized_active_new.newValue="";
		$scope.authorizedSignatoryJson.authorized_emailId_new.newValue="";
		$scope.authorizedSignatoryJson.authorized_number_new.newValue="";
		 var upload_Msg = angular.element(document
		            .querySelector('#file-upload-main1_errMsg'));
		 
		 upload_Msg[0].innerHTML =  "";
		 
		 
		 var des_Msg = angular.element(document
		            .querySelector('#file-upload-main1_upText'));
		 
		 des_Msg[0].innerHTML =  "";

		$rootScope.AuthorizedSignatory = true;
	};
	
	$scope.onClickContactPerson= function(){
		$scope.contactPersonJson.contactPerson_title_new.newValue="";
		$scope.contactPersonJson.contactPerson_firstName_new.newValue="";
		$scope.contactPersonJson.contactPerson_middleName_new.newValue="";
		$scope.contactPersonJson.contactPerson_lastName_new.newValue="";
		$scope.contactPersonJson.contactPerson_emailId_new.newValue="";
		$scope.contactPersonJson.contactPerson_number_new.newValue="";
		$rootScope.ContactPerson = true;
	};
	
	$scope.onClickBankDetails= function(){
		$scope.bankDetailsJson.bankAccount_bankName_new.newValue="";
		$scope.bankDetailsJson.bankAccount_accountNumber_new.newValue="";
		$scope.bankDetailsJson.bankAccount_IFSCCode_new.newValue="";
		var upload_Msg = angular.element(document
	            .querySelector('#file-upload-main2_errMsg'));
	 
	 upload_Msg[0].innerHTML =  "";
	 
	 
	 var des_Msg = angular.element(document
	            .querySelector('#file-upload-main2_upText'));
	 
	 des_Msg[0].innerHTML =  "";
		$rootScope.BankDetails  = true;
	};


	
	$scope.upload = function(upId, docType) {
		$rootScope.preloaderCheck=false;
        var desc_Id = angular.element(document
            .querySelector('#' + upId.id+'_errMsg'));
        var upload_Msg = angular.element(document
            .querySelector('#' + upId.id + '_upText'));
            if(upId.files.length != 0){   
            	
            	
            	upload_Msg[0].innerHTML="";	
            	desc_Id[0].innerHTML="";
            	$scope.allowedExtensions=["PDF","pdf","TIFF","tiff","JPG","jpg","JPEG" ,"jpeg" ,"xls","XLS","xlsx","XLSX"];
            	csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,$scope.fileUploadCallBack,$scope.policynumber,'Upload File',$scope.allowedExtensions);
            }
		};
		
	
            $scope.fileUploadCallBack = function(uploadFileJsonResp, fileId, upload_Msg,message) {
            	
            	if(uploadFileJsonResp=="ERROR")
            	{
            		
            		
          	    upload_Msg[0].innerHTML =  message;
            		
            		
            	return false;
            	}
            	
            	else
            		{
    	        var fileUploadResJsonObj = angular.fromJson(uploadFileJsonResp);
    	       
    	        if (fileUploadResJsonObj != null &&
    	            fileUploadResJsonObj != '' && fileUploadResJsonObj != "") {
    
    	        	for(var i=0;i<fileUploadResJsonObj.length;i++)
    	        		{
    	      
    	        		if(angular.fromJson(fileUploadResJsonObj[i]).errorMsg=="0")
    	        		{
    	        			$scope.uploadFileList=[];
    	        	   $scope.uploadFileList.push(angular.fromJson(fileUploadResJsonObj[i]));
    	        		}
    	        		else
    	        		{
    	        			ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
    	        		}
    	        		}
    	         
    	           
    	            
    	            if(fileId.length==1)
    	            	{
    	             upload_Msg[0].innerHTML =  "Document uploaded successfully.";
    	            	}
    	            else if(fileId.length>1)
    	            	{
    	            	upload_Msg[0].innerHTML =  "Documents uploaded successfully.";
    	            	}
    	            
    	        } else {
    	           
    	            ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup", "submitSuccessAlert");
    	        }
    	        
            		}
    	        $rootScope.preloaderCheck=false;
    	    };
            
	
	


}]);



