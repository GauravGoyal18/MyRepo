var app = angular.module('groupApp', [ 'ajaxUtil', 'ui.materialize','uiValidations','groupCommonUtil']);
app.controller('fundPerformanceController',['$rootScope','$scope','$location','ajaxHttpFactory','csrDocUploadFactory',function($rootScope, $scope, $location, ajaxHttpFactory,csrDocUploadFactory) {
							
							
							$rootScope.preloaderCheck=true;
						
							var ajaxurl = $location.absUrl();
							$scope.xCordinate = [];
							$scope.yCordinate = [];
							$scope.debtFund =[];
							$scope.balancedFund =[];
						    $scope.equityFund =[];
						    $scope.growthFund =[];
						    $scope.gobottom=function(){
								 var documentHeight=document.documentElement.offsetHeight;
								 var viewportHeight=window.innerHeight;
								 window.scrollTo(0,documentHeight-viewportHeight);
								 }
						  ajaxHttpFactory.getJsonData('fundDetail',ajaxurl,'','GET').then(
			                        function successCallback(response) {
			                        	$scope.debtShow = false;
			                        	$scope.growthShow = false;
			                        	$scope.balancedShow = false;
			                        	$scope.equityShow = false;
			                            $scope.fundDatas = response.data;
			                            
			                            angular.forEach( $scope.fundDatas, function(value, key ){
			                            	if(value["AssetClass"] == "Debt"){
			                            		$scope.debtFund.push(value);
			                            		$scope.debtShow = true;
			                            		}
			                            	if(value["AssetClass"] == "Balanced"){
			                            		$scope.balancedFund.push(value);
			                            		$scope.balancedShow = true;
			                            	}
			                            	if(value["AssetClass"] == "Equity"){
			                            		$scope.equityFund.push(value);
			                            		$scope.equityShow = true;
			                            	}
			                            	if(value["AssetClass"] == "Growth"){
			                            		$scope.growthFund.push(value);
			                            		$scope.growthShow = true;
			                            	}
			                            	
			                            	
			                            	$rootScope.preloaderCheck=false; 	
			                            })
			                            
			                            
			                        },
			                        function errorCallback(response) {
			                            console.error('Error while expanding Fund Performance');
			                        });
			                
						$scope.fundPerformanceChart = function(fundcode,fundName){
							
							$scope.xCordinate = [];
							$scope.yCordinate = [];
							$scope.yyCordinate = [];
							$scope.benchMarkSNIF ="";
							$scope.fundName = "";
							
							$scope.fundName = fundName;
							$scope.fundcodeObject = {};
							
							$scope.fundcodeObject.fundcodeData = fundcode;
							
							var fundcodePerformance = angular
							.toJson($scope.fundcodeObject);
							var ajaxurl = $location.absUrl();
							$rootScope.preloaderCheck=true;
							ajaxHttpFactory.postJsonDataSuccessFailure(fundcodePerformance, "POST", ajaxurl,"fundPerformance", $scope.successMethod,$scope.failureMethod);
							};
							$scope.successMethod = function(response){
								$rootScope.preloaderCheck=false;
								if (!ajaxHttpFactory.handleIPruException(response, "", "yyAlert"))
								{ 
									$scope.xCordinate = response.x;
									$scope.yCordinate = response.y;
									$scope.yyCordinate = response.yy;
									$scope.benchMarkSNIF = response.benchMarkSNIF;
									
				
				$scope.option =  {
										
					title: { text: $scope.fundName },
					xAxis: {categories:[0],categories: $scope.xCordinate},
					series:[0],
					series: [{ name: $scope.fundName,data:$scope.yCordinate},{name: $scope.benchMarkSNIF,data:$scope.yyCordinate}]
									 						    }
				new Highcharts.chart('container',$scope.option);
								}
							
								}				
							
							$scope.failureMethod = function(){
								$rootScope.preloaderCheck=false;
							consol.log("Failure");
							};
							
						}
								
						 ]);
						
	