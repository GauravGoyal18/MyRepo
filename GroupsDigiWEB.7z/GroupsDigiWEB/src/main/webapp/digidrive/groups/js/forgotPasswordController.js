var app = angular.module('groupApp', ['ajaxUtil', 'uiValidations', 'ui.materialize', 'generalUtility', 'otpModalApp']);

app.controller('forgotPasswordController', ['$scope', '$rootScope', '$location', 'ajaxHttpFactory', '$window', '$http', function($scope, $rootScope, $location, ajaxHttpFactory, $window, $http) {


    $scope.showForgotPasswordDiv = false;
    $scope.passwordDetail = {};
    $scope.forgotPasswordJson = {};
    $rootScope.preloaderCheck = false;
    $scope.showCountryNames = false;
    //var passwordnew = "";
    $scope.errorArray = [];
    $scope.responseObj = [];
    $scope.showCountryCode = false;
    $scope.showFullMobileNo = false;
    var ajaxurl = $location.absUrl();
    $scope.showNriMobileNo = false;
    $scope.showMobileNo = true;
    $scope.forgotPasswordJson.countryName = "INDIA";


    $scope.successMethodOfGetCountryNames = function(response) {
        $scope.responseObj = response

        $scope.onChangeCountryName = function() {

            /*$scope.forgotPasswordJson.code='';
        	$scope.forgotPasswordJson.countryName='';*/
        	$scope.forgotPasswordJson.mobileNo="";
            for (var i = 0; i < response.length; i++) {
                if (response[i].countryName == $scope.forgotPasswordJson.countryName) {
                    $scope.forgotPasswordJson.code = response[i].countryCode;
                } else
                if ($scope.forgotPasswordJson.countryName == "") {
                    $scope.forgotPasswordJson.code = '';
                }
            }
        };
    }



    var getCountryDetails = function() {
        $rootScope.preloaderCheck = true;
        return ajaxHttpFactory.getJsonData("getCountryDetails", $location.absUrl())
            .then(function(response) {
                    $rootScope.preloaderCheck = false;
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
                        if (response != null && response != "null") {

                            $scope.successMethodOfGetCountryNames(response.data);
                        }
                    }
                },
                function(response) {
                    //			alert("In failureMethod");
                    if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

                    }
                    $rootScope.preloaderCheck = false;
                });
    };

    getCountryDetails();
    $scope.submitEmailMobile = function() {
        if ($scope.forgotPasswordJson.countryName == "INDIA" || $scope.forgotPasswordJson.countryName == undefined || $scope.forgotPasswordJson.countryName == "") {
            var currentElement = angular.element(document.querySelector('#countryName'));
            currentElement.removeClass('invalid1');
            $('#countryName_errMsg').css("visibility", "");
            for (var i = 0; i < $scope.errorArray.length; i++)
                if ($scope.errorArray[i] == "countryName") {
                    $scope.errorArray.splice(i, 1);
                    break;
                }

            var currentElement = angular.element(document.querySelector('#nriMobileNo'));
            currentElement.removeClass('invalid1');
            $('#nriMobileNo_errMsg').css("visibility", "");
            for (var i = 0; i < $scope.errorArray.length; i++)
                if ($scope.errorArray[i] == "nriMobileNo") {
                    $scope.errorArray.splice(i, 1);
                    break;
                }

        }

        if ($scope.forgotPasswordJson.countryName != "INDIA" && $scope.forgotPasswordJson.countryName != "") {

            var currentElement = angular.element(document.querySelector('#phoneNumber'));
            currentElement.removeClass('invalid1');
            $('#phoneNumber_errMsg').css("visibility", "");
            for (var i = 0; i < $scope.errorArray.length; i++)
                if ($scope.errorArray[i] == "phoneNumber") {
                    $scope.errorArray.splice(i, 1);
                    break;
                }
            if ($scope.checkBasicFieldValidations()) {
                $scope.failMobileNo = $scope.forgotPasswordJson.mobileNo;
                $scope.forgotPasswordJson.fullMobileNo = $scope.forgotPasswordJson.code + $scope.forgotPasswordJson.mobileNo;
                $scope.forgotPasswordJson.mobileNo = $scope.forgotPasswordJson.fullMobileNo;

                var emailMobileSubmit = angular.toJson($scope.forgotPasswordJson);
                var ajaxurl = $location.absUrl();

                ajaxHttpFactory.postJsonDataSuccessFailure(emailMobileSubmit, "POST", ajaxurl, "emailMobileSubmit", $scope.successMethodEmailMobileSubmit, $scope.failureMethodEmailMobileSubmit);

            } else {
                $rootScope.preloaderCheck = false;
                ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
            }
        } else {
            if ($scope.checkBasicFieldValidations()) {
                if ($scope.forgotPasswordJson.mobileNo.match(/^[7-9]+[\d]{9}$/)) {

                    var emailMobileSubmit = angular.toJson($scope.forgotPasswordJson);
                    var ajaxurl = $location.absUrl();

                    ajaxHttpFactory.postJsonDataSuccessFailure(emailMobileSubmit, "POST", ajaxurl, "emailMobileSubmit", $scope.successMethodEmailMobileSubmit, $scope.failureMethodEmailMobileSubmit);
                } else {
                    ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill valid  Indian mobileNo", "errorMessage-popup", "forgotPasswordAlert");
                }
            } else {
                $rootScope.preloaderCheck = false;
                ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
            }
        }



    };

    $scope.onClickOfCountryButton = function(value) {
        if (value == "NRI") {

            $scope.showNriMobileNo = true;
            $scope.showCountryCode = true;
            $scope.showCountryNames = true;
            $scope.showMobileNo = false;
            $scope.forgotPasswordJson.mobileNo = "";
            $scope.forgotPasswordJson.emailId = "";
            $scope.forgotPasswordJson.countryName = value;


            var currentElement = angular.element(document.querySelector('#phoneNumber'));
            currentElement.removeClass('invalid1');
            $('#phoneNumber_errMsg').css("visibility", "");

            var currentElement = angular.element(document.querySelector('#emailID'));
            currentElement.removeClass('invalid1');
            $('#emailID_errMsg').css("visibility", "");

            $scope.errorArray = ["nriMobileNo", "countryName", "emailID"];

        } else {
            if (value == "INDIA") {
                $scope.showNriMobileNo = false;
                $scope.showCountryCode = false;
                $scope.showCountryNames = false;
                $scope.showMobileNo = true;
                $scope.forgotPasswordJson.mobileNo = "";
                $scope.forgotPasswordJson.emailId = "";
                $scope.forgotPasswordJson.countryName = "";
                $scope.forgotPasswordJson.code = "";

                $scope.forgotPasswordJson.countryName = value;



                var currentElement = angular.element(document.querySelector('#nriMobileNo'));
                currentElement.removeClass('invalid1');
                $('#nriMobileNo_errMsg').css("visibility", "");

                var currentElement = angular.element(document.querySelector('#emailID'));
                currentElement.removeClass('invalid1');
                $('#emailID_errMsg').css("visibility", "");

                var currentElement = angular.element(document.querySelector('#countryName'));
                currentElement.removeClass('invalid1');
                $('#countryName_errMsg').css("visibility", "");


                $scope.errorArray = ["phoneNumber", "emailID"];

            }
        }
    };




    $scope.successMethodEmailMobileSubmit = function(response) {

        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            $rootScope.preloaderCheck = false;
            $scope.linkRedirectionUrlWdgt();

            $rootScope.$on('otpHandShake', function(event, args) {
                if (args != null && args != undefined) {

                    $scope.showForgotPasswordDiv = true;


                }
            });
        } else {
            $scope.forgotPasswordJson.mobileNo = $scope.failMobileNo;
        }
    };

    $scope.failureMethodEmailMobileSubmit = function(response) {
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            $rootScope.preloaderCheck = false;
        }
    };

    $scope.linkRedirectionUrlWdgt = function() {
        var url = $location.absUrl();
        ajaxHttpFactory.linkRedirectionUrlWdgt(url, '&otpType=transactionalOTP');

    };

    $scope.submitForgotPassword = function() {
        if ($scope.checkBasicFieldValidations()) {
            if ($scope.checkPasswordValidation()) {
                $scope.forgotPasswordJson.newPassword = $.jCryption.encrypt($scope.forgotPasswordJson.newPassword, passwordnew);
                $scope.forgotPasswordJson.confirmPassword = $.jCryption.encrypt($scope.forgotPasswordJson.confirmPassword, passwordnew);

                var forgotPasswordSubmit = angular.toJson($scope.forgotPasswordJson);
                var ajaxurl = $location.absUrl();

                ajaxHttpFactory.postJsonDataSuccessFailure(forgotPasswordSubmit, "POST", ajaxurl, "forgotPasswordSubmit", $scope.successMethodForgotPasswordSubmit, $scope.failureMethodForgotPasswordSubmit);
            } else {
                ajaxHttpFactory.showErrorSuccessMessagePopup("New password and Confirm password should be same", "errorMessage-popup", "forgotPasswordAlert");
            }
        } else {
            ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details", "errorMessage-popup", "forgotPasswordAlert");
        }
    };

    $scope.successMethodForgotPasswordSubmit = function(response) {
        /* $rootScope.preloaderCheck = true;*/
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            $rootScope.check = true;

            $scope.message = "Your Password has been reset successfully.";
            $rootScope.preloaderCheck = false;
        }
    };

    $scope.okAlert = function() {
        /*  $rootScope.preloaderCheck = true;*/
        $window.location.href = "onlogout.htm";
    };

    $scope.failureMethodForgotPasswordSubmit = function(response) {
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {

        }
    };

    $scope.resetForgotPassword = function() {
        $scope.forgotPasswordJson.newPassword = '';
        $scope.forgotPasswordJson.confirmPassword = '';

        var currentElement = angular.element(document.getElementsByClassName('invalid1'));
        currentElement.removeClass('invalid1');
        $('.err-msg').css("visibility", "");
    };

    $scope.resetEmailMobile = function() {
        $scope.forgotPasswordJson.emailId = '';
        $scope.forgotPasswordJson.mobileNo = '';
        $scope.forgotPasswordJson.countryName = '';
        $scope.forgotPasswordJson.code = '';
        $scope.onClickOfCountryButton("INDIA");
        /* $scope.country.id="INDIA";*/
        var radiobtn = document.getElementById("India");
        radiobtn.checked = true;



        var currentElement = angular.element(document.getElementsByClassName('invalid1'));
        currentElement.removeClass('invalid1');
        $('.err-msg').css("visibility", "");
        $scope.errorArray = ["phoneNumber", "emailID", "nriMobileNo", "countryName"];
    };

    $scope.checkPasswordValidation = function() {
        if ($scope.forgotPasswordJson.newPassword == $scope.forgotPasswordJson.confirmPassword) {
            return true;
        } else {
            return false;
        }
    };

    $scope.checkBasicFieldValidations = function() {


        if ($scope.showForgotPasswordDiv == true) {
            var returnTrue = false;

            if (!angular.isDefined($scope.forgotPasswordJson.newPassword) || $scope.forgotPasswordJson.newPassword == "") {
                var currentElement = angular.element(document.querySelector('#newPassword'));
                currentElement.addClass('invalid1');
                $('#newPassword_errMsg').css("visibility", 'visible');
                returnTrue = true;
            }
            if (!angular.isDefined($scope.forgotPasswordJson.confirmPassword) || $scope.forgotPasswordJson.confirmPassword == "") {
                var currentElement = angular.element(document.querySelector('#confirmPassword'));
                currentElement.addClass('invalid1');
                $('#confirmPassword_errMsg').css("visibility", 'visible');
                returnTrue = true;
            }

            if (returnTrue == true) {
                return false;
            }


        }
        if ($scope.errorArray.length > 0) {
            for (var i = 0; i < $scope.errorArray.length; i++) {
                var lengthBfr = $scope.errorArray.length;
                var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
                if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT" || errorElement.prop('type') == "password") {
                    errorElement.triggerHandler("blur");
                }
                var lengthAftr = $scope.errorArray.length;
                if (lengthAftr < lengthBfr) {
                    i--;
                }
            }
            if ($scope.errorArray.length > 0) {
                $("#" + $scope.errorArray[0]).focus();
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    };

}]);