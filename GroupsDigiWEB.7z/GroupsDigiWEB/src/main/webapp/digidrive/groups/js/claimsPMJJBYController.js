var app = angular.module('groupApp', [ 'ajaxUtil', 'ui.materialize','uiValidations','groupCommonUtil','validationService']);
app.controller('claimsPMJJBYController',['$rootScope','$scope','$location','ajaxHttpFactory','csrDocUploadFactory','$window','validateFieldService','$filter',function($rootScope, $scope, $location, ajaxHttpFactory,csrDocUploadFactory,$window,validateFieldService,$filter) {

	
	$rootScope.preloaderCheck=true;	
							$scope.claimPMJJBY = {};	
							
							
							
							$scope.hideSubmitNreset = true;
							$scope.uploadArray = {};
							$scope.uploadArray.claimForm = "";
							$scope.uploadArray.deathCertificate = "";
							$scope.uploadArray.cancelledCheque = "";
							
							$scope.claimPMJJBY.beneficiary =[];
							
							$scope.eachBeneficiary = {};
							$scope.deleteId='';
							$scope.actions="";	
							$scope.claimPMJJBY.claimForm=[];
							$scope.claimPMJJBY.deathCertificate=[];
							$scope.claimPMJJBY.cancelledCheque=[];
							
							$scope.Beneficiary = [];
							$scope.benCount=0;
																				
							$scope.errorArray = [];
							$scope.functionalityId="";
							$scope.disabled=[];
							$scope.uploadName="";
							
							
									var onload = function () { 								
								return ajaxHttpFactory.getJsonData("getOnLoadData",$location.absUrl())
								.then(function(response) {
									if(ajaxHttpFactory.handleIPruException(response.data, "errorMessage-popup", "exceptionAlert")){
										$rootScope.openAlertID2 = true;	
										$scope.message = "No Data Found";
									}
								
									if (response != null && response != "null") {
										var responseData = response.data;
										$scope.claimPMJJBY = responseData;
										$scope.functionalityId=responseData.functionalityId;
										$scope.claimPMJJBY.claimForm=[];
										$scope.claimPMJJBY.deathCertificate=[];
										$scope.claimPMJJBY.cancelledCheque=[];
										$scope.claimPMJJBY.beneficiary =[];
										$scope.claimPMJJBY.claimDate=$filter('date')(new Date(),'dd MMMM, yyyy');
										$scope.Beneficiary.push('ben_0');		
										$rootScope.preloaderCheck=false;
										$scope.disabled[0]=false;
									}
								},
								function(errResponse) {
									$rootScope.preloaderCheck=false;
									if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
										
									}
									
								});

							};
							
							onload();
													
							
							$scope.disableFields=function(i)
							{
								if($scope.claimPMJJBY.beneficiary[i].typeOfPayment=="credit")
								{
									$scope.disabled[i]=true;									
									$scope.removeErrors(i);													 						
								}
								else
								{
									$scope.disabled[i]=false;
									$scope.removeErrors(i);
									
								}								
								
							}
							
							$scope.removeErrors=function(i)
							{
									index = $scope.errorArray.indexOf("beneficiaryIfscCode"+i);
									if(index!=-1)
									$scope.errorArray.splice(index,1);
									index = $scope.errorArray.indexOf("beneficiaryMicrCode"+i);
									if(index!=-1)
									$scope.errorArray.splice(index,1);
									index = $scope.errorArray.indexOf("beneficiaryBankName"+i);
									if(index!=-1)
									$scope.errorArray.splice(index,1);
									index = $scope.errorArray.indexOf("beneficiaryBankAccountNUMBER"+i);
									
									if(index!=-1)
									$scope.errorArray.splice(index,1);
									index = $scope.errorArray.indexOf("beneficiaryBankAddress"+i);
									
									if(index!=-1)
									$scope.errorArray.splice(index,1);
									
							}
							
							
							$scope.addErrors=function(i){
								index = $scope.errorArray.indexOf("beneficiaryIfscCode"+i);
								if(index<0)
								$scope.errorArray.push("beneficiaryIfscCode"+i);
								
								
								index = $scope.errorArray.indexOf("beneficiaryMicrCode"+i);
								if(index<0)
								$scope.errorArray.push("beneficiaryMicrCode"+i);
								
								index = $scope.errorArray.indexOf("beneficiaryBankName"+i);
								if(index<0)
								$scope.errorArray.push("beneficiaryBankName"+i);
								
								index = $scope.errorArray.indexOf("beneficiaryBankAccountNUMBER"+i);
								
								if(index<0)
								$scope.errorArray.push("beneficiaryBankAccountNUMBER"+i);
								
								index = $scope.errorArray.indexOf("beneficiaryBankAddress"+i);
								
								if(index<0)
								$scope.errorArray.push("beneficiaryBankAddress"+i);
							}
																		
							
							
								 $scope.checkBasicFieldValidations = function() {
										var deleteDetails=false;
										 var index=-1;
										
										
										
									    if ($scope.errorArray.length > 0) {
									    	
									    	
									    	 for(var i=0;i<=$scope.benCount;i++)
												{
													if($scope.claimPMJJBY.beneficiary[i].typeOfPayment != "credit")
													{													 
														$scope.removeErrors(i)																																					
													}
													else
													{
														$scope.addErrors(i);
													}
												}
									    	
									    	
									    	
									    	var arrlength=$scope.errorArray.length;
									    	
									    	
									    	for(var j=0;j<$scope.errorArray.length;j++)
									    	{
									    		
									    		if(deleteDetails)
									    		{
									    			j=0;
									    		}
								    			var index=$scope.errorArray[j].substr($scope.errorArray[j].length - 1);

									    	
									    		if($scope.errorArray[j].indexOf("beneficiary")==0)
									    		{
									    		if($scope.claimPMJJBY.beneficiary[index]==undefined)
								    			{
								    				$scope.errorArray.splice(j, 1);
								    				deleteDetails=true;
								    				j--;
								    			}
									    		else
							    				{
							    				deleteDetails=false;
							    				}
									    			}
									    		else
									    			{
									    			deleteDetails=false;
									    			}
									    	}
									    	
									    	
									        for (var i = 0; i < $scope.errorArray.length; i++) {
									            var lengthBfr = $scope.errorArray.length;
									            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
									            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
									                errorElement.triggerHandler("blur");
									            }
									            var lengthAftr = $scope.errorArray.length;
									            if (lengthAftr < lengthBfr) {
									                i--;
									            }
									        }
									       
											
									       
									        
									        
									        if ($scope.errorArray.length > 0) {
									            $("#" + $scope.errorArray[0]).focus();
									            
									            return false;
									        } else {
									            return true;
									        }
									    } else {
									        return true;
									    }
									};
								 
								 
								 $scope.okAlert= function (){
										$rootScope.openAlertID = false;
										if($scope.actions=="delete")
											{
										if($scope.benCount==0)
										{
												
											ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 beneficiary should be there. ","errorMessage-popup", "claimPMJJBYsAlert");
										}
										else
											{
											
										$scope.benCount= $scope.benCount-1;
										 
										
										
										  $scope.Beneficiary.splice($scope.deleteId,1);
										  $scope.claimPMJJBY.beneficiary.splice($scope.deleteId,1);
										  $scope.Beneficiary=[];
										  for(var i=0;i<=$scope.benCount;i++)
											  {			
											
											$scope.Beneficiary.push('ben_'+i);
											  }											  											 
											  }
											}
										else if($scope.action=="success")
											{
											$window.location.href = "dashboard.htm";
											}
										else if($scope.action=="failure")
											{
											$window.location.href = "onlogout.htm";
											}
										
									};
									$scope.cancelAlert= function (){
										$rootScope.openAlertID = false;
										$rootScope.openAlertID1 = false;
									};
									
									$scope.claimAdded= function (){
										$rootScope.openAlertID = false;
										$rootScope.openAlertID1 = false;
										$window.location.href = "claimsPMJJBY.htm";
									};
									$scope.dataAlert= function (){
										$rootScope.openAlertID2 = false;											
										$window.location.href = "dashboard.htm";
									};
									
							$scope.deleteBeneficary = function(deletID) {
								
								if($scope.benCount==0){		
									/*$rootScope.openAlertID1 = true;	
									$scope.message = "At least 1 Beneficiary should be there.";	*/	
									ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 Beneficiary should be there. ","errorMessage-popup", "claimPMJJBYsAlert");									
								}else{
									$rootScope.openAlertID = true;	
									$scope.actions="delete";
									$scope.message = "Are you sure want to delete";
									$scope.deleteId=deletID;																	
									}														
							};
							
							
							
						
							var total = 0;							
							$scope.addBeneficiary = function() {
								
								
								
								if ($scope.checkBasicFieldValidations())
								{
									
									$scope.totalSharePer=0;

									for(var i=0;i<$scope.claimPMJJBY.beneficiary.length;i++)
									{								
									$scope.totalSharePer=parseInt($scope.totalSharePer)+parseInt($scope.claimPMJJBY.beneficiary[i].sharePercentage);
									}
									
								if($scope.totalSharePer<100)
								{
								if($scope.benCount<2)
								{
									$scope.benCount	= $scope.benCount+1;
									$scope.Beneficiary.push('ben_'+$scope.benCount);
									$scope.disabled[$scope.benCount]=false;
									
							
									
								}
								else
									ajaxHttpFactory.showErrorSuccessMessagePopup("You cannot add more than 3 Beneficiary . ","errorMessage-popup", "claimPMJJBYsAlert");	
								}	
								else
									ajaxHttpFactory.showErrorSuccessMessagePopup("You cannot add more Beneficiary, Share% is 100% . ","errorMessage-popup", "claimPMJJBYsAlert");	
								}
								
								else
									ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details for Beneficiary ","errorMessage-popup", "claimPMJJBYsAlert");																	
								};
							
						

								var currentTime = new Date();
								$scope.currentTime = currentTime;
								$scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
								$scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
								$scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
								$scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

								$scope.today = '';
								$scope.clear = 'Clear';
								$scope.close = 'Done';
								var days = 100;
								$scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
								$scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
								
								$scope.onStart = function () {
								    
								};
								$scope.onRender = function () {
								   
								};
								$scope.onOpen = function () {
								   							    
								};
								$scope.onClose = function () {
									 
								    
								};
						
								$scope.onStop = function () {
								  
								};
								
								$scope.resetClaim = function(){
									$rootScope.openAlertID = false;	
									//$window.location.href = "claims.htm";
									$scope.hideSubmitNreset = true;								
									$scope.claimPMJJBY.deathDate="";
									$scope.claimPMJJBY.deathReason="";
									$scope.uploadArray = {};
									$scope.uploadArray.claimForm = "";
									$scope.uploadArray.deathCertificate = "";
									$scope.uploadArray.cancelledCheque = "";
									$scope.claimPMJJBY.beneficiary =[];									
									$scope.eachBeneficiary = {};																																														
									$scope.errorArray = [];
									$scope.claimPMJJBY.uploadFileList=[];
									$scope.claimPMJJBY.uploadFileList.length=0;
									var fileDiv = angular.element( document.querySelector( '#file-upload-main'));
									fileDiv.empty();								
									var m1 = angular.element( document.querySelector( '#file-upload-main_errMsg'));
					    			m1.empty();
					    			m1.innerHTML = "<b>List Of Uploaded Documents</b><br>";
					    			var m2 = angular.element( document.querySelector( '#file-upload-main_upText'));
					    			m2.empty();
					    			
					    			var fileDiv1 = angular.element( document.querySelector( '#file-upload-main1'));
									fileDiv1.empty();								
									var m3 = angular.element( document.querySelector( '#file-upload-main1_errMsg'));
					    			m3.empty();
					    			m3.innerHTML = "<b>List Of Uploaded Documents</b><br>";
					    			var m4 = angular.element( document.querySelector( '#file-upload-main1_upText'));
					    			m4.empty();
					    			
					    			var fileDiv2 = angular.element( document.querySelector( '#file-upload-main2'));
									fileDiv2.empty();								
									var m5 = angular.element( document.querySelector( '#file-upload-main2_errMsg'));
					    			m5.empty();
					    			m5.innerHTML = "<b>List Of Uploaded Documents</b><br>";
					    			var m6 = angular.element( document.querySelector( '#file-upload-main2_upText'));
					    			m6.empty();
					    			
					    			var currentElement = angular.element(document.getElementsByClassName('invalid1'));
					    			currentElement.removeClass('invalid1');
					    			$('.err-msg').css("visibility", "");
					    			
					    			
								};
								
								$scope.submitClaim = function() {
									$scope.preloaderCheck=true;
									if ($scope.checkBasicFieldValidations())
									{
										if($scope.claimPMJJBY.claimForm.length > 0 && $scope.claimPMJJBY.deathCertificate.length > 0 && $scope.claimPMJJBY.cancelledCheque.length > 0 && $scope.claimPMJJBY.claimForm.length == 2){
											
										
										$scope.totalSharePer=0;

										for(var i=0;i<$scope.claimPMJJBY.beneficiary.length;i++)
										{					
											$scope.Data=$scope.claimPMJJBY.beneficiary[i];
											
										$scope.totalSharePer=parseInt($scope.totalSharePer)+parseInt($scope.claimPMJJBY.beneficiary[i].sharePercentage);									
										
										}
										
									if(parseInt($scope.totalSharePer)==100)
									{										
										if($scope.claimPMJJBY.claimForm.length == 0 && $scope.claimPMJJBY.deathCertificate.length==0 &&  $scope.claimPMJJBY.cancelledCheque.length==0 &&  $scope.claimPMJJBY.claimForm.length!=2){											
											ajaxHttpFactory.showErrorSuccessMessagePopup("Please Upload pdf File. ","errorMessage-popup", "claimPMJJBYsAlert");
										}
										else{											
											var claimPMJJBYJson = angular.toJson($scope.claimPMJJBY);										
											var ajaxurl = $location.absUrl();
											ajaxHttpFactory.postJsonDataSuccessFailure(claimPMJJBYJson, "POST", ajaxurl,"Submit", $scope.successMethod,$scope.failureMethod);
										}																			
									}	
									else
										ajaxHttpFactory.showErrorSuccessMessagePopup("Beneficiary Share% should be 100% . ","errorMessage-popup", "claimPMJJBYsAlert");	
									}
									
									else{
										ajaxHttpFactory.showErrorSuccessMessagePopup("Please check the uploaded file ","errorMessage-popup", "claimPMJJBYsAlert");
										$scope.claimPMJJBY.claimForm=[];
									}
										
									}
									else
										ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details for Claims","errorMessage-popup", "claimPMJJBYsAlert");																	
									

									};																	
									
									
									$scope.upload = function(upId, docType,uploadName) {
										$scope.preloaderCheck=false;
										$scope.uploadName=uploadName;
								        var desc_Id = angular.element(document
								            .querySelector('#' + upId.id+'_errMsg'));
								        var upload_Msg = angular.element(document
								            .querySelector('#' + upId.id + '_upText'));
								            if(upId.files.length != 0){   
								            	
								            	
								            	upload_Msg[0].innerHTML="";	
								            	desc_Id[0].innerHTML="";
								            	csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,$scope.functionalityId,$scope.fileUploadCallBack,$scope.policynumber,'Upload File');
								            }
										};
										
								
								            $scope.fileUploadCallBack = function(uploadFileJsonResp, fileId, upload_Msg,message) {
								            	
								            	if(uploadFileJsonResp=="ERROR")
								            	{
								            	
								          	    upload_Msg[0].innerHTML =  message;
								            	
								            	return false;
								            	}
								            	
								            	else
								            		{
								    	        var fileUploadResJsonObj = angular.fromJson(uploadFileJsonResp);
								    	        if (fileUploadResJsonObj != null &&
								    	            fileUploadResJsonObj != '' && fileUploadResJsonObj != "") {
								    
								    				if(fileUploadResJsonObj.errorCode!=undefined)
								    				{
								    					ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
								    				}
								    				else
								    				{
								    	        	for(var i=0;i<fileUploadResJsonObj.length;i++)
								    	        		{
								    	  
								    	        		if(angular.fromJson(fileUploadResJsonObj[i]).errorCode=="0")
								    	        		{
								    	        			if($scope.uploadName=="claimForm"){
								    	        				 $scope.claimPMJJBY.claimForm.push(angular.fromJson(fileUploadResJsonObj[i]));
								    	        			}
								    	        			if($scope.uploadName=="deathCertificate"){
								    	        				 $scope.claimPMJJBY.deathCertificate.push(angular.fromJson(fileUploadResJsonObj[i]));
								    	        			}
								    	        			if($scope.uploadName=="cancelledCheque"){
								    	        				 $scope.claimPMJJBY.cancelledCheque.push(angular.fromJson(fileUploadResJsonObj[i]));
								    	        			}								    	        											    	        	

								       	            if(fileId.length==1)
								       	            	{
								       	             upload_Msg[0].innerHTML =  "Document uploaded successfully.";
								       	            	}
								       	            else if(fileId.length<=2 && fileId.length>0)
								       	            	{
								       	            	upload_Msg[0].innerHTML =  "Documents uploaded successfully.";
								       	            	}								       	            
											       	         else{
											       	            	ajaxHttpFactory.showErrorSuccessMessagePopup("Invalid file upload", "errorMessage-popup","submitSuccessAlert"); 
											       	            	
											       	            	$scope.claimPMJJBY.claimForm=[];
											       	            	var fileDiv = angular.element( document.querySelector( '#file-upload-main'));
																	fileDiv.empty();								
																	var m1 = angular.element( document.querySelector( '#file-upload-main_errMsg'));
													    			m1.empty();
													    			m1.innerHTML = "";
													    			var m2 = angular.element( document.querySelector( '#file-upload-main_upText'));
													    			m2.empty();
											       	            	return false;
											       	            }
								    	        		}
								    	        		else
								    	        		{
								    	        			ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
								    	        		}
								    	        		}
								    	         
								    	           }
								    	            
								    	        } else {
								    	          
								    	            ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup", "SuccessAlert");
								    	        }
								    	        
								            		}
								    	        $rootScope.preloaderCheck=false;
								    	    };
								    	    
								    	    $scope.checkDate= function(currentElement,errorMsgElement){
								    	    	if(angular.element(document.getElementById(currentElement)).val()=="")
								    	    		{
								    	    		angular.element(document.getElementById(currentElement)).addClass('invalid1');
								    	    		angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
								    	    		return false;
								    	    		}
								    	    	else
								    	    		{
								    	    		angular.element(document.getElementById(currentElement)).removeClass('invalid1');
								    	    		angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
								    	    		}
								    	    	return true;
								    	    	};
								    	    
								    	    $scope.successMethod = function(response) {	
								    	    	$rootScope.preloaderCheck=false;
								    	    	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
								    	    	if (response != null && response != "null") {								    	    	
								    	    		$rootScope.openAlertID1 = true;
								    	    		$scope.action="success";
								    	    		$scope.message = "Your request submitted successfully with request Id "+response;	
								    	    		$scope.resetClaim();
								    	    	}
								    	    	}
													};																								
													
													$scope.failureMethod=function(){														
														$rootScope.preloaderCheck=false;														
														$rootScope.openAlertID1 = true;
														$scope.action="failure";
														$scope.message = "Some Error Occured.";
													};
								
														
							}]);
							