/*var app = angular.module('groupApp', ['ajaxUtil','ui.materialize','validationService','uiValidations']);*/
app
		.controller(
				'profileAuthorizedSigChangeCtrl',
				[
						'$rootScope',
						'$scope',
						'$location',
						'ajaxHttpFactory',
						'validateFieldService',
						'$window',
						'csrDocUploadFactory',
						function($rootScope, $scope, $location,
								ajaxHttpFactory, validateFieldService, $window,
								csrDocUploadFactory) {
							$scope.AuthoritySignDetailsAccessMatrix = {};
							$rootScope.preloaderCheck = true;
							$scope.modalErrorArray = [];
							$scope.errorArray = [];
							$scope.loadAuthoritySignatoryDetails = {};
							$scope.prePopulateAuthoritySignatoryChange = {};
							$scope.authoritySignatoryChangeSubmit = {};
							$scope.absUrl = window.location.origin
									+ window.location.pathname
									+ window.location.search;
							$scope.AuthorizedSignatory = false;
							$rootScope.enable = true;
							$scope.gender = [ "Male", "Female" ];
							$scope.uploadFileList = [];
							$scope.titleDetails = [];
							$scope.functionalityId = 0;

							$scope.onClickAuthorizedSignatory = function() {
								$scope.loadAuthoritySignatoryDetails.title.newValue = "";
								$scope.loadAuthoritySignatoryDetails.firstName.newValue = "";
								$scope.loadAuthoritySignatoryDetails.middleName.newValue = "";
								$scope.loadAuthoritySignatoryDetails.lastName.newValue = "";
								$scope.loadAuthoritySignatoryDetails.emailId.newValue = "";
								$scope.loadAuthoritySignatoryDetails.mobnumber.newValue = "";

								// $scope.isActiveNew=false;
								// $scope.loadAuthoritySignatoryDetails.active.newValue=false;
								$scope.authorityInsertLimit = true;
								$scope.prePopulateflag = false;

								var upload_Msg = angular
										.element(document
												.querySelector('#file-upload-main4_errMsg'));

								upload_Msg[0].innerHTML = "";

								var des_Msg = angular
										.element(document
												.querySelector('#file-upload-main4_upText'));

								des_Msg[0].innerHTML = "";
								$scope.modalErrorArray = [
										"authorized_title_new",
										"authorized_firstName_new",
										"authorized_lastName_new",
										"authorized_emailId_new",
										"authorized_number_new" ];
								$scope.AuthorizedSignatory = true;

							};

							$scope.onCallRadioButton = function(index) {
								var currentElement = angular.element(document
										.getElementsByClassName('invalid1'));
								currentElement.removeClass('invalid1');
								$('.err-msg').css("visibility", "");
								$scope.authorizedDiv = true;
								$scope.index = index;
								if ($scope.prePopulateAuthoritySignatoryChange[$scope.index].active.newValue == "true") {
									$scope.isActive = true;
								} else if ($scope.prePopulateAuthoritySignatoryChange[$scope.index].active.newValue == "false") {
									$scope.isActive = false;
								}

							};

							$scope.authorizedSignatoryChangeCancel = function() {
								var currentElement = angular.element(document
										.getElementsByClassName('invalid1'));
								currentElement.removeClass('invalid1');
								$('.err-msg').css("visibility", "");
								$scope.AuthorizedSignatory = false;
								$scope.onClickAuthorizedSignatory();
							};

							var getAuthoritySignDetailsAccessMatrix = function() {

								return ajaxHttpFactory
										.getJsonData(
												"getAuthoritySignDetailsAccessMatrix",
												$scope.absUrl)
										.then(
												function(response) {
													$rootScope.preloaderCheck = false;
													if (response != null
															&& response != "null") {
														var responseData = response.data;
														$scope.AuthoritySignDetailsAccessMatrix = responseData.resultMap;

													}
												},
												function(errResponse) {
													$rootScope.preloaderCheck = false;
													console
															.error('Error while fetching profile details.');

												});

							};
							getAuthoritySignDetailsAccessMatrix();

							var loadAuthoritySignatoryDetails = function() {

								return ajaxHttpFactory
										.getJsonData(
												"loadAuthoritySignatoryDetails",
												$scope.absUrl)
										.then(
												function(response) {
													$rootScope.preloaderCheck = false;
													if (response != null
															&& response != "null") {
														var responseData = response.data;
														$scope.loadAuthoritySignatoryDetails = responseData;
														$scope.functionalityId = $scope.loadAuthoritySignatoryDetails.functionalityId;

													}
												},
												function(errResponse) {
													$rootScope.preloaderCheck = false;
													console
															.error('Error while fetching profile details.');

												});

							};
							loadAuthoritySignatoryDetails();

							var prePopulateAuthoritySignatoryChange = function() {

								return ajaxHttpFactory
										.getJsonData(
												"prePopulateAuthoritySignatoryChange",
												$scope.absUrl)
										.then(
												function(response) {
													$rootScope.preloaderCheck = false;
													if (response != null
															&& response != "null") {
														var responseData = response.data;
														$scope.prePopulateAuthoritySignatoryChange = responseData;
														if ($scope.prePopulateAuthoritySignatoryChange.length > 0) {

															$scope.radiodiv = true;
															// $scope.prePopulateAuthoritySignatoryChange[0].active.newValue=="true"
															// ? true : false;

														} else {

															$scope.radiodiv = false;
														}

													}
												},
												function(errResponse) {
													$rootScope.preloaderCheck = false;
													console
															.error('Error while fetching profile details.');

												});

							};
							prePopulateAuthoritySignatoryChange();

							var getTitleDetails = function() {
								$rootScope.preloaderCheck = true;
								return ajaxHttpFactory
										.getJsonData("getTitleDetails",
												$scope.absUrl)
										.then(
												function(response) {

													if (response != null
															&& response != "null") {
														var responseData = response.data;

														$scope.titleDetails
																.push(responseData);

													}
													$rootScope.preloaderCheck = false;
												},
												function(errResponse) {
													$rootScope.preloaderCheck = false;
													console
															.error('Error while fetching profile details.');

												});
							};

							getTitleDetails();

							$scope.validateFields = function(name, action) {

								$scope.id = name;
								$scope.action = action;
								$scope.result = validateFieldService
										.fieldValidate(
												$scope.id,
												$scope.action,
												$scope.AuthoritySignDetailsAccessMatrix);
								return $scope.result;

							};

							$scope.onclickeditbtn = function(id) {

								$scope.validateFields(id, 'enable');
								$rootScope.enable = false;

							};

							$scope.onClickCancelBn = function(id) {
								var currentElement = angular.element(document
										.getElementsByClassName('invalid1'));
								currentElement.removeClass('invalid1');
								$('.err-msg').css("visibility", "");

								if ($scope.prePopulateAuthoritySignatoryChange[$scope.index][id].oldValue == "true") {
									$scope.isActive = true;
								} else if ($scope.prePopulateAuthoritySignatoryChange[$scope.index][id].oldValue == "false") {
									$scope.isActive = false;
								} else {
									$scope.prePopulateAuthoritySignatoryChange[$scope.index][id].newValue = $scope.prePopulateAuthoritySignatoryChange[$scope.index][id].oldValue;
								}

								$scope.validateFields(id, 'cancel');

								$rootScope.enable = true;

							};

							$scope.authorizedSignatorySubmitForm = function() {

								if ($scope.checkBasicFieldValidationsModal()) {

									if ($scope.uploadFileList.length > 0) {

										if ($scope.loadAuthoritySignatoryDetails.active.newValue == true) {
											$scope.loadAuthoritySignatoryDetails.active.newValue = "true";
										} else if ($scope.loadAuthoritySignatoryDetails.active.newValue == false) {
											$scope.loadAuthoritySignatoryDetails.active.newValue = "false";
										}

										$scope.authoritySignatoryChangeSubmit = $scope.loadAuthoritySignatoryDetails;
										$scope.authoritySignatoryChangeSubmit.uploadFiles = $scope.uploadFileList;

										var authoritySignatoryChangeSubmitJson = angular
												.toJson($scope.authoritySignatoryChangeSubmit);
										$rootScope.preloaderCheck = true;
										ajaxHttpFactory
												.postJsonDataSuccessFailure(
														authoritySignatoryChangeSubmitJson,
														"POST",
														$scope.absUrl,
														"authoritySignatoryChangeSubmit",
														$scope.successMethod,
														$scope.failureMethod);
									} else {
										ajaxHttpFactory
												.showErrorSuccessMessagePopup(
														"please upload file.",
														"errorMessage-popup",
														"submitFileAlert");
									}
								}
							};

							$scope.onClickSaveBn = function(id) {

								if ($scope.checkBasicFieldValidations()) {

									if ($scope.isActive == true) {
										$scope.prePopulateAuthoritySignatoryChange[$scope.index].active.newValue = "true";
									} else if ($scope.isActive == false) {
										$scope.prePopulateAuthoritySignatoryChange[$scope.index].active.newValue = "false";
									}
									if ($scope.prePopulateAuthoritySignatoryChange[$scope.index][id].newValue == $scope.prePopulateAuthoritySignatoryChange[$scope.index][id].oldValue) {
										ajaxHttpFactory
												.showErrorSuccessMessagePopup(
														"Enter a different value to save ",
														"errorMessage-popup",
														"AuthorizedAlert");
										$scope.validateFields(id, 'save');
										$rootScope.enable = true;
									} else {
										$scope.editAuthorizedSignatorySubmit = $scope.prePopulateAuthoritySignatoryChange[$scope.index];

										$scope.editAuthorizedSignatorySubmit.index = $scope.index;
										if ($scope.uploadFileList.length > 0) {
											$scope.validateFields(id, 'save');
											$scope.editAuthorizedSignatorySubmit.uploadFiles = $scope.uploadFileList;

											var editAuthorizedSignatorySubmitJson = angular
													.toJson($scope.editAuthorizedSignatorySubmit);

											$rootScope.preloaderCheck = true;
											ajaxHttpFactory
													.postJsonDataSuccessFailure(
															editAuthorizedSignatorySubmitJson,
															"POST",
															$scope.absUrl,
															"editAuthorizedSignatorySubmit",
															$scope.successMethod,
															$scope.failureMethod);
											$scope.prePopulateAuthoritySignatoryChange[$scope.index][id].newValue = $scope.prePopulateAuthoritySignatoryChange[$scope.index][id].oldValue;
											if (id == "active") {
												if ($scope.prePopulateAuthoritySignatoryChange[$scope.index][id].oldValue == "true") {
													$scope.isActive = true;
												} else {
													$scope.isActive = false;
												}

											}
											$rootScope.enable = true;
										} else {
											ajaxHttpFactory
													.showErrorSuccessMessagePopup(
															"please upload file.",
															"errorMessage-popup",
															"submitFileAlert");
										}
									}
								}
								$scope.uploadFileList.length = 0;
								$scope.OnResetBtn();

							};

							$scope.successMethod = function(response) {
								$rootScope.preloaderCheck = false;
								if (!ajaxHttpFactory.handleIPruException(
										response, "errorMessage-popup",
										"AuthChangeAlert"))

								{
									ajaxHttpFactory
											.showErrorSuccessMessagePopup(
													"Your request submitted successfully. ",
													"errorMessage-popup",
													"AuthChangeAlert");
									$scope.uploadFileList.length = 0;
									$scope.OnResetBtn();
									$scope.AuthorizedSignatory = false;
									$scope.onClickAuthorizedSignatory();

								}
							};

							$scope.failureMethod = function(response) {
								$rootScope.preloaderCheck = false;
								if (!ajaxHttpFactory.handleIPruException(
										response, "errorMessage-popup",
										"AuthChangeAlert")) {

									ajaxHttpFactory
											.showErrorSuccessMessagePopup(
													"Some Error Occured : ",
													"errorMessage-popup",
													"AuthChangeAlert");
									$scope.uploadFileList.length = 0;
									$scope.OnResetBtn();
									$scope.onClickAuthorizedSignatory();

								}
							};
							$scope.checkBasicFieldValidations = function() {
								if ($scope.errorArray.length > 0) {
									for ( var i = 0; i < $scope.errorArray.length; i++) {
										var lengthBfr = $scope.errorArray.length;
										var errorElement = angular
												.element(document
														.querySelector('#'
																+ $scope.errorArray[i]));
										if (errorElement.prop('type') == "text"
												|| errorElement.prop('type') == "textarea"
												|| errorElement.prop('tagName') == 'DIV'
												|| errorElement.prop('tagName') == "SELECT") {
											errorElement.triggerHandler("blur");
										}
										var lengthAftr = $scope.errorArray.length;
										if (lengthAftr < lengthBfr) {
											i--;
										}
									}
									if ($scope.errorArray.length > 0) {
										$("#" + $scope.errorArray[0]).focus();
										return false;
									} else {
										return true;
									}
								} else {
									return true;
								}
							};
							$scope.checkBasicFieldValidationsModal = function() {
								if ($scope.modalErrorArray.length > 0) {
									for ( var i = 0; i < $scope.modalErrorArray.length; i++) {
										var lengthBfr = $scope.modalErrorArray.length;
										var errorElement = angular
												.element(document
														.querySelector('#'
																+ $scope.modalErrorArray[i]));
										if (errorElement.prop('type') == "text"
												|| errorElement.prop('type') == "textarea"
												|| errorElement.prop('tagName') == 'DIV'
												|| errorElement.prop('tagName') == "SELECT") {
											errorElement.triggerHandler("blur");
										}
										var lengthAftr = $scope.modalErrorArray.length;
										if (lengthAftr < lengthBfr) {
											i--;
										}
									}
									if ($scope.modalErrorArray.length > 0) {
										$("#" + $scope.modalErrorArray[0])
												.focus();
										return false;
									} else {
										return true;
									}
								} else {
									return true;
								}
							};
							$scope.upload = function(upId, docType) {

								$rootScope.preloaderCheck = false;

								var desc_Id = angular.element(document
										.querySelector('#' + upId.id
												+ '_errMsg'));
								var upload_Msg = angular.element(document
										.querySelector('#' + upId.id
												+ '_upText'));

								if (upId.files.length != 0) {

									if (upId.files[0].size < 5242880) {
										var length = upId.files[0].name
												.lastIndexOf('.');
										var ext = upId.files[0].name.substring(
												length + 1,
												upId.files[0].name.length);
										if (ext == 'PDF' || ext == 'pdf'
												|| ext == 'jpg' || ext == 'JPG'
												|| ext == 'JPEG'
												|| ext == 'jpeg'
												|| ext == 'TIFF'
												|| ext == 'tiff'
												|| ext  == 'TIF'
												|| ext == 'tif') {

											upload_Msg[0].innerHTML = "";
											desc_Id[0].innerHTML = "";
											$scope.allowedExtensions=["PDF","pdf","TIFF","tiff","JPG","jpg","JPEG" ,"jpeg","tif","TIF"];
							            	csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,$scope.functionalityId,$scope.fileUploadCallBack,$scope.policynumber,'Upload File',$scope.allowedExtensions);

										} else {
											$scope.uploadFileList.length = 0;
											upload_Msg[0].innerHTML = "";
											desc_Id[0].innerHTML = "";
											upload_Msg[0].innerHTML = "<span class=red-text>Error While Uploading. File extension should be PDF or JPEG or TIFF</span>";
										}
									} else {
										$scope.uploadFileList.length = 0;
										upload_Msg[0].innerHTML = "";
										desc_Id[0].innerHTML = "";
										upload_Msg[0].innerHTML = "<span class=red-text>Error While Uploading.File size should not be more than 5 MB</span>";
									}
								}
							};

							$scope.fileUploadCallBack = function(
									uploadFileJsonResp, fileId, upload_Msg,
									message) {
								if (uploadFileJsonResp == "ERROR") {

									$scope.upload_Msg[0].innerHTML = message;

									return false;
								}

								else {
									var fileUploadResJsonObj = angular
											.fromJson(uploadFileJsonResp);
									if (fileUploadResJsonObj != null
											&& fileUploadResJsonObj != ''
											&& fileUploadResJsonObj != "") {

										if (fileUploadResJsonObj.errorCode != undefined) {
											ajaxHttpFactory
													.showErrorSuccessMessagePopup(
															"Error while uploading file. Please try again.",
															"errorMessage-popup",
															"submitSuccessAlert");
										} else {
											for ( var i = 0; i < fileUploadResJsonObj.length; i++) {

												if (angular
														.fromJson(fileUploadResJsonObj[i]).errorCode == "0") {
													$scope.uploadFileList.length = 0;

													$scope.uploadFileList
															.push(angular
																	.fromJson(fileUploadResJsonObj[i]));

													if (fileId.length == 1) {
														upload_Msg[0].innerHTML = "<span class=green-text>Document uploaded successfully.</span>";
													} else if (fileId.length > 1) {
														upload_Msg[0].innerHTML = "<span class=red-text>Documents uploaded successfully.</span>";
													}
												} else {
													ajaxHttpFactory
															.showErrorSuccessMessagePopup(
																	"Error while uploading file. Please try again.",
																	"errorMessage-popup",
																	"submitSuccessAlert");
												}
											}

										}

									} else {

										ajaxHttpFactory
												.showErrorSuccessMessagePopup(
														"Error while uploading file. Please try again.",
														"errorMessage-popup",
														"submitSuccessAlert");
									}

								}
								$rootScope.preloaderCheck = false;
							};

							$scope.OnResetBtn = function() {
								$scope.uploadFileList.length = 0;
								$scope.uploadFileList = [];
								angular.element("input[type='file']").val(null);
								var m1 = angular
										.element(document
												.querySelector('#file-upload-main3_errMsg'));
								m1.empty();
								var m2 = angular
										.element(document
												.querySelector('#file-upload-main3_upText'));
								m2.empty();

								var m3 = angular
										.element(document
												.querySelector('#file-upload-main4_errMsg'));
								m3.empty();
								var m4 = angular
										.element(document
												.querySelector('#file-upload-main4_upText'));
								m4.empty();
							};

						} ]);
