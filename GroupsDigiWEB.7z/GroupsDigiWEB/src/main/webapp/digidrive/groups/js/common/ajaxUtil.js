var listOfErrorFields=[];
var alertId = "";
angular.module('ajaxUtil', []).factory('ajaxHttpFactory', ['$http','$rootScope','$q','$window', function($http,$rootScope,$q,$window) {
        
		var flagForLead = false;
		
        var getUrl = function(url, eventId) {
            if (angular.isDefined(eventId) && eventId != null && eventId.trim() != "")
                url = url + "&_eventId=" + eventId;
            return url;
        };
        
        var token=$('#_tk').val();
        
        var httpAjaxCall = function(connectionObj) {
            return $http(connectionObj);
        };
        
        var asyncHttpAjaxCall = function(connectionObj) {
            var deferred = $q.defer();
            $http(connectionObj)
                .success(function(response) {
                    deferred.resolve(response);
                })
                .error(function(response) {
                    // log error
                    deferred.reject(response);
                });
            return deferred.promise;
        };
        
        var redirectToUrl = function(url) {
            if(url != "" && angular.isDefined(url))
	             $window.location.href = url;	       
        };
        
        
         var handleIPruException = function(response, messageErrorDivId, alertId) {
            try {
            		
                	if (response != "" && response != null && response != undefined && response != 'undefined') {
	                    var res = null;
	                    
	                    //if response is object do not parse
	                    res = (!angular.isObject(response)) ? JSON.parse(response) : response; 
	                    
	                    if (!(res != null && res.IPruException != null && res.IPruException.message != null && res.IPruException.message != undefined && res.IPruException.message != "")) {
	                    	//normal flow
	                        return false;
	                    } 
	                    else 
	                    {
	                    	//exception handling
	                        if (res != null && res.IPruException != null && res.IPruException.redirectUrl != "") {
	                            var temp = alertId;
	                            alertId = {};
	                            alertId["id"] = temp;
	                            alertId["redirectUrl"] = res.IPruException.redirectUrl;
	                            alertId["exceptionType"] = res.IPruException.exceptionType;
	                            alertId["message"] = res.IPruException.message;
	                            alertId["status"] = res.IPruException.status;
	                            alertId["statusCode"] = res.IPruException.statusCode;
	                        }
	                        
	                        if (angular.isUndefined(messageErrorDivId) || messageErrorDivId == '' || messageErrorDivId === null || messageErrorDivId =='errorMessage-popup')
	                            showErrorSuccessMessagePopup(res.IPruException.statusCode + " : " + res.IPruException.message, messageErrorDivId, alertId);
	                        else
	                            showErrorSuccessMessagePopup(res.IPruException.message, messageErrorDivId, alertId);
	                        
	                        return true;
	                    }
                	}
            } catch (e) {
                //If response is not of JSON type do nothing
            }
            return false;
        };//handleIPruException method end
   
        $rootScope.openModal=false;
        $rootScope.alertIdcheckflag=false;
        
	    var showErrorSuccessMessagePopup = function(message, messageErrorDivId, alertObj, status) {
	        	                
		    	//Handling front end exception -- set alertObj
		    	if ((angular.isUndefined(alertObj) || typeof alertObj === 'string' || alertObj instanceof String ) && (angular.isUndefined(status))  ){
		    		alertObj = {};
		            alertObj["exceptionType"] = "Front End Exception";
		            alertObj["redirectUrl"] = "javascript:void(0)";
		            alertObj["message"] = message;
		            alertObj["status"] = "ERROR";
		            alertObj["statusCode"] = "UIERR01";
		    	}else if (!angular.isUndefined(status) && status=='SUCCESS') {
		    		alertObj = {};
		    		alertObj["redirectUrl"] = "dashboard.htm";
		            alertObj["exceptionType"] = "Success";
		            alertObj["message"] = message;
		            alertObj["status"] = "INFO";
		            alertObj["statusCode"] = "SUCCESS";
		    	}
	    	
	            var divElem = "";
	            messageErrorDivId = (angular.isUndefined(messageErrorDivId) || messageErrorDivId == '' || messageErrorDivId === null) ? "errorMessage-popup" : messageErrorDivId;
	            alertId = (angular.isUndefined(alertObj)) ? "" : alertObj;
	             if (angular.isObject(alertObj)) {
	            	status = (angular.isUndefined(alertObj.status))?status:alertObj.status;
	            	alertId =  (angular.isUndefined(alertObj.id))?alertId:alertObj.id;
	            	listOfErrorFields = (angular.isUndefined(alertObj.listOfErrorFields))?[]:alertObj.listOfErrorFields;
	            	
	            }
	             
	            listOfErrorFields = message.split("|||");
	                                    
	            if (messageErrorDivId == null) {
	                alert(message);
	                return true;
	            } else {
		                if (messageErrorDivId.indexOf("errorMessage-popup") > -1) {
		                	
		                    var innerMessage = "";
		                    
			                if(listOfErrorFields.length > 0){
			                   	  for(var i= 0 ;i < listOfErrorFields.length;i++){
			                   		  
				                   	    if(i == 0)
				                   	    { 
				                   	    	message  = listOfErrorFields[i] + "<ul>";
				                   	    }
				                   	    else {
				                   	    	innerMessage = innerMessage + "<li>" + listOfErrorFields[i] + "</li>";
				                   	    	if(i == listOfErrorFields.length-1)
				                   	    		innerMessage = innerMessage + "</ul>";
				                   	    }
			                   	   }
			                   	  
			                }
		                   	
		                   	angular.element(document.getElementById("errorMessage-body")).html(message + innerMessage);
		                   	listOfErrorFields = [];
		                    angular.element(document.getElementById("errorClass modal")).attr("class", "info_" + status.toLowerCase() );
		                    
		                
		                    $rootScope.openModal=true;   
		                    $rootScope.preloaderCheck=false;
		                    $rootScope.$broadcast("alertIdShown", alertObj);
		                    return false;
		
		                }
		                else {
		                    divElem = angular.element(document.getElementById(messageErrorDivId));
		                    divElem.css("visibility", "visible");
		                    divElem.html(message);
		                    $rootScope.preloaderCheck=false;//stop
		                    return true;
		                }
	            }
	
	            return false;
	
	        };//showErrorSuccessMessagePopup method end
        
       
        
        return {
        	
        	createExcel : function(data, methodType,url, eventId,sql) {
        		 try {
         			url = getUrl(url, eventId);
     		   		$http({
     		   			url: url,
     		   			method: methodType,
     		   			data: undefined,
     		   			headers: {
                            'Content-Type': 'application/json',
                            '_tk' : token
     		   			},
                        
                    })
                    .success(function() {
                    	var res = alasql(sql,[data]);    
//                    	 $rootScope.$broadcast('pageSpinner', false);
                    	$rootScope.preloaderCheck=false;
                    }).error(
                        function(data) {
                            // Some error log                      
//                             $rootScope.$broadcast('pageSpinner', false);
                        	$rootScope.preloaderCheck=false;
                        });
     	   	} 
         	finally {
         		
            }
             },
             
             linkRedirectionUrlWdgt: function(url, param) {
                 if (url != null && url != undefined && url != 'NA') {
                	 var widgetId=url.substring(url.lastIndexOf("/",url.indexOf(".htm"))+1,url.indexOf(".htm"));
                     var otpurl = "otpmanager.htm?widgetFlowId=" + widgetId;
                     if (param != null && param != undefined && param != '') {
                         otpurl = otpurl + param;
                         $rootScope.transactionalOtp = true;
                     }
                     return asyncHttpAjaxCall({
                             type: "GET",
                             url: otpurl
                         })
                         .then(
                             function(response) {
                                 var resVal = response.split(',');
                                 if (resVal[0] != undefined && resVal[0] == 'TRUE') {
                                     $rootScope.otpFlag = true;
                                     $rootScope.otpExecutionKey = resVal[1];
                                     $rootScope.redirectionUrl = url;
                                 } else {
                                     if (param != null && param != undefined && param != '') {
                                         $rootScope.$broadcast('otpHandShake', true);
                                     } else {
                                         redirectToUrl(url);
                                     }
                                 }
                             },
                             function(errResponse) {
                             });
                 } else {
                 }

             } ,
       
    
            postJsonDataSuccessFailure : function(data, methodType, url, eventId, callBackSuccessFunction,callBackFailureFunction) {
            	try {
            			url = getUrl(url, eventId);
            			$http({
        		   			url: url,
        		   			method: methodType,
        		   			headers: {
                               'Content-Type': 'application/json',
                               '_tk' : token
        		   			},
                           data: data
                       })
                       .success(function(response) {
                               
                    	   if(response!=null && angular.isDefined(response) && response!="") {
                    		
                    		  callBackSuccessFunction(response);
                    		  
                             }
                           })
                       .error(function(response) {
                    	      callBackFailureFunction(response);
                       });
        	   	} 
            	finally {
            		
               }
           },
           
           
           
           
        getJsonData: function(eventId, url, params, method) {
            var isEmptyParamCheck = false; 
             url = getUrl(url, eventId);
             method = angular.isUndefined(method) ? "GET" : method;
             if(angular.isUndefined(params) || null == params || params == "" ){
               isEmptyParamCheck = true;
             }
     
             var connectionObj = {
                 url: url,
                 method: method,
                 headers:{
                 	'_tk':token
                 }
             };
             if(isEmptyParamCheck === false){
	                if (method.indexOf("GET") > -1 )
	                    connectionObj["params"] = params;
	                else
	                    connectionObj["data"] = params;
             }
             return httpAjaxCall(connectionObj);
         },
         
         handleIPruException: function(message, messageErrorDivId, alertId) {
                return handleIPruException(message, messageErrorDivId, alertId);
         },//method
         
         linkRedirectionUrl: function(url, divId) {
             if (url != null && url != undefined && url != 'NA') {
                 redirectToUrl(url);
             }
         },
         
         showErrorSuccessMessagePopup: function(message, messageErrorDivId, alertObj,status) {
        	 return showErrorSuccessMessagePopup(message, messageErrorDivId, alertObj,status);
         }
         
        };//return
        
    }])//angular.module end

    .directive("errorModalPopup", function() {
    return {
        
       template: '<div id="errorMessage-popup"  class = "modal" >' +
       '<div class="modal-content">'+
    
       	'<div ng-class="{ \'modal-body\': true,\'divScroll\' :errorLength > 0}">' +
			'<div id="errorClass" class=""></div>' +
			'<div class="errorMsgDiv" id="errorMessage-body"></div>'+
			'<div class="clearfix"></div>'+
		'</div>' +
       '</div>'+
       '<div class="modal-footer center-text">'+
       '<a class="btn" id="okBtn" ng-click="select()">Ok</a> &nbsp;'+
       '<a class="btn" id="cancelBtn" ng-click="cancel()">Cancel</a>'+
      
       '</div>',
        controller: ['$scope', '$rootScope', '$window', function($scope, $rootScope, $window) {
        	
        	    $scope.select = function () {
        	    	
        	    	//closes the pop up
        	    	 $rootScope.openModal = false;
        	    	 
        	    	 if (angular.isDefined(redirectUrl) && redirectUrl != "" && redirectUrl != "null") {
 	                	
 	                		$window.location.href = redirectUrl;
 	                }
 	              
        	    };//select method end

        	    $scope.cancel = function () {
        	    	//closes the pop up
        	    	 $rootScope.openModal = false;
        	    };

            //start : Variables initialization
            var redirectUrl = "";
            var cancelText="";
            $scope.errorLength = listOfErrorFields.length;
            //end : Variables initialization

            //start: function declarations                       
            $rootScope.$on('alertIdShown', function(event, args) {
                var cancelBtnElem = angular.element(document.getElementById("cancelBtn"));
                if (angular.isObject(args)) {
                    showConfirmBox = angular.isDefined(args.showConfirmBox)?args.showConfirmBox:false;
                    cancelText= (args.cancelText!=null && angular.isDefined(args.cancelText))?args.cancelText:"";
                    redirectUrl = angular.isDefined(args.redirectUrl)?args.redirectUrl:"";
                    (showConfirmBox) ? cancelBtnElem.removeClass("hidden"): cancelBtnElem.addClass("hidden");
                    if(args.enableEvents!=null && angular.isDefined( args.enableEvents) && args.enableEvents)
                    	$rootScope.enableEvents = false;
                    
                    if(cancelText!=null && typeof cancelText=='string' && cancelText.trim()!='')
                    {
                    	cancelBtnElem.html(cancelText);
                    }
                    else
                    {
                    	cancelBtnElem.html("Cancel");
                    }
                    
                } else {
                    alertId = args;
                    cancelBtnElem.addClass("hidden");
                }
            });
            //end: function declarations

        }]
    }//return
})//errorModalPopup directive end

.directive("modalPopupPage", function() {
    return {
    	restrict: 'E',
        transclude: true,
        scope :{modalId: '@'},
       template: '<div id={{modalId}}  class = "modal bottom-sheet" >' +
       '<div class="modal-content">'+
     
       	'<div ng-transclude></div>'+
		
       '<div class="modal-footer">'+
       '</div>' +
       '</div>',
};})//modalPopupPage directive end
       
.directive("alertCheck", function() {
    return {
    	restrict: 'E',
    	transclude: true,
    	scope :{alertId: '@'},
    	template: '<div id = {{alertId}} class = "modal">' +
       '<div class="modal-content">'+
        '<div ng-transclude></div>'+
		'</div>'
       
};})//alertCheck directive end

.directive("popup", function() {
    return {
    	restrict: 'E',
    	transclude: true,
    	scope :{popupId: '@'},
        template: '<div id = {{popupId}} class = "modal">' +
       '<div class="modal-content">'+
       '<div ng-transclude></div>'+
		'</div>'
       
};})//popup directive end

.directive("bigpopup", function() {
    return {
    	restrict: 'E',
    	transclude: true,
    	scope :{popupId: '@'},
        template: '<div id = {{popupId}} class = "bigmodal">' +
       '<div class="modal-content">'+
       '<div ng-transclude></div>'+
		'</div>'
       
};})

