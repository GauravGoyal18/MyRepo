var app = angular.module('groupApp', ['uiValidations','ajaxUtil','ui.materialize','validationService','generalUtility']);


app.controller('brokerDashboardController',['$rootScope','$scope','ajaxHttpFactory','$location','validateFieldService','$window',function($rootScope,$scope,ajaxHttpFactory,$location,validateFieldService,$window){
	
	$rootScope.preloaderCheck=true;
	$scope.brokerDetail = {};
	$scope.accessMappingList = {};
	$scope.fieldAccessMappingMap = [];
	$scope.roleAccessMapList = {};
    $scope.errorArray = [];
    
    var loadBrokerDashboardData = function() {
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("loadBrokerDashboardDetails",$location.absUrl())
		.then(function(response) {
			$rootScope.preloaderCheck=false;
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
				if (response != null && response != "null") {
					var brokerDashboardDetailsPO = response.data;
					$scope.brokerDetail = brokerDashboardDetailsPO;
					
					$scope.roleAccessMapList = $scope.brokerDetail.roleAccessMapList;
					
					
					if(angular.isDefined($scope.roleAccessMapList[0])){
						$scope.accessMappingList = $scope.roleAccessMapList[0].accessMappingList;
					}
					
					$rootScope.preloaderCheck=false;
				}
				$rootScope.preloaderCheck=false;
			} else{
				$rootScope.preloaderCheck=false;
			}
		}, 
		function(response) {
//			alert("In failureMethod");
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
				
			}
			$rootScope.preloaderCheck=false;
		});	
	};
	
	loadBrokerDashboardData();
	
	$scope.validateFields = function(id,action)  
	{
      
		$scope.id=id;
		$scope.action=action;
		$scope.result = validateFieldService.fieldValidate($scope.id,$scope.action,$scope.fieldAccessMappingMap);
		return $scope.result;
		
	};
	
	$scope.onclickIcon= function(id){
        
        var url=id.screenCode+".htm";
        if(url != "" && angular.isDefined(url))
       	 
       	 if(url == "serviceWebPage.htm"){
       		 url = url + "?selectedOption="+id.displayName;
       	 }
       	 
       	 $window.location.href = url;
        
    };
	
$scope.onclickTab= function(id){
    	
    	var roleAccessList = $scope.roleAccessMapList;
    	
    	for(var i = 0; i< roleAccessList.length; i++ ){
    		$('#tab_a_'+i).removeClass('active');
    	}
    	
    	// $('#tab_a_0').removeClass('active');
    	 $('#tab_a_'+id).addClass('active');
    	if(angular.isDefined($scope.roleAccessMapList[id])){
			$scope.accessMappingList = $scope.roleAccessMapList[id].accessMappingList;
		}
    };
	
    
}]);