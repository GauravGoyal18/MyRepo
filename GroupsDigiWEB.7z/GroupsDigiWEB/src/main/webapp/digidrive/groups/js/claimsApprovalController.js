var app=angular.module('groupApp',['ui.materialize','uiValidations','ajaxUtil','ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.grid.selection','groupCommonUtil']);

app.controller('claimsApprovalController',['$scope','ajaxHttpFactory','$location','$window','$filter','$http','$rootScope','uiGridConstants','csrDocUploadFactory', function($scope,ajaxHttpFactory,$location,$window,$filter,$http,$rootScope,uiGridConstants,csrDocUploadFactory){
	
	$rootScope.preloaderCheck=false;
	$scope.claimsApprovalDeathDiv=false;
	$scope.claimsApprovalNonDeathDiv=false;
	$scope.claimsApprovalViewDiv=false;
	$rootScope.claimsApprovalModal = false;	
	$scope.email2=false;
	$scope.trackType=[];
	$scope.trackStatus=[];
	$scope.logs={};
	$scope.errorArray=[];
	$scope.requestId=[];	
	$scope.Data=[];
	$scope.successResponse='';
	$scope.claimsApprovalModalData={}
	$scope.headerName="";
	$scope.selectedDataObj={};
	$scope.selectedDataObj.selectedData=[];
	var ajaxurl=$location.absUrl();
	$scope.claimsApprovalData=[];
	$scope.claimsApprovalDeathData=[];
	$scope.claimsApprovalNonDeathData=[];
	$scope.claimsApprovalDeathDataTrust=[];
	$scope.claimsApprovalNonDeathDataTrust=[];
	$scope.roleType="";
	$scope.row=[];
	$scope.allData=[];
	$scope.claimsViewData={};
	$scope.beneficiaryViewData={};
	$scope.excelValidationList=[];
	$scope.excelModal={};
	$scope.excelValidation={};
	$scope.excelValidationdata={};
	$scope.customerTrxnId='';
	$rootScope.excelModal =false;
	
	var paginationOptions = {
			    pageNumber: 1,
			    pageSize: 10,
			    sort: null
			  };
	 
		$scope.gridRowClick = function(member){				
			$rootScope.preloaderCheck=true;
			$scope.claimsApprovalModalData = member.entity;
			
			var claimsApprovalModalDataString = angular.toJson($scope.claimsApprovalModalData);
			
			ajaxHttpFactory.postJsonDataSuccessFailure(claimsApprovalModalDataString,"POST",ajaxurl,"getclaimsApprovalModalData",$scope.successViewMethod,$scope.submitFailureMethod);
			
		};
		
		
		$scope.gridRowClickOnStatus = function(member){				
			$scope.excelValidationList=[];
			$rootScope.preloaderCheck=true;
			$scope.excelValidation.customerTrxnId=$scope.excelValidationdata.customerTrxnId;
			$scope.excelValidation = member.entity;
			$scope.excelValidationdata.customerTrxnId=$scope.excelValidation.customerTrxnId;
			
			var excelJson = angular.toJson($scope.excelValidationdata);
			
			ajaxHttpFactory.postJsonDataSuccessFailure(excelJson,"POST",ajaxurl,"getclaimsExcelValidation",$scope.success2Method,$scope.failure2Method);
			
		};
		
		$scope.download = function(data){				
			$rootScope.preloaderCheck=true;
			
			var claimsApprovalDownloadDataString = angular.toJson(data.entity);
			
			ajaxHttpFactory.postJsonDataSuccessFailure(claimsApprovalDownloadDataString,"POST",ajaxurl,"getclaimsApprovalDownloadData",$scope.success1Method,$scope.submitFailureMethod);
			
		};
	 
	 
	 $scope.claimsgridDeathOptions = {
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableFiltering: false,
			    multiSelect: true,
		        //enableRowHeaderSelection : false,	
    		   enableRowSelection: true,
		        enableSelectAll: true,		      
		        showGridFooter:true,		      
		        resizable: false,
		        enableColumnResizing: true,
		        enableSorting: false,		       
		        
			    columnDefs: [
			      { field: 'customerTrxnId', displayName: 'CLAIM ID', width: "10%"},
			      { field: 'currentDate', displayName: 'CLAIM DATE', width: "30%"},			      
			      { field: 'approvalStatus', displayName: 'STATUS', width: "20%"},			     
			      { field: 'approvalDate', displayName: 'APPROVED DATE', width: "25%"},
			      { field: 'Action', displayName: 'ACTION', width: "15%", enableSorting: false,cellTemplate : '<div><p class="center-align"> <a modal modal1 data-target = "claimsApprovalView" data-dismissible="false" ready="onReady" open= "claimsApprovalModal" complete="onComplete"  ng-click="grid.appScope.gridRowClick(row)" class="uigridbtn" class="center-align" class="modal modal-fixed-footer">View Details</a></p></div>'}
			     // { field: 'Action', displayName: 'ACTION', width: "15%", enableSorting: false,cellTemplate : '<p> <a modal data-target = "claimsApprovalView" align="center" open= "claimsApprovalModal" ng-click="grid.appScope.gridRowClick(row)">View Details</a></p>'}
			    ],
			    
			    isRowSelectable : function(row) {
				    if(row.entity.approvalStatus === "PENDING")		    	
				    	return true;
				    else return false;
				},
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageD();			        
			      });			      
			     
			      gridApi.selection.on.rowSelectionChanged($scope,function(row){
			    	  if($scope.selectedDataObj.selectedData.indexOf(row.entity)==-1){			    		  
			    		  $scope.selectedDataObj.selectedData.push(row.entity);	  
			    	  }else{
			    		  var  index = $scope.selectedDataObj.selectedData.indexOf(row.entity);
			    		  $scope.selectedDataObj.selectedData.splice(index, 1);   
			    	  }  	
			        });
			      
			      gridApi.selection.on.rowSelectionChangedBatch($scope,function(rows){
			    	  	
			    	  for (var i=0; i<rows.length; i++) {			    		  			    		  
			    		  if($scope.selectedDataObj.selectedData.indexOf(rows[i].entity)==-1){
			    			  $scope.selectedDataObj.selectedData.push(rows[i].entity);
			    		  }else{
			    			  var  index = $scope.selectedDataObj.selectedData.indexOf(rows[i].entity);
			    			  $scope.selectedDataObj.selectedData.splice(index, 1);   
			    		  }
			    	    }
			    	  			    	 
			        });
			    }
			  };
	 
	
	 
	 
	 $scope.claimsgridNonDeathOptions = {
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableFiltering: false,
			    multiSelect: true,
		        //enableRowHeaderSelection : false,	
 		   enableRowSelection: true,
		        enableSelectAll: true,		      
		        showGridFooter:true,		      
		        resizable: false,
		        enableColumnResizing: true,
		        enableSorting: false,		       
		        
			    columnDefs: [
			      { field: 'customerTrxnId', displayName: 'CLAIM ID', width: "10%"},
			      { field: 'currentDate', displayName: 'CLAIM DATE', width: "30%"},			      
			      { field: 'approvalStatus', displayName: 'STATUS', width: "20%"},			    
			      { field: 'approvalDate', displayName: 'APPROVED DATE', width: "25%"},
			      { field: 'Action', displayName: 'DOWNLOAD', width: "15%",cellTemplate:'<button ng-click="grid.appScope.download(row)"><img src="digidrive/groups/images/download-icon.png" /></button>'}
			      /*{ field: 'Action', displayName: 'DOWNLOAD', width: "15%",cellTemplate:'<a ng-href=""  target="_blank"> <img src="digidrive/groups/images/download-icon.png" /></a>'}*/
			    ],
			    
			    isRowSelectable : function(row) {
				    if(row.entity.approvalStatus === "PENDING")		    	
				    	return true;
				    else return false;
				},
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageND();
			        $scope.headerName="CLAIM APPROVAL";
			      });			      
			     
			      gridApi.selection.on.rowSelectionChanged($scope,function(row){
			    	  if($scope.selectedDataObj.selectedData.indexOf(row.entity)==-1){			    		  
			    		  $scope.selectedDataObj.selectedData.push(row.entity);	  
			    	  }else{
			    		  var  index = $scope.selectedDataObj.selectedData.indexOf(row.entity);
			    		  $scope.selectedDataObj.selectedData.splice(index, 1);   
			    	  }  	
			        });
			      
			      gridApi.selection.on.rowSelectionChangedBatch($scope,function(rows){
			    	  	
			    	  for (var i=0; i<rows.length; i++) {			    		  			    		  
			    		  if($scope.selectedDataObj.selectedData.indexOf(rows[i].entity)==-1){
			    			  $scope.selectedDataObj.selectedData.push(rows[i].entity);
			    		  }else{
			    			  var  index = $scope.selectedDataObj.selectedData.indexOf(rows[i].entity);
			    			  $scope.selectedDataObj.selectedData.splice(index, 1);   
			    		  }
			    	    }
			    	  			    	 
			        });
			      
			      
			      
			    }
			  };
	 

	 
	 $scope.claimsgridDeathOptionsView = {			 				
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableFiltering: true,
			  
 		   enableRowSelection: false,
		      	      
		        resizable: false,
		        enableColumnResizing: false,
		        enableSorting: false,		       
		        
			    columnDefs: [
			      { field: 'customerTrxnId', displayName: 'CLAIM ID', width: "20%",enableFiltering: false},
			      { field: 'currentDate', displayName: 'CLAIM DATE', width: "30%",enableFiltering: false},			     			    
			      { field: 'approvalStatus', displayName: 'STATUS', width: "20%",enableFiltering: false},			   
			      { field: 'approvalDate', displayName: 'APPROVED DATE', width: "30%",enableFiltering: false}
			   	      
			    ],
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageDV();
			        $scope.headerName="CLAIM TRACKER";
			      });			      			 
			    }
			  };
	 
	 $scope.claimsgridNonDeathOptionsView = {			 				
			    paginationPageSizes: [10],
			    paginationPageSize: 10,
			    useExternalPagination: true,
			    useExternalSorting: true,
			    enableColumnMenus: false,
			    enableFiltering: true,
			  
		   enableRowSelection: false,
		      	      
		        resizable: false,
		        enableColumnResizing: false,
		        enableSorting: false,		       
		        
			    columnDefs: [
			      { field: 'customerTrxnId', displayName: 'CLAIM ID', width: "20%",enableFiltering: false},
			      { field: 'currentDate', displayName: 'CLAIM DATE', width: "30%",enableFiltering: false},			     			    
			      { field: 'approvalStatus', displayName: 'STATUS', width: "20%",enableFiltering: false,cellTemplate: '<div ng-if=\"row.entity.approvalStatus == \'INVALIDEXCEL\'" ><p > <a  modal data-target = "claimExcelValidationModal" data-dismissible="false" ready="onReady"  complete="onComplete" ng-click="grid.appScope.gridRowClickOnStatus(row)" class="uigridbtn">{{row.entity[col.field]}}</a></p></div><div ng-if=\"row.entity.approvalStatus != \'INVALIDEXCEL\'" ><p > {{row.entity[col.field]}}</p></div>'},			  
			      { field: 'approvalDate', displayName: 'APPROVED DATE', width: "30%",enableFiltering: false}
			     	      
			    ],
			    
			    isRowSelectable : function(row) {
				    if(row.entity.approvalStatus === "PENDING")		    	
				    	return true;
				    else return false;
				},
			    
			    onRegisterApi: function(gridApi) {
			      $scope.gridApi = gridApi;						      
			      gridApi.pagination.on.paginationChanged($scope, function (newPage, pageSize) {
			        paginationOptions.pageNumber = newPage;
			        paginationOptions.pageSize = pageSize;			     
			        $scope.getPageNDV();
			        $scope.headerName="CLAIM TRACKER";
			      });			      			 
			    }
			  };
		

	 

	 $scope.getPageD = function() {
	 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
     $scope.claimsgridDeathOptions.data=$scope.claimsApprovalDeathDataTrust.slice(firstRow, firstRow + paginationOptions.pageSize);
    
	};
	
	 $scope.getPageND = function() {
		 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);
	
	     $scope.claimsgridNonDeathOptions.data=$scope.claimsApprovalNonDeathDataTrust.slice(firstRow, firstRow + paginationOptions.pageSize);
	     
		};
	
		 $scope.getPageDV = function() {
			 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);		   
		     $scope.claimsgridDeathOptionsView.data=$scope.claimsApprovalDeathData.slice(firstRow, firstRow + paginationOptions.pageSize);
		   
			};
	
			 $scope.getPageNDV = function() {
				 var firstRow = ((paginationOptions.pageNumber - 1) * paginationOptions.pageSize);		   			    
			     $scope.claimsgridNonDeathOptionsView.data=$scope.claimsApprovalNonDeathData.slice(firstRow, firstRow + paginationOptions.pageSize);
				};
	
	
	var onLoadData=function(){			
		$rootScope.preloaderCheck=true;		
		return ajaxHttpFactory.getJsonData("LoadClaimsApproval",ajaxurl)
		.then(function(response){	
			
			if(ajaxHttpFactory.handleIPruException(response.data, "errorMessage-popup", "exceptionAlert")){
				 $rootScope.preloaderCheck=false;
			}
			$scope.roleType=response.data.role;
			$scope.productType=response.data.productType;
			var responseDeathData = response.data.deathList;
			$scope.claimsApprovalDeathData=responseDeathData;
			for(var i=0;i<responseDeathData.length;i++){
				if(responseDeathData[i].approvalStatus=="PENDING" || responseDeathData[i].approvalStatus=="REJECTED" || responseDeathData[i].approvalStatus=="APPROVED"){
					$scope.claimsApprovalDeathDataTrust.push(responseDeathData[i]);
				}				
			}			
			$scope.claimsgridDeathOptions.totalItems=$scope.claimsApprovalDeathDataTrust.length;
			//$scope.claimsgridDeathOptions.totalItems=$scope.claimsApprovalDeathData.length;
			
					
			var responseNonDeathData = response.data.nonDeathList;
			$scope.claimsApprovalNonDeathData=responseNonDeathData;
			
			for(var i=0;i<responseNonDeathData.length;i++){
				if(responseNonDeathData[i].approvalStatus=="PENDING" || responseNonDeathData[i].approvalStatus=="REJECTED" || responseNonDeathData[i].approvalStatus=="APPROVED"){
					$scope.claimsApprovalNonDeathDataTrust.push(responseNonDeathData[i]);
				}				
			}
						
			$scope.claimsgridNonDeathOptions.totalItems=$scope.claimsApprovalNonDeathDataTrust.length;	
		
				if($scope.roleType==="TRUST" && $scope.productType !="Gratuity" ){
					$scope.headerName="CLAIM APPROVAL";
					$scope.claimsApprovalDeathDiv=true;
					$scope.claimsApprovalNonDeathDiv=false;
					$scope.claimsApprovalDeathViewDiv=false;
					$scope.claimsApprovalNonDeathViewDiv=false;
				}else if($scope.roleType==="UPLOADER" || $scope.roleType==="MEMBER" || $scope.roleType==="GTRUST" || $scope.roleType==="TERM" || $scope.productType==="Gratuity"){
					$scope.headerName="CLAIM TRACKER";
					$scope.claimsApprovalDeathViewDiv=true;
					$scope.claimsApprovalNonDeathViewDiv=false;
					$scope.claimsApprovalDeathDiv=false;
					$scope.claimsApprovalNonDeathDiv=false;
				}	
				
					
				//$scope.claimsgridDeathOptionsView.totalItems=$scope.allData.length;
				$scope.claimsgridDeathOptionsView.totalItems=$scope.claimsApprovalDeathData.length;
				$scope.claimsgridNonDeathOptionsView.totalItems=$scope.claimsApprovalNonDeathData.length;
				 $scope.getPageD();	
				 $scope.getPageND();
				 $scope.getPageDV();
				 $scope.getPageNDV();
				 $rootScope.preloaderCheck=false;
			
		},
		function(errResponse){
			ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert");
			$rootScope.preloaderCheck=false;			
		});
	};

	onLoadData();

	
	$scope.nonDeath=function(){
		$rootScope.preloaderCheck=false;
		 angular.element( document.querySelector('#Death')).removeClass("claimbtn");
		 angular.element( document.querySelector('#nonDeath')).addClass("claimbtn");
			if($scope.roleType==="TRUST" && $scope.productType !="Gratuity"){
				$scope.headerName="CLAIM APPROVAL";
				$scope.claimsApprovalDeathViewDiv=false;
				$scope.claimsApprovalNonDeathViewDiv=false;
				$scope.claimsApprovalDeathDiv=false;
				$scope.claimsApprovalNonDeathDiv=true;
				
			}else if($scope.roleType==="UPLOADER" || $scope.roleType==="MEMBER" || $scope.roleType==="GTRUST" || $scope.roleType==="TERM" || $scope.productType ==="Gratuity"){
				$scope.headerName="CLAIM TRACKER";
				$scope.claimsApprovalDeathViewDiv=false;
				$scope.claimsApprovalNonDeathViewDiv=true;
				$scope.claimsApprovalDeathDiv=false;
				$scope.claimsApprovalNonDeathDiv=false;
				
			}
	
	};
	
	$scope.death=function(){		
		$rootScope.preloaderCheck=false;
		 angular.element( document.querySelector('#nonDeath')).removeClass("claimbtn");
		 angular.element( document.querySelector('#Death')).addClass("claimbtn");
		if($scope.roleType==="TRUST" && $scope.productType !="Gratuity"){
			$scope.headerName="CLAIM APPROVAL";
			$scope.claimsApprovalDeathViewDiv=false;
			$scope.claimsApprovalNonDeathViewDiv=false;
			$scope.claimsApprovalDeathDiv=true;
			$scope.claimsApprovalNonDeathDiv=false;
		}else if($scope.roleType==="UPLOADER" || $scope.roleType==="MEMBER" || $scope.roleType==="GTRUST" || $scope.roleType==="TERM" || $scope.productType ==="Gratuity"){
			$scope.headerName="CLAIM TRACKER";
			$scope.claimsApprovalDeathViewDiv=true;
			$scope.claimsApprovalNonDeathViewDiv=false;
			$scope.claimsApprovalDeathDiv=false;
			$scope.claimsApprovalNonDeathDiv=false;
		}	
	};
	
	$scope.approve = function(){	
		
		$rootScope.preloaderCheck=false;
		 
		if($scope.selectedDataObj.selectedData.length!=0){
			var approvedJson=angular.toJson($scope.selectedDataObj.selectedData);
			ajaxHttpFactory.postJsonDataSuccessFailure(approvedJson,"POST",ajaxurl,"Approved",$scope.successMethod,$scope.failureMethod);	
		}else{
			ajaxHttpFactory.showErrorSuccessMessagePopup("No Data Has Been Selected","errorMessage-popup", "claimsApprovalAlert");
		}
		
	}
	
	$scope.reject = function(){		
		$rootScope.preloaderCheck=false;
		
		if($scope.selectedDataObj.selectedData.length!=0){
		var approvedJson=angular.toJson($scope.selectedDataObj.selectedData);
		ajaxHttpFactory.postJsonDataSuccessFailure(approvedJson,"POST",ajaxurl,"Rejected",$scope.successMethod,$scope.failureMethod);
		}else{
			ajaxHttpFactory.showErrorSuccessMessagePopup("No Data Has Been Selected","errorMessage-popup", "claimsApprovalAlert");
		}
	}
	
	/*$scope.onClickOfStatus=function(){
		alert("hii");
		$rootScope.preloaderCheck=false;
		if($scope.excelValidation.ClaimsExcelValidationPO = $scope.claimApproval){
			var excelJson=angular.toJson($scope.excelValidation);
			ajaxHttpFactory.postJsonDataSuccessFailure(excelJson,"POST",ajaxurl,"getclaimsExcelValidation",$scope.successMethod,$scope.failureMethod);	
		}else{
			ajaxHttpFactory.showErrorSuccessMessagePopup("No Data Has Been Selected","errorMessage-popup", "claimsApprovalAlert");
		}
	}*/
		/*$scope.excelValidation = function(){	
		
		$rootScope.preloaderCheck=false;
		 
		if($scope.excelValidation != null && angular.isDefined($scope.excelValidation)){
			var excelJson=angular.toJson($scope.excelValidation);
			ajaxHttpFactory.postJsonDataSuccessFailure(excelJson,"POST",ajaxurl,"getclaimsExcelValidation",$scope.successMethod,$scope.failureMethod);	
		}else{
			ajaxHttpFactory.showErrorSuccessMessagePopup("No Data Has Been Selected","errorMessage-popup", "claimsApprovalAlert");
		}
		
	}*/
	$scope.successViewMethod = function(response) {		
		$rootScope.preloaderCheck=false;
    	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
    		$rootScope.claimsApprovalModal = true;	
    		if(response.employeeEmailId_2.length!=0){
    			$scope.email2=true;
    		}else{
    			$scope.email2=false;
    		}
    		$scope.claimsViewData=response;	

    			$scope.beneficiaryViewData=response.beneficiary;
    		  		
			
		}
	};
	
	$scope.closeView=function(){
		$rootScope.claimsApprovalModal = false;	
		$rootScope.excelModal = false;
	}
	
	$scope.okAlert= function (){
		$rootScope.openAlertID = false;		
		$window.location.href = "claimsApproval.htm";
	};
	
	
	$scope.successMethod = function(response) {		
		$rootScope.preloaderCheck=false;
    	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			if (response != null && response != "null") {	    	
	    		$rootScope.openAlertID = true;
	    		$rootScope.claimsApprovalModal = true;
	    		$rootScope.openAlertID1 = false;	    		
	    		$scope.action="success";
	    		$scope.message = "Updated Successfully";	    		
	    	}		
		}
	};
	
	$scope.success1Method = function(response) {		
		$rootScope.preloaderCheck=false;
    	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			if (response != null && response != "null") {	    	
	    		
	    		csrDocUploadFactory.downloadFileFromServer();
	    	}		
		}
	};
	
	$scope.success2Method = function(response) {
		
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			$scope.result=response;
			var excelValidationListJson = angular.fromJson(response);
			
			$scope.excelValidationList = excelValidationListJson;
			
			$rootScope.excelModal = true;
			
		} else {
			//$scope.excelValidationList = null;
			//ajaxHttpFactory.showErrorSuccessMessagePopup("No Data Available. ","errorMessage-popup", "ClaimExcelalert");
			$rootScope.preloaderCheck=false;
		}
	};
	
	$scope.failureMethod = function(response) {
		$rootScope.preloaderCheck=false;
		$rootScope.openAlertID = true;
		$scope.action="failure";
		$scope.message = "Some Error Occured.";		
	
		
	};	
	
	$scope.failure2Method = function(response) {
		//alert("In failureMethod");
		$rootScope.preloaderCheck=false;	
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
				
		} else {
			$rootScope.preloaderCheck=false;
		}
	};
	
    
}]);

