var app = angular.module('groupApp', [ 'ajaxUtil', 'uiValidations',
		'ui.materialize' ]);

app.controller('annuityCalculatorController', [
		'$scope',
		'$location',
		'ajaxHttpFactory',
		'$rootScope',
		'$window',
		function($scope, $location, ajaxHttpFactory, $rootScope, $window) {

			$scope.annuityCalculator = {};
			$scope.errorArray = [];
			$scope.showResult = false;
			$scope.showForm = true;
			$scope.showResultWithoutTax = false;
			$scope.showAge = false;
			$scope.showSpage = false;
			$scope.showClaimFormLink = false;
			$scope.disablePurchasePrice = false;
			$scope.claimId = '';
			
			var loadAnnuityData = function() {
				return ajaxHttpFactory.getJsonData("annuityLoad",$location.absUrl())
				.then(function(response) {
					if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
						if (response != null && response != "null") {
							var annuityResponseVO = response.data;
							$scope.showClaimFormLink = annuityResponseVO.showFormLink;
							if($scope.showClaimFormLink == true){
								$scope.annuityCalculator.inputAmt = annuityResponseVO.purchasePrice;
								$scope.claimId = annuityResponseVO.claimId;
								$scope.disablePurchasePrice = true;
							}
						}
					}
				}, 
				function(response) {
					if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
						
					}
				});
			};
			
			loadAnnuityData();			

			$scope.calculateAge = function(birthday) {

				var ageDifMs = Date.now() - birthday.getTime();
				var ageDate = new Date(ageDifMs);

				return Math.abs(ageDate.getUTCFullYear() - 1970);
			};

			var currentTime = new Date();
			$scope.currentTime = currentTime;
			$scope.month = [ 'January', 'February', 'March', 'April', 'May',
					'June', 'July', 'August', 'September', 'October',
					'November', 'December' ];
			$scope.monthShort = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
					'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ];
			$scope.weekdaysFull = [ 'Sunday', 'Monday', 'Tuesday', 'Wednesday',
					'Thursday', 'Friday', 'Saturday' ];
			$scope.weekdaysLetter = [ 'S', 'M', 'T', 'W', 'T', 'F', 'S' ];

			$scope.today = '';
			$scope.clear = 'Clear';
			$scope.close = 'Done';
			var days = 100;
			$scope.minDate = (new Date($scope.currentTime.getTime()
					- (10000000 * 60 * 60 * 24 * days))).toISOString();
			$scope.maxDate = (new Date($scope.currentTime.getTime()))
					.toISOString();
			$scope.onStart = function() {

			};
			$scope.onRender = function() {

			};
			$scope.onOpen = function() {

			};
			$scope.onClose = function() {
				$(document.activeElement).blur();

			};

			$scope.onSet = function(dob) {

				$scope.birthday = new Date(dob);
				if ($scope.birthday != '' || $scope.birthday != undefined) {
					$scope.annuityCalculator.annuitantAge = $scope
							.calculateAge($scope.birthday);

				}

			};

			$scope.onSet1 = function() {

				$scope.birthday = new Date($scope.annuityCalculator.spDob);
				if ($scope.birthday != '' || $scope.birthday != undefined) {
					$scope.annuityCalculator.spouseAge = $scope
							.calculateAge($scope.birthday);

				}
			};
			$scope.onStop = function() {

			};

			$rootScope.$on('isOkClicked', function(event, args) {
				if (args == 'exceptionAlert') {
					alert("Exception came");
				}
				if (args == 'submitSuccessAlert') {

				}
			});

			$scope.validateAgeForMale = function() {
				return validateAge($scope.annuityCalculator.annuitantAge,
						$scope.annuityCalculator.annuitantGender);
			}
			$scope.submitAnnuity = function() {

				if ($scope.checkBasicFieldValidations()) {
					if (validateAge($scope.annuityCalculator.annuitantAge,
							$scope.annuityCalculator.annuitantGender)) {
						$rootScope.preloaderCheck = true;

						$scope.annuityCalculator.ageDiff = calculateAgeDiff(
								$scope.annuityCalculator.annuitantAge,
								$scope.annuityCalculator.spouseAge,
								$scope.annuityCalculator.annuitantGender)

						var annuityDetailsSubmit = angular
								.toJson($scope.annuityCalculator);
						var ajaxurl = $location.absUrl();
						ajaxHttpFactory.postJsonDataSuccessFailure(
								$scope.annuityCalculator, "POST", ajaxurl,
								"annuitySubmit", $scope.successMethod,
								$scope.failureMethod);
					}

					else {
						ajaxHttpFactory.showErrorSuccessMessagePopup(
								"Age must be greater than 20 ",
								"errorMessage-popup", "annuityAlert");

					}
				} else {
					ajaxHttpFactory.showErrorSuccessMessagePopup(
							"Please Enter all Fields ", "errorMessage-popup",
							"annuityAlert");

				}
			}

			$scope.failureMethod = function() {

				$rootScope.preloaderCheck = false;

				$rootScope.openAlertID = true;
				$scope.action = "failure";
				$scope.message = "Some Error Occured.";
			};

			$scope.successMethod = function(response) {
				$rootScope.preloaderCheck = false;

				if (!ajaxHttpFactory.handleIPruException(response,
						"errorMessage-popup", "exceptionAlert")) {

					if (response != null && response != "null") {
						$scope.showResult = true;
						$scope.showForm = false;

						$scope.action = "success";
						$scope.result = response.list;
						$scope.result1 = response.list1;

						if (result1.length > 0) {
							$scope.showResultWithoutTax = true;
						}

					} else {
						ajaxHttpFactory.showErrorSuccessMessagePopup(
								"No data Found ", "errorMessage-popup",
								"annuityAlert");

					}
				}

			};
			$scope.okAlert = function() {
				$rootScope.openAlertID = false;

				if ($scope.action == "success") {
					$rootScope.openAlertID = false;

				} else if ($scope.action == "failure") {
					$rootScope.openAlertID = false;
				}

			};

			function validateAge(age, gender) {
				if (gender != undefined && gender != null && gender != "") {

					{
						if (age != undefined && age != null) {
							if (age < 20) {
								ajaxHttpFactory.showErrorSuccessMessagePopup(
										"DOB must be greater than 20",
										"errorMessage-popup", "annuityAlert");
								return false;
							}
						}

					}

					return true;
				}
				return false;
			}
			function calculateAgeDiff(annAge, spAge, gender) {
				var ageDiff = 0;
				if (annAge != undefined && annAge != null && annAge != ""
						&& !isNaN(annAge)) {
					if (spAge != undefined && spAge != null && spAge != ""
							&& !isNaN(spAge)) {
						if (gender == "M") {
							ageDiff = annAge - spAge;
						} else if (gender == "F") {
							ageDiff = spAge - annAge;
						}
					} else {
						ageDiff = annAge;
					}
				}
				return ageDiff;
			}

			$scope.cancelAlert = function() {
				$rootScope.openAlertID = false;

			};

			$scope.checkBasicFieldValidations = function() {

				if ($scope.errorArray.length > 0) {
					for ( var i = 0; i < $scope.errorArray.length; i++) {
						var lengthBfr = $scope.errorArray.length;
						var errorElement = angular.element(document
								.querySelector('#' + $scope.errorArray[i]));
						if (errorElement.prop('type') == "text"
								|| errorElement.prop('type') == "textarea"
								|| errorElement.prop('tagName') == 'DIV'
								|| errorElement.prop('tagName') == "SELECT") {
							errorElement.triggerHandler("blur");
						}
						var lengthAftr = $scope.errorArray.length;
						if (lengthAftr < lengthBfr) {
							i--;
						}
					}
					if ($scope.errorArray.length > 0) {
						$("#" + $scope.errorArray[0]).focus();
						return false;
					} else {
						return true;
					}
				} else {
					return true;
				}
			};
			$scope.checkDate = function(currentElement, errorMsgElement) {

				if (angular.element(document.getElementById(currentElement))
						.val() == "") {
					angular.element(document.getElementById(currentElement))
							.addClass('invalid1');
					angular.element(document.getElementById(errorMsgElement))
							.css('visibility', 'visible');
					return false;
				} else {
					if (currentElement == "dob") {
						$scope.showAge = true;
					} else if (currentElement == "spDob") {
						$scope.showSpage = true;
					}
					angular.element(document.getElementById(currentElement))
							.removeClass('invalid1');
					angular.element(document.getElementById(errorMsgElement))
							.css('visibility', 'hidden');
					return true;
				}

			}

		} ]);
