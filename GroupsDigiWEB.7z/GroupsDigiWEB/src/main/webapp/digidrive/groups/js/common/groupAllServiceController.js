var app = angular.module('groupApp', []);


app.controller('groupAllServiceController',['$scope', '$window','$rootScope' , function($scope, $window, $rootScope){
	
	/*$scope.WidgetList=angular.fromJson(dfltScreenWdgtList);
	$scope.dashBoardName=$scope.WidgetList.page;*/
	
	
	
	$scope.IWantToMenuDetails = angular.fromJson(dashboardIWantToJsonString);
	$scope.IWantToMenuList = $scope.IWantToMenuDetails.menuList;
	
	$scope.setDate = function(date) {
        $scope.cdate =new Date(date);
        return  $scope.cdate;
        
    };
    
    $scope.showSlider =  function(event){
	
	       var parentElementSlider = angular.element(event.currentTarget);
	        angular.element(parentElementSlider.find("#hide")).removeClass("hidden");
	        
    	
    	
    		
	      
	       
	      //  parentElementSlider.find("#hideThis").toggleClass('hidden');
	        
	       
	       
	        
	        //this.custom = this.custom === false ? true: false;
	      
	        
	     /*   parentElementSlider.find(".hide").toggleClass('hide');*/
	    
	};
	
	
	 $scope.showSlider1 =  function(event){
		  var parentElementSlider = angular.element(event.currentTarget);
	        angular.element(parentElementSlider.find("#hide")).addClass("hidden");
	    
	};
	
	
	$scope.linkRedirectionUrlWdgt=function(){	
	      $rootScope.$broadcast('pageSpinner',true);
	};
	
	
	$scope.custom = true;
    $scope.toggleCustom = function() {
        $scope.custom = $scope.custom === false ? true: false;
    };
	
    
    $scope.hoverIn = function(){
        this.hoverEdit = true;
    };

    $scope.hoverOut = function(){
        this.hoverEdit = false;
    };
    
    
    
    
    
    
    $scope.toggleClass = function (event){
        $(event.target).toggleClass('active');
    }
    
    
    
}]);