angular.module('groupCommonUtil', ['ajaxUtil']).factory('csrDocUploadFactory', ['$rootScope', '$http', 'ajaxHttpFactory', function($rootScope, $http, ajaxHttpFactory) {
    var uploadDetails = function(fileId, descId, successId, docType, functionality, callBackFunc, policyNumber, docName, allowedExtensions) {

        var filesToBeUploaded = [];
        $rootScope.typeflag = true;
        for (var i = 0; i < fileId.length; i++) {
            if (window.File && window.FileReader && window.FileList && window.Blob && fileId.length > 0) {
                if (docType == null || docType == '') {
                    callBackFunc("ERROR", fileId, successId, '<span class=red-text>Please upload file</span>');
                    return false;
                } else {
                    if (fileId != null && fileId != undefined) {

                        var mb = parseInt(1048576);
                        var size = Math.round((fileId[i].size) / mb);
                        if (size <= 5) {
                            var extension = fileId[i].type.split("/", 2)[1];


                            for (var j = 0; j <= allowedExtensions.length; j++) {
                                if (extension == allowedExtensions[j]) {

                                    if (descId != null) {
                                        descId[0].innerHTML = descId[0].innerHTML + "<br>" + fileId[i].name;

                                    }
                                    filesToBeUploaded.push(fileId[i]);
                                    break;
                                    return true;

                                } else {
                                    if (j == 0) {
                                        var dot = fileId[i].name.lastIndexOf(".");
                                        extension = fileId[i].name.substring(dot + 1, fileId[i].name.length);
                                    }
                                    if (extension == allowedExtensions[j]) {

                                        if (descId != null) {
                                            descId[0].innerHTML = descId[0].innerHTML + "<br>" + fileId[i].name;

                                        }
                                        filesToBeUploaded.push(fileId[i]);
                                        break;
                                        return true;

                                    }
                                    if (j >= allowedExtensions.length) {
                                    	  filesToBeUploaded = [];
                                        callBackFunc("ERROR", fileId, descId, '<span class=red-text>Invalid file format</span>');
                                        i=fileId.length;
                                        $rootScope.typeflag = false;
                                        break;
                                        return false;
                                    }
                                    

                                }
                                
                            }

                        } else {
                            callBackFunc("ERROR", fileId, descId, '<span class=red-text>File size exceeded 5MB</span>');
                            $rootScope.typeflag = false;
                            break;
                            return false;
                        }
                    } else {
                        callBackFunc("ERROR", fileId, descId, '<span class=red-text>Please upload File.</span>');
                        $rootScope.typeflag = false;
                        break;
                        return false;
                    }
                }
            } else {
                callBackFunc("ERROR", fileId, descId, '<span class=red-text>The File API is not supported by your Browser</span>');
                $rootScope.typeflag = false;
                break;
                return false;
            }

        } //for loop
        if ($rootScope.typeflag)
            uploadMultipleDocument(filesToBeUploaded, successId, docType, functionality, callBackFunc, policyNumber, docName);

    };



    var uploadMultipleDocument = function(fileId, successId, docType, functionality, callBackFunc, policyNumber, docName) {
        if (angular.isUndefined(fileId) || fileId == '') {

            return false;
        }

        var fd = new FormData();

        fd.append("docType", docType);
        fd.append("functionality", functionality);
        fd.append("docName", docName);
        fd.append("policyNumber", policyNumber);
        fd.append("numberOfFiles", fileId.length);
        for (var j = 0; j < fileId.length; j++) {
            fd.append("files" + j, fileId[j]);

        }

        $http
            .post(
                "group_uploadmultiplefiles.htm",
                fd, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined
                    }
                })
            .success(
                function(response) {
                    callBackFunc(JSON.stringify(response), fileId, successId);
                    //page spinner	
                })
            .error(
                function(errResponse) {


                    callBackFunc(JSON.stringify(errResponse), fileId, successId);
                });

    };

    var downloadFile = function() {
        var fd = new FormData();

        $http
            .post(
                "downloadFile.htm",
                fd, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined
                    }
                })
            .success(
                function(response) {
                    fileDownloadCallBack(JSON.stringify(response));
                    //page spinner	
                })
            .error(
                function(errResponse) {
                    fileDownloadCallBack(JSON.stringify(errResponse));
                });
    };

    var fileDownloadCallBack = function(response) {
        if (!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")) {
            if (response.includes("ERROR")) {

                ajaxHttpFactory.showErrorSuccessMessagePopup("<span class=red-text>Error while downloading file. Please try again.</span>", "errorMessage-popup", "submitSuccessAlert");

            } else {
                $rootScope.filePoId = angular.fromJson(response);
                var type = $rootScope.filePoId.contentType;
                var fileName = $rootScope.filePoId.docName;



                $rootScope.methodType = 'POST';


                $http({
                    url: 'DownloadFileServlet.do',
                    method: $rootScope.methodType,
                    responseType: 'arraybuffer',
                    data: undefined,
                    headers: {
                        'Content-type': 'application/json',
                        'Accept': type
                    }
                }).success(function(data) {
                    if (data.byteLength > 0) {
                        var blob = new Blob([data], {
                            type: type
                        });
                        saveAs(blob, fileName);
                        $rootScope.preloaderCheck = false;
                        ajaxHttpFactory.showErrorSuccessMessagePopup("<span class=green-text>File downloaded successfully.</span>", "errorMessage-popup", "submitSuccessAlert");

                    } else {

                        $rootScope.preloaderCheck = false;
                        ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ", "errorMessage-popup", "submitSuccessAlert");

                    }
                }).error(
                    function() {
                        // Some error log
                        // $rootScope.$broadcast('pageSpinner', false);
                        $rootScope.preloaderCheck = false;
                        ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ", "errorMessage-popup", "bidAlert");

                    });



            }
        } else {
            ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ", "errorMessage-popup", "bidAlert");

        }
    }
    return {
        uploadFileOnServer: function(fileId, descId, successId, docType, functionality, callBackFunc, policyNumber, docName, allowedExtensions) {
            return uploadDetails(fileId, descId, successId, docType, functionality, callBackFunc, policyNumber, docName, allowedExtensions);
        },

        downloadFileFromServer: function() {
            return downloadFile();
        }

    };


}]);