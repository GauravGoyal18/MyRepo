var app = angular.module('groupApp',['uiValidations','ajaxUtil','ui.materialize','groupCommonUtil']);

app.controller('serviceWebPageController',[ '$scope','ajaxHttpFactory','$location','$window','$rootScope','csrDocUploadFactory', function($scope,ajaxHttpFactory,$location,$window,$rootScope,csrDocUploadFactory){
	
	$rootScope.preloaderCheck=false;
	$scope.menuListPO = {};
	$scope.menuList = {};
	$scope.DownloadFormat = false;
	$scope.errorArray = [];
	$scope.submitJson = {};	
//	$scope.submitJson.clientId = '';
	$scope.errSuccessAlertObj = {};
	$scope.uploadArray={};
	$scope.submitJson.uploadFileList=[];
	$rootScope.openAlertID = false;
	$rootScope.check = false;
	
	$scope.showRequestType = false;
	$scope.showSelectRequestType = false;
	$scope.showResetButton = false;
	$scope.functionalityId = '';
	
	$scope.okalert= function()
	{
		$window.location.href = "dashboard.htm";	
	};
	
	$scope.upload = function(upId, docType) {
		$rootScope.preloaderCheck=true;
        var desc_Id = angular.element(document
            .querySelector('#' + upId.id+'_errMsg'));
        var upload_Msg = angular.element(document
            .querySelector('#' + upId.id + '_upText'));
            if(upId.files.length != 0){   
            	
            	//alert("upId.files"+upId.files+", desc_Id "+desc_Id+", upload_Msg"+upload_Msg+", " );
            	upload_Msg[0].innerHTML="";	
            	desc_Id[0].innerHTML="";
            	$scope.allowedExtensions=["PDF","pdf","TIFF","tiff","JPG","jpg","JPEG" ,"jpeg" ,"xls","XLS","xlsx","XLSX"];
            	csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,$scope.functionalityId,$scope.fileUploadCallBack,$scope.policynumber,'Upload File',$scope.allowedExtensions);
            }
		};
	//	$rootScope.check = false;
	
            $scope.fileUploadCallBack = function(uploadFileJsonResp, fileId, upload_Msg,message) {
            	
            	if(uploadFileJsonResp=="ERROR")
            	{
            		
            		//$rootScope.check = true;
          	    //  $scope.message = "Invalid file format.";
          	      
          	    upload_Msg[0].innerHTML =  message;
          	  $rootScope.preloaderCheck=false;
            		
            		//ajaxHttpFactory.showErrorSuccessMessagePopup(message, "errorMessage-popup","submitSuccessAlert");
            	return false;
            	}
            	
            	else
            		{
    	        var fileUploadResJsonObj = angular.fromJson(uploadFileJsonResp);
    	       // alert(fileUploadResJsonObj);
    	        if (fileUploadResJsonObj != null &&
    	            fileUploadResJsonObj != '' && fileUploadResJsonObj != "") {
    
    				if(fileUploadResJsonObj.errorCode!=undefined)
    				{
    					    	        			
    					  ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
    					  var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
    					  m.empty();
    					  m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
    				
    				}
    				else
    				{
    	        	for(var i=0;i<fileUploadResJsonObj.length;i++)
    	        		{
    	  
    	        		if(angular.fromJson(fileUploadResJsonObj[i]).errorCode=="0")
    	        		{
    	        	   $scope.submitJson.uploadFileList.push(angular.fromJson(fileUploadResJsonObj[i]));

       	            if(fileId.length==1)
       	            	{
       	             upload_Msg[0].innerHTML =  "Document uploaded successfully.";
       	            	}
       	            else if(fileId.length>1)
       	            	{
       	            	upload_Msg[0].innerHTML =  "Documents uploaded successfully.";
       	            	}
       	             //$rootScope.$broadcast('pageSpinner', false);
    	        		}
    	        		else
    	        		{
    	        			ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
    	        			var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
    	  				  	m.empty();
    	  				  	m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
    	        		}
    	        		}
    	         
    	           }
    	            
    	        } else {
    	           // $scope.errSuccessAlertObj['status'] = 'ERROR';
    	            ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup", "submitSuccessAlert");
    	            var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
  				  	m.empty();
  				  	m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
    	        }
    	        
            		}
    	        $rootScope.preloaderCheck=false;
    	    };
            
	var loadMenuList = function() {
		$rootScope.preloaderCheck=true;		
		return ajaxHttpFactory.getJsonData("getMenuListJson",$location.absUrl())
		.then(function(response) {
			if (response != null && response != "null") {
				var menuListPO = response.data;
				$scope.menuList = menuListPO.menuList;
				$scope.submitJson.policyNumber = menuListPO.policyNo;
				$scope.functionalityId = menuListPO.functionalityId;
				$scope.submitJson.selectedMenu = "Select Option";
				
				if($scope.menuList.length > 1) {
					$scope.showRequestType = false;
					$scope.showSelectRequestType = true;
					$scope.showResetButton = true;
				} else {
					$scope.showRequestType = true;
					$scope.showSelectRequestType = false;
					$scope.showResetButton = false;
					$scope.submitJson.selectedMenu = $scope.menuList[0];
					$scope.showDownloadFormat($scope.submitJson.selectedMenu);
				}
				
//				$scope.showDownloadFormat($scope.submitJson.selectedMenu);
//				alert("MenuList : "+$scope.menuList);				
			}
			$rootScope.preloaderCheck=false;
		}, 
		function(errResponse) {
			//alert("In failureMethod");
			$rootScope.preloaderCheck=false;
		});
	
//			ajaxHttpFactory.postJsonDataSuccessFailure(policyJson,"POST",ajaxurl,"zzSidanaSubmit",$scope.successMethod,$scope.failureMethod);
	};
	
	loadMenuList();
	
	$scope.showDownloadFormat = function(selectedMenu){
				
		if(selectedMenu != null){
			if(selectedMenu.formatLink != null){
				$scope.DownloadFormat = true;
				
			} else {
				$scope.DownloadFormat = false;
			}
		} else {
			$scope.DownloadFormat = false;
		}
	};
	
	$scope.OnSubmitBtn = function(){
		
		
//		alert("Inside submit button : "+$scope.submitJson);
		
		if($scope.submitJson != null && angular.isDefined($scope.submitJson)){
		
//		alert("$scope.submitJson.selectedMenu.requestMenuName  :"+ $scope.submitJson.selectedMenu.requestMenuName+":");
//		alert("$scope.submitJson.detailOfRequest  :"+$scope.submitJson.detailOfRequest+":");
		
			if($scope.checkBasicFieldValidations()){
				if($scope.DownloadFormat==false)
				{
					var submitJsonString = angular.toJson($scope.submitJson);
					var ajaxurl = $location.absUrl();
					$rootScope.preloaderCheck=true;
					ajaxHttpFactory.postJsonDataSuccessFailure(submitJsonString,"POST",ajaxurl,"serviceWebPageSubmit",$scope.submitSuccessMethod,$scope.submitFailureMethod);
				}
				else
					{
					if($scope.submitJson.uploadFileList.length>0)
						{
						var submitJsonString = angular.toJson($scope.submitJson);
						var ajaxurl = $location.absUrl();
						$rootScope.preloaderCheck=true;
						ajaxHttpFactory.postJsonDataSuccessFailure(submitJsonString,"POST",ajaxurl,"serviceWebPageSubmit",$scope.submitSuccessMethod,$scope.submitFailureMethod);
						
						}
					else
						{
						ajaxHttpFactory.showErrorSuccessMessagePopup("Please upload file. ","errorMessage-popup", "fileErrorAlert");
						}
					}
			} else {
				$rootScope.preloaderCheck=false;
			}
		}
	
	};

	$scope.checkBasicFieldValidations = function() {
	    if ($scope.errorArray.length > 0) {
	        for (var i = 0; i < $scope.errorArray.length; i++) {
	            var lengthBfr = $scope.errorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = $scope.errorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	        if ($scope.errorArray.length > 0) {
	            $("#" + $scope.errorArray[0]).focus();
	            return false;
	        } else {
	            return true;
	        }
	    } else {
	        return true;
	    }
	};

	$scope.submitSuccessMethod = function(response) {
//		alert("In Success Method");
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			var fileUploadJson = angular.fromJson(response);
			if(fileUploadJson != null){
				var requestId = fileUploadJson.requestId;
//				alert("Your request submitted successfully. Reference No : "+fileUploadJson.requestId);
				$rootScope.check = true;
				$scope.message = "Your request submitted successfully. Reference No : "+fileUploadJson.requestId;
				//ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. Reference No : "+fileUploadJson.requestId,"errorMessage-popup", "submitSuccessAlert");
				$scope.OnResetBtn();
				$rootScope.preloaderCheck=false;
				
//				$window.location.href = "dashboard.htm";
				
				
//				$scope.errSuccessAlertObj={};
//				$scope.errSuccessAlertObj['status'] = 'INFO';
//				ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. Reference No : "+requestId,'', $scope.errSuccessAlertObj);
//				$scope.OnResetBtn();
			}	
		} 
//		alert("angular.fromJson(response)  : "+angular.fromJson(response));
		
	};

	$scope.submitFailureMethod = function(response) {
		
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			
		}
		$rootScope.preloaderCheck=false;
	};
	
	$rootScope.$on('isOkClicked', function(event, args) {
		 if (args == 'exceptionAlert') {
			alert("Exception came") ;
		 } if (args == 'submitSuccessAlert') {
			alert("Submit success.") ;
		 }		 
	 });
	
	$scope.OnResetBtn = function(){
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$('.err-msg').css("visibility", "");
		$scope.submitJson.detailOfRequest = '';
		$scope.submitJson.selectedMenu = {};
		angular.element("input[type='file']").val(null);
		
		var fileDiv = angular.element( document.querySelector( '#file-upload-main'));
		fileDiv.empty();
		
		$scope.inputTextFile = '';
		
		var m = angular.element( document.querySelector( '#file-upload-main_errMsg'));
		m.empty();
		m.innerHTML = "<b>List Of Uploaded Documents</b><br>";
		
		var m2 = angular.element( document.querySelector( '#file-upload-main_upText'));
		m2.empty();
        //angular.element("#file-upload-main").value = "";
//		$("#detailOfRequest_errMsg").css("visibility").value = "hidden";
//		$scope.uploadArray.mainFile = {};
	};
}]);