var jPM ;

function checkScreenSize(wdgtArray){
	 //js code for small browser - + code = start here
	var mq = window.matchMedia( "(max-width: 767px)" );
	
	 if (mq.matches) {
		 $.each( wdgtArray, function( index, value ){
			 $( "#login_widg_"+value+"_content" ).hide();
			 $( "#login_widg_"+value).text("+");
			// $( "#login_widg_"+value).text("+");
			
			});
		 
		}
		else {
			//alert("100");
		}
	//js code for small browser - + code = end here
}

function populateWidget(divElm, config)
{
	//making a sync ajax call
	var divContent= $.ajax({
	    type: "GET",
	    url: config.loadUrl,
	    async: false
	}).responseText;

	return divContent;
}

function addWidget(id,widgetIdParam,wdgtindex)
{
	var widgetConfig = null;
	var widgetIndex = null;
	$.each(widgetConfigArray, function(index, value) {
        if(widgetIdParam==value.divIdPrefix)
    	{
        	widgetConfig = value;
        	widgetIndex = value.widgetId;
        	return false;
    	}
    });
	var divId = 'win_'+widgetIdParam;
	var divElm= id;
	addWidgetFrame(divElm,divId,widgetConfig,widgetIndex);
	 /*if (mq.matches) {
		 if(wdgtindex!=1){
			 $( "#login_widg_"+widgetIdParam+"_content" ).hide();
			 $( "#login_widg_"+widgetIdParam).text("+");
			// $( "#login_widg_"+value).text("+");
		 }
		}
		else {
			//alert("100");
		}
*/
}

function succesCallBack(response){
	
	var json = jQuery.parseJSON(response);
	if(json!=undefined && json!=""){
		//added for csrf
		$('#csrfTokenH').val(json[1].CSRFToken);
		
		if(json[0].Result=="true"){
			//alert("Widget configuration saved successfully.");
			return true;
		}
		
			
	}
	alert("Failed to save widget configuration.");
}

function removeWidget(widgetIndex,divId)
{
		 
	$('#win_'+divId).remove();
	
	
}
function rearrangeWidgets(){
	var parentPageCount = 1;
	var count=0;
	document.getElementById("masterDiv").innerHTML = "";
	var divId = addSliderPage("masterDiv",parentPageCount);
	$("#jPanelMenu-menu [class='merger_arrow_right']").each(function() {
	 var $this = $(this);    
	    if($(this).hasClass("merger_arrow_right")){
	    	++count;
			var wdgtJsonId=$this.attr("title");
			
			if((parentPageCount*wdgtOnPageCnt) < count){
				parentPageCount++;
				divId = addSliderPage("masterDiv",parentPageCount);
			}
			
			addWidget(divId,wdgtJsonId,count);
			 
			$(function() {
				
			for(var i=0; i<parentPageCount; i++){
			 $( "#landing_sortable_0"+parentPageCount).sortable({
			 	revert: true
			 });
			 $( "#draggable" ).draggable({
				 connectToSortable: "#landing_sortable_0"+parentPageCount,
				 helper: "clone",
				 revert: "invalid"
			 });
			}
			 $( "ul, li" ).disableSelection();
			});
		
	    }
	});
	
	/*if(parentPageCount==1){
		$("#leftSlider").hide();
		$("#rightSlider").hide();
		
	}*/
}
/*function checkAndUncheck(id,widgetIdParam)
{
	    if ($('#'+id).hasClass("merger_arrow_right")) {
	    	
		    jPM.off();
			$('#'+id).removeClass("merger_arrow_right").addClass("merger_arrow_wrong");
			jPM.on();
			jPM.open();
	    
	    }
			else{
				 jPM.off();
					$('#'+id).removeClass("merger_arrow_wrong").addClass("merger_arrow_right");
					jPM.on();
					jPM.open();
		}
    
	if ($('#'+id).hasClass("merger_arrow_right")) {
    }
	else
	{
		removeWidget(id,widgetIdParam);
		
	}
	rearrangeWidgets();
	saveWdgt();
}
*/
function toggleUpDown(minimizeId,contentId)	
{
		$("#"+contentId ).toggle( "slow" );
		var newText = $("#"+minimizeId).text() == "-" ? "+" : "-";
	    $("#"+minimizeId).text(newText);
}
function getContextPath()
{
	var contextpath=window.location.pathname.split('/');
	return contextpath[1];
}
 var contextpath=getContextPath();


function linkRedirectionJsonUrl(widgetId){
	
	var widgetConfig = null;
	var url="";
	$.each(widgetConfigArray, function(index, value) {
        if(widgetId==value.widgetId)
    	{
        	widgetConfig = value;
        	return false;
    	}
    });
	if(widgetConfig.pageUrl=="#."){
		return false;
	}
	
	if((widgetConfig.pageUrl).indexOf(contextPath) <0)
		url="/"+contextpath+"/"+widgetConfig.pageUrl;
	else
		url=widgetConfig.pageUrl;
	var str1 = "://";
	if(widgetConfig.pageUrl.indexOf(str1) != -1){
	    url=widgetConfig.pageUrl;
	}

  window.location.href=url;

}

function linkRedirection(url){
	if(url!=null && url!= undefined && url!="null" && url!="undefined"){
		window.location.href=url+".htm";
	}
}

function linkRedirectionUrl(url){
	if(url!=null && url!= undefined && url!="null" && url!="undefined"){
		    	window.location.href=url;
	}
}

function linkRedirectionUrlWdgt(divId, url){
	if(url!=null && url!= undefined && url!="null" && url!="undefined"){
		

		 if(divId=="win_oldWebsite" || divId=="win_dlWebsite" || divId=="win_digitalHelpLine" || divId=="claims" ||  divId=="win_rAndRMicrosite" || divId=="win_socialConnect" || divId=="win_fundPerformance" || divId=="win_loginAssistant" || divId=="win_cms" || divId=="win_taxChamp" || divId=="win_mynavigator" || divId=="win_csr_grievance")
		    {
			 window.open(
					 url,
					  '_blank' // <- This is what makes it open in a new window.
					);
		    }
		    else
		    {	
		    	if(divId=="win_wealthPlans"){
		    		if(pasaFlow!=undefined){
		    		url=url+"&Flow="+pasaFlow;
		    		}	
		    	}
		    	window.location.href=url;
		    }
		 
		
	}
}

function addSliderPage(parentDiv, divId){
	$.unblockUI();
	var wHTML = "";
	if(divId=="1"){
	wHTML +=('<div id ="'+divId+'" class="active item">');
	}
	else{
		wHTML +=('<div id ='+divId+' class="item">');
	}
    wHTML += ('<div class="row-fluid login_widght" id="landing_sortable_0'+divId+'"></div></div>');

    document.getElementById(parentDiv).innerHTML += wHTML;
    var conDiv = $('#landing_sortable_0'+divId);
    return conDiv;
	
}
function addWidgetFrame(parentDiv,divId,config,widgetIndex)
{
		var wHTML = "";
	 if((widgetIndex!= null && widgetIndex!= undefined && widgetIndex!='' && widgetIndex!= 'null')&&(widgetIndex=="81"))
		{
		 wHTML +=(
				 '<div id ="'+divId+'" class="span12 ui-state-default" style="cursor:pointer;" onclick="linkRedirectionUrlWdgt(this.id,\''+config.pageUrl+'\');" >'
				 );
		}
	else if((widgetIndex!= null && widgetIndex!= undefined && widgetIndex!='' && widgetIndex!= 'null')&&(widgetIndex=="62" || widgetIndex=="63"))
		{
		 wHTML +=(
				 '<div id ="'+divId+'" class="span6 ui-state-default" style="cursor:pointer;" onclick="linkRedirectionUrlWdgt(this.id,\''+config.pageUrl+'\');" >'
				 );
		}
	 else if((widgetIndex!= null && widgetIndex!= undefined && widgetIndex!='' && widgetIndex!= 'null')&&(widgetIndex=="89" || widgetIndex=="67"))
	 {
		 wHTML +=('<div id ="'+divId+'" class="span3 ui-state-default" style="cursor:pointer;" onclick="linkRedirectionUrlWdgt(this.id,\''+config.pageUrl+'\');">');
	 }
	else if((widgetIndex!= null && widgetIndex!= undefined && widgetIndex!='' && widgetIndex!= 'null')&&(widgetIndex=="109"))
	{
		 wHTML +=(
				 '<div id ="'+divId+'" class="span6 ui-state-default" style="cursor:pointer;" onclick="linkRedirectionUrlWdgt(this.id,\''+config.pageUrl+'\');" >'
				 );
	}
	 else{
		 wHTML +=('<div id ="'+divId+'" class="span3 ui-state-default" style="cursor:pointer;" onclick="linkRedirectionUrlWdgt(this.id,\''+config.pageUrl+'\');">');
	 }     	
		
	//wHTML +=('<div id ="'+divId+'" class="span3 ui-state-default">');
    //wHTML += ('<div class="login_widght_header"><a href="'+config.pageUrl+'">'+config.title+'</a><span class="merger_login_widght_display">');
    //wHTML += ('<a href="#." class="header_minus_icon" onclick="toggleUpDown(this.id,\''+config.contentId+'\');" id="'+config.minimizeId+'">-</a>');
    //wHTML += ('<a href="#." onclick="removeWidget(\''+config.widgetId+'\',\''+config.divIdPrefix+'\');saveWdgt();" id="'+config.closeId+'">X</a>');
    //wHTML += ('</span></div>');
	if((widgetIndex!= null && widgetIndex!= undefined && widgetIndex!='' && widgetIndex!= 'null')&&(widgetIndex=="4"))
	{
    wHTML += ('<div class="login_widght_content" id="'+config.contentId+'">');
	}
	else
	{
		wHTML += ('<div class="login_widght_content" id="'+config.contentId+'">');
	}
	 
    if(config.loadUrl != null && config.loadUrl != undefined && config.loadUrl !='' && config.loadUrl != 'null')
	{
    	wHTML +=populateWidget(config.contentId,config);
    	
	}else if(config.imageUrl!=null && config.imageUrl!=undefined &&  config.imageUrl!='' && config.imageUrl!='null' )
    {
		if(config.imageUrlWthFnCall!=null){
			wHTML += ('<img src='+config.imageUrl+' class="img-responsive" onclick='+config.imageUrlWthFnCall+'('+config.widgetId+')>');
		}else{
		wHTML += ('<img src='+config.imageUrl+' class="img-responsive">');
		}
		wHTML += ('<p><strong>'+config.title+'</strong><br /><span class="merger_smallTxt">'+config.text+'</span></p>');
		
    }else if(config.pageUrl!=null && config.pageUrl!=undefined && config.pageUrl!='#.' && config.pageUrl!='#' && config.pageUrl!='' && config.pageUrl!='null'){
    	
    	wHTML += ('<img src="merger/img/awaiting-content.jpg" class="img-responsive">');
    	
    } else{
    	
    	wHTML += ('<img src="merger/img/ComingSoon.jpg" class="img-responsive">');
	}
   
   
    wHTML += ('</div>');
    wHTML += ('</div>');
    //document.getElementById(divId).innerHTML = wHTML;
    document.getElementById(parentDiv[0].id).innerHTML += wHTML;
  //  document.getElementById(divId).className = "span3 ui-state-default";
   // $(divId).addClass("span3 ui-state-default");
    var conDiv = $('#'+config.contentId);
  //  document.getElementById(""+config.widgetId).checked=true;
  //  $("#"+config.widgetId ).removeClass("merger_arrow_wrong");
  //  $("#"+config.widgetId ).addClass("merger_arrow_right");

    return conDiv;
    //return parentDiv;
	
}

