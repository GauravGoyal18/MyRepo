var app = angular.module('groupApp', ['ajaxUtil','validationService','uiValidations','ui.materialize']);
app.controller('serviceExpressController',['$rootScope','$scope','$location','ajaxHttpFactory','validateFieldService', function($rootScope, $scope,$location,ajaxHttpFactory,validateFieldService)
{
	
	$scope.errorArray = [];
	$rootScope.preloaderCheck=false;
	$scope.serviceExp = {};
	var ajaxurl=$location.absUrl();
	

       
       
       $scope.onclicksubmitbtn=function(){           	   	
    	   $rootScope.preloaderCheck=true;
   		
   		if($scope.serviceExp != null && angular.isDefined($scope.serviceExp))
   		{			
   			if($scope.checkBasicFieldValidations())
   			{	
   			
   				
   			
   				var requestDataJson=angular.toJson($scope.serviceExp);
   				
   				ajaxHttpFactory.postJsonDataSuccessFailure(requestDataJson,"POST",ajaxurl,"Submit",$scope.submitSuccessMethod,$scope.submitFailureMethod);
   				$rootScope.preloaderCheck=false;
   			} 
   			else 
   			{
   				$rootScope.preloaderCheck=false;
   			}
   		}
   		else 
   			{
   				$rootScope.preloaderCheck=false;
   			}
   	
   	};
      
	$scope.OnResetBtn = function(){
			
			var currentElement = angular.element(document.getElementsByClassName('invalid1'));
			currentElement.removeClass('invalid1');
			$('.err-msg').css("visibility", "");
			$scope.serviceExp = {};
       	};
       
   	
       	
       	$scope.checkBasicFieldValidations = function() {
       	
	    if ($scope.errorArray.length > 0) {
	        for (var i = 0; i < $scope.errorArray.length; i++) {
	            var lengthBfr = $scope.errorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = $scope.errorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	        if ($scope.errorArray.length > 0) {
	            $("#" + $scope.errorArray[0]).focus();
	            return false;
	        } else {
	            return true;
	        }
	    } else {
	        return true;
	    }
	};
		$scope.submitSuccessMethod = function(response) {

		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			var serviceExpressJson = angular.fromJson(response);
			if(serviceExpressJson != null){
				var requestId = serviceExpressJson.requestID;

				ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. Reference No : "+requestId,"errorMessage-popup", "submitSuccessAlert");
				$scope.OnResetBtn();
			
				
				
			}	
		} 

		
	};

	$scope.submitFailureMethod = function() {
		
		$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
			ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured","errorMessage-popup", "submitFailureAlert");
		
			
		}

	};
	
}]);