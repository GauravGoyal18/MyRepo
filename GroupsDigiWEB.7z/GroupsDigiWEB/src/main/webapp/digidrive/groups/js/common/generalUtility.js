(function (ng) {
    'use strict';

    var app = ng.module('generalUtility', []);
    
    //angular Value Object maintain to handle Errors
    app.value('EbiValues',{
    	EbiInputErrors : [],
    	ErrorMsg:{}
    });
    
    app.filter('toPercent', function() {
      return function (value,toFixed) {
  		if (value == 0) {
  		    value = "NA";
  		} else if (Math.abs(value) >= 1){
  		    value =  (value).toFixed(toFixed) + "%";
                  }else{
  		    value =  (value).toFixed(toFixed) + "%";
                  }
                  return value;
      }
    });
    
    app.filter('ordinal', function() { 
    	  // Create the return function and set the required parameter name to **input**
    	  // provide the number
    	  return function(number) {
    	    if(isNaN(number)) {
    	      return number;
    	    } else {
    		    if(number == 1) 
    		    	return number + 'st';
    		    else if(number == 2) 
    		    	return number + 'nd';
    		    else if(number == 3) 
    		    	return number + 'rd';
    		    else if(number > 3) 
  		    	return number + 'th';
    	    }
    	  };
    	});
    
    app.filter('ifEmpty', function() {
        return function(input, defaultValue) {
            if (angular.isUndefined(input) || input === null || input === '') {
                return defaultValue;
            }

            return input;
        }
    });
    
    app.filter('customDate', function($filter) { 

    	  // Create the return function and set the required parameter name to **input**
    	  //
    	
    	
    	
    	  return function(input) {
    	    // Ensure that we are working with some data
    		  var temp="";
    		  if (angular.isDefined(input))
    		  {
    			  if(input.toString().indexOf('-') > -1)
    			{
    				  temp=input.split('-');  
    			}
    			  else if (input.toString().indexOf('\\') > -1)
    			 {
    				  temp=input.split('\\'); 
    			 }
    			  else if (input.toString().indexOf('\/') > -1)
     			 {
     				  temp=input.split('\/'); 
     			 } 
    			  else if (input.toString().indexOf(' ') > -1)
      			 {
      				  temp=input.split(' '); 
      			 } 
    			  
    		  }
    		  else
    		  {
    			  return "";
    		  }
    		  
    		  if(temp.length==3)
    		  {
      		    input = $filter('date')(new Date(temp[1]+","+temp[0]+","+temp[2]),'d MMMM yyyy');
    	    	return input;
    		  }
    		  else
    			{
    			  return "";
    			}  

    	    
    	  };
    });
    
    app.filter('customCurrency', function() { 

  	  // Create the return function and set the required parameter name to **input**
  	  // setup optional parameters for the currency symbol and location (left or right of the amount)
  	  return function(input) {  		  
    	 //Ajinkya : Adding comma removal - starts  
	    if (angular.isDefined(input) && input.toString().indexOf(',') > -1)
  		  {
    	   	input = input.replace(/\,/g,'');
  		  }
  		//Ajinkya : Adding comma removal - ends  		

  	    // Ensure that we are working with a number
  	    if(isNaN(input)) {
  	      return input;
  	    } else {
  	    	if(input > 0){
  	    		if(input >= 10000000)
  	  		    	input = (input/10000000).toFixed(3) + ' Crore';
  	  		    else if(input >= 100000) 
  	  		    	input = (input/100000).toFixed(3) + ' Lakhs';
  	  		    else if(input >= 1000) 
  	  		    	input = (input/1000).toFixed(3) + ' Thousand';
  	  		    else if(input >= 100) 
  			    	input = (input/100).toFixed(3) + ' Hundred';
  	    	}
  	    	else if(input < 0){
  	    		if(input <= -10000000) 
  	  		    	input = (input/10000000).toFixed(3) + ' Crore';
  	  		    else if(input <= -100000) 
  	  		    	input = (input/100000).toFixed(3) + ' Lakhs';
  	  		    else if(input <= -1000) 
  	  		    	input = (input/1000).toFixed(3) + ' Thousand';
  	  		    else if(input <= -100) 
  	  		    	input = (input/100).toFixed(3) + ' Hundred';
  	    	} else {
  	    		input = input;
  	    	}
  	    	
  		    return input;
  	    }
  	  };

  	});
    

    
    app.constant('commonConstant', {
    	mappingJSON : {
    			"frequency": {//property
    				"Monthly-CC": 12,//value
    				"Monthly-ECS": 12,//value
    				"Half-Yearly": 2,
    				"Yearly": 1,
    				"once" : 1,
    				"Monthly": 12//value
    			
    		},
		annuity: {//property
			Married:11,//value
			Single:1,//value
			Divorced:21,
			Widowed: 10
		},
	    activeProductList : ["I11","I17","I23","U98","E10","E11","E18","E19","E21","E22","ULA1","ULA4","ULA5","ULA8","ULA8_SK","T38","T44","I05","T46",
		                "T82","U96","T43","I28","I29","I30","I31","I34","I37","I40","I41","I47","I50","I53","I51","I52","I54","NeedAnalysis"
		               ],
        pasaAllowedProductList : ["UA1","ULA1","UA2","ULA5","UA5","UA6","ULA8","UA8","UA9","ULA4","UA4","UA3","ULA3","U98","U99","E10","E11","E12","E18","T46","T47"],
        
		regexConstant :{
			NUMBER_VALIDATION : /^\d+$/,
			MAX_NUMBER : /^0*(?:[0-9][0-9]?|100)$/,
			NAME_VALIDATION : /^[a-zA-Z']+(\s[a-zA-Z']+){0,3}$/,
			ALPHANUMARIC : /^[a-zA-Z0-9]+(\s[a-zA-Z0-9]+){0,3}$/,
			ALPHA_ONLY : /^[a-zA-Z ]*$/,
			EMAIL_VALIDATION : /^([a-zA-Z0-9])+([_\.]?[a-zA-Z0-9]+)?([_\.]?[a-zA-Z0-9]+)?\@([a-zA-Z0-9\-])+(\.([a-zA-Z]{2,12})){1,2}$/			
		}
    	},
    	
    	ageJson : {"I11":{"selfMinAge":18,"selfMaxAge":60,"dependantMinAge":1,"dependantMaxAge":60},
    			"I12":{"selfMinAge":25,"selfMaxAge":54,"dependantMinAge":25,"dependantMaxAge":54},
    			"I13":{"selfMinAge":35,"selfMaxAge":60,"dependantMinAge":35,"dependantMaxAge":60},
    			"I14":{"selfMinAge":20,"selfMaxAge":62,"dependantMinAge":20,"dependantMaxAge":62},
    			"I15":{"selfMinAge":18,"selfMaxAge":54,"dependantMinAge":15,"dependantMaxAge":54},
    			"I16":{"selfMinAge":18,"selfMaxAge":65,"dependantMinAge":15,"dependantMaxAge":65},
    			"I17":{"selfMinAge":18,"selfMaxAge":54,"dependantMinAge":0,"dependantMaxAge":54},
    			"I19":{"selfMinAge":25,"selfMaxAge":50,"dependantMinAge":25,"dependantMaxAge":50},
    			"I20":{"selfMinAge":35,"selfMaxAge":54,"dependantMinAge":35,"dependantMaxAge":54},
    			"I21":{"selfMinAge":35,"selfMaxAge":54,"dependantMinAge":35,"dependantMaxAge":54},
    			"I22":{"selfMinAge":35,"selfMaxAge":54,"dependantMinAge":35,"dependantMaxAge":54},
    			"I23":{"selfMinAge":18,"selfMaxAge":50,"dependantMinAge":0,"dependantMaxAge":50},
    			"I24":{"selfMinAge":20,"selfMaxAge":50,"dependantMinAge":20,"dependantMaxAge":50},
    			"I25":{"selfMinAge":20,"selfMaxAge":50,"dependantMinAge":20,"dependantMaxAge":50},
    			"I26":{"selfMinAge":20,"selfMaxAge":50,"dependantMinAge":20,"dependantMaxAge":50},
    			"U98":{"selfMinAge":18,"selfMaxAge":70,"dependantMinAge":8,"dependantMaxAge":70},
    			"E11":{"selfMinAge":18,"selfMaxAge":60,"dependantMinAge":0,"dependantMaxAge":60},
    			"E21":{"selfMinAge":18,"selfMaxAge":58,"dependantMinAge":0,"dependantMaxAge":58},
    			"ULA1":{"selfMinAge":18,"selfMaxAge":69,"dependantMinAge":0,"dependantMaxAge":69},
    			"ULA4":{"selfMinAge":18,"selfMaxAge":70,"dependantMinAge":0,"dependantMaxAge":70},
    			"ULA5":{"selfMinAge":18,"selfMaxAge":69,"dependantMinAge":0,"dependantMaxAge":69},
    			"E10":{"selfMinAge":18,"selfMaxAge":60,"dependantMinAge":0,"dependantMaxAge":60},
    			"ULA8":{"selfMinAge":20,"selfMaxAge":54,"dependantMinAge":20,"dependantMaxAge":54},
    			"E18":{"selfMinAge":18,"selfMaxAge":60,"dependantMinAge":6,"dependantMaxAge":60},
    			"T38":{"selfMinAge":18,"selfMaxAge":60,"dependantMinAge":18,"dependantMaxAge":60},
    			"T82":{"selfMinAge":18,"selfMaxAge":65,"dependantMinAge":0,"dependantMaxAge":65},
    			"T26":{"selfMinAge":20,"selfMaxAge":55,"dependantMinAge":20,"dependantMaxAge":55},
    			"U96":{"selfMinAge":35,"selfMaxAge":80,"dependantMinAge":0,"dependantMaxAge":80},
    			"I05":{"selfMinAge":45,"selfMaxAge":100,"dependantMinAge":45,"dependantMaxAge":100},
    			"E19":{"selfMinAge":18,"selfMaxAge":60,"dependantMinAge":18,"dependantMaxAge":60},
    			"I27":{"selfMinAge":18,"selfMaxAge":50,"dependantMinAge":18,"dependantMaxAge":50},
    			"T42":{"selfMinAge":18,"selfMaxAge":60,"dependantMinAge":18,"dependantMaxAge":60},
    			"T43":{"selfMinAge":18,"selfMaxAge":60,"dependantMinAge":18,"dependantMaxAge":60},
    			"I28":{"selfMinAge":18,"selfMaxAge":49,"dependantMinAge":18,"dependantMaxAge":49},
    			"I29":{"selfMinAge":18,"selfMaxAge":54,"dependantMinAge":3,"dependantMaxAge":54},
    			"I30":{"selfMinAge":18,"selfMaxAge":54,"dependantMinAge":0,"dependantMaxAge":54},
    			"I31":{"selfMinAge":18,"selfMaxAge":54,"dependantMinAge":0,"dependantMaxAge":54},
    			"I32":{"selfMinAge":25,"selfMaxAge":54,"dependantMinAge":25,"dependantMaxAge":54},
    			"I33":{"selfMinAge":25,"selfMaxAge":54,"dependantMinAge":25,"dependantMaxAge":54},
    			"I34":{"selfMinAge":20,"selfMaxAge":54,"dependantMinAge":20,"dependantMaxAge":54},
    			"I35":{"selfMinAge":20,"selfMaxAge":54,"dependantMinAge":20,"dependantMaxAge":54},
    			"I36":{"selfMinAge":20,"selfMaxAge":54,"dependantMinAge":20,"dependantMaxAge":54},
    			"ULA8_SK":{"selfMinAge":20,"selfMaxAge":54,"dependantMinAge":20,"dependantMaxAge":54},
    			"I37":{"selfMinAge":20,"selfMaxAge":49,"dependantMinAge":20,"dependantMaxAge":49},
    			"I40":{"selfMinAge":20,"selfMaxAge":49,"dependantMinAge":20,"dependantMaxAge":49},
    			"I41":{"selfMinAge":20,"selfMaxAge":49,"dependantMinAge":20,"dependantMaxAge":49},
    			"I43":{"selfMinAge":18,"selfMaxAge":54,"dependantMinAge":3,"dependantMaxAge":54},
    			"I44":{"selfMinAge":18,"selfMaxAge":54,"dependantMinAge":0,"dependantMaxAge":54},
    			"I45":{"selfMinAge":18,"selfMaxAge":54,"dependantMinAge":0,"dependantMaxAge":54},
    			"I47":{"selfMinAge":20,"selfMaxAge":54,"dependantMinAge":20,"dependantMaxAge":54},
    			"T44":{"selfMinAge":18,"selfMaxAge":65,"dependantMinAge":18,"dependantMaxAge":65},
    			"I46":{"selfMinAge":18,"selfMaxAge":54,"dependantMinAge":3,"dependantMaxAge":54},
    			"I48":{"selfMinAge":18,"selfMaxAge":54,"dependantMinAge":15,"dependantMaxAge":54},
    			"T46":{"selfMinAge":18,"selfMaxAge":60,"dependantMinAge":18,"dependantMaxAge":60},
    			"I49":{"selfMinAge":18,"selfMaxAge":65,"dependantMinAge":15,"dependantMaxAge":65},
    			"I50":{"selfMinAge":20,"selfMaxAge":54,"dependantMinAge":20,"dependantMaxAge":54},
    			"I53":{"selfMinAge":20,"selfMaxAge":65,"dependantMinAge":20,"dependantMaxAge":65},
    			"I51":{"selfMinAge":18,"selfMaxAge":65,"dependantMinAge":15,"dependantMaxAge":65},
    			"I52":{"selfMinAge":20,"selfMaxAge":58,"dependantMinAge":20,"dependantMaxAge":58},
    			"I54":{"selfMinAge":18,"selfMaxAge":50,"dependantMinAge":18,"dependantMaxAge":50},
    			"E22":{"selfMinAge":18,"selfMaxAge":60,"dependantMinAge":8,"dependantMaxAge":60},
    			"NeedAnalysis":{"selfMinAge":0,"selfMaxAge":59,"dependantMinAge":0,"dependantMaxAge":59}
    			},
    	
    	
    			ProdCode : {  // for review

    				"SavingSuraksha": "E11",
    				"WealthBuilderII": "ULA5",
    				"ELITEWEALTHII":"ULA4",
    				"Smart Life": "ULA8",
    				"ICICI PRU ASIP": "E18",
    				"GUARANTEEDWEALTHPROTECT": "U98",
    				"CashAdvantage": "E10",
    				"iProtectSmart": "T46",
    				"EasyRetirement" :"U96",
    				"ELITELIFEII" :"ULA1",
    				"EasyRetirementSP" :"U96",
    				"FuturePerfect" : "E21",
    				"SINGLEPAYGUARANTEEDRETURN" : "E22"
    			},
    			
    			ProdName : { // for product logo

    				"E11":"SavingSuraksha",
    				"E21":"ICICI Pru Future Perfect",
    				"ULA5":"WealthBuilderII",
    				"ULA4":"ELITEWEALTHII",
    				"ULA8":"Smart Life",
    				"E18":"ICICI PRU ASIP",
    				"U98":"GUARANTEEDWEALTHPROTECT",
    				"E10":"CashAdvantage",
    				"E22":"SINGLEPAYGUARANTEEDRETURN",
    				"T46":"iProtectSmart",
    				"U96":"EasyRetirement" ,
    				"ULA1":"ELITELIFEII",
    				"E19" :"AnmolBachat",
    				"I37": "Joint Life Smart Parents Aggressive",
    				"I40": "Joint Life Smart Parents Moderate",
    				"I41": "Joint Life Smart Parents Conservative",
    				"I50" : "Super Protect Solution",
    				"I17" : "Tax-Free Income Solution",
    				"I54" : "ICICI Prudential Health Guard",
    				"T38":"iCareII",
    				"T43":"Life Raksha",
    				"T82":"Loan Protect",
    				"T44":"Loan Protect Plus",
    				"ULA8_SK":"Smart Kid",
    				"I11" : "Early Cash Solution",
    				"I28":"Protect Plus Solution",
    				"I29": "Grand Parents Gifting Solution Conservative",
    				"I30": "Grand Parents Gifting Solution Moderate",
    				"I31": "Grand Parents Gifting Solution Aggressive",
    				"I51": "My Pension Fund - Retire Confident",
    				"I52": "My Pension Fund - Retire Secure",
    				"I53": "My Pension Fund - Retire Happy",
    				"I23": "Money Back Solution",
    				"I34" : "Installment Based Solution",
    				"I47" : "Installment Based Savings Solution Conservative"
    			},
    			LogoBasedOnProductCodes:{  //for product logo
    				"E11": "/digidrive/common/images/products-logo/E11.png",
    				"ULA5": "/digidrive/common/images/products-logo/ULA5.png",
    				"ULA4":"/digidrive/common/images/products-logo/ULA4.png",
    				"ULA1": "/digidrive/common/images/products-logo/ULA1.png",
    				"ULA8": "/digidrive/common/images/products-logo/ULA8.png",
    				"E18": "/digidrive/common/images/products-logo/E18.png",
    				"U98": "/digidrive/common/images/products-logo/U98.png",
    				"E10": "/digidrive/common/images/products-logo/E10.png",
    				"T46": "/digidrive/common/images/products-logo/T46.png",
    				"U96": "/digidrive/common/images/products-logo/U96.png",		
    				"E19": "/digidrive/common/images/products-logo/E19.png",	
    				"I28": "/digidrive/common/images/products-logo/I28.png",
    				"I29": "/digidrive/common/images/products-logo/I29.png",
    				"I30": "/digidrive/common/images/products-logo/I30.png",
    				"I31": "/digidrive/common/images/products-logo/I31.png",
    				"I37": "/digidrive/common/images/products-logo/I37.png",
    				"I40": "/digidrive/common/images/products-logo/I40.png",
    				"I41": "/digidrive/common/images/products-logo/I41.png",
    				"I11": "/digidrive/common/images/products-logo/I11.png",
    				"I51": "/digidrive/common/images/products-logo/I51.png",
    				"I52": "/digidrive/common/images/products-logo/I52.png",
    				"I53": "/digidrive/common/images/products-logo/I53.png",
    				"I17": "/digidrive/common/images/products-logo/I17.png",
    				"T38": "/digidrive/common/images/products-logo/T38.png",
    				"T43": "/digidrive/common/images/products-logo/T43.png",
    				"T44": "/digidrive/common/images/products-logo/T44.png",
    				"T82": "/digidrive/common/images/products-logo/T82.png",
    				"I34": "/digidrive/common/images/products-logo/I34.png",
    				"I47": "/digidrive/common/images/products-logo/I47.png",
    				"I23": "/digidrive/common/images/products-logo/I23.png",
    				"ULA8_SK": "/digidrive/common/images/products-logo/ULA8_SK.png",
    				"NeedAnalysis":"/digidrive/purchaseflow/common/images/needAnalysis.jpg"    //for need analysis pre ebi - not to show any logo
    																	// add the entry in the json only if logo is provided
    			},
    			
    			StoryCodeProductCodeMap:{//for AppForm
    			    				
    				"BH": "I20",
    				"BF": "I21",
    				"BI": "I22",
    				"BJ": "I23",
    				"BK": "I23",
    				"BN": "I24",
    				"BL": "I25",
    				"BM": "I26",
    				"BT": "I33",
    				"BU": "I32",
    				"BQ": "I29",
    				"BR": "I30",
    				"BS": "I31",
    				"BP" : "I28",
    				"CF" : "I37",
    				"CD" : "I40",
    				"CE" : "I41",
    				"CN" : "I50",
    				"T46" : "T46",
    				"T47" : "T46",
    				"T34" : "T82",
    				"T35" : "T82",
    				"T36" : "T82",
    				"T37" : "T82",
    				"U96": "U96",
    				"U97": "U96",
    				"U98": "U98",
    				"U99": "U98",
    				"UA1": "ULA1",
    				"UA2": "ULA1",
    				"UA3": "ULA4",
    				"UA4": "ULA4",
    				"UA5": "ULA5",
    				"UA6": "ULA5",
    				"E10": "E10",
    				"E11": "E11",
    				"E12": "E11",
    				"E18": "E18",
    				"E19": "E19",
    				"E20": "E19",
    				"E21": "E21",
    				"E22": "E22",
    				"T38": "T38",
    				"T39": "T38",
    				"T40": "T38",
    				"T41": "T38",
    				"T43": "T43",
    				"T44": "T44",
    				"T45": "T44",
    				"UA8_SK": "ULA8_SK",    
    				"UA9_SK": "ULA8_SK",
    				"UA8": "ULA8",    
    				"UA9": "ULA8" ,
    				"CP":"I51",
    				"CO" : "I52",
    				"CQ" : "I53",
    				"AV" : "I11",
    				"BB" : "I17",
    				"BW" : "I34",
    				"CK" : "I47",
    				"DD" : "I54"
    			},
    			
    			// to display values on header based on module
    			ValuesOnHeader:{

    				"Ebi" : {
    					"title": "CALCULATE HOW YOUR MATURITY BENEFITS CHANGE AS YOU CUSTOMISE YOUR PREMIUM",
    					"ProgressBarPerCent" : "15%",
    					"Header" :"Benefit Calculation"
    				},
    				"Review" : {
    					"title": "Review your purchase and make sure everything's right",
    					"ProgressBarPerCent" : "15%",
    					"Header" :"Review products"

    				},
    				"iAttach" :{
    					"title": "Add products to better your investment benefits",
    					"ProgressBarPerCent" : "15%",
    					"Header" :"Add Products"
    				},
    				"PreEBI" :{
    					"title": "Use smart identification to get your form prefilled",
    					"ProgressBarPerCent" : "0%",
    					"Header" :"Benefit Illustration"
    				}
    			},
    			
    			addProductListData : {	                     

    					"U98": {
    						"image":"digidrive/common/images/add-product/gwp.png",
    						"fliptext":["Guarantee on the money you invest", "Premium payment as per your comfort","Rewards of Wealth Boosters and Loyalty Additions for long term investments","Security of your loved ones in your absence"],
    						"productName":"Guaranteed Wealth Protector"
    					},
    					"E11": {
    						"image":"digidrive/common/images/add-product/savingsuraksha.png",
    						"fliptext":["Savings with the comfort of guarantee", "Premium payment as per your comfort","Security of your loved ones with wealth creation and your Life Cover"],
    						"productName":"Savings Suraksha"
    					},
    					"ULA5": {
    						"image":"digidrive/common/images/add-product/wealthbuilderII.png",
    						"fliptext":["Choice of investment strategy to suit your needs", "Easy access to your money","Rewards of Wealth Boosters and Loyalty Additions for long term investments","Security of your loved ones in your absence"],
    						"productName":"Wealth Builder II"
    					
    					},
    					"ULA4": {
    						"image":"digidrive/common/images/add-product/elitewealthII.png",
    						"fliptext":["Premium payment as per your comfort", "Customisation of  investment strategy to suit your needs","Rewards of Wealth Boosters and Loyalty Additions for long term investments","Security of your loved ones in your absence"],
    						"productName":"Elite Wealth II"
    					},
    					"E18": {
    						"image":"digidrive/common/images/add-product/asip.png",
    						"fliptext":["Growth of wealth with Guaranteed Additions", "A lump sum pay out to secure your future","Premium payment as per your comfort"],
    						"productName":"Assured Savings Insurance Plan"
    					},
    					"E10": {
    						"image":"digidrive/common/images/add-product/cashadvantage.png",
    						"fliptext":["Addition to your regular income with guaranteed pay-outs", "Security of your loved ones with wealth creation and your Life Cover","Premium payment as per your comfort"],
    						"productName":"Cash Advantage"
    					},
    					"ULA8": {
    						"image":"digidrive/common/images/add-product/smartlife.png",
    						"fliptext":["Choice of investment strategy to suit your needs", "Rewards of Wealth Boosters and Loyalty Additions for long term investments","Security of your loved ones with premium waived in your absence"],
    						"productName":"Smart Life"
    					},
    					"ULA1": {
    						"image":"digidrive/common/images/add-product/elitelifeII.png",
    						"fliptext":["Choice of investment strategy to suit your needs", "Rewards of Wealth Boosters and Loyalty Additions for long term investments","Movement of money between equity and debt funds conveniently","Security of your loved ones in your absence"],
    						"productName":"Elite Life II"
    					},
    					"U96": {
    						"image":"digidrive/common/images/add-product/easyretirement.png",
    						"fliptext":["Guarantee on the money you invest", "Pension Boosters to increase your retirement savings","Choice of annuity options as per your needs to get regular income along with the protection of Life Cover"],
    						"productName":"Easy Retirement"
    					}       

    			}
    				
    			// to display values on header based on module

    });
        
    // Util services method are available - reusable
    app.service('generalUtilityService', function(EbiValues,commonConstant){
    	this.executeFunctionByName=function(functionName, context , args ) {
    	    var args = Array.prototype.slice.call(arguments, 2);
    	    var namespaces = functionName.split(".");
    	    var func = namespaces.pop();
    	    for (var i = 0; i < namespaces.length; i++) {
    	        context = context[namespaces[i]];
    	    }
    	    return context[func].apply(context, args);
    	};
    	
    	 this.calculateAge = function(dob){    		 
 	    	var age=0;
 	    	var dateOfBirth = dob;
 			var currentDate= new Date();
 			var currentDay = currentDate.getDate();
 			var currentMonth = currentDate.getMonth();
 			var currentYear = currentDate.getFullYear();
 			var currentMonth= currentMonth+1; 
 			var dateArray = dateOfBirth.split("-");
 			var year = currentYear-dateArray[0];
 			var month = currentMonth-dateArray[1]; 
 			var day = currentDay-dateArray[2];
 			if(dateArray.length == 1){
 				dateArray = dateOfBirth.split("/");
 				year = currentYear-dateArray[2];
 	 			month = currentMonth-dateArray[0]; 
 	 			day = currentDay-dateArray[1];
 			} 			
 			if(day<0)
 			{
 				month=month-1;
 			}
 			if(month<0)
 			{
 				
 				month=month+12;
 				year=year-1;
 			}
 			if(month<6)
 			{
 				
 				age=year;
 			}
 			else
 				age=year;
 			return age;
 	    };
 	    
 	   //Venkatesh : To add INR currency comma format 
 	   this.addComma = function(value) {
       	var x=value;
 	    	x=x.toString();
 	    	var lastThree = x.substring(x.length-3);
 	    	var otherNumbers = x.substring(0,x.length-3);
 	    	if(otherNumbers != '')
 	    	    lastThree = ',' + lastThree;
 	    	var result = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;  	    	
 	    	return result;
       };
       
       this.removeComma = function(value){
       	return value.toString().replace(/\,/g,'');
       };
       
       // use for PolicyCommencementDate tag - T46, T38
       this.todaysDate = function(){
    	var today = new Date();
   		var dd = today.getDate();
   		var mm = today.getMonth() + 1; // January is 0!
   		var yyyy = today.getFullYear();
   		if (dd < 10) {
   			dd = '0' + dd;
   		}
   		if (mm < 10) {
   			mm = '0' + mm;
   		}
   		today = yyyy + '-' + mm + '-' + dd;
   		return today.toString();
       };
       
       this.pushError = function(errorElement){    	  
 	    	if(EbiValues.EbiInputErrors.indexOf(errorElement) == -1){
 	    		EbiValues.EbiInputErrors.push(errorElement);
				}
 	    };
 	    
 	    this.removeError = function(errorElement){
 	    	if(EbiValues.EbiInputErrors.indexOf(errorElement) != -1){
 	    		EbiValues.EbiInputErrors.splice(EbiValues.EbiInputErrors.indexOf(errorElement),1);
			}
 	    };
 	    
 	    this.pushErrorMsg = function(attr){
 	    	 EbiValues.ErrorMsg[attr.id] = "Please enter "+ attr.title ;
 	    };
 	    
 	 //Adds Invalid Class to the Element
 	   this.addInvalidClass = function(currentElement,errorMsgElement){
 	   	currentElement.addClass('invalid1');
 	   	errorMsgElement.css('visibility','visible'); 	   	
 	   };

 	   //Removes Invalid Class from the Element
 	   this.removeInvalidClass = function(currentElement,errorMsgElement){
 	   	currentElement.removeClass('invalid1');
 	   	errorMsgElement.css('visibility','hidden');
 	   };
 	   
 	   //backdation logic for financial years
 	  this.getFinancialBackdation= function(){
 			var today=new Date();	
 			var month=(today.getMonth())+1;
 			var days;
 			if(month<4)
 				{
 				 days=new Date(""+((today.getFullYear())-1)+"-04-01");
 				}
 			else
 				{
 				days=new Date(""+(today.getFullYear())+"-04-01");
 				}
 			var diff=Math.round((today-days)/(1000*60*60*24));
 			var backDate = new Date();
 			backDate.setDate(backDate.getDate() - diff);
 			var dd = backDate.getDate();
 	   		var mm = backDate.getMonth() + 1; // January is 0!
 	   		var yyyy = backDate.getFullYear();
 	   		if (dd < 10) {
 	   			dd = '0' + dd;
 	   		}
 	   		if (mm < 10) {
 	   			mm = '0' + mm;
 	   		}
 	    	backDate = yyyy + '-' + mm + '-' + dd;
 	   		return backDate.toString();
 		};
 		this.setValuesOnHeader=function(module)
 		{
 			// to display title name, progressbarpercentage and module name  on header 
 			var progressBarElem = angular.element(document.querySelector('#progressBar'));
 			var completionPercentElem = angular.element(document.querySelector('#completionPercent'));
 			progressBarElem.css("width",commonConstant.ValuesOnHeader[module].ProgressBarPerCent);
 			completionPercentElem.html(commonConstant.ValuesOnHeader[module].ProgressBarPerCent);	
 			$('#page-header-title-span').text(commonConstant.ValuesOnHeader[module].title);
 			$("#moduleHeader").text(commonConstant.ValuesOnHeader[module].Header);
 		// to display title name, progressbarpercentage and module name  on header 
 		};
    });
    
    // Directive to convert to Capital Case
    app.directive('inputVisibilityFilter',[function() {
   return {
     require: 'ngModel',
     link: function(scope, element, attrs, modelCtrl) {
       var capitalize = function(inputValue) {
         if (inputValue == undefined) inputValue = '';
         var capitalized = inputValue.toUpperCase();
         if (capitalized !== inputValue) {
           modelCtrl.$setViewValue(capitalized);
           modelCtrl.$render();
         }
         return capitalized;
       }
       modelCtrl.$parsers.push(capitalize);
       capitalize(scope[attrs.ngModel]); // capitalize initial value
     }
   }}
 ]);
        
	  
    /*START - venkatesh : directive for textfield min max - use directive ng-min-max = min,max */
    app.directive('ngMinMax', ['generalUtilityService', function(Utility){    	
  	  return{
  	    require:'ngModel',
  	    link: function(scope, elem, attrs, ctrl){
  	    	 attrs.$observe('ngMinMax', function(currentMinMax){    	    	        
  	    		 	currentMinMax = currentMinMax.split(",");
  	    		 	return checkMinMax(ctrl.$viewValue,currentMinMax);
  	    	      });
  	    	 
  	      ctrl.$parsers.unshift(checkMinMax);
  	      ctrl.$formatters.unshift(checkMinMax);    	      
  	   
  	    function checkMinMax(viewValue,MinMax){  
  	    	//changed
  	    	if(angular.isDefined(viewValue) && viewValue!= ""){
  	    		viewValue = viewValue.toString().search(',')!= -1? Utility.removeComma(viewValue) : viewValue;
  	  	    	viewValue = +viewValue;
  	    	}
  	    	
  	    	if(angular.isUndefined(MinMax)){
	    	    	var currentMinMax = attrs.ngMinMax;
	    	    	MinMax = currentMinMax.split(",");
  	    	}
  	    	scope.errDiv = angular.element(document.querySelector('#'+attrs.id+'_errMsg'));
  	    	var min = +MinMax[0], max= +MinMax[1];
  	    	var nonRupee = MinMax.length > 2 && MinMax[2] !="" ? MinMax[2] : "INR";
  	    	if(min != 0 && max != 0){
	    	    	if (isNaN(viewValue) || viewValue == "" || viewValue == undefined) {
		    	    	scope.errDiv.text(attrs.title+" can't be left blank");
		    	    	Utility.pushError(attrs.id);
		    	    	Utility.addInvalidClass(elem,scope.errDiv);		    	    	
		    	    	ctrl.$setValidity('ngMinMax', false);
	    	    	} else if (viewValue < min || viewValue > max) {
	    	    		if(nonRupee == "INR"){
	    	    			scope.errDiv.text(attrs.title+" cannot be less than " +'₹'+ " " + Utility.addComma(min) +" or greater than "+ '₹' + " " + Utility.addComma(max) );							
	    	    		}else{
	    	    			scope.errDiv.text(attrs.title+" cannot be less than "+ Utility.addComma(min) + " " + nonRupee +" or greater than "+ Utility.addComma(max) + " " + nonRupee );
	    	    		}
	    	    		Utility.pushError(attrs.id);
		  				Utility.addInvalidClass(elem,scope.errDiv);	
		  				ctrl.$setValidity('ngMinMax', false);
	    	    	} else {
		  				scope.errDiv.text("");
		  				Utility.removeError(attrs.id);
		  				Utility.removeInvalidClass(elem,scope.errDiv);	
		  				ctrl.$setValidity('ngMinMax', true);
	    	    	}
  	    	}else{
  	    		scope.errDiv.text("");
  				Utility.removeError(attrs.id);
  				ctrl.$setValidity('ngMinMax', true);
  	    	}
  	    	return viewValue;
  	    }
  	    }
  	  };  	  
  	}]);
    
    /*END - venkatesh : directive for textfield min max */   
    
    /*START - venkatesh regex pattern validation - app constant used to maintain constant regex pattern */
    app.directive('allowPattern',['commonConstant',function(commonConstant){    	
        return {
            restrict: "A",
            require:'ngModel',
            compile: function(tElement, tAttrs) {
                return function(scope, element, attrs,ctrl) {
                	// handle key events
                    element.bind("keypress", function(event) {                   	
                    	
                        var keyCode = event.which || event.keyCode; // safely get the keyCode pressed from the event.
                        var keyCodeChar = String.fromCharCode(keyCode); // determine the char from the keyCode.
              
              // If the keyCode char does not match the allowed Regex Pattern, then don't allow the input into the field.
                        //changed
                       var withoutComma = (element.val()).indexOf(',')== -1 ? element.val() :(element.val()).replace(/\,/g,'');
                       var value = withoutComma+keyCodeChar;
                       // Regex pattern from constant
                       var regex = commonConstant.mappingJSON.regexConstant[attrs.allowPattern];
                        if((!regex.test(keyCodeChar) || !regex.test(value)) && keyCodeChar.charCodeAt(0) > 32) {
                        	event.returnValue = false;
                            if(event.preventDefault) {
                            	event.preventDefault();
                            }
                        }
                        

    					var keyCode = event.which;
    			        var keyCodeChar = String.fromCharCode(keyCode);
    			        if(allowBasicKeys.indexOf(keyCode) != -1){
     			          /* allow basic keys like backspace,space,delete */
    			          }else if(!keyCodeChar.match(regex)){
    			                event.preventDefault();
    			          }      				
                    });
                    
                    element.bind("blur", function(event) {
                    	if(element.val().trim() == "" && attrs.allowPattern == "MAX_NUMBER"){
                    		ctrl.$setViewValue("0");	
                    		ctrl.$render();
            		   	 	//scope.$apply();
                    	}
                    });
                    
                    /*element.bind("keyup", function(event) {
                    	if(attrs.allowPattern == "NUMBER_VALIDATION"){
                    		var value = element.val().trim();
                    		element.val(value);
                    		ctrl.$setViewValue(value);	
                    		ctrl.$render();
                    	}
                    });*/
                };
            }
        };
     }]);    
    /*END - venkatesh : directive for regex validation */    
    
    /* START - venkatesh : common validation directive */ 
    /**
     * validation factory 
     * methods and validation logic for commaValidation directive
     * 
     */
    app.factory('validationUtils',['generalUtilityService', function (Utility) {	  
	    return {
	      isEmpty: function (input,elem,attrs,errDiv) {
	    	  if(input=="" || input== "0"){
	    		  Utility.pushError(attrs.id);	    		  
	    		  Utility.pushErrorMsg(attrs);	
	    		 return true;
	    	  }else{
	    		  Utility.removeError(attrs.id);
	    		  errDiv.text("");
	    		  Utility.removeInvalidClass(elem,errDiv);
	    		  return false;
	    	  }
	      },
	      
	      spouseNameCheck : function(input,elem,attrs,errDiv){
	    	var alphabet=/^[a-zA-Z']+(\s[a-zA-Z']+){0,3}$/;
	    	if(attrs.isShow == "true"){
	  		if(input.length>=1 && input != "" && input.charAt(0)!=" " && input.charAt(0)!="." && ( input.charAt(0)!=" " || input.charAt(1)!=" ") &&  (input.charAt(1)!=" " || input.charAt(2)!="") && (input.charAt(1)!=" " || input.charAt(2)!=" ") )
	  			
	  		{
	  		if(!alphabet.test(input))
	  		{
	  			Utility.pushError(attrs.id);	    		  
	    		Utility.pushErrorMsg(attrs);
	  			return false;
	  		}
	  		else
	  		{
			Utility.removeError(attrs.id);
	    		errDiv.text("");
	    		Utility.removeInvalidClass(elem,errDiv);	  			
	  			return true;
	  		}
	  		}
	  		else{
	  			Utility.pushError(attrs.id);	    		  
	    		Utility.pushErrorMsg(attrs);
	  			return false;
	  		}
	    	}
	      },
	      
	      PremiumRounding : function(input,elem,attrs,multiOf){
	    	  var returnData={};	    	  
	    	  input = input.toString().trim() == "" ? 0 : input;
	    	  input = parseInt(Utility.removeComma(input));
	    	  var minMax = (attrs.ngMinMax).split(",");
	    	  if (!(input < parseInt(minMax[0]) || input > parseInt(minMax[1]))) {
			  if(multiOf == 100){
				  var modulo=input%100;
				  if(modulo<50){             //if modulo is <50, we round it to lower value
				  input=input-modulo;				  
				  }else{					//if modulo is > 50, we round it to higher value
				  modulo=100-modulo;
				  input=input+modulo;
				  }
				  returnData["value"] = Utility.addComma(input);  
				return returnData;
				}
			  else if(multiOf == 1000){
			  if(input%1000 !=0){ 			//if the premium entered is a multiple of 1000
				  var modulo=input%1000;
				  if(modulo<500){			//if modulo is <500, we round it to lower value
					  input=input-modulo;
					  }else{				//if modulo is > 500, we round it to higher value
					  modulo=1000-modulo;
					  input=input+modulo;
					  }
				  }			  
			  returnData["value"] = Utility.addComma(input);
			  return returnData;
			  }
	    	  }else{
				  returnData["value"] = Utility.addComma(input);
				  return returnData;
			  }
	      }
	    };
  }]);
    
  /**
   * common directive for basic validation 
   */
    app.directive('commmonValidation', ['validationUtils', function (validationUtils) {
	 return {
		 require:'ngModel',
	  	    link: function(scope, elem, attrs, ctrl){	
	  	    	ctrl.$parsers.push(function (value) {
	  	    		if(attrs.commmonValidation != ""){
	  	    			scope.errDiv = angular.element(document.querySelector('#'+attrs.id+'_errMsg'));
	  	              if(validationUtils[attrs.commmonValidation](value,elem,attrs,scope.errDiv)) {	  	            	
	  	                ctrl.$setValidity('commmonValidation', false);
	  	              }else{	  	            
						ctrl.$setValidity('commmonValidation', true);
	  	              }
	  	            return value;
	  	    		}
	  	          });
	  	    	
	  	    	ctrl.$formatters.push(function(value){
	  	    		if(attrs.commmonValidation != ""){
	  	    			
	  	    			scope.errDiv = angular.element(document.querySelector('#'+attrs.id+'_errMsg'));
	  	    		 if (validationUtils[attrs.commmonValidation](value,elem,attrs,scope.errDiv)) {
		  	                ctrl.$setValidity('commmonValidation', false);
		  	              }else{	  	            
		  	            ctrl.$setValidity('commmonValidation', true);
		  	              }		  	            
	  	    		}
	  	    		return value;
	            });	  	    	
	  	    }
	 };
  }]);    
    /* END - venkatesh : common validation directive */ 
    
    app.directive('inputParser', ['validationUtils','generalUtilityService', function (UtilityFac,generalUtilityService) {
   	 return {
   		 require:'ngModel',
   	  	    link: function(scope, elem, attrs, ctrl){
   	  	   var inputObj = eval('(' + attrs.inputParser + ')');	
   	  	   attrs.$observe('inputParser', function(newValue){    	    	        
   	  		   	inputObj = eval('(' + newValue + ')');
	    	      });
   	  	    	
   	  	  // var inputObj = eval('(' + attrs.inputParser + ')');
   	  	   if(angular.isDefined(inputObj.rounding) && inputObj.rounding.length > 0 && inputObj.rounding.split(",")[3] == "true"){
   	  		if(inputObj.rounding != ""){
	   	  	    var inputData = (inputObj.rounding).split(",");
	   	  	    if(ctrl.$viewValue!= ''){
	   	  	   elem.bind(inputData[1], function(event) {		   	  		   
		   	  		var returnData = UtilityFac[inputData[0]](ctrl.$viewValue,elem,attrs,+inputData[2]);
		   	  		var value = returnData.value == 0 ? "" : returnData.value;
			   	  	ctrl.$setViewValue(value);		   	  		
			   	  	ctrl.$render();
		           });
	   	  	    }
			   }
   	  	   }
   	  	   
   	  	   if(angular.isDefined(inputObj.modelEmpty) && inputObj.modelEmpty.length > 0){
   	  		elem.bind(inputObj.modelEmpty, function(event) {
		   	  	ctrl.$setViewValue("");
		   	  	ctrl.$render();
		   	 	//scope.$apply();
	           });
   	  	   }
   	  	   
   	  	   if(angular.isDefined(inputObj.maxLength) && inputObj.maxLength.length > 0){   	  		   
   	  		elem.bind('keypress', function(event) {
   	  		if (event.which < 0x20) {
  	             // e.which < 0x20, then it's not a printable character
  	             // e.which === 0 - Not a character
  	             return;     // Do nothing
  	         }
	   	  	if(this.value.length == inputObj.maxLength) {
	   	  		event.preventDefault();
		      }
	           });   	  		
   	  	   }
   	  	   
   	  	   if(angular.isDefined(inputObj.leadingZero) && inputObj.leadingZero){
   	  		elem.bind('keyup keypress',function(event){
				if(elem.val != null && elem.val != undefined && elem.val != ""){
					var leadingzero=new RegExp(/^[0]+/g);
					if(leadingzero.test(generalUtilityService.removeComma(elem.val()))){					
						var value = elem.val().replace(/^[0,]+/g,'');						
						elem.val(value);
					}
				}
			
		}); 
   	  	   }
   	  	   
	  	    	ctrl.$formatters.push(function(value){	  	    		
	  	    		if(angular.isDefined(inputObj.rounding) && inputObj.rounding != "" && value!= '' && inputObj.rounding.split(",")[3] == "true"){
	  	    			var inputData = (inputObj.rounding).split(",");
	  	    			var returnData = UtilityFac[inputData[0]](value,elem,attrs,+inputData[2]);
	  	    			value = returnData.value;	  	    			
	  	    		}
	  	    		ctrl.$setViewValue(value);
	  	    		ctrl.$render();
	  	    		return value;
	            });	
	  	    	
	  	    	/*ctrl.$parsers.push(function(value) {
	  	    		
	  	    	    return value;
	  	    	  });*/
	  	    }
   	 };
     }]);  
    
    
    app.directive('commaDirective',['generalUtilityService', function (util) {
    return {
        restrict: 'A',
        terminal: true,
        require: "?ngModel",
        link: function (scope, element, attrs, ngModel) {
        	attrs.$observe('commaDirective', function(newvalue){    	    	        
	    		return appendCommas(ngModel.$viewValue);
	    	      });
        	
        	ngModel.$parsers.push(appendCommas);
        	
        	function appendCommas(viewValue) {
        		if(viewValue!=null)
        		{
            	 var appended = viewValue.toString().indexOf(',')== -1?util.addComma(viewValue) : util.addComma(util.removeComma(viewValue));
                 element.val(appended);
                 return util.removeComma(element.val());
        		}
        	};
        }
    };
}]);
  
	app.filter('words', function() {
		  function isInteger(x) {
		        return x % 1 === 0;
		    }		  
		  return function(value) {
		    if (value && isInteger(value)){
		    	return convertNumberToWords(value);
		    }
		      
		    	 
		    if (value!=null && value!=undefined && value.toString().indexOf(',') > -1){
		    	value = value.replace(/\,/g,'');
		    	 return convertNumberToWords(value);
		    }
		    
		    if(value!=null && value!=undefined && value.toString() == "0"){
		    	return convertNumberToWords(value);
		    }
		    
		    return value;
		  };

		});
	
	//START - venkatesh : currency filter - indian format with decimal and symbol
	 app.filter('INRCurrency', function () {
	        return function (amount, showDecimals, decimalLenght, symbol) {	        	
	            if (angular.isUndefined(amount) || amount.length <= 0) {
	                return null;
	            }
	            
	            //for Not a Number case : 'string' data return same string back
	            if(isNaN(amount)){
	            	return amount;
	            }

	            var afterPoint = '';
	            amount+= "";
	            //alert(typeof amount);
	            if (showDecimals && amount.indexOf('.') > 0) {
	            	amount = parseFloat(amount);
	            	amount = amount.toFixed(decimalLenght);
	                afterPoint = amount.substring(amount.indexOf('.'), amount.length);
	            }

	            amount = Math.floor(amount);
	            amount = amount.toString();
	            var lastThree = amount.substring(amount.length - 3);
	            var otherNumbers = amount.substring(0, amount.length - 3);
	            if (otherNumbers != '')
	                lastThree = ',' + lastThree;
	            var formattedAmount = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + afterPoint;
	            
	            return formattedAmount;

	        };
	    });
	//END - currency Filter
	 
		function convertNumberToWords(amount) { 
		    var words = new Array();
		     words[0] = '';
		    words[1] = 'One';
		    words[2] = 'Two';
		    words[3] = 'Three';
		    words[4] = 'Four';
		    words[5] = 'Five';
		    words[6] = 'Six';
		    words[7] = 'Seven';
		    words[8] = 'Eight';
		    words[9] = 'Nine';
		    words[10] = 'Ten';
		    words[11] = 'Eleven';
		    words[12] = 'Twelve';
		    words[13] = 'Thirteen';
		    words[14] = 'Fourteen';
		    words[15] = 'Fifteen';
		    words[16] = 'Sixteen';
		    words[17] = 'Seventeen';
		    words[18] = 'Eighteen';
		    words[19] = 'Nineteen';
		    words[20] = 'Twenty';
		    words[30] = 'Thirty';
		    words[40] = 'Forty';
		    words[50] = 'Fifty';
		    words[60] = 'Sixty';
		    words[70] = 'Seventy';
		    words[80] = 'Eighty';
		    words[90] = 'Ninety'; 
		    amount = amount.toString();
		    var atemp = amount.split(".");
		    var number = atemp[0].split(",").join("");
		    var n_length = number.length;
		    var words_string = "";
		    if (n_length <= 11) {
		        var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
		        var received_n_array = new Array();
		        for (var i = 0; i < n_length; i++) {
		            received_n_array[i] = number.substr(i, 1);
		        }
		        for (var i = 11 - n_length, j = 0; i < 11; i++, j++) {
		            n_array[i] = received_n_array[j];
		        }
		        for (var i = 0, j = 1; i < 11; i++, j++) {
		            if (i == 2 || i == 4 || i == 6 || i == 9) {
		                if (n_array[i] == 1) {
		                    n_array[j] = 10 + parseInt(n_array[j]);
		                    n_array[i] = 0;
		                }
		            }
		        }
		        var value = "";
		        for (var i = 0; i < 11; i++) {
		            if (i == 2 || i == 4 || i == 6 || i == 9) {
		                value = n_array[i] * 10;
		            } else {
		                value = n_array[i];
		            }
		            if (value != 0) {
		                words_string += words[value] + " ";
		            }
		            if ((i == 0 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
		                words_string += "Thousand ";
		            }
		            if ((i == 1 && value != 0) || (i == 1 && value != 0 && n_array[i + 1] == 0)) {
		                words_string += "Hundred ";
		            }
		            if ((i == 3 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0) || (i == 2 && value != 0 && n_array[i + 1] == 0) || (i == 1 && value != 0 && n_array[i + 1] == 0)) {
		                words_string += "Crore ";
		            }
		            if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
		                words_string += "Lakh ";
		            }
		            if ((i == 7 && value != 0) || (i == 6 && value != 0 && n_array[i + 1] == 0)) {
		                words_string += "Thousand ";
		            }
		            if (i == 8 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
		                words_string += "Hundred ";
		            } else if (i == 8 && value != 0) {
		                words_string += "Hundred ";
		            }
		        }
		        words_string = words_string.split("  ").join(" ");
		    }
		    //return (words_string+" Only");
		    
		    if(amount != 0)
		    {
		    	return (words_string+"Only");
		    }
		    else if(amount == 0){
		    	return "Zero Only";
		    }else{
		    	return words_string;
		    }
		}
		
		 //Added by Sudha Suman for INR Currency with paise to words starts
		app.filter('wordsDecimal', function() {
				  function isInteger(x) {
				        return x % 1 === 0;
				    }		  
				  return function(value) {
				    if (value && isInteger(value)){
				    	return convertNumberWithDecimalToWords(value);
				    }
				      
				    	 
				    if (value.toString().indexOf(',') > -1){
				    	value = value.replace(/\,/g,'');
				    	 return convertNumberWithDecimalToWords(value);
				    }
				    
				    if(value.toString() == "0"){
				    	return convertNumberWithDecimalToWords(value);
				    }
				    
				    return value;
				  };

				});
			
			function convertNumberWithDecimalToWords(amount) { 
			    var words = new Array();
			     words[0] = '';
			    words[1] = 'One';
			    words[2] = 'Two';
			    words[3] = 'Three';
			    words[4] = 'Four';
			    words[5] = 'Five';
			    words[6] = 'Six';
			    words[7] = 'Seven';
			    words[8] = 'Eight';
			    words[9] = 'Nine';
			    words[10] = 'Ten';
			    words[11] = 'Eleven';
			    words[12] = 'Twelve';
			    words[13] = 'Thirteen';
			    words[14] = 'Fourteen';
			    words[15] = 'Fifteen';
			    words[16] = 'Sixteen';
			    words[17] = 'Seventeen';
			    words[18] = 'Eighteen';
			    words[19] = 'Nineteen';
			    words[20] = 'Twenty';
			    words[30] = 'Thirty';
			    words[40] = 'Forty';
			    words[50] = 'Fifty';
			    words[60] = 'Sixty';
			    words[70] = 'Seventy';
			    words[80] = 'Eighty';
			    words[90] = 'Ninety'; 
			    amount = amount.toString();
			    var atemp = amount.split(".");
			    var number = atemp[0].split(",").join("");
			    var n_length = number.length;
			    var words_string = "";
			    if (n_length <= 11) {
			        var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			        var received_n_array = new Array();
			        for (var i = 0; i < n_length; i++) {
			            received_n_array[i] = number.substr(i, 1);
			        }
			        for (var i = 11 - n_length, j = 0; i < 11; i++, j++) {
			            n_array[i] = received_n_array[j];
			        }
			        for (var i = 0, j = 1; i < 11; i++, j++) {
			            if (i == 2 || i == 4 || i == 6 || i == 9) {
			                if (n_array[i] == 1) {
			                    n_array[j] = 10 + parseInt(n_array[j]);
			                    n_array[i] = 0;
			                }
			            }
			        }
			        var value = "";
			        for (var i = 0; i < 11; i++) {
			            if (i == 2 || i == 4 || i == 6 || i == 9) {
			                value = n_array[i] * 10;
			            } else {
			                value = n_array[i];
			            }
			            if (value != 0) {
			                words_string += words[value] + " ";
			            }
			            if ((i == 0 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
			                words_string += "Thousand ";
			            }
			            if ((i == 1 && value != 0) || (i == 1 && value != 0 && n_array[i + 1] == 0)) {
			                words_string += "Hundred ";
			            }
			            if ((i == 3 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0) || (i == 2 && value != 0 && n_array[i + 1] == 0) || (i == 1 && value != 0 && n_array[i + 1] == 0)) {
			                words_string += "Crore ";
			            }
			            if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
			                words_string += "Lakh ";
			            }
			            if ((i == 7 && value != 0) || (i == 6 && value != 0 && n_array[i + 1] == 0)) {
			                words_string += "Thousand ";
			            }
			            if (i == 8 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
			                words_string += "Hundred ";
			            } else if (i == 8 && value != 0) {
			                words_string += "Hundred ";
			            }
			        }
			        words_string = words_string.split("  ").join(" ");
			    }
			    //return (words_string+" Only");
			    
			    //Added by Sudha Suman for Decimal part
			    var dec_words_string = "";
			    if(atemp[1] != null && atemp[1] != undefined)
			    {
			    var dec_number = atemp[1].split(",").join("");
		    	var dec_n_length = (dec_number != null) ? dec_number.length : 0;
			    if (dec_n_length != 0 && dec_n_length <= 2) {
			    	dec_words_string = " And ";
			        var received_dec_n_array = new Array();
			        for (var i = 0; i < dec_n_length; i++) {
			            received_dec_n_array[i] = dec_number.substr(i, 1);
			        }
			        
			        if(dec_n_length == 2)
			        {
			        	var tenth = received_dec_n_array[0];
			        	var unit = received_dec_n_array[1];
				        if(!(tenth == 0 && unit == 0))
				        {
				        	if(tenth == 0)
				        	{
				        		dec_words_string += words[unit];
				        	}
				        	else
				        	{
				        		if(tenth == 1)
				        		{
				        			dec_words_string += words[dec_number];
				        		}
				        		else if(unit == 0)
				        		{
				        			dec_words_string += words[tenth*10];
				        		}
				        		else
				        		{
				        			dec_words_string += words[tenth*10] +" "+ words[unit];
				        		}
				        	}
				        }
			        }
			        else if(dec_n_length == 1)
			        {
			 			var tenth = received_dec_n_array[0];
			        	dec_words_string += words[tenth*10];
			        }
			        dec_words_string += " Paise ";
			        dec_words_string = dec_words_string.split("  ").join(" ");
			    }
			    }
				  
			    if(amount != 0)
			    {
			    	return (words_string+dec_words_string+"Only");
			    }
			    else if(amount == 0){
			    	return "Zero Only";
			    }else{
			    	return words_string+dec_words_string;
			    }
			}
			//Added by Sudha Suman for INR Currency with paise to words ends

		app.filter('capitalize', function() {
		    return function(input, all) {
		      var reg = (all) ? /([^\W_]+[^\s-]*) */g : /([^\W_]+[^\s-]*)/;
		      return (!!input) ? input.replace(reg, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();}) : '';
		    }
		});
		  
		/*Directive for onready function - Added by Kaushik - START*/
		app.directive( 'elemReady', function( $parse ) {
		   return {
		       restrict: 'A',
		       link: function( $scope, elem, attrs ) {    
		          elem.ready(function(){
		            $scope.$apply(function(){
		                var func = $parse(attrs.elemReady);
		                func($scope);
		            });
		          });
		       }
		    }
		});
		/*Directive for onready function - Added by Kaushik - END*/
		
		/*Directive for scroll pane auto reinitialise function - Added by Kaushik - START*/
		app.directive('scrollpane', function() {
	        return {
	            restrict: 'A',
	            link: function(scope, elem, attr) {
	            	if ($(elem).text() != '') {
	        			$(elem).jScrollPane({
	        				autoReinitialise: true
	        			});
	        		}
	            }
	        };
	    });
		/*Directive for scroll pane auto reinitialise function - Added by Kaushik - END*/
		
		app.directive('plus', function() {
	        return {
	            restrict: 'C',
	            link: function(scope, elem, attr) {
	            	$(elem).click(function(){
	            		  if($(this).text() == '+' ){
	            	 		 	$(this).text("-");
	            	 	        $(this).parent().parent().next(".showDiv").show();
	            	 	}else {
	            			  $(this).text("+");
	            			  $(this).parent().parent().next(".showDiv").hide();
	            		  }
	            		 
	            	    }); 
	            }
	        };
	    });
		
		/*Directive for lazy loading of JS function - Added by Gajanan - START*/
		 app.directive("includeScript", function() {
				return {
					restrict : "EA",
					link : function(scope, element, attrs) {
						element.empty();
						var scriptTag = angular.element(document.createElement("script"));
						scriptTag.attr("src", attrs.scriptname);
						element.append(scriptTag);
					}
				};
			});
		 /*Directive for lazy loading of JS function - Added by Gajanan - End*/

		//Directive for SmartQuote -- Mohini		
			app.directive('prcntActive', function(){
				return{
					restrict: 'A',
					  link: function(scope, elem, attr) {
						  $('.prcnt-list').click(function(){
							   $(this).parent('li').siblings().removeClass('active');
				    		    $(this).parent('li').addClass('active');
				    		    var id1 = $(this).attr('id');
				    		    if (id1 == '10_prcnt' || id1 == '12_prcnt' || id1 == '15_prcnt') {
				    		        $('.footer').hide();
				    		        $('.cash-head, .secondary-head').fadeOut(100);
				    		        $('.extra-points').css('display', 'none');
				    		        $('main.content').addClass('no-header');
				    		        $('.close').fadeIn(50);
				    		    };
				    		   
				    		}); 
						  
						  $('.header-tital .close').click(function() {
							    $('.footer').show();
							    $('.cash-head, .secondary-head').fadeIn(100);
							    $('.extra-points').css('display', 'block');
							    $('.close').fadeOut(50);
							    $('main.content').removeClass('no-header');
							});
						  
					  }
				};
				
			});
			
			/*Added by Kaushik for setting focus on specified field - START*/
			app.directive('autoFocus', function() {
			    return {
			        restrict: 'A',
			        link: function(_scope, _element,attrs) {
			        	var setFocus = attrs.autoFocus;
			        	if(setFocus=="true"){
//				            $timeout(function(){
			            		_element[0].focus();
//				            }, 0);
			        	}
			        }
			    };
			});
			
			/*Added by Kaushik for setting focus on specified field - END*/
			
			/* Generic select2 directive for static dropdowns - Apply on select tag as select2=true/false*/
			app.directive('select2', function() {
			    return {
			        restrict: 'A',
			        link: function(_scope,_element,attrs) {			        	
			        	_element.ready(function(){
			        	var addSelect2 = attrs.select2;
			        	if(addSelect2=="true"){			        		
			        		$(_element[0]).select2();			        	
			        		}
			        	});
			        }
			    };
			});
			/*Generic select2 directive for static dropdowns - END*/
			
			app.directive('urlBind',function(){
				return{
					restrict: 'A',
					link: function(scope, element, attr){
						if(attr.urlBind != ""){
							var url = attr.urlBind;
							$.ajax({
							    type: "GET",
							    url: url
							})
							    .done(function(data){
							    	element.append($(data).find("div").text());
							    	//$rootScope.content = $sce.getTrustedHtml($sce.trustAsHtml(data));
							    });
							
						}
						}
				};
			});
			
			app.directive('callExternalJsFunctions',function(){//for calling 3rd party js functions
				return{
					restrict:'A',
					link:function(scope, element, attr){
						try{
							scope.showClickToCall();
						}
						catch(e) {}
					}
				};
			});
			
			app.directive('body',function(){
				return{
					restrict: 'E',
					link: function(scope, element, attr){
						 element.on('cut copy paste contextmenu', function (event) {
				              event.preventDefault();
				            });
					}
				};
			});
			
			app.directive('select2element',function(){
				return{
					restrict: 'A',
					link: function(scope, element, attr){
						$(element).select2();
					}
				};
			});
			
		    app.directive('loginToggle', function() {
		        return {
		            restrict: 'A',
		            link: function(scope, elem, attr) {
		                $(elem).click(function(){
		                    $('.showDetails').toggle();
		                });
		            }
		        };
		    });
		    
		   
		    app.directive('ngEnter', function () { //a directive to 'enter key press' in elements with the "ng-enter" attribute

		        return function (scope, element, attrs) {

		            element.bind("keydown keypress", function (event) {
		                if (event.which === 13) {
		                    scope.$apply(function () {
		                        scope.$eval(attrs.ngEnter);
		                    });

		                    event.preventDefault();
		                }
		            });
		        };
		    })
		 
}(angular));


