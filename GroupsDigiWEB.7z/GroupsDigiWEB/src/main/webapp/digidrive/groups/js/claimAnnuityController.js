var app = angular.module('groupApp', ['ajaxUtil','uiValidations','ui.materialize','groupCommonUtil','validationService']);

app.controller('claimRequestCtrl',['$scope','$rootScope','$location','ajaxHttpFactory','$window','csrDocUploadFactory','validateFieldService','$filter','$http', function($scope,$rootScope,$location,ajaxHttpFactory,$window,csrDocUploadFactory,validateFieldService,$filter,$http){

	$rootScope.preloaderCheck=false;
	$scope.claimAnnuity={};
	$scope.claimAnnuity.beneficiary =[];	
	$scope.claimAnnuity.spouse={};
    $scope.errorArray=[];
    $scope.spouse=[];
    $scope.modalErrorArray=[];
    $scope.showsurvivour=false;
   // $scope.showfields=false;
    $scope.showbeneficiary=false;
    $scope.showdob=false;
    $scope.showdobbeneficiary=false;
    $scope.Beneficiary=[];
    $scope.annuityOpt=[];    
    $scope.responseData=[];
    $scope.onloadData=[];
    $scope.newresponseData={};
    $scope.benCount=0;
    $scope.eachBeneficiary = {};
    $scope.deleteId='';
    $scope.actions="";
    $scope.functionalityId="";
    $scope.uploadArray = {};
    $scope.claimAnnuity.panUploadFileList = [];
    $scope.claimAnnuity.dobUploadFileList = [];
    $scope.claimAnnuity.benDobUploadFileList = [];
    $scope.claimAnnuity.ageProofUploadFileList = [];
   $scope.disableField=false;
    
    $scope.uploadArray.panUpload = "";
    $scope.uploadArray.dobUpload = "";
    $scope.uploadArray.benDobUpload = "";
    $scope.uploadArray.ageProofUpload = "";
   // $scope.policynumber="";
    $scope.disabled=[];
    $scope.downloadShow="";
    $scope.downloadTab=false;
    $scope.claimAnnuityDisplay=false;
    
    
	var onload = function () { 		

	    
		return ajaxHttpFactory.getJsonData("onload",$location.absUrl())
		.then(function(response) {
			if(ajaxHttpFactory.handleIPruException(response.data, "errorMessage-popup", "exceptionAlert")){
				$scope.message = "No Data Found";
			}
		 
			if (response != null && response != "null") {
				$scope.responseData = response.data.claimAnnuityOptionList;
				$scope.onloadData=response.data.claimAnnuityWegaList;
				for(var i=0;i<$scope.responseData.length;i++){
					$scope.annuityOpt.push($scope.responseData[i].optionName);										
				}
				// $scope.Beneficiary.push('ben_0');
				 $scope.functionalityId=$scope.onloadData[0].functionalityId
				 //$scope.policynumber=$scope.responseData[0].policyNo;
				 $scope.claimAnnuity=$scope.onloadData[0];
				 $scope.claimAnnuity.beneficiary =[];	
				 $scope.claimAnnuity.spouse={};
				 $scope.claimAnnuity.panUploadFileList = [];
				 $scope.claimAnnuity.dobUploadFileList = [];
				 $scope.claimAnnuity.benDobUploadFileList = [];
				 $scope.claimAnnuity.ageProofUploadFileList = [];
				 $scope.claimAnnuity.gender="male";
			
				 $scope.downloadShow=$scope.responseData[0].downloadShow; 
				 if($scope.downloadShow=="Y"){
					 $scope.downloadTab=true;
				 }else{
					 $scope.claimAnnuityDisplay=true;
				 }

					$scope.disableField=true;
				 
			}
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
				
			}
			
		});

	};
	onload();
    
	$scope.showBeneficiaryErrors=function(i)
	{
		if($scope.newresponseData.isBeneficiaryVisible=="Y")
		{
												
			$scope.addErrors(i);													 						
		}
		else
		{			
			$scope.removeErrors(i);			
		}								
		
	}
    
	$scope.removeErrors=function(i)
	{		
			
			index = $scope.errorArray.indexOf("beneficiaryName"+i);
			if(index!=-1)
			$scope.errorArray.splice(index,1);
			index = $scope.errorArray.indexOf("beneficiaryDOB"+i);
			if(index!=-1)
			$scope.errorArray.splice(index,1);
			index = $scope.errorArray.indexOf("beneficiaryRelWithAnnty"+i);
			if(index!=-1)
			$scope.errorArray.splice(index,1);
			index = $scope.errorArray.indexOf("beneficiaryAppointeeName"+i);
			
			if(index!=-1)
			$scope.errorArray.splice(index,1);
			index = $scope.errorArray.indexOf("beneficiaryRelWithBen"+i);
			
			if(index!=-1)
				$scope.errorArray.splice(index,1);
				index = $scope.errorArray.indexOf("beneficiaryAllocationPer"+i);
				
				if(index!=-1)
				$scope.errorArray.splice(index,1);
				index = $scope.errorArray.indexOf("beneficiaryAddress_1"+i);
				
				if(index!=-1)
					$scope.errorArray.splice(index,1);
					index = $scope.errorArray.indexOf("beneficiaryAddress_2"+i);
					if(index!=-1)
					$scope.errorArray.splice(index,1);
					index = $scope.errorArray.indexOf("beneficiaryAddress_3"+i);
					
					if(index!=-1)
					$scope.errorArray.splice(index,1);
					index = $scope.errorArray.indexOf("beneficiaryState"+i);
					
					if(index!=-1)
						$scope.errorArray.splice(index,1);
						index = $scope.errorArray.indexOf("beneficiaryCity"+i);
						
						if(index!=-1)
						$scope.errorArray.splice(index,1);
						index = $scope.errorArray.indexOf("beneficiaryPincode"+i);
						
						
							
							if(index!=-1)
							$scope.errorArray.splice(index,1);
							index = $scope.errorArray.indexOf("beneficiaryLandlineNo"+i);
							
							if(index!=-1)
								$scope.errorArray.splice(index,1);
								index = $scope.errorArray.indexOf("beneficiaryMobileNo"+i);
								
								if(index!=-1)
								$scope.errorArray.splice(index,1);
								index = $scope.errorArray.indexOf("beneficiaryMaritalStatus"+i);
								if(index!=-1)
								$scope.errorArray.splice(index,1);
			
	}
	
	
	$scope.addErrors=function(i){
		index = $scope.errorArray.indexOf("beneficiaryName"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryName"+i);
		
		
		index = $scope.errorArray.indexOf("beneficiaryDOB"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryDOB"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryRelWithAnnty"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryRelWithAnnty"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryAppointeeName"+i);
		
		if(index<0)
		$scope.errorArray.push("beneficiaryAppointeeName"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryRelWithBen"+i);
		
		if(index<0)
		$scope.errorArray.push("beneficiaryRelWithBen"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryAllocationPer"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryAllocationPer"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryAddress_1"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryAddress_1"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryAddress_2"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryAddress_2"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryAddress_3"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryAddress_3"+i);

		index = $scope.errorArray.indexOf("beneficiaryState"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryState"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryCity"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryCity"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryPincode"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryPincode"+i);
		
		
		
		index = $scope.errorArray.indexOf("beneficiaryLandlineNo"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryLandlineNo"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryMobileNo"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryMobileNo"+i);
		
		index = $scope.errorArray.indexOf("beneficiaryMaritalStatus"+i);
		if(index<0)
		$scope.errorArray.push("beneficiaryMaritalStatus"+i);
		
		
		
		
	}
    
    
    $scope.onclickofAnnuityOption=function(){
    	for(var i=0;i<$scope.responseData.length;i++){
    		if($scope.responseData[i].optionName == $scope.claimAnnuity.annuityOption){
    			$scope.newresponseData=$scope.responseData[i];
    		}
    	}
    	
    	if($scope.newresponseData.isBeneficiaryVisible=="Y"){
    		$scope.showbeneficiary=true;
    		$scope.Beneficiary=[];
    		for(var i=0;i<$scope.benCount;i++){
    			if(angular.isDefined($scope.claimAnnuity.beneficiary[i].gender))
    			$scope.claimAnnuity.beneficiary[i].gender='male';
    		}
    		$scope.Beneficiary.push("ben_0");

    	}else{
    		$scope.showbeneficiary=false;
    		for(var i=0;i<=$scope.benCount;i++){
    		$scope.removeErrors(i);
    		}
    		$scope.claimAnnuity.beneficiary=[];
    		$scope.Beneficiary=[];
    		$scope.benCount=0;

    	}
    	
    	if($scope.newresponseData.isSpouseVisible=="Y"){
    		$scope.showsurvivour=true;
    		$scope.claimAnnuity.spouse.gender='male';
    		if($scope.spouse.length<=0){
    		$scope.spouse.push('spouse');
    		}
    		//$scope.modalErrorArray.push("landlineNo1");
    	
    	}else{
    		$scope.showsurvivour=false;
    		$scope.spouse=[];
    		$scope.modalErrorArray=[];
   $scope.claimAnnuity.spouse={};

    	}
    	
    	if($scope.newresponseData.isSpouseDobFileVisible=="Y"){
    		$scope.showdob=true;
    	}else{
    		$scope.showdob=false;
    	}
    	
    	if($scope.newresponseData.isBenDobFileVisible=="Y"){
    		$scope.showdobbeneficiary=true;
    	}else{
    		$scope.showdobbeneficiary=false;
    	}
    
	};
    	
	$scope.OnResetBtn=function(){
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$('.err-msg').css("visibility", "");
		//$scope.errorArray=[];
		//$scope.claimRequestFormJson={};
		$scope.ClaimAnnuitySpouse={};
		$scope.claimAnnuity={};
		$scope.claimAnnuity.beneficiary =[];
		  var upload_Msg = angular.element(document
				    .querySelector('#file-upload-main1_errMsg'));
		  			$scope.claimAnnuity.panUploadFileList=[];
				    upload_Msg[0].innerHTML ="";
				    var des_Msg = angular.element(document
				            .querySelector('#file-upload-main1_upText'));
				    des_Msg[0].innerHTML =  "";
				    
				    var upload_Msg = angular.element(document
						    .querySelector('#file-upload-main2_errMsg'));
				    		$scope.claimAnnuity.dobUploadFileList=[];
						    upload_Msg[0].innerHTML ="";
						    var des_Msg = angular.element(document
						            .querySelector('#file-upload-main2_upText'));
						    des_Msg[0].innerHTML =  "";		
				    
						    var upload_Msg = angular.element(document
								    .querySelector('#file-upload-main3_errMsg'));
						    		$scope.claimAnnuity.benDobUploadFileList=[];
								    upload_Msg[0].innerHTML ="";
								    var des_Msg = angular.element(document
								            .querySelector('#file-upload-main3_upText'));
								    des_Msg[0].innerHTML =  "";
								    var upload_Msg = angular.element(document
										    .querySelector('#file-upload-main4_errMsg'));
								    		$scope.claimAnnuity.ageProofUploadFileList=[];
										    upload_Msg[0].innerHTML ="";
										    var des_Msg = angular.element(document
										            .querySelector('#file-upload-main4_upText'));
										    des_Msg[0].innerHTML =  "";								    
	
	};

	$scope.deleteBeneficary = function(deletID) {
		
		if($scope.benCount==0){		
			/*$rootScope.openAlertID1 = true;	
			$scope.message = "At least 1 Beneficiary should be there.";	*/	
			ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 Beneficiary should be there. ","errorMessage-popup", "claimAnnuitysAlert");									
		}else{
			$rootScope.openAlertID = true;	
			$scope.actions="delete";
			$scope.message = "Are you sure want to delete";
			$scope.deleteId=deletID;																	
			}														
	};
	
	 $scope.checkBasicFieldValidations = function() {
	       	
		 var deleteDetails=false;
		 var index=-1;
		
		
		
	    if ($scope.errorArray.length > 0) {
	    	
	    	
	    	 for(var i=0;i<$scope.benCount;i++)
				{
	    		 $scope.showBeneficiaryErrors(i);
			
				}
	    	
	    	
	    	
	    	var arrlength=$scope.errorArray.length;
	    	
	    	
	    	for(var j=0;j<$scope.errorArray.length;j++)
	    	{
	    		
	    		if(deleteDetails)
	    		{
	    			j=0;
	    		}
    			var index=$scope.errorArray[j].substr($scope.errorArray[j].length - 1);

	    	
	    		if($scope.errorArray[j].indexOf("Beneficiary")==0)
	    		{
	    		if($scope.claimAnnuity.beneficiary[index]==undefined)
    			{
    				$scope.errorArray.splice(j, 1);
    				deleteDetails=true;
    				j--;
    			}
	    		else
				{
				deleteDetails=false;
				}
	    			}
	    		else
	    			{
	    			deleteDetails=false;
	    			}
	    	}
	    	
	    	
	        for (var i = 0; i < $scope.errorArray.length; i++) {
	            var lengthBfr = $scope.errorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = $scope.errorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	       
			
	       
	        
	        
	        if ($scope.errorArray.length > 0) {
	            $("#" + $scope.errorArray[0]).focus();
	            
	            return false;
	        } else {
	            return true;
	        }
	    } else {
	        return true;
	    }
	};
 
		$scope.checkBasicFieldValidationsModal = function() {
		    if ($scope.modalErrorArray.length > 0) {
		        for (var i = 0; i < $scope.modalErrorArray.length; i++) {
		            var lengthBfr = $scope.modalErrorArray.length;
		            var errorElement = angular.element(document.querySelector('#' + $scope.modalErrorArray[i]));
		            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
		                errorElement.triggerHandler("blur");
		            }
		            var lengthAftr = $scope.modalErrorArray.length;
		            if (lengthAftr < lengthBfr) {
		                i--;
		            }
		        }
		        if ($scope.modalErrorArray.length > 0) {
		            $("#" + $scope.modalErrorArray[0]).focus();
		            return false;
		        } else {
		            return true;
		        }
		    } else {
		        return true;
		    }
		};
	
		
		var currentTime = new Date();
		$scope.currentTime = currentTime;
		$scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		$scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
		$scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
		$scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

		$scope.today = '';
		$scope.clear = 'Clear';
		$scope.close = 'Done';
		var days = 100;
		$scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
		
		$scope.onStart = function () {
		   
		};
		$scope.onRender = function () {
		   
		};
		$scope.onOpen = function () {

		};
		$scope.onClose = function () {
	    
		};
		$scope.onSet = function () {
		
			
		};
		$scope.onStop = function () {
		  
		};
	/*	$scope.deleteBeneficary = function(deletID) {
			
			if($scope.benCount==0){		
				
				ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 Beneficiary should be there. ","errorMessage-popup", "claimAnnuitysAlert");									
			}else{
				$rootScope.openAlertID = true;	
				$scope.actions="delete";
				$scope.message = "Are you sure want to delete";
				//$scope.deleteId=deletID;																	
				}														
		};*/
		
		var total = 0;							
		$scope.addBeneficiary = function() {
			if ($scope.checkBasicFieldValidations())
			{
				
				$scope.totalSharePer=0;

				for(var i=0;i<$scope.claimAnnuity.beneficiary.length;i++)
				{								
				$scope.totalSharePer=parseInt($scope.totalSharePer)+parseInt($scope.claimAnnuity.beneficiary[i].allocationPer);
				}
				
			if($scope.totalSharePer<100)
			{
			if($scope.benCount<9)
			{
				$scope.benCount	= $scope.benCount+1;
				$scope.Beneficiary.push('ben_'+$scope.benCount);
				$scope.disabled[$scope.benCount]=false;
				
			}
			else
				ajaxHttpFactory.showErrorSuccessMessagePopup("You cannot add more than 10 Beneficiary. ","errorMessage-popup", "claimAnnuitysAlert");	
			}	
			else
				ajaxHttpFactory.showErrorSuccessMessagePopup("You cannot Allocate more than 100%. ","errorMessage-popup", "claimAnnuitysAlert");	
			}			
			else
				ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details for Beneficiary ","errorMessage-popup", "claimAnnuitysAlert");																	
			};
    
			$scope.deleteBeneficary = function(deletID) {
				
				if($scope.benCount==0){		
					/*$rootScope.openAlertID1 = true;	
					$scope.message = "At least 1 Beneficiary should be there.";	*/	
					ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 Beneficiary should be there. ","errorMessage-popup", "claimAnnuitysAlert");									
				}else{
					$rootScope.openAlertID = true;	
					$scope.actions="delete";
					$scope.message = "Are you sure want to delete";
					$scope.deleteId=deletID;																	
					}														
			};
			
			
			$scope.okAlert= function (){
				$rootScope.openAlertID = false;
				if($scope.actions=="delete")
					{
				if($scope.benCount==0)
				{
						
					ajaxHttpFactory.showErrorSuccessMessagePopup("At least 1 beneficiary should be there. ","errorMessage-popup", "claimAnnuitysAlert");
				}
				else
					{
						
				  $scope.Beneficiary.splice($scope.deleteId,1);
				  $scope.claimAnnuity.beneficiary.splice($scope.deleteId,1);				  
				  $scope.benCount= $scope.benCount-1;	
				  $scope.Beneficiary=[];
				  $scope.removeErrors($scope.deleteId);
				  //$scope.removeErrors($scope.deleteId+1);
				  for(var i=0;i<=$scope.benCount;i++)
					  {								
					$scope.Beneficiary.push('ben_'+i);					
					  }	
				  for(var k=0;k<=$scope.errorArray.length;k++)
				  {			
					  if($scope.errorArray[k] != ""){
						  var str=$scope.errorArray[k];
						  var res = str.substring(0, str.length-1)+$scope.deleteId;
						  $scope.errorArray[k] = res;
					  }								
				  }	
					  }
					}
				else if($scope.action=="success")
					{
					$window.location.href = "dashboard.htm";
					}
				else if($scope.action=="failure")
					{
					$window.location.href = "onlogout.htm";
					}				
			};
			
			
			$scope.upload = function(upId, docType,uploadType) {
				$scope.preloaderCheck=false;
		        var desc_Id = angular.element(document
		            .querySelector('#' + upId.id+'_errMsg'));
		        var upload_Msg = angular.element(document
		            .querySelector('#' + upId.id + '_upText'));
		            if(upId.files.length != 0){  
		            	
		            	
		            	if(upId.files[0].size<5242880)
	            		{
	            	var length=upId.files[0].name.lastIndexOf('.');
	            	var ext=upId.files[0].name.substring(length+1,upId.files[0].name.length);
	            	if(ext=='PDF' || ext=='pdf' || ext=='jpg' || ext=='JPG' || ext=='JPEG' || ext=='jpeg' || ext=='TIFF' || ext=='tiff')
	            		{
		         
		            	$scope.uploadType=uploadType;
		            	upload_Msg[0].innerHTML="";	
		            	desc_Id[0].innerHTML="";
		            	$scope.allowedExtensions=["PDF","pdf","TIFF","tiff","JPG","jpg","JPEG" ,"jpeg" ,"xls","XLS","xlsx","XLSX"];
		            	csrDocUploadFactory.uploadFileOnServer(upId.files, desc_Id, upload_Msg, docType,$scope.functionalityId,$scope.fileUploadCallBack,$scope.claimAnnuity.policyNo,'Upload File',$scope.allowedExtensions);
		            }
	            	else
            		{
            	
	            		$scope.claimAnnuity.panUploadFileList.length=0;
	            	$scope.claimAnnuity.dobUploadFileList.length=0;
	            	$scope.claimAnnuity.benDobUploadFileList.length=0;
	            	$scope.claimAnnuity.ageProofUploadFileList.length=0;
            		upload_Msg[0].innerHTML="";
            		desc_Id[0].innerHTML="";
            		upload_Msg[0].innerHTML="<span class=red-text>Error While Uploading. File extension should be PDF or TIFF</span>";
            		}
            		}
            	else
            		{
            		$scope.claimAnnuity.panUploadFileList.length=0;
            	    $scope.claimAnnuity.dobUploadFileList.length=0;
            		$scope.claimAnnuity.benDobUploadFileList.length=0;
            		$scope.claimAnnuity.ageProofUploadFileList.length=0;
            		upload_Msg[0].innerHTML="";
            		desc_Id[0].innerHTML="";
            		upload_Msg[0].innerHTML="<span class=red-text>Error While Uploading.File size should not be more than 5 MB</span>";
            		}
		            }
		            	
		            	
				};
				
				 $scope.fileUploadCallBack = function(uploadFileJsonResp, fileId, upload_Msg,message) {
		            	
		            	if(uploadFileJsonResp=="ERROR")
		            	{
		            	
		          	    upload_Msg[0].innerHTML =  message;
		            	
		            	return false;
		            	}
		            	
		            	else
		            		{
		    	        var fileUploadResJsonObj = angular.fromJson(uploadFileJsonResp);
		    	        if (fileUploadResJsonObj != null &&
		    	            fileUploadResJsonObj != '' && fileUploadResJsonObj != "") {
		    
		    				if(fileUploadResJsonObj.errorCode!=undefined)
		    				{
		    					ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
		    				}
		    				else
		    				{
		    	        	for(var i=0;i<fileUploadResJsonObj.length;i++)
		    	        		{
		    	  
		    	        		if(angular.fromJson(fileUploadResJsonObj[i]).errorCode=="0")
		    	        		{
		    	        			if($scope.uploadType=="panUpload"){
		    	        				$scope.claimAnnuity.panUploadFileList.push(angular.fromJson(fileUploadResJsonObj[i]));
		    	        			}
		    	        			if($scope.uploadType=="dobUpload"){
		    	        				$scope.claimAnnuity.dobUploadFileList.push(angular.fromJson(fileUploadResJsonObj[i]));
		    	        			}
		    	        			if($scope.uploadType=="benDobUpload"){
		    	        				$scope.claimAnnuity.benDobUploadFileList.push(angular.fromJson(fileUploadResJsonObj[i]));
		    	        			}
		    	        			if($scope.uploadType=="ageProofUpload"){
		    	        				$scope.claimAnnuity.ageProofUploadFileList.push(angular.fromJson(fileUploadResJsonObj[i]));
		    	        			}		    	        			    	        	

		       	            if(fileId.length==1)
		       	            	{
		       	             upload_Msg[0].innerHTML =  "Document uploaded successfully.";
		       	            	}
		       	           
		    	        		}
		    	        		else
		    	        		{
		    	        			ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup","submitSuccessAlert");
		    	        		}
		    	        		}
		    	         
		    	           }
		    	            
		    	        } else {
		    	          
		    	            ajaxHttpFactory.showErrorSuccessMessagePopup("Error while uploading file. Please try again.", "errorMessage-popup", "SuccessAlert");
		    	        }
		    	        
		            		}
		    	        $rootScope.preloaderCheck=false;
		    	    };
		    	    $scope.checkDate= function(currentElement,errorMsgElement){
		    			if(angular.element(document.getElementById(currentElement)).val()=="")
		    				{
		    				angular.element(document.getElementById(currentElement)).addClass('invalid1');
		    				angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
		    				if(currentElement=="dateofBirth"){
		    				$scope.errorArray.push("dateofBirth");	
		    				}else if(currentElement=="dateofBirth1"){
		    				$scope.modalErrorArray.push("dateofBirth1")	
		    				}
		    				
		    				return false;
		    				}
		    			else
		    				{
		    			
		    				angular.element(document.getElementById(currentElement)).removeClass('invalid1');
		    				angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
		    			
		    				}
		    			return true;
		    			}
		    	    
		    	    $scope.submitClaim = function() {
						$scope.preloaderCheck=true;
						if($scope.claimAnnuity.tdsPer > 100){
							ajaxHttpFactory.showErrorSuccessMessagePopup("TDS percentage should not be greater than 100%. ","errorMessage-popup", "claimAnnuitysAlert");
							return false;
						}
						 if($scope.newresponseData.isSpouseVisible=="Y"){
								if($scope.checkBasicFieldValidations())
								{
									if($scope.checkBasicFieldValidationsModal()){
										/*if($scope.claimAnnuity.gender==""){
											*/
										
										if($scope.newresponseData.isSpouseDobFileVisible=="Y"){
											if($scope.claimAnnuity.dobUploadFileList.length == 0){											
												ajaxHttpFactory.showErrorSuccessMessagePopup("Please Upload Spouse Date of birth File. ","errorMessage-popup", "claimAnnuitysAlert");
												return false;
											}
										}
										if($scope.newresponseData.isPanFileVisible=="Y"){
											if($scope.claimAnnuity.panUploadFileList.length == 0){											
												ajaxHttpFactory.showErrorSuccessMessagePopup("Please Upload PAN Document. ","errorMessage-popup", "claimAnnuitysAlert");
												return false;
											}
										}
										if($scope.newresponseData.isBenDobFileVisible=="Y"){
											if($scope.claimAnnuity.benDobUploadFileList.length == 0){											
												ajaxHttpFactory.showErrorSuccessMessagePopup("Please Upload Beneficiary Date of birth File ","errorMessage-popup", "claimAnnuitysAlert");
												return false;
											}
										}
										if($scope.newresponseData.isAgeProofVisible=="Y"){
											if($scope.claimAnnuity.ageProofUploadFileList.length == 0){											
												ajaxHttpFactory.showErrorSuccessMessagePopup("Please Upload Age Proof Document. ","errorMessage-popup", "claimAnnuitysAlert");
												return false;
											}
										}	
										
										if($scope.newresponseData.isBeneficiaryVisible=="Y"){
										$scope.totalSharePer=0;

										for(var i=0;i<$scope.claimAnnuity.beneficiary.length;i++)
										{					
											$scope.Data=$scope.claimAnnuity.beneficiary[i];
											
										$scope.totalSharePer=parseInt($scope.totalSharePer)+parseInt($scope.claimAnnuity.beneficiary[i].allocationPer);									
										
										}
										
									if(parseInt($scope.totalSharePer)==100)
									{			
									
											var claimAnnuityJson = angular.toJson($scope.claimAnnuity);										
											var ajaxurl = $location.absUrl();
											ajaxHttpFactory.postJsonDataSuccessFailure(claimAnnuityJson, "POST", ajaxurl,"Submit", $scope.successMethod,$scope.failureMethod);
																													
									}	
									else
										ajaxHttpFactory.showErrorSuccessMessagePopup("Beneficiary Share% should be 100% . ","errorMessage-popup", "claimAnnuitysAlert");	
									
										}else{
											var claimAnnuityJson = angular.toJson($scope.claimAnnuity);										
											var ajaxurl = $location.absUrl();
											ajaxHttpFactory.postJsonDataSuccessFailure(claimAnnuityJson, "POST", ajaxurl,"Submit", $scope.successMethod,$scope.failureMethod);
										}
										/*}else{
											ajaxHttpFactory.showErrorSuccessMessagePopup("Please select gender","errorMessage-popup", "claimAnnuitysAlert");
										}*/
									}else{
										ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details for Claims","errorMessage-popup", "claimAnnuitysAlert");				
									}
								}
								else {
									$scope.checkBasicFieldValidationsModal();
									ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details for Claims","errorMessage-popup", "claimAnnuitysAlert");													
								}
						}
						 
						
						
						
						else
						{	
						if ($scope.checkBasicFieldValidations())
						{
							
							if($scope.newresponseData.isSpouseDobFileVisible=="Y"){
								if($scope.claimAnnuity.dobUploadFileList.length == 0){											
									ajaxHttpFactory.showErrorSuccessMessagePopup("Please Upload Spouse Date of birth File. ","errorMessage-popup", "claimAnnuitysAlert");
									return false;
								}
							}
							if($scope.newresponseData.isPanFileVisible=="Y"){
								if($scope.claimAnnuity.panUploadFileList.length == 0){											
									ajaxHttpFactory.showErrorSuccessMessagePopup("Please Upload PAN Document. ","errorMessage-popup", "claimAnnuitysAlert");
									return false;
								}
							}
							if($scope.newresponseData.isBenDobFileVisible=="Y"){
								if($scope.claimAnnuity.benDobUploadFileList.length == 0){											
									ajaxHttpFactory.showErrorSuccessMessagePopup("Please Upload Beneficiary Date of birth File ","errorMessage-popup", "claimAnnuitysAlert");
									return false;
								}
							}
							if($scope.newresponseData.isAgeProofVisible=="Y"){
								if($scope.claimAnnuity.ageProofUploadFileList.length == 0){											
									ajaxHttpFactory.showErrorSuccessMessagePopup("Please Upload Age Proof Document. ","errorMessage-popup", "claimAnnuitysAlert");
									return false;
								}
							}
							
							if($scope.newresponseData.isBeneficiaryVisible=="Y"){
							$scope.totalSharePer=0;

							for(var i=0;i<$scope.claimAnnuity.beneficiary.length;i++)
							{					
								$scope.Data=$scope.claimAnnuity.beneficiary[i];
								
							$scope.totalSharePer=parseInt($scope.totalSharePer)+parseInt($scope.claimAnnuity.beneficiary[i].allocationPer);									
							
							}
							
						if(parseInt($scope.totalSharePer)==100)
						{		
							
								var claimAnnuityJson = angular.toJson($scope.claimAnnuity);										
								var ajaxurl = $location.absUrl();
								ajaxHttpFactory.postJsonDataSuccessFailure(claimAnnuityJson, "POST", ajaxurl,"Submit", $scope.successMethod,$scope.failureMethod);
																										
						}	
						else
							ajaxHttpFactory.showErrorSuccessMessagePopup("Beneficiary Share% should be 100% . ","errorMessage-popup", "claimAnnuitysAlert");							
						}
						else{
							var claimAnnuityJson = angular.toJson($scope.claimAnnuity);										
							var ajaxurl = $location.absUrl();
							ajaxHttpFactory.postJsonDataSuccessFailure(claimAnnuityJson, "POST", ajaxurl,"Submit", $scope.successMethod,$scope.failureMethod);
						}												
						}							
						else
							ajaxHttpFactory.showErrorSuccessMessagePopup("Please Fill mandatory details for Claims","errorMessage-popup", "claimAnnuitysAlert");																	
						
						}
						};	
						
						 $scope.successMethod = function(response) {	
							    	    	$rootScope.preloaderCheck=false;
							    	    	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
							    	    	if (response != null && response != "null") {								    	    	
							    	    		$rootScope.openAlertID1 = true;
							    	    		$scope.action="success";
							    	    		$scope.message = "Your request submitted successfully with request Id "+response;	
							    	    		$scope.resetClaim();
							    	    	}
							    	    	}
									};	
									
						$scope.failureMethod=function(){														
										$rootScope.preloaderCheck=false;														
										$rootScope.openAlertID1 = true;
										$scope.action="failure";
										$scope.message = "Some Error Occured.";
									};
									
						$scope.claimAdded= function (){
										$rootScope.openAlertID = false;
										$rootScope.openAlertID1 = false;
										$window.location.href = "claimAnnuity.htm";
									};
									
						$scope.cancelAlert= function (){
										$rootScope.openAlertID = false;
										$rootScope.openAlertID1 = false;
										$window.location.href = "dashboard.htm";
									};	
									
									
									$scope.downloadPdf=function()
									{
										$rootScope.preloaderCheck=true;

										var claimAnnuityJson = angular.toJson($scope.claimAnnuity);										
										var ajaxurl = $location.absUrl();
										ajaxHttpFactory.postJsonDataSuccessFailure(claimAnnuityJson, "POST", ajaxurl,"Download", $scope.successDownloadMethod,$scope.failureMethod);
								
									};
									
									$scope.successDownloadMethod=function(response){
										$rootScope.preloaderCheck=true;
										if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "exceptionAlert")){
										
										if(response=="success")
											{
										 	$scope.methodType = 'POST';
											
											$http({
								                url: 'PDFStatementServlet.do',
								                method: $scope.methodType,
								                responseType: 'arraybuffer',
								                data: undefined,
								                headers: {
								                    'Content-type': 'application/json',
								                    'Accept': 'application/pdf'
								                }
								            }).success(function(data) {
								            	$rootScope.preloaderCheck=true;
								            	if(data.byteLength>0)
								            	{
								                var blob = new Blob([data], {
								                    type: 'application/pdf'
								                });
								                saveAs(blob, 'ClaimAnnuity' + '.pdf');
								                $rootScope.preloaderCheck=false;
												ajaxHttpFactory.showErrorSuccessMessagePopup("File downloaded successfully. ","errorMessage-popup", "bidAlert");

								            	}
								            	else
								            	{
								            		$rootScope.preloaderCheck=false;
													ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "bidAlert");

								            	}
								                
								                
								            }).error(
								                function() {
								                 	$rootScope.preloaderCheck=false;
													ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured while downloading file. ","errorMessage-popup", "bidAlert");

								                });
											
											
											
											}
										else
											{
											$rootScope.preloaderCheck=false;
											ajaxHttpFactory.showErrorSuccessMessagePopup("Some error occured. ","errorMessage-popup", "bidAlert");

											}
										}
										$rootScope.preloaderCheck=false;
									
									}
						


}]);

