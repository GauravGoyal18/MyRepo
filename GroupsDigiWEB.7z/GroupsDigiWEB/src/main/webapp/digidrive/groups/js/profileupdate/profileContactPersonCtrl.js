		/*var app = angular.module('groupApp', ['ajaxUtil','ui.materialize','validationService','uiValidations']);*/
app.controller('profileContactPersonCtrl',['$rootScope','$scope','$location','ajaxHttpFactory','validateFieldService','$window', function($rootScope, $scope,$location,ajaxHttpFactory,validateFieldService,$window){
	$rootScope.preloaderCheck=true;
	$scope.contactPersonMatrix={};
	$scope.modalErrorArray=[];
	$scope.errorArray=[];
	$scope.loadContactDetails={};
	$scope.prepopulateContactDetails={};
	$scope.titleDetails=[];
	$scope.loadContactDetails={};
	$scope.editContactPersonChangeSubmit={};
	$rootScope.enable=true;
	//$scope.editContactPersonChangeSubmitJson={};
	$scope.absUrl =window.location.origin + window.location.pathname+window.location.search;
	$scope.contactDiv=false;
    $scope.gender=["Male","Female"];
	$scope.radiodiv=false;
	
	
	$scope.onClickContactPerson= function(){
	$scope.loadContactDetails.title.newValue="";
	$scope.loadContactDetails.firstName.newValue="";
	$scope.loadContactDetails.middleName.newValue="";
	$scope.loadContactDetails.lastName.newValue="";
	$scope.loadContactDetails.emailId.newValue="";
	$scope.loadContactDetails.mobnumber.newValue="";
	$scope.modalErrorArray=["contactPerson_title_new","contactPerson_firstName_new", "contactPerson_lastName_new", "contactPerson_emailId_new", "contactPerson_number_new"];
		$scope.ContactPerson = true;
		 
		 
		
	};
	$scope.contactPersonChangeCancel= function(){
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$('.err-msg').css("visibility", "");
		$scope.ContactPerson = false;	
		$scope.onClickContactPerson();
	};
	
	$scope.validateFields = function(name,action)  
	{
	  
		$scope.id=name;
		$scope.action=action;
		$scope.result = validateFieldService.fieldValidate($scope.id,$scope.action,$scope.contactPersonMatrix);
		return $scope.result;
		
	};
	$scope.onCallRadioButton= function (index){
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$('.err-msg').css("visibility", "");
		$scope.contactDiv=true;
		$scope.index=index;
		/*if($scope.prepopulateContactDetails[$scope.index].title.newValue=="Mr"){
			$scope.prepopulateContactDetails[$scope.index].title.newValue="Male";
		}
		else{
			$scope.prepopulateContactDetails[$scope.index].title.newValue="Female";
		}*/
	
	};
	
	$scope.onclickeditbtn = function(id)    
	{
		
		$scope.validateFields(id,'enable');
		$rootScope.enable=false;
	
		
	};
	$scope.onClickCancelBn = function(id)   
	{
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$('.err-msg').css("visibility", "");
		
		
		$scope.prepopulateContactDetails[$scope.index][id].newValue=$scope.prepopulateContactDetails[$scope.index][id].oldValue;
		
		$scope.validateFields(id,'cancel');
		
		$rootScope.enable=true;
	
	};
	
	var getContactPersonDetailsAccessMatrix = function () { 
		
		return ajaxHttpFactory.getJsonData("getContactPersonChangeDetailsAccessMatrix",$scope.absUrl)
		.then(function(response) {
			$rootScope.preloaderCheck=false;
			if (response != null && response != "null") {
				var responseData = response.data;
				$scope.contactPersonMatrix = responseData.resultMap;
				
				//loadCompanyAddressDetails();
			}
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});

	};
	getContactPersonDetailsAccessMatrix();	
	
	
	var loadContactPersonDetails = function () { 
		
		return ajaxHttpFactory.getJsonData("loadContactPersonDetails",$scope.absUrl)
	.then(function(response) {
		$rootScope.preloaderCheck=false;
		if (response != null && response != "null") {
			var responseData = response.data;
			$scope.loadContactDetails = responseData;
			
		}
	},
	function(errResponse) {
		$rootScope.preloaderCheck=false;
		console.error('Error while fetching profile details.');

	});

};
loadContactPersonDetails();
		  	

var prePopulateContactPersonDetails = function () { 
	
	
		return ajaxHttpFactory.getJsonData("prePopulateContactPersonDetails",$scope.absUrl)
		.then(function(response) {
			$rootScope.preloaderCheck=false;
			if (response != null && response != "null") {
				var responseData = response.data;
				$scope.prepopulateContactDetails = responseData;
				if(angular.isDefined($scope.prepopulateContactDetails) && $scope.prepopulateContactDetails.length>0)
					{
					$scope.radiodiv=true;
					}
				
			}
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});

	};
	prePopulateContactPersonDetails();
	
	
	
	var getTitleDetails=function(){
		$rootScope.preloaderCheck=true;
		return ajaxHttpFactory.getJsonData("getTitleDetails",$scope.absUrl)
		.then(function(response) {

			if (response != null && response != "null") {
				var responseData = response.data;
				
					$scope.titleDetails.push(responseData);
				
			}	
			$rootScope.preloaderCheck=false;
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching profile details.');

		});
	};
	
	getTitleDetails();
	
	
	$scope.contactPersonChangeSubmitForm = function()
	{
		
		/*if($scope.loadContactDetails.title.newValue=="Male"){
			$scope.loadContactDetails.title.newValue="Mr";
		}
		else{
			$scope.loadContactDetails.title.newValue="Ms";
		}*/
		if($scope.checkBasicFieldValidationsModal())
{
	$scope.contactPersonChangeSubmit=$scope.loadContactDetails;
	
	$rootScope.preloaderCheck=true;
		ajaxHttpFactory.postJsonDataSuccessFailure($scope.contactPersonChangeSubmit,"POST",$scope.absUrl,"contactPersonChangeSubmit",$scope.successMethod,$scope.failureMethod);
}
	};

$scope.successMethod=function(response){
	$rootScope.preloaderCheck=false;
if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "companyAddressChangeAlert"))
	
{
	ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. ","errorMessage-popup", "companyAddressChangeAlert"); 
	$scope.ContactPerson = false;
	$scope.onClickContactPerson();
}
};

$scope.failureMethod=function(response){
	$rootScope.preloaderCheck=false;
	if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "companyAddressChangeAlert")){
		
		ajaxHttpFactory.showErrorSuccessMessagePopup("Some Error Occured : ","errorMessage-popup", "companyAddressChangeAlert");
		$scope.onClickContactPerson();
	}
};
	
	
	

$scope.onClickSaveBn = function(id)
	{
	 if($scope.checkBasicFieldValidations())
	 {
	$scope.validateFields(id,'save');
	/*if($scope.prepopulateContactDetails[$scope.index].title.newValue=="Male"){
		$scope.prepopulateContactDetails[$scope.index].title.newValue="Mr";
	}
	else{
		$scope.prepopulateContactDetails[$scope.index].title.newValue="Ms";
	}*/
	
		 if($scope.prepopulateContactDetails[$scope.index][id].newValue==$scope.prepopulateContactDetails[$scope.index][id].oldValue)
			 {
				ajaxHttpFactory.showErrorSuccessMessagePopup("Enter a different value to save ","errorMessage-popup", "ContactPersonAlert");
			 }
		 else
			 {
	$scope.editContactPersonChangeSubmit=$scope.prepopulateContactDetails[$scope.index];
	
		$scope.editContactPersonChangeSubmit.index=$scope.index;
		var editContactPersonChangeSubmitJson=angular.toJson($scope.editContactPersonChangeSubmit);

		$rootScope.preloaderCheck=true;
		ajaxHttpFactory.postJsonDataSuccessFailure(editContactPersonChangeSubmitJson,"POST",$scope.absUrl,"editContactPersonChangeSubmitJson",$scope.successMethod,$scope.failureMethod);
		$scope.prepopulateContactDetails[$scope.index][id].newValue=$scope.prepopulateContactDetails[$scope.index][id].oldValue;
		}
		 $rootScope.enable=true;
		}
		
};
$scope.checkBasicFieldValidations = function() {
    if ($scope.errorArray.length > 0) {
        for (var i = 0; i < $scope.errorArray.length; i++) {
            var lengthBfr = $scope.errorArray.length;
            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
                errorElement.triggerHandler("blur");
            }
            var lengthAftr = $scope.errorArray.length;
            if (lengthAftr < lengthBfr) {
                i--;
            }
        }
        if ($scope.errorArray.length > 0) {
            $("#" + $scope.errorArray[0]).focus();
            return false;
        } else {
            return true;
        }
    } else {
        return true;
    }
};
$scope.checkBasicFieldValidationsModal = function() {
    if ($scope.modalErrorArray.length > 0) {
        for (var i = 0; i < $scope.modalErrorArray.length; i++) {
            var lengthBfr = $scope.modalErrorArray.length;
            var errorElement = angular.element(document.querySelector('#' + $scope.modalErrorArray[i]));
            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
                errorElement.triggerHandler("blur");
            }
            var lengthAftr = $scope.modalErrorArray.length;
            if (lengthAftr < lengthBfr) {
                i--;
            }
        }
        if ($scope.modalErrorArray.length > 0) {
            $("#" + $scope.modalErrorArray[0]).focus();
            return false;
        } else {
            return true;
        }
    } else {
        return true;
    }
};
	
}]);


