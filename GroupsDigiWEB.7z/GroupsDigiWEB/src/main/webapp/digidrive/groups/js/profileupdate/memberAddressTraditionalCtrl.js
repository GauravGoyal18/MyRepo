		/*var app = angular.module('groupApp', ['ajaxUtil','ui.materialize','validationService','uiValidations']);*/
app.controller('memberAddressTraditionalCtrl',['$rootScope','$scope','$location','ajaxHttpFactory','validateFieldService','$window', function($rootScope, $scope,$location,ajaxHttpFactory,validateFieldService,$window){

	$rootScope.preloaderCheck=false;
	$scope.errorArray=[];
	$scope.modalErrorArray=[];
	$scope.absUrl =window.location.origin + window.location.pathname+window.location.search;
	$scope.memberAddressTraditionalModel={};
	$scope.memberAddTraditionalAcccessMatrix={};
	
	$scope.memberAddTraditionalFormCancel= function(){
		
		var currentElement = angular.element(document.getElementsByClassName('invalid1'));
		currentElement.removeClass('invalid1');
		$('.err-msg').css("visibility", "");
		$scope.memberAddressTraditionalModel={};

		/*$scope.memberAddressTraditionalModel.dob="";
		$scope.memberAddressTraditionalModel.mobileNo="";
		$scope.memberAddressTraditionalModel.emailID="";
		$scope.memberAddressTraditionalModel.doj="";*/
		$scope.modalErrorArray=["dob","emailID","doj","mobileNo"];
   	};
	
	var getLoadMemberAddressTraditional = function () { 
		
		return ajaxHttpFactory.getJsonData("getLoadMemberAddressTraditional",$scope.absUrl)
		.then(function(response) {
			$rootScope.preloaderCheck=false;
			if (response != null && response != "null") {
				var responseData = response.data;

				$scope.memberAddTraditionalAcccessMatrix=responseData.resultMap;
				
			}
		},
		function(errResponse) {
			$rootScope.preloaderCheck=false;
			console.error('Error while fetching getLoadMemberAddressTraditional details.');

		});

	};
	getLoadMemberAddressTraditional();	
	
	$scope.validateFields = function(name, action) {
		$scope.id = name;
		$scope.action = action;
		$scope.result = validateFieldService.fieldValidate($scope.id,$scope.action,$scope.memberAddTraditionalAcccessMatrix);
		return $scope.result;
	};
	
	$scope.memberAddTraditionalFormSubmit=function(){
		
		if($scope.checkBasicFieldValidationsModal()){
			
			
			var requestDataJson =angular.toJson($scope.memberAddressTraditionalModel);
			
			ajaxHttpFactory.postJsonDataSuccessFailure(requestDataJson,"POST",$scope.absUrl,"memberAddressTraditionalSubmit",$scope.successMethod1,$scope.failureMethod);
	}
		
		};
		
		
		$scope.successMethod1=function(response){
			$rootScope.preloaderCheck=false;
		if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "MemberAddressTraditionalAlert"))
			
		{
			
			ajaxHttpFactory.showErrorSuccessMessagePopup("Your request submitted successfully. ","errorMessage-popup", "MemberAddressTraditionalAlert"); 
			$scope.memberAddTraditionalFormCancel();
		}
		};
		
		
		$scope.failureMethod=function(response){
			$rootScope.preloaderCheck=false;
			if(!ajaxHttpFactory.handleIPruException(response, "errorMessage-popup", "MemberAddressTraditionalAlert")){
			
				ajaxHttpFactory.showErrorSuccessMessagePopup("Some Error Occured : ","errorMessage-popup", "MemberAddressTraditionalAlert");
				$scope.memberAddTraditionalFormCancel();
			}
		};
			
		var currentTime = new Date();
		$scope.currentTime = currentTime;
		$scope.month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		$scope.monthShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
		$scope.weekdaysFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
		$scope.weekdaysLetter = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

		$scope.today = '';
		$scope.clear = 'Clear';
		$scope.close = 'Done';
		var days = 100;
		$scope.minDate = (new Date($scope.currentTime.getTime() - ( 10000000 * 60 * 60 *24 * days ))).toISOString();
		$scope.maxDate = (new Date($scope.currentTime.getTime())).toISOString();
		
		$scope.onStart = function () {
		   
		};
		$scope.onRender = function () {
		   
		};
		$scope.onOpen = function () {
		  
		};
		$scope.onClose = function () {
			//$(document.activeElement).blur();

		};
		$scope.onSet = function () {
		};
		
		
		$scope.onSet1 = function () {
			if(angular.isDefined($scope.memberAddressTraditionalModel.dob)){
				$scope.minDoj=(new Date($scope.memberAddressTraditionalModel.dob)).toISOString();
			
				//$scope.minDoj = new Date((Date.parse($scope.memberAddressTraditionalModel.dob))+60*1000*60*24*366).toISOString();
			}
			/*var currentElement = angular.element( document.querySelector('#dob'));
			currentElement.removeClass('invalid1');
			$('#dob_errMsg').css("visibility", "");
			
			var currentElement = angular.element( document.querySelector('#doj'));
			currentElement.removeClass('invalid1');
			$('#doj_errMsg').css("visibility", "");*/
		};
		$scope.onStop = function () {
			  
		};
		$scope.checkDate= function(currentElement,errorMsgElement){
			if(angular.element(document.getElementById(currentElement)).val()=="")
				{
				angular.element(document.getElementById(currentElement)).addClass('invalid1');
				angular.element(document.getElementById(errorMsgElement)).css('visibility','visible');
				return false;
				}
			else
				{
				angular.element(document.getElementById(currentElement)).removeClass('invalid1');
				angular.element(document.getElementById(errorMsgElement)).css('visibility','hidden');
				}
			return true;
			}


	$scope.checkBasicFieldValidations = function() {
		
	      
	    if ($scope.errorArray.length > 0) {
	        for (var i = 0; i < $scope.errorArray.length; i++) {
	            var lengthBfr = $scope.errorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + $scope.errorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = $scope.errorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	        if ($scope.errorArray.length > 0) {
	            $("#" + $scope.errorArray[0]).focus();
	            return false;
	        } else {
	            return true;
	        }
	    } else {
	        return true;
	    }
	};
	
	$scope.checkBasicFieldValidationsModal = function() {
	    if ($scope.modalErrorArray.length > 0) {
	        for (var i = 0; i < $scope.modalErrorArray.length; i++) {
	            var lengthBfr = $scope.modalErrorArray.length;
	            var errorElement = angular.element(document.querySelector('#' + $scope.modalErrorArray[i]));
	            if (errorElement.prop('type') == "text" || errorElement.prop('type') == "textarea" || errorElement.prop('tagName') == 'DIV' || errorElement.prop('tagName') == "SELECT") {
	                errorElement.triggerHandler("blur");
	            }
	            var lengthAftr = $scope.modalErrorArray.length;
	            if (lengthAftr < lengthBfr) {
	                i--;
	            }
	        }
	        if ($scope.modalErrorArray.length > 0) {
	            $("#" + $scope.modalErrorArray[0]).focus();
	            return false;
	        } else {
	            return true;
	        }
	    } else {
	        return true;
	    }
	};
	
	
	$rootScope.$on('$includeContentLoaded', function (event) {
	    // it has loaded!
	if($scope.onloadFlag==true){
	
	$timeout(function() {
		angular.element('#companyAddressChange').trigger('click');
		$scope.onloadFlag=false;
	},100,true);
	}
});
	

	


}]);


