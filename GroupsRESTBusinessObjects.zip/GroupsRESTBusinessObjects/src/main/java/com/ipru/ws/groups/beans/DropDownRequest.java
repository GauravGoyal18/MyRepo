package com.ipru.ws.groups.beans;

public class DropDownRequest {

	private String functionality;
	private String dropDownType;
	private ParamObj paramObj;

	public DropDownRequest() {

		super();
		
	}

	public DropDownRequest(String functionality, String dropDownType) {
		super();
		this.functionality = functionality;
		this.dropDownType = dropDownType;
		
	}

	public DropDownRequest(String functionality, String dropDownType, ParamObj paramObj) {
		super();
		this.functionality = functionality;
		this.dropDownType = dropDownType;
		this.paramObj = paramObj;
		
	}

	public String getFunctionality() {
		return functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}

	public String getDropDownType() {
		return dropDownType;
	}

	public ParamObj getParamObj() {
		return paramObj;
	}

	public void setParamObj(ParamObj paramObj) {
		this.paramObj = paramObj;
	}

	public void setDropDownType(String dropDownType) {
		this.dropDownType = dropDownType;
	}

	@Override
	public String toString() {
		return "DropDownRequest [functionality=" + functionality + ", dropDownType=" + dropDownType + ", paramObj=" + paramObj + "]";
	}

}
