package com.ipru.ws.groups.beans;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class ParamObj {

	private List<String> param;
	private Map<String, Object> paramMap;

	public Map<String, Object> getParamMap() {
		return paramMap;
	}

	public void setParamMap(Map<String, Object> paramMap) {
		this.paramMap = paramMap;
	}

	public ParamObj() {
		super();
	}

	public List<String> getParam() {
		return param;
	}

	@JsonDeserialize(using = ParamObjDeserializable.class)
	public void setParam(List<String> param) {
		this.param = param;
	}

	@Override
	public String toString() {
		return "ParamObj [param=" + param + "]";
	}

	public ParamObj(List<String> param) {
		super();
		this.param = param;
	}

}
