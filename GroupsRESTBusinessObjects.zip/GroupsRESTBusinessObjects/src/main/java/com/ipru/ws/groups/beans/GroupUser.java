package com.ipru.ws.groups.beans;

import java.io.Serializable;
import java.util.List;

public class GroupUser implements Serializable {
	public String emailId;
	public Long mobileNo;
	public String webClientId;
	public List<GroupPolicyDetail> policyDetailList;
	
	
	public GroupUser() {
		super();
	}
	public GroupUser(String emailId, Long mobileNo, String webClientId) {
		super();
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.webClientId = webClientId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getWebClientId() {
		return webClientId;
	}
	public void setWebClientId(String webClientId) {
		this.webClientId = webClientId;
	}
	public List<GroupPolicyDetail> getPolicyDetailList() {
		return policyDetailList;
	}
	public void setPolicyDetailList(List<GroupPolicyDetail> policyDetailList) {
		this.policyDetailList = policyDetailList;
	}
	
	
}
