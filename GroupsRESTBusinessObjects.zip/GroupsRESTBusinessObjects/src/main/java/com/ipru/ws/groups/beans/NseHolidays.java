package com.ipru.ws.groups.beans;

import java.sql.Date;

public class NseHolidays {
	private long srNo;
	private Date holidayDate;
	private String holiday;
	private String holidayDesc;
	private String activeFlag;

	public synchronized Date getHolidayDate() {
		return holidayDate;
	}

	public synchronized void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}

	public synchronized String getHoliday() {
		return holiday;
	}

	public synchronized void setHoliday(String holiday) {
		this.holiday = holiday;
	}

	public synchronized String getHolidayDesc() {
		return holidayDesc;
	}

	public synchronized void setHolidayDesc(String holidayDesc) {
		this.holidayDesc = holidayDesc;
	}

	public synchronized String getActiveFlag() {
		return activeFlag;
	}

	public synchronized void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}

	public synchronized long getSrNo() {
		return srNo;
	}

	public synchronized void setSrNo(long srNo) {
		this.srNo = srNo;
	}

	@Override
	public String toString() {
		return "NscHolidays [srNo=" + srNo + ", holidayDate=" + holidayDate + ", holiday=" + holiday + ", holidayDesc=" + holidayDesc + ", activeFlag=" + activeFlag + "]";
	}

}
