package com.ipru.ws.groups.beans;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ipru.ws.beans.base.BaseObject;

@XmlRootElement(name = "testObject")
@XmlAccessorType(XmlAccessType.FIELD)
public class TestObj extends BaseObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@XmlElement
	public int id;
	@XmlElement
	public String name;

	public TestObj() {
		super();
	}

	public TestObj(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
