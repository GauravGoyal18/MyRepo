package com.ipru.ws.groups.beans;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ParamObjDeserializable extends JsonDeserializer<List<String>> {

	@Override
	public List<String> deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
		// TODO Auto-generated method stub
		final ObjectMapper mapper = (ObjectMapper) jp.getCodec();

		final JsonNode node = (JsonNode) mapper.readTree(jp);

		// TODO - Write the following logic in a better way
		String toStr = node.toString();
		toStr = StringUtils.replace(toStr, "\"{", "{");
		toStr = StringUtils.replace(toStr, "}\"", "}");
		toStr = StringUtils.remove(toStr, "\\r\\n");
		toStr = StringUtils.remove(toStr, "\\");

		final JsonNode newNode = mapper.readTree(toStr);
	
		if (newNode.isArray()) {
			final List<String> empInfo = mapper.convertValue(newNode, List.class);

		

			return empInfo;
		}
		else {
			final String empInfo = mapper.convertValue(newNode, String.class);

			

			return Arrays.asList(empInfo);

		}
	}

}