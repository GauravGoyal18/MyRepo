package com.ipru.ws.groups.beans;

import java.util.ArrayList;
import java.util.Set;

public class SwitchToRequest {

	private ParamObj paramObj;
	private Set<String> fundCodes;

	public Set<String> getFundCodes() {
		return fundCodes;
	}

	public void setFundCodes(Set<String> fundCodes) {
		this.fundCodes = fundCodes;
	}

	public ParamObj getParamObj() {
		return paramObj;
	}

	public void setParamObj(ParamObj paramObj) {
		this.paramObj = paramObj;
	}

}
