package com.ipru.ws.groups.beans;

public class PrePopulateBean {

	private String className;
	private String functionality;
	private ParamObj paramObj;
	private Integer max;

	public ParamObj getParamObj() {
		return paramObj;
	}

	public void setParamObj(ParamObj paramObj) {
		this.paramObj = paramObj;
	}

	public String getFunctionality() {
		return functionality;
	}

	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public PrePopulateBean(String className, String functionality) {
		super();
		this.className = className;
		this.functionality = functionality;
	}

	public PrePopulateBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getMax() {
		return max;
	}

	public void setMax(Integer max) {
		this.max = max;
	}

}
