package com.ipru.ws.groups.beans;

public class SwitchFundToRequest {

}
