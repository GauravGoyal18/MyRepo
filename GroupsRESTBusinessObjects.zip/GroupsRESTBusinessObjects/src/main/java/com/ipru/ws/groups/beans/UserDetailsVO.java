package com.ipru.ws.groups.beans;

import java.io.Serializable;


public class UserDetailsVO implements Serializable {

	private static final long serialVersionUID = 1L;
	public String webClientId;
	private String clientId;

	public String getWebClientId() {
		return webClientId;
	}

	public void setWebClientId(String webClientId) {
		this.webClientId = webClientId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

}
