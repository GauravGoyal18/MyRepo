package com.ipru.ws.groups.beans;

import java.util.List;

import com.ipru.groups.to.SwitchTo;

public class Switch {
	private List<SwitchTo> switchTo;
	private ProductCodeBean productCode;
	private List<NseHolidays> nseHolidays;

	public synchronized List<SwitchTo> getSwitchTo() {
		return switchTo;
	}

	public synchronized void setSwitchTo(List<SwitchTo> switchTo) {
		this.switchTo = switchTo;
	}

	public synchronized ProductCodeBean getProductCode() {
		return productCode;
	}

	public synchronized void setProductCode(ProductCodeBean productCode) {
		this.productCode = productCode;
	}

	public synchronized List<NseHolidays> getNseHolidays() {
		return nseHolidays;
	}

	public synchronized void setNseHolidays(List<NseHolidays> nseHolidays) {
		this.nseHolidays = nseHolidays;
	}

	@Override
	public String toString() {
		return "Switch [switchTo=" + switchTo + ", productCode=" + productCode + ", nseHolidays=" + nseHolidays + "]";
	}

}
