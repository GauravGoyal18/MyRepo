package com.ipru.groups.vo;

import java.io.Serializable;
import java.sql.Timestamp;

public class GroupsUserAuthInfo implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int userid;
	private String fname;
	private String psswrd;
	private String isuserlocked;
	private String isvaliduser;
	private String lastPassword1;
	private String lastPassword2;
	private String lastPassword3;
	private String lastPassword4;
	private String lastPassword5;
	private Timestamp lastPasswordUpdateDate;
	private String securityQuestion;
	private String securityAnswer;
	private int loginAttempts;
	private String firstLogin;

	private String lastSuccessfullIpAddress;
	private String lastUnsuccessfullIpAddress;
	private String currentIpAddress;
	
	private String lastSuccessfulMACAddress;
	private String lastUnsuccessfulMACAddress;
	private String currentMACAddress;
	
	private Timestamp lastSuccessfulLoginTime;
	private Timestamp lastUnsuccessculLoginTime;
	private Timestamp currentLoginTime;
	
	private String role;
	private String policyNo;
	private String clientId;
	private String webClientId;
	private String firstName;
	private String lastName;
	
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getPsswrd() {
		return psswrd;
	}
	public void setPsswrd(String psswrd) {
		this.psswrd = psswrd;
	}
	public String getIsuserlocked() {
		return isuserlocked;
	}
	public void setIsuserlocked(String isuserlocked) {
		this.isuserlocked = isuserlocked;
	}
	public String getIsvaliduser() {
		return isvaliduser;
	}
	public void setIsvaliduser(String isvaliduser) {
		this.isvaliduser = isvaliduser;
	}
	public String getLastPassword1() {
		return lastPassword1;
	}
	public void setLastPassword1(String lastPassword1) {
		this.lastPassword1 = lastPassword1;
	}
	public String getLastPassword2() {
		return lastPassword2;
	}
	public void setLastPassword2(String lastPassword2) {
		this.lastPassword2 = lastPassword2;
	}
	public String getLastPassword3() {
		return lastPassword3;
	}
	public void setLastPassword3(String lastPassword3) {
		this.lastPassword3 = lastPassword3;
	}
	public String getLastPassword4() {
		return lastPassword4;
	}
	public void setLastPassword4(String lastPassword4) {
		this.lastPassword4 = lastPassword4;
	}
	public String getLastPassword5() {
		return lastPassword5;
	}
	public void setLastPassword5(String lastPassword5) {
		this.lastPassword5 = lastPassword5;
	}
	public Timestamp getLastPasswordUpdateDate() {
		return lastPasswordUpdateDate;
	}
	public void setLastPasswordUpdateDate(Timestamp lastPasswordUpdateDate) {
		this.lastPasswordUpdateDate = lastPasswordUpdateDate;
	}
	public String getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	public String getSecurityAnswer() {
		return securityAnswer;
	}
	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}
	public int getLoginAttempts() {
		return loginAttempts;
	}
	public void setLoginAttempts(int loginAttempts) {
		this.loginAttempts = loginAttempts;
	}
	public String getFirstLogin() {
		return firstLogin;
	}
	public void setFirstLogin(String firstLogin) {
		this.firstLogin = firstLogin;
	}
	public String getLastSuccessfullIpAddress() {
		return lastSuccessfullIpAddress;
	}
	public void setLastSuccessfullIpAddress(String lastSuccessfullIpAddress) {
		this.lastSuccessfullIpAddress = lastSuccessfullIpAddress;
	}
	public String getLastUnsuccessfullIpAddress() {
		return lastUnsuccessfullIpAddress;
	}
	public void setLastUnsuccessfullIpAddress(String lastUnsuccessfullIpAddress) {
		this.lastUnsuccessfullIpAddress = lastUnsuccessfullIpAddress;
	}
	public String getCurrentIpAddress() {
		return currentIpAddress;
	}
	public void setCurrentIpAddress(String currentIpAddress) {
		this.currentIpAddress = currentIpAddress;
	}
	public Timestamp getLastSuccessfulLoginTime() {
		return lastSuccessfulLoginTime;
	}
	public void setLastSuccessfulLoginTime(Timestamp lastSuccessfulLoginTime) {
		this.lastSuccessfulLoginTime = lastSuccessfulLoginTime;
	}
	public Timestamp getLastUnsuccessculLoginTime() {
		return lastUnsuccessculLoginTime;
	}
	public void setLastUnsuccessculLoginTime(Timestamp lastUnsuccessculLoginTime) {
		this.lastUnsuccessculLoginTime = lastUnsuccessculLoginTime;
	}
	public Timestamp getCurrentLoginTime() {
		return currentLoginTime;
	}
	public void setCurrentLoginTime(Timestamp currentLoginTime) {
		this.currentLoginTime = currentLoginTime;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getLastSuccessfulMACAddress() {
		return lastSuccessfulMACAddress;
	}
	public void setLastSuccessfulMACAddress(String lastSuccessfulMACAddress) {
		this.lastSuccessfulMACAddress = lastSuccessfulMACAddress;
	}
	public String getLastUnsuccessfulMACAddress() {
		return lastUnsuccessfulMACAddress;
	}
	public void setLastUnsuccessfulMACAddress(String lastUnsuccessfulMACAddress) {
		this.lastUnsuccessfulMACAddress = lastUnsuccessfulMACAddress;
	}
	public String getCurrentMACAddress() {
		return currentMACAddress;
	}
	public void setCurrentMACAddress(String currentMACAddress) {
		this.currentMACAddress = currentMACAddress;
	}
	public String getWebClientId() {
		return webClientId;
	}
	public void setWebClientId(String webClientId) {
		this.webClientId = webClientId;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "GroupsUserAuthInfo [userid=" + userid + ", fname=" + fname + ", psswrd=" + psswrd + ", isuserlocked=" + isuserlocked + ", isvaliduser=" + isvaliduser + ", lastPassword1="
				+ lastPassword1 + ", lastPassword2=" + lastPassword2 + ", lastPassword3=" + lastPassword3 + ", lastPassword4=" + lastPassword4 + ", lastPassword5=" + lastPassword5
				+ ", lastPasswordUpdateDate=" + lastPasswordUpdateDate + ", securityQuestion=" + securityQuestion + ", securityAnswer=" + securityAnswer + ", loginAttempts=" + loginAttempts
				+ ", firstLogin=" + firstLogin + ", lastSuccessfullIpAddress=" + lastSuccessfullIpAddress + ", lastUnsuccessfullIpAddress=" + lastUnsuccessfullIpAddress + ", currentIpAddress="
				+ currentIpAddress + ", lastSuccessfulMACAddress=" + lastSuccessfulMACAddress + ", lastUnsuccessfulMACAddress=" + lastUnsuccessfulMACAddress + ", currentMACAddress="
				+ currentMACAddress + ", lastSuccessfulLoginTime=" + lastSuccessfulLoginTime + ", lastUnsuccessculLoginTime=" + lastUnsuccessculLoginTime + ", currentLoginTime=" + currentLoginTime
				+ ", role=" + role + ", policyNo=" + policyNo + ", clientId=" + clientId + "]";
	}
	
}
