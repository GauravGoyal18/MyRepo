package com.ipru.groups.vo;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class FundDataGratuityVO implements Serializable {

	private String funddesc;
	private double units;
	private double navValue;
	private double totalAmount;
	private String sfin;

	public synchronized String getFunddesc() {
		return funddesc;
	}

	public synchronized void setFunddesc(String funddesc) {
		this.funddesc = funddesc;
	}

	public synchronized double getUnits() {
		return units;
	}

	public synchronized void setUnits(double units) {
		this.units = units;
	}

	public synchronized double getNavValue() {
		return navValue;
	}

	public synchronized void setNavValue(double navValue) {
		this.navValue = navValue;
	}

	public synchronized double getTotalAmount() {
		return totalAmount;
	}

	public synchronized void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public synchronized String getSfin() {
		return sfin;
	}

	public synchronized void setSfin(String sfin) {
		this.sfin = sfin;
	}

	@Override
	public String toString() {
		return "FundDataGratuityVO [funddesc=" + funddesc + ", units=" + units
				+ ", navValue=" + navValue + ", totalAmount=" + totalAmount
				+ ", sfin=" + sfin + "]";
	}

}
