package com.ipru.groups.vo;
import java.io.Serializable;

public class CountryDetailsVO implements Serializable {


	public String countryCode;
	public String countryName;
	
	
	
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	@Override
	public String toString() {
		return "CountryDetailsVO [countryCode=" + countryCode + ", countryName=" + countryName + "]";
	}
	
	
	
	
	
}