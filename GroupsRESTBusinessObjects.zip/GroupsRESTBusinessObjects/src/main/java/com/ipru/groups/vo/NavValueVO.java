package com.ipru.groups.vo;

import java.io.Serializable;
import java.math.BigDecimal;

public class NavValueVO implements Serializable {
	
	private BigDecimal navValue;

	public BigDecimal getNavValue() {
		return navValue;
	}

	public void setNavValue(BigDecimal navValue) {
		this.navValue = navValue;
	}

	@Override
	public String toString() {
		return "getNavValueVO [navValue=" + navValue + "]";
	}
	
	

}
