package com.ipru.groups.vo;

import java.io.Serializable;
import java.math.BigDecimal;

public class NavValueBO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigDecimal navValue;

	public BigDecimal getNavValue() {
		return navValue;
	}

	public void setNavValue(BigDecimal navValue) {
		this.navValue = navValue;
	}

	@Override
	public String toString() {
		return "NavValueBO [navValue=" + navValue + "]";
	}
	
}
