package com.ipru.groups.vo;


import java.io.Serializable;
import java.util.Date;

public class SaMemberStatus  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNo;
	private String empId;
	private String status;
	private String clientId;
	private Long count;
	
	
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	public Long getCount() {
		return count;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "SaMemberStatus [policyNo=" + policyNo + ", empId=" + empId + ", status=" + status + ", clientId=" + clientId + ", count=" + count + "]";
	}
	
	
	

	
}
