package com.ipru.groups.vo;

public class TestVO {
	private String offerNAV;

	public String getDescription() {
		return offerNAV;
	}

	public void setDescription(String offerNAV) {
		this.offerNAV = offerNAV;
	}

	@Override
	public String toString() {
		return "TestVO [description=" + offerNAV + "]";
	}
	

}
