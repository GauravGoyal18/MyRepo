package com.ipru.groups.vo;

import java.io.Serializable;


public class CoiResponseDataVO implements Serializable{

	private String masterpolicy;
	private String policynumber;
	private String nameProposer;
	private String address;
	private String nameLa;
	private String birthdate;
	private String age;
	private String employeeid;
	private String sumassured;
	private String dateCmncmentCover;
	private String terminationDate;
	private String annualReturnDate;
	private String pannumber;
	private String folionumber;
	private String premium;
	private String premiumMode;
	private String schemeName;
	private String uinno;
	private String applicationDt;
	private String policyType;
	private String companyname;
	private String employeename;
	private String dateofjoiningscheme;
	private String productUin;
	private String clientStatus;
	
	private String nomineeName;
	private String nomineeAge;
	private String nomineeRelation;
	
	private String appointeeName ;
	
	
	private String docFlag;

	
	public String getNomineeAge() {
		return nomineeAge;
	}
	public void setNomineeAge(String nomineeAge) {
		this.nomineeAge = nomineeAge;
	}
	public String getNomineeName() {
		return nomineeName;
	}
	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}
	
	public String getNomineeRelation() {
		return nomineeRelation;
	}
	public void setNomineeRelation(String nomineeRelation) {
		this.nomineeRelation = nomineeRelation;
	}
	public String getAppointeeName() {
		return appointeeName;
	}
	public void setAppointeeName(String appointeeName) {
		this.appointeeName = appointeeName;
	}
	public String getClientStatus() {
		return clientStatus;
	}
	public void setClientStatus(String clientStatus) {
		this.clientStatus = clientStatus;
	}
	public String getMasterpolicy() {
		return masterpolicy;
	}
	public void setMasterpolicy(String masterpolicy) {
		this.masterpolicy = masterpolicy;
	}
	public String getPolicynumber() {
		return policynumber;
	}
	public void setPolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}
	public String getNameProposer() {
		return nameProposer;
	}
	public void setNameProposer(String nameProposer) {
		this.nameProposer = nameProposer;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getNameLa() {
		return nameLa;
	}
	public void setNameLa(String nameLa) {
		this.nameLa = nameLa;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}
	public String getSumassured() {
		return sumassured;
	}
	public void setSumassured(String sumassured) {
		this.sumassured = sumassured;
	}
	public String getDateCmncmentCover() {
		return dateCmncmentCover;
	}
	public void setDateCmncmentCover(String dateCmncmentCover) {
		this.dateCmncmentCover = dateCmncmentCover;
	}
	public String getTerminationDate() {
		return terminationDate;
	}
	public void setTerminationDate(String terminationDate) {
		this.terminationDate = terminationDate;
	}
	public String getAnnualReturnDate() {
		return annualReturnDate;
	}
	public void setAnnualReturnDate(String annualReturnDate) {
		this.annualReturnDate = annualReturnDate;
	}
	public String getPannumber() {
		return pannumber;
	}
	public void setPannumber(String pannumber) {
		this.pannumber = pannumber;
	}
	public String getFolionumber() {
		return folionumber;
	}
	public void setFolionumber(String folionumber) {
		this.folionumber = folionumber;
	}
	public String getPremium() {
		return premium;
	}
	public void setPremium(String premium) {
		this.premium = premium;
	}
	public String getPremiumMode() {
		return premiumMode;
	}
	public void setPremiumMode(String premiumMode) {
		this.premiumMode = premiumMode;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getUinno() {
		return uinno;
	}
	public void setUinno(String uinno) {
		this.uinno = uinno;
	}
	public String getApplicationDt() {
		return applicationDt;
	}
	public void setApplicationDt(String applicationDt) {
		this.applicationDt = applicationDt;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getEmployeename() {
		return employeename;
	}
	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}
	public String getDateofjoiningscheme() {
		return dateofjoiningscheme;
	}
	public void setDateofjoiningscheme(String dateofjoiningscheme) {
		this.dateofjoiningscheme = dateofjoiningscheme;
	}
	public String getProductUin() {
		return productUin;
	}
	public void setProductUin(String productUin) {
		this.productUin = productUin;
	}
	
	public String getDocFlag() {
		return docFlag;
	}
	public void setDocFlag(String docFlag) {
		this.docFlag = docFlag;
	}
	@Override
	public String toString() {
		return "CoiResponseDataVO [masterpolicy=" + masterpolicy
				+ ", policynumber=" + policynumber + ", nameProposer="
				+ nameProposer + ", address=" + address + ", nameLa=" + nameLa
				+ ", birthdate=" + birthdate + ", age=" + age + ", employeeid="
				+ employeeid + ", sumassured=" + sumassured
				+ ", dateCmncmentCover=" + dateCmncmentCover
				+ ", terminationDate=" + terminationDate
				+ ", annualReturnDate=" + annualReturnDate + ", pannumber="
				+ pannumber + ", folionumber=" + folionumber + ", premium="
				+ premium + ", premiumMode=" + premiumMode + ", schemeName="
				+ schemeName + ", uinno=" + uinno + ", applicationDt="
				+ applicationDt + ", policyType=" + policyType
				+ ", companyname=" + companyname + ", employeename="
				+ employeename + ", dateofjoiningscheme=" + dateofjoiningscheme
				+ ", productUin=" + productUin + ", clientStatus="
				+ clientStatus + ", nomineeName=" + nomineeName
				+ ", nomineeAge=" + nomineeAge + ", nomineeRelation="
				+ nomineeRelation + ", appointeeName=" + appointeeName
				+ ", docFlag=" + docFlag + "]";
	}
	
	
	
}
