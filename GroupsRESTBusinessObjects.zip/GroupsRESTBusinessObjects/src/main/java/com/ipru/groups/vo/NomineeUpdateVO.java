package com.ipru.groups.vo;

public class NomineeUpdateVO {
	private String beneficaryName;
	private String dob;
	private String relation;
	private String appointeeRelation;
	private String appointeeName;
	private int sharePer;

	public NomineeUpdateVO() {
		super();
		
	}

	public String getBeneficaryName() {
		return beneficaryName;
	}

	public void setBeneficaryName(String beneficaryName) {
		this.beneficaryName = beneficaryName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getAppointeeRelation() {
		return appointeeRelation;
	}

	public void setAppointeeRelation(String appointeeRelation) {
		this.appointeeRelation = appointeeRelation;
	}

	public String getAppointeeName() {
		return appointeeName;
	}

	public void setAppointeeName(String appointeeName) {
		this.appointeeName = appointeeName;
	}

	public int getSharePer() {
		return sharePer;
	}

	public void setSharePer(int sharePer) {
		this.sharePer = sharePer;
	}

	@Override
	public String toString() {
		return "NomineeUpdatePo [beneficaryName=" + beneficaryName + ", dob=" + dob + ", relation=" + relation + ", appointeeRelation=" + appointeeRelation + ", appointeeName=" + appointeeName
				+ ", sharePer=" + sharePer + "]";
	}

}
