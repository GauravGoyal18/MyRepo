package com.ipru.groups.vo;

import java.io.Serializable;
import java.math.BigDecimal;

public class OpeningBalanceVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	BigDecimal amount;
	BigDecimal  NAVValue;
	String closingDate;
	@Override
	public String toString() {
		return "OpeningBalanceVO [amount=" + amount + ", NAVValue=" + NAVValue
				+ ", closingDate=" + closingDate + "]";
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getNAVValue() {
		return NAVValue;
	}
	public void setNAVValue(BigDecimal nAVValue) {
		NAVValue = nAVValue;
	}
	public String getClosingDate() {
		return closingDate;
	}
	public void setClosingDate(String closingDate) {
		this.closingDate = closingDate;
	}

}
