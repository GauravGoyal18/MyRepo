package com.ipru.groups.vo;

import java.io.Serializable;

public class NavDateBO implements Serializable{
	private String navDate;

	public String getNavDate() {
		return navDate;
	}

	public void setNavDate(String navDate) {
		this.navDate = navDate;
	}

	@Override
	public String toString() {
		return "NavDateBO [navDate=" + navDate + "]";
	}
	
	

}
