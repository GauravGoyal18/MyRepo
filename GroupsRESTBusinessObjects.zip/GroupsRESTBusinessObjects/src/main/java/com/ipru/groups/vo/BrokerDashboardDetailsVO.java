package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;



public class BrokerDashboardDetailsVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String branchCode;
	private String nationalCode;
	private String licenseValidityDate;
	
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getNationalCode() {
		return nationalCode;
	}
	public void setNationalCode(String nationalCode) {
		this.nationalCode = nationalCode;
	}
	
	
	public String getLicenseValidityDate() {
		return licenseValidityDate;
	}
	public void setLicenseValidityDate(String licenseValidityDate) {
		this.licenseValidityDate = licenseValidityDate;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
