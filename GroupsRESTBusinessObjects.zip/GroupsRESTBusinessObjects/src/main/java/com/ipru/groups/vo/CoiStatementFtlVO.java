package com.ipru.groups.vo;

public class CoiStatementFtlVO {

}
