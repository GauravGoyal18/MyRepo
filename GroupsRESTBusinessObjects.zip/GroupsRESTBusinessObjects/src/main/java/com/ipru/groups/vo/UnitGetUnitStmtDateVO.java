package com.ipru.groups.vo;

import java.io.Serializable;

public class UnitGetUnitStmtDateVO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String firstDay;

	public String getFirstDay() {
		return firstDay;
	}

	public void setFirstDay(String firstDay) {
		this.firstDay = firstDay;
	}

	@Override
	public String toString() {
		return "UnitGetUnitStmtDateVO [firstDay=" + firstDay + "]";
	}
	
	

}
