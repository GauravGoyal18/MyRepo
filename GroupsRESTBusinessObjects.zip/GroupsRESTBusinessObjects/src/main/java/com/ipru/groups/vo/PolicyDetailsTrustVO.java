package com.ipru.groups.vo;

import java.io.Serializable;

import java.util.Date;



public class PolicyDetailsTrustVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private String policyType;
	private String policyNo;
	private String trustName;
	private String salutation;
	private String trusteeName;
	private String role;
	private String clientId;
	private String policyCommencementDate;
	private String typeOfScheme;
	private long noOfMembers;
	private double fund;
	private String unitCode;
	private String unitName;
	private String renewalNo;
	private String productSysKey;
	private String productName;
	private String statusSysKey;
	private String productCode;
	private String premiumMode;
	private String companyAddress;
	private String ard;
	private String schemeJoiningDate;
	
	public long getNoOfMembers() {
		return noOfMembers;
	}

	public void setNoOfMembers(long noOfMembers) {
		this.noOfMembers = noOfMembers;
	}

	public double getFund() {
		return fund;
	}

	public void setFund(double fund) {
		this.fund = fund;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getTrustName() {
		return trustName;
	}

	public void setTrustName(String trustName) {
		this.trustName = trustName;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getTrusteeName() {
		return trusteeName;
	}

	public void setTrusteeName(String trusteeName) {
		this.trusteeName = trusteeName;
	}
	
	

	public String getPolicyCommencementDate() {
		return policyCommencementDate;
	}

	public void setPolicyCommencementDate(String policyCommencementDate) {
		this.policyCommencementDate = policyCommencementDate;
	}

	public String getTypeOfScheme() {
		return typeOfScheme;
	}

	public void setTypeOfScheme(String typeOfScheme) {
		this.typeOfScheme = typeOfScheme;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}


	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getRenewalNo() {
		return renewalNo;
	}

	public void setRenewalNo(String renewalNo) {
		this.renewalNo = renewalNo;
	}

	public String getProductSysKey() {
		return productSysKey;
	}

	public void setProductSysKey(String productSysKey) {
		this.productSysKey = productSysKey;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getStatusSysKey() {
		return statusSysKey;
	}

	public void setStatusSysKey(String statusSysKey) {
		this.statusSysKey = statusSysKey;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getPremiumMode() {
		return premiumMode;
	}

	public void setPremiumMode(String premiumMode) {
		this.premiumMode = premiumMode;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	
	public String getArd() {
		return ard;
	}

	public void setArd(String ard) {
		this.ard = ard;
	}

	public String getSchemeJoiningDate() {
		return schemeJoiningDate;
	}

	public void setSchemeJoiningDate(String schemeJoiningDate) {
		this.schemeJoiningDate = schemeJoiningDate;
	}

	@Override
	public String toString() {
		return "PolicyDetailsTrustVO [id=" + id + ", policyType=" + policyType
				+ ", policyNo=" + policyNo + ", trustName=" + trustName
				+ ", salutation=" + salutation + ", trusteeName=" + trusteeName
				+ ", role=" + role + ", clientId=" + clientId
				+ ", policyCommencementDate=" + policyCommencementDate
				+ ", typeOfScheme=" + typeOfScheme + ", noOfMembers="
				+ noOfMembers + ", fund=" + fund + ", unitCode=" + unitCode
				+ ", unitName=" + unitName + ", renewalNo=" + renewalNo
				+ ", productSysKey=" + productSysKey + ", productName="
				+ productName + ", statusSysKey=" + statusSysKey
				+ ", productCode=" + productCode + ", premiumMode="
				+ premiumMode + ", companyAddress=" + companyAddress + ", ard="
				+ ard + ", schemeJoiningDate=" + schemeJoiningDate + "]";
	}
	
	
}
