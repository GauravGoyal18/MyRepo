package com.ipru.groups.vo;

import java.io.Serializable;

//import com.tcs.vo.BaseVO;

public class GroupsBaseVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String clientId;
	private String policyNo;
	private String productType;
	private String role;
	private long functionalityId;
	private String memberType;
	private String webClientId;
	private String policykey;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public long getFunctionalityId() {
		return functionalityId;
	}

	public void setFunctionalityId(long functionalityId) {
		this.functionalityId = functionalityId;
	}

	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	public String getWebClientId() {
		return webClientId;
	}

	public void setWebClientId(String webClientId) {
		this.webClientId = webClientId;
	}

	public String getPolicykey() {
		return policykey;
	}

	public void setPolicykey(String policykey) {
		this.policykey = policykey;
	}

	@Override
	public String toString() {
		return "GroupsBaseVO [clientId=" + clientId + ", policyNo=" + policyNo
				+ ", productType=" + productType + ", role=" + role
				+ ", functionalityId=" + functionalityId + ", memberType="
				+ memberType + ", webClientId=" + webClientId + ", policykey="
				+ policykey + "]";
	}

	
}
