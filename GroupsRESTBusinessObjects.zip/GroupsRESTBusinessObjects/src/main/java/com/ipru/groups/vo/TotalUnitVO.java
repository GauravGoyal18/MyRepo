package com.ipru.groups.vo;

import java.io.Serializable;


public class TotalUnitVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String description;
	private String decode;
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDecode() {
		return decode;
	}
	public void setDecode(String decode) {
		this.decode = decode;
	}
	@Override
	public String toString() {
		return "TotalUnitVO [description=" + description + ", decode=" + decode
				+ "]";
	}
	

}
