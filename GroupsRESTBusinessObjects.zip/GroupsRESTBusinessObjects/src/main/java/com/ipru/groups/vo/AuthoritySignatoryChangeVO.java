package com.ipru.groups.vo;

import java.io.Serializable;

public class AuthoritySignatoryChangeVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String requestId;
	public String title;
	public String firstName;
	public String middleName;
	public String lastName;
	public String emailId;
	public String mobnumber;
	public String active;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "AuthoritySignatoryChangeBO [requestId=" + requestId + ", title=" + title + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName + ", emailId="
				+ emailId + ", mobnumber=" + mobnumber + ", active=" + active + "]";
	}

	public String getMobnumber() {
		return mobnumber;
	}

	public void setMobnumber(String mobnumber) {
		this.mobnumber = mobnumber;
	}

}
