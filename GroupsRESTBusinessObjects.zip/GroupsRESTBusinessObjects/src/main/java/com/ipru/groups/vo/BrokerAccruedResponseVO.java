package com.ipru.groups.vo;

import java.io.Serializable;

public class BrokerAccruedResponseVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String branchCode;
	private String nationalCode;
	private String policynumber;
	private String premiumWithStec;
	private String premiumExclStec;
	private String commissionAmount;
	private String productName;
	private String policyIssuanceDate;
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getNationalCode() {
		return nationalCode;
	}
	public void setNationalCode(String nationalCode) {
		this.nationalCode = nationalCode;
	}
	public String getPolicynumber() {
		return policynumber;
	}
	public void setPolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}
	public String getPremiumWithStec() {
		return premiumWithStec;
	}
	public void setPremiumWithStec(String premiumWithStec) {
		this.premiumWithStec = premiumWithStec;
	}
	public String getPremiumExclStec() {
		return premiumExclStec;
	}
	public void setPremiumExclStec(String premiumExclStec) {
		this.premiumExclStec = premiumExclStec;
	}
	
	
	public String getCommissionAmount() {
		return commissionAmount;
	}
	public void setCommissionAmount(String commissionAmount) {
		this.commissionAmount = commissionAmount;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPolicyIssuanceDate() {
		return policyIssuanceDate;
	}
	public void setPolicyIssuanceDate(String policyIssuanceDate) {
		this.policyIssuanceDate = policyIssuanceDate;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
