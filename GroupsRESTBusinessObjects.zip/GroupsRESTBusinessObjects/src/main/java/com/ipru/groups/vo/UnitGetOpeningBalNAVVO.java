package com.ipru.groups.vo;

import java.io.Serializable;

public class UnitGetOpeningBalNAVVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String offerNav;

	public String getOfferNav() {
		return offerNav;
	}

	public void setOfferNav(String offerNav) {
		this.offerNav = offerNav;
	}

	@Override
	public String toString() {
		return "UnitGetOpeningBalNAV [offerNav=" + offerNav + "]";
	}
	

}
