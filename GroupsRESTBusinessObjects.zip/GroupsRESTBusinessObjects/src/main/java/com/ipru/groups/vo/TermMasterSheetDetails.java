package com.ipru.groups.vo;


public class TermMasterSheetDetails {
	private String policyNo;
	private String unitCode;
	private String policyKey;
	private String renewalNo;
	private String clientId;
	private String policyType;
	private String policyStatus;
	private String productCode;
	private String clientCode;
	private String companyName;
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getUnitCode() {
		return unitCode;
	}
	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}
	public String getPolicyKey() {
		return policyKey;
	}
	public void setPolicyKey(String policyKey) {
		this.policyKey = policyKey;
	}
	public String getRenewalNo() {
		return renewalNo;
	}
	public void setRenewalNo(String renewalNo) {
		this.renewalNo = renewalNo;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getPolicyStatus() {
		return policyStatus;
	}
	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getClientCode() {
		return clientCode;
	}
	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	@Override
	public String toString() {
		return "TermMasterSheetDetails [policyNo=" + policyNo + ", unitCode=" + unitCode + ", policyKey=" + policyKey + ", renewalNo=" + renewalNo + ", clientId=" + clientId + ", policyType="
				+ policyType + ", policyStatus=" + policyStatus + ", productCode=" + productCode + ", clientCode=" + clientCode + ", companyName=" + companyName + "]";
	}
	
	
	
}
