package com.ipru.groups.vo;

public class LatestNavVO {

	private String fundCode;
	private String fundDesc;
	private String sfin;
	private String navDate;
	private String navValue;

	public synchronized String getFundCode() {
		return fundCode;
	}

	public synchronized void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}

	public synchronized String getFundDesc() {
		return fundDesc;
	}

	public synchronized void setFundDesc(String fundDesc) {
		this.fundDesc = fundDesc;
	}

	public synchronized String getSfin() {
		return sfin;
	}

	public synchronized void setSfin(String sfin) {
		this.sfin = sfin;
	}

	public synchronized String getNavDate() {
		return navDate;
	}

	public synchronized void setNavDate(String navDate) {
		this.navDate = navDate;
	}

	public synchronized String getNavValue() {
		return navValue;
	}

	public synchronized void setNavValue(String navValue) {
		this.navValue = navValue;
	}

	@Override
	public String toString() {
		return "LatestNav [fundCode=" + fundCode + ", fundDesc=" + fundDesc + ", sfin=" + sfin + ", navDate=" + navDate + ", navValue=" + navValue + "]";
	}

}
