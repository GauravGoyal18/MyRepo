package com.ipru.groups.vo;

import java.io.Serializable;

public class CompanyAddressChangeVO implements Serializable {

	String companyAddress_addressType;
	String companyAddress_address1;

	public String getCompanyAddress_addressType() {
		return companyAddress_addressType;
	}

	public void setCompanyAddress_addressType(String companyAddress_addressType) {
		this.companyAddress_addressType = companyAddress_addressType;
	}

	public String getCompanyAddress_address1() {
		return companyAddress_address1;
	}

	public void setCompanyAddress_address1(String companyAddress_address1) {
		this.companyAddress_address1 = companyAddress_address1;
	}

	@Override
	public String toString() {
		return "CompanyAddressChangeVO [companyAddress_addressType=" + companyAddress_addressType + ", companyAddress_address1=" + companyAddress_address1 + "]";
	}

}
