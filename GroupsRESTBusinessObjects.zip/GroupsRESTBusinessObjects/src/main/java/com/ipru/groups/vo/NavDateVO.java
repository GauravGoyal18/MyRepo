package com.ipru.groups.vo;

import java.io.Serializable;

public class NavDateVO implements Serializable {
	public String getNavDate() {
		return navDate;
	}

	public void setNavDate(String navDate) {
		this.navDate = navDate;
	}

	private String navDate;

	@Override
	public String toString() {
		return "NavDateVO [navDate=" + navDate + "]";
	}
	
	
	

}
