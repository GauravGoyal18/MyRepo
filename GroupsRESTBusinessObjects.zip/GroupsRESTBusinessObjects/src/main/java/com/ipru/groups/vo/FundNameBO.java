package com.ipru.groups.vo;

import java.io.Serializable;

public class FundNameBO implements Serializable{
	private String fundDesc;

	public String getFundDesc() {
		return fundDesc;
	}

	public void setFundDesc(String fundDesc) {
		this.fundDesc = fundDesc;
	}

	@Override
	public String toString() {
		return "FundNameBO [fundDesc=" + fundDesc + "]";
	}

	

}
