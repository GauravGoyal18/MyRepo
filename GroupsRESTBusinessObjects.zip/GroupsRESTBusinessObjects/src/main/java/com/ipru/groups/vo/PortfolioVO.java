package com.ipru.groups.vo;

public class PortfolioVO {

	private String un1;
	private String un2;
	private String amount;
	private String units;
	private String navValue;
	private String fundcode;
	private String navDate;
	
	
	public String getNavValue() {
		return navValue;
	}
	public void setNavValue(String navValue) {
		this.navValue = navValue;
	}
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	public String getUn1() {
		return un1;
	}
	public void setUn1(String un1) {
		this.un1 = un1;
	}
	public String getUn2() {
		return un2;
	}
	public void setUn2(String un2) {
		this.un2 = un2;
	}
	
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
/*	@Override
	public String toString() {
		return "PortfolioVO [un1=" + un1 + ", un2=" + un2 + ", amount="
				+ amount + ", units=" + units + ", navValue=" + navValue + "]";
	}*/
	public String getFundcode() {
		return fundcode;
	}

	public void setFundcode(String fundcode) {
		this.fundcode = fundcode;
	}
	
	
	public String getNavDate() {
		return navDate;
	}
	public void setNavDate(String navDate) {
		this.navDate = navDate;
	}
	@Override
	public String toString() {
		return "PortfolioVO [un1=" + un1 + ", un2=" + un2 + ", amount="
				+ amount + ", units=" + units + ", navValue=" + navValue
				+ ", fundcode=" + fundcode + ", navDate=" + navDate + "]";
	}
	
}
