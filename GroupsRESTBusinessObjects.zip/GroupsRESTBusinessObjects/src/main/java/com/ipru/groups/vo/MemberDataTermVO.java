package com.ipru.groups.vo;

public class MemberDataTermVO {

	private String policyNo;
	private String memberId;
	private String memberName;
	private String dateOfBirth;
	private String gender;
	private String dateOfJoining;
	private String unitCode;
	private String designation;
	private Double coverProvided;
	private Double coverRequested;
	private String medicalRequired;

	public MemberDataTermVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberDataTermVO(String policyNo, String memberId, String memberName, String dateOfBirth, String gender, String dateOfJoining, String unitCode, String designation, Double coverProvided, Double coverRequested, String medicalRequired) {
		super();
		this.policyNo = policyNo;
		this.memberId = memberId;
		this.memberName = memberName;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.dateOfJoining = dateOfJoining;
		this.unitCode = unitCode;
		this.designation = designation;
		this.coverProvided = coverProvided;
		this.coverRequested = coverRequested;
		this.medicalRequired = medicalRequired;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Double getCoverProvided() {
		return coverProvided;
	}

	public void setCoverProvided(Double coverProvided) {
		this.coverProvided = coverProvided;
	}

	public Double getCoverRequested() {
		return coverRequested;
	}

	public void setCoverRequested(Double coverRequested) {
		this.coverRequested = coverRequested;
	}

	public String getMedicalRequired() {
		return medicalRequired;
	}

	public void setMedicalRequired(String medicalRequired) {
		this.medicalRequired = medicalRequired;
	}

	@Override
	public String toString() {
		return "MemberDataTermVO [policyNo=" + policyNo + ", memberId=" + memberId + ", memberName=" + memberName + ", dateOfBirth=" + dateOfBirth + ", gender=" + gender + ", dateOfJoining="
				+ dateOfJoining + ", unitCode=" + unitCode + ", designation=" + designation + ", coverProvided=" + coverProvided + ", coverRequested=" + coverRequested + ", medicalRequired="
				+ medicalRequired + "]";
	}

}
