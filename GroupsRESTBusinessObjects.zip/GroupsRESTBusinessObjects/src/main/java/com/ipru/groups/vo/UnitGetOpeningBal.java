package com.ipru.groups.vo;

import java.io.Serializable;

public class UnitGetOpeningBal implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String sumFundAmount;
	private String sumUnits;
	
	public String getSumFundAmount() {
		return sumFundAmount;
	}
	public void setSumFundAmount(String sumFundAmount) {
		this.sumFundAmount = sumFundAmount;
	}
	public String getSumUnits() {
		return sumUnits;
	}
	public void setSumUnits(String sumUnits) {
		this.sumUnits = sumUnits;
	}
	@Override
	public String toString() {
		return "UnitGetOpeningBal [sumFundAmount=" + sumFundAmount
				+ ", sumUnits=" + sumUnits + "]";
	}
	
	
	
	
	
	
	
	

}
