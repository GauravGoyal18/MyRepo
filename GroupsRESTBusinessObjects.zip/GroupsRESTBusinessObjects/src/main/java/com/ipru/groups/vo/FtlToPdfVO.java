package com.ipru.groups.vo;

import java.io.Serializable;

public class FtlToPdfVO implements Serializable{

	private String ftlName;
	Serializable objectData;
	private String pdfName;
	
	
	
	public String getPdfName() {
		return pdfName;
	}
	public void setPdfName(String pdfName) {
		this.pdfName = pdfName;
	}
	public String getFtlName() {
		return ftlName;
	}
	public void setFtlName(String ftlName) {
		this.ftlName = ftlName;
	}
	public Serializable getObjectData() {
		return objectData;
	}
	public void setObjectData(Serializable objectData) {
		this.objectData = objectData;
	}
	@Override
	public String toString() {
		return "FtlToPdfVO [ftlName=" + ftlName + ", objectData=" + objectData
				+ ", pdfName=" + pdfName + "]";
	}
	
	
}
