package com.ipru.groups.vo;

import java.io.Serializable;

public class UnitGetClosingBal implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fundAmount;
	private String units;
	public String getFundAmount() {
		return fundAmount;
	}
	public void setFundAmount(String fundAmount) {
		this.fundAmount = fundAmount;
	}
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	@Override
	public String toString() {
		return "UnitGetClosingBal [fundAmount=" + fundAmount + ", units="
				+ units + "]";
	}
	
	

}
