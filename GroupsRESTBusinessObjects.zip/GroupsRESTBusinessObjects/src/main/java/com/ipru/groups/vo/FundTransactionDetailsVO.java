package com.ipru.groups.vo;

import java.io.Serializable;

public class FundTransactionDetailsVO implements Serializable {
	
	private String navDate;
	private String description;
	private String tranDescription;
	private String entryType;
	private String sumAmount;
	private String offerNAV;
	
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTranDescription() {
		return tranDescription;
	}
	public void setTranDescription(String tranDescription) {
		this.tranDescription = tranDescription;
	}
	public String getNavDate() {
		return navDate;
	}
	public void setNavDate(String navDate) {
		this.navDate = navDate;
	}
	public String getEntryType() {
		return entryType;
	}
	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}
	public String getSumAmount() {
		return sumAmount;
	}
	public void setSumAmount(String sumAmount) {
		this.sumAmount = sumAmount;
	}
	public String getOfferNAV() {
		return offerNAV;
	}
	public void setOfferNAV(String offerNAV) {
		this.offerNAV = offerNAV;
	}
	@Override
	public String toString() {
		return "FundTransactionDetailsVO [navDate=" + navDate
				+ ", description=" + description + ", tranDescription="
				+ tranDescription + ", entryType=" + entryType + ", sumAmount="
				+ sumAmount + ", offerNAV=" + offerNAV + "]";
	}
	
	
	
	
	
	

}
