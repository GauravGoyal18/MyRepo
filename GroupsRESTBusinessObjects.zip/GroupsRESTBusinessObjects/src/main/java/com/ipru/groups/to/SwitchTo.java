package com.ipru.groups.to;

import java.math.BigDecimal;

public class SwitchTo {

	private String funddesc;
	private String sfin;
	private String fundcode;
	private String units;
	private String navValue;
	private BigDecimal totalAmount;

	public String getFunddesc() {
		return funddesc;
	}

	public void setFunddesc(String funddesc) {
		this.funddesc = funddesc;
	}

	public String getSfin() {
		return sfin;
	}

	public void setSfin(String sfin) {
		this.sfin = sfin;
	}

	public String getFundcode() {
		return fundcode;
	}

	public void setFundcode(String fundcode) {
		this.fundcode = fundcode;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public String getNavValue() {
		return navValue;
	}

	public void setNavValue(String navValue) {
		this.navValue = navValue;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	@Override
	public String toString() {
		return "SwitchTo [funddesc=" + funddesc + ", sfin=" + sfin + ", fundcode=" + fundcode + ", units=" + units + ", navValue=" + navValue + ", totalAmount=" + totalAmount + "]";
	}

}
