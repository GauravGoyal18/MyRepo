package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;


public class PolicyDetailsMemberVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String policyNo;
	private String empId;
	private String empName;
	private String dateOfJoiningScheme;
	private String clientId;
	private String clientName;
	private String policyType;
	private String policyCommencementDate;
	private String typeOfScheme;
	private double fund;
	private String productName;
	private String statusSysKey;
	private String productCode;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	public String getDateOfJoiningScheme() {
		return dateOfJoiningScheme;
	}

	public void setDateOfJoiningScheme(String dateOfJoiningScheme) {
		this.dateOfJoiningScheme = dateOfJoiningScheme;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	

	public String getPolicyCommencementDate() {
		return policyCommencementDate;
	}

	public void setPolicyCommencementDate(String policyCommencementDate) {
		this.policyCommencementDate = policyCommencementDate;
	}

	public String getTypeOfScheme() {
		return typeOfScheme;
	}

	public void setTypeOfScheme(String typeOfScheme) {
		this.typeOfScheme = typeOfScheme;
	}

	public double getFund() {
		return fund;
	}

	public void setFund(double fund) {
		this.fund = fund;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getStatusSysKey() {
		return statusSysKey;
	}

	public void setStatusSysKey(String statusSysKey) {
		this.statusSysKey = statusSysKey;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

}
