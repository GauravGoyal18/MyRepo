package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;

public class ServiceWebpagePolicyTypeVO implements Serializable{
	
	/**
	 * 
	 */
	private String nationalCode;
	private String branchCode;
	private String loginType;
	private String policyNumber;
	private String renewalNo;
	private String clientName;
	private String productCode;
	private Date RCD;
	private String UINNO;
	private String productName;
	private String productType;
	private String statusKey;
	private Date anniversaryDT;
	private String zone;
	private String rmName;
	private String state;
	private double premiumAmount;
	private double premiumExclsTec;
	private Date policyIssuanceDate;
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getRenewalNo() {
		return renewalNo;
	}
	public void setRenewalNo(String renewalNo) {
		this.renewalNo = renewalNo;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public Date getRCD() {
		return RCD;
	}
	public void setRCD(Date rCD) {
		RCD = rCD;
	}
	public String getUINNO() {
		return UINNO;
	}
	public void setUINNO(String uINNO) {
		UINNO = uINNO;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getStatusKey() {
		return statusKey;
	}
	public void setStatusKey(String statusKey) {
		this.statusKey = statusKey;
	}
	public Date getAnniversaryDT() {
		return anniversaryDT;
	}
	public void setAnniversaryDT(Date anniversaryDT) {
		this.anniversaryDT = anniversaryDT;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRmName() {
		return rmName;
	}
	public void setRmName(String rmName) {
		this.rmName = rmName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public double getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	public double getPremiumExclsTec() {
		return premiumExclsTec;
	}
	public void setPremiumExclsTec(double premiumExclsTec) {
		this.premiumExclsTec = premiumExclsTec;
	}
	public Date getPolicyIssuanceDate() {
		return policyIssuanceDate;
	}
	public void setPolicyIssuanceDate(Date policyIssuanceDate) {
		this.policyIssuanceDate = policyIssuanceDate;
	}
	
	public String getNationalCode() {
		return nationalCode;
	}
	public void setNationalCode(String nationalCode) {
		this.nationalCode = nationalCode;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
	@Override
	public String toString() {
		return "ServiceWebpagePolicyTypeVO [nationalCode=" + nationalCode
				+ ", branchCode=" + branchCode + ", loginType=" + loginType
				+ ", policyNumber=" + policyNumber + ", renewalNo=" + renewalNo
				+ ", clientName=" + clientName + ", productCode=" + productCode
				+ ", RCD=" + RCD + ", UINNO=" + UINNO + ", productName="
				+ productName + ", productType=" + productType + ", statusKey="
				+ statusKey + ", anniversaryDT=" + anniversaryDT + ", zone="
				+ zone + ", rmName=" + rmName + ", state=" + state
				+ ", premiumAmount=" + premiumAmount + ", premiumExclsTec="
				+ premiumExclsTec + ", policyIssuanceDate="
				+ policyIssuanceDate + "]";
	}
	
	
	
	
	
	

}
