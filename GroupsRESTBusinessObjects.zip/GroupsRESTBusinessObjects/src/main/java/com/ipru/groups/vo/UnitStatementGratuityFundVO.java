package com.ipru.groups.vo;

import java.io.Serializable;

public class UnitStatementGratuityFundVO implements Serializable {

	
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private String navDate;
private String transDescription;
private String fundAmount;
private String navRate;
private String units;
private String expr1;


public String getNavDate() {
	return navDate;
}
public void setNavDate(String navDate) {
	this.navDate = navDate;
}
public String getTransDescription() {
	return transDescription;
}
public void setTransDescription(String transDescription) {
	this.transDescription = transDescription;
}
public String getFundAmount() {
	return fundAmount;
}
public void setFundAmount(String fundAmount) {
	this.fundAmount = fundAmount;
}
public String getNavRate() {
	return navRate;
}
public void setNavRate(String navRate) {
	this.navRate = navRate;
}
public String getUnits() {
	return units;
}
public void setUnits(String units) {
	this.units = units;
}
public String getExpr1() {
	return expr1;
}
public void setExpr1(String expr1) {
	this.expr1 = expr1;
}
@Override
public String toString() {
	return "UnitStatementGratuityVO [navDate=" + navDate
			+ ", transDescription=" + transDescription + ", fundAmount="
			+ fundAmount + ", navRate=" + navRate + ", units=" + units
			+ ", expr1=" + expr1 + "]";
}




}
