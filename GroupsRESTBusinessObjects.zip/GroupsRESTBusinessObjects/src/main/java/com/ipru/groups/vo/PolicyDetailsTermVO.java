package com.ipru.groups.vo;

import java.io.Serializable;
import java.util.Date;



public class PolicyDetailsTermVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String policyNo;
	private String unitCode;
	private String unitName;
	private String dateOfJoiningScheme;
	private String clientId;
	private String clientName;
	private String policyType;
	private String policyCommencementDate;
	private String typeOfScheme;
	private double fund;
	private String productName;
	private String statusSysKey;
	private String productCode;
	private String premiumMode;
	private String companyAddress;
	private String ard;

	public PolicyDetailsTermVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PolicyDetailsTermVO(String policyNo, String unitCode,
			String unitName, String dateOfJoiningScheme, String clientId,
			String clientName, String policyType, String policyCommencementDate,
			String typeOfScheme, double fund, Date schemeJoiningDate,
			String productName, String statusSysKey, String productCode,
			String premiumMode, String companyAddress, String ard) {
		super();
		this.policyNo = policyNo;
		this.unitCode = unitCode;
		this.unitName = unitName;
		this.dateOfJoiningScheme = dateOfJoiningScheme;
		this.clientId = clientId;
		this.clientName = clientName;
		this.policyType = policyType;
		this.policyCommencementDate = policyCommencementDate;
		this.typeOfScheme = typeOfScheme;
		this.fund = fund;
		this.productName = productName;
		this.statusSysKey = statusSysKey;
		this.productCode = productCode;
		this.premiumMode = premiumMode;
		this.companyAddress = companyAddress;
		this.ard = ard;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	
	public String getDateOfJoiningScheme() {
		return dateOfJoiningScheme;
	}

	public void setDateOfJoiningScheme(String dateOfJoiningScheme) {
		this.dateOfJoiningScheme = dateOfJoiningScheme;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	
	public String getPolicyCommencementDate() {
		return policyCommencementDate;
	}

	public void setPolicyCommencementDate(String policyCommencementDate) {
		this.policyCommencementDate = policyCommencementDate;
	}

	public String getTypeOfScheme() {
		return typeOfScheme;
	}

	public void setTypeOfScheme(String typeOfScheme) {
		this.typeOfScheme = typeOfScheme;
	}

	public double getFund() {
		return fund;
	}

	public void setFund(double fund) {
		this.fund = fund;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getStatusSysKey() {
		return statusSysKey;
	}

	public void setStatusSysKey(String statusSysKey) {
		this.statusSysKey = statusSysKey;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getPremiumMode() {
		return premiumMode;
	}

	public void setPremiumMode(String premiumMode) {
		this.premiumMode = premiumMode;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	public String getArd() {
		return ard;
	}

	public void setArd(String ard) {
		this.ard = ard;
	}
	

}
