package com.ipru.groups.vo;

import java.util.Date;

public class MemberDataTrustVO {
	private String memberId;
	private String memberName;
	private String dateOfJoining;
	private double units;
	private String dateOfBirth;

	public synchronized String getMemberId() {
		return memberId;
	}

	public synchronized void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public synchronized String getMemberName() {
		return memberName;
	}

	public synchronized void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public synchronized String getDateOfJoining() {
		return dateOfJoining;
	}

	public synchronized void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public synchronized double getUnits() {
		return units;
	}

	public synchronized void setUnits(double units) {
		this.units = units;
	}

	public synchronized String getDateOfBirth() {
		return dateOfBirth;
	}

	public synchronized void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {
		return "MemberDataTrustVO [memberId=" + memberId + ", memberName="
				+ memberName + ", dateOfJoining=" + dateOfJoining + ", units="
				+ units + ", dateOfBirth=" + dateOfBirth + "]";
	}

}
