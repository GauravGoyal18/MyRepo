package com.ipru.groups.vo;

import java.io.Serializable;

public class BrokerBIDRestVO implements Serializable {

	private String clientName;

	private String renewalNo;

	private String policyKey;

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getRenewalNo() {
		return renewalNo;
	}

	public void setRenewalNo(String renewalNo) {
		this.renewalNo = renewalNo;
	}

	public String getPolicyKey() {
		return policyKey;
	}

	public void setPolicyKey(String policyKey) {
		this.policyKey = policyKey;
	}

}
