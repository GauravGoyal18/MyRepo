package com.ipru.groups.vo;

import java.io.Serializable;

public class FundNameVO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fundDesc;

	public String getFundDesc() {
		return fundDesc;
	}

	public void setFundDesc(String fundDesc) {
		this.fundDesc = fundDesc;
	}

	@Override
	public String toString() {
		return "FundNameVO [fundDesc=" + fundDesc + "]";
	}

	

}
