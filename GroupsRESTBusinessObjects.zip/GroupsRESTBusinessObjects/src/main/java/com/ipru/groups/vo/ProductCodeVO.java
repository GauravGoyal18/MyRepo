package com.ipru.groups.vo;

public class ProductCodeVO {

	private String polnumber;
	private String productcode;
	private String productname;
	private String producttype;

	public synchronized String getPolnumber() {
		return polnumber;
	}

	public synchronized void setPolnumber(String polnumber) {
		this.polnumber = polnumber;
	}

	public synchronized String getProductcode() {
		return productcode;
	}

	public synchronized void setProductcode(String productcode) {
		this.productcode = productcode;
	}

	public synchronized String getProductname() {
		return productname;
	}

	public synchronized void setProductname(String productname) {
		this.productname = productname;
	}

	public synchronized String getProducttype() {
		return producttype;
	}

	public synchronized void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	@Override
	public String toString() {
		return "ProductCodeBean [polnumber=" + polnumber + ", productcode=" + productcode + ", productname=" + productname + ", producttype=" + producttype + "]";
	}

}
