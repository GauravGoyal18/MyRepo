package com.ipru.groups.to;

public class LatestNavTO {

	private String fundCode;
	private String fundDesc;
	private String fundNAVEffectiveDate;
	private String fundNAV;
	private String preFundUnit;
	private String sfin;
	private String preFundAmount;

	public synchronized String getPreFundAmount() {
		return preFundAmount;
	}

	public synchronized void setPreFundAmount(String preFundAmount) {
		this.preFundAmount = preFundAmount;
	}

	public synchronized String getFundCode() {
		return fundCode;
	}

	public synchronized void setFundCode(String fundCode) {
		this.fundCode = fundCode;
	}

	public synchronized String getFundDesc() {
		return fundDesc;
	}

	public synchronized void setFundDesc(String fundDesc) {
		this.fundDesc = fundDesc;
	}

	public synchronized String getFundNAVEffectiveDate() {
		return fundNAVEffectiveDate;
	}

	public synchronized void setFundNAVEffectiveDate(String fundNAVEffectiveDate) {
		this.fundNAVEffectiveDate = fundNAVEffectiveDate;
	}

	public synchronized String getFundNAV() {
		return fundNAV;
	}

	public synchronized void setFundNAV(String fundNAV) {
		this.fundNAV = fundNAV;
	}

	public synchronized String getPreFundUnit() {
		return preFundUnit;
	}

	public synchronized void setPreFundUnit(String preFundUnit) {
		this.preFundUnit = preFundUnit;
	}

	public synchronized String getSfin() {
		return sfin;
	}

	public synchronized void setSfin(String sfin) {
		this.sfin = sfin;
	}

	@Override
	public String toString() {
		return "LatestNavTO [fundCode=" + fundCode + ", fundDesc=" + fundDesc + ", fundNAVEffectiveDate=" + fundNAVEffectiveDate + ", fundNAV=" + fundNAV + ", preFundUnit=" + preFundUnit + ", sfin="
				+ sfin + ", preFundAmount=" + preFundAmount + "]";
	}

}
